export const URL_SurveyBroadcastAPIV2= "https://a9aikwz2rg.execute-api.us-east-2.amazonaws.com"
export const URL_SurveyFormAdminAPIV2= "https://04g4bjuen6.execute-api.us-east-2.amazonaws.com"