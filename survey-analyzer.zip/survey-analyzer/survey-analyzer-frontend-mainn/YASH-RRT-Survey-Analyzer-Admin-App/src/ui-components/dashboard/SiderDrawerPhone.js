import React, { useState } from "react";
import { Menu, Drawer } from "antd";
import {
  LayoutFilled,
  MenuUnfoldOutlined,
  ContainerFilled,
} from "@ant-design/icons";
import { NavLink } from "react-router-dom";
import { brand, routes } from "../../util/constants";
import logo from "../../assests/img/newLogo2.png";

export default function SiderDrawerPhone() {
  const [visible, setVisible] = useState(false);
  const [placement] = useState("left");
  const showDrawer = () => {
    setVisible(true);
  };
  const onClose = () => {
    setVisible(false);
  };

  return (
    <span>
      <MenuUnfoldOutlined onClick={showDrawer} className="trigger-phone" />
      <Drawer
        placement={placement}
        closable={false}
        onClose={onClose}
        open={visible}
        key={placement}
      >
        <div className="side-header-small">
          <div className="brand-name">
            <div className="brand-logo">
              <div>
                <img
                  className="ms-4"
                  src={logo}
                  alt="Logo"
                  width={50}
                  height={50}
                />
              </div>
              <span
                style={{
                  fontSize: "19px",
                  margin: "-6px 0px 0px 10px",
                  color: "#fff",
                }}
                className="app-name"
                mode="full"
              >
                {brand.NAME}
              </span>
            </div>
          </div>
        </div>
        <Menu
          theme="light"
          mode="inline"
          defaultSelectedKeys={[window.location.pathname]}
        >
          <Menu.Item key={routes.ADMIN_DASHBOARD} icon={<LayoutFilled />}>
            <NavLink
              className="sider-links text-decoration-none"
              to={routes.ADMIN_DASHBOARD}
            >
              Dashboard
            </NavLink>
          </Menu.Item>
          <p class="menu-subhead" mode="full">
            OPERATIONS
          </p>
          <Menu.Item key={routes.FORM_BUILDER} icon={<ContainerFilled />}>
            <NavLink
              className="sider-links text-decoration-none"
              to={routes.FORM_BUILDER}
            >
              FORM BUILDER
            </NavLink>
          </Menu.Item>
          <Menu.Item key={routes.VIEW_FORM} icon={<ContainerFilled />}>
            <NavLink
              className="sider-links text-decoration-none"
              to={routes.VIEW_FORM}
            >
              VIEW FORM
            </NavLink>
          </Menu.Item>
        </Menu>
      </Drawer>
    </span>
  );
}
