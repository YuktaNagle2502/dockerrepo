import React from "react";
import { Menu } from "antd";
import { NavLink, useLocation } from "react-router-dom";
import { LayoutFilled, ContainerFilled, AuditOutlined, FileDoneOutlined } from "@ant-design/icons";
import { brand, routes } from "../../util/constants";
import logo from "../../assests/img/LogoSurveyLens.png";
// import logo from "../../assests/img/logo_white-removebg-preview.png";

export default function SiderMenu(props) {
  const location = useLocation();

  return (
    <div
      className={props.collapsed ? "sider-menu" : "sider-menu menu-position"}
    >
      <div className="side-header">
        <div className="brand-name">
          <div className="brand-logo">
            <img className="logo" src={logo} alt="Logo" />
            <span
              className="app-name mt-1"
              style={{ fontSize: "15px" }}
              mode="full"

            >
              {brand.NAME}
            </span>
          </div>
        </div>
      </div>

      <Menu
        theme="light"
        mode="inline"
        defaultSelectedKeys={[location.pathname]}
      >
        <Menu.Item
          key={routes.DASHBOARD}
          icon={<LayoutFilled />}
          className="menu-item"
        >
          <NavLink
            className="sider-links text-decoration-none"
            to={routes.DASHBOARD}
            style={{ fontSize: '12px' }}
          >
            Dashboard
          </NavLink>
        </Menu.Item>
        <p className="menu-subhead" mode="full">
          Operations
        </p>
        {/* <Menu.Item
          key={routes.FORM_BUILDER}
          icon={<AuditOutlined />}
          className="menu-item"
        >
          <NavLink
            className="sider-links text-decoration-none"
            to={routes.FORM_BUILDER}
            style={{fontSize : '12px'}}
          >
            Form Builder
          </NavLink>
        </Menu.Item> */}
        <Menu.Item
          key={routes.VIEW_FORM}
          icon={<ContainerFilled />}
          className="menu-item"
        >
          <NavLink
            className="sider-links text-decoration-none"
            to={routes.VIEW_FORM}
            style={{ fontSize: '12px' }}
          >
            Forms
          </NavLink>
        </Menu.Item>

        <Menu.Item
          key={routes.SURVEY_ANALYSER}
          icon={<FileDoneOutlined />}
          className="menu-item"
        >
          <NavLink
            className="sider-links text-decoration-none"
            to={routes.SURVEY_ANALYSER}
            style={{ fontSize: '12px' }}
          >
            Analytics
          </NavLink>
         
          
        </Menu.Item>
       

        {/* <Menu.Item
          key={routes.SURVEY_ANALYSER}
          icon={<FileDoneOutlined />}
          className="menu-item"
        > */}
        {/* <NavLink
            className="sider-links text-decoration-none"
            to={routes.Dashboard}
            style={{fontSize : '12px'}}
          >
            Dashboardd
          </NavLink> */}
        {/* </Menu.Item> */}

      </Menu>
    </div>
  );
}
