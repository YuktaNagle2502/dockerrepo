import React, { useState } from "react";
import { Input } from "antd";

const KeywordInput = () => {
  const [keyword, setKeyword] = useState("");

  const handleKeywordChange = (e) => {
    setKeyword(e.target.value);
  };

  return (
    <Input
      style={{ marginTop: "40px" }}
      placeholder="Enter keyword"
      value={keyword}
      onChange={handleKeywordChange}
    />
  );
};

export default KeywordInput;
