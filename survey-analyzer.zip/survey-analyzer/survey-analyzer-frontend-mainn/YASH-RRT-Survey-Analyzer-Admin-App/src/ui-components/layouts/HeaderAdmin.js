import React from "react";
import { Layout, Dropdown, Avatar } from "antd";
import { Link, useNavigate } from "react-router-dom";
import {
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  LogoutOutlined,
  UserOutlined,
} from "@ant-design/icons";
// import SiderDrawerPhone from "../dashboard/SiderDrawerPhone";
import { HomeOutlined } from "@ant-design/icons/lib/icons";
import { useMsal } from "@azure/msal-react";

const { Header } = Layout;

export default function HeaderAdmin(props) {
  const navigate = useNavigate();
  const { instance } = useMsal();

  const handleLoginRedirect = () => {
    instance.logoutRedirect();
  };

  const items = [
    {
      label: (
        <Link
          to="/dashboard"
          className="ms-4 fs-4"
          style={{ textDecoration: "none", fontSize: "12px" }} 
        >
          <HomeOutlined style={{ fontSize: "12px" }} /> 
          <span
            className="ms-4 menu-item-name"
            style={{ paddingLeft: "5px", fontSize: "12px" }}
          >
            Home
          </span>
        </Link>
      ),
      key: "0",
    },

    {
      label: (
        <span className="ms-4 fs-4" onClick={handleLoginRedirect}>
          <LogoutOutlined style={{ fontSize: "12px" }} /> 
          <span
            className="ms-4 menu-item-name"
            style={{ paddingLeft: "5px", fontSize: "12px" }} 
          >
            Sign Out
          </span>
        </span>
      ),
      key: "1",
    },
  ];

  return (
    <Header
      className="header-admin site-layout-background"
      style={{
        padding: "0 10px", // Reduced padding on the sides
        height: "50px", // Set a fixed, reduced height
        display: "flex",
        justifyContent: "space-between", // Align items with space between
        alignItems: "center", // Vertically center elements
      }}
    >
      {React.createElement(
        props.collapsed ? MenuUnfoldOutlined : MenuFoldOutlined,
        {
          className: "trigger",
          onClick: props.toggle,
        }
      )}
      {/* <SiderDrawerPhone user={props.user} /> */}

      <Dropdown
        menu={{
          items,
        }}
        trigger={["click"]}
      >
        <div
          className="avatar-user-details"
          onClick={(e) => e.preventDefault()}
          style={{ display: "flex", alignItems: "center", gap: "8px" }} // Reduced gap between elements
        >
          <div className="avatar-box">
            <span className="avatar-name">
              <strong style={{ fontSize: "12px" }}>{props.user ? props.user.name : ""}</strong> {/* Reduced font size */}
            </span>
            <div className="avatar-img">
              <Avatar
                style={{ backgroundColor: "#3b404f" }}
                size={32} // Reduced avatar size to 32px for a smaller height
                icon={<UserOutlined />}
              />
            </div>
          </div>
        </div>
      </Dropdown>
    </Header>
  );
}
