import React, { useState } from "react";
import { Row, Col, Modal } from "antd";
import image1 from "../assests/img/template1.avif";
import image2 from "../assests/img/template2.jpg";
import image3 from "../assests/img/template3.png";
import image4 from "../assests/img/template4.jpg";
import image5 from "../assests/img/template6.jpg";
import image6 from "../assests/img/template2.jpg";

const ImageGrid = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const images = [image1, image2, image3, image4, image5, image6];

  const handleImageClick = (image) => {
    console.log("image", image);
    setSelectedImage(image);
  };

  const handleCloseModal = () => {
    setSelectedImage(null);
  };

  return (
    <div>
      <h3 style={{ marginTop: "-10px" }}> Please Select a Template</h3>
      <Row gutter={[16, 16]} justify="center">
        {images.map((image, index) => (
          <Col xs={24} sm={24} md={12} lg={8} key={index}>
            <img
              src={image}
              alt={`Image ${index}`}
              style={{ width: "360px", height: "120px", cursor: "pointer" }}
              onClick={() => handleImageClick(image)}
            />
          </Col>
        ))}
      </Row>
      <Modal
        visible={selectedImage !== null}
        onCancel={handleCloseModal}
        footer={null}
        centered
        bodyStyle={{ padding: 0, position: "relative" }}
        style={{ top: 20 }}
      >
        <img
          src={selectedImage}
          alt="Selected Image"
          style={{ width: "100%" }}
        />
      </Modal>
    </div>
  );
};

export default ImageGrid;
