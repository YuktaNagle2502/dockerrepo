import React from "react";
import { Modal } from "antd";

const TextSummary = ({ isVisible, onClose, summaryText }) => {
  return (
    <Modal
      title="Generate Summary"
      visible={isVisible}
      onCancel={onClose}
      footer={null}
      centered
    >
      <div style={{ padding: "16px", fontSize: "14px", lineHeight: "1.6" }}>
        {summaryText ? (
          <p>{summaryText}</p>
        ) : (
          <p>No summary available. Please generate one.</p>
        )}
      </div>
    </Modal>
  );
};

export default TextSummary;