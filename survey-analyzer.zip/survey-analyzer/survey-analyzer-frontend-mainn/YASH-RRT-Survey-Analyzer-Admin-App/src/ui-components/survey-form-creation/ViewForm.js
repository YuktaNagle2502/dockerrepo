import React, { useEffect, useState } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import * as XLSX from "xlsx";
import { v4 as uuidv4 } from "uuid";
import { parseISO } from "date-fns";
import { parse, startOfDay, endOfDay } from "date-fns";
import moment from "moment";
import {
  faShareAlt,
  faCopy,
  faTrash,
  faShare,
} from "@fortawesome/free-solid-svg-icons";
import {
  Table,
  Button,
  Checkbox,
  DatePicker,
  TimePicker,
  Form,
  Input,
  InputNumber,
  Radio,
  Select,
  Upload,
  Model,
  Icon,
  Tag,
  message,
  Modal,
  Spin,
  Tooltip,
} from "antd";
import TextArea from "antd/es/input/TextArea";
import {
  CopyOutlined,
  DeleteOutlined,
  EditOutlined,
  LoadingOutlined,
  PlusOutlined,
  ShareAltOutlined,
  UploadOutlined,
} from "@ant-design/icons";
import BreadCrumbs from "../BreadCrumbs";
import styled from "@emotion/styled";
import {
  URL_SurveyBroadcastAPIV2,
  URL_SurveyFormAdminAPIV2,
} from "../../util/constants";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { SearchOutlined } from "@ant-design/icons";
import { useNavigate } from "react-router-dom";

const ViewForms = (props) => {
  const [showRangePicker, setShowRangePicker] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const [hovered, setHovered] = useState(false);
  const [forms, setForms] = useState([]);
  const [surveyData, setSurveyData] = useState([]);
  const [editorValue, setEditorValue] = useState("");
  const [emails, setEmails] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [formTitle, setFormTitle] = useState("");
  const [formURL, setFormURL] = useState("http://dummyLink/view-forms");
  const [shareDisable, setShareDisable] = useState(false);
  const [modalLoading, setModalLoading] = useState(false);
  const [selectedForm, setSelectedForm] = useState(null);
  const [searchInput, setSearchInput] = useState("");
  const [selectedValue, setSelectedValue] = useState(null);
  const [dateRange, setDateRange] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [messageApi, contextHolder] = message.useMessage();
  const [expiresAt, setExpiresAt] = useState(null);
  const [reminderCount, setReminderCount] = useState(null);
  const key = "updatable";
  const [previewMode, setPreviewMode] = useState(false);

  const onExpiryDateChange = (dates) => {
    if (dates) {
      const formattedDate = dates.format("YYYY-MM-DDTHH:mm:ssZ");
      console.log("Expiry date selected:", formattedDate);
      setExpiresAt(formattedDate);
    } else {
      setExpiresAt(null);
    }
  };
  const disablePastDates = (current) => {
    return current && current < moment().startOf("day");
  };

  const disablePastTimes = (selectedDate) => {
    if (!selectedDate || selectedDate.isAfter(moment(), "day")) {
      return {}; // Allow all times for future dates
    }
  
    const currentHour = moment().hour();
    const currentMinute = moment().minute();
  
    return {
      disabledHours: () => Array.from({ length: 24 }, (_, i) => i).filter((hour) => hour < currentHour),
      disabledMinutes: (selectedHour) =>
        selectedHour === currentHour
          ? Array.from({ length: 60 }, (_, i) => i).filter((minute) => minute < currentMinute)
          : [],
    };
  };

  const handleReminderChange = (value) => {
    console.log("Reminder count set to:", value);
    setReminderCount(value);
  };

  const getNextTenDays = () => {
    const today = new Date();
    return Array.from({ length: 10 }, (_, i) => {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      return date.toLocaleDateString(); // Format as needed
    });
  };

  const handleExpiryClick = (e) => {
    e.preventDefault();
    setShowRangePicker((prev) => !prev);
  };

  const openMessage = () => {
    messageApi.open({
      key,
      type: "loading",
      content: "Copying...",
    });
    setTimeout(() => {
      messageApi.open({
        key,
        type: "success",
        content: "Copied!",
        duration: 2,
      });
    }, 1000);
  };

  const handleDateChange = (dates) => {
    console.log("Date picker value:", dates);

    if (!dates || !Array.isArray(dates) || dates.length !== 2) {
      setDateRange(null);
      return;
    }

    if (!dates[0] || !dates[1]) {
      setDateRange(null);
      return;
    }

    setDateRange(dates);
    console.log("Date range set to:", dates);
  };

  const safeSurveyData = Array.isArray(surveyData) ? surveyData : [];

  const parseCustomDateFormat = (dateString) => {
    if (!dateString) {
      return null;
    }

    try {
      // Match DD/MM/YYYY, HH:MM:SS format
      const match = dateString.match(
        /(\d{2})\/(\d{2})\/(\d{4}), (\d{2}):(\d{2}):(\d{2})/
      );

      if (!match) {
        console.warn(`Invalid date format: ${dateString}`);
        return null;
      }

      const day = parseInt(match[1], 10);
      const month = parseInt(match[2], 10) - 1;
      const year = parseInt(match[3], 10);
      const hours = parseInt(match[4], 10);
      const minutes = parseInt(match[5], 10);
      const seconds = parseInt(match[6], 10);

      const parsedDate = new Date(year, month, day, hours, minutes, seconds);
      console.log(`Parsed date for "${dateString}":`, parsedDate);
      return parsedDate;
    } catch (error) {
      console.error(`Error parsing date: ${dateString}`, error);
      return null;
    }
  };

  const startOfDay = (date) => {
    const newDate = new Date(date);
    newDate.setHours(0, 0, 0, 0);
    return newDate;
  };

  const endOfDay = (date) => {
    const newDate = new Date(date);
    newDate.setHours(23, 59, 59, 999);
    return newDate;
  };

  const filteredSurveyData = safeSurveyData
    .filter((item) => {
      const matchesSearch = item.title
        ?.toLowerCase()
        .includes(searchInput?.toLowerCase() || "");

      if (!dateRange || dateRange.length !== 2) return matchesSearch;

      const createdAt = parseCustomDateFormat(item.createdAt);

      if (!createdAt) return false;

      const startDate = startOfDay(dateRange[0]);
      const endDate = endOfDay(dateRange[1]);

      return matchesSearch && createdAt >= startDate && createdAt <= endDate;
    })
    .map((item) => ({
      ...item,
      shared: item.shared || !!item.lastSubmitted || !!item.sharedDate, // Set `shared` to true if the form is shared or submitted
    }))
    .sort((a, b) => {
      // Sort by createdAt in descending order (latest first)
      const dateA = parseCustomDateFormat(a.createdAt);
      const dateB = parseCustomDateFormat(b.createdAt);

      return dateB - dateA; // Latest date first
    });

  const { RangePicker } = DatePicker;

  const columns = [
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
      render: (text, record) => (
        <span
          onClick={async () => {
            console.log("Record Before Navigation:", record);

            if (!record.id) {
              console.error(" Record ID is missing.");
              return;
            }

            handleChange(record.id);

            try {
              const url = `${URL_SurveyFormAdminAPIV2}/dev/survey-formV2?id=${record.id}`;
              const response = await axios.get(url);

              // Ensure response data is valid
              const formSchemaData = response.data?.[0]?.form_schema ?? [];

              // Convert fields if form_schema exists
              const formData = Array.isArray(formSchemaData)
                ? formSchemaData.map((field) => ({ ...field, id: uuidv4() }))
                : [];

              console.log("Updated form_schema:", formData);

              navigate("/view-forms/form-builder", {
                state: {
                  formData: {
                    ...record,
                    form_schema: formData,
                  },
                  hideToolbox: true,
                },
              });
            } catch (error) {
              console.error("Error fetching survey form:", error);
            }
          }}
          style={{
            color: "#1890ff",
            textDecoration: "underline",
            cursor: "pointer",
            fontSize: "12px",
          }}
        >
          {text}
        </span>
      ),
    },
    {
      title: "Date",
      dataIndex: "createdAt",
      key: "createdAt",
    },
    {
      title: "Submitted Date",
      dataIndex: "lastSubmitted",
      key: "lastSubmitted",
    },
    {
      title: "Status",
      key: "status",
      render: (_, record) => {
        if (record.shared) {
          return <Tag color="green">Shared</Tag>;
        } else {
          return <Tag color="red">Not Shared</Tag>;
        }
      },
    },
    {
      title: "Actions",
      key: "actions",
      render: (_, record) => (
        <div>
          {record.lastSubmitted === null ||
          record.lastSubmitted === "" ||
          record.lastSubmitted === undefined ? (
            <Button
              icon={<EditOutlined style={{ color: "#faad14" }} />}
              onClick={async () => {
                console.log(" Record Before Navigation:", record);
                if (!record.form_schema || record.form_schema.length === 0) {
                  console.error(
                    " form_schema is empty or missing before navigation:",
                    record
                  );
                }
                handleChange(record.id);
                let formData = [];
                try {
                  const url = `${URL_SurveyFormAdminAPIV2}/dev/survey-formV2?id=${record.id}`;
                  await axios
                    .get(url) // Use params object for GET requests
                    .then((response) => {
                      const updatedFormSchema =
                        response.data[0].form_schema.map((field) => ({
                          ...field,
                          id: uuidv4(),
                        }));
                      formData = updatedFormSchema;
                    })
                    .catch((error) => {
                      console.error("Error fetching data:", error);
                    });
                } catch (error) {
                  console.error("Error fetching survey form:", error);
                  throw error;
                }
                console.log("record.form_schema:", formData);

                navigate("/view-forms/form-builder", {
                  state: {
                    formData: {
                      ...record,
                      form_schema: formData,
                    },
                    isUpdate: true,
                  },
                });
              }}
              style={{ marginRight: "8px", border: "none" }}
            />
          ) : null}

          <Button
            icon={<DeleteOutlined style={{ color: "#ff4d4f" }} />}
            onClick={() => {
              handleDeleteClick(record.id);
            }}
            style={{ marginRight: "8px", border: "none" }}
          />
          <Button
            icon={<ShareAltOutlined style={{ color: "#468cfe" }} />}
            onClick={() => {
              handleChange(record.id);

              handleViewClick(record.title);
            }}
            style={{ marginRight: "8px", border: "none" }}
          />
          <Button
            icon={<CopyOutlined style={{ color: "#18bd0b" }} />}
            onClick={async () => {
              console.log(" Record Before Navigation:", record);
              if (!record.form_schema || record.form_schema.length === 0) {
                console.error(
                  " form_schema is empty or missing before navigation:",
                  record
                );
              }
              handleChange(record.id);
              let formData = [];
              try {
                const url = `${URL_SurveyFormAdminAPIV2}/dev/survey-formV2?id=${record.id}`;
                await axios
                  .get(url)
                  .then((response) => {
                    const updatedFormSchema = response.data[0].form_schema.map(
                      (field) => ({
                        ...field,
                        id: uuidv4(),
                      })
                    );
                    formData = updatedFormSchema;
                  })
                  .catch((error) => {
                    console.error("Error fetching data:", error);
                  });
              } catch (error) {
                console.error("Error fetching survey form:", error);
                throw error;
              }
              console.log("record.form_schema:", formData);

              navigate("/view-forms/form-builder", {
                state: {
                  formData: {
                    ...record,
                    form_schema: formData,
                  },
                  isUpdate: false,
                },
              });
            }}
            style={{ marginRight: "8px", border: "none" }}
          />
        </div>
      ),
    },
  ];

  const handleCloneForm = async (form) => {
    try {
      const clonedForm = {
        ...form,
        id: Date.now().toString(),
        title: `${form.title} (Clone)`,
        lastSubmitted: null,
      };
      const response = await axios.post(
        `${URL_SurveyFormAdminAPIV2}/dev/survey-formV2`,
        clonedForm
      );
      console.log("Cloned form response:", response.data);
      setSurveyData([...surveyData, clonedForm]);
      messageApi.open({
        key,
        type: "success",
        content: "Form cloned successfully!",
        duration: 2,
      });
    } catch (error) {
      console.error("Error cloning form:", error);
      messageApi.open({
        key,
        type: "error",
        content: "Failed to clone form.",
        duration: 2,
      });
    }
  };

  const handleEditForm = (record) => {
    console.log("Full record in handleEditForm:", record);

    if (!record || record.length === 0) {
      console.error("No record data available");
      return;
    }

    const formRecord = record[0] || record;

    if (!formRecord.form_schema) {
      console.error("form_schema is missing from the record", formRecord);
      return;
    }

    const formData = {
      formTitle: formRecord.title,
      form_schema: formRecord.form_schema.map((item) => ({
        field_type: item.field_type,
        label: item.label,
        placeholder: item.placeholder || "",
        required: item.required,
        options: item.options || [],
      })),
    };

    console.log("Prepared formData for navigation:", formData);
    navigate("/view-forms/form-builder", { state: formData });
  };

  const handleDeleteClick = async (id) => {
    setLoading(true);
    const payload = {
      form_id: id,
    };
    try {
      console.log("deleteFormField id:", id);
      console.log("filteredSurveyData:", surveyData);
      setSurveyData(
        surveyData.filter((data) => {
          return data.id !== id;
        })
      );

      const response = await fetch(
        "https://04g4bjuen6.execute-api.us-east-2.amazonaws.com/dev/delete-form",
        {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        }
      );

      if (response.ok) {
        alert("Form deleted successfully!");

        setForms((prevForms) => prevForms.filter((form) => form.id !== id));
      } else {
        alert("Failed to delete the form.");
      }
    } catch (error) {
      console.error("Error deleting form:", error);
      alert("An error occurred while deleting the form.");
    } finally {
      setLoading(false);
    }
  };
  const antIcon = (
    <>
      <LoadingOutlined style={{ fontSize: 24 }} spin />
    </>
  );
  const copyLinkToClipboard = () => {
    // inputRef.current.select();
    openMessage();
    navigator.clipboard.writeText(formURL);
  };

  const [shareForm] = Form.useForm();
  shareForm.setFieldsValue({
    title: formTitle,
  });

  const [isModalOpenForm, setIsModalOpenForm] = useState(false);

  const showModalForm = () => {
    setIsModalOpenForm(!isModalOpenForm);
  };

  const [isModalOpen, setIsModalOpen] = useState(false);

  const showModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  const handleViewClick = (title) => {
    console.log("title:", title);
    setSelectedForm(title);
    setFormTitle(title);
    shareForm.setFieldsValue({ title: title });
    showModal();
  };

  useEffect(() => {
    if (formTitle) {
      shareForm.setFieldsValue({ title: formTitle });
    }
  }, [formTitle, shareForm]);
  //     setModalLoading(true);
  //     console.log("values received:", values);

  //     const { title, emails, content } = values;

  //     console.log("Title:", title);
  //     console.log("Emails:", emails);
  //     console.log("Content:", content);

  //     let scheduledTime = null;

  //     if (selectedDate && selectedTime) {
  //       if (!selectedTime.isValid()) {
  //         console.error("Invalid selected time!");
  //         messageApi.open({
  //           key,
  //           type: "error",
  //           content: "Invalid time selected! Please select a valid time.",
  //           duration: 2,
  //         });
  //         setModalLoading(false);
  //         return;
  //       }

  //       // Clone the date and set time
  //       const combinedDateTime = selectedDate.clone().set({
  //         hour: selectedTime.hour(),
  //         minute: selectedTime.minute(),
  //         second: 0
  //       });

  //       console.log("Combined Date-Time:", combinedDateTime.format("YYYY-MM-DD HH:mm:ss"));

  //       // Get timezone offset
  //       const tzOffset = combinedDateTime.format('Z').replace(/(\d{2})(\d{2})/, '$1:$2');

  //       // Format in required format with proper timezone
  //       scheduledTime = combinedDateTime.format("YYYY-MM-DDTHH:mm:ss") + tzOffset;
  //       console.log("Scheduled Time for payload:", scheduledTime);
  //     }

  //     let recipients = [];
  //     if (Array.isArray(emails)) {
  //       recipients = emails.map(({ name, email }) => ({
  //         name: name || "",
  //         email: email || "",
  //       }));
  //     } else if (typeof emails === 'string') {
  //       const emailList = emails.split(',').map(email => email.trim());
  //       console.log("Email list after splitting:", emailList);

  //       recipients = emailList.map(email => ({
  //         name: "",
  //         email: email,
  //       }));
  //     } else {
  //       recipients = [{
  //         name: "",
  //         email: emails || "",
  //       }];
  //     }

  //     console.log("Recipients:", recipients);

  //     let htmlContent = content?.html || editorValue || "";

  //     const surveyLink = "userApplicationLink"; // Replace this with actual dynamic link

  //     htmlContent = htmlContent.replace(
  //       /Survey Link/g,
  //       `<a href="${surveyLink}" target="_blank">Survey Link</a>`
  //     );

  //     const contentData = content || {
  //       font: "dmsans",
  //       size: "10px",
  //       bold: true,
  //       italic: true,
  //       underline: true,
  //       strike: false,
  //       align: "left",
  //       list: false,
  //       bullet: false,
  //       clean: false,
  //       html: htmlContent,
  //     };

  //     console.log("Final Content:", contentData);

  //     const payload = {
  //       scheduledTime: scheduledTime,
  //       form_id: selectedValue,
  //       recipients,
  //       content: contentData,
  //     };

  //     console.log("Payload being sent:", JSON.stringify(payload, null, 2));

  //     if (selectedDate || selectedTime) {
  //       if (!scheduledTime) {
  //         messageApi.open({
  //           key,
  //           type: "warning",
  //           content: "Please select both date and time for scheduling!",
  //           duration: 2,
  //         });
  //         setModalLoading(false);
  //         return;
  //       }
  //     }

  //     try {
  //       const response = await axios.post(
  //         `${URL_SurveyBroadcastAPIV2}/dev/send-surveyV2`,
  //         payload
  //       );

  //       console.log("Response:", response);
  //       setEmails([]);
  //       messageApi.open({
  //         key,
  //         type: "success",
  //         content: scheduledTime ? "Email scheduled successfully!" : "Email sent immediately!",
  //         duration: 2,
  //       });
  //     } catch (error) {
  //       console.error("Error sending survey:", error);
  //       messageApi.open({
  //         key,
  //         type: "error",
  //         content: "Something went wrong!",
  //         duration: 2,
  //       });
  //     }

  //     showModal();
  //     setModalLoading(false);
  // };

  const handleCancelForm = () => {
    setIsModalOpenForm(!isModalOpenForm);
  };

  const handleCancel = () => {
    setIsModalOpen(!isModalOpen);
  };

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleInputConfirm = (e) => {
    e.preventDefault();
    if (
      inputValue &&
      validateEmail(inputValue) &&
      !emails.some((email) => email.email === inputValue)
    ) {
      setEmails([...emails, { name: "", email: inputValue }]);
      setInputValue("");
      shareForm.setFieldsValue({
        emails: [...emails, { name: "", email: inputValue }],
      });
    } else {
      messageApi.open({
        type: "error",
        content: "Invalid email or email already exists",
        duration: 2,
      });
    }
  };

  const handleRemoveEmail = (removedEmail) => {
    setEmails(emails.filter((email) => email !== removedEmail));
  };

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleFileUploadForEmails = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const emailsFromFile = XLSX.utils
        .sheet_to_json(firstSheet, { header: 1 })
        .filter((row) => validateEmail(row[1]))
        .map((row) => ({ name: row[0], email: row[1] }));
      const newEmails = [...emails, ...emailsFromFile];
      setEmails(newEmails);
      shareForm.setFieldsValue({
        emails: newEmails,
      });
    };
    reader.readAsArrayBuffer(file);
    return false; // Prevent upload
  };

  async function fetchSurveyForm() {
    try {
      const response = await axios.get(
        `${URL_SurveyFormAdminAPIV2}/dev/survey-formV2?id=null`
      );
      console.log(
        "response data*********************************************",
        response.data
      );
      setSurveyData(response.data);
      return response.data;
    } catch (error) {
      console.error("Error fetching survey form:", error);
      throw error;
    }
  }

  useEffect(() => {
    fetchSurveyForm();

    // .catch(error => setError(error));
  }, []);

  function fun(selectedValue) {
    console.log("Hello, you selected:", selectedValue);
  }

  async function getFormDataByID(item) {
    try {
      const url = `${URL_SurveyFormAdminAPIV2}/dev/survey-formV2?id=${item}`;
      axios
        .get(url)
        .then((response) => {
          console.log(response.data[0].title);
          setForms(response.data);
          setFormTitle(response.data[0].title);
          setShareDisable(true);
          shareForm.setFieldsValue({
            title: response.data[0].title,
          });
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    } catch (error) {
      console.error("Error fetching survey form:", error);
      throw error;
    }
  }

  const normFile = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e?.fileList;
  };

  useEffect(() => {
    const loadForms = async () => {
      try {
        const item = localStorage.getItem("form-builder");
        setForms(item ? [JSON.parse(item)] : null);
      } catch (error) {}
    };

    // loadForms();
  }, []);

  const handleSearchInputChange = (e) => {
    setSearchInput(e.target.value);
  };

  const renderFormField = (field) => {
    const commonStyles = {
      width: "100%",
      padding: "6px",
      margin: "6px 0",
      border: "1px solid #ccc",
      borderRadius: "4px",
      fontSize: "12px",
      color: "#495057",
    };

    switch (field.field_type) {
      case "text":
        return (
          <Form.Item label={field.label} name={field.label}>
            <Input
              placeholder={field.placeholder}
              style={{
                color: "#ffffff",
                backgroundColor: "#ffffff",
                borderColor: "#ffffff",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                cursor: "not-allowed",
                opacity: 1,
              }}
              disabled={previewMode}
            />
          </Form.Item>
        );
      case "email":
        return (
          <Form.Item name={field.label} label={field.label}>
            <Input
              placeholder={field.placeholder}
              style={{
                color: "#ffffff",
                backgroundColor: "#ffffff",
                borderColor: "#ffffff",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                cursor: "not-allowed",
                opacity: 1,
              }}
              disabled={previewMode}
            />
          </Form.Item>
        );
      case "number":
        return (
          <Form.Item label={field.label} name={field.label}>
            <InputNumber
              placeholder={field.placeholder}
              style={{
                width: "100%",
                color: "#ffffff",
                backgroundColor: "#ffffff",
                borderColor: "#ffffff",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                cursor: "not-allowed",
                opacity: 1,
              }}
              disabled={previewMode}
            />
          </Form.Item>
        );
      case "password":
        return (
          <Form.Item label={field.label} name={field.label}>
            <Input.Password
              placeholder={field.placeholder}
              disabled={previewMode}
            />
          </Form.Item>
        );
      case "checkbox":
        return (
          <Form.Item label={field.label}>
            <Checkbox.Group disabled={previewMode}>
              {field.options.map((option, index) => (
                <Checkbox value={option}>{option}</Checkbox>
                // <Radio value={option}>{option} </Radio>
              ))}
            </Checkbox.Group>
          </Form.Item>
        );
      case "radio":
        return (
          <Form.Item label={field.label}>
            <Radio.Group disabled={previewMode}>
              {field.options.map((option, index) => (
                <Radio value={option}>{option} </Radio>
              ))}
            </Radio.Group>
          </Form.Item>
        );
      case "dropdown":
        return (
          <Form.Item label={field.label} name={field.label}>
            <Select
              placeholder={field.placeholder}
              filterSort={(optionA, optionB) =>
                (optionA?.label ?? "")
                  ?.toLowerCase()
                  .localeCompare((optionB?.label ?? "")?.toLowerCase())
              }
              options={field.options.map((option) => ({
                value: option,
                label: option,
              }))}
              disabled={previewMode}
              style={{
                color: "#333",
                backgroundColor: "#ffffff",
                borderColor: "#ddd",
                borderRadius: "8px",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                cursor: "not-allowed",
                opacity: 1,
              }}
              dropdownStyle={{
                backgroundColor: "#ffffff",
              }}
            />
          </Form.Item>
        );
      case "date":
        return (
          <Form.Item label={field.label} name={field.label}>
            <DatePicker disabled={previewMode} />
          </Form.Item>
        );
      case "textarea":
        return (
          <Form.Item label={field.label}>
            <TextArea
              rows={4}
              placeholder={field.placeholder}
              disabled={previewMode}
            />
          </Form.Item>
        );
      case "file":
        return (
          <Form.Item
            label={field.label}
            name={field.label}
            valuePropName="fileList"
            getValueFromEvent={normFile}
          >
            <Upload action="/upload.do" listType="picture-card" maxCount={1}>
              <button
                style={{
                  border: "2px solid rgb(205 187 238)",
                  backgroundColor: "#ffffff",
                  borderRadius: "8px",
                  padding: "20px",
                  cursor: "pointer",
                  transition: "background-color 0.3s, border-color 0.3s",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                }}
                type="button"
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = "#f0f0f0";
                  e.currentTarget.style.borderColor = "#5a34a1";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = "#ffffff";
                  e.currentTarget.style.borderColor = "rgb(55 23 255)";
                }}
                disabled={previewMode}
              >
                <PlusOutlined
                  style={{ fontSize: "24px", color: "rgb(55 23 255)" }}
                />
                <div
                  style={{
                    marginTop: 5,
                    color: "rgb(55 23 255)",
                    fontWeight: "500",
                  }}
                >
                  Upload
                </div>
              </button>
            </Upload>
          </Form.Item>
        );
      case "button":
        return (
          <Form.Item
            wrapperCol={{
              offset: 0,
              span: 16,
            }}
          >
            <Button
              type="primary"
              htmlType="submit"
              style={{
                backgroundColor: "rgb(55 23 255)",
                borderColor: "rgb(55 23 255)",
                color: "#ffffff",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                textTransform: "capitalize",
              }}
              disabled={previewMode}
            >
              {field.placeholder}
            </Button>
          </Form.Item>
        );
      default:
        return <div>Unknown Form Item</div>;
    }
  };

  const handleShareClick = (slug) => {
    console.log("slug:", slug);
    alert("Embed code copied to clipboard!");
  };

  const generateHtmlString = (formFields) => {
    return formFields
      .map((field) => {
        switch (field.field_type) {
          case "text":
            return `<Form.Item label="${field.label}" name="${field.label}">
                <Input placeholder="${field.placeholder}" />
              </Form.Item>`;
          case "email":
            return `
              <Form.Item name="${field.label}" label="${field.label}">
                <Input placeholder="${field.placeholder}" />
              </Form.Item>`;
          case "number":
            return `
              <Form.Item label="${field.label}" name="${field.label}">
                <InputNumber
                  placeholder="${field.placeholder}"
                  style={{
                    width: "100%",
                  }}
                />
              </Form.Item>`;
          case "password":
            return `
              <Form.Item label="${field.label}" name="${field.label}">
                <Input.Password placeholder="${field.placeholder}" />
              </Form.Item>`;
          case "checkbox":
            return `
                <Form.Item label="${field.label}">
                    <Checkbox.Group>
                      ${field.options
                        .map(
                          (option, index) =>
                            `<Checkbox value=${option}>${option}</Checkbox>`
                        )
                        .join("")}
                    </Checkbox.Group>
                  </Form.Item>
          `;
          case "radio":
            return `
              <Form.Item label="${field.label}">
                <Radio.Group>
                  ${field.options
                    .map(
                      (option, index) =>
                        ` <Radio value=${option}>${option} </Radio>`
                    )
                    .join("")}
                </Radio.Group>
              </Form.Item>`;
          case "dropdown":
            return `
              <Form.Item label="${field.label}" name="${field.label}">
                <Select
                  placeholder="${field.placeholder}"
                  filterSort=${(optionA, optionB) =>
                    (optionA?.label ?? "")
                      ?.toLowerCase()
                      .localeCompare((optionB?.label ?? "")?.toLowerCase())
                      .join("")}
                  options=${field.options
                    .map((option, index) => ({
                      value: option,
                      label: option,
                    }))
                    .join("")}
                />
              </Form.Item>`;
          case "date":
            return `
              <Form.Item label="${field.label}" name="${field.label}">
                <DatePicker />
              </Form.Item>`;
          case "textarea":
            return `
              <Form.Item label="${field.label}">
                <TextArea rows={4} placeholder="${field.placeholder}" />
              </Form.Item>`;
          case "file":
            return `
              <Form.Item
                label="${field.label}"
                valuePropName="fileList"
                getValueFromEvent={normFile}
              >
                <Upload action="/upload.do" listType="picture-card" maxCount={1}>
                  <button
                    style={{
                      border: 0,
                      background: "none",
                    }}
                    type="button"
                  >
                    <PlusOutlined />
                    <div
                      style={{
                        marginTop: 5,
                      }}
                    >
                      Upload
                    </div>
                  </button>
                </Upload>
              </Form.Item>`;
          case "button":
            return `
                  <Form.Item
                    wrapperCol={{
                      offset: 0,  // Aligns the button to the left
                      span: 16,
                    }}
                  >
                    <Button
                      type="primary"
                      htmlType="submit"
                      style={{ textTransform: "capitalize" }}
                    >
                      ${capitalizeFirstLetter(field.placeholder)}
                    </Button>
                  </Form.Item>
                `;

          default:
            return <div>Unknown Form Item</div>;
        }
      })
      .join("");
  };

  const capitalizeFirstLetter = (str) => {
    if (typeof str !== "string" || str.length === 0) return str;
    return str.charAt(0).toUpperCase() + str.slice(1);
  };

  const handleCopyHtml = (formFields) => {
    let htmlString = generateHtmlString(formFields);
    const prefix = `<Form
    name="basic"
    layout="vertical"
    onFinish={onFinish}
    labelCol={{
          span: 2,
        }}
  >`;

    const suffix = `</Form>`;
    htmlString = prefix + htmlString + suffix;
    console.log("htmlString:", htmlString);
    navigator.clipboard.writeText(htmlString).then(() => {
      alert("HTML copied to clipboard!");
    });
  };

  const handleChange = (value) => {
    console.log("valuev", value);
    getFormDataByID(value);
    setSelectedValue(value);
    setSelectedForm(surveyData.find((item) => item.id === value));
  };

  const PageContainer = styled.div`
    display: flex;
    background-color: white;
    min-height: calc(100vh - 64px);
    padding: 24px;
  `;

  const MainContent = styled.div`
    flex-grow: 1;
    background: white;
    border-radius: 12px;
    border: 1px solid #e6e8f0;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  `;

  const HeaderSection = styled.div`
    padding: 24px;
    border-bottom: 1px solid #e6e8f0;
  `;

  const HeaderContent = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 24px;

    @media (max-width: 768px) {
      flex-direction: column;
      align-items: stretch;
    }
  `;

  const Title = styled.h3`
    font-size: 24px;
    font-weight: 600;
    color: #2b2e48;
    margin: 0;
  `;

  const ActionButtons = styled.div`
    display: flex;
    gap: 12px;

    @media (max-width: 768px) {
      justify-content: stretch;
    }
  `;

  const StyledButton = styled.button`
    padding: 12px 20px;
    background-color: ${(props) =>
      props.variant === "primary" ? "#2B2E48" : "#28a745"};
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 500;
    transition: opacity 0.2s;

    &:hover {
      opacity: 0.9;
    }

    &:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `;

  const FormField = styled.div`
    background-color: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    border: 1px solid #e9ecef;
  `;

const onDateSelect = (date) => {
  if (date && date.isBefore(moment(), "day")) {
    message.warning("You cannot select a past date.");
    setSelectedDate(null); // Reset the selected date
  } else {
    console.log("Selected date:", date);
    setSelectedDate(date);
  }
};

  const handleTimeChange = (time) => {
    if (time && time.isValid()) {
      console.log("Time Selected:", time.format("HH:mm"));
      setSelectedTime(time);
    } else {
      console.log("No valid time selected");
      setSelectedTime(null);
    }
  };

  const getScheduledDateTime = () => {
    if (!selectedDate || !selectedTime || !selectedTime.isValid()) {
      console.log(" Error: Missing or Invalid Date/Time");
      return null;
    }

    console.log("selectedDate year:", selectedDate.year());
    console.log("selectedDate month:", selectedDate.month());
    console.log("selectedDate day:", selectedDate.date());
    console.log("selectedTime hour:", selectedTime.hour());
    console.log("selectedTime minute:", selectedTime.minute());

    const year = selectedDate.year();
    const month = (selectedDate.month() + 1).toString().padStart(2, "0");
    const day = selectedDate.date().toString().padStart(2, "0");
    const hour = selectedTime.hour().toString().padStart(2, "0");
    const minute = selectedTime.minute().toString().padStart(2, "0");
    const timezone = selectedDate.format("Z");

    const formattedDateTime = `${year}-${month}-${day}T${hour}:${minute}:00${timezone}`;

    console.log(" Final Scheduled Time for Payload:", formattedDateTime);
    return formattedDateTime;
  };

  const handleOk = async (values) => {
    setModalLoading(true);
    console.log("values received:", values);

    const { title, emails, content } = values;

    console.log("Title:", title);
    console.log("Emails:", emails);
    console.log("Content:", content);

    const scheduledTime = getScheduledDateTime();
    // if (!scheduledTime) {
    //   console.error("Scheduled time is missing or invalid!");
    //   messageApi.open({
    //     key,
    //     type: "warning",
    //     content: "Please select a valid date and time for scheduling!",
    //     duration: 2,
    //   });
    //   setModalLoading(false);
    //   return;
    // }

    let recipients = [];
    if (Array.isArray(emails)) {
      recipients = emails.map(({ name, email }) => ({
        name: name || "",
        email: email || "",
      }));
    } else if (typeof emails === "string") {
      const emailList = emails.split(",").map((email) => email.trim());
      recipients = emailList.map((email) => ({
        name: "",
        email: email,
      }));
    } else {
      recipients = [
        {
          name: "",
          email: emails || "",
        },
      ];
    }

    console.log("Recipients:", recipients);

    let htmlContent = content?.html || editorValue || "";
    const surveyLink = "userApplicationLink";
    htmlContent = htmlContent.replace(
      /Survey Link/g,
      `<a href="${surveyLink}" target="_blank">Survey Link</a>`
    );

    const contentData = content || {
      font: "dmsans",
      size: "12px",
      bold: false,
      italic: false,
      underline: false,
      strike: false,
      align: "left",
      list: false,
      bullet: false,
      clean: false,
      html: htmlContent,
    };

    console.log("Final Content:", contentData);

    const payload = {
      // scheduledTime,
      expires_at: expiresAt || null,
      reminder_count: reminderCount || null,
      form_id: selectedValue,
      recipients,
      content: contentData,
    };

    if (scheduledTime) {
      payload.scheduledTime = scheduledTime;
    }

    console.log("Payload being sent:", JSON.stringify(payload, null, 2));

    try {
      const response = await axios.post(
        `${URL_SurveyBroadcastAPIV2}/dev/send-surveyV2`,
        payload
      );

      console.log("Response:", response);
      setEmails([]);
      messageApi.open({
        key,
        type: "success",
        content: "Email successfully sent!",
        duration: 2,
      });
    } catch (error) {
      console.error("Error sending survey:", error);
      messageApi.open({
        key,
        type: "error",
        content: "Something went wrong!",
        duration: 2,
      });
    }

    showModal();
    setModalLoading(false);
  };

  const handlePlusClick = () => {
    navigate("/view-forms/form-builder", {
      state: {
        hideToolbox: false, 
      },
    });
  };

  return (
    <>
      <BreadCrumbs location={props.location} />
      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          padding: "10px 20px",
        }}
      >
        <Tooltip title="Create New Form" placement="top">
          <Button
            type="primary"
            icon={<PlusOutlined />}
            size="large"
            onClick={handlePlusClick}
            style={{
              backgroundColor: "#1890ff",
              border: "none",
              boxShadow: "0 2px 5px rgba(0, 0, 0, 0.2)",
              width: "40px",
              height: "40px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              borderRadius: "4px",
            }}
          />
        </Tooltip>
      </div>
      {loading && <div className="loader"></div>}
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          height: "92vh",
          position: "fixed",
          width: "-webkit-fill-available",
          paddingBottom: "100px",
        }}
      >
        {contextHolder}
        <div
          style={{
            padding: "10px",
            flexGrow: 1,
            maxWidth: "1160px",
            margin: "16px",
            borderRadius: "12px",
            overflow: "auto",
            maxHeight: "90vh",
          }}
        >
          <Modal
            title="Share Form"
            open={isModalOpen}
            onCancel={handleCancel}
            footer={null}
            width={650}
            style={{ fontFamily: "Calibri, sans-serif", fontSize: "10px" }}
          >
            <Spin
              indicator={antIcon}
              spinning={modalLoading}
              tip="Sending emails..."
              style={{
                position: "relative",
                top: "-20px",
              }}
            >
              <Form
                form={shareForm}
                name="basic"
                style={{ maxWidth: "100%" }}
                onFinish={handleOk}
              >
                <Form.Item
                  label={
                    <span
                      style={{
                        fontFamily: "Calibri, sans-serif",
                        fontSize: "12px",
                        fontWeight: "600",
                      }}
                    >
                      Form Title
                    </span>
                  }
                  name="title"
                  style={{
                    fontFamily: "Calibri, sans-serif",
                    fontSize: "12px",
                  }}
                >
                  <Input
                    style={{
                      fontFamily: "Calibri, sans-serif",
                      fontSize: "12px",
                    }}
                  />
                </Form.Item>

                <Form.Item
                  label={
                    <span
                      style={{
                        fontFamily: "Calibri, sans-serif",
                        fontSize: "12px",
                        fontWeight: "600",
                        color: "#black",
                      }}
                    >
                      Email
                    </span>
                  }
                  name="emails"
                  rules={[
                    { required: false, message: "Please input your email!" },
                  ]}
                >
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <Input
                      type="text"
                      placeholder="Enter email and press Enter"
                      value={inputValue}
                      onChange={handleInputChange}
                      onPressEnter={(e) => handleInputConfirm(e)}
                      style={{
                        width: "calc(129% - 100px)",
                        marginRight: "10px",
                        fontFamily: "Calibri, sans-serif",
                        fontSize: "12px",
                      }}
                    />
                    <Upload
                      beforeUpload={handleFileUploadForEmails}
                      showUploadList={false}
                    >
                      <div
                        style={{
                          position: "relative",
                          display: "inline-block",
                        }}
                      >
                        <Button
                          style={{
                            height: "26px",
                            backgroundColor: "rgb(23, 118, 236)",
                            color: "#ffffff",
                            border: "1px solid #ccc",
                            borderRadius: "4px",
                            cursor: "pointer",
                          }}
                          onMouseEnter={() => setHovered(true)}
                          onMouseLeave={() => setHovered(false)}
                        >
                          <UploadOutlined />
                        </Button>
                        {hovered && (
                          <span
                            style={{
                              position: "absolute",
                              top: "30px",
                              left: "50%",
                              transform: "translateX(-50%)",
                              backgroundColor: "#ffffff",
                              padding: "2px 5px",
                              borderRadius: "4px",
                              boxShadow: "0 1px 2px rgba(0, 0, 0, 0.2)",
                              fontSize: "12px",
                              color: "#000",
                              whiteSpace: "nowrap",
                            }}
                          >
                            Upload File
                          </span>
                        )}
                      </div>
                    </Upload>
                  </div>
                </Form.Item>

                {emails.map((recipient) => (
                  <Tag
                    key={recipient.email}
                    closable
                    onClose={() => handleRemoveEmail(recipient.email)}
                    style={{
                      height: "25px",
                      margin: "0 0 5px 0",
                      backgroundColor: "#f1f3f4",
                      color: "#5f6368",
                    }}
                  >
                    {recipient.email}
                  </Tag>
                ))}

                <div style={{ marginTop: "20px" }}>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginBottom: "10px",
                    }}
                  >
                    <strong style={{ marginRight: "10px" }}>
                      Schedule at:
                    </strong>
                    <DatePicker
                      format="DD/MM/YYYY"
                      onChange={onDateSelect}
                      disabledDate={disablePastDates}
                      style={{
                        marginRight: "8px",
                        width: "116px",
                        fontSize: "12px",
                        height: "26px",
                      }}
                      inputStyle={{ fontSize: "8px" }}
                    />
                    <TimePicker
                      format="HH:mm"
                      onChange={handleTimeChange}
                      disabledTime={() => disablePastTimes(selectedDate)}
                      style={{
                        width: "116px",
                        fontSize: "12px",
                        height: "26px",
                        marginRight: "10px",
                      }}
                    />
                  </div>
                </div>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    marginBottom: "10px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginTop: "10px",
                    }}
                  >
                    <strong style={{ marginRight: "10px", fontSize: "13px" }}>
                      Expiry Date & Time:
                    </strong>
                    <DatePicker
                      showTime
                      format="DD/MM/YYYY HH:mm"
                      style={{
                        marginRight: "8px",
                        width: "150px",
                        height: "26px",
                      }}
                      onChange={onExpiryDateChange}
                      disabledDate={disablePastDates} 
                      disabledTime={() => disablePastTimes(selectedDate)} 
                    />
                    <Select
                      placeholder="Set Reminder"
                      style={{
                        marginRight: "10px",
                        width: "150px",
                        fontSize: "10px",
                        height: "26px",
                        border: "none",
                        boxShadow: "none",
                      }}
                      onChange={handleReminderChange}
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((count) => (
                        <Select.Option key={count} value={count}>
                          {count} day{count > 1 ? "s" : ""}
                        </Select.Option>
                      ))}
                    </Select>
                  </div>
                </div>

                <ReactQuill
                  value={editorValue}
                  onChange={setEditorValue}
                  modules={{
                    toolbar: [
                      [{ font: [] }],
                      [{ size: [] }],
                      ["bold", "italic", "underline", "strike"],
                      [{ align: [] }],
                      [{ list: "ordered" }, { list: "bullet" }],
                      ["clean"],
                    ],
                  }}
                  formats={[
                    "header",
                    "font",
                    "size",
                    "bold",
                    "italic",
                    "underline",
                    "strike",
                    "align",
                    "list",
                    "bullet",
                    "clean",
                  ]}
                  style={{
                    minHeight: "150px",
                    marginBottom: "10px",
                    fontFamily: "Calibri, sans-serif",
                  }}
                />
                <style>
                  {`
      .ql-container {
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px; /* Adjust padding for overall container */
        max-height: 200px; /* Set a max height for scrolling */
        overflow-y: auto; /* Enable vertical scrolling */
        position: relative; /* Position relative for absolute positioning */
      }
      .ql-editor {
        font-family: 'Calibri', sans-serif; /* Ensure editor content uses Calibri */
        padding: 0; /* Remove padding to allow cursor at the top */
        min-height: 150px; /* Maintain minimum height */
      }
      .ql-editor.ql-blank::before {
        font-family: 'Calibri', sans-serif; /* Ensure placeholder uses Calibri */
        font-style: normal; /* Remove italic style */
        color: #999; /* Placeholder color */
        content: 'Hello {name}\\A\\AThis is GeneralSurvey Form\\ASurvey Link\\A\\AThanks\\AHR Team!'; /* Custom placeholder text */
        white-space: pre-line; /* Preserve line breaks */
        position: absolute; /* Position it absolutely */
        top: 10px; /* Position at the top */
        left: 10px; /* Align with padding */
        pointer-events: none; /* Allow clicks to go through to the editor */
      }
    `}
                </style>

                <div
                  style={{ display: "flex", justifyContent: "space-between" }}
                >
                  <Button key="back" onClick={handleCancel}>
                    Cancel
                  </Button>

                  <Button key="submit" type="primary" htmlType="submit">
                    Share
                  </Button>
                </div>
              </Form>
            </Spin>
          </Modal>

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: "20px",
            }}
          >
            <Input
              placeholder="Search by form name"
              value={searchInput}
              onChange={handleSearchInputChange}
              style={{ width: "300px" }}
              suffix={<SearchOutlined />}
            />
            <RangePicker onChange={handleDateChange} />
          </div>

          {loading || !filteredSurveyData || filteredSurveyData.length === 0 ? (
            <div
              style={{
                textAlign: "center",
                padding: "1.4rem",
                backgroundColor: "white",
                borderRadius: "8px",
                marginBottom: "1.4rem",
                boxShadow: "0 3px 6px rgba(0, 0, 0, 0.1)",
              }}
            >
              {loading ? (
                <>
                  <Spin size="large" />
                  <div
                    style={{
                      color: "#2C3E50",
                      fontWeight: "300",
                      marginTop: "1rem",
                    }}
                  >
                    Loading...
                  </div>
                </>
              ) : (
                <div
                  style={{
                    textAlign: "center",
                    padding: "1.4rem",
                    backgroundColor: "white",
                    borderRadius: "8px",
                    marginBottom: "1.4rem",
                    // boxShadow: "0 3px 6px rgba(0, 0, 0, 0.1)",
                  }}
                >
                  <Spin size="large" />
                  <div
                    style={{
                      color: "#2C3E50",
                      fontWeight: "300",
                      marginTop: "1rem",
                    }}
                  >
                    Loading...
                  </div>
                </div>
              )}
            </div>
          ) : (
            <Table
              columns={columns}
              dataSource={filteredSurveyData.map((item) => ({
                ...item,
                key: item.id,
              }))}
              pagination={{ pageSize: 5, position: ["bottomCenter"] }}
            />
          )}

          <Modal
            open={isModalOpenForm}
            onCancel={handleCancelForm}
            footer={null}
            style={{
              fontFamily: "Roboto, sans-serif",
            }}
          >
            <Form
              layout="vertical"
              disabled={true}
              style={{
                margin: "20px auto",
                backgroundColor: "#ffffff",
                borderRadius: "16px",
                boxShadow: "0 6px 20px rgba(0, 0, 0, 0.12)",
                overflowY: "auto",
                height: "60vh",
              }}
            >
              {forms?.map((form) => (
                <div key={form.id} style={{ marginBottom: "30px" }}>
                  <div
                    style={{
                      padding: "6px",
                      textAlign: "center",
                      borderRadius: "5px",
                      color: "black",
                      fontWeight: "600",
                      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
                    }}
                  >
                    {form.title}
                  </div>
                  <div style={{ padding: "20px" }}>
                    {form.form_schema.map((field) => (
                      <div key={field.id} style={{ marginBottom: "20px" }}>
                        <label
                          style={{
                            display: "block",
                            marginBottom: "8px",
                            color: "#5f6368",
                            fontWeight: "600",
                            fontSize: "8px",
                          }}
                        ></label>
                        {renderFormField(field, {
                          placeholderStyle: { color: "black" },
                        })}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </Form>
          </Modal>
        </div>
      </div>
    </>
  );
};

export default ViewForms;
