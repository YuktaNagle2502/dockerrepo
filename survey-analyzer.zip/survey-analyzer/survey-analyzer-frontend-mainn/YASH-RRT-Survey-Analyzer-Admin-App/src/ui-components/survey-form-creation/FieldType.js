import React from "react";
import {
  Button,
  Checkbox,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Radio,
  Select,
  Upload,
} from "antd";
import TextArea from "antd/es/input/TextArea";
import { PlusOutlined } from "@ant-design/icons";

const FormField = ({
  field,
  previewMode,
  onDelete,
  onUpdateLabel,
  onUpdateOptions,
}) => {
  const normFile = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e?.fileList;
  };

  const renderInput = () => {
    {
      const commonStyle = {
        fontSize: '30%',
        height : '30%',
        lineHeight: '30%',
      }
    }
    switch (field.field_type) {
      case "text":
        return (
          <Form.Item label={field.label} name={field.label}>
            <Input placeholder={field.placeholder} style={commonStyle} />
          </Form.Item>
        );
      case "email":
        return (
          <Form.Item name={field.label} label={field.label}>
            <Input placeholder={field.placeholder} style={commonStyle} />
          </Form.Item>
        );
      case "number":
        return (
          <Form.Item label={field.label} name={field.label}>
            <InputNumber
              placeholder={field.placeholder}
              style={{
                ...commonStyle,
                width: "100%",
              }}
            />
          </Form.Item>
        );
      case "password":
        return (
          <Form.Item label={field.label} name={field.label}>
            <Input.Password placeholder={field.placeholder} style={commonStyle} />
          </Form.Item>
        );
      case "checkbox":
        return (
          <Form.Item label={field.label}>
            <Checkbox.Group>
              {field.options.map((option, index) => (
                <Checkbox value={option} style={commonStyle}>{option}</Checkbox>
                // <Radio value={option}>{option} </Radio>
              ))}
            </Checkbox.Group>
          </Form.Item>
        );
      case "radio":
        return (
          <Form.Item label={field.label}>
            <Radio.Group>
              {field.options.map((option, index) => (
                <Radio value={option} style={commonStyle}>{option} </Radio>
              ))}
            </Radio.Group>
          </Form.Item>
        );
      case "dropdown":
        return (
          <Form.Item label={field.label} name={field.label}>
            <Select
              placeholder={field.placeholder}
              filterSort={(optionA, optionB) =>
                (optionA?.label ?? "")
                  .toLowerCase()
                  .localeCompare((optionB?.label ?? "").toLowerCase())
              }
              options={field.options.map((option, index) => ({
                value: option,
                label: option,
              }))}
            />
          </Form.Item>
        );
      case "date":
        return (
          <Form.Item label={field.label} name={field.label}>
            <DatePicker />
          </Form.Item>
        );
      case "textarea":
        return (
          <Form.Item label={field.label}>
            <TextArea rows={4} placeholder={field.placeholder} />
          </Form.Item>
        );
      case "file":
        // return <input type="file" disabled={true} />;
        return (
          <Form.Item
            label={field.label}
            valuePropName="fileList"
            getValueFromEvent={normFile}
          >
            <Upload action="/upload.do" listType="picture-card" maxCount={1}>
              <button
                style={{
                  border: 0,
                  background: "none",
                }}
                type="button"
              >
                <PlusOutlined />
                <div
                  style={{
                    marginTop: 5,
                  }}
                >
                  Upload
                </div>
              </button>
            </Upload>
          </Form.Item>
        );
      case "button":
        return (
          <Form.Item
            wrapperCol={{
              offset: 6,
              span: 16,
            }}
          >
            <Button type="primary" htmlType="submit">
              {field.placeholder}
            </Button>
          </Form.Item>
        );
      default:
        return <div>Unknown Form Item</div>;
    }
  };

  return (
    <div
      style={{ marginBottom: "16px", padding: "8px", border: "1px solid #ccc" }}
    >
      <div>
        <Input
          type="text"
          value={field.label}
          onChange={(e) => onUpdateLabel(e.target.value)}
          placeholder="Label"
          style={{ marginBottom: "8px", width: "100%" }}
        />
      </div>
      {field.field_type === "dropdown" && (
        <div>
          <Input
            type="text"
            value={field.options.join(",")}
            onChange={(e) => onUpdateOptions(e.target.value.split(","))}
            placeholder="Comma-separated options"
            style={{ marginBottom: "8px", width: "100%" }}
          />
        </div>
      )}
      {field.field_type === "radio" && (
        <div>
          <Input
            type="text"
            value={field.options.join(",")}
            onChange={(e) => onUpdateOptions(e.target.value.split(","))}
            placeholder="Comma-separated options"
            style={{ marginBottom: "8px", width: "100%" }}
          />
        </div>
      )}
      {field.field_type === "checkbox" && (
        <div>
          <Input
            type="text"
            value={field.options.join(",")}
            onChange={(e) => onUpdateOptions(e.target.value.split(","))}
            placeholder="Comma-separated options"
            style={{ marginBottom: "8px", width: "100%" }}
          />
        </div>
      )}
      {field.field_type === "checkbox" && (
        <div>
          <Input
            type="text"
            value={field.options.join(",")}
            onChange={(e) => onUpdateOptions(e.target.value.split(","))}
            placeholder="Comma-separated options"
            style={{ marginBottom: "8px", width: "100%" }}
          />
        </div>
      )}
      {renderInput()}
      {!previewMode && (
        <button
          onClick={onDelete}
          style={{
            marginTop: "8px",
            backgroundColor: "#ff4d4d",
            color: "white",
            border: "none",
            padding: "8px",
            borderRadius: "4px",
          }}
        >
          Delete
        </button>
      )}
    </div>
  );
};

export default FormField;
