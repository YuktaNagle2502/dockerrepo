import React, { useState, useEffect } from "react";
import { Modal, Card, message, Select, Button } from "antd";
import { Bar, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";
import axios from "axios";
import styled from "styled-components";
import WordCloudComponent from "./WordCloudComponent";
import { URL_SurveyBroadcastAPIV2 } from "../../util/constants";

// ChartJS registration
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

// Styled Components
const StyledCard = styled(Card)`
  border-radius: 12px !important;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08) !important;
  transition: all 0.3s ease-in-out;
  min-width: 280px;
  max-width: 100%;
  word-wrap: break-word;

  .ant-card-head-title {
    white-space: normal !important;
    word-wrap: break-word !important;
    font-weight: 600;
    font-size: 16px;
    line-height: 1.4;
  }

  &:hover {
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.12);
  }
`;

const StyledModal = styled(Modal)`
  .ant-modal-content {
    border-radius: 12px;
    padding: 24px;
    transition: all 0.3s ease-in-out;
    transform: scale(${(props) => (props.isinitial === "true" ? "0.85" : "1")});
  }

  .ant-modal-title {
    font-size: 20px;
    font-weight: 600;
    color: #2b2e48;
  }
`;

const StyledMessage = styled.div`
  padding: 16px;
  background-color: #fff5f5;
  border: 1px solid #ffa3a3;
  border-radius: 8px;
  color: #cc0000;
  margin-bottom: 24px;
  font-weight: 500;
`;

const LoadingSpinner = styled.div`
  align-self: center;
  display: inline-block;
  width: 50px;
  height: 50px;
  border: 3px solid #f3f3f3;
  border-top: 3px solid rgb(43, 46, 74);
  border-radius: 50%;
  animation: spin 1s linear infinite;

  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
`;

const LoadingIndicator = () => (
  <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "200px" }}>
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
      <LoadingSpinner />
      <div style={{ marginTop: "16px", color: "#2B2E48", fontWeight: "500" }}>Loading...</div>
    </div>
  </div>
);

const WordCloudAnalysisModal = ({ isVisible, onClose, formId }) => {
  const [wordCloudData, setWordCloudData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [models, setModels] = useState([]);
  const [selectedModel, setSelectedModel] = useState("");
  const [initial, setInitial] = useState(true);

  useEffect(() => {
    if (isVisible) {
      setInitial(true);
      fetchModels();
      setTimeout(() => setInitial(false), 200); // smooth opening animation
    }
  }, [isVisible]);

  const fetchModels = async () => {
    try {
      const response = await axios.get(
        "https://a9aikwz2rg.execute-api.us-east-2.amazonaws.com/dev/SurveyAnalysisAiModels"
      );
      const parsedBody = JSON.parse(response.data.body);
      const formattedModels = parsedBody.models.map((model) => ({ id: model, name: model }));
      setModels(formattedModels);
    } catch (error) {
      console.error("Error fetching models:", error);
      message.error("Failed to fetch models. Please try again.");
    }
  };

  const fetchWordCloudData = async () => {
    if (!selectedModel) {
      message.warning("Please select a model before proceeding.");
      return;
    }

    try {
      setLoading(true);
      setError("");

      const timeout = setTimeout(() => {
        console.error("Timeout: No Word Cloud data received within 3 minutes.");
        setLoading(false);
        setWordCloudData([]);
        message.error("Word Cloud data loading timed out. Please try again.");
      }, 180000);

      const response = await axios.post(`${URL_SurveyBroadcastAPIV2}/dev/form-field-analysis`, {
        id: formId,
        model: selectedModel,
      });

      const rawBody = response?.data?.body;
      if (!rawBody) throw new Error("No 'body' field found in response.");

      const parsedBody = typeof rawBody === "string" ? JSON.parse(rawBody) : rawBody;
      const results = parsedBody?.results;

      if (results) {
        const transformedData = Object.keys(results).map((key) => {
          const field = results[key];
          return {
            question: key,
            type: field.type,
            responses: field.data.map((item) => ({
              answer: item.option || item.key,
              count: item.count || item.value,
              percentage: item.percentage || null,
            })),
          };
        });
        setWordCloudData(transformedData);
      } else {
        message.warning("No Word Cloud data available for this form.");
        setWordCloudData([]);
      }

      clearTimeout(timeout);
    } catch (error) {
      console.error("Error fetching Word Cloud data:", error);
      setError("Failed to fetch Word Cloud data.");
      message.error("Failed to fetch Word Cloud data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <StyledModal
      title="Word Cloud Analysis"
      open={isVisible}
      onCancel={onClose}
      width={1000}
      footer={null}
      destroyOnClose
      isinitial={initial.toString()}
    >
      {error && <StyledMessage>{error}</StyledMessage>}

      <div style={{ display: "flex", alignItems: "center", gap: "16px", marginBottom: "24px" }}>
        <label style={{ fontWeight: "600" }}>Select Model:</label>
        <Select
          placeholder="Select a model"
          style={{ width: "300px" }}
          onChange={(value) => setSelectedModel(value)}
          value={selectedModel}
        >
          {models.map((model) => (
            <Select.Option key={model.id} value={model.name}>
              {model.name}
            </Select.Option>
          ))}
        </Select>
        <Button type="primary" onClick={fetchWordCloudData} disabled={!selectedModel}>
          Fetch Data
        </Button>
      </div>

      {loading ? (
        <LoadingIndicator />
      ) : (
        <div style={{ maxHeight: "70vh", overflowY: "auto", padding: "20px 0" }}>
          {wordCloudData.length > 0 && (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
                gap: "24px",
              }}
            >
              {wordCloudData.map((item, index) => (
                <StyledCard key={index} title={item.question}>
                  <div style={{ height: "300px", position: "relative" }}>
                    {item.type === "radio" ? (
                      <Pie
                        data={{
                          labels: item.responses.map((r) => r.answer),
                          datasets: [
                            {
                              data: item.responses.map((r) => r.count),
                              backgroundColor: [
                                "#A5D6A7", // light green
                                "#FFCC80", // light orange
                                "#EF9A9A", // light red
                                "#81D4FA", // light blue
                                "#CE93D8", // light purple
                              ],
                            },
                          ],
                        }}
                        options={{
                          maintainAspectRatio: false,
                          plugins: {
                            legend: { position: "bottom" },
                            title: { display: false },
                          },
                        }}
                      />
                    ) : item.type === "checkbox" ? (
                      <Bar
                        data={{
                          labels: item.responses.map((r) => r.answer),
                          datasets: [
                            {
                              label: "Responses",
                              data: item.responses.map((r) => r.count),
                              backgroundColor: "#81D4FA",
                            },
                          ],
                        }}
                        options={{
                          maintainAspectRatio: false,
                          plugins: {
                            legend: { display: false },
                            title: { display: false },
                          },
                        }}
                      />
                    ) : (
                      <WordCloudComponent data={item.responses} />
                    )}
                  </div>
                </StyledCard>
              ))}
            </div>
          )}
        </div>
      )}
    </StyledModal>
  );
};

export default WordCloudAnalysisModal;
