import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import cloud from 'd3-cloud';

export default function WordCloudComponent({ data = [] }) {
  const svgRef = useRef(null);

  useEffect(() => {
    const width = 400;  // reduced width
    const height = 300; // reduced height

    // Limit words and apply size scaling
    const processedWords = data
      .sort((a, b) => b.count - a.count)
      .slice(0, 40) 
      .map(d => ({
        text: d.answer,
        size: Math.sqrt(d.count) * 15 
      }));

    const layout = cloud()
      .size([width, height])
      .words(processedWords)
      .padding(5)
      .rotate(() => 0)
      .font('Impact')
      .fontSize(d => d.size)
      .on('end', draw);

    layout.start();

    function draw(words) {
      const svgElement = d3.select(svgRef.current);
      svgElement.selectAll('*').remove();

      const svg = svgElement
        .attr('width', width)
        .attr('height', height)
        .append('g')
        .attr('transform', `translate(${width / 2},${height / 2})`);

      svg.selectAll('text')
        .data(words)
        .enter().append('text')
        .style('font-size', d => `${d.size}px`)
        .style('font-family', 'Impact')
        .style('fill', (_, i) => d3.schemeCategory10[i % 10])
        .attr('text-anchor', 'middle')
        .attr('transform', d => `translate(${d.x},${d.y})rotate(${d.rotate})`)
        .text(d => d.text);
    }
  }, [data]);

  return (
    <div className="p-4 bg-white rounded shadow">
      <svg ref={svgRef}></svg>
    </div>
  );
}
