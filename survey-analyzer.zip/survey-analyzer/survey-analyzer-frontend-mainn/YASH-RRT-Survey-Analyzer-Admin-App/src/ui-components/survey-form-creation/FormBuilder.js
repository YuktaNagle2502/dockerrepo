import React, { useState, useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import * as XLSX from "xlsx";
import { serialize } from "bson";
import { saveAs } from "file-saver";
import { useDrop } from "react-dnd";
import { v4 as uuidv4 } from "uuid";
import Toolbox from "./ToolBox";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer, toast } from "react-toastify";
import FormField from "./FormField";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEye,
  faCopy,
  faSave,
  faFileAlt,
} from "@fortawesome/free-solid-svg-icons";
import TextArea from "antd/es/input/TextArea";
import styled from "styled-components";
import {
  PlusOutlined,
  SendOutlined,
  AliwangwangOutlined,
  RobotOutlined,
  CloseOutlined,
  AliwangwangFilled,
  WechatWorkFilled,
  WechatWorkOutlined,
} from "@ant-design/icons";
import { Button, Form, Input, Spin, Select } from "antd";
import axios from "axios";
import BreadCrumbs from "../BreadCrumbs";
import { UploadOutlined } from "@ant-design/icons";
import { message } from "antd";
import {
  URL_SurveyBroadcastAPIV2,
  URL_SurveyFormAdminAPIV2,
} from "../../util/constants";
import { mode } from "crypto-js";
const FormBuilder = (props) => {
  const fileInputRef = useRef(null);
  const [formItems, setFormItems] = useState([]);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [rotate, setRotate] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [formTitle, setFormTitle] = useState("");
  const [chatbotInput, setChatbotInput] = useState("");
  const [isScrolled, setIsScrolled] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  // const [isUpdate, setIsUpdate] = useState(false);
  const [scrollOffSet, setScrollOffSet] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [isToolboxOpen, setIsToolboxOpen] = useState(true);
  const [toolboxHeight, setToolboxHeight] = useState(0);
  const [isTyping, setIsTyping] = useState(false);
  const handleToolboxToggle = (isOpen) => {
    setIsToolboxOpen(isOpen);
    setToolboxHeight(isOpen ? 300 : 0);
  };
  const [selectedModel, setSelectedModel] = useState(null);
  // const { createForm } = useCreateForm();
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();
  const [{ isOver, canDrop }, drop] = useDrop(() => ({
    accept: [
      "text",
      "checkbox",
      "radio",
      "dropdown",
      "date",
      "textarea",
      "email",
      "number",
      "password",
      "file",
      "button",
    ],
    drop: (item) => {
      if (!previewMode) {
        // Function to add the dropped item to the form
        addItemToForm(item);
      }
    },
    canDrop: () => !previewMode, // Disable drop when in preview mode
    collect: (monitor) => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  }));

  // const renderMessage = !isOver && !canDrop ? <p>No item dropped</p> : null;
  const location = useLocation();
  const { hideToolbox = false } = location.state || {};
  const formData = location.state?.formData || {};
  const [isUpdate, setIsUpdate] = useState(location.state?.isUpdate ?? false);

  useEffect(() => {
    console.log("Received Data in FormBuilder:", formData);

    // Set isUpdate properly if navigation changed
    setIsUpdate(location.state?.isUpdate ?? false);

    if (!formData || Object.keys(formData).length === 0) {
      console.error("No form data received in FormBuilder");
      return;
    }

    const { title, form_schema } = formData;

    if (title) {
      setFormTitle(title);
      console.log("Form title set:", title);
    } else {
      console.warn("Form title is missing or undefined.");
    }

    if (Array.isArray(form_schema)) {
      setFormItems(form_schema);
      console.log("Form schema set:", form_schema);
    } else {
      console.error("form_schema is missing or not an array:", form_schema);
    }

    setFormLoading(false);
  }, [formData]);

  const normFile = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e?.fileList;
  };
  const LoadingSpinner = styled.div`
    align-self: center;
    display: inline-block;
    width: 50px;
    height: 50px;
    border: 3px solid #f3f3f3;
    border-top: 3px solid rgb(43, 46, 74);
    border-radius: 50%;
    animation: spin 1s linear infinite;

    @keyframes spin {
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(360deg);
      }
    }
  `;
  useEffect(() => {
    location.state?.hideToolbox ? setPreviewMode(true) : setPreviewMode(false);
    const handleScroll = () => {
      const offset = window.scrollY;
      setScrollOffSet(offset);
      setIsScrolled(offset > 10);
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const FormContainer = styled.div`
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
  `;

  const StyledForm = styled(Form)`
    display: flex;
    flex-direction: column;
    gap: 24px;

    .ant-form-item {
      margin-bottom: 0;
    }
  `;

  const FieldsGrid = styled.div`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 24px;
  `;

  const EmptyState = styled.div`
    text-align: center;
    padding: 40px;
    background: #f8fafc;
    border-radius: 12px;
    border: 2px dashed #e2e8f0;
    color: #64748b;
    font-size: 16px;
    margin: 20px 0;
  `;

  const FormFieldWrapper = styled.div`
    background: white;
    border-radius: 12px;
    border: 1px solid #e5e7eb;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;

    &:hover {
      border-color: rgb(43, 46, 74);
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
      transform: translateY(-2px);
    }

    &:before {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      width: 4px;
      height: 100%;
      background: rgb(43, 46, 74);
      opacity: 0;
      transition: opacity 0.3s ease;
    }

    &:hover:before {
      opacity: 1;
    }
  `;
  const ChatModal = styled.div`
    position: fixed;
    bottom: 70px;
    right: 450px;
    width: 400px;
    height: 500px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    display: flex;
    flex-direction: column;
    z-index: 1000;
    border: 1px solid #e8e8e8;
    transition: all 0.3s ease;
  `;

  const ChatHeader = styled.div`
    padding: 15px 20px;
    background: rgb(43, 46, 72);
    color: white;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  `;

  const ChatArea = styled.div`
    flex: 1;
    padding: 20px;
    overflow-y: auto;
    background: #f9f9f9;
    display: flex;
    flex-direction: column;
  `;
  const TypingIndicatorContainer = styled.div`
    display: flex;
    align-items: center;
    background: white;
    padding: 12px;
    border-radius: 10px;
    width: fit-content;
    margin-top: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  `;
  const TypingDot = styled.span`
    display: inline-block;
    width: 8px;
    height: 8px;
    background-color: rgb(43, 46, 72);
    border-radius: 50%;
    margin: 0 3px;
    opacity: 0.6;

    &:nth-child(1) {
      animation: typing 1.4s infinite;
    }
    &:nth-child(2) {
      animation: typing 1.4s infinite 0.2s;
    }
    &:nth-child(3) {
      animation: typing 1.4s infinite 0.4s;
    }

    @keyframes typing {
      0%,
      100% {
        transform: translateY(0);
      }
      50% {
        transform: translateY(-10px);
      }
    }
  `;

  const WelcomeMessage = styled.div`
    padding: 10px 15px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    margin-bottom: 10px;
  `;

  const ChatInputContainer = styled.div`
    padding: 15px;
    background: white;
    border-top: 1px solid #e8e8e8;
    display: flex;
    gap: 10px;
    align-items: center;
  `;

  const BouncingChatButton = styled(AliwangwangOutlined)`
    float: right;
    font-size: 35px;
    color: rgb(56, 68, 174);
    margin: -6px 150px 0px 0px;
  `;
  //new chatbot css
  // const ChatbotContainer = styled.div`
  //   position: fixed;
  //   bottom: 20px;
  //   right: 20px; // Adjusted for better positioning
  //   display: flex;
  //   align-items: flex-end;
  //   gap: 16px;
  //   z-index: 1000;
  //   transition: all 0.3s ease; // Smooth transition for the container
  // `;

  // const ChatInputContainer = styled.div`
  //   display: flex;
  //   align-items: center;
  //   background-color: white;
  //   border-radius: 12px;
  //   padding: 12px;
  //   box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  //   transform-origin: bottom right;
  //   opacity: ${props => props.isOpen ? 1 : 0};
  //   transform: ${props => props.isOpen ? 'translateY(0) scale(1)' : 'translateY(20px) scale(0.9)'};
  //   transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
  //   width: ${props => props.isOpen ? '400px' : '0'};
  //   margin-right: 16px;
  //   border: 2px solid rgba(43, 46, 72, 0.1);

  //   &:hover {
  //     box-shadow: 0 12px 28px rgba(0, 0, 0, 0.2);
  //   }
  // `;

  // const StyledInput = styled(Input)`
  //   border: none;
  //   background: rgba(43, 46, 72, 0.05);
  //   border-radius: 8px;
  //   padding: 12px;
  //   margin-right: 12px;
  //   transition: all 0.2s ease;

  //   &:hover, &:focus {
  //     background: rgba(43, 46, 72, 0.08);
  //     box-shadow: none;
  //   }

  //   &::placeholder {
  //     color: rgba(43, 46, 72, 0.6);
  //   }
  // `;

  // const StyledSendButton = styled(Button)`
  //   background: none;
  //   border: none;
  //   padding: 8px;
  //   display: flex;
  //   align-items: center;
  //   justify-content: center;
  //   cursor: pointer;
  //   transition: all 0.2s ease;

  //   &:hover {
  //     transform: scale(1.1);
  //   }

  //   .anticon {
  //     font-size: 24px;
  //     color: rgb(43, 46, 72);
  //   }
  // `;

  // const ChatbotIcon = styled(WechatFilled)`
  //   font-size: 50px;
  //   color: rgb(43, 46, 72);
  //   cursor: pointer;
  //   transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
  //   transform: ${props => props.isChatbotOpen ? 'rotate(360deg) scale(1.1)' : 'rotate(0) scale(1)'};

  //   &:hover {
  //     transform: ${props => props.isChatbotOpen ? 'rotate(360deg) scale(1.2)' : 'scale(1.1)'};
  //     filter: brightness(1.1);
  //   }

  //   animation: ${props => props.isChatbotOpen ? 'none' : 'bounce 2s infinite'};

  //   @keyframes bounce {
  //     0%, 20%, 50%, 80%, 100% {
  //       transform: translateY(0);
  //     }
  //     40% {
  //       transform: translateY(-12px);
  //     }
  //     60% {
  //       transform: translateY(-6px);
  //     }
  //   }
  // `;

  const iconStyles = {
    position: "sticky",
    bottom: 10,
    right: 145,
    cursor: "pointer",
    zIndex: 1,
    float: "right",
    transition: "all 0.2s ease",
    height: "36px",
    marginRight: "15.5%",
    marginLeft: " 1.25%",
  };
  if (isScrolled) {
    if (scrollOffSet < 30) {
      iconStyles.bottom = iconStyles.bottom + scrollOffSet + 3;
    } else {
      iconStyles.bottom = iconStyles.bottom + 33;
    }
    iconStyles.transform = "scale(1)";
  }

  const handleChatBotInput = (e) => {
    setChatbotInput(e.target.value);
  };


const chatbotSubmit = async () => {
  if (!chatbotInput.trim()) {
    toast.error("Please enter a prompt.");
    return;
  }

  if (!selectedModel) {
    toast.error("Please select a model."); 
    return;
  }

  setFormLoading(true);
  setIsTyping(true);

  let payload = {
    prompt: chatbotInput,
    model: selectedModel,
  };

  try {
    const response = await axios.post(
      `${URL_SurveyBroadcastAPIV2}/dev/chatbotV2`,
      payload,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    const updatedFormSchema = response.data.body.message.form_schema.map(
      (field) => ({
        ...field,
        id: uuidv4(),
      })
    );

    setFormItems(updatedFormSchema);
    setPreviewMode(!previewMode);
    setChatbotInput("");
    setIsChatbotOpen(false);
  } catch (error) {
    toast.error("Sorry! Unexpected Error occurs");
  } finally {
    setIsTyping(false);
    setFormLoading(false);
  }
};

  const viewCreatedForms = () => {
    navigate("/view-forms");
  };

  const capitalizeFirstLetter = (string) => {
    return string.charAt(0).toUpperCase() + string.slice(1);
  };

  const generateHtmlString = () => {
    return formItems
      .map((item) => {
        const placeholder = capitalizeFirstLetter(item.placeholder);
        switch (item.field_type) {
          case "text":
            return `<Form.Item label="${item.label}"labelCol={{ span: 8 }} wrapperCol={{ span: 16 }} name="${item.label}">
                <Input placeholder="${item.placeholder}" style={{ whiteSpace: 'normal', wordWrap: 'break-word' }}/>
              </Form.Item>`;
          case "email":
            return `
              <Form.Item name="${item.label}" label="${item.label}">
                <Input placeholder="${item.placeholder}" />
              </Form.Item>`;
          case "number":
            return `
              <Form.Item label="${item.label}" name="${item.label}">
                <InputNumber
                  placeholder="${item.placeholder}"
                  style={{
                    width: "100%",
                  }}
                />
              </Form.Item>`;
          case "password":
            return `
              <Form.Item label="${item.label}" name="${item.label}">
                <Input.Password placeholder="${item.placeholder}" />
              </Form.Item>`;
          case "checkbox":
            return `
            <Form.Item label="${item.label}">
                <Checkbox.Group>
                  ${item.options
                    .map(
                      (option, index) =>
                        `<Checkbox value=${option}>${option}</Checkbox>`
                    )
                    .join("")}
                </Checkbox.Group>
              </Form.Item>
      `;
          case "radio":
            return `
              <Form.Item label="${item.label}">
                <Radio.Group>
                  ${item.options
                    .map(
                      (option, index) =>
                        ` <Radio value=${option}>${option} </Radio>`
                    )
                    .join("")}
                </Radio.Group>
              </Form.Item>`;
          case "dropdown":
            return `
              <Form.Item label="${item.label}" name="${item.label}">
                <Select
                  placeholder="${item.placeholder}"
                  filterSort=${(optionA, optionB) =>
                    (optionA?.label ?? "")
                      .toLowerCase()
                      .localeCompare((optionB?.label ?? "").toLowerCase())
                      .join("")}
                  options=${item.options
                    .map((option, index) => ({
                      value: option,
                      label: option,
                    }))
                    .join("")}
                />
              </Form.Item>`;
          case "date":
            return `
              <Form.Item label="${item.label}" name="${item.label}">
                <DatePicker />
              </Form.Item>`;
          case "textarea":
            return `
              <Form.Item label="${item.label}">
                <TextArea rows={4} placeholder="${item.placeholder}" />
              </Form.Item>`;
          case "file":
            return `
              <Form.Item
                label="${item.label}"
                valuePropName="fileList"
                getValueFromEvent={normFile}
              >
                <Upload action="/upload.do" listType="picture-card" maxCount={1}>
                  <button
                    style={{
                      border: 0,
                      background: "none",
                     
                    }}
                    type="button"
                  >
                    <PlusOutlined />
                    <div
                      style={{
                        marginTop: 5,
                      }}
                    >
                      Upload
                    </div>
                  </button>
                </Upload>
              </Form.Item>`;
          case "button":
            return `
                    <Form.Item
                      wrapperCol={{
                        offset: 6,
                        span: 16,
                      }}
                    >
                      <Button type="primary" htmlType="submit">
                        ${placeholder}
                      </Button>
                    </Form.Item>`;
          default:
            return <div>Unknown Form Item</div>;
        }
      })
      .join("");
  };

  const handleCopyHtml = () => {
    const htmlString = generateHtmlString();
    navigator.clipboard.writeText(htmlString).then(() => {
      alert("HTML copied to clipboard!");
    });
  };
  const formTitleChange = (e) => {
    setFormTitle(e.target.value);
  };

  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      if (chatbotInput.length > 0) {
        chatbotSubmit();
      }
    }
  };
  const addItemToForm = (item) => {
    const newItem = {
      id: uuidv4(),
      field_type: item.type,
      label: item.label || "New Field",
      required: false,
      options:
        item.type === "dropdown" ||
        item.type === "radio" ||
        item.type === "checkbox"
          ? ["Option 1", "Option 2", "Option 3"]
          : [],
      placeholder: item.placeholder || "",
      wordCloud:
        item.type === "text" || item.type === "textarea" ? false : undefined, // Initialize wordCloud for text and textarea
    };
    setFormItems((prevItems) => [...prevItems, newItem]);
  };

  const onUpdateWordCloud = (id, isChecked) => {
    setFormItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, wordCloud: isChecked } : item
      )
    );
  };

  const saveForm = async () => {
    if (!formTitle) {
      console.error("Please provide a title for your form.");
      toast.error("Please provide a title for your form.");
      return;
    }

    setSaving(true);

    try {
      console.log("setIsUpdate:", isUpdate);

      const payloadSchema = formItems.map((item) => ({
        field_type: item.field_type,
        label: item.label,
        placeholder: item.placeholder,
        required: item.required,
        options: item.options,
        wordCloud: item.wordCloud || false, // Default to false if not set
      }));

      if (!isUpdate) {
        const payload = {
          title: formTitle,
          form_schema: payloadSchema,
        };

        console.log("payload.form_fields:", payload);

        const response = await axios.post(
          `${URL_SurveyFormAdminAPIV2}/dev/survey-formV2`,
          payload,
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        console.log("response:", response);
        toast.success("Form and fields saved successfully");
      } else {
        if (!formData?.id) {
          console.error("Invalid form data received");
          toast.error("Invalid form data for update.");
          return;
        }

        const url = `${URL_SurveyFormAdminAPIV2}/dev/update-form-schema`;

        const payload = {
          form_id: formData.id,
          updated_form_schema: payloadSchema,
        };

        console.log("updated_form_schema:", payload);

        const response = await axios.post(url, payload, {
          headers: {
            "Content-Type": "application/json",
          },
        });

        console.log("Form updated successfully:", response.data);
        toast.success("Form and fields edited successfully");
      }
    } catch (error) {
      console.error("Error saving form:", error);
      toast.error("Error saving form.");
    } finally {
      setSaving(false);
    }
  };

  const convertExcelToBson = async (file) => {
    try {
      if (!selectedModel) {
        alert("Please select a model.");
        return;
      }
      setFormLoading(true);
      setIsChatbotOpen(false);
      const reader = new FileReader();
      reader.readAsBinaryString(file);
  
      reader.onload = async (e) => {
        try {
          const binaryStr = e.target.result;
          const workbook = XLSX.read(binaryStr, { type: "binary" });
          const sheet1 = workbook.Sheets[workbook.SheetNames[0]];
  
          console.log("Excel Data:", sheet1);
  
          const keys = Object.keys(sheet1);
          const values = keys.map((key) => sheet1[key]?.v).filter(Boolean);
  
          console.log("Extracted Excel Values:", values);
  
          const formattedValues = JSON.stringify(values).replace(/"/g, "'");
          sendExtractedData(formattedValues); // Pass extracted values to sendExtractedData
        } catch (apiError) {
          console.error("API Request Failed:", apiError);
          toast.error("An error occurred while processing the file.");
        } finally {
          setFormLoading(false);
        }
      };
  
      reader.onerror = () => {
        console.error("File reading failed.");
        toast.error("Failed to read the file. Please try again.");
        setFormLoading(false);
      };
    } catch (error) {
      console.error("Error converting Excel to BSON:", error);
      toast.error("An unexpected error occurred. Please try again.");
      setFormLoading(false);
    }
  };
  const sendExtractedData = async (extractedValues) => {
    try {
      const payload = {
        "Extracted Excel Values": extractedValues,
        model: selectedModel,
      };
  
      console.log("Sending second API payload:", payload);
  
      const response = await fetch(
        `${URL_SurveyBroadcastAPIV2}/dev/chatbotfileV2`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        }
      );
  
      if (!response.ok) {
        const errorData = await response.json();
        console.error("API Error Response:", errorData);
        toast.error(errorData.error || `Error: ${response.status}`);
        setFormLoading(false);
        return;
      }
  
      const result = await response.json();
      console.log("Second API Response:", result);
  
      const updatedFormSchema = result.body.message.form_schema.map((field) => ({
        ...field,
        id: uuidv4(),
      }));
  
      setFormItems(updatedFormSchema);
      setPreviewMode(!previewMode);
      setChatbotInput("");
      setIsChatbotOpen(false);
      setFormLoading(false);
    } catch (error) {
      console.error("Second API Request Failed:", error);
      toast.error("An error occurred while processing the extracted data.");
    }
  };

  //   const file = event.target.files[0];

  //   if (file) {
  //     const reader = new FileReader();

  //     reader.onload = (e) => {
  //       const fileData = {
  //         name: file.name,
  //         type: file.type,
  //         size: file.size,
  //         content: e.target.result,
  //       };

  //       console.log("Uploaded File Data:", fileData);
  //       message.success(`File uploaded: ${file.name}`);
  //     };

  //     reader.readAsText(file);
  //   }
  // };

  // Function to trigger file explorer

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      convertExcelToBson(file);
      console.log("File Name", file);
    }
  };

  const openFileExplorer = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleEditForm = async (formData) => {
    if (!formData?.id || !Array.isArray(formData.form_schema)) {
      console.error(" Invalid form data received");
      return;
    }

    const url = `${URL_SurveyFormAdminAPIV2}/dev/update-form-schema`;

    const payload = {
      form_id: formData.id,
      updated_form_schema: formData.form_schema,
      title: formData.formTitle,
    };

    try {
      const response = await axios.post(url, payload);
      console.log(" Form updated successfully:", response.data);
    } catch (error) {
      console.error(" Failed to update form:", error);
    }
  };

  return (
    <>
      <style>
        {`
    /* Disable scrolling on the entire page */
    body {
      overflow: hidden;
      font-family: 'Arial', sans-serif;
      background-color: #f4f4f4;
      color: #333;
    }
 
    /* Overlay for shadowing or blurring the background */
    .overlay {
      
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      
      z-index: 999;
      display: none;
    }
 
    .overlay.show {
      display: block;
    }
 
    /* Outer container with scroll enabled */
    .outer-card {
      overflow-y: auto;
      max-height: 90vh;
      padding: 30px; /* Increased padding for better spacing */
      padding-top: 50px; /* Additional top padding */
      padding-bottom: 100px; /* Additional bottom padding */
      border-radius: 12px;
      // box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
    }
 
    /* Inner form container with its own scroll */
    .form-container {
      overflow-y: auto;
      height: 60vh;
      padding: 15px;
      // border: 1px solid #e5e7eb;
      border-radius: 8px;
      // background-color: #f9f9f9;
    }
 
    /* Button styles */
    button {
      border: none;
      border-radius: 8px;
      cursor: pointer;
      padding: 12px 20px;
      transition: all 0.3s ease;
      font-weight: bold;
      font-size: 16px;
    }
 
    /* Primary button styles */
    .btn-primary {
      background-color: #007bff;
      color: white;
    }
    .btn-primary:hover {
      background-color: #0056b3;
      transform: translateY(-2px);
    }
 
    /* Success button styles */
    .btn-success {
      background-color: #28a745;
      color: white;
    }
    .btn-success:hover {
      background-color: #218838;
      transform: translateY(-2px);
    }
 
    /* Chatbot styles */
.chatbot {
      position: fixed;
      top: 50%; /* Center vertically */
      left: 50%; /* Center horizontally */
      transform: translate(-50%, -50%); /* Adjust for the size of the card */
      width: calc(100% - 40px); /* Responsive width with some margin */
      max-width: 500px; /* Maximum width for the chatbot */
      z-index: 1000;
      background-color: #ffffff;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
      border-radius: 12px;
      border: 1px solid #e8e8e8;
    }
 
    .chatbot-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 15px;
      border-bottom: 1px solid #f0f0f0;
      background-color: #f9f9f9;
      border-top-left-radius: 12px;
      border-top-right-radius: 12px;
    }
 
    .chatbot-input {
      display: flex;
      align-items: center;
      padding: 10px;
    }
 
    .chatbot-input input {
      flex: 1;
      margin-right: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
      padding: 10px;
      transition: border-color 0.3s ease;
    }
    .chatbot-input input:focus {
      border-color: #007bff;
      outline: none;
    }
  `}
      </style>

      <div style={{ position: "relative" }}>
        {isChatbotOpen && <div className="overlay show"></div>}

        <BreadCrumbs location={props.location} />
        <ToastContainer position="top-center" />

        <div
          style={{
            marginBottom: "55px",
            display: "flex",
            backgroundColor: "white",
            minHeight: "60vh",
          }}
        >
          <div
            ref={drop}
            style={{
              padding: "14px",
              minHeight: "210px",
              flexGrow: 1,
              margin: "7px",
              width: `${(props) =>
                props.isToolboxOpen
                  ? "calc(100% - 245px)"
                  : "calc(100% - 42px)"}`,
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                color: "#2B2E48",
                marginBottom: "14px",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  margin: "0",
                  padding: "0",
                }}
              >
                <label
                  style={{
                    margin: "0",
                    padding: "0",
                    fontSize: "15px",
                    fontWeight: "600",
                    color: "#333",
                    marginRight: "10px",
                    whiteSpace: "nowrap",
                  }}
                >
                  Form Title:
                </label>
                <Input
                  placeholder="Enter Title"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  style={{
                    flex: 1,
                    padding: "8px 11px",
                    fontSize: "11px",
                    border: "2px solid #e5e7eb",
                    borderRadius: "8px",
                    transition: "all 0.2s ease",
                    color: "#1f2937",
                    textTransform: "capitalize",
                    margin: "0",
                  }}
                />
              </div>
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  flexWrap: "wrap",
                  gap: "7px",
                }}
              >
                {!location.state?.hideToolbox && (
                  <>
                    <button
                      onClick={() => setPreviewMode(!previewMode)}
                      className={previewMode ? "btn-primary" : "btn-success"}
                      style={{
                        padding: "6px 10px",
                        fontSize: "9px",
                        minWidth: "77px",
                        borderRadius: "6px",
                        transition: "all 0.2s ease-in-out",
                      }}
                    >
                      <FontAwesomeIcon
                        icon={faEye}
                        style={{ marginRight: "3px" }}
                      />
                      {previewMode ? "Back to Edit" : "Preview Form"}
                    </button>
                  </>
                )}

                {previewMode && !location.state?.hideToolbox && (
                  <>
                    <div>
                      {saving && (
                        <div
                          style={{
                            position: "fixed",
                            top: 0,
                            left: 0,
                            width: "100%",
                            height: "100%",
                            backgroundColor: "rgba(255, 255, 255, 0.8)",
                            zIndex: 1000,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            backdropFilter: "blur(2px)",
                          }}
                        >
                          <Spin size="large" tip="Saving..." />
                        </div>
                      )}

                      <button
                        onClick={saveForm}
                        className="btn-success"
                        style={{
                          padding: "6px 10px",
                          fontSize: "9px",
                          minWidth: "77px",
                          borderRadius: "6px",
                          transition: "all 0.2s ease-in-out",
                          opacity: saving ? 0.5 : 1, // Optional: make the button semi-transparent when loading
                          cursor: saving ? "not-allowed" : "pointer", // Change cursor style when loading
                        }}
                        disabled={saving} // Disable the button while saving
                      >
                        {saving ? (
                          <>
                            <Spin size="larg" style={{ marginRight: "3px" }} />
                            Saving...
                          </>
                        ) : (
                          <>
                            <FontAwesomeIcon
                              icon={faSave}
                              style={{ marginRight: "3px" }}
                            />
                            Save Form
                          </>
                        )}
                      </button>
                    </div>
                    {/* <button
          onClick={async (data) => {
            console.log("Data:",data)
            if (!formData?.id || !Array.isArray(form_schema)) {
              console.error("Missing form ID or schema");
              return;
            }

    const payload = {
      form_id: formData.id,
      updated_form_schema: form_schema.map(({ id, ...field }) => field), 
    };

    try {
      const response = await axios.post(
        "https://04g4bjuen6.execute-api.us-east-2.amazonaws.com/dev/update-form-schema",
        payload
      );
      console.log("Form updated:", response.data);
      alert("Form updated successfully!");
    } catch (error) {
      console.error("Failed to update form:", error);
      alert("Failed to update form.");
    }
  }}
  className="btn-primary"
  style={{
    padding: "6px 10px",
    fontSize: "9px",
    minWidth: "77px",
    borderRadius: "6px",
    transition: "all 0.2s ease-in-out",
  }}
>
  <FontAwesomeIcon icon={faCopy} style={{ marginRight: "3px" }} />
  Edit
</button> */}
                  </>
                )}
              </div>
            </div>
            <hr style={{ color: "rgb(43, 46, 74)", marginTop: "14px" }} />
            {formLoading && (
              <div style={{ placeItems: "center", marginTop: "98px" }}>
                <LoadingSpinner />
                <div
                  style={{
                    color: "rgb(43, 46, 74)",
                    alignSelf: "center",
                    fontWeight: "500",
                  }}
                >
                  Loading...
                </div>
              </div>
            )}

            {!formLoading && (
              <div className="form-container">
                <>
                  {formItems.length == 0 && (
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        alignItems: "center",
                        minHeight: "50vh",
                        backgroundColor: "#f9f9f9",
                        border: "1px dashed #ccc",
                        borderRadius: "8px",
                        textAlign: "center",
                        padding: "20px",
                        boxShadow: "0 2px 10px rgba(0, 0, 0, 0.1)",
                      }}
                    >
                      <p
                        style={{
                          color: "rgb(43, 46, 74)",
                          fontWeight: "400",
                          fontSize: "1.1rem",
                        }}
                      >
                        Drag and drop fields here
                      </p>
                    </div>
                  )}
                  <Form layout="vertical">
                    {formItems.map((item, index) => (
                      <FormField
                        style={{ width: "100%" }}
                        key={index}
                        field={item}
                        previewMode={previewMode}
                        onDelete={() =>
                          setFormItems(
                            formItems.filter((i) => i.id !== item.id)
                          )
                        }
                        onUpdateLabel={(newLabel) =>
                          setFormItems(
                            formItems.map((i) =>
                              i.id === item.id ? { ...i, label: newLabel } : i
                            )
                          )
                        }
                        onUpdatePlaceholder={(newPlaceholder) =>
                          setFormItems(
                            formItems.map((i) =>
                              i.id === item.id
                                ? { ...i, placeholder: newPlaceholder }
                                : i
                            )
                          )
                        }
                        onUpdateOptions={(newOptions) =>
                          setFormItems(
                            formItems.map((i) =>
                              i.id === item.id
                                ? { ...i, options: newOptions }
                                : i
                            )
                          )
                        }
                        onUpdateWordCloud={onUpdateWordCloud}
                      />
                    ))}
                  </Form>
                </>
              </div>
            )}
          </div>

          {location.state?.hideToolbox ? (
            <></>
          ) : (
            <Toolbox onToggle={handleToolboxToggle} />
          )}
        </div>

        {isChatbotOpen && (
          <div
            style={{
              position: "fixed",
              left: "57%",
              transform: "translate(-50%, -50%)",
              width: "calc(100% - 210px)",
              maxWidth: "1200px",
              zIndex: 1000,
              backgroundColor: "white",
              boxShadow: "0 4px 15px rgba(0, 0, 0, 0.1)",
              borderRadius: "8px",
              border: "1px solid #e8e8e8",
              marginTop: "-64px",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "7px 10px",
                borderBottom: "1px solid #f0f0f0",
              }}
            >
              <div style={{ display: "flex", alignItems: "center" }}>
                <RobotOutlined
                  style={{
                    fontSize: "14px",
                    marginRight: "7px",
                    color: "rgb(43, 46, 72)",
                  }}
                />
                <h4
                  style={{
                    margin: 0,
                    fontWeight: 600,
                    color: "rgb(43, 46, 72)",
                    fontSize: "12px",
                  }}
                >
                  Form Generator Assistant
                </h4>
              </div>
              <div
                style={{ display: "flex", alignItems: "center", gap: "10px" }}
              >
                {/* Dropdown for selectable entities */}
                <Select
                  style={{ width: 200 }}
                  placeholder="Select a model"
                  onChange={(value) => setSelectedModel(value)}
                  options={[
                    { value: "qwen2.5-coder:3b", label: "qwen2.5-coder:3b" },
                    {
                      value: "gemini-2.0-flash-exp",
                      label: "gemini-2.0-flash-exp",
                    },
                  ]}
                />
                <CloseOutlined
                  onClick={() => setIsChatbotOpen(false)}
                  style={{
                    cursor: "pointer",
                    fontSize: "11px",
                    color: "rgba(0,0,0,0.45)",
                  }}
                />
              </div>
            </div>
            <div
              className="chatbot-input"
              style={{ display: "flex", alignItems: "center", gap: "6px" }}
            >
              <Input
                onChange={(e) => setChatbotInput(e.target.value)}
                placeholder="Describe your form requirements..."
                value={chatbotInput}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    chatbotSubmit();
                    setIsChatbotOpen(false);
                  }
                }}
                style={{
                  flex: 1,
                  marginRight: "7px",
                  borderRadius: "4px",
                  border: "1px solid #ccc",
                  fontSize: "12px",
                }}
                autoFocus
              />

              <input
                type="file"
                ref={fileInputRef}
                style={{ display: "none" }}
                onChange={handleFileUpload}
              />
              <Button
                icon={<UploadOutlined />}
                onClick={openFileExplorer}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  borderRadius: "6px",
                  border: "1px solid #ccc",
                  backgroundColor: "#f8f9fa",
                  fontSize: "12px",
                }}
              />
              <Button
                type="primary"
                onClick={() => chatbotInput.length > 0 && chatbotSubmit()}
                icon={<SendOutlined />}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "12px",
                }}
              />
            </div>
          </div>
        )}

        <div
          style={{
            position: "fixed",
            bottom: 30,
            right: -130,
            cursor: "pointer",
            zIndex: 1000,
            transition: "all 0.2s ease",
            marginLeft: "200px",
          }}
        >
          <BouncingChatButton
            onClick={() => setIsChatbotOpen(!isChatbotOpen)}
          />
        </div>
      </div>
    </>
  );
};

export default FormBuilder;
