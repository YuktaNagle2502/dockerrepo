import React, { useEffect, useState } from "react";
import axios from "axios";
import { Card, Row, Col, Spin, Alert, Button, Tooltip, Modal, Input } from "antd";
import { BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip, CartesianGrid, ResponsiveContainer } from "recharts";
import { URL_SurveyFormAdminAPIV2 } from "../../util/constants";

const Dashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [grafanaUrl, setGrafanaUrl] = useState("");

  const GRAFANA_IP_ADDRESS = "44.237.14.238";
  const GRAFANA_DASHBOARD_PATH = "/d/becbkb4dw5y4gd/demo-dashboard?orgId=1&from=now-6h&to=now&timezone=browser";
  const GRAFANA_PORT = "3000";

  useEffect(() => {
    axios
      .get(`${URL_SurveyFormAdminAPIV2}/dev/dashboard`)
      .then((response) => {
        setDashboardData(response.data.body || {});
        setLoading(false);
      })
      .catch((error) => {
        console.error("API Fetch Error:", error);
        setError(true);
        setLoading(false);
      });
  }, []);

  const handleGenerateGraph = () => {
    const url = `http://${GRAFANA_IP_ADDRESS}:${GRAFANA_PORT}${GRAFANA_DASHBOARD_PATH}`;
    setGrafanaUrl(url);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  if (loading) {
    return (
      <div style={{ textAlign: "center", padding: "2rem" }}>
        <Spin size="large" />
        <p>Loading Dashboard Data...</p>
      </div>
    );
  }

  if (error || !dashboardData) {
    return (
      <div style={{ textAlign: "center", color: "red", padding: "2rem" }}>
        <Alert message="Error loading dashboard data. Please try again." type="error" showIcon />
      </div>
    );
  }

  const { TotalForm, statusCounts, total_forms } = dashboardData;

  return (
    <div style={{ padding: "20px", maxWidth: "1200px", margin: "auto", height: "100vh", overflowY: "auto" }}>
      <div style={{ position: "absolute", top: "20px", right: "90px", marginTop: "82px" }}>
        <Tooltip title="Generate Grafana Graph" placement="top">
          <Button type="primary" style={buttonStyle} onClick={handleGenerateGraph}>
            Grafana Dashboard
          </Button>
        </Tooltip>
      </div>
      
      <h1 style={{ textAlign: "center", marginBottom: "20px", color: "#333" }}>Dashboard</h1>
      <Row gutter={[16, 16]} justify="center">
        <Col xs={24} sm={12} md={8}>
          <Card title="Total Forms" bordered={false} style={cardStyle}>
            <h2 style={cardValueStyle}>{TotalForm}</h2>
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8}>
          <Card title="Forms Submitted" bordered={false} style={cardStyle}>
            <h2 style={cardValueStyle}>{statusCounts.submitted}</h2>
          </Card>
        </Col>
        <Col xs={24} sm={12} md={8}>
          <Card title="Pending Forms" bordered={false} style={cardStyle}>
            <h2 style={cardValueStyle}>{statusCounts.pending}</h2>
          </Card>
        </Col>
      </Row>

      <div style={chartContainerStyle}>
        <h3 style={chartTitleStyle}>Total Forms Submitted Per Month</h3>
        <div style={chartStyle}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart 
              data={total_forms}
              margin={{ top: 5, right: 20, left: 10, bottom: 50 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="month" 
                angle={-45} 
                textAnchor="end" 
                height={50}
                interval={0} 
                tick={{ fontSize: 12 }}
              />
              <YAxis 
                tickCount={5} 
                allowDecimals={false} 
                tick={{ fontSize: 12 }}
              />
              <RechartsTooltip />
              <Bar dataKey="total" fill="#4caf50" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

const cardStyle = {
  transition: "transform 0.2s",
  cursor: "pointer",
  borderRadius: "10px",
  textAlign: "center",
  boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
  backgroundColor: "#ffffff",
  border: "1px solid #f0f0f0",
  height: "150px",
};

const cardValueStyle = {
  color: "#1a73e8",
  fontSize: "1.5rem",
  margin: "10px 0",
};

const chartContainerStyle = {
  marginTop: "20px",
  background: "#fff",
  padding: "20px",
  borderRadius: "10px",
  boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
};

const chartTitleStyle = {
  color: "#555",
  textAlign: "center",
  marginBottom: "15px",
};

const chartStyle = {
  width: "100%",
  height: "300px",
};

const buttonStyle = {
  borderRadius: "5px",
  padding: "10px 20px",
  fontSize: "16px",
  backgroundColor: "#4caf50",
  color: "#fff",
  border: "none",
};

export default Dashboard; 