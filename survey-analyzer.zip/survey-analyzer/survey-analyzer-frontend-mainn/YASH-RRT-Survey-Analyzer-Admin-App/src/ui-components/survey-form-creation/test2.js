import React, { useEffect, useState } from "react";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import * as XLSX from "xlsx";
import {
  faShareAlt,
  faCopy,
  faTrash,
  faShare,
} from "@fortawesome/free-solid-svg-icons";
import {
  Button,
  Checkbox,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Radio,
  Select,
  Upload,
  Model,
  Icon,
  Tag,
  message,
  Modal,
  Spin,
} from "antd";
import TextArea from "antd/es/input/TextArea";
import { CopyOutlined, LoadingOutlined, PlusOutlined } from "@ant-design/icons";
import BreadCrumbs from "../BreadCrumbs";
import styled from "@emotion/styled";
import {
  URL_SurveyBroadcastAPIV2,
  URL_SurveyFormAdminAPIV2,
} from "../../util/constants";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { SearchOutlined } from "@ant-design/icons";

const ViewForms = (props) => {
  const [forms, setForms] = useState([]);
  // const [emails, setEmails] = useState([]);
  const [editorValue, setEditorValue] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [formTitle, setFormTitle] = useState("");
  const [formURL, setFormURL] = useState("http://dummyLink/view-forms");
  const [shareDisable, setShareDisable] = useState(false);
  const [modalLoading, setModalLoading] = useState(false);
  const [selectedForm, setSelectedForm] = useState(null);
  const [searchInput, setSearchInput] = useState("");
  const [selectedValue, setSelectedValue] = useState(null);
  const [emails, setEmails] = useState([]);
  const [messageApi, contextHolder] = message.useMessage();
  const key = "updatable";

  const openMessage = () => {
    messageApi.open({
      key,
      type: "loading",
      content: "Copying...",
    });
    setTimeout(() => {
      messageApi.open({
        key,
        type: "success",
        content: "Copied!",
        duration: 2,
      });
    }, 1000);
  };

  // const handleSearch = (value) => {
  //   const newEmail = value.trim();
  //   if (newEmail) {

  //     setEmails([...emails, newEmail]);
  //   }
  // };

  const antIcon = (
    <>
      <LoadingOutlined style={{ fontSize: 24 }} spin />
    </>
  );
  const copyLinkToClipboard = () => {
    // inputRef.current.select();
    openMessage();
    navigator.clipboard.writeText(formURL);
  };

  const [shareForm] = Form.useForm();
  shareForm.setFieldsValue({
    title: formTitle,
  });

  const [isModalOpenForm, setIsModalOpenForm] = useState(false);

  const showModalForm = () => {
    setIsModalOpenForm(!isModalOpenForm);
  };

  const [isModalOpen, setIsModalOpen] = useState(false);

  const showModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  const handleViewClick = (title) => {
    console.log("title:", title);
    setSelectedForm(title); // Set the selected form data
    setFormTitle(title); // Set the form title in the state
    shareForm.setFieldsValue({ title: title }); // Set the form title in the shareForm state
    showModal(); // Open the modal
  };

  useEffect(() => {
    if (formTitle) {
      shareForm.setFieldsValue({ title: formTitle });
    }
  }, [formTitle, shareForm]);

  const handleOk = async (values) => {
    setModalLoading(true);
    console.log("values received:", values);

    // Extract correct properties from values
    const { title, emails, content } = values;

    console.log("Title:", title);
    console.log("Emails:", emails);
    console.log("Content:", content);

    let recipients = [];
    if (Array.isArray(emails)) {
      // If emails is an array of objects
      recipients = emails.map(({ name, email }, index) => ({
        name: name || "", // Set to empty string if name is not provided
        email: email || "", // Ensure email is always present
      }));
    } else if (typeof emails === 'string') {
      // If emails is a comma-separated string
      const emailList = emails.split(',').map(email => email.trim());
      console.log("Email list after splitting:", emailList); // Add this log for debugging
 
      recipients = emailList.map((email, index) => ({
        name: "", // If no name is provided, we set it as an empty string
        email: email, // Ensure the email is included
      }));
    } else {
      // If emails is just a single email
      recipients = [{
        name: "", // Default empty name
        email: emails || "", // Ensure email is present
      }];
    }

    // console.log("Recipients:", recipients);

    // Default editor content fallback
    let htmlContent = content?.html || editorValue || "";

    // Define the actual survey link
    const surveyLink = "userApplicationLink"; // Replace this with the actual dynamic link

    // Replace every occurrence of "Survey Links" with the correct anchor tag
    htmlContent = htmlContent.replace(
      /Survey Link/g,
      `<a href="${surveyLink}" target="_blank">Survey Link</a>`
    );

    // Ensure content is properly structured
    const contentData = content || {
      font: "dmsans",
      size: "12px",
      bold: false,
      italic: false,
      underline: false,
      strike: false,
      align: "left",
      list: false,
      bullet: false,
      clean: false,
      html: htmlContent, // Fallback to editor value
    };

    console.log("Final Content:", contentData);

    // Construct the payload
    const payload = {
      form_id: selectedValue,
      recipients,
      content: contentData,
    };

    console.log("Payload being sent:", JSON.stringify(payload, null, 2));

    try {
      const response = await axios.post(
        `${URL_SurveyBroadcastAPIV2}/dev/send-surveyV2`,
        payload
      );

      console.log("Response:", response);
      setEmails([]);
      messageApi.open({
        key,
        type: "success",
        content: "Email sent successfully!",
        duration: 2,
      });
    } catch (error) {
      console.error("Error sending survey:", error);
      messageApi.open({
        key,
        type: "error",
        content: "Something went wrong!",
        duration: 2,
      });
    }

    showModal();
    setModalLoading(false);
  };

  // const handleOk = async (values) => {
  //   setModalLoading(true);
  //   console.log("values received:", values);
 
  //   // Extract correct properties from values
  //   const { title, emails, content } = values;
 
  //   console.log("Title:", title);
  //   console.log("Emails:", emails);
  //   console.log("Content:", content);
 
  //   let recipients = [];
  //   if (Array.isArray(emails)) {
  //     // If emails is an array of objects
  //     recipients = emails.map(({ name, email }, index) => ({
  //       name: name || "", // Set to empty string if name is not provided
  //       email: email || "", // Ensure email is always present
  //     }));
  //   } else if (typeof emails === 'string') {
  //     // If emails is a comma-separated string
  //     const emailList = emails.split(',').map(email => email.trim());
  //     console.log("Email list after splitting:", emailList); // Add this log for debugging
 
  //     recipients = emailList.map((email, index) => ({
  //       name: "", // If no name is provided, we set it as an empty string
  //       email: email, // Ensure the email is included
  //     }));
  //   } else {
  //     // If emails is just a single email
  //     recipients = [{
  //       name: "", // Default empty name
  //       email: emails || "", // Ensure email is present
  //     }];
  //   }
 
  //   console.log("Recipients:", recipients);
 
  //   // Default editor content fallback
  //   let htmlContent = content?.html || editorValue || "";
 
  //   // Define the actual survey link
  //   const surveyLink = "userApplicationLink"; // Replace this with the actual dynamic link
 
  //   // Replace every occurrence of "Survey Link" with the correct anchor tag
  //   htmlContent = htmlContent.replace(
  //     /Survey Link/g,
  //     `<a href="${surveyLink}" target="_blank">Survey Link</a>`
  //   );
 
  //   // Ensure content is properly structured
  //   const contentData = content || {
  //     font: "dmsans",
  //     size: "10px",
  //     bold: true,
  //     italic: true,
  //     underline: true,
  //     strike: false,
  //     align: "left",
  //     list: false,
  //     bullet: false,
  //     clean: false,
  //     html: htmlContent, // Fallback to editor value
  //   };
 
  //   console.log("Final Content:", contentData);
 
  //   // Construct the payload
  //   const payload = {
  //     form_id: selectedValue,
  //     recipients,
  //     content: contentData,
  //   };
 
  //   console.log("Payload being sent:", JSON.stringify(payload, null, 2));
 
  //   try {
  //     const response = await axios.post(
  //       `${URL_SurveyBroadcastAPIV2}/dev/send-surveyV2`,
  //       payload
  //     );
 
  //     console.log("Response:", response);
  //     setEmails([]);
  //     messageApi.open({
  //       key,
  //       type: "success",
  //       content: "Email sent successfully!",
  //       duration: 2,
  //     });
  //   } catch (error) {
  //     console.error("Error sending survey:", error);
  //     messageApi.open({
  //       key,
  //       type: "error",
  //       content: "Something went wrong!",
  //       duration: 2,
  //     });
  //   }
 
  //   showModal();
  //   setModalLoading(false);
  // };
 

  const handleCancelForm = () => {
    setIsModalOpenForm(!isModalOpenForm);
  };

  const handleCancel = () => {
    setIsModalOpen(!isModalOpen);
  };
  // const handleSubmit = (e) => {
  //   e.preventDefault();

  //   // Add your email sending logic here, e.g., using a library like `react-emailjs`
  //   // console.log(`Sending email to: ${to}`);
  //   // console.log(`Subject: ${subject}`);
  //   // console.log(`Message: ${message}`);
  //   // axios
  //   //   .post(
  //   //     "https://puebem38qc.execute-api.ap-south-1.amazonaws.com/dev/send-survey",
  //   //     { title: subject, email: [to] }
  //   //   )
  //   //   .then((res) => {
  //   //     console.log(res);
  //   //   })
  //   //   .catch((err) => console.log(err));
  // };

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleInputConfirm = () => {
    if (
      inputValue &&
      validateEmail(inputValue) &&
      !emails.some(email => email.email === inputValue)
    ) {
     setEmails([...emails, { name: "", email: inputValue }]);
      setInputValue("");
      shareForm.setFieldsValue({
        emails: "",
        title: formTitle,
      });
    } else {
      messageApi.open({
        type: "error",
        content: "Invalid email",
        duration: 2,
      });
    }
  };

  const handleRemoveEmail = (removedEmail) => {
    setEmails(emails.filter((email) => email !== removedEmail));
  };

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleFileUploadForEmails = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const emailsFromFile = XLSX.utils
        .sheet_to_json(firstSheet, { header: 1 })
        .filter((row) => validateEmail(row[1])) // Assuming email is in the second column
        .map((row) => ({ name: row[0], email: row[1] })); // Assuming name is in the first column
        const newEmails = [...emails, ...emailsFromFile];
        setEmails(newEmails);
        shareForm.setFieldsValue({
          emails: newEmails,
        });
      };
    reader.readAsArrayBuffer(file);
    return false; // Prevent upload
  };

  async function fetchSurveyForm() {
    try {
      const response = await axios.get(
        `${URL_SurveyFormAdminAPIV2}/dev/survey-formV2?id=null`
      );
      console.log(
        "response data*********************************************",
        response.data
      );
      setSurveyData(response.data);
      return response.data;
    } catch (error) {
      console.error("Error fetching survey form:", error);
      throw error; // Re-throw the error to handle it appropriately in the calling component
    }
  }
  const [surveyData, setSurveyData] = useState([]);

  useEffect(() => {
    fetchSurveyForm();

    // .catch(error => setError(error));
  }, []);

  function fun(selectedValue) {
    console.log("Hello, you selected:", selectedValue);
  }

  async function getFormDataByID(item) {
    try {
      const url = `${URL_SurveyFormAdminAPIV2}/dev/survey-formV2?id=${item}`;
      axios
        .get(url) // Use params object for GET requests
        .then((response) => {
          console.log(response.data[0].title);
          setForms(response.data);
          setFormTitle(response.data[0].title);
          setShareDisable(true);
          shareForm.setFieldsValue({
            title: response.data[0].title,
          });
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    } catch (error) {
      console.error("Error fetching survey form:", error);
      throw error; // Re-throw the error to handle it appropriately in the calling component
    }
  }

  const normFile = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e?.fileList;
  };
  const handleDeleteClick = async (id) => {
    try {
      console.log("deleteFormField id:", id);
      // await deleteFormField(id);
      setForms(forms.filter((form) => form.id !== id));
      alert("Form deleted successfully!");
    } catch (error) {
      alert("Failed to delete form.");
    }
  };

  useEffect(() => {
    const loadForms = async () => {
      try {
        const item = localStorage.getItem("form-builder");
        setForms(item ? [JSON.parse(item)] : null);
      } catch (error) {}
    };

    // loadForms();
  }, []);

  const handleSearchInputChange = (e) => {
    setSearchInput(e.target.value);
  };
  const filteredSurveyData = surveyData.filter((item) =>
    item.title.toLowerCase().includes(searchInput.toLowerCase())
  );

  const renderFormField = (field) => {
    const commonStyles = {
      width: "100%",
      padding: "6px",
      margin: "6px 0",
      border: "1px solid #ccc",
      borderRadius: "4px",
      fontSize: "12px",
      color: "#495057",
    };

    switch (field.field_type) {
      case "text":
        return (
          <Form.Item label={field.label} name={field.label}>
            <Input
              placeholder={field.placeholder}
              style={{
                color: "#ffffff",
                backgroundColor: "#ffffff",
                borderColor: "#ffffff",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                cursor: "not-allowed",
                opacity: 1,
              }}
            />
          </Form.Item>
        );
      case "email":
        return (
          <Form.Item name={field.label} label={field.label}>
            <Input
              placeholder={field.placeholder}
              style={{
                color: "#ffffff",
                backgroundColor: "#ffffff",
                borderColor: "#ffffff",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                cursor: "not-allowed",
                opacity: 1,
              }}
            />
          </Form.Item>
        );
      case "number":
        return (
          <Form.Item label={field.label} name={field.label}>
            <InputNumber
              placeholder={field.placeholder}
              style={{
                width: "100%",
                color: "#ffffff",
                backgroundColor: "#ffffff",
                borderColor: "#ffffff",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                cursor: "not-allowed",
                opacity: 1,
              }}
            />
          </Form.Item>
        );
      case "password":
        return (
          <Form.Item label={field.label} name={field.label}>
            <Input.Password placeholder={field.placeholder} />
          </Form.Item>
        );
      case "checkbox":
        return (
          <Form.Item label={field.label}>
            <Checkbox.Group>
              {field.options.map((option, index) => (
                <Checkbox value={option}>{option}</Checkbox>
                // <Radio value={option}>{option} </Radio>
              ))}
            </Checkbox.Group>
          </Form.Item>
        );
      case "radio":
        return (
          <Form.Item label={field.label}>
            <Radio.Group>
              {field.options.map((option, index) => (
                <Radio value={option}>{option} </Radio>
              ))}
            </Radio.Group>
          </Form.Item>
        );
      case "dropdown":
        return (
          <Form.Item label={field.label} name={field.label}>
            <Select
              placeholder={field.placeholder}
              filterSort={(optionA, optionB) =>
                (optionA?.label ?? "")
                  .toLowerCase()
                  .localeCompare((optionB?.label ?? "").toLowerCase())
              }
              options={field.options.map((option) => ({
                value: option,
                label: option,
              }))}
              style={{
                color: "#333", // Dark text for better readability
                backgroundColor: "#ffffff", // White background
                borderColor: "#ddd", // Light border
                borderRadius: "8px", // Rounded corners
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", // Subtle shadow
                cursor: "not-allowed", // Not allowed cursor
                opacity: 1, // Full opacity
              }}
              dropdownStyle={{
                backgroundColor: "#ffffff", // White dropdown background
              }}
            />
          </Form.Item>
        );
      case "date":
        return (
          <Form.Item label={field.label} name={field.label}>
            <DatePicker />
          </Form.Item>
        );
      case "textarea":
        return (
          <Form.Item label={field.label}>
            <TextArea rows={4} placeholder={field.placeholder} />
          </Form.Item>
        );
      case "file":
        return (
          <Form.Item
            label={field.label}
            name={field.label}
            valuePropName="fileList"
            getValueFromEvent={normFile}
          >
            <Upload action="/upload.do" listType="picture-card" maxCount={1}>
              <button
                style={{
                  border: "2px solid rgb(205 187 238)", // Solid border in purple
                  backgroundColor: "#ffffff", // White background
                  borderRadius: "8px", // Rounded corners
                  padding: "20px", // Padding for better spacing
                  cursor: "pointer", // Pointer cursor for interactivity
                  transition: "background-color 0.3s, border-color 0.3s", // Smooth transition
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", // Subtle shadow for depth
                }}
                type="button"
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = "#f0f0f0"; // Light gray on hover
                  e.currentTarget.style.borderColor = "#5a34a1"; // Darken border on hover
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = "#ffffff"; // Reset background
                  e.currentTarget.style.borderColor = "rgb(55 23 255)"; // Reset border
                }}
              >
                <PlusOutlined
                  style={{ fontSize: "24px", color: "rgb(55 23 255)" }}
                />
                <div
                  style={{
                    marginTop: 5,
                    color: "rgb(55 23 255)",
                    fontWeight: "500",
                  }}
                >
                  Upload
                </div>
              </button>
            </Upload>
          </Form.Item>
        );
      case "button":
        return (
          <Form.Item
            wrapperCol={{
              offset: 0,
              span: 16,
            }}
          >
            <Button
              type="primary"
              htmlType="submit"
              style={{
                backgroundColor: "rgb(55 23 255)", // Purple background
                borderColor: "rgb(55 23 255)", // Purple border
                color: "#ffffff", // White text color
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)", // Optional shadow for depth
                textTransform: "capitalize",
              }}
            >
              {field.placeholder}
            </Button>
          </Form.Item>
        );
      default:
        return <div>Unknown Form Item</div>;
    }
  };

  // const generateEmbedCode = (slug) => {
  //   const embedUrl = `${API_URL}/api/V2/forms/${slug}`;
  //   return `<iframe src="${embedUrl}" width="100%" height="500px" frameborder="0"></iframe>`;
  // };

  const handleShareClick = (slug) => {
    console.log("slug:", slug);
    // const embedCode = generateEmbedCode(slug);
    // navigator.clipboard.writeText(embedCode);
    alert("Embed code copied to clipboard!");
  };

  const generateHtmlString = (formFields) => {
    return formFields
      .map((field) => {
        switch (field.field_type) {
          // {
          //   case "text":
          //   case "email":
          //   case "number":
          //   case "password":
          //     return `<input type="${field.field_type}" placeholder="${field.placeholder}" disabled />`;
          //   case "checkbox":
          //   case "radio":
          //     return `<label><input type="${field.field_type}" disabled /> ${field.label}</label>`;
          //   case "dropdown":
          //     return `<select disabled>${field.options
          //       .map((option) => `<option>${option}</option>`)
          //       .join("")}</select>`;
          //   case "date":
          //     return `<input type="date" disabled />`;
          //   case "textarea":
          //     return `<textarea placeholder="${field.placeholder}" disabled></textarea>`;
          //   case "file":
          //     return `<input type="file" disabled />`;
          //   default:
          //     return `<div>Unknown field type</div>`;
          // }
          case "text":
            return `<Form.Item label="${field.label}" name="${field.label}">
                <Input placeholder="${field.placeholder}" />
              </Form.Item>`;
          case "email":
            return `
              <Form.Item name="${field.label}" label="${field.label}">
                <Input placeholder="${field.placeholder}" />
              </Form.Item>`;
          case "number":
            return `
              <Form.Item label="${field.label}" name="${field.label}">
                <InputNumber
                  placeholder="${field.placeholder}"
                  style={{
                    width: "100%",
                  }}
                />
              </Form.Item>`;
          case "password":
            return `
              <Form.Item label="${field.label}" name="${field.label}">
                <Input.Password placeholder="${field.placeholder}" />
              </Form.Item>`;
          case "checkbox":
            return `
                <Form.Item label="${field.label}">
                    <Checkbox.Group>
                      ${field.options
                        .map(
                          (option, index) =>
                            `<Checkbox value=${option}>${option}</Checkbox>`
                        )
                        .join("")}
                    </Checkbox.Group>
                  </Form.Item>
          `;
          case "radio":
            return `
              <Form.Item label="${field.label}">
                <Radio.Group>
                  ${field.options
                    .map(
                      (option, index) =>
                        ` <Radio value=${option}>${option} </Radio>`
                    )
                    .join("")}
                </Radio.Group>
              </Form.Item>`;
          case "dropdown":
            return `
              <Form.Item label="${field.label}" name="${field.label}">
                <Select
                  placeholder="${field.placeholder}"
                  filterSort=${(optionA, optionB) =>
                    (optionA?.label ?? "")
                      .toLowerCase()
                      .localeCompare((optionB?.label ?? "").toLowerCase())
                      .join("")}
                  options=${field.options
                    .map((option, index) => ({
                      value: option,
                      label: option,
                    }))
                    .join("")}
                />
              </Form.Item>`;
          case "date":
            return `
              <Form.Item label="${field.label}" name="${field.label}">
                <DatePicker />
              </Form.Item>`;
          case "textarea":
            return `
              <Form.Item label="${field.label}">
                <TextArea rows={4} placeholder="${field.placeholder}" />
              </Form.Item>`;
          case "file":
            // return <input type="file" disabled={true} />;
            return `
              <Form.Item
                label="${field.label}"
                valuePropName="fileList"
                getValueFromEvent={normFile}
              >
                <Upload action="/upload.do" listType="picture-card" maxCount={1}>
                  <button
                    style={{
                      border: 0,
                      background: "none",
                    }}
                    type="button"
                  >
                    <PlusOutlined />
                    <div
                      style={{
                        marginTop: 5,
                      }}
                    >
                      Upload
                    </div>
                  </button>
                </Upload>
              </Form.Item>`;
          case "button":
            return `
                  <Form.Item
                    wrapperCol={{
                      offset: 0,  // Aligns the button to the left
                      span: 16,
                    }}
                  >
                    <Button
                      type="primary"
                      htmlType="submit"
                      style={{ textTransform: "capitalize" }}
                    >
                      ${capitalizeFirstLetter(field.placeholder)}
                    </Button>
                  </Form.Item>
                `;

          default:
            return <div>Unknown Form Item</div>;
        }
      })
      .join("");
  };

  const capitalizeFirstLetter = (str) => {
    // Check if the input is a string and not empty
    if (typeof str !== "string" || str.length === 0) return str;

    // Capitalize the first letter and concatenate it with the rest of the string
    return str.charAt(0).toUpperCase() + str.slice(1);
  };

  const handleCopyHtml = (formFields) => {
    let htmlString = generateHtmlString(formFields);
    const prefix = `<Form
    name="basic"
    layout="vertical"
    onFinish={onFinish}
    labelCol={{
          span: 2,
        }}
  >`;

    const suffix = `</Form>`;
    htmlString = prefix + htmlString + suffix;
    console.log("htmlString:", htmlString);
    navigator.clipboard.writeText(htmlString).then(() => {
      alert("HTML copied to clipboard!");
    });
  };

  const handleChange = (value) => {
    console.log("valuev", value);
    getFormDataByID(value);
    setSelectedValue(value);
    setSelectedForm(surveyData.find((item) => item.id === value)); // Set the selected form
  };
  //yha pe view form heading ki css hai

  const PageContainer = styled.div`
    display: flex;
    background-color: white;
    min-height: calc(100vh - 64px);
    padding: 24px;
  `;

  const MainContent = styled.div`
    flex-grow: 1;
    background: white;
    border-radius: 12px;
    border: 1px solid #e6e8f0;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  `;

  const HeaderSection = styled.div`
    padding: 24px;
    border-bottom: 1px solid #e6e8f0;
  `;

  const HeaderContent = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 24px;

    @media (max-width: 768px) {
      flex-direction: column;
      align-items: stretch;
    }
  `;

  const Title = styled.h3`
    font-size: 24px;
    font-weight: 600;
    color: #2b2e48;
    margin: 0;
  `;

  const ActionButtons = styled.div`
    display: flex;
    gap: 12px;

    @media (max-width: 768px) {
      justify-content: stretch;
    }
  `;

  const StyledButton = styled.button`
    padding: 12px 20px;
    background-color: ${(props) =>
      props.variant === "primary" ? "#2B2E48" : "#28a745"};
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 500;
    transition: opacity 0.2s;

    &:hover {
      opacity: 0.9;
    }

    &:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `;

  // const FormContainer = styled.div`
  //   padding: 24px;
  //   max-width: 600px;
  //   margin: 0 auto;
  // `;

  const FormField = styled.div`
    background-color: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    border: 1px solid #e9ecef;
  `;

  return (
    <>
      <BreadCrumbs location={props.location} />
      <div
        style={{
          display: "flex",
          // backgroundColor: "#f5f5f5", // A light background like Google Forms
          justifyContent: "center", // Center the form horizontally
          height: "92vh", // Full viewport height
          position: "fixed",
          width: "-webkit-fill-available",
          paddingBottom: "100px",
        }}
      >
        {contextHolder}
        <div
          style={{
            padding: "32px", // Extra padding for a spacious feel
            flexGrow: 1,
            maxWidth: "1160px", // Larger width for readability
            margin: "16px",
            // border: "1px solid #e0e0e0", // Lighter border color
            borderRadius: "12px", // Rounded corners for a modern look
            // backgroundColor: "#ffffff",
            // boxShadow: "0 6px 25px rgba(0, 0, 0, 0.1)", // Softer box-shadow for elegance
            overflow: "auto", // Enable scrolling inside this container
            maxHeight: "90vh", // Limit height for scrolling
          }}
        >
          {/* Share Form Modal */}
          <Modal
            title="Share Form"
            open={isModalOpen}
            onCancel={handleCancel}
            footer={null}
            width={650}
            style={{ fontFamily: "Calibri, sans-serif", fontSize: "10px" }}
          >
            <Spin
              indicator={antIcon}
              spinning={modalLoading}
              tip="Sending emails..."
            >
              <Form
                form={shareForm}
                name="basic"
                style={{ maxWidth: "100%" }}
                onFinish={handleOk}
              >
                <Form.Item
                  label={
                    <span
                      style={{
                        fontFamily: "Calibri, sans-serif",
                        fontSize: "12px",
                        fontWeight: "600",
                      }}
                    >
                      Form Title
                    </span>
                  }
                  name="title"
                  style={{
                    fontFamily: "Calibri, sans-serif",
                    fontSize: "12px",
                  }}
                >
                  <Input
                    style={{
                      fontFamily: "Calibri, sans-serif",
                      fontSize: "12px",
                    }}
                  />
                </Form.Item>

                <Form.Item
                  label={
                    <span
                      style={{
                        fontFamily: "Calibri, sans-serif",
                        fontSize: "12px",
                        fontWeight: "600",
                        color: "#ff4d4f",
                      }}
                    >
                      Email
                    </span>
                  }
                  name="emails"
                  rules={[
                    { required: true, message: "Please input your email!" },
                  ]}
                >
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <Input
                      type="text"
                      placeholder="Enter email and press Enter"
                      value={inputValue}
                      onChange={handleInputChange}
                      onPressEnter={handleInputConfirm}
                      style={{
                        width: "calc(100% - 100px)",
                        marginRight: "10px",
                        fontFamily: "Calibri, sans-serif",
                        fontSize: "12px",
                      }}
                    />
                    <Upload
                      beforeUpload={handleFileUploadForEmails}
                      showUploadList={false}
                    >
                      <Button
                        style={{
                          height: "26px",
                          backgroundColor: "#f1f3f4",
                          color: "#5f6368",
                          border: "1px solid #ccc",
                          borderRadius: "4px",
                          cursor: "pointer",
                        }}
                      >
                        Upload File
                      </Button>
                    </Upload>
                  </div>
                </Form.Item>

                {emails.map((recipient) => (
                  <Tag
                    key={recipient.email}
                    closable
                    onClose={() => handleRemoveEmail(recipient.email)}
                    style={{
                      height: "25px",
                      margin: "0 0 5px 0",
                      backgroundColor: "#f1f3f4",
                      color: "#5f6368",
                    }}
                  >
                    {recipient.email}
                  </Tag>
                ))}

                <div style={{ marginTop: "20px" }}>
                  <ReactQuill
                    value={editorValue}
                    onChange={setEditorValue}
                    modules={{
                      toolbar: [
                        [{ font: [] }],
                        [{ size: [] }],
                        ["bold", "italic", "underline", "strike"],
                        [{ align: [] }],
                        [{ list: "ordered" }, { list: "bullet" }],
                        ["clean"],
                      ],
                    }}
                    formats={[
                      "header",
                      "font",
                      "size",
                      "bold",
                      "italic",
                      "underline",
                      "strike",
                      "align",
                      "list",
                      "bullet",
                      "clean",
                    ]}
                    style={{
                      minHeight: "150px",
                      marginBottom: "10px",
                      fontFamily: "Calibri, sans-serif", // Set Calibri font for editor content
                    }}
                  />
                  <style>
                    {`
      .ql-container {
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px; /* Adjust padding for overall container */
        max-height: 200px; /* Set a max height for scrolling */
        overflow-y: auto; /* Enable vertical scrolling */
        position: relative; /* Position relative for absolute positioning */
      }
      .ql-editor {
        font-family: 'Calibri', sans-serif; /* Ensure editor content uses Calibri */
        padding: 0; /* Remove padding to allow cursor at the top */
        min-height: 150px; /* Maintain minimum height */
      }
      .ql-editor.ql-blank::before {
        font-family: 'Calibri', sans-serif; /* Ensure placeholder uses Calibri */
        font-style: normal; /* Remove italic style */
        color: #999; /* Placeholder color */
        content: 'Hello {name}\\A\\AThis is GeneralSurvey Form\\ASurvey Link\\A\\AThanks\\AHR Team!'; /* Custom placeholder text */
        white-space: pre-line; /* Preserve line breaks */
        position: absolute; /* Position it absolutely */
        top: 10px; /* Position at the top */
        left: 10px; /* Align with padding */
        pointer-events: none; /* Allow clicks to go through to the editor */
      }
    `}
                  </style>
                </div>

                {/* Action Buttons (Share and Cancel) */}
                <div
                  style={{ display: "flex", justifyContent: "space-between" }}
                >
                  <Button
                    key="back"
                    onClick={handleCancel}
                    style={{
                      width: "19%",
                      height: "40px",
                      fontSize: "12px",
                      backgroundColor: "#f1f3f4",
                      borderRadius: "5px",
                    }}
                  >
                    Cancel
                  </Button>

                  <Button
                    key="submit"
                    type="primary"
                    htmlType="submit"
                    style={{
                      width: "16%",
                      height: "40px",
                      fontSize: "12px",
                      backgroundColor: "rgb(232 128 23 / 56%)",
                      color: "white",
                      border: "none",
                      borderRadius: "30px",
                      cursor: "pointer",
                    }}
                  >
                    <FontAwesomeIcon
                      icon={faShare}
                      style={{ marginRight: "8px" }}
                    />
                    Share
                  </Button>
                </div>
              </Form>
            </Spin>
          </Modal>

          <Input
            placeholder="Search by form name"
            value={searchInput}
            onChange={handleSearchInputChange}
            style={{ marginBottom: "20px", width: "300px" }}
            suffix={<SearchOutlined />}
          />

          {filteredSurveyData.length > 0 ? (
            <table
              style={{
                width: "100%",
                marginTop: "10px",
                borderCollapse: "collapse",
              }}
            >
              <thead>
                <tr
                  style={{
                    backgroundColor: "#ffffff",
                    color: "black",
                    fontWeight: "600",
                    textAlign: "centre",
                  }}
                >
                  <th style={{ padding: "10px", border: "1px solid #e0e0e0" }}>
                    Title
                  </th>
                  <th style={{ padding: "10px", border: "1px solid #e0e0e0" }}>
                    Created At
                  </th>
                  <th style={{ padding: "10px", border: "1px solid #e0e0e0" }}>
                    Last Submitted
                  </th>
                  <th style={{ padding: "10px", border: "1px solid #e0e0e0" }}>
                    View
                  </th>
                  <th style={{ padding: "10px", border: "1px solid #e0e0e0" }}>
                    Share
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredSurveyData.map((item) => (
                  <tr key={item.id}>
                    <td
                      style={{
                        padding: "10px",
                        border: "1px solid #e0e0e0",
                        color: "#5f6368",
                      }}
                    >
                      {item.title}
                    </td>
                    <td
                      style={{
                        padding: "10px",
                        border: "1px solid #e0e0e0",
                        color: "#5f6368",
                      }}
                    >
                      {item.createdAt}
                    </td>
                    <td
                      style={{
                        padding: "10px",
                        border: "1px solid #e0e0e0",
                        color: "#5f6368",
                      }}
                    >
                      {item.lastSubmitted}
                    </td>
                    <td
                      style={{
                        padding: "10px",
                        border: "1px solid #e0e0e0",
                        color: "#5f6368",
                      }}
                    >
                      <Button
                        onClick={() => {
                          handleChange(item.id);
                          showModalForm();
                        }}
                      >
                        View
                      </Button>
                    </td>
                    <td
                      style={{
                        padding: "10px",
                        border: "1px solid #e0e0e0",
                        color: "#5f6368",
                      }}
                    >
                      <Button
                        onClick={() => {
                          handleChange(item.id);
                          handleViewClick(item.title);
                        }}
                      >
                        Share
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p>No results found.</p> // Display a message if no results match the search
          )}
          <hr style={{ borderTop: "1px solid #e0e0e0" }} />

          <Modal
            // title="Share Form"
            open={isModalOpenForm}
            onCancel={handleCancelForm}
            footer={null}
            style={{
              fontFamily: "Roboto, sans-serif",
            }}
          >
            <Form
              layout="vertical"
              disabled={true}
              style={{
                // width: "100%",
                margin: "20px auto",
                backgroundColor: "#ffffff",
                borderRadius: "16px", // More rounded edges
                boxShadow: "0 6px 20px rgba(0, 0, 0, 0.12)", // Soft shadow
                overflowY: "auto",
                height: "60vh",
              }}
            >
              {forms?.map((form) => (
                <div key={form.id} style={{ marginBottom: "30px" }}>
                  <div
                    style={{
                      padding: "6px",
                      backgroundColor: "#5046e5d9",
                      textAlign: "center",
                      borderRadius: "5px",
                      color: "#ffffff",
                      fontWeight: "600",
                      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)", // Shadow effect
                    }}
                  >
                    {form.title}
                  </div>
                  <div style={{ padding: "20px" }}>
                    {form.form_schema.map((field) => (
                      <div key={field.id} style={{ marginBottom: "20px" }}>
                        <label
                          style={{
                            display: "block",
                            marginBottom: "8px",
                            color: "#5f6368", // Dark text for labels
                            fontWeight: "600",
                            fontSize: "8px",
                          }}
                        >
                          {/* {field.label}  */}
                        </label>
                        {renderFormField(field, {
                          placeholderStyle: { color: "black" },
                        })}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </Form>
          </Modal>
        </div>
      </div>
    </>
  );
};

export default ViewForms;