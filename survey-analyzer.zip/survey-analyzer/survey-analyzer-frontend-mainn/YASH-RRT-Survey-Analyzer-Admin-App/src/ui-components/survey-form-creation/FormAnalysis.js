import React, { useState, useEffect } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import {
  Card,
  Table,
  Row,
  Col,
  Statistic,
  Spin,
  Tag,
  Button,
  DatePicker,
  Modal,
} from "antd";
import { Eye, Search, AlertCircle, Settings } from "lucide-react";
import BreadCrumbs from "../BreadCrumbs";
import TextSummary from "./TextSummary";
import {
  URL_SurveyBroadcastAPIV2,
  URL_SurveyFormAdminAPIV2,
} from "../../util/constants";
import WordCloudAnalysisModal from "./WordCloudAnalysis";

const FormAnalysis = () => {
  const { formId: paramFormId } = useParams(); 
  const navigate = useNavigate();
  const location = useLocation();
  const formId = location.state?.formId || paramFormId; 
  const formData = location.state?.formData || {};
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [formTitle, setFormTitle] = useState(formData?.title || "");
  const [formAnalysisData, setFormAnalysisData] = useState(null);
  const [emailList, setEmailList] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [isSummaryModalVisible, setIsSummaryModalVisible] = useState(false);
  const [currentSummaryText, setCurrentSummaryText] = useState("");
  const [isWordCloudVisible, setIsWordCloudVisible] = useState(false);

  useEffect(() => {
    if (!formId) {
      setError("Form ID is missing!");
      return;
    }

    console.log("Form ID:", formId);
    fetchFormDetails();
  }, [formId]);

  const fetchFormDetails = async () => {
    if (!formId) return;

    setLoading(true);
    setError("");

    try {
      // Fetch form users
      const usersResponse = await axios.get(
        `${URL_SurveyFormAdminAPIV2}/dev/form-usersV2?form_id=${formId}`
      );
      console.log("Users Response:", usersResponse.data); // Debugging
      setEmailList(usersResponse.data);

      // Fetch form analysis data
      const analysisConfig = {
        method: "post",
        url: `${URL_SurveyBroadcastAPIV2}/dev/survey-responseV2/get-response-rateV2`,
        data: { formId },
      };

      const analysisResponse = await axios.request(analysisConfig);
      console.log("Analysis Response:", analysisResponse.data); // Debugging
      setFormAnalysisData(analysisResponse.data.body);

      // Fetch survey analysis
      const surveyAnalysisResponse = await axios.get(
        `${URL_SurveyBroadcastAPIV2}/dev/survey-analysisV2`
      );
      console.log("Survey Analysis Response:", surveyAnalysisResponse.data); // Debugging

      const surveyData = surveyAnalysisResponse?.data?.body;
      getTableData(surveyData, usersResponse.data);
    } catch (error) {
      console.error("Error fetching survey details:", error);
      setError(
        "Failed to fetch survey details: " +
          (error?.response?.data || error.message)
      );
    } finally {
      setLoading(false);
    }
  };

  function getTableData(formAllData, emails) {
    console.log("Form All Data:", formAllData);
    console.log("Emails:", emails);

    let data = [];

    emails?.map((email, index) => {
      let formResponse = formAllData?.find((forms) => forms.id === email.id);
      if (!formResponse) return;

      let object = {};
      object.no = index + 1;
      object.key = email.id;
      object.respondent = email.shared_with;

      object.status =
        formResponse?.status === "pending" ? "INCOMPLETE" : "COMPLETED";
      object.submission = formResponse.formattedDuration;
      object.isSummaryGenerated = !!formResponse.summary;
      object.summary = formResponse.summary || "";

      if (formResponse.image_kpi) {
        let sentiments = [];
        formResponse.image_kpi.map((data) => {
          sentiments.push(data.overall_sentiment);
        });
        object.image = sentiments;
      }
      if (formResponse.video_kpi) {
        let sentiments = [];
        formResponse.video_kpi.map((data) => {
          sentiments.push(data.overall_sentiment);
        });
        object.video = sentiments;
      }
      if (formResponse.audio_kpi) {
        let sentiments = [];
        formResponse.audio_kpi.map((data) => {
          sentiments.push(data.overall_sentiment);
        });
        object.audio = sentiments;
      }

      data.push(object);
    });

    console.log("Table Data:", data); // Debugging
    setTableData(data);
  }

  const handleGenerateSummary = async (key) => {
    console.log(`Generating summary for record with key: ${key}`);
    setLoading(true);
    setCurrentSummaryText(""); // Clear previous summary text

    try {
      const response = await axios.post(
        "https://a9aikwz2rg.execute-api.us-east-2.amazonaws.com/dev/form-summary",
        { id: key } // Payload with the key as id
      );

      const data = response.data;
      const parsedBody = JSON.parse(data.body); // Parse the stringified JSON in the body
      const summary = parsedBody.summary || "No summary found."; // Extract the summary

      setCurrentSummaryText(summary); // Set the summary text
      setIsSummaryModalVisible(true); // Show the modal

      // Update the table data to include the generated summary
      setTableData((prevData) =>
        prevData.map((item) =>
          item.key === key
            ? { ...item, isSummaryGenerated: true, summary } // Update the summary
            : item
        )
      );
    } catch (error) {
      console.error("Error fetching summary:", error);
      setCurrentSummaryText("Error fetching summary."); // Show error message
      setIsSummaryModalVisible(true); // Show the modal even on error
    } finally {
      setLoading(false); // Hide loading spinner
    }
  };

  const handleCloseSummaryModal = () => {
    setIsSummaryModalVisible(false);
    setCurrentSummaryText("");
  };

  const columns = [
    {
      title: "S No.",
      dataIndex: "no",
      key: "no",
      onHeaderCell: () => ({
        style: {
          fontWeight: "bold",
          color: "black",
          border: "1px solid lightgrey",
          borderBottom: "2px solid lightgrey",
        },
      }),
    },
    {
      title: (
        <span style={{ color: "black", fontWeight: "bold", fontSize: "10px" }}>
          Respondent
        </span>
      ),
      dataIndex: "respondent",
      key: "respondent",
      width: "20%",
      onHeaderCell: () => ({
        style: {
          fontWeight: "bold",
          color: "black",
          border: "1px solid lightgrey",
          borderBottom: "2px solid lightgrey",
          fontSize: "0.8rem",
        },
      }),
      render: (text) => <span style={{ fontSize: "10px" }}>{text}</span>,
    },
    {
      title: (
        <span
          style={{ color: "black", fontWeight: "bold", fontSize: "0.8rem" }}
        >
          Status
        </span>
      ),
      dataIndex: "status",
      key: "status",
      onHeaderCell: () => ({
        style: {
          fontWeight: "bold",
          color: "black",
          border: "1px solid lightgrey",
          borderBottom: "2px solid lightgrey",
          fontSize: "0.8rem",
        },
      }),
      render: (text) => (
        <span
          style={{
            color: text === "Completed" ? "green" : "green",
            fontSize: "10px",
          }}
        >
          {text}
        </span>
      ),
    },
    {
      title: (
        <span
          style={{ color: "black", fontWeight: "bold", fontSize: "0.8rem" }}
        >
          Submission Time
        </span>
      ),
      dataIndex: "submission",
      key: "submission",
      onHeaderCell: () => ({
        style: {
          fontWeight: "bold",
          color: "black",
          border: "1px solid lightgrey",
          borderBottom: "2px solid lightgrey",
          fontSize: "0.8rem",
        },
      }),
      render: (text) => <span style={{ fontSize: "10px" }}>{text}</span>,
    },
    {
      title: (
        <span
          style={{ color: "black", fontWeight: "bold", fontSize: "0.8rem" }}
        >
          Sentiments
        </span>
      ),
      onHeaderCell: () => ({
        style: {
          fontWeight: "bold",
          color: "black",
          border: "1px solid lightgrey",
          borderBottom: "2px solid lightgrey",
          fontSize: "0.8rem",
        },
      }),
      children: [
        {
          title: (
            <span
              style={{ color: "black", fontWeight: "bold", fontSize: "0.8rem" }}
            >
              Audio
            </span>
          ),
          dataIndex: "audio",
          key: "audio",
          onHeaderCell: () => ({
            style: {
              fontWeight: "bold",
              color: "black",
              border: "1px solid lightgrey",
              borderBottom: "2px solid lightgrey",
              fontSize: "0.8rem",
            },
          }),
          render: (text) => (
            <>
              {text
                ? text.map((tag) => (
                    <Tag
                      color={
                        tag === "positive"
                          ? "green"
                          : tag === "neutral"
                          ? "yellow"
                          : "red"
                      }
                      key={tag}
                      style={{
                        margin: "4px",
                        borderRadius: "8px",
                        fontSize: "10px",
                      }}
                    >
                      {tag.toUpperCase()}
                    </Tag>
                  ))
                : "N/A"}
            </>
          ),
        },
        {
          title: (
            <span
              style={{ color: "black", fontWeight: "bold", fontSize: "0.8rem" }}
            >
              Image
            </span>
          ),
          dataIndex: "image",
          key: "image",
          onHeaderCell: () => ({
            style: {
              fontWeight: "bold",
              color: "black",
              border: "1px solid lightgrey",
              borderBottom: "2px solid lightgrey",
              fontSize: "0.8rem",
            },
          }),
          render: (text) => (
            <>
              {text
                ? text.map((tag) => (
                    <Tag
                      color={
                        tag === "positive"
                          ? "green"
                          : tag === "neutral"
                          ? "yellow"
                          : "red"
                      }
                      key={tag}
                      style={{
                        margin: "4px",
                        borderRadius: "8px",
                        fontSize: "10px",
                      }}
                    >
                      {tag.toUpperCase()}
                    </Tag>
                  ))
                : "N/A"}
            </>
          ),
        },
        {
          title: (
            <span
              style={{ color: "black", fontWeight: "bold", fontSize: "0.8rem" }}
            >
              Video
            </span>
          ),
          dataIndex: "video",
          key: "video",
          onHeaderCell: () => ({
            style: {
              fontWeight: "bold",
              color: "black",
              border: "1px solid lightgrey",
              borderBottom: "2px solid lightgrey",
              fontSize: "0.8rem",
            },
          }),
          render: (text) => (
            <>
              {text
                ? text.map((tag) => (
                    <Tag
                      color={
                        tag === "positive"
                          ? "green"
                          : tag === "neutral"
                          ? "yellow"
                          : "red"
                      }
                      key={tag}
                      style={{
                        margin: "4px",
                        borderRadius: "8px",
                        fontSize: "10px",
                      }}
                    >
                      {tag.toUpperCase()}
                    </Tag>
                  ))
                : "N/A"}
            </>
          ),
        },
      ],
    },
    {
      title: (
        <span style={{ color: "black", fontWeight: "bold" }}>
          View Analysis
        </span>
      ),
      dataIndex: "view",
      key: "view",
      onHeaderCell: () => ({
        style: {
          fontWeight: "bold",
          color: "black",
          border: "1px solid lightgrey",
          borderBottom: "2px solid lightgrey",
          fontSize: "0.8rem",
        },
      }),
      render: (_, record) => {
        // Check if audio, video, or image data exists
        const hasAnalysisData =
          record.audio?.length > 0 || record.video?.length > 0 || record.image?.length > 0;
    
        return hasAnalysisData ? (
          <a
            onClick={() =>
              navigate("/survey-lens/form-analysis/view-analyser", {
                state: {
                  email: record.key,
                  submitedBy: record.respondent,
                  formId,
                },
              })
            }
            style={{
              color: "#1890ff",
              textDecoration: "underline",
              cursor: "pointer",
              fontSize: "10px",
            }}
          >
            Click to view analysis
          </a>
        ) :(
          <span style={{ fontSize: "14px", color: "black" }}>N/A</span> 
        ); 
      },
    },
    {
      title: (
        <span
          style={{ color: "black", fontWeight: "bold", fontSize: "0.8rem" }}
        >
          User Response
        </span>
      ),
      dataIndex: "view",
      key: "view",
      onHeaderCell: () => ({
        style: {
          fontWeight: "bold",
          color: "black",
          border: "1px solid lightgrey",
          borderBottom: "2px solid lightgrey",
        },
      }),
      render: (_, record) => (
        <>
          <a
            onClick={() =>
              navigate("/survey-lens/form-analysis/view-response", {
                state: { email: record.key, submitedBy: record.respondent },
              })
            }
            style={{
              color: "#1890ff",
              textDecoration: "underline",
              cursor: "pointer",
              fontSize: "10px",
            }}
          >
            Click to view Response
          </a>
        </>
      ),
    },
    {
      title: (
        <span
          style={{ color: "black", fontWeight: "bold", fontSize: "0.8rem" }}
        >
          Summary
        </span>
      ),
      dataIndex: "summary",
      key: "summary",
      onHeaderCell: () => ({
        style: {
          fontWeight: "bold",
          color: "black",
          border: "1px solid lightgrey",
          borderBottom: "2px solid lightgrey",
          fontSize: "0.8rem",
        },
      }),
      render: (text, record) => (
        <div style={{ textAlign: "center" }}>
          {record.isSummaryGenerated ? (
            <span
              style={{
                cursor: "pointer",
                color: "#1890ff",
                fontSize: "16px",
              }}
              title="View Summary"
              onClick={() => {
                setCurrentSummaryText(record.summary);
                setIsSummaryModalVisible(true);
              }}
            >
              <Eye />
            </span>
          ) : (
            <span
              style={{
                cursor: "pointer",
                color: "#ff9800",
                fontSize: "16px",
              }}
              title="Generate Summary"
              onClick={() => handleGenerateSummary(record.key)}
            >
              <Settings />
            </span>
          )}
        </div>
      ),
    },
  ];

  const cardStyle = {
    borderRadius: "12px",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.05)",
    border: "1px solid #e1e4e8",
    marginBottom: "10px",
    marginTop: "10px",
  };

  const statisticStyle = {
    fontSize: "0.8rem",
    fontWeight: "600",
    color: "#2b2e4a",
  };

  const containerStyle = {
    padding: "2rem",
    backgroundColor: "#f5f7fa",
    minHeight: "100vh",
  };
  const showDetailedAnalysis = () => {
    setIsWordCloudVisible(true);
};

const handleOk = () => {
    setIsModalVisible(false);
};

const handleCancel = () => {
    setIsModalVisible(false);
};

const showWordCloudModal = () => {
    setIsWordCloudVisible(true);
};

  return (
    <div
      style={{
        height: "100vh",
        overflow: "auto",
        backgroundColor: "#f5f7fa",
        padding: "20px",
      }}
    >
      <Card
        style={{
          borderRadius: "12px",
          boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
          padding: "20px",
          backgroundColor: "#ffffff",
        }}
      >
        <BreadCrumbs location={location} />

        <button
          onClick={() => navigate("/survey-lens")}
          style={{
            marginBottom: "1rem",
            padding: "8px 14px",
            backgroundColor: "#0958d9",
            color: "#ffffff",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          Back to Forms
        </button>

        {loading && (
          <div
            style={{
              textAlign: "center",
              padding: "1.4rem",
              backgroundColor: "white",
              borderRadius: "8px",
              marginBottom: "1.4rem",
              boxShadow: "0 3px 6px rgba(0, 0, 0, 0.1)",
            }}
          >
            <Spin size="large" />
            <div
              style={{
                color: "#2C3E50",
                fontWeight: "300",
                marginTop: "1rem",
              }}
            >
              Loading...
            </div>
          </div>
        )}

        {error && (
          <div
            style={{
              padding: "16px",
              backgroundColor: "#FDEBD0",
              border: "1px solid #F5B041",
              borderRadius: "8px",
              color: "#C0392B",
              marginBottom: "2rem",
              boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
            }}
          >
            {error}
          </div>
        )}

        {formAnalysisData && !loading && !error && (
          <>
            <Card
              title="Overall Form Analysis"
              style={{
                borderRadius: "10px",
                boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)",
                backgroundColor: "#ffffff",
                marginBottom: "1rem",
              }}
            >
              <Row gutter={[24, 24]}>
                <Col xs={24} sm={12} md={6}>
                  <Statistic
                    title="Form Title"
                    value={formTitle}
                    valueStyle={{ fontSize: "0.8rem", fontWeight: "600" }}
                  />
                </Col>
                <Col xs={24} sm={12} md={6}>
                  <Statistic
                    title="Total Responses"
                    value={formAnalysisData.totalResponses}
                    valueStyle={{ fontSize: "0.8rem", fontWeight: "600" }}
                  />
                </Col>
                <Col xs={24} sm={12} md={6}>
                  <Statistic
                    title="Response Rate"
                    value={formAnalysisData.responseRate}
                    valueStyle={{ fontSize: "0.8rem", fontWeight: "600" }}
                  />
                </Col>
                <Col xs={24} sm={12} md={6}>
                <Button type="primary" onClick={showDetailedAnalysis}
                style={{
                  width: "auto", 
                  maxWidth: "200px", 
                  fontSize: "14px", 
                  padding: "10px 16px",
                  borderRadius: "8px",
                  textAlign: "center",
                  margin: "0 auto", 
                  whiteSpace: "normal", 
                  wordWrap: "break-word", 
                }}
              >
                Open Detailed Analysis
            </Button>
            {/* <Modal
                // title="Detailed Analysis"
                visible={isModalVisible}
                onOk={handleOk}
                onCancel={handleCancel}
                footer={null} // Customize footer if needed
            > */}
                {/* <p>Your detailed analysis content goes here.</p>
                <Button type="primary" onClick={showWordCloudModal}>
                    View Word Cloud Analysis
                </Button> */}

                <WordCloudAnalysisModal
                    isVisible={isWordCloudVisible}
                    onClose={() => setIsWordCloudVisible(false)}
                    formId={formId}
                />
            {/* </Modal> */}
                </Col>
              </Row>
            </Card>

            <Card
              style={{
                borderRadius: "10px",
                boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)",
                backgroundColor: "#ffffff",
              }}
            >
              <Table
                columns={columns}
                dataSource={tableData}
                pagination={{
                  pageSize: 10,
                  position: ["bottomCenter"],
                }}
                scroll={{ x: true }}
              />
            </Card>
          </>
        )}

        {!formAnalysisData && !loading && !error && (
          <div
            style={{
              padding: "20px",
              textAlign: "center",
              backgroundColor: "#f8f9fa",
              borderRadius: "8px",
              margin: "2rem 0",
            }}
          >
            <AlertCircle size={48} color="#718096" />
            <h3>No data available</h3>
            <p>There's no analysis data available for this survey yet.</p>
          </div>
        )}

        <TextSummary
          isVisible={isSummaryModalVisible}
          onClose={handleCloseSummaryModal}
          summaryText={
            typeof currentSummaryText === "string"
              ? currentSummaryText
              : JSON.stringify(currentSummaryText)
          }
        />
      </Card>
    </div>
  );
};

export default FormAnalysis;
