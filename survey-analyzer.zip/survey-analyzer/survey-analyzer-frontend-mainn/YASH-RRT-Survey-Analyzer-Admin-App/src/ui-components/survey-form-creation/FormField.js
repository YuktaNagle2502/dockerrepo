import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash, faEdit, faSave } from "@fortawesome/free-solid-svg-icons";
import {
  Button,
  Checkbox,
  DatePicker,
  Form,
  Input,
  InputNumber,
  Radio,
  Select,
  Upload,
} from "antd";
import TextArea from "antd/es/input/TextArea";
import { PlusOutlined } from "@ant-design/icons";

const FormField = ({
  field,
  previewMode,
  onDelete,
  onUpdateLabel,
  onUpdatePlaceholder,
  onUpdateOptions,
  onUpdateWordCloud,
}) => {
  const [newOption, setNewOption] = useState("");
  const [editingOptionIndex, setEditingOptionIndex] = useState(null);
  const [editingOptionValue, setEditingOptionValue] = useState("");
  const [showDetails, setShowDetails] = useState(false);

  const handleAddOption = () => {
    if (newOption.trim()) {
      onUpdateOptions([...field.options, newOption]);
      setNewOption("");
    }
  };

  const normFile = (e) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e?.fileList;
  };

  const handleEditOption = (index) => {
    setEditingOptionIndex(index);
    setEditingOptionValue(field.options[index]);
  };

  const handleSaveEditedOption = () => {
    const updatedOptions = [...field.options];
    updatedOptions[editingOptionIndex] = editingOptionValue;
    onUpdateOptions(updatedOptions);
    setEditingOptionIndex(null);
    setEditingOptionValue("");
  };

  const inputStyle = {
    height: "26px",
    fontSize: "0.8rem",
    padding: "2px 8px",
    lineHeight: "1.2",
  };

  const renderInput = () => {
    switch (field.field_type) {
      case "text":
        return <Input placeholder={field.placeholder} style={inputStyle} />;
      case "email":
        return <Input placeholder={field.placeholder} style={inputStyle} />;
      case "number":
        return (
          <InputNumber
            placeholder={field.placeholder}
            style={{
              ...inputStyle,
              width: "100%",
            }}
          />
        );
      case "password":
        return (
          <Input.Password placeholder={field.placeholder} style={inputStyle} />
        );
      case "checkbox":
        return (
          <Checkbox.Group style={{ fontSize: "0.8rem" }}>
            {field.options.map((option, index) => (
              <Checkbox value={option} key={index}>
                {option}
              </Checkbox>
            ))}
          </Checkbox.Group>
        );
      case "radio":
        return (
          <Radio.Group style={{ fontSize: "0.8rem" }}>
            {field.options.map((option, index) => (
              <Radio value={option} key={index} style={{ fontSize: "0.8rem" }}>
                {option}
              </Radio>
            ))}
          </Radio.Group>
        );
      case "dropdown":
        return (
          <Select
            placeholder={field.placeholder}
            filterSort={(optionA, optionB) =>
              (optionA?.label ?? "")
                .toLowerCase()
                .localeCompare((optionB?.label ?? "").toLowerCase())
            }
            options={field.options.map((option) => ({
              value: option,
              label: option,
            }))}
            style={{ ...inputStyle, width: "100%" }}
            dropdownStyle={{ fontSize: "0.8rem" }}
          />
        );
      case "date":
        return <DatePicker style={inputStyle} />;
      case "textarea":
        return (
          <TextArea
            rows={2}
            placeholder={field.placeholder}
            style={{ fontSize: "0.8rem", padding: "4px 8px" }}
          />
        );
      case "file":
        return (
          <Upload action="/upload.do" listType="picture-card" maxCount={1}>
            <button
              style={{
                border: 0,
                background: "none",
                fontSize: "0.7rem",
                padding: "4px",
              }}
              type="button"
            >
              <PlusOutlined style={{ fontSize: "0.8rem" }} />
              <div style={{ marginTop: 2 }}>Upload</div>
            </button>
          </Upload>
        );
      case "button":
        return (
          <Button
            type="primary"
            htmlType="submit"
            style={{
              marginLeft: "0%",
              backgroundColor: "#6882ff",
              textTransform: "capitalize",
              padding: "1px 10px",
              fontSize: "11px",
              height: "24px",
              minWidth: "56px",
              lineHeight: "1.3",
            }}
          >
            {field.placeholder}
          </Button>
        );
      default:
        return <div>Unknown Form Item</div>;
    }
  };

  const containerStyle = {
    marginTop: "8px",
    marginBottom: "18px",
    borderRadius: "10px",
    backgroundColor: "white",
    boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
    transition: "all 0.25s ease",
    border: "1px solid rgba(233, 236, 239, 0.8)",
    overflow: "hidden",
    position: "relative",
    padding: "12px",
  };

  return (
    <div
      style={containerStyle}
      onMouseEnter={(e) => {
        if (!previewMode) {
          e.currentTarget.style.boxShadow = "0 8px 16px rgba(0,0,0,0.12)";
          e.currentTarget.style.transform = "translateY(-2px)";
          e.currentTarget.style.borderColor = "rgba(80, 70, 229, 0.3)";
        }
      }}
      onMouseLeave={(e) => {
        if (!previewMode) {
          e.currentTarget.style.boxShadow = "0 2px 8px rgba(0,0,0,0.08)";
          e.currentTarget.style.transform = "translateY(0)";
          e.currentTarget.style.borderColor = "rgba(233, 236, 239, 0.8)";
        }
      }}
    >
      <div
        className="form-field-header"
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "10px",
        }}
      >
        <Form.Item
          label={field.label}
          name={field.label}
          style={{
            margin: 0,
            flex: 1,
            color: "#dc3545",
            fontSize: "9px",
          }}
          labelCol={{
            style: {
              fontSize: "10px",
              padding: "0 0 2px 0",
              height: "18px",
              lineHeight: "18px",
            },
          }}
        >
          {renderInput()}
        </Form.Item>

        {!previewMode && (
          <div className="form-field-actions" style={{ marginLeft: "12px" }}>
            {(field.field_type === "text" ||
              field.field_type === "textarea") && (
              <Checkbox
                style={{ marginRight: "6px" }}
                checked={field.wordCloud || false}
                onChange={(e) => {
                  const isChecked = e.target.checked;
                  onUpdateWordCloud(field.id, isChecked); 
                }}
                onMouseEnter={(e) => {
                  e.target.title = "Check this box to create a Word Cloud";
                }}
              ></Checkbox>
            )}
            <button
              onClick={() => setShowDetails(!showDetails)}
              style={{
                marginRight: "6px",
                background: "none",
                border: "none",
                cursor: "pointer",
                padding: "4px",
              }}
            >
              <FontAwesomeIcon
                icon={faEdit}
                style={{ color: "rgb(80, 70, 229)", fontSize: "0.8rem" }}
              />
            </button>
            <button
              onClick={onDelete}
              style={{
                background: "none",
                border: "none",
                cursor: "pointer",
                padding: "4px",
              }}
            >
              <FontAwesomeIcon
                icon={faTrash}
                style={{ color: "#dc3545", fontSize: "0.8rem" }}
              />
            </button>
          </div>
        )}
      </div>

      {!previewMode && showDetails && (
        <div
          className="form-field-details"
          style={{
            marginTop: "12px",
            position: "sticky",
            top: "0",
            backgroundColor: "#f9fafc",
            zIndex: 1,
            padding: "12px",
            borderRadius: "6px",
            boxShadow: "0 2px 6px rgba(0,0,0,0.08)",
            fontSize: "0.8rem",
          }}
        >
          <label
            style={{
              fontWeight: "500",
              marginBottom: "3px",
              fontSize: "9px",
              display: "block",
            }}
          >
            Label
          </label>
          <Input
            type="text"
            value={field.label}
            onChange={(e) => onUpdateLabel(e.target.value)}
            placeholder="Label"
            style={{
              marginBottom: "6px",
              width: "100%",
              height: "24px",
              fontSize: "0.75rem",
              padding: "2px 8px",
            }}
            onFocus={(e) =>
              e.target.scrollIntoView({ behavior: "smooth", block: "center" })
            }
            onClick={(e) => e.stopPropagation()}
          />
          <label
            style={{
              fontWeight: "500",
              marginBottom: "3px",
              fontSize: "9px",
              display: "block",
            }}
          >
            Placeholder
          </label>
          <Input
            type="text"
            value={field.placeholder}
            onChange={(e) => onUpdatePlaceholder(e.target.value)}
            placeholder="Placeholder"
            style={{
              marginBottom: "6px",
              width: "100%",
              height: "24px",
              fontSize: "0.75rem",
              padding: "2px 8px",
            }}
            onFocus={(e) =>
              e.target.scrollIntoView({ behavior: "smooth", block: "center" })
            }
            onClick={(e) => e.stopPropagation()}
          />
          {["radio", "checkbox", "dropdown"].includes(field.field_type) && (
            <div>
              {field.options.map((option, index) => (
                <div
                  key={index}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    marginBottom: "6px",
                    fontSize: "0.75rem",
                  }}
                >
                  {editingOptionIndex === index ? (
                    <Input
                      type="text"
                      value={editingOptionValue}
                      onChange={(e) => setEditingOptionValue(e.target.value)}
                      style={{
                        marginRight: "6px",
                        flexGrow: 1,
                        height: "24px",
                        fontSize: "0.75rem",
                        padding: "2px 8px",
                      }}
                      onFocus={(e) =>
                        e.target.scrollIntoView({
                          behavior: "smooth",
                          block: "center",
                        })
                      }
                      onClick={(e) => e.stopPropagation()}
                    />
                  ) : (
                    <span style={{ flexGrow: 1, fontSize: "0.75rem" }}>
                      {option}
                    </span>
                  )}
                  {editingOptionIndex === index ? (
                    <button
                      onClick={handleSaveEditedOption}
                      style={{
                        marginLeft: "6px",
                        padding: "3px 6px",
                        backgroundColor: "#28a745",
                        color: "white",
                        border: "none",
                        borderRadius: "3px",
                        cursor: "pointer",
                        fontSize: "0.7rem",
                      }}
                    >
                      <FontAwesomeIcon
                        icon={faSave}
                        style={{ fontSize: "0.7rem" }}
                      />
                    </button>
                  ) : (
                    <button
                      onClick={() => handleEditOption(index)}
                      style={{
                        marginLeft: "6px",
                        padding: "3px 6px",
                        backgroundColor: "#007bff",
                        color: "white",
                        border: "none",
                        borderRadius: "3px",
                        cursor: "pointer",
                        fontSize: "0.7rem",
                      }}
                    >
                      <FontAwesomeIcon
                        icon={faEdit}
                        style={{ fontSize: "0.7rem" }}
                      />
                    </button>
                  )}
                </div>
              ))}
              <Input
                type="text"
                value={newOption}
                onChange={(e) => setNewOption(e.target.value)}
                placeholder="Add option"
                style={{
                  marginBottom: "6px",
                  width: "100%",
                  height: "24px",
                  fontSize: "0.75rem",
                  padding: "2px 8px",
                }}
                onFocus={(e) =>
                  e.target.scrollIntoView({
                    behavior: "smooth",
                    block: "center",
                  })
                }
                onClick={(e) => e.stopPropagation()}
              />
              <button
                onClick={handleAddOption}
                style={{
                  marginBottom: "6px",
                  width: "100%",
                  padding: "5px",
                  backgroundColor: "#007bff",
                  color: "white",
                  border: "none",
                  borderRadius: "3px",
                  cursor: "pointer",
                  fontSize: "0.75rem",
                }}
              >
                Add Option
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default FormField;
