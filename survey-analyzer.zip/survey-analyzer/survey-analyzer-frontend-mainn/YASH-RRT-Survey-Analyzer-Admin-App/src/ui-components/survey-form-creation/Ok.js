import React from 'react'

const Ok = () => {
  return (
    <div>
      This is the OK page.
    </div>
  )
}

export default Ok
