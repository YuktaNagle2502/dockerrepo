export const routes = {
  HOME: "/",
  ADMIN_DASHBOARD: "/dashboard",
  FORM_BUILDER: "/view-forms/form-builder",
  VIEW_FORM: "/view-forms",
  SURVEY_ANALYSER: "/survey-lens",
  FORM_ANALYSIS: "/survey-lens/form-analysis",
  VIEW_ANALYSER: "/survey-lens/form-analysis/view-analyser",
  VIEW_RESPONSE: "/survey-lens/form-analysis/view-response",
  DASHBOARD: "/dashboard",
  FORM_ANALYSIS: "/survey-lens/form-analysis",
  
};
export const brand = {
  NAME: "Survey Lens",
};

export const URL_SurveyBroadcastAPIV2="https://a9aikwz2rg.execute-api.us-east-2.amazonaws.com";
export const URL_SurveyFormAdminAPIV2="https://04g4bjuen6.execute-api.us-east-2.amazonaws.com";
