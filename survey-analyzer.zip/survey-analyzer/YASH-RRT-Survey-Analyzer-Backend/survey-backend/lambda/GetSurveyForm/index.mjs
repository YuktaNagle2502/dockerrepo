import AWS from 'aws-sdk';
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = 'SurveyFormDetailsAdmin';
 
export const handler = async (event, context) => {
    console.log('event', event, context);
    try {
        let response;
        const id = event.queryStringParameters?.id;
 
        if (id=="null" || id=="undefined") {
             const params = {
                TableName: TABLE_NAME,
                ProjectionExpression: "id, title" // Only retrieve id and title
            };
            const result = await dynamoDb.scan(params).promise();
            response = result.Items; // Return array of items with id and title
        } else {
             const params = {
                TableName: TABLE_NAME,
                Key: { id }
            };
            const result = await dynamoDb.get(params).promise();
            response = result.Item ? [result.Item] : [];
        }
 
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET'
            },
            body: JSON.stringify(response)
        };
    } catch (error) {
        console.error("Error:", error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET'
            },
            body: JSON.stringify({
                message: "An error occurred",
                error: error.message
            })
        };
    }
};