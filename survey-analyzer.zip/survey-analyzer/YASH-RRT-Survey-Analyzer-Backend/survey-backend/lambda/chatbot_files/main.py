import json
import google.generativeai as genai
 
# Configure the API key
genai.configure(api_key="AIzaSyBikg6slbte2y_MHwj9REz8j-pODhw_DDI")
 
def lambda_handler(event, context):
    # Check if the 'Extracted Excel Values' key is present in the event
    if 'Extracted Excel Values' in event:
        # Get the JSON data from the event
        data = event['Extracted Excel Values']
        print("event data :", data)
       
        generation_config = {
            "temperature": 1,
            "top_p": 0.95,
            "top_k": 40,
            "max_output_tokens": 8192,
            "response_mime_type": "text/plain",
        }
       
        model = genai.GenerativeModel(
            model_name="gemini-2.0-flash-exp",
            generation_config=generation_config,
        )
       
        chat_session = model.start_chat(
            history=[
                {
                    "role": "user",
                    "parts": [
                        'I need a survey form with json format and will give you the purpose. Ensure every form includes a submit button with the placeholder "Submit"\n{ "form_schema": [ { "field_type": "text", "label": "Name", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "checkbox", "label": "Married", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "radio", "label": "City", "required": false, "options": [ "Bhopal", "Indore", "Satna" ] }, { "field_type": "dropdown", "label": "How likely are you to recommend our company as a great place to work?", "required": false, "options": [ "Agree", "Disagree", "Strongly Agree" ] }, { "field_type": "date", "label": "Joinin Date", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "textarea", "label": "Do you feel motivated to do your best work every day?", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "email", "label": "Your Email Address", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "number", "label": "Number Field", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "password", "label": "Password Field", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "file", "label": "Upload your image", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "button", "label": "Button", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] } ]}\n',
                    ],
                },
                {
                    "role": "model",
                    "parts": [
                        'Okay, I understand. You want a JSON schema for a survey form, and you\'ve provided a good starting point. However, some of the `options` fields in your provided schema are not relevant to the field type and could cause confusion. I\'ll revise the schema, remove irrelevant options from fields like `date`, `textarea`, `email`, `number`, `password`, `file` and `button`. I\'ll also add some common question fields and ensure every form include a submit button with the placeholder "Submit".\n\n**Here\'s the revised JSON schema, ready for your purpose:**\n```json\n{\n "form_schema": [\n {\n "field_type": "text",\n "label": "Full Name",\n "required": true,\n "placeholder": "Enter your full name"\n \n },\n {\n "field_type": "checkbox",\n "label": "Select your interests:",\n "required": false,\n "options": [\n "Technology",\n "Arts",\n "Sports",\n "Travel",\n "Other"\n ]\n },\n {\n "field_type": "radio",\n "label": "Gender",\n "required": true,\n "options": [\n "Male",\n "Female",\n "Prefer not to say"\n ]\n },\n {\n "field_type": "dropdown",\n "label": "How did you hear about us?",\n "required": true,\n "placeholder": "Select option",\n "options": [\n "Social Media",\n "Friend/Family",\n "Search Engine",\n "Advertisement",\n "Other"\n ]\n },\n {\n "field_type": "date",\n "label": "Date of Birth",\n "required": false,\n "placeholder": "YYYY-MM-DD"\n },\n {\n "field_type": "textarea",\n "label": "Any additional comments or feedback?",\n "required": false,\n "placeholder": "Enter your comments here"\n },\n {\n "field_type": "email",\n "label": "Email Address",\n "required": true,\n "placeholder": "Enter your email"\n },\n {\n "field_type": "number",\n "label": "Your age",\n "required": false,\n "placeholder": "Enter your age"\n },\n {\n "field_type": "password",\n "label": "Create a Password",\n "required": true,\n "placeholder": "Enter your password"\n \n },\n {\n "field_type": "file",\n "label": "Upload your profile picture",\n "required": false,\n "accept": "image/*"\n },\n\n {\n "field_type": "button",\n "label": "Submit",\n "button_type": "submit", \n "placeholder": "Submit"\n  }\n ]\n}\n```\n\n**Key changes and explanation:**\n\n* **Removed Irrelevant `options`:** The `options` array is removed from fields where it doesn\'t apply (e.g., `date`, `textarea`, `email`, `number`, `password`, `file`, `button`). These fields will now function correctly for their respective data types\n* **`placeholder` attributes:** I\'ve added placeholder text to guide users on what to enter in text, textarea, number, email, password and dropdown fields.\n* **`accept` attribute:** The `file` field has an `accept` attribute to specify that only image files are accepted.\n* **`button_type` attribute:** The button field has an attribute called `button_type` which specified button type (`submit` and `reset`).\n* **`required` attribute:** The `required` is used to mark important fields.\n* **Clearer labels:** Labels have been changed for better understanding and relevancy.\n* **Added placeholders for dropdown:** Added placeholder text for the dropdown menu.\n\n**How to use this JSON:**\n\n1. **Parsing:** You would use a JSON parser (in JavaScript, Python, or any other language) to load this data structure.\n2. **Form Generation:** Your application code would then iterate through the `form_schema` array. For each object, it would dynamically generate the corresponding HTML form element (input fields, checkboxes, dropdowns, etc.).\n3. **Data Collection:** When the user fills out the form, your application would gather the entered data and submit it to a backend server or process it as needed.\n\n**Next steps:**\n1. **Let me know your purpose**: Tell me what kind of survey this will be. (e.g. customer feedback, employee engagement, event registration, etc.).\n2. **Specific Questions:** You may need more specific questions related to your purpose. I can add, edit, or remove fields as needed.\n3. **Validation Rules:** If you require more robust input validation (e.g., min/max lengths for text, numeric ranges, or specific email patterns), we can add validation attributes to the schema.\n\nI\'m ready for your feedback and further refinements. Please let me know how you want to proceed!\n',
                    ],
                },
                {
                    "role": "user",
                    "parts": [
                        'I need a survey form with below json format. Can you generate for employee satisfaction\n\n{ "form_schema": [ { "field_type": "text", "label": "Name", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "checkbox", "label": "Married", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "radio", "label": "City", "required": false, "options": [ "Bhopal", "Indore", "Satna" ] }, { "field_type": "dropdown", "label": "How likely are you to recommend our company as a great place to work?", "required": false, "options": [ "Agree", "Disagree", "Strongly Agree" ] }, { "field_type": "date", "label": "Joinin Date", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "textarea", "label": "Do you feel motivated to do your best work every day?", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "email", "label": "Your Email Address", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "number", "label": "Number Field", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "password", "label": "Password Field", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "file", "label": "Upload your image", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] }, { "field_type": "button", "label": "Button", "required": false, "options": [ "Option 1", "Option 2", "Option 3" ] } ]}\n',
                    ],
                },
                {
                    "role": "model",
                    "parts": [
                        'Okay, I understand. You want to use that specific JSON structure as a base and adapt it for an employee satisfaction survey. I\'ll keep the same `field_type`, `label`, `required`, and `options` structure, but I will:\n\n1. **Remove irrelevant options:** as before, we will remove `options` from where they don\'t apply.\n2. **Replace Labels:** Adjust labels to focus on employee satisfaction.\n3. **Add relevant options** to radio, dropdown and checkbox fields.\n4. **Remove unnecessary fields:** Fields like the file upload and password are not relevant for employee satisfaction.\n5. **Add placeholders** to text, number, email and textarea fields.\n\nHere\'s the adapted JSON schema for an employee satisfaction survey:\n```json\n{\n "form_schema": [\n {\n "field_type": "text",\n "label": "Employee ID",\n "required": true,\n "placeholder": "Enter your Employee ID"\n },\n {\n "field_type": "checkbox",\n "label": "What benefits are most important to you?",\n "required": false,\n "options": [\n "Health Insurance",\n "Paid Time Off",\n "Retirement Plan",\n "Professional Development",\n "Other"\n ]\n },\n {\n "field_type": "radio",\n "label": "How would you rate your work-life balance?",\n "required": true,\n "options": [\n "Excellent",\n "Good",\n "Fair",\n "Poor"\n ]\n },\n {\n "field_type": "dropdown",\n "label": "How likely are you to recommend our company as a great place to work?",\n "required": true,\n "placeholder": "Select option",\n "options": [\n "Very Likely",\n "Likely",\n "Neutral",\n "Unlikely",\n "Very Unlikely"\n \n ]\n },\n {\n "field_type": "date",\n "label": "Start Date at Company",\n "required": false,\n "placeholder": "YYYY-MM-DD"\n },\n {\n "field_type": "textarea",\n "label": "What aspects of your job do you enjoy the most?",\n "required": false,\n "placeholder": "Enter your feedback here"\n },\n {\n "field_type": "email",\n "label": "Work Email Address",\n "required": true,\n "placeholder": "Enter your Work email"\n },\n {\n "field_type": "number",\n "label": "Years of Experience at Company",\n "required": false,\n "placeholder":"Enter your Experience"\n },\n\n {\n "field_type": "textarea",\n "label": "Any other comments to improve the work environment?",\n "required": false,\n "placeholder": "Enter your comment here"\n },\n {\n "field_type": "button",\n "label": "Submit",\n "button_type": "submit",\n "placeholder": "Submit"\n  }\n ]\n}\n```\n\n**Key changes:**\n\n* **Removed Unnecessary Fields:** The `password` and `file` field have been removed as they are not needed for an employee satisfaction survey.\n* **Relevant Labels:** The labels have been changed to reflect questions about employee satisfaction, benefits, work-life balance, and job enjoyment.\n* **Specific Options:** Options for radio buttons, dropdowns, and checkboxes are now tailored to employee feedback.\n* **Added placeholder:** Placeholder text has been added to guide the user to the correct input.\n* **Added Employee ID:** Added a text field to collect Employee ID for identification.\n\n**How to use this updated JSON:**\n\n1. **Load and Parse:** Use a JSON parser to load the JSON data into your application.\n2. **Dynamic Form Generation:** Your application code will iterate through the `form_schema` array and dynamically generate the corresponding HTML form elements based on `field_type` and other attributes.\n3. **Data Collection and Handling:** After the employee fills out the form, the submitted data can be collected and processed by your backend application.\n\n**Next Steps:**\n\n1. **Review:** Please review the updated schema to see if it meets your requirements for an employee satisfaction survey.\n2. **More Questions:** If you need to include additional questions or different types of questions, let me know, and I\'ll be glad to modify the schema.\n3. **Validation:** If you want to incorporate any validation rules or error handling, please specify what you need.\n\nI\'m ready for your feedback and any further changes. Let me know how you\'d like to proceed!\n',
                    ],
                },
            ]
        )
       
        try:
            # Convert data list to JSON string
            data_str = json.dumps(data)
           
            # Send message to chat session
            response = chat_session.send_message(
                data_str + " and provide result in exactly json only and don't include \\ and \\n because I am going to use json in python program"
            )
           
            # Extract text from response
            response_text = response.text
            print(" response ", response_text)
           
            # Remove markdown formatting and clean up the response
            json_str = response_text.replace("```json\n", "").replace("\n```", "")
           
            # Parse the cleaned JSON string
            try:
                parsed_json = json.loads(json_str)
                return {
                    "statusCode": 200,
                    "body": {"message": parsed_json}
                }
            except json.JSONDecodeError as e:
                return {
                    "statusCode": 400,
                    "body": {"error": f"Failed to parse response as JSON: {str(e)}"}
                }
               
        except Exception as e:
            return {
                "statusCode": 500,
                "body": {"error": f"Error processing request: {str(e)}"}
            }
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Bad Request: Missing Extracted Excel Values in the event'}),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
 
