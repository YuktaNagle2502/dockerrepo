import AWS from 'aws-sdk';
const dynamoDb = new AWS.DynamoDB.DocumentClient();

export const handler = async (event) => {
    const tableName = process.env.TABLE_NAME || 'SurveyFormDetailsUser';
    const indexName = process.env.INDEX_NAME || 'form_id-index'; 
    const formId = event.queryStringParameters && event.queryStringParameters.form_id;

    if (!formId) {
        console.error("form_id is missing in the event");
        return {
            statusCode: 400,
            body: JSON.stringify('form_id is required')
        };
    }

    const params = {
        TableName: tableName,
        IndexName: indexName,
        KeyConditionExpression: 'form_id = :form_id',
        ExpressionAttributeValues: {
            ':form_id': formId
        }
    };

    try {
        const data = await dynamoDb.query(params).promise();
        const items = data.Items;

        const submittedItems = items.filter(item => item.status === 'submitted');

        if (submittedItems.length > 0) {
            return {
                statusCode: 200,
                body: JSON.stringify(submittedItems.map(item => ({
                    id: item.id,
                    shared_with: item.shared_with
                })))
            };
        } else {
            return {
                statusCode: 404,
                body: JSON.stringify('No submitted forms found')
            };
        }
    } catch (error) {
        console.error('Error fetching form details:', error);
        return {
            statusCode: 500,
            body: JSON.stringify('Internal server error')
        };
    }
};