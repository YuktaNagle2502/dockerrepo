from fastapi import APIRouter, WebSocket, WebSocketDisconnect, HTTPException, Query
from fastapi.responses import FileResponse
from src.face_monitoring import EngagementDetector
import asyncio
import base64
import cv2
import numpy as np
import time
import os
import shutil

router = APIRouter()

def validate_frame_data(frame_data: bytes) -> bool:
    return frame_data and len(frame_data) > 100

def decode_frame(frame_data: bytes) -> np.ndarray:
    if not validate_frame_data(frame_data):
        raise ValueError("Invalid frame data received")
    nparr = np.frombuffer(frame_data, np.uint8)
    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if frame is None:
        raise ValueError("Failed to decode frame")
    return frame

@router.websocket("/frame-stream/{interview_id}")
async def frame_stream_endpoint(websocket: WebSocket,interview_id: str):
    print("interview_id:",interview_id)
    await websocket.accept()
    detector = EngagementDetector(batch_size=10, interview_id=interview_id)
    frame_queue = asyncio.Queue(maxsize=30)
    is_processing = True
    is_connected = True
    
    async def process_frames():
        nonlocal is_processing, is_connected
        consecutive_errors = 0
        while is_processing and is_connected:
            try:
                frame = await asyncio.wait_for(frame_queue.get(), timeout=0.1)
                start_time = time.time()
                updated_frame = detector.detect_face(frame)
                _, buffer = cv2.imencode('.jpg', updated_frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
                frame_base64 = base64.b64encode(buffer).decode('utf-8')
                processing_time = time.time() - start_time
                if is_connected:
                    await websocket.send_json({
                        'status': 'success',
                        'processing_time': processing_time,
                        'frame': frame_base64
                    })
                consecutive_errors = 0
            except asyncio.TimeoutError:
                await asyncio.sleep(0.01)
            except Exception as e:
                consecutive_errors += 1
                print(f"Processing error: {e}")
                if consecutive_errors > 5:
                    print("Too many consecutive errors, stopping processing")
                    is_processing = False
                    break
                if is_connected:
                    try:
                        await websocket.send_json({
                            'status': 'error',
                            'message': str(e)
                        })
                    except:
                        pass
            finally:
                if not frame_queue.empty():
                    frame_queue.task_done()

    processing_task = asyncio.create_task(process_frames())

    try:
        while is_connected:
            try:
                frame_data = await asyncio.wait_for(websocket.receive_bytes(), timeout=5.0)
                frame = decode_frame(frame_data)
                if frame_queue.qsize() < frame_queue.maxsize:
                    await frame_queue.put(frame)
                else:
                    print("Frame queue full, skipping frame")
            except WebSocketDisconnect:
                print("Client disconnected")
                is_connected = False
                break
            except asyncio.TimeoutError:
                print("Receive timeout")
                is_connected = False
                break
            except Exception as e:
                print(f"Receive error: {e}")
                is_connected = False
                break
    finally:
        is_processing = False
        try:
            await processing_task
        except:
            pass
        if is_connected:
            await websocket.close()

@router.get("/status")
async def get_status_csv(interview_id: str = Query(...)):
    print("get status of interview_id:",interview_id)
    csv_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),"streaming",interview_id, "status.csv")
    if not os.path.exists(csv_path):
        raise HTTPException(status_code=404, detail="Status CSV not found")
    return FileResponse(csv_path, media_type="text/csv", filename="status.csv")

@router.post("/clear-status")
async def clear_status_csv(interview_id: str = Query(...)):
    print("clear-status of interview_id:", interview_id)
    parent_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "streaming", interview_id)
    csv_path = os.path.join(parent_dir, "status.csv")
    try:
        if os.path.exists(csv_path):
            os.remove(csv_path)  # Delete the status.csv file
            shutil.rmtree(parent_dir)  # Delete the parent directory and its contents
            return {"status": "success", "message": "status.csv and parent folder deleted"}
        else:
            raise HTTPException(status_code=404, detail="Status CSV not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting status CSV and folder: {str(e)}")

@router.get("/health")
async def health_check():
    return {"status": "healthy"}