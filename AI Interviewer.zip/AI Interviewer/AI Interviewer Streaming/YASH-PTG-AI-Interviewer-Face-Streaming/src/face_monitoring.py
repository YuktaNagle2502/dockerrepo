from datetime import datetime
import cv2
import os
import numpy as np
from src.utils import *
from src.face_iris_detection import *
from src.face_pose_estimation import *
import mediapipe as mp
import warnings

mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles
mp_face_mesh = mp.solutions.face_mesh
mp_face_detection = mp.solutions.face_detection

warnings.filterwarnings("ignore")

class EngagementDetector:
    def __init__(self, batch_size=30, interview_id=None):
        self.final_status = ''
        self.current_status = ''
        self.frame_buffer = 0
        self.engagement_counts = {'Engaged': 0, 'Disengaged': 0}
        self.batch_size = batch_size
        # Construct csv_file path with interview_id
        if interview_id:
            self.csv_file = os.path.join(os.path.dirname(os.path.dirname(__file__)),"streaming", interview_id, "status.csv")
        else:
            self.csv_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "status.csv")
        self.face_mesh = mp_face_mesh.FaceMesh(
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        self.check_and_create_csv()
        
    def check_and_create_csv(self):
        """Check if status.csv exists; create or clear it with headers."""
        parent_dir = os.path.dirname(self.csv_file)
        # Check if the parent directory exists
        if os.path.exists(parent_dir):
            print(f"Directory {parent_dir} exists. Clearing {self.csv_file}.")
            # Clear the status.csv file and write headers
            with open(self.csv_file, 'w') as f:
                f.write("Timestamp,Status,Engaged_Frames,Disengaged_Frames\n")
            print(f"Cleared {self.csv_file} and wrote headers.")
        else:
            print(f"Directory {parent_dir} not found. Creating directory and {self.csv_file}.")
            # Create the parent directory
            os.makedirs(parent_dir, exist_ok=True)
            # Create the file with default CSV headers
            with open(self.csv_file, 'w') as f:
                f.write("Timestamp,Status,Engaged_Frames,Disengaged_Frames\n")
            print(f"Created {self.csv_file} with default headers.")

    def draw_face_landmarks_fp(self, image, face_landmarks):
        mp_drawing.draw_landmarks(
            image=image,
            landmark_list=face_landmarks,
            connections=mp_face_mesh.FACEMESH_TESSELATION,
            landmark_drawing_spec=None,
            connection_drawing_spec=mp_drawing_styles.DrawingSpec(color=(204,204,0), thickness=1))
        mp_drawing.draw_landmarks(
            image=image,
            landmark_list=face_landmarks,
            connections=mp_face_mesh.FACEMESH_CONTOURS,
            landmark_drawing_spec=None,
            connection_drawing_spec=mp_drawing_styles.get_default_face_mesh_contours_style())
        mp_drawing.draw_landmarks(
            image=image,
            landmark_list=face_landmarks,
            connections=mp_face_mesh.FACEMESH_LIPS,
            landmark_drawing_spec=None,
            connection_drawing_spec=mp_drawing_styles.DrawingSpec(color=YELLOW, thickness=1))

    def reset_counts(self):
        self.engagement_counts = {'Engaged': 0, 'Disengaged': 0}
        self.frame_buffer = 0

    def draw_status_text(self, frame):
        if self.current_status:
            colorBackgroundText(
                frame,
                f"Current: {self.current_status}",
                FONTS, 1.0, (40, 320), 2,
                WHITE,
                GREEN if self.current_status == "Engaged" else RED,
                8, 8
            )

    def detect_face(self, frame):
        img_height, img_width, img_c = frame.shape
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame.flags.writeable = False
        try:
            resize_factor = 2
            results = self.face_mesh.process(cv2.resize(rgb_frame, (int(img_width*resize_factor), int(img_height*resize_factor))))
            
            if results and results.multi_face_landmarks:
                frame.flags.writeable = True
                self.draw_face_landmarks_fp(frame, results.multi_face_landmarks[0])
                mesh_points2d = np.array([np.multiply([p.x,p.y], [img_width,img_height]).astype(int) 
                                        for p in results.multi_face_landmarks[0].landmark])
                
                (l_cx,l_cy),l_radius=cv2.minEnclosingCircle(mesh_points2d[LEFT_IRIS])
                (r_cx,r_cy),r_radius=cv2.minEnclosingCircle(mesh_points2d[RIGHT_IRIS])
                
                center_left=np.array([l_cx,l_cy],dtype=np.int32)
                center_right=np.array([r_cx,r_cy],dtype=np.int32)
                sum_sq = np.sum(np.square(center_right - center_left))
                center_distance=np.sqrt(sum_sq)
                
                cv2.circle(frame,center_left,int(l_radius),(255,0,255),1,cv2.LINE_AA)
                cv2.circle(frame,center_right,int(r_radius),(255,0,255),1,cv2.LINE_AA)
                
                right_coords = [mesh_points2d[p] for p in RIGHT_EYE]
                left_coords = [mesh_points2d[p] for p in LEFT_EYE]
                
                if center_distance>102:
                    isengaged_right,isengaged_left=iris_position_pipeline(frame, right_coords, left_coords)
                    self.current_status = "Engaged" if (isengaged_right and isengaged_left) else "Disengaged"
                    self.engagement_counts[self.current_status] += 1
                else:
                    position = pipelineHeadTiltPose(frame,results.multi_face_landmarks[0])
                    if position:
                        isengaged_right,isengaged_left=iris_position_pipeline(frame, right_coords, left_coords)
                        self.current_status = "Engaged" if (isengaged_right or isengaged_left) else "Disengaged"
                        self.engagement_counts[self.current_status] += 1
                    else:
                        self.current_status = "Disengaged"
                        self.engagement_counts[self.current_status] += 1 
                self.frame_buffer+=1
                if self.frame_buffer >= self.batch_size:
                    total_frames = sum(self.engagement_counts.values())
                    engagement_ratio = self.engagement_counts['Engaged'] / total_frames
                    self.final_status = "Engaged" if engagement_ratio >= 0.6 else "Disengaged"
                    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    write_headers = not os.path.exists(self.csv_file) or os.path.getsize(self.csv_file) == 0
                    with open(self.csv_file, "a") as f:
                        if write_headers:
                            f.write("Timestamp,Status,Engaged_Frames,Disengaged_Frames\n")
                        f.write(f"{current_time},{self.final_status.lower()},{self.engagement_counts['Engaged']},{self.engagement_counts['Disengaged']}\n")
                    self.reset_counts()                                                                                                                                                                                                                                                                                                                                                    
                self.draw_status_text(frame)  
                    
        except Exception as error:
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            write_headers = not os.path.exists(self.csv_file) or os.path.getsize(self.csv_file) == 0
            with open(self.csv_file, "a") as f:
                if write_headers:
                    f.write("Timestamp,Status,Engaged_Frames,Disengaged_Frames\n")
                f.write(f"{current_time},{'No Face Detected'},{0},{0}\n")
            colorBackgroundText(frame, "No Face Detected", FONTS, 1.0, (40, 320), 2, BLACK, YELLOW, 8, 8)
        
        return frame

def direct_func():
    cap = cv2.VideoCapture(0)
    detector = EngagementDetector(batch_size=30)
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        processed_frame = detector.detect_face(frame)
        cv2.imshow('Engagement Detection', processed_frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()