import cv2
import numpy as np

def eyesExtractor(img, right_eye_coords, left_eye_coords):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    dim = gray.shape
    mask = np.zeros(dim, dtype=np.uint8)
    
    cv2.fillPoly(mask, [np.array(right_eye_coords, dtype=np.int32)], 255)
    cv2.fillPoly(mask, [np.array(left_eye_coords, dtype=np.int32)], 255)
    
    eyes = cv2.bitwise_and(gray, gray, mask=mask)
    eyes[mask==0]=155
    
    r_max_x = (max(right_eye_coords, key=lambda item: item[0]))[0]
    r_min_x = (min(right_eye_coords, key=lambda item: item[0]))[0]
    r_max_y = (max(right_eye_coords, key=lambda item: item[1]))[1]
    r_min_y = (min(right_eye_coords, key=lambda item: item[1]))[1]
    
    l_max_x = (max(left_eye_coords, key=lambda item: item[0]))[0]
    l_min_x = (min(left_eye_coords, key=lambda item: item[0]))[0]
    l_max_y = (max(left_eye_coords, key=lambda item: item[1]))[1]
    l_min_y = (min(left_eye_coords, key=lambda item: item[1]))[1]
    
    cropped_right = eyes[r_min_y: r_max_y, r_min_x: r_max_x]
    cropped_left = eyes[l_min_y: l_max_y, l_min_x: l_max_x]
    hl, wl = cropped_left.shape
    hr, wr = cropped_right.shape
    resize_factor=2
    cropped_right=cv2.resize(cropped_right, (int(wr*resize_factor), int(hr*resize_factor)),interpolation=cv2.INTER_CUBIC)
    cropped_left=cv2.resize(cropped_left, (int(wl*resize_factor), int(hl*resize_factor)),interpolation=cv2.INTER_CUBIC)
    return cropped_right, cropped_left

def positionEstimator(cropped_eye):
    h, w = cropped_eye.shape
    gaussain_blur = cv2.GaussianBlur(cropped_eye, (9,9), 0)
    median_blur = cv2.medianBlur(gaussain_blur, 3)
    ret, threshed_eye = cv2.threshold(median_blur, 130, 255, cv2.THRESH_BINARY)
    piece = int(w/3)
    thres=2
    right_piece = threshed_eye[0:h, 0:piece+thres]
    center_piece = threshed_eye[0:h, piece+thres: piece+piece-thres]
    left_piece = threshed_eye[0:h, piece+piece-thres:w]
    
    eye_position = pixelCounter(right_piece, center_piece, left_piece)
    return eye_position

def pixelCounter(first_piece, second_piece, third_piece):
    right_part = np.sum(first_piece==0)
    center_part = np.sum(second_piece==0)
    left_part = np.sum(third_piece==0)
    eye_parts = [right_part, center_part, left_part]
    max_index = eye_parts.index(max(eye_parts))
    return 1 if max_index==1 else 0

def iris_position_pipeline(frame, right_coords, left_coords):
    crop_right, crop_left = eyesExtractor(frame, right_coords, left_coords)
    isengaged_left = positionEstimator(crop_left)
    isengaged_right = positionEstimator(crop_right)
    return isengaged_right, isengaged_left