from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from src import app as app_module
from middleware.auth_middleware import KeycloakAuthMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# app.add_middleware(KeycloakAuthMiddleware)
app.include_router(app_module.router)