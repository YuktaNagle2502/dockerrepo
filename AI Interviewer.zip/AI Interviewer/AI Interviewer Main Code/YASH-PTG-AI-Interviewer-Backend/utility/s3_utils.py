import boto3
import os
from botocore.exceptions import ClientError, NoCredentialsError, PartialCredentialsError
from urllib.parse import urlparse, unquote
from fastapi import HTTPException
import logging
import requests

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# AWS S3 Configuration
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION = os.getenv("AWS_REGION")
BUCKET_NAME = os.getenv("BUCKET_NAME")  

def validate_aws_credentials():
    """Validate AWS credentials are present"""
    missing_vars = []
    if not AWS_ACCESS_KEY_ID:
        missing_vars.append("AWS_ACCESS_KEY_ID")
    if not AWS_SECRET_ACCESS_KEY:
        missing_vars.append("AWS_SECRET_ACCESS_KEY")
    if not AWS_REGION:
        missing_vars.append("AWS_REGION")
    if not BUCKET_NAME:
        missing_vars.append("BUCKET_NAME")
   
    if missing_vars:
        raise HTTPException(
            status_code=500,
            detail=f"Missing AWS environment variables: {', '.join(missing_vars)}"
        )

def get_s3_client():
    """Initialize and return an S3 client with proper error handling."""
    try:
        validate_aws_credentials()
       
        s3_client = boto3.client(
            's3',
            region_name=AWS_REGION,
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY
        )
        return s3_client
    except NoCredentialsError:
        logger.error("AWS credentials not found")
        raise HTTPException(status_code=500, detail="AWS credentials not found")
    except PartialCredentialsError:
        logger.error("Incomplete AWS credentials")
        raise HTTPException(status_code=500, detail="Incomplete AWS credentials")
    except Exception as e:
        logger.error(f"Failed to initialize S3 client: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to initialize S3 client: {str(e)}")

def ensure_s3_folders():
    """Ensure all required folders exist in the S3 bucket with better error handling."""
    folders = [
        "ai-interviewer/fileupload/resume/",
        "ai-interviewer/fileupload/jd_files/",
        "ai-interviewer/fileupload/jd_custom_question_files/",
        "ai-interviewer/profileimage/user_images/",
        "ai-interviewer/recordings/",
        "ai-interviewer/suspicious-activity/tab_switching/",
        "ai-interviewer/report-summary/"  # Added for summary report PDFs
    ]
   
    try:
        s3_client = get_s3_client()
       
        for folder in folders:
            try:
                s3_client.put_object(
                    Bucket=BUCKET_NAME,
                    Key=folder,
                    Body=b'',
                    ContentType='application/x-directory'
                )
                logger.info(f"Ensured folder exists: {folder}")
            except ClientError as e:
                error_code = e.response['Error']['Code']
                if error_code == '403':
                    logger.warning(f"Access denied when creating folder {folder}")
                else:
                    logger.error(f"Failed to create folder {folder}: {str(e)}")
    except Exception as e:
        logger.warning(f"Could not ensure S3 folders on startup: {str(e)}")

# Run folder creation on module load
try:
    ensure_s3_folders()
except Exception as e:
    logger.warning(f"Could not ensure S3 folders on startup: {str(e)}")

async def upload_file_to_s3(key: str, file_content: bytes, content_type: str) -> str:
    """
    Uploads a file to S3 and returns its S3 path (s3://bucket/key).
    """
    try:
        validate_aws_credentials()
       
        key = key.lstrip('/')
        if key.startswith(f"{BUCKET_NAME}/"):
            key = key[len(BUCKET_NAME) + 1:]
       
        if not key.startswith("ai-interviewer/"):
            key = f"ai-interviewer/{key}"
           
        logger.info(f"Uploading file to S3: {BUCKET_NAME}/{key}")
       
        s3_client = get_s3_client()
       
        s3_client.put_object(
            Bucket=BUCKET_NAME,
            Key=key,
            Body=file_content,
            ContentType=content_type
        )
 
        s3_path = f"s3://{BUCKET_NAME}/{key}"
        logger.info(f"Successfully uploaded file to S3: {s3_path}")
        return s3_path
       
    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
       
        if error_code == '403':
            logger.error(f"Access denied for S3 upload: {error_message}")
            raise HTTPException(
                status_code=403,
                detail=f"S3 access denied. Check your AWS credentials and bucket permissions. Error: {error_message}"
            )
        elif error_code == '404':
            logger.error(f"Bucket not found: {error_message}")
            raise HTTPException(
                status_code=404,
                detail=f"S3 bucket '{BUCKET_NAME}' not found. Error: {error_message}"
            )
        else:
            logger.error(f"S3 client error: {error_code} - {error_message}")
            raise HTTPException(
                status_code=500,
                detail=f"S3 error ({error_code}): {error_message}"
            )
    except NoCredentialsError:
        logger.error("AWS credentials not found")
        raise HTTPException(status_code=500, detail="AWS credentials not configured")
    except PartialCredentialsError:
        logger.error("Incomplete AWS credentials")
        raise HTTPException(status_code=500, detail="Incomplete AWS credentials")
    except Exception as e:
        logger.error(f"Unexpected error uploading to S3: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to upload file to S3: {str(e)}")

def get_signed_s3_url(file_url: str, expiry_hours: int = 1, method: str = 'get_object', content_type: str = None) -> str:
    """
    Given a full S3 URL (s3://bucket/key), returns a presigned URL valid for the specified duration.
    Supports both get_object and put_object methods.
    """
    try:
        validate_aws_credentials()
       
        if not file_url.startswith("s3://"):
            if file_url.startswith("https://"):
                parsed = urlparse(file_url)
                if parsed.hostname and parsed.hostname.endswith('.amazonaws.com'):
                    bucket = parsed.hostname.split('.')[0]
                    key = unquote(parsed.path.lstrip('/'))
                else:
                    raise ValueError("Invalid S3 URL format")
            else:
                raise ValueError("Invalid S3 URL format, expected s3://bucket/key or https://...")
        else:
            parsed = urlparse(file_url)
            bucket = parsed.netloc
            key = unquote(parsed.path.lstrip('/'))
           
        logger.info(f"Generating presigned URL for {bucket}/{key} with method {method}")
 
        if bucket != BUCKET_NAME:
            raise ValueError(f"Bucket name mismatch: expected {BUCKET_NAME}, got {bucket}")
 
        s3_client = get_s3_client()
        params = {'Bucket': BUCKET_NAME, 'Key': key}
        if method == 'put_object' and content_type:
            params['ContentType'] = content_type
        presigned_url = s3_client.generate_presigned_url(
            method,
            Params=params,
            ExpiresIn=expiry_hours * 3600
        )
 
        logger.info(f"Generated presigned URL for {BUCKET_NAME}/{key}")
        return presigned_url
       
    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
        logger.error(f"Failed to generate presigned URL: {error_code} - {error_message}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate presigned URL: {error_message}"
        )
    except Exception as e:
        logger.error(f"Failed to generate presigned URL: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate presigned URL: {str(e)}")

def download_s3_file(presigned_url: str) -> bytes:
    """Download a file from S3 using a presigned URL with better error handling."""
    try:
        response = requests.get(presigned_url, timeout=30)
        response.raise_for_status()
        logger.info(f"Successfully downloaded file from presigned URL")
        return response.content
    except requests.exceptions.Timeout:
        logger.error("Timeout downloading file from S3")
        raise HTTPException(status_code=408, detail="Timeout downloading file from S3")
    except requests.exceptions.RequestException as e:
        logger.error(f"Error downloading file from S3: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error downloading file from S3: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error downloading file from S3: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error downloading file from S3: {str(e)}")

def is_presigned_url_valid(presigned_url: str) -> bool:
    """
    Assume presigned URL is valid to avoid HEAD request requiring s3:HeadObject.
    """
    logger.info(f"Assuming presigned URL is valid: {presigned_url}")
    return True

def check_s3_object_exists(key: str) -> bool:
    """
    Assume object exists if key is provided, as s3:HeadObject permission is not available.
    """
    if not key:
        logger.info("No key provided for object existence check")
        return False
    logger.info(f"Assuming object exists for key: {BUCKET_NAME}/{key} (s3:HeadObject not available)")
    return True

def delete_s3_object(file_url: str) -> bool:
    """
    Deletes an object from S3 given its full URL (s3://bucket/key).
    Returns True if deletion was successful, False otherwise.
    """
    try:
        validate_aws_credentials()
       
        if not file_url.startswith("s3://"):
            raise ValueError("Invalid S3 URL format, expected s3://bucket/key")
        parsed = urlparse(file_url)
        bucket = parsed.netloc
        key = unquote(parsed.path.lstrip('/'))
        logger.info(f"Deleting S3 object: {bucket}/{key}")
 
        if bucket != BUCKET_NAME:
            raise ValueError(f"Bucket name mismatch: expected {BUCKET_NAME}, got {bucket}")
 
        s3_client = get_s3_client()
        s3_client.delete_object(Bucket=BUCKET_NAME, Key=key)
        logger.info(f"Successfully deleted object: {BUCKET_NAME}/{key}")
        return True
       
    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
        logger.error(f"Failed to delete S3 object: {error_code} - {error_message}")
        return False
    except Exception as e:
        logger.error(f"Failed to delete S3 object: {str(e)}")
        return False