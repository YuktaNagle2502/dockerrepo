class TemplateUtility:
    @staticmethod
    def replace_placeholders(template_string: str, placeholders: dict) -> str:
        """
        Replace placeholders in template string with actual values.
        
        Args:
            template_string: String containing placeholders like {placeholder_name}
            placeholders: Dictionary with placeholder names as keys and replacement values as values
            
        Returns:
            String with placeholders replaced by actual values
        """
        result = template_string
        for key, value in placeholders.items():
            placeholder = "{" + key + "}"
            result = result.replace(placeholder, str(value))
        return result