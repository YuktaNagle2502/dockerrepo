from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, JSON, CheckConstraint, DECIMAL, Text, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from sqlalchemy.types import LargeBinary  # Import LargeBinary instead of Binary
from database import Database
from datetime import datetime
import PyPDF2
from io import BytesIO
import pytz

def get_ist_time():
    """Get current time in IST timezone"""
    ist = pytz.timezone("Asia/Kolkata")
    current_time = datetime.now(ist)
    return current_time.replace(tzinfo=None)

Base = declarative_base()

class JDDetails(Base):
    __tablename__ = 'jd_details'
    job_id = Column(Integer, primary_key=True, autoincrement=True)
    job_title = Column(String(255), nullable=False)
    job_location = Column(String(255), nullable=False)
    jd_questions = Column(JSON, nullable=True)
    # jd_file = Column(LargeBinary, nullable=False)  # Use LargeBinary
    jd_summary_text = Column(String, nullable=True)
    jd_custom_questions_text = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=func.current_timestamp())
    jd_file_path = Column(String(255), nullable=True)
    jd_expiration = Column(DateTime, nullable=True)
    llm_id = Column(Integer, ForeignKey('llms.id'), nullable=False)
    tech_stack_id = Column(Integer, ForeignKey('tech_stack.id'), nullable=False)
    jd_custom_questions_path = Column(String(255), nullable=True)
    jd_qualification_score = Column(DECIMAL(3,2))

class InterviewDetailsMain(Base):
    __tablename__ = 'interview_details_main'
    unique_id = Column(String(36), primary_key=True)
    full_name = Column(String(255), nullable=False)
    age = Column(Integer, nullable=False)
    sex = Column(String(10), nullable=False)
    phone = Column(String(15), nullable=False)
    email_id = Column(String(55), nullable=False)
    # resume = Column(LargeBinary, nullable=False)  # Use LargeBinary
    resume_path = Column(String(500), nullable=True)
    job_id = Column(Integer, ForeignKey('jd_details.job_id'), nullable=False)
    user_image = Column(String, nullable=True)
    user_image_path = Column(String(500), nullable=True)
    interview_questions = Column(JSON, nullable=True)
    interview_answers = Column(JSON, nullable=True)
    domain = Column(String(255), nullable=True)
    # text_file = Column(LargeBinary, nullable=True) 
    evaluation_result = Column(JSON, nullable=True)
    recording_urls = Column(JSON, nullable=True)
    status = Column(String(15), CheckConstraint("status IN ('pending', 'scheduled', 'completed', 'cancelled', 'expired')"), default='pending')
    scheduled_at = Column(DateTime, default=func.current_timestamp())
    interview_end_time = Column(DateTime, nullable=True)  # End time of the interview slot
    created_at = Column(DateTime, default=func.current_timestamp())
    resume_score = Column(DECIMAL(7, 6),nullable=True)
    summary_report_path = Column(String(500), nullable=True)
    

class UsersStats(Base):
    __tablename__ = 'users_stats'
    id = Column(Integer, primary_key=True)
    interview_id = Column(String(50), ForeignKey('interview_details_main.unique_id'), nullable=False)
    job_id = Column(Integer, ForeignKey('jd_details.job_id'), nullable=False)
    file_data = Column(LargeBinary, nullable=False)  # Use LargeBinary
    upload_date = Column(DateTime, default=func.current_timestamp())
    job_id = Column(Integer, ForeignKey('jd_details.job_id'), nullable=False)


class LLMs(Base):
    __tablename__ = 'llms'
    id = Column(Integer, primary_key=True, autoincrement=True)
    provider = Column(String(255), nullable=False)
    prefix = Column(String(255), nullable=False)
    model = Column(String(255), nullable=False)
    key = Column(String(255), nullable=False)
    is_default = Column(Boolean, default=False, nullable=False)
    created_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, nullable=False)
    updated_at = Column(DateTime, nullable=False)

class TechStack(Base):
    __tablename__ = 'tech_stack'
    id = Column(Integer, primary_key=True, autoincrement=True)
    tech_stack = Column(String(50), nullable=False)
    is_default = Column(Boolean, default=False, nullable=False)
    created_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, nullable=False)
    updated_at = Column(DateTime, nullable=False)

class AgentPrompts(Base):
    __tablename__ = 'agent_prompts'
    id = Column(Integer, primary_key=True, autoincrement=True)
    tech_stack_id = Column(Integer, ForeignKey('tech_stack.id'), nullable=False)
    agent_name = Column(String, nullable=False)
    prompt = Column(Text, nullable=True)
    placeholders = Column(JSON, nullable=False)
    created_at = Column(DateTime, default=func.current_timestamp(), nullable=False)
    type = Column(String, CheckConstraint("type IN ('ASSISTANT', 'MESSAGE', 'AGENT', 'TASK')"), nullable=True)

class TabSwitchingActivity(Base):
    __tablename__ = 'tab_switching_activity'
    id = Column(Integer, primary_key=True, autoincrement=True)
    interview_id = Column(String(50), ForeignKey('interview_details_main.unique_id'), nullable=False)
    screenshot_url = Column(String(500), nullable=False)  # Will store presigned URL
    blob_name = Column(String(500), nullable=False)  # Store blob path for regenerating URLs
    timestamp = Column(DateTime, nullable=False)  # When the tab switch occurred
    
    def __repr__(self):
        return f"<TabSwitchingActivity(interview_id='{self.interview_id}', timestamp='{self.timestamp}')>"    

def init_db():
    db = Database()
    Base.metadata.create_all(db._engine)
    db.close(db.get_session())