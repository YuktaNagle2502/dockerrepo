# main.py
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from routes.interview_routes import router as interview_router
from routes.summary_routes import router as summary_router
from routes.question_routes import router as question_router
from routes.speech_routes import router as speech_router
from routes.jd_routes import router as jd_router
from routes.llm_routes import router as llm_router
from routes.tech_stack_routes import router as tech_stack_router
from routes.agent_prompts_routes import router as agent_prompts_router
from routes.tab_switch_routes import router as tab_switch_router
from middleware.auth_middleware import KeycloakAuthMiddleware
import logging
import websockets
import asyncio
import os
from routes.recording_routes import router as recording_router
from opentelemetry import trace, metrics
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor
from opentelemetry.sdk.resources import SERVICE_NAME, Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
from opentelemetry.exporter.otlp.proto.http._log_exporter import OTLPLogExporter
from opentelemetry.sdk._logs import LoggerProvider
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry._logs import set_logger_provider
from opentelemetry.instrumentation.logging import LoggingInstrumentor
from opentelemetry.sdk._logs import LoggingHandler
from traceloop.sdk import Traceloop

os.environ["CREWAI_TRACING_ENABLED"] = "true"

app = FastAPI()
origins = [
   "*"
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
 
app.add_middleware(KeycloakAuthMiddleware)
 
app.include_router(interview_router, prefix="/interview")
app.include_router(summary_router, prefix="/interview-summary")
app.include_router(question_router, prefix="/question")
app.include_router(speech_router, prefix="/speech")
app.include_router(jd_router, prefix="/jd")
app.include_router(llm_router, prefix="/llm")
app.include_router(tech_stack_router, prefix="/tech-stack")
app.include_router(agent_prompts_router)
app.include_router(recording_router)
app.include_router(tab_switch_router, prefix="/tab-switching")
 
logging.getLogger().setLevel(logging.INFO)
 
# Configure OpenTelemetry
resource = Resource(attributes={
    SERVICE_NAME: "AI-Interviewer",
    "service.version": "1.0.0",
    "service.instance.id": "ai-interviewer-backend-instance"
})
# OTLP endpoint configuration
OTLP_ENDPOINT = os.getenv("OTLP_ENDPOINT", "https://otel.genai.yashtech.link")
 
# ========== TRACES CONFIGURATION ==========
# Configure Tracing
trace_provider = TracerProvider(resource=resource)
trace.set_tracer_provider(trace_provider)
 
# OTLP Trace Exporter
otlp_trace_exporter = OTLPSpanExporter(
    endpoint=f"{OTLP_ENDPOINT}/v1/traces",
    headers={},  # Add any required headers if needed
)
trace_provider.add_span_processor(BatchSpanProcessor(otlp_trace_exporter))
 
# ========== METRICS CONFIGURATION ==========
# Configure Metrics
otlp_metric_exporter = OTLPMetricExporter(
    endpoint=f"{OTLP_ENDPOINT}/v1/metrics",
    headers={},  # Add any required headers if needed
)
 
metric_reader = PeriodicExportingMetricReader(
    exporter=otlp_metric_exporter,
    export_interval_millis=30000,  # Export every 30 seconds
)
 
metrics_provider = MeterProvider(
    resource=resource,
    metric_readers=[metric_reader]
)
metrics.set_meter_provider(metrics_provider)
 
# Create a meter for custom metrics
meter = metrics.get_meter("ai-interviewer-backend-meter")
 
# Example custom metrics
request_counter = meter.create_counter(
    "http_requests_total",
    description="Total number of HTTP requests",
    unit="1"
)
 
request_duration = meter.create_histogram(
    "http_request_duration_seconds",
    description="HTTP request duration in seconds",
    unit="s"
)
 
# ========== LOGS CONFIGURATION ==========
# Configure Logging
otlp_log_exporter = OTLPLogExporter(
    endpoint=f"{OTLP_ENDPOINT}/v1/logs",
    headers={},
        # Add any required headers if needed
)
 
logger_provider = LoggerProvider(resource=resource)
set_logger_provider(logger_provider)
logger_provider.add_log_record_processor(BatchLogRecordProcessor(otlp_log_exporter))
 
# ✅ BIND to Python logging system
otel_handler = LoggingHandler(level=logging.NOTSET, logger_provider=logger_provider)
logging.getLogger().addHandler(otel_handler)
 
 
# Add log processor
logger_provider.add_log_record_processor(
    BatchLogRecordProcessor(otlp_log_exporter)
)
 
# Configure Python logging to work with OpenTelemetry
LoggingInstrumentor().instrument(set_logging_format=True,logging_level=logging.INFO)
 
# Set up Python logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("main")
 
# ========== INSTRUMENTATION ==========
# Instrument FastAPI & requests
FastAPIInstrumentor.instrument_app(app)
RequestsInstrumentor().instrument()
 
# Set the Traceloop base URL to point to your OTEL collector
os.environ["TRACELOOP_BASE_URL"] = "https://otel.genai.yashtech.link"
os.environ["OTEL_SERVICE_NAME"] = "llm-service"
 
# Initialize Traceloop - it will automatically use the TRACELOOP_BASE_URL
Traceloop.init(
disable_batch=True
)
 
# Serve index.html at root
@app.get("/", response_class=HTMLResponse)
async def serve_index():
    with open("index.html") as f:
        return HTMLResponse(content=f.read())
 
# Configure the streaming app URL using an environment variable
streaming_app_base_url = os.getenv("STREAMING_APP_URL", "ws://127.0.0.1:8002/frame-stream")
 
@app.websocket("/frame-stream/{interview_id}")
async def frame_stream_proxy(websocket: WebSocket, interview_id: str):
    print("frame_stream_proxy interview_id:",interview_id)
    await websocket.accept()
    print("WebSocket connected")
    streaming_app_url = f"{streaming_app_base_url}?interview_id={interview_id}"
    async with websockets.connect(streaming_app_url) as streaming_ws:
        try:
            while True:
                frame_data = await websocket.receive_bytes()
                print("Received frame data of size:", len(frame_data))
                await streaming_ws.send(frame_data)
                response = await streaming_ws.recv()
                await websocket.send_json(response)
        except WebSocketDisconnect:
            print("Client disconnected from main app")
        except websockets.exceptions.ConnectionClosed:
            print("Connection to streaming app closed")
        except Exception as e:
            print(f"Error in frame stream proxy: {e}")
            await websocket.send_json({
                "status": "error",
                "message": str(e)
            })
        finally:
            await websocket.close()
 
@app.get("/health")
async def health():
    logger.info("info log message for health ai interview")
    logger.warning("Test warning message health ai interview")
    logger.error("Test error message health ai interview")
    return {"status": "ok"}            
 