-- Database Migration Script
-- Execute this script in your main PostgreSQL database

-- Create custom enum type for difficulty level (if not exists)
DO $$ BEGIN
    CREATE TYPE difficulty_level AS ENUM ('easy', 'medium', 'hard');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create sequences
CREATE SEQUENCE IF NOT EXISTS domain_id_seq;
CREATE SEQUENCE IF NOT EXISTS jd_details_domain_id_seq;

-- Create category table
CREATE TABLE IF NOT EXISTS category (
    id serial4 NOT NULL,
    "name" varchar(50) NOT NULL,
    description text NULL,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP NULL,
    updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL,
    CONSTRAINT category_name_key UNIQUE (name),
    CONSTRAINT category_pkey PRIMARY KEY (id)
);

-- Create llms table
CREATE TABLE IF NOT EXISTS llms (
    id serial4 NOT NULL,
    provider varchar(50) NOT NULL,
    prefix varchar(50) NULL,
    model varchar(50) NOT NULL,
    "key" varchar NOT NULL,
    CONSTRAINT llms_pkey PRIMARY KEY (id)
);

-- Create tech_stack table
CREATE TABLE IF NOT EXISTS tech_stack (
    id int4 DEFAULT nextval('domain_id_seq'::regclass) NOT NULL,
    tech_stack varchar(50) NOT NULL,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT domain_pkey PRIMARY KEY (id)
);

-- Create agent_prompts table
CREATE TABLE IF NOT EXISTS agent_prompts (
    id serial4 NOT NULL,
    tech_stack_id serial4 NOT NULL,
    agent_name varchar NOT NULL,
    prompt text NULL,
    placeholders jsonb NULL,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "type" varchar NULL,
    CONSTRAINT agent_prompts_pkey PRIMARY KEY (id),
    CONSTRAINT fk_agent_prompts_tech_stack FOREIGN KEY (tech_stack_id) REFERENCES tech_stack(id)
);

-- Create jd_details table
CREATE TABLE IF NOT EXISTS jd_details (
    job_id serial4 NOT NULL,
    jd_questions jsonb NULL,
    jd_questions_text text NULL,
    jd_summary_text text NULL,
    jd_custom_questions_text bytea NULL,
    jd_custom_questions_path text NULL,
    jd_file_path text NULL,
    jd_file bytea NULL,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP NULL,
    job_title varchar(255) DEFAULT ''::character varying NOT NULL,
    job_location varchar(255) DEFAULT ''::character varying NOT NULL,
    jd_expiration timestamp NULL,
    llm_id serial4 NOT NULL,
    tech_stack_id int4 DEFAULT nextval('jd_details_domain_id_seq'::regclass) NOT NULL,
    CONSTRAINT jd_details_pkey PRIMARY KEY (job_id),
    CONSTRAINT fk_jd_details_domain_id FOREIGN KEY (tech_stack_id) REFERENCES tech_stack(id),
    CONSTRAINT fk_jd_details_llm_id FOREIGN KEY (llm_id) REFERENCES llms(id)
);

-- Create question_bank table
CREATE TABLE IF NOT EXISTS question_bank (
    id serial4 NOT NULL,
    category_id int4 NOT NULL,
    question_text text NOT NULL,
    difficulty difficulty_level NOT NULL,
    answer_text text NOT NULL,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP NULL,
    updated_at timestamp DEFAULT CURRENT_TIMESTAMP NULL,
    CONSTRAINT question_bank_pkey PRIMARY KEY (id),
    CONSTRAINT question_bank_category_id_fkey FOREIGN KEY (category_id) REFERENCES category(id) ON DELETE RESTRICT
);

-- Create interview_details_main table
CREATE TABLE IF NOT EXISTS interview_details_main (
    unique_id varchar(36) NOT NULL,
    full_name varchar(255) NOT NULL,
    age int4 NOT NULL,
    sex varchar(10) NOT NULL,
    phone varchar(15) NOT NULL,
    email_id varchar(55) NOT NULL,
    resume_path text NULL,
    resume bytea NULL,
    job_id int4 NOT NULL,
    user_image text NULL,
    user_image_path text NULL,
    interview_questions jsonb NULL,
    interview_answers jsonb NULL,
    "domain" varchar(255) DEFAULT NULL::character varying NULL,
    text_file bytea NULL,
    evaluation_result jsonb NULL,
    resume_score numeric(7, 6) NULL,
    status varchar(15) DEFAULT 'pending'::character varying NULL,
    scheduled_at timestamp DEFAULT CURRENT_TIMESTAMP NULL,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP NULL,
    recording_session_id varchar(100) NULL,
    recording_urls json NULL,
    interview_end_time timestamp NULL,
    CONSTRAINT interview_details_main_pkey PRIMARY KEY (unique_id),
    CONSTRAINT interview_details_main_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('scheduled'::character varying)::text, ('completed'::character varying)::text, ('cancelled'::character varying)::text, ('expired'::character varying)::text]))),
    CONSTRAINT interview_details_main_jd_details_fk FOREIGN KEY (job_id) REFERENCES jd_details(job_id)
);

-- Create users_stats table
CREATE TABLE IF NOT EXISTS users_stats (
    id serial4 NOT NULL,
    interview_id varchar(50) NOT NULL,
    job_id int4 NOT NULL,
    file_data_text text NULL,
    file_data bytea NULL,
    upload_date timestamp DEFAULT CURRENT_TIMESTAMP NULL,
    file_data_path text NULL,
    CONSTRAINT users_stats_pkey PRIMARY KEY (id),
    CONSTRAINT users_stats_interview_id_fkey FOREIGN KEY (interview_id) REFERENCES interview_details_main(unique_id),
    CONSTRAINT users_stats_job_id_fkey FOREIGN KEY (job_id) REFERENCES jd_details(job_id)
);