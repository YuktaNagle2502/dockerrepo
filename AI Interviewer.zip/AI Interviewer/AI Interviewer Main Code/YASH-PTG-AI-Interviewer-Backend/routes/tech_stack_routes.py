from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
from services.tech_stack_service import TechStackService
from database import Database
import jwt
from typing import Optional

router = APIRouter()

class TechStackCreate(BaseModel):
    tech_stack: str

class TechStackUpdate(BaseModel):
    tech_stack: str

def extract_email_from_token(authorization: str = None) -> str:
    """Extract email from JWT token"""
    if not authorization or not authorization.startswith("Bearer "):
        return None
    
    token = authorization.split(" ")[1]
    try:
        # Decode without verification for now - adjust based on your JWT setup
        payload = jwt.decode(token, options={"verify_signature": False})
        return payload.get("email") or payload.get("sub")
    except:
        return None

@router.post("/tech-stack")
async def create_tech_stack(tech_stack: TechStackCreate, authorization: Optional[str] = Header(None)):
    db = Database()
    service = TechStackService(db)
    try:
        created_by = extract_email_from_token(authorization)
        tech_stack_id = service.create_tech_stack(tech_stack.tech_stack, created_by)
        db.close(db.get_session())
        return {"id": tech_stack_id, "message": "Tech stack created successfully"}
    except ValueError as e:
        db.close(db.get_session())
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/tech-stack")
async def get_all_tech_stacks():
    db = Database()
    service = TechStackService(db)
    tech_stacks = service.get_all_tech_stacks()
    db.close(db.get_session())
    return [{"id": ts.id, "tech_stack": ts.tech_stack, "is_default": ts.is_default, "created_by": ts.created_by, "created_at": ts.created_at.isoformat() if ts.created_at else None, "updated_at": ts.updated_at.isoformat() if ts.updated_at else None} for ts in tech_stacks]

@router.get("/tech-stack/{tech_stack_id}")
async def get_tech_stack_by_id(tech_stack_id: int):
    db = Database()
    service = TechStackService(db)
    tech_stack = service.get_tech_stack_by_id(tech_stack_id)
    db.close(db.get_session())
    if not tech_stack:
        raise HTTPException(status_code=404, detail="Tech stack not found")
    return {"id": tech_stack.id, "tech_stack": tech_stack.tech_stack, "is_default": tech_stack.is_default, "created_by": tech_stack.created_by, "created_at": tech_stack.created_at.isoformat() if tech_stack.created_at else None, "updated_at": tech_stack.updated_at.isoformat() if tech_stack.updated_at else None}

@router.put("/tech-stack/{tech_stack_id}")
async def update_tech_stack(tech_stack_id: int, tech_stack: TechStackUpdate):
    db = Database()
    service = TechStackService(db)
    success = service.update_tech_stack(tech_stack_id, tech_stack.tech_stack)
    db.close(db.get_session())
    if not success:
        raise HTTPException(status_code=404, detail="Tech stack not found")
    return {"message": "Tech stack updated successfully"}

@router.delete("/tech-stack/{tech_stack_id}")
async def delete_tech_stack(tech_stack_id: int):
    db = Database()
    service = TechStackService(db)
    success = service.delete_tech_stack(tech_stack_id)
    db.close(db.get_session())
    if not success:
        raise HTTPException(status_code=404, detail="Tech stack not found")
    return {"message": "Tech stack deleted successfully"}