from fastapi import APIRouter, UploadFile, File, HTTPException, Form
from typing import Annotated
from services.interview_service import InterviewService
from database import Database
from datetime import datetime
from fastapi import BackgroundTasks
import pytz
 
router = APIRouter()
 
def validate_job_data(job_title: str, job_location: str, jd_expiration: str = None, jd_qualification_score: float = None):
    """Validate job data fields"""
    errors = []
   
    if not job_title or not job_title.strip():
        errors.append("Job title is required and cannot be empty")
   
    if not job_location or not job_location.strip():
        errors.append("Job location is required and cannot be empty")
   
    if jd_expiration:
        try:
            ist = pytz.timezone("Asia/Kolkata")
            expiration_datetime = datetime.strptime(jd_expiration, "%Y-%m-%d %H:%M:%S")
            expiration_datetime = ist.localize(expiration_datetime)
            current_time = datetime.now(ist)
            if expiration_datetime <= current_time:
                errors.append("Expiration datetime must be in the future")
        except ValueError:
            errors.append("Invalid expiration datetime format. Expected YYYY-MM-DD HH:MM:SS")
   
    if jd_qualification_score is not None:
        if not (0 <= jd_qualification_score <= 1):
            errors.append("Qualification score must be between 0 and 1")
        # Check for at most 2 decimal places
        if round(jd_qualification_score, 2) != jd_qualification_score:
            errors.append("Qualification score must have at most 2 decimal places")
   
    return errors
 
def validate_file(file: UploadFile, file_type: str = "pdf"):
    """Validate file (PDF or text)"""
    errors = []
   
    if not file:
        errors.append(f"{file_type.upper()} file is required")
        return errors
   
    if file_type == "pdf" and not file.content_type == "application/pdf":
        errors.append("Only PDF files are allowed")
    elif file_type == "text" and not file.content_type.startswith("text/"):
        errors.append("Only text files are allowed")
   
    if file.size == 0:
        errors.append(f"{file_type.upper()} file cannot be empty")
    elif file.size > 10 * 1024 * 1024:  # 10MB limit
        errors.append(f"{file_type.upper()} file size cannot exceed 10MB")
   
    if not file.filename:
        errors.append(f"{file_type.upper()} file must have a filename")
    elif file_type == "pdf" and not file.filename.lower().endswith('.pdf'):
        errors.append("JD file must have .pdf extension")
    elif file_type == "text" and not file.filename.lower().endswith('.txt'):
        errors.append("Custom questions file must have .txt extension")
   
    return errors
 
@router.post("/jd_questions_generation")
async def generate_job_question(
    background_tasks: BackgroundTasks,
    job_title: Annotated[str, Form()],
    job_location: Annotated[str, Form()],
    jd_file: UploadFile = File(...),
    jd_custom_questions_file: UploadFile = File(None),
    jd_summary_text: Annotated[str, Form()] = None,
    jd_expiration: Annotated[str, Form()] = None,
    llm_id: Annotated[str, Form()] = None,
    tech_stack_id: Annotated[str, Form()] = None,
    jd_qualification_score: Annotated[float, Form()] = None
):
    try:
        print("models:",llm_id)
        print("tech_stack_id:",tech_stack_id)
        # Validate job data
        job_errors = validate_job_data(job_title, job_location, jd_expiration, jd_qualification_score)
        if job_errors:
            raise HTTPException(status_code=400, detail={"errors": job_errors})
       
        # Validate PDF file
        file_errors = validate_file(jd_file, file_type="pdf")
        if file_errors:
            raise HTTPException(status_code=400, detail={"errors": file_errors})
       
        # Validate text file if provided
        if jd_custom_questions_file:
            text_file_errors = validate_file(jd_custom_questions_file, file_type="text")
            if text_file_errors:
                raise HTTPException(status_code=400, detail={"errors": text_file_errors})
       
        db = Database()
        service = InterviewService(db)
       
        jd_file_content = await jd_file.read()
        jd_custom_questions_content = await jd_custom_questions_file.read() if jd_custom_questions_file else None
        expiration_datetime = None
        if jd_expiration:
            expiration_datetime = datetime.strptime(jd_expiration, "%Y-%m-%d %H:%M:%S")
 
         # Create initial JD record and get job_id
        job_id = await service.create_initial_jd_record(
            jd_file_content, job_title.strip(), job_location.strip(),
            jd_summary_text=jd_summary_text, llm_id=llm_id,
            tech_stack_id=tech_stack_id, jd_expiration=expiration_datetime,
            jd_qualification_score=round(jd_qualification_score, 2) if jd_qualification_score is not None else None
        )
       
        if not job_id:
            raise HTTPException(status_code=500, detail="Failed to create initial JD record")
       
        # Add background task for processing
        background_tasks.add_task(
            service.process_jd_background_tasks,
            job_id,
            jd_custom_questions_file,
            jd_file_content,
            jd_custom_questions_content,
            job_title.strip(),
            job_location.strip()
        )
       
        db.close(db.get_session())
       
        return {
            "message": "JD record created successfully. Processing in background...",
            "job_id": job_id,
            "status": "processing",
            "jd_qualification_score": round(jd_qualification_score, 2) if jd_qualification_score is not None else None
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
 
@router.get("/{job_id}/questions")
async def get_jd_questions(job_id: int):
    db = Database()
    service = InterviewService(db)
    result, exists = await service.get_jd_questions(job_id)
    db.close(db.get_session())
    if not exists:
        raise HTTPException(status_code=404, detail=f"Job ID {job_id} not found")
    if result is None:
        raise HTTPException(status_code=404, detail=f"Job ID {job_id} exists but has no questions")
    return result
 
@router.get("/jobs")
async def get_all_jobs():
    """Get all job details (job_id, title, location, created_at)"""
    try:
        db = Database()
        service = InterviewService(db)
        jobs = service.get_all_jobs()
        db.close(db.get_session())
       
        if not jobs:
            return {"jobs": [], "message": "No jobs found"}
       
        return {"jobs": jobs}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
 
@router.get("/{job_id}")
async def get_jd(job_id: int):
    print("inside get jd method route")
    db = Database()
    service = InterviewService(db)
    result, exists = service.get_jd(job_id)
    print(" --- 109 --", result)
    # result = True
    # exists = False
    db.close(db.get_session())
    if not exists:
        raise HTTPException(status_code=404, detail=f"Job ID {job_id} not found")
    print("115 ----")
    return result
 
@router.post("/update/{job_id}")
async def update_job(
    job_id: int,
    job_title: Annotated[str, Form()],
    job_location: Annotated[str, Form()],
    jd_file: UploadFile = File(None),
    jd_custom_questions_file: UploadFile = File(None),
    jd_summary_text: Annotated[str, Form()] = None,
    llm_id: Annotated[str, Form()] = None,
    tech_stack_id: Annotated[str, Form()] = None,
    jd_expiration: Annotated[str, Form()] = None,
    jd_qualification_score: Annotated[float, Form()] = None
):
    """Update a job by job_id with validation"""
    try:
        # Validate job data
        errors = validate_job_data(job_title, job_location, jd_expiration, jd_qualification_score)
 
        # Validate PDF file if provided
        if jd_file and jd_file.filename:
            file_errors = validate_file(jd_file, file_type="pdf")
            errors.extend(file_errors)
       
        # Validate text file if provided
        if jd_custom_questions_file and jd_custom_questions_file.filename:
            text_file_errors = validate_file(jd_custom_questions_file, file_type="text")
            errors.extend(text_file_errors)
       
        if errors:
            raise HTTPException(status_code=400, detail={"errors": errors})
       
        db = Database()
        service = InterviewService(db)
       
        # Check if job exists
        _, exists = await service.get_jd_questions(job_id)
        if not exists:
            db.close(db.get_session())
            raise HTTPException(status_code=404, detail=f"Job ID {job_id} not found")
       
        # Read file content if provided
        jd_file_content = None
        if jd_file and jd_file.filename:
            try:
                jd_file_content = await jd_file.read()
                if len(jd_file_content) == 0:
                    raise ValueError("Uploaded JD file is empty")
            except Exception as e:
                db.close(db.get_session())
                raise HTTPException(status_code=400, detail=f"Failed to read JD file: {str(e)}")
       
        jd_custom_questions_content = None
        if jd_custom_questions_file and jd_custom_questions_file.filename:
            try:
                jd_custom_questions_content = await jd_custom_questions_file.read()
                if len(jd_custom_questions_content) == 0:
                    raise ValueError("Uploaded custom questions file is empty")
            except Exception as e:
                db.close(db.get_session())
                raise HTTPException(status_code=400, detail=f"Failed to read custom questions file: {str(e)}")
       
        expiration_datetime = None
        if jd_expiration:
            expiration_datetime = datetime.strptime(jd_expiration, "%Y-%m-%d %H:%M:%S")
        # Update job
        result = await service.update_job(jd_custom_questions_file,jd_file, job_id, job_title.strip(), job_location.strip(), jd_file_content, jd_custom_questions_content, jd_summary_text=jd_summary_text, llm_id=llm_id, tech_stack_id=tech_stack_id, jd_expiration=expiration_datetime, jd_qualification_score=round(jd_qualification_score, 2) if jd_qualification_score is not None else None)
        db.close(db.get_session())
       
        if not result["success"]:
            raise HTTPException(status_code=500, detail=result["error"])
       
        return {
            "message": f"Job with ID {job_id} successfully updated",
            "job_data": result["data"]
        }
    except HTTPException as e:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
 
@router.delete("/{job_id}")
async def delete_job(job_id: int):
    """Delete a job by job_id with validation"""
    try:
        db = Database()
        service = InterviewService(db)
       
        # Check if job exists before deletion
        _, exists = await service.get_jd_questions(job_id)
        if not exists:
            db.close(db.get_session())
            raise HTTPException(status_code=404, detail=f"Job ID {job_id} not found in jd_details table")
       
        # Check if job is referenced by any interviews
        session = db.get_session()
        from models import InterviewDetailsMain
        interview_count = session.query(InterviewDetailsMain).filter(
            InterviewDetailsMain.job_id == job_id
        ).count()
       
        if interview_count > 0:
            db.close(session)
            raise HTTPException(
                status_code=409,
                detail=f"Cannot delete job. {interview_count} interview(s) are associated with this job"
            )
       
        # Perform deletion
        success = service.delete_job(job_id)
        db.close(session)
       
        if not success:
            raise HTTPException(status_code=500, detail="Failed to delete job")
       
        return {
            "message": f"Job with ID {job_id} successfully deleted",
            "job_id": job_id
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
   
# @router.get("/jd_status/{job_id}")
# async def get_jd_status(job_id: int):
#     """Check the processing status of a JD"""
#     try:
#         db = Database()
#         session = db.get_session()
       
#         jd = session.query(JDDetails).filter(JDDetails.job_id == job_id).first()
#         if not jd:
#             raise HTTPException(status_code=404, detail="JD not found")
       
#         response = {
#             "job_id": job_id,
#             "status": getattr(jd, 'processing_status', 'unknown'),
#             "job_title": jd.job_title,
#             "job_location": jd.job_location,
#             "created_at": jd.created_at if hasattr(jd, 'created_at') else None,
#             "questions_count": len(jd.jd_questions) if jd.jd_questions else 0
#         }
       
#         if hasattr(jd, 'error_message') and jd.error_message:
#             response["error_message"] = jd.error_message
       
#         db.close(session)
#         return response
       
#     except HTTPException:
#         raise
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")