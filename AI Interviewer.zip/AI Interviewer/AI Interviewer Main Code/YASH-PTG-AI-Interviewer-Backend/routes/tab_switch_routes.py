from fastapi import APIRouter, Form, HTTPException, Depends
from typing import Annotated
from database import Database
from models import TabSwitchingActivity, InterviewDetailsMain
from datetime import datetime, timedelta
import base64
import pytz
import os
import boto3
from botocore.exceptions import ClientError
from utility.s3_utils import upload_file_to_s3, get_signed_s3_url, delete_s3_object

# Create router instance
router = APIRouter()

# AWS S3 Configuration
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION = os.getenv("AWS_REGION")
BUCKET_NAME = os.getenv("BUCKET_NAME")

# Initialize S3 client
s3_client = boto3.client(
    's3',
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY
)

def get_db():
    db = Database()
    try:
        yield db
    finally:
        db.close(db.get_session())

async def upload_screenshot_to_s3(screenshot_data: str, interview_id: str) -> tuple[str, str]:
    """Upload screenshot to AWS S3 and return the key and public URL"""
    try:
        # Generate a unique key with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        blob_name = f"ai-interviewer/suspicious-activity/tab_switching/{interview_id}/{timestamp}_screenshot.jpg"
        
        # Decode base64 screenshot data
        if screenshot_data.startswith('data:image'):
            screenshot_data = screenshot_data.split(',')[1]
        
        screenshot_bytes = base64.b64decode(screenshot_data)
        
        # Upload to S3
        s3_url = await upload_file_to_s3(blob_name, screenshot_bytes, content_type="image/jpeg")
        
        return blob_name, s3_url
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to upload screenshot: {str(e)}")

def generate_screenshot_presigned_url(blob_name: str, expiry_hours: int = 72) -> str:
    """
    Generate a presigned URL for the screenshot in S3
    """
    try:
        presigned_url = get_signed_s3_url(f"s3://{BUCKET_NAME}/{blob_name}", expiry_hours, method='get_object')
        return presigned_url
    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
        logger.error(f"Failed to generate presigned URL for {blob_name}: {error_code} - {error_message}")
        if error_code == 'NoSuchKey':
            raise HTTPException(status_code=404, detail=f"S3 object not found: s3://{BUCKET_NAME}/{blob_name}")
        elif error_code == 'AccessDenied':
            raise HTTPException(status_code=403, detail=f"Access denied to S3 object: {error_message}")
        raise HTTPException(status_code=500, detail=f"S3 error: {error_message}")
    except Exception as e:
        logger.error(f"Failed to generate presigned URL for {blob_name}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate presigned URL: {str(e)}")
    
@router.post("/report_tab_switching")
async def report_tab_switching(
    interview_id: Annotated[str, Form()],
    screenshot_data: Annotated[str, Form()],
    timestamp: Annotated[str, Form()]  # ISO format timestamp from frontend
):
    """
    Report suspicious tab switching activity with screenshot
    """
    try:
        # Parse timestamp from frontend
        switch_timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        switch_timestamp = switch_timestamp.replace(tzinfo=None)
        
        # Upload screenshot to S3
        blob_name, screenshot_url = await upload_screenshot_to_s3(screenshot_data, interview_id)
        
        # Save to database
        db = Database()
        try:
            session = db.get_session()
            
            # Verify interview exists
            interview_exists = session.query(InterviewDetailsMain).filter_by(unique_id=interview_id).first()
            if not interview_exists:
                raise HTTPException(status_code=404, detail="Interview not found")
            
            # Create tab switching record
            tab_switch_record = TabSwitchingActivity(
                interview_id=interview_id,
                screenshot_url=screenshot_url,
                blob_name=blob_name,
                timestamp=switch_timestamp
            )
            
            session.add(tab_switch_record)
            session.commit()
            
            return {
                "status": "success",
                "message": "Tab switching activity reported successfully",
                "activity_id": tab_switch_record.id,
                "screenshot_url": screenshot_url,
                "timestamp": switch_timestamp.isoformat()
            }
            
        except Exception as e:
            session.rollback()
            raise e
        finally:
            db.close(session)
            
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reporting tab switching: {str(e)}")

@router.get("/get_tab_switching_activities/{interview_id}")
async def get_tab_switching_activities(interview_id: str, db: Database = Depends(get_db)):
    """
    Get all tab switching activities for an interview
    """
    try:
        from services.tab_switching_service import TabSwitchingService
        service = TabSwitchingService(db)
        result = service.get_tab_switching_activities(interview_id)
        
        if not result["success"]:
            raise HTTPException(status_code=404, detail=result["message"])
            
        # Generate fresh presigned URLs for screenshots
        for activity in result["activities"]:
            if activity["blob_name"]:
                try:
                    activity["screenshot_url"] = generate_screenshot_presigned_url(activity["blob_name"])
                except HTTPException as he:
                    if he.status_code == 404:  # Handle NoSuchKey
                        logger.warning(f"Screenshot not found for blob_name: {activity['blob_name']}")
                        activity["screenshot_url"] = None
                    else:
                        raise
                except Exception as e:
                    logger.error(f"Error generating presigned URL for {activity['blob_name']}: {str(e)}")
                    activity["screenshot_url"] = None
                
        return {
            "status": "success",
            "interview_id": interview_id,
            "total_activities": result["total_activities"],
            "activities": result["activities"]
        }
        
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving activities: {str(e)}")
    
@router.get("/refresh_screenshot_url/{activity_id}")
async def refresh_screenshot_url(activity_id: int, db: Database = Depends(get_db)):
    """
    Refresh the presigned URL for a tab switching activity screenshot
    """
    try:
        from services.tab_switching_service import TabSwitchingService
        session = db.get_session()
        
        try:
            activity = session.query(TabSwitchingActivity).filter_by(id=activity_id).first()
            if not activity:
                raise HTTPException(status_code=404, detail="Activity not found")
                
            new_screenshot_url = generate_screenshot_presigned_url(activity.blob_name)
            
            service = TabSwitchingService(db)
            update_result = service.update_screenshot_url(activity_id, new_screenshot_url)
            
            if not update_result["success"]:
                raise HTTPException(status_code=500, detail=update_result["message"])
                
            return {
                "status": "success",
                "activity_id": activity_id,
                "new_screenshot_url": new_screenshot_url
            }
            
        finally:
            db.close(session)
            
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error refreshing screenshot URL: {str(e)}")

@router.delete("/delete_tab_switching_activity/{activity_id}")
async def delete_tab_switching_activity(activity_id: int, db: Database = Depends(get_db)):
    """
    Delete a tab switching activity and its associated screenshot from S3
    """
    try:
        from services.tab_switching_service import TabSwitchingService
        service = TabSwitchingService(db)
        result = service.delete_tab_switching_activity(activity_id)
        
        if not result["success"]:
            raise HTTPException(status_code=404, detail=result["message"])
            
        # Delete screenshot from S3
        if result["blob_name"]:
            try:
                delete_s3_object(result["blob_name"])
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to delete screenshot from S3: {str(e)}")
                
        return {
            "status": "success",
            "message": "Tab switching activity and screenshot deleted",
            "activity_id": activity_id
        }
        
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting activity: {str(e)}")

@router.get("/interview_suspicious_summary/{interview_id}")
async def interview_suspicious_summary(interview_id: str, db: Database = Depends(get_db)):
    """
    Get summary of suspicious activities for an interview
    """
    try:
        from services.tab_switching_service import TabSwitchingService
        service = TabSwitchingService(db)
        result = service.get_interview_suspicious_activities_summary(interview_id)
        
        if not result["success"]:
            raise HTTPException(status_code=404, detail=result["message"])
            
        return {
            "status": "success",
            "interview_id": interview_id,
            "total_tab_switches": result["total_tab_switches"],
            "has_suspicious_activity": result["has_suspicious_activity"],
            "first_switch_time": result["first_switch_time"],
            "last_switch_time": result["last_switch_time"]
        }
        
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving summary: {str(e)}")

@router.get("/get_activities_by_date_range/{interview_id}")
async def get_activities_by_date_range(
    interview_id: str, 
    start_date: str,
    end_date: str,
    db: Database = Depends(get_db)
):
    """
    Get tab switching activities for an interview within a date range
    """
    try:
        from services.tab_switching_service import TabSwitchingService
        
        # Parse dates
        try:
            start_datetime = datetime.fromisoformat(start_date.replace('Z', '+00:00')).replace(tzinfo=None)
            end_datetime = datetime.fromisoformat(end_date.replace('Z', '+00:00')).replace(tzinfo=None)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date format, use ISO format (e.g., 2023-10-01T00:00:00)")
            
        service = TabSwitchingService(db)
        result = service.get_activities_by_date_range(interview_id, start_datetime, end_datetime)
        
        if not result["success"]:
            raise HTTPException(status_code=404, detail=result["message"])
            
        # Generate fresh presigned URLs for screenshots
        for activity in result["activities"]:
            if activity["blob_name"]:
                activity["screenshot_url"] = generate_screenshot_presigned_url(activity["blob_name"])
            
        return {
            "status": "success",
            "interview_id": interview_id,
            "date_range": {
                "start": start_datetime.isoformat(),
                "end": end_datetime.isoformat()
            },
            "total_activities": len(result["activities"]),
            "activities": result["activities"]
        }
        
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving activities by date range: {str(e)}")

@router.get("/get_all_suspicious_interviews")
async def get_all_suspicious_interviews(db: Database = Depends(get_db)):
    """
    Get all interviews that have suspicious tab switching activity
    """
    try:
        from services.tab_switching_service import TabSwitchingService
        service = TabSwitchingService(db)
        result = service.get_all_interviews_with_suspicious_activity()
        
        if not result["success"]:
            raise HTTPException(status_code=500, detail=result["message"])
            
        return {
            "status": "success",
            "total_suspicious_interviews": result["total_interviews"],
            "interviews": result["interviews"]
        }
        
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving suspicious interviews: {str(e)}")

@router.get("/health")
async def health_check():
    """
    Health check endpoint for tab switching routes
    """
    try:
        # Test database connection
        db = Database()
        session = db.get_session()
        
        # Test query
        count = session.query(TabSwitchingActivity).count()
        db.close(session)
        
        # Test S3 connection (assume healthy if head_bucket is not permitted)
        s3_status = "connected"  # Avoid head_bucket due to potential lack of s3:ListBucket permission
        
        return {
            "status": "healthy",
            "service": "tab_switching_routes",
            "timestamp": datetime.now().isoformat(),
            "database_connection": "connected",
            "total_activities_in_db": count,
            "aws_s3_storage": s3_status,
            "available_endpoints": [
                "POST /report_tab_switching",
                "GET /get_tab_switching_activities/{interview_id}",
                "GET /refresh_screenshot_url/{activity_id}",
                "DELETE /delete_tab_switching_activity/{activity_id}",
                "GET /interview_suspicious_summary/{interview_id}",
                "GET /get_activities_by_date_range/{interview_id}",
                "GET /get_all_suspicious_interviews",
                "GET /health"
            ]
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }