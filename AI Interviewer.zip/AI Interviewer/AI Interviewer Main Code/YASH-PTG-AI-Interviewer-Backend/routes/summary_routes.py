from fastapi import APIRouter, Depends, HTTPException, Response
from fastapi.responses import StreamingResponse
from fastapi.templating import Jinja2Templates
from database import Database
from services.interview_service import InterviewService
from services.tab_switching_service import TabSwitchingService
from services.question_service import QuestionService
from typing import Dict, Any, Optional, List
from pydantic import BaseModel
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import requests
import base64
import io
import weasyprint
import boto3
import os
from botocore.exceptions import ClientError

router = APIRouter()
templates = Jinja2Templates(directory="templates")

# PDFShift API Key (consider using environment variables in production)
PDFSHIFT_API_KEY = "sk_e5a19adb97dcb9214dd126432901130f1391eda0"

# AWS S3 Configuration (consider using environment variables in production)
S3_BUCKET_NAME = os.getenv("BUCKET_NAME")
s3_client = boto3.client('s3')

# Pydantic model for report data
class ProcessedReportData(BaseModel):
    interview_id: str
    generated_date: str
    candidate_name: str
    candidate_position: str
    candidate_email: str
    candidate_phone: str
    candidate_age: int
    candidate_gender: str
    candidate_photo_base64: Optional[str] = None
    resume_score: float
    overall_score: float
    engagement_score: float
    engaged_count: int
    disengaged_count: int
    questions: List[Dict[str, Any]]
    communication_assessment: str
    grammar_assessment: str
    clarity_assessment: str
    overall_conclusion: str
    suspicious_activities_text: str
    suspicious_images: List[Dict[str, str]]
    engagement_timeline_data: List[Dict[str, Any]]
    question_scores_data: List[Dict[str, Any]]
    distribution_data: Dict[str, int]

# HTML Template with smaller charts
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interview Summary Report</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        @page {
            margin: 10mm;
            size: A4 portrait;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif; background-color: white; color: #333; line-height: 1.5; font-size: 14px; }
        .container { width: 100%; background: white; padding: 0; min-height: 100vh; box-sizing: border-box; }
        .header { border-bottom: 2px solid #e9ecef; padding-bottom: 12px; margin-bottom: 15px; }
        .header h1 { font-size: 28px; font-weight: 600; color: #2c3e50; margin-bottom: 5px; }
        .header-info { display: flex; justify-content: space-between; font-size: 12px; color: #000000; }
        .candidate-section { display: flex; gap: 15px; margin-bottom: 15px; padding: 12px; background: #f8f9fa; border-radius: 8px; }
        .candidate-photo { width: 150px; height: 180px; border-radius: 8px; background: #dee2e6; display: flex; align-items: center; justify-content: center; font-size: 12px; color: #6c757d; flex-shrink: 0; overflow: hidden; }
        .candidate-photo img { width: 100%; height: 100%; object-fit: cover; }
        .candidate-info h2 { font-size: 20px; font-weight: 600; color: #2c3e50; margin-bottom: 5px; }
        .candidate-info p { margin-bottom: 3px; font-size: 12px; color: #495057; }
        .resume-score { margin-left: auto; text-align: right; }
        .resume-score .score { font-size: 14px; font-weight: 600; color: #007bff; }
        .resume-score .label { font-size: 14px; color: #6c757d; }
        .metrics-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 15px; }
        .metric-card { padding: 12px; border-radius: 8px; text-align: center; border: 1px solid #e9ecef; }
        .metric-card.overall { background: #f3e5f5; border-color: #e1bee7; }
        .metric-card.engagement { background: #e8f5e8; border-color: #c8e6c9; }
        .metric-card.engaged { background: #fff3cd; border-color: #ffeeba; }
        .metric-card.disengaged { background: #f8d7da; border-color: #f5c6cb; }
        .metric-value { font-size: 28px; font-weight: 700; margin-bottom: 5px; }
        .metric-label { font-size: 12px; font-weight: 500; text-transform: uppercase; margin-bottom: 3px; }
        .metric-sublabel { font-size: 11px; color: #6c757d; }
        .charts-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-bottom: 12px; }
        .chart-card { padding: 10px; border: 1px solid #e9ecef; border-radius: 8px; background: white; }
        .chart-title { font-size: 12px; font-weight: 600; color: #495057; margin-bottom: 6px; display: flex; align-items: center; gap: 5px; }
        .chart-container { height: 100px; position: relative; }
        canvas { max-height: 100%; width: 100%; }
        .section { margin-bottom: 15px; border: 1px solid #e9ecef; border-radius: 8px; overflow: hidden; }
        .section-header { background: #f8f9fa; padding: 10px 12px; border-bottom: 1px solid #e9ecef; display: flex; align-items: center; gap: 8px; }
        .section-icon { width: 16px; height: 16px; border-radius: 50%; background: #007bff; }
        .section-title { font-size: 16px; font-weight: 600; color: #2c3e50; }
        .section-subtitle { font-size: 12px; color: #6c757d; margin-left: auto; }
        .section-content { padding: 12px; }
        .questions-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
        .question-card { border: 1px solid #e9ecef; border-radius: 6px; overflow: hidden; }
        .question-header { background: #f8f9fa; padding: 8px 10px; border-bottom: 1px solid #e9ecef; display: flex; justify-content: space-between; align-items: center; }
        .question-title { font-size: 13px; font-weight: 600; color: #495057; }
        .question-score { font-size: 15px; font-weight: 600; color: #007bff; }
        .question-content { padding: 10px; }
        .question-text { font-size: 12px; font-weight: 600; color: #2c3e50; margin-bottom: 6px; }
        .question-desc { font-size: 11px; color: #6c757d; margin-bottom: 8px; line-height: 1.4; }
        .answer-section { margin-bottom: 8px; }
        .answer-label { font-size: 11px; font-weight: 600; color: #495057; margin-bottom: 3px; }
        .answer-text { font-size: 11px; color: #6c757d; font-style: italic; margin-bottom: 6px; }
        .assessment-content { background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; padding: 8px; }
        .assessment-text { font-size: 11px; line-height: 1.4; color: #495057; }
        .final-assessment { margin-bottom: 0; background-color: #f8f9fa; }
        .assessment-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
        .assessment-card { border: 1px solid #e9ecef; border-radius: 6px; overflow: hidden; }
        .assessment-header { padding: 8px 10px; border-bottom: 1px solid #e9ecef; display: flex; align-items: center; gap: 8px; }
        .assessment-header.communication { background: #e3f2fd; }
        .assessment-header.clarity { background: #f3e5f5; }
        .assessment-header.grammar { background: #e8f5e8; }
        .assessment-header.conclusion { background: #fff3cd; }
        .assessment-icon { width: 14px; height: 14px; border-radius: 50%; background: #007bff; }
        .assessment-title { font-size: 13px; font-weight: 600; color: #2c3e50; }
        .assessment-body { padding: 10px; }
        .assessment-desc { font-size: 11px; color: #6c757d; line-height: 1.4; }
        .warning-box { background: #fff3cd; border: 1px solid #ffeeba; border-radius: 4px; padding: 8px; margin-bottom: 8px; }
        .warning-text { font-size: 11px; color: #856404; display: flex; align-items: center; gap: 5px; }
        .icon-circle { width: 14px; height: 14px; border-radius: 50%; display: inline-block; }
        .icon-warning { background: #ffc107; }
        .suspicious-images-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-top: 10px; }
        .suspicious-image-card { border: 1px solid #e9ecef; border-radius: 6px; overflow: hidden; }
        .suspicious-image-header { background: #f8f9fa; padding: 8px 10px; border-bottom: 1px solid #e9ecef; }
        .suspicious-image-title { font-size: 13px; font-weight: 600; color: #495057; }
        .suspicious-image-content { padding: 10px; }
        .suspicious-image { width: 100%; max-height: 150px; object-fit: contain; }
        .footer { margin-top: 12px; padding-top: 8px; border-top: 1px solid #e9ecef; text-align: center; }
        .footer .footer-content { display: flex; align-items: center; justify-content: center; gap: 10px; color: #b4b4b8; }
        .footer .footer-content span { font-size: 8px; }
        @media print {
            body { background: white; margin: 0; }
            .container { width: 100%; padding: 0; box-shadow: none; }
            .final-assessment { background-color: transparent; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Interview Summary Report</h1>
            <div class="header-info">
                <span>Interview ID: {{interview_id}} | Generated: {{generated_date}}</span>
            </div>
        </div>
        <div class="candidate-section">
            <div class="candidate-photo">
                {% if candidate_photo_base64 %}
                    <img src="data:image/jpeg;base64,{{candidate_photo_base64}}" alt="Candidate Photo">
                {% else %}
                    Photo N/A
                {% endif %}
            </div>
            <div class="candidate-info">
                <h2>{{candidate_name}}</h2>
                <p><strong>{{candidate_position}}</strong></p>
                <p><strong>Email:</strong> {{candidate_email}}</p>
                <p><strong>Phone:</strong> {{candidate_phone}}</p>
                <p><strong>Age:</strong> {{candidate_age}}</p>
                <p><strong>Gender:</strong> {{candidate_gender}}</p>
            </div>
            <div class="resume-score">
                <div class="score"><span class="label">Resume Score </span> {{resume_score}}%</div>
            </div>
        </div>
        <div class="metrics-grid">
            <div class="metric-card overall">
                <div class="metric-value" style="color: #9c27b0;">{{overall_score}}%</div>
                <div class="metric-label" style="color: #9c27b0;">Overall Score</div>
                <div class="metric-sublabel">Performance Rating</div>
            </div>
            <div class="metric-card engagement">
                <div class="metric-value" style="color: #2e7d32;">{{engagement_score}}%</div>
                <div class="metric-label" style="color: #2e7d32;">Engagement</div>
                <div class="metric-sublabel">Average Score</div>
            </div>
            <div class="metric-card engaged">
                <div class="metric-value" style="color: #f57c00;">{{engaged_count}}</div>
                <div class="metric-label" style="color: #f57c00;">Engaged</div>
                <div class="metric-sublabel">Total Frames</div>
            </div>
            <div class="metric-card disengaged">
                <div class="metric-value" style="color: #d32f2f;">{{disengaged_count}}</div>
                <div class="metric-label" style="color: #d32f2f;">Disengaged</div>
                <div class="metric-sublabel">Total Frames</div>
            </div>
        </div>
        <div class="charts-grid">
            <div class="chart-card">
                <div class="chart-title">
                    <span class="icon-circle" style="background: #007bff;"></span>
                    Engagement Timeline
                </div>
                <div class="chart-container">
                    <canvas id="engagementTimelineChart"></canvas>
                </div>
            </div>
            <div class="chart-card">
                <div class="chart-title">
                    <span class="icon-circle" style="background: #28a745;"></span>
                    Question Scores
                </div>
                <div class="chart-container">
                    <canvas id="questionScoresChart"></canvas>
                </div>
            </div>
            <div class="chart-card">
                <div class="chart-title">
                    <span class="icon-circle" style="background: #007bff;"></span>
                    Distribution
                </div>
                <div class="chart-container">
                    <canvas id="distributionChart"></canvas>
                </div>
            </div>
        </div>
        <script>
            const engagementTimelineCtx = document.getElementById('engagementTimelineChart').getContext('2d');
            new Chart(engagementTimelineCtx, {
                type: 'line',
                data: {
                    labels: [{% for item in engagement_timeline_data %}'{{item.time}}'{% if not loop.last %},{% endif %}{% endfor %}],
                    datasets: [{
                        label: 'Engagement Rate (%)',
                        data: [{% for item in engagement_timeline_data %}{{item.engagement_rate}}{% if not loop.last %},{% endif %}{% endfor %}],
                        borderColor: '#2196F3',
                        backgroundColor: 'rgba(33, 150, 243, 0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        pointBackgroundColor: '#2196F3',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: { 
                            beginAtZero: true, 
                            max: 100,
                            min: 0,
                            ticks: {
                                stepSize: 25,
                                callback: function(value) { return value; },
                                font: { size: 8 }
                            },
                            grid: { 
                                color: 'rgba(0,0,0,0.1)',
                                drawBorder: false
                            },
                            border: { display: false }
                        },
                        x: { 
                            grid: { 
                                color: 'rgba(0,0,0,0.1)',
                                drawBorder: false
                            },
                            ticks: { 
                                font: { size: 7 },
                                maxRotation: 0,
                                minRotation: 0
                            },
                            border: { display: false }
                        }
                    },
                    plugins: { 
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: 'rgba(0,0,0,0.8)',
                            titleColor: 'white',
                            bodyColor: 'white',
                            titleFont: { size: 8 },
                            bodyFont: { size: 8 }
                        }
                    },
                    elements: {
                        point: {
                            hoverRadius: 6
                        }
                    }
                }
            });
            
            const questionScoresCtx = document.getElementById('questionScoresChart').getContext('2d');
            new Chart(questionScoresCtx, {
                type: 'bar',
                data: {
                    labels: [{% for item in question_scores_data %}'{{item.question}}'{% if not loop.last %},{% endif %}{% endfor %}],
                    datasets: [{
                        label: 'Question Scores',
                        data: [{% for item in question_scores_data %}{{item.score}}{% if not loop.last %},{% endif %}{% endfor %}],
                        backgroundColor: '#4CAF50',
                        borderColor: '#4CAF50',
                        borderWidth: 0,
                        borderRadius: 4,
                        borderSkipped: false
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: { 
                            beginAtZero: true, 
                            max: 10,
                            min: 0,
                            ticks: {
                                stepSize: 2,
                                callback: function(value) { return value; },
                                font: { size: 8 }
                            },
                            grid: { 
                                color: 'rgba(0,0,0,0.1)',
                                drawBorder: false
                            },
                            border: { display: false }
                        },
                        x: { 
                            grid: { 
                                display: false
                            },
                            ticks: { 
                                font: { size: 8 }
                            },
                            border: { display: false }
                        }
                    },
                    plugins: { 
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: 'rgba(0,0,0,0.8)',
                            titleColor: 'white',
                            bodyColor: 'white',
                            titleFont: { size: 8 },
                            bodyFont: { size: 8 }
                        }
                    }
                }
            });
            
            const distributionCtx = document.getElementById('distributionChart').getContext('2d');
            new Chart(distributionCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Engaged', 'Disengaged'],
                    datasets: [{
                        data: [{{distribution_data.engaged}}, {{distribution_data.disengaged}}],
                        backgroundColor: ['#2196F3', '#4CAF50'],
                        borderColor: ['#ffffff', '#ffffff'],
                        borderWidth: 2,
                        cutout: '50%'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { 
                        legend: { 
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0,0,0,0.8)',
                            titleColor: 'white',
                            bodyColor: 'white',
                            titleFont: { size: 8 },
                            bodyFont: { size: 8 }
                        }
                    }
                }
            });
        </script>
        <div class="section">
            <div class="section-header">
                <span class="section-icon" style="background: #dc3545;"></span>
                <span class="section-title">Suspicious Activities</span>
                <span class="section-subtitle">Detected suspicious activities</span>
            </div>
            <div class="section-content">
                <div class="warning-box">
                    <div class="warning-text">
                        <span class="icon-circle icon-warning"></span>
                        {{suspicious_activities_text}}
                    </div>
                </div>
                {% if suspicious_images %}
                <div class="suspicious-images-grid">
                    {% for image in suspicious_images %}
                    <div class="suspicious-image-card">
                        <div class="suspicious-image-header">
                            <div class="suspicious-image-title">Tab Switch at {{image.timestamp}}</div>
                        </div>
                        <div class="suspicious-image-content">
                            <img class="suspicious-image" src="data:image/jpeg;base64,{{image.base64}}" alt="Tab Switch Screenshot">
                        </div>
                    </div>
                    {% endfor %}
                </div>
                {% endif %}
            </div>
        </div>
        <div class="section">
            <div class="section-header">
                <span class="section-icon" style="background: #007bff;"></span>
                <span class="section-title">Detailed Question Analysis</span>
                <span class="section-subtitle">Performance breakdown for each interview question</span>
            </div>
            <div class="section-content">
                <div class="questions-grid">
                    {% for question in questions %}
                    <div class="question-card">
                        <div class="question-header">
                            <div class="question-title">Question {{loop.index}}</div>
                            <div class="question-score">{{question.score}}%</div>
                        </div>
                        <div class="question-content">
                            <div class="question-text">QUESTION</div>
                            <div class="question-desc">{{question.question_text}}</div>
                            <div class="answer-section">
                                <div class="answer-label">CANDIDATE ANSWER</div>
                                <div class="answer-text">{{question.answer}}</div>
                            </div>
                            <div class="assessment-content">
                                <div class="assessment-text">{{question.assessment}}</div>
                            </div>
                        </div>
                    </div>
                    {% endfor %}
                </div>
            </div>
        </div>
        <div class="section final-assessment">
            <div class="section-header">
                <span class="section-icon" style="background: #6f42c1;"></span>
                <span class="section-title">Final Assessment</span>
                <span class="section-subtitle">Comprehensive evaluation summary</span>
            </div>
            <div class="section-content">
                <div class="assessment-grid">
                    <div class="assessment-card">
                        <div class="assessment-header communication">
                            <span class="assessment-icon"></span>
                            <span class="assessment-title">Communication Skills</span>
                        </div>
                        <div class="assessment-body">
                            <div class="assessment-desc">{{communication_assessment}}</div>
                        </div>
                    </div>
                    <div class="assessment-card">
                        <div class="assessment-header grammar">
                            <span class="assessment-icon"></span>
                            <span class="assessment-title">Grammar & Language</span>
                        </div>
                        <div class="assessment-body">
                            <div class="assessment-desc">{{grammar_assessment}}</div>
                        </div>
                    </div>
                    <div class="assessment-card">
                        <div class="assessment-header clarity">
                            <span class="assessment-icon"></span>
                            <span class="assessment-title">Clarity & Expression</span>
                        </div>
                        <div class="assessment-body">
                            <div class="assessment-desc">{{clarity_assessment}}</div>
                        </div>
                    </div>
                    <div class="assessment-card">
                        <div class="assessment-header conclusion">
                            <span class="assessment-icon"></span>
                            <span class="assessment-title">Overall Conclusion</span>
                        </div>
                        <div class="assessment-body">
                            <div class="assessment-desc">{{overall_conclusion}}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <br>
        <div class="footer">
            <div class="footer-content">
                <span class="bullet">•</span>
                <span class="text-sm">Generated on {{generated_date}}</span>
                <span class="bullet">•</span>
                <span class="text-sm">AI-Powered Interview Analysis</span>
                <span class="bullet">•</span>
                <span class="text-sm">Confidential Report</span>
            </div>
        </div>
    </div>
</body>
</html>
"""

def get_db():
    db = Database()
    try:
        yield db
    finally:
        db.close(db.get_session())

def generate_interview_timestamps(num_segments: int, start_time: str = "10:33:24 AM") -> List[str]:
    """Generate realistic interview timestamps for engagement timeline."""
    try:
        start_dt = datetime.strptime(start_time, "%I:%M:%S %p")
        timestamps = []
        current_time = start_dt
        for i in range(num_segments):
            timestamps.append(current_time.strftime("%I:%M:%S %p"))
            interval = 45 + (i * 15)
            current_time += timedelta(seconds=interval)
        return timestamps
    except Exception as e:
        print(f"Timestamp generation error: {str(e)}")
        return [f"10:33:{24 + i*30:02d} AM" for i in range(num_segments)]

def calculate_engagement_metrics(interview_status: List[Dict]) -> Dict[str, Any]:
    """Calculate engagement metrics from interview status."""
    try:
        total_engaged = sum(entry.get('Engaged_Frames', 0) for entry in interview_status)
        total_disengaged = sum(entry.get('Disengaged_Frames', 0) for entry in interview_status)
        total_frames = total_engaged + total_disengaged
        engagement_percentage = (total_engaged / total_frames * 100) if total_frames > 0 else 0
        
        num_segments = len(interview_status)
        timestamps = generate_interview_timestamps(num_segments)
       
        engagement_timeline = [
            {
                'time': timestamps[i] if i < len(timestamps) else f"Segment {i+1}",
                'engagement_rate': round(
                    (entry.get('Engaged_Frames', 0) /
                     (entry.get('Engaged_Frames', 0) + entry.get('Disengaged_Frames', 0)) * 100), 1
                ) if (entry.get('Engaged_Frames', 0) + entry.get('Disengaged_Frames', 0)) > 0 else 0
            }
            for i, entry in enumerate(interview_status)
        ]
       
        return {
            'engagement_score': round(engagement_percentage, 1),
            'engaged_count': total_engaged,
            'disengaged_count': total_disengaged,
            'engagement_timeline': engagement_timeline,
            'distribution': {'engaged': total_engaged, 'disengaged': total_disengaged}
        }
    except Exception as e:
        print(f"Engagement metrics error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Engagement metrics error: {str(e)}")

def process_questions_data(interview_evaluation: Dict) -> List[Dict[str, Any]]:
    """Process questions data from evaluation."""
    try:
        return [
            {
                'question_text': q.get('question', 'Question not available'),
                'answer': q.get('user_answer', 'No answer provided'),
                'score': round(q.get('weighted_score', 0) * 100, 1),
                'assessment': q.get('ai_comment', 'No assessment available')
            }
            for q in interview_evaluation.get('question_scores', [])
        ]
    except Exception as e:
        print(f"Questions data error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Questions data error: {str(e)}")

def fetch_s3_image(blob_name: str) -> Optional[str]:
    """Fetch image from S3 and encode to base64."""
    try:
        response = s3_client.get_object(Bucket=S3_BUCKET_NAME, Key=blob_name)
        image_data = response['Body'].read()
        return base64.b64encode(image_data).decode('utf-8')
    except ClientError as e:
        print(f"S3 image fetch error for {blob_name}: {str(e)}")
        return None

def format_suspicious_activities(tab_switching: Dict) -> tuple[str, List[Dict[str, str]]]:
    """Format suspicious activities text and images."""
    try:
        if not tab_switching.get('success', False) or tab_switching.get('total_activities', 0) == 0:
            return "No suspicious activities detected", []
       
        text = f"Tab switching detected: {tab_switching.get('total_activities')} instance(s)"
        images = []
        for activity in tab_switching.get('activities', []):
            blob_name = activity.get('blob_name')
            if blob_name:
                base64_image = fetch_s3_image(blob_name)
                if base64_image:
                    images.append({
                        'base64': base64_image,
                        'timestamp': activity.get('timestamp', 'N/A')
                    })
       
        return text, images
    except Exception as e:
        print(f"Suspicious activities error: {str(e)}")
        return "Error processing suspicious activities", []

def download_and_encode_image(image_url: str) -> Optional[str]:
    """Download and encode image to base64."""
    try:
        response = requests.get(image_url, timeout=10)
        response.raise_for_status()
        return base64.b64encode(response.content).decode('utf-8')
    except Exception as e:
        print(f"Image download error: {str(e)}")
        return None

def transform_api_data_to_report(api_data: Dict[str, Any]) -> ProcessedReportData:
    """Transform API data to report format."""
    try:
        candidate = api_data.get('interview_candidate_details', {}).get('data', {})
        evaluation = api_data.get('interview_evaluation', {})
        status = api_data.get('interview_status', [])
        tab_switching = api_data.get('tab_switching_activities', {})
       
        engagement = calculate_engagement_metrics(status)
        questions = process_questions_data(evaluation)
        photo_base64 = download_and_encode_image(candidate.get('user_image_url')) if candidate.get('user_image_url') else None
        suspicious_text, suspicious_images = format_suspicious_activities(tab_switching)
       
        return ProcessedReportData(
            interview_id=candidate.get('unique_id', 'N/A'),
            generated_date=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            candidate_name=candidate.get('full_name', 'N/A'),
            candidate_position=candidate.get('job_title', 'N/A'),
            candidate_email=candidate.get('email_id', 'N/A'),
            candidate_phone=candidate.get('phone', 'N/A'),
            candidate_age=candidate.get('age', 'N/A'),
            candidate_gender=candidate.get('sex', 'N/A'),
            candidate_photo_base64=photo_base64,
            resume_score=round(candidate.get('resume_score', 0) * 100, 1),
            overall_score=round(evaluation.get('overall_score', 0) * 100, 1),
            engagement_score=engagement['engagement_score'],
            engaged_count=engagement['engaged_count'],
            disengaged_count=engagement['disengaged_count'],
            questions=questions,
            communication_assessment=evaluation.get('communication_skills', 'Assessment not available'),
            grammar_assessment=evaluation.get('grammatical_correctness', 'Assessment not available'),
            clarity_assessment=evaluation.get('clarity', 'Assessment not available'),
            overall_conclusion=evaluation.get('conclusion', 'Conclusion not available'),
            suspicious_activities_text=suspicious_text,
            suspicious_images=suspicious_images,
            engagement_timeline_data=engagement['engagement_timeline'],
            question_scores_data=[{'question': f"Q{i+1}", 'score': q['score']} for i, q in enumerate(questions)],
            distribution_data=engagement['distribution']
        )
    except Exception as e:
        print(f"Data transformation error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Data transformation error: {str(e)}")

def create_matplotlib_chart_base64(data_points: list, labels: list, title: str, chart_type: str):
    """
    Generates a chart image with Matplotlib and returns a Base64 encoded string.
    
    Args:
        data_points (list): The numerical data for the chart.
        labels (list): The labels for the data points.
        title (str): The title of the chart.
        chart_type (str): The type of chart ('line', 'bar', 'doughnut').
    
    Returns:
        str: A Base64 encoded string of the chart image.
    """
    plt.ioff()
    fig, ax = plt.subplots(figsize=(4, 3))
    
    if chart_type == 'line':
        ax.plot(labels, data_points, marker='o', color='#2196F3', linewidth=2, markersize=4)
        ax.set_title(title, fontsize=12)
        ax.set_ylim(0, 100)
        ax.tick_params(axis='both', labelsize=8)
    elif chart_type == 'bar':
        ax.bar(labels, data_points, color='#4CAF50')
        ax.set_title(title, fontsize=12)
        ax.set_ylim(0, 10)
        ax.tick_params(axis='both', labelsize=8)
    elif chart_type == 'doughnut':
        colors = ["#2196F3", "#4CAF50"]
        ax.pie(data_points, labels=labels, autopct='%1.1f%%', startangle=90, colors=colors, textprops={'fontsize': 8})
        centre_circle = plt.Circle((0,0),0.70,fc='white')
        fig.gca().add_artist(centre_circle)
        ax.set_title(title, fontsize=12)
    
    plt.tight_layout()
    
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png', dpi=150)
    plt.close(fig)
    
    buffer.seek(0)
    base64_encoded = base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    return base64_encoded

def generate_pdf_from_template(report_data: ProcessedReportData) -> bytes:
    """Generate PDF from HTML template using WeasyPrint."""
    try:
        data = report_data.__dict__
        engagement_chart_base64 = create_matplotlib_chart_base64(
            data_points=[item['engagement_rate'] for item in data.get('engagement_timeline_data', [])],
            labels=[item['time'] for item in data.get('engagement_timeline_data', [])],
            title='Engagement Timeline',
            chart_type='line'
        )
        
        question_chart_base64 = create_matplotlib_chart_base64(
            data_points=[item['score'] for item in data.get('question_scores_data', [])],
            labels=[item['question'] for item in data.get('question_scores_data', [])],
            title='Question Scores',
            chart_type='bar'
        )
        
        distribution_data = data.get('distribution_data', {})
        distribution_chart_base64 = create_matplotlib_chart_base64(
            data_points=[distribution_data.get('engaged', 0), distribution_data.get('disengaged', 0)],
            labels=['Engaged', 'Disengaged'],
            title='Distribution',
            chart_type='doughnut'
        )
        data["engagement_chart_base64"] = engagement_chart_base64
        data["question_chart_base64"] = question_chart_base64
        data["distribution_chart_base64"] = distribution_chart_base64

        html_content = templates.get_template("interview_report.html").render(data)
       
        pdf_buffer = io.BytesIO()
        weasyprint.HTML(string=html_content).write_pdf(pdf_buffer)
        pdf_buffer.seek(0)
        return pdf_buffer.getvalue()
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF generation error: {str(e)}")

@router.get("/summary_data/{interview_id}")
async def summary_data(interview_id: str, db: Database = Depends(get_db)):
    try:
        tab_switching_service = TabSwitchingService(db)
        interview_service = InterviewService(db)
        question_service = QuestionService(db)

        result1 = tab_switching_service.get_tab_switching_activities(interview_id)
        result2 = interview_service.get_status_data(interview_id)
        result3 = interview_service.get_interview_candidate_details(interview_id)
        result4 = question_service.evaluate_interview(interview_id)

        api_data = {
            "tab_switching_activities": result1,
            "interview_status": result2,
            "interview_candidate_details": result3,
            "interview_evaluation": result4
        }

        report_data = transform_api_data_to_report(api_data)
        pdf_bytes = generate_pdf_from_template(report_data)

        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=interview_report_{interview_id}.pdf"}
        )

    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating summary report: {str(e)}")