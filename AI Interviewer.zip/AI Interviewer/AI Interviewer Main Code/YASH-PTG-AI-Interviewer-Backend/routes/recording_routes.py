import atexit
from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse, Response
import os
import datetime
import asyncio
from concurrent.futures import ThreadPoolExecutor
import logging
from typing import Optional, Dict, List
import json
import uuid
import threading
from services.interview_service import InterviewService
from database import Database
import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from botocore.config import Config
import base64
from utility.s3_utils import upload_file_to_s3, get_signed_s3_url, check_s3_object_exists

# Initialize router
router = APIRouter(prefix="/recording", tags=["recording"])

# AWS S3 Configuration
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION = os.getenv("AWS_REGION")
BUCKET_NAME = os.getenv("BUCKET_NAME")

# Initialize S3 client with retry configuration
s3_config = Config(
    retries={
        'max_attempts': 3,
        'mode': 'adaptive'
    },
    connect_timeout=300,
    read_timeout=300
)

s3_client = boto3.client(
    's3',
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    config=s3_config
)

# Thread pool for async operations
executor = ThreadPoolExecutor(max_workers=4)

# Thread-safe session management for upload sessions
session_lock = threading.RLock()
active_upload_sessions: Dict[str, Dict] = {}

# Configuration
MAX_UPLOAD_SESSION_HOURS = 3  # Maximum time for an upload session
CLEANUP_INTERVAL_HOURS = 24   # How often to cleanup old sessions

def get_upload_session(unique_id: str) -> Optional[Dict]:
    """Thread-safe session retrieval"""
    with session_lock:
        return active_upload_sessions.get(unique_id)

def add_upload_session(unique_id: str, session: Dict) -> bool:
    """Thread-safe session addition"""
    with session_lock:
        if unique_id in active_upload_sessions:
            existing = active_upload_sessions[unique_id]
            logging.warning(f"Upload session already exists for {unique_id}, replacing it")
        
        active_upload_sessions[unique_id] = session
        logging.info(f"Added upload session for {unique_id}. Total active sessions: {len(active_upload_sessions)}")
        return True

def remove_upload_session(unique_id: str) -> bool:
    """Thread-safe session removal"""
    with session_lock:
        if unique_id in active_upload_sessions:
            del active_upload_sessions[unique_id]
            logging.info(f"Removed upload session for {unique_id}. Remaining sessions: {len(active_upload_sessions)}")
            return True
        return False

def update_upload_session(unique_id: str, updates: Dict) -> bool:
    """Thread-safe session update"""
    with session_lock:
        if unique_id in active_upload_sessions:
            active_upload_sessions[unique_id].update(updates)
            return True
        return False

async def upload_recording_to_s3(recording_content: bytes, unique_id: str) -> str:
    """Upload recording to S3 and return the S3 URL"""
    try:
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        key = f"ai-interviewer/recordings/{unique_id}_{timestamp}.webm"
        logging.info(f"Uploading recording to S3 with key: {key}")
        s3_url = await upload_file_to_s3(key, recording_content, content_type="video/webm")
        logging.info(f"Recording uploaded successfully: {s3_url}")
        return s3_url
    except Exception as e:
        logging.error(f"Error uploading recording to S3 for unique_id {unique_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to upload recording: {str(e)}")

@router.post("/generate-upload-url")
async def generate_upload_url(request: dict = {}):
    """Generate a presigned URL for direct S3 upload"""
    try:
        unique_id = request.get("unique_id")
        if not unique_id:
            raise HTTPException(status_code=400, detail="unique_id is required")
        
        if not isinstance(unique_id, str) or len(unique_id) < 3:
            raise HTTPException(status_code=400, detail="Invalid unique_id format")
        
        existing_session = get_upload_session(unique_id)
        if existing_session and existing_session.get("status") == "active":
            created_at = datetime.datetime.fromisoformat(existing_session["created_at"])
            if datetime.datetime.now() - created_at < datetime.timedelta(hours=MAX_UPLOAD_SESSION_HOURS):
                logging.info(f"Returning existing active session for {unique_id}: s3_key={existing_session['s3_key']}")
                return {
                    "upload_url": existing_session["upload_url"],
                    "s3_key": existing_session["s3_key"],
                    "expires_at": existing_session["expires_at"],
                    "chunk_size_limit": existing_session.get("chunk_size_limit", 100 * 1024 * 1024),
                    "upload_session_id": unique_id,
                    "session_uuid": existing_session["session_uuid"],
                    "message": "Using existing active session"
                }
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        session_uuid = uuid.uuid4().hex[:8]
        s3_key = f"ai-interviewer/recordings/direct_upload_{unique_id}_{timestamp}_{session_uuid}.webm"
        
        expiry_time = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=3)
        upload_url = get_signed_s3_url(f"s3://{BUCKET_NAME}/{s3_key}", 3, method='put_object', content_type='video/webm')
        
        upload_session = {
            "unique_id": unique_id,
            "s3_key": s3_key,
            "upload_url": upload_url,
            "created_at": datetime.datetime.now().isoformat(),
            "expires_at": expiry_time.isoformat(),
            "status": "active",
            "session_uuid": session_uuid,
            "chunk_size_limit": 100 * 1024 * 1024,
            "total_chunks_uploaded": 0,
            "last_activity": datetime.datetime.now().isoformat()
        }
        
        add_upload_session(unique_id, upload_session)
        
        logging.info(f"Generated upload URL for {unique_id}: s3_key={s3_key}, content_type=video/webm, expires_at={upload_session['expires_at']}")
        
        return {
            "upload_url": upload_url,
            "s3_key": s3_key,
            "expires_at": upload_session["expires_at"],
            "chunk_size_limit": upload_session["chunk_size_limit"],
            "upload_session_id": unique_id,
            "session_uuid": session_uuid,
            "message": "Upload URL generated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error generating upload URL for {unique_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate upload URL: {str(e)}")

@router.post("/complete-upload")
async def complete_upload(request: dict = {}):
    """Mark upload as complete and update database"""
    try:
        unique_id = request.get("unique_id")
        s3_key = request.get("s3_key")
        
        if not unique_id or not s3_key:
            raise HTTPException(status_code=400, detail="unique_id and s3_key are required")
        
        session = get_upload_session(unique_id)
        if not session:
            raise HTTPException(status_code=404, detail="Upload session not found")
        
        if session.get("s3_key") != s3_key:
            raise HTTPException(status_code=400, detail="s3_key does not match session")
        
        s3_url = f"s3://{BUCKET_NAME}/{s3_key}"
        
        try:
            db = Database()
            service = InterviewService(db)
            success = service.update_interview_recording(unique_id, s3_url)
            db.close(db.get_session())
            
            if not success:
                raise HTTPException(status_code=500, detail="Failed to update database")
        except Exception as db_error:
            logging.error(f"Database update failed for {unique_id}: {db_error}")
            raise HTTPException(status_code=500, detail="Failed to update database")
        
        update_upload_session(unique_id, {"status": "completed", "last_activity": datetime.datetime.now().isoformat()})
        
        logging.info(f"Completed upload for {unique_id}: {s3_url}")
        
        return {
            "message": "Upload completed successfully",
            "s3_url": s3_url,
            "unique_id": unique_id,
            "s3_key": s3_key,
            "file_size": session.get("file_size", 0),
            "file_size_mb": round(session.get("file_size", 0) / (1024 * 1024), 2),
            "completed_at": datetime.datetime.now().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error completing upload for {unique_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to complete upload: {str(e)}")

@router.get("/regenerate-presigned-url/{unique_id}")
async def regenerate_presigned_url(unique_id: str, expiry_hours: int = 1):
    """Regenerate presigned URL for an existing recording"""
    try:
        if not 1 <= expiry_hours <= 24:
            raise HTTPException(status_code=400, detail="expiry_hours must be between 1 and 24")
        
        db = Database()
        service = InterviewService(db)
        interview = service.get_interview(unique_id)
        db.close(db.get_session())

        if not interview:
            raise HTTPException(status_code=404, detail=f"No interview found for unique_id: {unique_id}")

        if not interview.get("recording_urls"):
            raise HTTPException(status_code=404, detail=f"No recording found for unique_id: {unique_id}")

        recording_url = interview["recording_urls"][0]
        
        try:
            s3_key = recording_url[len(f"s3://{BUCKET_NAME}/"):] if recording_url.startswith(f"s3://{BUCKET_NAME}/") else recording_url
        except IndexError:
            raise HTTPException(status_code=400, detail="Invalid recording URL format")

        new_presigned_url = get_signed_s3_url(f"s3://{BUCKET_NAME}/{s3_key}", expiry_hours, method='get_object')

        logging.info(f"Regenerated presigned URL for {unique_id}, expires in {expiry_hours} hours")

        return {
            "message": "Presigned URL regenerated successfully",
            "unique_id": unique_id,
            "s3_key": s3_key,
            "presigned_url": new_presigned_url,
            "expires_in_hours": expiry_hours,
            "expires_at": (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=expiry_hours)).isoformat(),
            "regenerated_at": datetime.datetime.now().isoformat()
        }

    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error regenerating presigned URL for {unique_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to regenerate presigned URL: {str(e)}")

@router.get("/recording-info/{unique_id}")
async def get_recording_info(unique_id: str):
    """Get recording information without generating presigned URL"""
    try:
        db = Database()
        service = InterviewService(db)
        interview = service.get_interview(unique_id)
        db.close(db.get_session())

        if not interview:
            raise HTTPException(status_code=404, detail=f"No interview found for unique_id: {unique_id}")

        if not interview.get("recording_urls"):
            raise HTTPException(status_code=404, detail=f"No recording found for unique_id: {unique_id}")

        recording_url = interview["recording_urls"][0]
        
        try:
            s3_key = recording_url[len(f"s3://{BUCKET_NAME}/"):] if recording_url.startswith(f"s3://{BUCKET_NAME}/") else recording_url
        except IndexError:
            raise HTTPException(status_code=400, detail="Invalid recording URL format")

        logging.info(f"Retrieved recording info for {unique_id}: {s3_key}")

        return {
            "unique_id": unique_id,
            "s3_key": s3_key,
            "recording_url": recording_url,
            "bucket": BUCKET_NAME,
            "region": AWS_REGION,
            "exists": check_s3_object_exists(s3_key),
            "note": "Use /regenerate-presigned-url to get download URL"
        }

    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error getting recording info for {unique_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get recording info: {str(e)}")

@router.post("/upload-legacy")
async def upload_legacy_recording(request: dict = {}):
    """Legacy endpoint for direct recording upload (for backward compatibility)"""
    try:
        unique_id = request.get("unique_id")
        recording_data = request.get("recording_data")  # base64 encoded
        
        if not unique_id or not recording_data:
            raise HTTPException(status_code=400, detail="unique_id and recording_data are required")
        
        try:
            if recording_data.startswith('data:'):
                recording_data = recording_data.split(',')[1]
            recording_bytes = base64.b64decode(recording_data, validate=True)
            logging.info(f"Decoded recording bytes length: {len(recording_bytes)} for unique_id: {unique_id}")
        except Exception as decode_error:
            logging.error(f"Invalid recording data format for unique_id {unique_id}: {str(decode_error)}")
            raise HTTPException(status_code=400, detail=f"Invalid recording data format: {str(decode_error)}")
        
        s3_url = await upload_recording_to_s3(recording_bytes, unique_id)
        
        try:
            db = Database()
            service = InterviewService(db)
            success = service.update_interview_recording(unique_id, s3_url)
            db.close(db.get_session())
            
            if not success:
                raise HTTPException(status_code=500, detail="Failed to update database")
                
        except Exception as db_error:
            logging.error(f"Database update failed for {unique_id}: {db_error}")
            raise HTTPException(status_code=500, detail="Failed to update database")
        
        logging.info(f"Legacy upload completed for {unique_id}: {s3_url}")
        
        return {
            "message": "Recording uploaded successfully",
            "s3_url": s3_url,
            "unique_id": unique_id,
            "s3_key": s3_url[len(f"s3://{BUCKET_NAME}/"):],
            "file_size": len(recording_bytes),
            "file_size_mb": round(len(recording_bytes) / (1024 * 1024), 2),
            "upload_type": "legacy"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error in legacy upload for {unique_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to upload recording: {str(e)}")

@router.get("/upload-session/{unique_id}")
async def get_upload_session_status(unique_id: str):
    """Get upload session status"""
    session = get_upload_session(unique_id)
    if not session:
        raise HTTPException(status_code=404, detail="Upload session not found")
   
    created_at = datetime.datetime.fromisoformat(session["created_at"])
    is_expired = datetime.datetime.now() - created_at > datetime.timedelta(hours=MAX_UPLOAD_SESSION_HOURS)
   
    if is_expired and session["status"] == "active":
        session_updates = {"status": "expired", "expired_at": datetime.datetime.now().isoformat()}
        update_upload_session(unique_id, session_updates)
        session.update(session_updates)
   
    return {
        "session": session,
        "is_expired": is_expired,
        "time_remaining_hours": max(0, MAX_UPLOAD_SESSION_HOURS - (datetime.datetime.now() - created_at).total_seconds() / 3600)
    }

@router.post("/start")
async def start_recording(request: dict = {}):
    """Start recording session (simplified for direct upload)"""
    try:
        unique_id = request.get("unique_id")
        if not unique_id:
            raise HTTPException(status_code=400, detail="unique_id is required")
       
        logging.info(f"Recording session started for {unique_id}")
       
        return {
            "message": "Recording session started successfully",
            "unique_id": unique_id,
            "status": "active",
            "timestamp": datetime.datetime.now().isoformat(),
            "next_step": "Use /generate-upload-url to get direct upload URL"
        }
       
    except Exception as e:
        logging.error(f"Error starting recording session for {unique_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to start recording: {str(e)}")

@router.post("/stop")
async def stop_recording(request: dict = {}):
    """Stop recording session (simplified for direct upload)"""
    try:
        unique_id = request.get("unique_id")
        if not unique_id:
            raise HTTPException(status_code=400, detail="unique_id is required")
       
        session = get_upload_session(unique_id)
        if session and session.get("status") == "active":
            session_updates = {
                "status": "stopped",
                "stopped_at": datetime.datetime.now().isoformat(),
                "last_activity": datetime.datetime.now().isoformat()
            }
            update_upload_session(unique_id, session_updates)
       
        logging.info(f"Recording session stopped for {unique_id}")
       
        return {
            "message": "Recording stopped successfully",
            "unique_id": unique_id,
            "status": "stopped",
            "timestamp": datetime.datetime.now().isoformat(),
            "note": "Upload may still be in progress. Use /complete-upload when finished."
        }
       
    except Exception as e:
        logging.error(f"Error stopping recording: {e}")
        raise HTTPException(status_code=500, detail=f"Error stopping recording: {str(e)}")

@router.get("/status")
async def get_recording_status():
    """Get system status including upload sessions"""
    try:
        with session_lock:
            total_sessions = len(active_upload_sessions)
            active_sessions = sum(1 for s in active_upload_sessions.values() if s.get("status") == "active")
            completed_sessions = sum(1 for s in active_upload_sessions.values() if s.get("status") == "completed")
           
            recent_sessions = []
            sorted_sessions = sorted(
                active_upload_sessions.items(),
                key=lambda x: x[1].get("created_at", ""),
                reverse=True
            )[:10]
           
            for unique_id, session in sorted_sessions:
                recent_sessions.append({
                    "unique_id": unique_id,
                    "status": session.get("status"),
                    "created_at": session.get("created_at"),
                    "s3_key": session.get("s3_key"),
                    "file_size": session.get("file_size")
                })
       
        return {
            "total_upload_sessions": total_sessions,
            "active_sessions": active_sessions,
            "completed_sessions": completed_sessions,
            "recent_sessions": recent_sessions,
            "system_stats": {
                "s3_bucket": BUCKET_NAME,
                "direct_upload_enabled": True,
                "max_session_hours": MAX_UPLOAD_SESSION_HOURS,
                "upload_approach": "direct_s3_upload"
            }
        }
       
    except Exception as e:
        logging.error(f"Error getting recording status: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting status: {str(e)}")

@router.get("/health")
async def health_check():
    """Health check for direct upload system"""
    try:
        s3_healthy = False
        try:
            s3_client.head_bucket(Bucket=BUCKET_NAME)
            s3_healthy = True
        except ClientError as e:
            logging.error(f"S3 bucket check failed: {e}")
        
        with session_lock:
            total_sessions = len(active_upload_sessions)
            active_sessions = sum(1 for s in active_upload_sessions.values() if s.get("status") == "active")
       
        health_status = "healthy"
        issues = []
       
        if not s3_healthy:
            health_status = "unhealthy"
            issues.append("S3 bucket connection failed")
       
        if active_sessions > 50:
            health_status = "warning" if health_status == "healthy" else health_status
            issues.append(f"High number of active sessions: {active_sessions}")
       
        if total_sessions > 200:
            health_status = "critical"
            issues.append(f"Memory usage high - too many tracked sessions: {total_sessions}")
       
        return {
            "status": health_status,
            "s3_connection": "connected" if s3_healthy else "failed",
            "direct_upload_ready": s3_healthy,
            "active_upload_sessions": active_sessions,
            "total_tracked_sessions": total_sessions,
            "features": {
                "direct_upload": True,
                "pre_signed_urls": True,
                "session_tracking": True,
                "automatic_cleanup": True
            },
            "configuration": {
                "max_session_hours": MAX_UPLOAD_SESSION_HOURS,
                "cleanup_interval_hours": CLEANUP_INTERVAL_HOURS,
                "s3_bucket": BUCKET_NAME
            },
            "issues": issues if issues else None,
            "recommendations": [
                "System is operating normally" if health_status == "healthy" else "Check issues above",
                "Consider running cleanup if total_tracked_sessions > 100" if total_sessions > 100 else None
            ]
        }
       
    except Exception as e:
        logging.error(f"Health check error: {str(e)}")
        return {
            "status": "unhealthy",
            "error": str(e),
            "s3_connection": "unknown",
            "direct_upload_ready": False,
            "active_upload_sessions": 0,
            "total_tracked_sessions": 0
        }

@router.get("/presigned-url/by-unique-id/{unique_id}")
async def get_presigned_url_by_unique_id(unique_id: str):
    """Generate a pre-signed URL for reading the S3 object associated with the unique_id"""
    try:
        db = Database()
        service = InterviewService(db)
        interview = service.get_interview(unique_id)
        db.close(db.get_session())

        if not interview:
            raise HTTPException(status_code=404, detail=f"No interview found for unique_id: {unique_id}")

        if not interview.get("recording_urls"):
            raise HTTPException(status_code=404, detail=f"No recording found for unique_id: {unique_id}")

        recording_url = interview["recording_urls"][0]
        
        try:
            s3_key = recording_url[len(f"s3://{BUCKET_NAME}/"):] if recording_url.startswith(f"s3://{BUCKET_NAME}/") else recording_url
        except IndexError:
            raise HTTPException(status_code=400, detail="Invalid recording URL format")

        presigned_url = get_signed_s3_url(f"s3://{BUCKET_NAME}/{s3_key}", 1, method='get_object')

        logging.info(f"Generated presigned URL for {unique_id}: {s3_key}")

        return {
            "message": "Presigned URL generated successfully",
            "unique_id": unique_id,
            "s3_key": s3_key,
            "presigned_url": presigned_url,
            "expires_in_hours": 1,
            "expires_at": (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=1)).isoformat()
        }

    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error generating presigned URL for {unique_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate presigned URL: {str(e)}")

@router.get("/download-url/{unique_id}")
async def get_download_url(unique_id: str):
    """Get a download URL for the recording"""
    try:
        logging.info(f"Download URL request for unique_id: {unique_id}")
        
        db = Database()
        service = InterviewService(db)
        interview = service.get_interview(unique_id)
        db.close(db.get_session())

        if not interview:
            raise HTTPException(status_code=404, detail=f"No interview found for unique_id: {unique_id}")

        if not interview.get("recording_urls"):
            raise HTTPException(status_code=404, detail=f"No recording found for unique_id: {unique_id}")

        recording_url = interview["recording_urls"][0]
        
        try:
            s3_key = recording_url[len(f"s3://{BUCKET_NAME}/"):] if recording_url.startswith(f"s3://{BUCKET_NAME}/") else recording_url
        except IndexError:
            raise HTTPException(status_code=400, detail="Invalid recording URL format")

        presigned_url = get_signed_s3_url(f"s3://{BUCKET_NAME}/{s3_key}", 1, method='get_object')

        logging.info(f"Generated download URL for {unique_id}: {s3_key}")

        return {
            "message": "Download URL generated successfully",
            "unique_id": unique_id,
            "s3_key": s3_key,
            "download_url": presigned_url,
            "expires_in_hours": 1,
            "expires_at": (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=1)).isoformat()
        }

    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error generating download URL for {unique_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate download URL: {str(e)}")

@router.post("/cleanup-sessions")
async def cleanup_old_sessions(hours_old: int = CLEANUP_INTERVAL_HOURS):
    """Clean up old upload sessions from memory"""
    try:
        if hours_old < 1:
            raise HTTPException(status_code=400, detail="hours_old must be at least 1")
       
        cutoff_time = datetime.datetime.now() - datetime.timedelta(hours=hours_old)
        removed_sessions = []
       
        with session_lock:
            sessions_to_remove = []
            for unique_id, session in active_upload_sessions.items():
                try:
                    session_time = datetime.datetime.fromisoformat(session["created_at"])
                    if session_time < cutoff_time:
                        sessions_to_remove.append(unique_id)
                        removed_sessions.append({
                            "unique_id": unique_id,
                            "status": session.get("status"),
                            "created_at": session.get("created_at"),
                            "s3_key": session.get("s3_key"),
                            "age_hours": (datetime.datetime.now() - session_time).total_seconds() / 3600
                        })
                except (ValueError, KeyError) as e:
                    logging.warning(f"Invalid session data for {unique_id}: {e}")
                    sessions_to_remove.append(unique_id)
           
            for unique_id in sessions_to_remove:
                del active_upload_sessions[unique_id]
       
        logging.info(f"Cleaned up {len(removed_sessions)} old upload sessions")
        
        return {
            "message": f"Cleaned up {len(removed_sessions)} sessions",
            "removed_sessions": removed_sessions,
            "remaining_sessions": len(active_upload_sessions)
        }
       
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error during session cleanup: {e}")
        raise HTTPException(status_code=500, detail=f"Error during cleanup: {str(e)}")

@router.delete("/sessions/{unique_id}")
async def force_remove_session(unique_id: str):
    """Force remove a specific upload session (admin endpoint)"""
    try:
        session = get_upload_session(unique_id)
        if not session:
            raise HTTPException(status_code=404, detail=f"Upload session not found for unique_id: {unique_id}")
       
        removed_session = session.copy()
        success = remove_upload_session(unique_id)
       
        if success:
            logging.info(f"Force removed upload session for {unique_id}")
            return {
                "message": f"Upload session forcefully removed for {unique_id}",
                "removed_session": removed_session,
                "remaining_sessions": len(active_upload_sessions)
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to remove session")
       
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error force removing session {unique_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Error removing session: {str(e)}")

@router.get("/sessions")
async def list_upload_sessions():
    """List all current upload sessions"""
    try:
        with session_lock:
            sessions_list = []
            for unique_id, session in active_upload_sessions.items():
                try:
                    created_at = datetime.datetime.fromisoformat(session["created_at"])
                    age_hours = (datetime.datetime.now() - created_at).total_seconds() / 3600
                except (ValueError, KeyError):
                    age_hours = 0
               
                sessions_list.append({
                    "unique_id": unique_id,
                    "status": session.get("status"),
                    "created_at": session.get("created_at"),
                    "s3_key": session.get("s3_key"),
                    "file_size": session.get("file_size"),
                    "age_hours": round(age_hours, 2),
                    "session_uuid": session.get("session_uuid")
                })
       
        sessions_list.sort(key=lambda x: x.get("created_at", ""), reverse=True)
       
        return {
            "sessions": sessions_list,
            "total_count": len(sessions_list),
            "active_count": sum(1 for s in sessions_list if s["status"] == "active"),
            "completed_count": sum(1 for s in sessions_list if s["status"] == "completed"),
            "stopped_count": sum(1 for s in sessions_list if s["status"] == "stopped")
        }
       
    except Exception as e:
        logging.error(f"Error listing upload sessions: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing sessions: {str(e)}")

# Optional: Background task for automatic cleanup (uncomment if needed)
# import asyncio
# from contextlib import asynccontextmanager
# @asynccontextmanager
# async def lifespan(app):
#     cleanup_task = asyncio.create_task(periodic_cleanup())
#     yield
#     cleanup_task.cancel()
# async def periodic_cleanup():
#     """Periodically clean up old sessions"""
#     while True:
#         try:
#             await asyncio.sleep(CLEANUP_INTERVAL_HOURS * 3600)
#             cutoff_time = datetime.datetime.now() - datetime.timedelta(hours=CLEANUP_INTERVAL_HOURS)
#             removed_count = 0
#             
#             with session_lock:
#                 sessions_to_remove = []
#                 for unique_id, session in active_upload_sessions.items():
#                     try:
#                         session_time = datetime.datetime.fromisoformat(session["created_at"])
#                         if session_time < cutoff_time:
#                             sessions_to_remove.append(unique_id)
#                     except (ValueError, KeyError):
#                         sessions_to_remove.append(unique_id)
#                 
#                 for unique_id in sessions_to_remove:
#                     del active_upload_sessions[unique_id]
#                     removed_count += 1
#             
#             if removed_count > 0:
#                 logging.info(f"Automatic cleanup removed {removed_count} old sessions")
#                 
#         except asyncio.CancelledError:
#             break
#         except Exception as e:
#             logging.error(f"Error in periodic cleanup: {e}")

def shutdown_handler():
    """Graceful shutdown"""
    logging.info("Shutting down recording service...")
    with session_lock:
        final_count = len(active_upload_sessions)
        if final_count > 0:
            logging.info(f"Shutdown with {final_count} active upload sessions")
    logging.info("Recording service shutdown complete")

atexit.register(shutdown_handler)