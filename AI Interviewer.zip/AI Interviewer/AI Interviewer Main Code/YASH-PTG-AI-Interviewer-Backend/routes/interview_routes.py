from fastapi import APIRouter, Form, Header, UploadFile, File, HTTPException, Depends, BackgroundTasks
from pydantic import BaseModel
from fastapi.responses import JSONResponse, Response
from typing import Annotated
from services.interview_service import InterviewService
from database import Database
from utility.s3_utils import upload_file_to_s3, get_signed_s3_url, check_s3_object_exists
from datetime import datetime, timedelta
import base64
import json
import uuid
import os
import boto3
from botocore.exceptions import ClientError
import logging
from models import InterviewDetailsMain

router = APIRouter()

# Initialize logger
logger = logging.getLogger("interview_routes")
logger.setLevel(logging.INFO)

# AWS S3 Configuration
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION = os.getenv("AWS_REGION")
BUCKET_NAME = os.getenv("BUCKET_NAME")

# Initialize S3 client
s3_client = boto3.client(
    's3',
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY
)

def get_db():
    db = Database()
    try:
        yield db
    finally:
        db.close(db.get_session())

class UserRegistration(BaseModel):
    fullName: str
    age: int
    sex: str
    phone: str

class InterviewScheduleRequest(BaseModel):
    unique_id: str
    full_name: str
    age: int
    sex: str
    phone: str
    job_id: int
    email_id: str
    domain: str

async def upload_resume_to_s3(resume_content: bytes, unique_id: str, original_filename: str) -> str:
    """Upload resume to S3 and return the key"""
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_extension = original_filename.split('.')[-1] if '.' in original_filename else 'pdf'
        key = f"ai-interviewer/fileupload/resume/{unique_id}_{timestamp}.{file_extension}"
        
        resume_url = await upload_file_to_s3(key, resume_content, content_type="application/pdf")
        return key
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to upload resume: {str(e)}")

async def upload_user_image_to_s3(image_data: str, unique_id: str) -> str:
    """Upload user image to S3 and return the S3 URL"""
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Determine file extension and content type from data URI
        file_extension = 'jpg'
        content_type = 'image/jpeg'
        if image_data.startswith('data:image'):
            mime_type = image_data.split(';')[0].split(':')[1]
            file_extension = mime_type.split('/')[1]
            content_type = mime_type
            image_data = image_data.split(',')[1]
            logger.info(f"Detected image MIME type: {content_type}, extension: {file_extension} for unique_id: {unique_id}")
        else:
            logger.warning(f"No data:image prefix found for user image upload: {unique_id}")
        
        # Validate base64 data
        try:
            image_bytes = base64.b64decode(image_data, validate=True)
            logger.info(f"Decoded image bytes length: {len(image_bytes)} for unique_id: {unique_id}")
        except Exception as e:
            logger.error(f"Invalid base64 image data for unique_id {unique_id}: {str(e)}")
            raise HTTPException(status_code=400, detail="Invalid base64 image data")
        
        key = f"ai-interviewer/profileimage/user_images/{unique_id}_{timestamp}.{file_extension}"
        logger.info(f"Uploading user image to S3 with key: {key}")
        
        image_url = await upload_file_to_s3(key, image_bytes, content_type=content_type)
        logger.info(f"User image uploaded successfully: {image_url}")
        
        return image_url
    except HTTPException as he:
        raise he
    except Exception as e:
        logger.error(f"Failed to upload user image for unique_id {unique_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to upload user image: {str(e)}")
    
def generate_user_image_public_url(key: str, expiry_hours: int = 24) -> str:
    """Generate a presigned URL for the user image in S3"""
    try:
        # Normalize key to remove any leading slashes or bucket name
        key = key.lstrip('/')
        if key.startswith(f"{BUCKET_NAME}/"):
            key = key[len(BUCKET_NAME) + 1:]
        
        logger.info(f"Attempting to generate presigned URL for key: {key}")
        
        # Since we can't use s3:HeadObject, rely on get_signed_s3_url to detect non-existent objects
        s3_url = f"s3://{BUCKET_NAME}/{key}"
        presigned_url = get_signed_s3_url(s3_url, expiry_hours)
        logger.info(f"Successfully generated presigned URL for key: {key}")
        return presigned_url
    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
        logger.error(f"S3 error generating presigned URL for key {key}: {error_code} - {error_message}")
        if error_code == 'NoSuchKey':
            raise HTTPException(status_code=404, detail=f"S3 object not found: s3://{BUCKET_NAME}/{key}")
        elif error_code == 'AccessDenied':
            raise HTTPException(status_code=403, detail=f"Access denied to S3 object: {error_message}")
        raise HTTPException(status_code=500, detail=f"S3 error: {error_message}")
    except HTTPException as he:
        raise he
    except Exception as e:
        logger.error(f"Failed to generate presigned URL for key {key}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate presigned URL for user image: {str(e)}")
    
def generate_presigned_url(key: str, expiry_hours: int = 24) -> str:
    """Generate a presigned URL for the S3 object"""
    try:
        s3_url = f"s3://{BUCKET_NAME}/{key}"
        presigned_url = get_signed_s3_url(s3_url, expiry_hours)
        return presigned_url
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate presigned URL: {str(e)}")

def download_resume_from_s3(key: str) -> bytes:
    """Download resume content from S3"""
    try:
        response = s3_client.get_object(Bucket=BUCKET_NAME, Key=key)
        return response['Body'].read()
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code in ['NoSuchKey', 'AccessDenied']:
            raise HTTPException(status_code=404, detail=f"Resume not found: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to download resume: {str(e)}")

@router.post("/register_user")
async def register_user(user_data: UserRegistration):
    db = Database()
    service = InterviewService(db)
    user_id = service.register_user(
        user_data.fullName,
        user_data.age,
        user_data.sex,
        user_data.phone
    )
    db.close(db.get_session())
    if not user_id:
        raise HTTPException(status_code=500, detail="Failed to register user")
    return {"message": "User registered successfully", "id": user_id}

@router.get("/get_users")
async def get_users():
    db = Database()
    service = InterviewService(db)
    users = service.get_users()
    db.close(db.get_session())
    return [
        {
            "id": str(user[0]),
            "fullName": user[1],
            "phone": user[2],
        }
        for user in users
    ]
@router.post("/schedule_interview")
async def schedule_interview(
    background_tasks: BackgroundTasks,
    unique_id: Annotated[str, Form()],
    user_image: Annotated[str, Form()],
    full_name: Annotated[str, Form()],
    age: Annotated[int, Form()],
    sex: Annotated[str, Form()],
    phone: Annotated[str, Form()],
    job_id: Annotated[int, Form()],
    email_id: Annotated[str, Form()],
    domain: Annotated[str, Form()],
    resume: UploadFile,
    scheduled_date: Annotated[str, Form()] = None,
    time_slot: Annotated[str, Form()] = None,
):
    try:
        form_data = InterviewScheduleRequest(
            unique_id=unique_id,
            full_name=full_name,
            age=age,
            sex=sex,
            phone=phone,
            job_id=job_id,
            email_id=email_id,
            domain=domain
        )

        # Check for existing application before uploading files
        db = Database()
        service = InterviewService(db)
        existing_application = service.session.query(InterviewDetailsMain).filter(
            InterviewDetailsMain.email_id == form_data.email_id,
            InterviewDetailsMain.job_id == form_data.job_id
        ).first()
        if existing_application:
            db.close(db.get_session())
            raise HTTPException(
                status_code=409,
                detail=f"You have already applied for this job position. Application ID: {existing_application.unique_id}"
            )

        # Validate resume file type
        if not resume.content_type == "application/pdf":
            db.close(db.get_session())
            raise HTTPException(status_code=400, detail="Only PDF files are allowed")

        # Validate scheduled date and time
        scheduled_start_time = None
        if scheduled_date and time_slot:
            import pytz
            import re
            ist = pytz.timezone("Asia/Kolkata")
            current_time = datetime.now(ist)

            try:
                date_parts = scheduled_date.split('-')
                year, month, day = map(int, date_parts)

                time_slot_pattern = re.compile(r'(\d+)(?::(\d+))?\s*([AP]M)\s+to\s+(\d+)(?::(\d+))?\s*([AP]M)', re.IGNORECASE)
                match = time_slot_pattern.match(time_slot)

                if not match:
                    raise ValueError(f"Invalid time slot format: {time_slot}. Expected format: '7AM to 7:30AM'")

                start_hour = int(match.group(1))
                start_minute = int(match.group(2)) if match.group(2) else 0
                start_am_pm = match.group(3).upper()

                if start_am_pm == 'PM' and start_hour < 12:
                    start_hour += 12
                elif start_am_pm == 'AM' and start_hour == 12:
                    start_hour = 0

                scheduled_start_time = datetime(year, month, day, start_hour, start_minute)

                current_time_naive = current_time.replace(tzinfo=None)

                if scheduled_start_time <= current_time_naive:
                    raise HTTPException(status_code=400, detail="Scheduled time must be in the future")

                max_future_date = current_time_naive + timedelta(days=7)
                if scheduled_start_time > max_future_date:
                    raise HTTPException(status_code=400, detail="Interviews can only be scheduled up to 7 days in advance")

            except ValueError as e:
                db.close(db.get_session())
                raise HTTPException(status_code=400, detail=f"Invalid date or time format: {str(e)}")

        # Read resume content
        resume_content = await resume.read()

        # Upload resume to S3
        resume_key = await upload_resume_to_s3(resume_content, unique_id, resume.filename)

        # Upload user image to S3
        user_image_s3_url = await upload_user_image_to_s3(user_image, unique_id)
        user_image_key = user_image_s3_url[len(f"s3://{BUCKET_NAME}/"):] if user_image_s3_url.startswith(f"s3://{BUCKET_NAME}/") else user_image_s3_url
        logger.info(f"Storing user_image_key: {user_image_key} for unique_id: {unique_id}")

        # Generate presigned URL for resume
        resume_url = generate_presigned_url(resume_key)

        # Schedule the interview
        result = await service.schedule_interview(
            full_name=form_data.full_name,
            age=form_data.age,
            sex=form_data.sex,
            email_id=form_data.email_id,
            job_id=form_data.job_id,
            phone=form_data.phone,
            unique_id=form_data.unique_id,
            user_image_path=user_image_key,
            resume=resume_content,
            resume_path=resume_key,
            domain=form_data.domain,
            background_tasks=background_tasks,
            scheduled_start_time=scheduled_start_time
        )

        db.close(db.get_session())

        if result.get("statusCode"):
            raise HTTPException(status_code=409, detail=result.get("message", "Interview already scheduled"))

        if not result.get("success", False):
            raise HTTPException(status_code=500, detail=result.get("message", "Error scheduling interview"))

        return {"status": "success", "message": result.get("message")}

    except HTTPException as he:
        raise he
    except Exception as e:
        db.close(db.get_session())
        raise HTTPException(status_code=500, detail=f"Error scheduling interview: {str(e)}")

@router.get("/generate_user_image_url/{unique_id}")
async def generate_user_image_url(unique_id: str):
    """
    Generate public URL for user image using database-stored path
    """
    try:
        db = Database()
        service = InterviewService(db)
        interview = service.get_interview_details(unique_id)
        db.close(db.get_session())
        
        if not interview or not hasattr(interview, 'user_image_path') or not interview.user_image_path:
            raise HTTPException(status_code=404, detail=f"No user image found for interview {unique_id}")
        
        user_image_url = generate_user_image_public_url(interview.user_image_path)
        return {
            "user_image_url": user_image_url,
            "key": interview.user_image_path,
            "unique_id": unique_id,
            "source": "database_path"
        }
        
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate user image URL: {str(e)}")

@router.get("/generate_resume_url/{unique_id}")
async def generate_resume_url(unique_id: str, expiry_hours: int = 24):
    """
    Generate presigned URL using database-stored resume path
    """
    try:
        db = Database()
        service = InterviewService(db)
        interview = service.get_interview_details(unique_id)
        db.close(db.get_session())
        
        if not interview or not interview.resume_path:
            raise HTTPException(status_code=404, detail=f"No resume found for interview {unique_id}")
        
        resume_url = generate_presigned_url(interview.resume_path, expiry_hours)
        return {
            "resume_url": resume_url,
            "key": interview.resume_path,
            "expiry_hours": expiry_hours,
            "unique_id": unique_id,
            "source": "database_path"
        }
        
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate resume URL: {str(e)}")

@router.get("/download_resume/{unique_id}")
async def download_resume(unique_id: str):
    """Download resume file directly"""
    db = Database()
    service = InterviewService(db)
    interview = service.get_interview_details(unique_id)
    db.close(db.get_session())
    
    if not interview or not interview.resume_path:
        raise HTTPException(status_code=404, detail="Resume not found")
    
    try:
        resume_content = download_resume_from_s3(interview.resume_path)
        return Response(
            content=resume_content,
            headers={
                "Content-Disposition": f"inline; filename={interview.full_name}_resume.pdf",
                "Content-Type": "application/pdf",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Expose-Headers": "Content-Disposition, Content-Type"
            }
        )
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error downloading resume: {str(e)}")

@router.post("/update_interview")
async def update_interview(unique_id: str = Form(...), questions: str = Form(...)):
    db = Database()
    service = InterviewService(db)
    success, error_message = service.update_interview_answers(unique_id, json.dumps(questions))
    db.close(db.get_session())
    if not success:
        raise HTTPException(status_code=500, detail=error_message or "Failed to update interview.")
    return {"message": "Interview updated successfully"}

@router.get("/candidate-details/{unique_id}")
async def get_interview_candidate_details(unique_id: str, db: Database = Depends(get_db)):
    try:
        interview_service = InterviewService(db)
        response = interview_service.get_interview_candidate_details(unique_id)

        if not response.get("success", False):
            raise HTTPException(status_code=404, detail=response.get("message", "Failed to fetch candidate details"))

        session = db.get_session()
        interview = session.query(InterviewDetailsMain).filter_by(unique_id=unique_id).first()

        if not interview:
            db.close(session)
            raise HTTPException(status_code=404, detail="Interview not found")

        summary_report_url = None
        summary_report_path = getattr(interview, 'summary_report_path', None)

        if summary_report_path:
            # Clean up path
            if summary_report_path.startswith(f"s3://{BUCKET_NAME}/"):
                summary_report_path = summary_report_path[len(f"s3://{BUCKET_NAME}/"):]
            elif summary_report_path.startswith("s3://"):
                summary_report_path = summary_report_path.split("/", 3)[-1]

            now = datetime.now()
            expiry_time = getattr(interview, 'summary_report_url_expiry', None)
            stored_url = getattr(interview, 'summary_report_url', None)

            if not stored_url or not expiry_time or now >= expiry_time:
                # Use generate_user_image_public_url to avoid s3:ListBucket dependency
                summary_report_url = generate_user_image_public_url(summary_report_path)
                interview.summary_report_url = summary_report_url
                interview.summary_report_url_expiry = now + timedelta(hours=24)
                session.commit()
            else:
                summary_report_url = stored_url

        db.close(session)

        response["summary_report_path"] = summary_report_path
        response["summary_report_url"] = summary_report_url

        return JSONResponse(content=response, status_code=200)

    except HTTPException as he:
        raise he
    except Exception as e:
        db.close(db.get_session())
        raise HTTPException(status_code=500, detail=f"Failed to fetch candidate details: {str(e)}")

@router.get("/get_interviews")
async def get_interviews():
    db = Database()
    service = InterviewService(db)
    interviews = service.get_all_interviews()
    db.close(db.get_session())
    
    result = []
    for interview in interviews:
        interview_data = {
            "unique_id": interview[0],
            "user_image": interview[1],
            "status": interview[2],
            "scheduled_at": interview[3].isoformat(),
            "candidate_name": interview[4],
            "candidate_phone": interview[5],
            "job_title": interview[6]
        }
        
        if interview[1]:
            try:
                user_image_url = generate_user_image_public_url(interview[1])
                interview_data["user_image_url"] = user_image_url
            except Exception as e:
                print(f"Error generating user image URL for {interview[0]}: {e}")
                interview_data["user_image_url"] = None
        else:
            interview_data["user_image_url"] = None
            
        result.append(interview_data)
    
    return result

@router.delete("/cancel_interview/{unique_id}")
async def cancel_interview(unique_id: str):
    db = Database()
    service = InterviewService(db)
    success = service.cancel_interview(unique_id)
    db.close(db.get_session())
    if not success:
        raise HTTPException(status_code=500, detail="Failed to cancel interview or interview has expired")
    return {"message": "Interview cancelled successfully"}

@router.get("/interviews/completed/users")
async def get_completed_interview_users():
    db = Database()
    service = InterviewService(db)
    users = service.get_completed_interview_users()
    db.close(db.get_session())
    return [
        {
            "user_id": str(user[0]),
            "candidate_name": user[1],
            "candidate_phone": user[2]
        }
        for user in users
    ]

@router.get("/interview/{unique_id}")
async def get_interview(unique_id: str):
    db = Database()
    service = InterviewService(db)
    
    access_check = service.is_interview_accessible(unique_id)
    if not access_check["accessible"]:
        db.close(db.get_session())
        if "expired" in access_check["message"].lower():
            raise HTTPException(status_code=410, detail=access_check["message"])
        else:
            raise HTTPException(status_code=403, detail=access_check["message"])
    
    interview = service.get_interview_details(unique_id)
    db.close(db.get_session())
    if not interview:
        raise HTTPException(status_code=404, detail="Interview not found")
    
    resume_url = None
    if interview.resume_path:
        try:
            resume_url = generate_presigned_url(interview.resume_path)
            logger.info(f"Generated resume URL for unique_id {unique_id}: {resume_url}")
        except Exception as e:
            logger.error(f"Error generating resume URL for unique_id {unique_id}: {str(e)}")
    
    user_image_url = None
    user_image_path = getattr(interview, 'user_image_path', None) or getattr(interview, 'user_image', None)
    
    if user_image_path and not user_image_path.startswith('data:'):
        try:
            user_image_url = generate_user_image_public_url(user_image_path)
            logger.info(f"Generated user image URL for unique_id {unique_id}: {user_image_url}")
        except HTTPException as he:
            logger.error(f"HTTP error generating user image URL for unique_id {unique_id}: {str(he)}")
            user_image_url = None
        except Exception as e:
            logger.error(f"Unexpected error generating user image URL for unique_id {unique_id}: {str(e)}")
            user_image_url = None
    elif user_image_path and user_image_path.startswith('data:'):
        user_image_url = user_image_path
        logger.info(f"Using data URI for user image for unique_id {unique_id}")
    
    return {
        "unique_id": interview.unique_id,
        "candidate_name": interview.full_name,
        "age": interview.age,
        "sex": interview.sex,
        "candidate_phone": interview.phone,
        "email_id": interview.email_id,
        "resume": None,
        "resume_url": resume_url,
        "resume_path": getattr(interview, 'resume_path', None),
        "job_id": interview.job_id,
        "user_image": user_image_url,
        "user_image_path": user_image_path,
        "questions": interview.interview_questions,
        "answers": interview.interview_answers,
        "domain": interview.domain,
        "evaluation_result": interview.evaluation_result,
        "recording_urls": interview.recording_urls or [],
        "status": interview.status,
        "scheduled_at": interview.scheduled_at.isoformat() if interview.scheduled_at else None,
        "created_at": interview.created_at.isoformat() if interview.created_at else None
    }

@router.get("/get_interview_recordings_url/{unique_id}")
async def get_interview_recordings_url(unique_id: str):
    db = Database()
    service = InterviewService(db)
    interview = service.get_interview_details(unique_id)
    db.close(db.get_session())
    if not interview:
        raise HTTPException(status_code=404, detail="Interview not found")
    return {
        "unique_id": interview.unique_id,
        "recording_urls": interview.recording_urls or [],
        "message": "Recordings retrieved successfully"
    }

@router.get("/get_question/{unique_id}")
async def get_question(unique_id: str):
    db = Database()
    service = InterviewService(db)
    result = service.get_questions(unique_id)
    db.close(db.get_session())
    if result is None:
        raise HTTPException(status_code=404, detail="No questions found for this interview")
    return {
        "data": result,
        "message": "Questions retrieved successfully"
    }

@router.get("/status_api_data/{user_Id}")
async def status_api(user_Id: str, db: Database = Depends(get_db)):
    try:
        service = InterviewService(db)
        status_data = service.get_status_data(user_Id)
        if not status_data:
            raise HTTPException(status_code=404, detail="Data not found for this user")
        return JSONResponse(content=status_data)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Server error: {str(e)}")

@router.post("/share_interview_link/{unique_id}")
async def share_interview_link(unique_id: str, db: Database = Depends(get_db)):
    try:
        db = Database()
        service = InterviewService(db)
        result = await service.share_interview_link(unique_id)
        db.close(db.get_session())
        print("Result from service:", result)
        
        if not result.get("success", False):
            raise HTTPException(status_code=500, detail=result.get("message", "Error scheduling interview"))
        return {"status": "success", "message": result.get("message")}
        
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error scheduling interview: {str(e)}")

@router.post("/upload_summary_report/{unique_id}")
async def upload_summary_report(unique_id: str, file: UploadFile = File(...)):
    try:
        # Check if a summary report already exists for this unique_id
        db = Database()
        session = db.get_session()
        interview = session.query(InterviewDetailsMain).filter_by(unique_id=unique_id).first()
        if not interview:
            db.close(session)
            raise HTTPException(status_code=404, detail="Interview not found")
        
        # Check if summary_report_path exists and if the file exists in S3
        if interview.summary_report_path:
            try:
                s3_url = f"s3://{BUCKET_NAME}/{interview.summary_report_path}"
                if check_s3_object_exists(s3_url):
                    db.close(session)
                    raise HTTPException(status_code=409, detail="A summary report has already been uploaded for this interview")
                else:
                    logger.info(f"Summary report path {interview.summary_report_path} found in DB but not in S3 for unique_id {unique_id}. Allowing new upload.")
                    # Clear the stale DB entry to maintain consistency
                    interview.summary_report_path = None
                    interview.summary_report_url = None
                    interview.summary_report_url_expiry = None
                    session.commit()
            except Exception as e:
                logger.error(f"Error checking S3 object existence for {interview.summary_report_path}: {str(e)}")
                db.close(session)
                raise HTTPException(status_code=500, detail=f"Error verifying existing summary report: {str(e)}")
        
        content = await file.read()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        key = f"ai-interviewer/report-summary/{unique_id}_{timestamp}.pdf"
        
        # Upload to S3
        s3_url = await upload_file_to_s3(key, content, content_type="application/pdf")
        
        # Generate presigned URL
        expiry_hours = 24
        summary_report_url = generate_presigned_url(key, expiry_hours)
        expiry_time = datetime.now() + timedelta(hours=expiry_hours)
        
        # Save to DB
        interview.summary_report_path = key
        interview.summary_report_url = summary_report_url
        interview.summary_report_url_expiry = expiry_time
        session.commit()
        db.close(session)
        
        return {"success": True, "message": "PDF uploaded to S3", "key": key, "summary_report_url": summary_report_url}
    except HTTPException as he:
        raise he
    except Exception as e:
        logger.error(f"Error uploading summary report for {unique_id}: {str(e)}")
        db.close(session)
        raise HTTPException(status_code=500, detail=f"Failed to upload PDF: {str(e)}")