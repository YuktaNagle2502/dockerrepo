from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
from services.llm_service import LLMService
from database import Database
import jwt
from typing import Optional

router = APIRouter()

class LLMCreate(BaseModel):
    provider: str
    prefix: str
    model: str
    key: str

class LLMUpdate(BaseModel):
    provider: str = None
    prefix: str = None
    model: str = None
    key: str = None

def extract_email_from_token(authorization: str = None) -> str:
    """Extract email from JWT token"""
    if not authorization or not authorization.startswith("Bearer "):
        return None
    
    token = authorization.split(" ")[1]
    try:
        # Decode without verification for now - adjust based on your JWT setup
        payload = jwt.decode(token, options={"verify_signature": False})
        return payload.get("email") or payload.get("sub")
    except:
        return None

@router.post("/llm")
async def create_llm(llm_data: LLMCreate, authorization: Optional[str] = Header(None)):
    db = Database()
    service = LLMService(db)
    created_by = extract_email_from_token(authorization)
    llm_id = service.create_llm(llm_data.provider, llm_data.prefix, llm_data.model, llm_data.key, created_by)
    db.close(db.get_session())
    if not llm_id:
        raise HTTPException(status_code=500, detail="Failed to create LLM")
    return {"message": "LLM created successfully", "id": llm_id}

@router.get("/llm")
async def get_all_llms():
    db = Database()
    service = LLMService(db)
    llms = service.get_all_llms()
    db.close(db.get_session())
    return [{"id": llm.id, "provider": llm.provider, "prefix": llm.prefix, "model": llm.model, "key": llm.key, "is_default": llm.is_default, "created_by": llm.created_by, "created_at": llm.created_at.isoformat() if llm.created_at else None, "updated_at": llm.updated_at.isoformat() if llm.updated_at else None} for llm in llms]

@router.get("/llm/{llm_id}")
async def get_llm(llm_id: int):
    db = Database()
    service = LLMService(db)
    llm = service.get_llm_by_id(llm_id)
    db.close(db.get_session())
    if not llm:
        raise HTTPException(status_code=404, detail="LLM not found")
    return {"id": llm.id, "provider": llm.provider, "prefix": llm.prefix, "model": llm.model, "key": llm.key, "is_default": llm.is_default, "created_by": llm.created_by, "created_at": llm.created_at.isoformat() if llm.created_at else None, "updated_at": llm.updated_at.isoformat() if llm.updated_at else None}

@router.put("/llm/{llm_id}")
async def update_llm(llm_id: int, llm_data: LLMUpdate):
    db = Database()
    service = LLMService(db)
    success = service.update_llm(llm_id, llm_data.provider, llm_data.prefix, llm_data.model, llm_data.key)
    db.close(db.get_session())
    if not success:
        raise HTTPException(status_code=404, detail="LLM not found or update failed")
    return {"message": "LLM updated successfully"}

@router.delete("/llm/{llm_id}")
async def delete_llm(llm_id: int):
    db = Database()
    service = LLMService(db)
    success = service.delete_llm(llm_id)
    db.close(db.get_session())
    if not success:
        raise HTTPException(status_code=404, detail="LLM not found or delete failed")
    return {"message": "LLM deleted successfully"}