from fastapi import APIRouter,WebSocket, WebSocketDisconnect
from pydantic import BaseModel
from services.speech_service import SpeechService
from database import Database
from dotenv import load_dotenv
import os
import asyncio
import websockets
import json


router = APIRouter()
load_dotenv()

DEEPGRAM_WS_URL = f"wss://api.deepgram.com/v1/listen?language=en-US&punctuate=true&endpointing=300"
DEEPGRAM_API_KEY=os.getenv("DEEPGRAM_API_KEY")

class TTSRequest(BaseModel):
    text: str

@router.websocket("/stt")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    print("WebSocket accepted")
    
    try:
        async with websockets.connect(
            DEEPGRAM_WS_URL,
            additional_headers={"Authorization": f"Token {DEEPGRAM_API_KEY}"}
        ) as dg_ws:
            print("🔗 Connected to Deepgram")
            
            async def receive_from_deepgram():
                try:
                    async for msg in dg_ws:
                        data = json.loads(msg)
                        transcript = (
                            data.get("channel", {})
                            .get("alternatives", [{}])[0]
                            .get("transcript", "")
                        )
                        if transcript:
                            await websocket.send_text(transcript)
                except Exception as e:
                    print(" Deepgram receive error:", e)
                    # await websocket.send_text("[System]: Deepgram error occurred.")
                    await websocket.send_text("No answer detected")
            
            dg_task = asyncio.create_task(receive_from_deepgram())
            
            try:
                while True:
                    try:
                        audio_chunk = await websocket.receive_bytes()
                        await dg_ws.send(audio_chunk)
                    except WebSocketDisconnect:
                        print("🚪 Frontend disconnected")
                        break
            except Exception as e:
                print("❌ Error in WebSocket endpoint:", e)
                # await websocket.send_text(f"[System]: Error: {str(e)}")
                await websocket.send_text("No answer detected")

            finally:
                await dg_ws.send(json.dumps({"type": "CloseStream"}))
                dg_task.cancel()
                try:
                    await dg_task
                except asyncio.CancelledError:
                    pass
                await dg_ws.close()
                # await websocket.close()
                print("✅ Connection closed")
    except Exception as e:
        print("❌ Error connecting to Deepgram:", e)
        # await websocket.send_text("[System]: Failed to connect to Deepgram.")
        await websocket.send_text("No answer detected")
        await websocket.close()

@router.websocket("/tts")
async def websocket_endpoint(websocket: WebSocket):
    db = Database()
    service = SpeechService(db)
    await service.stream_audio(websocket)
    db.close(db.get_session())