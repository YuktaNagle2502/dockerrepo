from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Literal, List
from services.agent_prompts_service import AgentPromptsService
from database import Database
from utility.template_utility import TemplateUtility

router = APIRouter()

class AgentPromptCreate(BaseModel):
    tech_stack_id: int
    agent_name: str
    prompt: Optional[str] = None
    placeholders: Dict = {}
    type: Optional[Literal['ASSISTANT', 'MESSAGE', 'AGENT', 'TASK']] = None

class AgentPromptUpdate(BaseModel):
    tech_stack_id: Optional[int] = None
    agent_name: Optional[str] = None
    prompt: Optional[str] = None
    placeholders: Optional[Dict] = None
    type: Optional[Literal['ASSISTANT', 'MESSAGE', 'AGENT', 'TASK']] = None

class TemplateTestRequest(BaseModel):
    template_string: str
    placeholders: Dict

@router.post("/agent-prompts")
async def create_agent_prompt(agent_prompt: AgentPromptCreate):
    db = Database()
    service = AgentPromptsService(db)
    prompt_id = service.create_agent_prompt(
        tech_stack_id=agent_prompt.tech_stack_id,
        agent_name=agent_prompt.agent_name,
        prompt=agent_prompt.prompt,
        placeholders=agent_prompt.placeholders,
        type=agent_prompt.type
    )
    db.close(db.get_session())
    return {"id": prompt_id, "message": "Agent prompt created successfully"}

@router.get("/agent-prompts")
async def get_all_agent_prompts():
    db = Database()
    service = AgentPromptsService(db)
    prompts = service.get_all_agent_prompts()
    db.close(db.get_session())
    return [{
        "id": prompt.id,
        "tech_stack_id": prompt.tech_stack_id,
        "agent_name": prompt.agent_name,
        "prompt": prompt.prompt,
        "placeholders": prompt.placeholders,
        "type": prompt.type,
        "created_at": prompt.created_at.isoformat()
    } for prompt in prompts]

@router.put("/agent-prompts/bulk-update")
async def bulk_update_agent_prompts(agent_prompts: List[dict]):
    db = Database()
    service = AgentPromptsService(db)
    updated_count = service.bulk_update_agent_prompts(agent_prompts)
    db.close(db.get_session())
    return {"message": f"{updated_count} agent prompts updated successfully"}

@router.get("/agent-prompts/{prompt_id}")
async def get_agent_prompt_by_id(prompt_id: int):
    db = Database()
    service = AgentPromptsService(db)
    prompt = service.get_agent_prompt_by_id(prompt_id)
    db.close(db.get_session())
    if not prompt:
        raise HTTPException(status_code=404, detail="Agent prompt not found")
    return {
        "id": prompt.id,
        "tech_stack_id": prompt.tech_stack_id,
        "agent_name": prompt.agent_name,
        "prompt": prompt.prompt,
        "placeholders": prompt.placeholders,
        "type": prompt.type,
        "created_at": prompt.created_at.isoformat()
    }

@router.get("/agent-prompts/tech-stack/{tech_stack_id}")
async def get_agent_prompts_by_tech_stack(tech_stack_id: int):
    db = Database()
    service = AgentPromptsService(db)
    prompts = service.get_agent_prompts_by_tech_stack(tech_stack_id)
    db.close(db.get_session())
    return [{
        "id": prompt.id,
        "tech_stack_id": prompt.tech_stack_id,
        "agent_name": prompt.agent_name,
        "prompt": prompt.prompt,
        "placeholders": prompt.placeholders,
        "type": prompt.type,
        "created_at": prompt.created_at.isoformat()
    } for prompt in prompts]

@router.put("/agent-prompts/{prompt_id}")
async def update_agent_prompt(prompt_id: int, agent_prompt: AgentPromptUpdate):
    db = Database()
    service = AgentPromptsService(db)
    success = service.update_agent_prompt(
        prompt_id=prompt_id,
        tech_stack_id=agent_prompt.tech_stack_id,
        agent_name=agent_prompt.agent_name,
        prompt=agent_prompt.prompt,
        placeholders=agent_prompt.placeholders,
        type=agent_prompt.type
    )
    db.close(db.get_session())
    if not success:
        raise HTTPException(status_code=404, detail="Agent prompt not found")
    return {"message": "Agent prompt updated successfully"}

@router.delete("/agent-prompts/{prompt_id}")
async def delete_agent_prompt(prompt_id: int):
    db = Database()
    service = AgentPromptsService(db)
    success = service.delete_agent_prompt(prompt_id)
    db.close(db.get_session())
    if not success:
        raise HTTPException(status_code=404, detail="Agent prompt not found")
    return {"message": "Agent prompt deleted successfully"}

@router.post("/template/test")
async def test_template_utility(request: TemplateTestRequest):
    processed_string = TemplateUtility.replace_placeholders(
        request.template_string, 
        request.placeholders
    )
    return {
        "original_template": request.template_string,
        "placeholders": request.placeholders,
        "processed_string": processed_string
    }