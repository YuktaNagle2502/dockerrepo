from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from services.question_service import QuestionService
from database import Database

router = APIRouter()

class Item(BaseModel):
    question: str
    reference_answer: str
    user_answer: str

class Item2(BaseModel):
    question: str

@router.post("/generate_dynamic_question_autogen_resume/{unique_id}")
async def generate_dynamic_question(question: Item,unique_id: str):
    db = Database()
    service = QuestionService(db)
    qa_dict = await service.generate_dynamic_question(question,unique_id)
    db.close(db.get_session())
    return qa_dict

# @router.post("/generate_user_question")
# async def generate_dynamic_added(question: Item2):
#     db = Database()
#     service = QuestionService(db)
#     result = await service.generate_dynamic_added(question)
#     db.close(db.get_session())
#     return result

@router.post("/evaluate/{user_id}")
async def evaluate_interview(user_id: str):
    db = Database()
    service = QuestionService(db)
    result = service.evaluate_interview(user_id)
    db.close(db.get_session())
    return result