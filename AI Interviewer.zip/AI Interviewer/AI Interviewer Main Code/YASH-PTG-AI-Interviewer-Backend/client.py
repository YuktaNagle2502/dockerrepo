import requests
import json

def get_evaluation_results1(base_url="http://127.0.0.1:8000"):
    try:
        endpoint = f"{base_url}/question/generate_question_autogen_resume"
        response = requests.get(endpoint)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return f"Error making request: {str(e)}"
    except json.JSONDecodeError as e:
        return f"Error parsing JSON response: {str(e)}"
print(get_evaluation_results1())

def get_evaluation_results2(base_url="http://127.0.0.1:8000"):
    try:
        endpoint = f"{base_url}/jd/generate_question_autogen_jd"
        response = requests.get(endpoint)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return f"Error making request: {str(e)}"
    except json.JSONDecodeError as e:
        return f"Error parsing JSON response: {str(e)}"
print(get_evaluation_results2())

def get_evaluation_results4(base_url="http://127.0.0.1:8000"):
    try:
        endpoint = f"{base_url}/question/generate_dynamic_question_autogen_resume"
        response = requests.get(endpoint)
        response.raise_for_status()
        print(response.json())
        return response.json()
    except requests.exceptions.RequestException as e:
        return f"Error making request: {str(e)}"
    except json.JSONDecodeError as e:
        return f"Error parsing JSON response: {str(e)}"
print(get_evaluation_results4())

def get_evaluation_results(base_url="http://127.0.0.1:8000"):
    try:
        endpoint = f"{base_url}/question/evaluate"
        response = requests.get(endpoint)
        response.raise_for_status()
        print(json.loads(response.json()))
        return json.loads(response.json())
    except requests.exceptions.RequestException as e:
        return f"Error making request: {str(e)}"
    except json.JSONDecodeError as e:
        return f"Error parsing JSON response: {str(e)}"
print(get_evaluation_results())