from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import os
from dotenv import load_dotenv
load_dotenv()
class Database:
    _engine = None
    _Session = None

    def __init__(self, connection_url=os.getenv("DATABASE_URL")):
        print(":connection_url:",connection_url)
        if not Database._engine:
            try:
                Database._engine = create_engine(connection_url)
                Database._Session = sessionmaker(bind=Database._engine)
            except Exception as e:
                print(f"Error initializing database: {e}")
                raise

    def get_session(self):
        return Database._Session()

    def close(self, session):
        session.close()