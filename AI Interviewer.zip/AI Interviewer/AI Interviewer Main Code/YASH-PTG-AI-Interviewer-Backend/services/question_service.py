from sqlalchemy.orm import Session
from database import Database
import asyncio
import os
from fastapi import APIRouter, HTTPException, UploadFile
import json
from fastapi.encoders import jsonable_encoder
from typing import Dict, List, Optional
from datetime import datetime
from collections import defaultdict
import xml.etree.ElementTree as ET
from io import BytesIO, StringIO
import numpy as np
from utility.template_utility import TemplateUtility
import html
import uuid
import boto3
import PyPDF2
import io
import re
import nltk
from nltk.translate.bleu_score import sentence_bleu
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import chromadb
import autogen
from autogen import AssistantAgent, UserProxyAgent
from models import InterviewDetailsMain, JDDetails, UsersStats, LLMs, AgentPrompts
from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent
import random
import hashlib
import time
from pydantic import BaseModel
from botocore.exceptions import ClientError

try:
    from crewai import Crew, Task, Agent, LLM, Process
except ImportError:
    Crew = Task = Agent = LLM = Process = None
from dotenv import load_dotenv

nltk.download('punkt', quiet=True)
load_dotenv()

embedding_model = SentenceTransformer('sentence-transformers/all-minilm-l6-v2', token=os.getenv("HF_TOKEN"))

class CustomEmbeddingFunction:
    def __init__(self, model):
        self.model = model

    def __call__(self, input):
        return self.model.encode(input).tolist()

class ResumeScoreRequest(BaseModel):
    job_description: str
    resume_text: str
    domain: str = "General"
    llm_id: int

class ResumeScoreResponse(BaseModel):
    score: float
    summary_points: List[str]
    raw_response: str

embedding_function = CustomEmbeddingFunction(embedding_model)

class QuestionService:
    def __init__(self, db: Database):
        self.db = db
        self.session = db.get_session()

    def get_llm_config_by_id(self, llm_id: int) -> List[Dict]:
        """
        Retrieve LLM configuration by ID
        Args:
            llm_id: LLM configuration ID
        Returns:
            List of configuration dictionaries
        """
        try:
            llm_config = self.session.query(LLMs).filter(LLMs.id == llm_id).first()
            
            if llm_config:
                config = {
                    "model": llm_config.model,
                    "api_key": llm_config.key,
                    "api_type": llm_config.provider.lower()
                }
                return [config]
            else:
                print(f"LLM configuration not found for ID: {llm_id}")
                raise HTTPException(status_code=500, detail="LLM configuration not found for ID: {llm_id}")
                
        except Exception as e:
            print(f"Error retrieving LLM config by ID: {e}")
            raise HTTPException(status_code=500, detail=f"Error retrieving LLM config by ID: {e}")

    def get_assistant_prompts_by_tech_stack(self, tech_stack_id: int) -> Dict[str, str]:
        """
        Get assistant prompts from database by tech_stack_id and return as a dictionary
        with agent_name as key and prompt as value (with placeholders replaced using DB stored values)
        
        Args:
            tech_stack_id: ID of the tech stack
            
        Returns:
            Dictionary with agent_name as key and processed prompt as value
        """
        from utility.template_utility import TemplateUtility  # Import your utility class
        
        db = Database()
        session = db.get_session()
        
        try:
            # Query for prompts with type 'ASSISTANT' and specific tech_stack_id
            prompts = session.query(AgentPrompts).filter(
                AgentPrompts.tech_stack_id == tech_stack_id,
                AgentPrompts.type == 'ASSISTANT'
            ).all()
            
            # Convert to dictionary with agent_name as key and process placeholders
            prompts_dict = {}
            for prompt in prompts:
                if prompt.agent_name and prompt.prompt:
                    processed_prompt = prompt.prompt
                    
                    # Replace placeholders using stored values from database
                    if prompt.placeholders:
                        processed_prompt = TemplateUtility.replace_placeholders(
                            prompt.prompt,
                            prompt.placeholders
                        )
                    
                    prompts_dict[prompt.agent_name] = processed_prompt
            print("prompts_dict:", prompts_dict)
            return prompts_dict
        
        except Exception as e:
            # Log the error or handle it as appropriate for your application
            print(f"Error fetching assistant prompts: {str(e)}")
            return {}
        
        finally:
            db.close(session)

    def create_dynamic_agents(self, llm_id: Optional[int] = None, tech_stack_id: Optional[int] = None) -> Dict:
        """Create agents with dynamic LLM configuration from database"""
        if llm_id:
            config_list = self.get_llm_config_by_id(llm_id)
        else:
            raise HTTPException(status_code=500, detail="LLM not found during create_dynamic_agents")
        
        if not tech_stack_id:
            raise HTTPException(status_code=500, detail="Tech stack ID is required for dynamic agents")
        
        # Get prompts from database with placeholders replaced using DB stored values
        prompts_dict = self.get_assistant_prompts_by_tech_stack(tech_stack_id)
        print("prompts_dict.get('jd_assistant'):", prompts_dict.get('jd_assistant'))
        return {
            'jd_assistant': AssistantAgent(
                name="jd_assistant",
                system_message=prompts_dict.get('jd_assistant'),
                llm_config={"config_list": config_list, "seed": 25}
            ),
            'resume_assistant': AssistantAgent(
                name="resume_assistant",
                system_message=prompts_dict.get('resume_assistant'),
                llm_config={"config_list": config_list, "seed": 25}
            ),
            "dynamic_question_assistant": AssistantAgent(
                name="dynamic_question_assistant",
                system_message=prompts_dict.get('dynamic_question_assistant'),
                llm_config={"config_list": config_list, "seed": 25}
            ),
            'file_based_assistant': AssistantAgent(
                name="file_based_assistant",
                system_message=prompts_dict.get('file_based_assistant'),
                llm_config={"config_list": config_list, "seed": 25}
            ),
            'domain_assistant': AssistantAgent(
                name="domain_assistant",
                system_message=prompts_dict.get('domain_assistant'),
                llm_config={"config_list": config_list, "seed": 25}
            ),
            'user_proxy': UserProxyAgent(
                name="user_proxy",
                human_input_mode="NEVER",
                code_execution_config=False,
                max_consecutive_auto_reply=0,
            ),
        }

    def xml_to_dict_list1(self, xml_string):
        xml_string = xml_string.replace("```xml\n", "").replace("\n```", "").replace("\\n", "\n")
        tree = ET.parse(StringIO(xml_string))
        root = tree.getroot()
        qa_list = []
        for qa in root.findall('qa'):
            qa_dict = {
                "question": qa.find('question').text.strip(),
                "answer": qa.find('answer').text.strip()
            }
            qa_list.append(qa_dict)
        return qa_list

    def xml_to_dict2(self, xml_string):
        xml_string = xml_string.replace("```xml\n", "").replace("\n```", "").replace("\\n", "\n")
        xml_string = xml_string.encode('utf-8').decode('utf-8-sig')  # Remove BOM
        xml_string = re.sub(r'[\x00-\x1F\x7F]', '', xml_string)  # Remove control characters
        print("Cleaned xml_string:", xml_string)
        try:
            tree = ET.parse(StringIO(xml_string))
            root = tree.getroot()
            
            qa_dict = {}
            
            # Find all <qa> elements
            for qa in root.findall('qa'):
                question = qa.find('question').text.strip() if qa.find('question') is not None else ""
                answer = qa.find('answer').text.strip() if qa.find('answer') is not None else ""
                qa_dict = {
                    "question": question,
                    "answer": answer
                }
            
            return qa_dict
        
        except ET.ParseError as e:
            print(f"XML parsing error: {e}")
            print("Problematic XML:", xml_string)
            raise ValueError(f"Failed to parse XML: {e}")

    def _generate_dynamic_seed(self, base_content: str) -> int:
        """Generate a dynamic seed based on content and current time"""
        # Create a hash of the content combined with current timestamp
        timestamp = str(int(time.time() * 1000))  # millisecond precision
        random_component = str(random.randint(1000, 9999))
        combined = f"{base_content}_{timestamp}_{random_component}"
        
        # Generate hash and convert to integer seed
        hash_object = hashlib.md5(combined.encode())
        seed = int(hash_object.hexdigest()[:8], 16) % (2**31 - 1)
        return seed

    def _get_question_focus_areas(self) -> List[str]:
        """Define different focus areas for question generation"""
        return [
            "technical implementation and coding challenges",
            "system design and architecture principles",
            "problem-solving and algorithmic thinking",
            "best practices and code quality standards",
            "performance optimization and scalability",
            "debugging and troubleshooting scenarios",
            "team collaboration and project management",
            "emerging technologies and future trends"
        ]

    def _get_question_styles(self) -> List[str]:
        """Define different question styles"""
        return [
            "scenario-based problem solving",
            "conceptual understanding and theory",
            "practical implementation examples",
            "comparative analysis between approaches",
            "real-world project experience",
            "troubleshooting and debugging situations"
        ]

    async def generate_dynamic_question(self, question, unique_id):
        llm_id = self.session.query(JDDetails.llm_id).join(InterviewDetailsMain, JDDetails.job_id == InterviewDetailsMain.job_id).filter(InterviewDetailsMain.unique_id == unique_id).first()
        tech_stack_id = self.session.query(JDDetails.tech_stack_id).join(InterviewDetailsMain, JDDetails.job_id == InterviewDetailsMain.job_id).filter(InterviewDetailsMain.unique_id == unique_id).first()
        print("llm_id:", llm_id[0], " tech_stack_id", tech_stack_id[0])
        agents = self.create_dynamic_agents(llm_id[0], tech_stack_id[0])
        agent_prompt = self.session.query(AgentPrompts).filter(
            AgentPrompts.agent_name == 'generate_follow_up_questions',
            AgentPrompts.tech_stack_id == tech_stack_id[0]
        ).first()
        
        if not agent_prompt:
            print(f"No prompt found for agent 'generate_follow_up_questions' with tech_stack_id {tech_stack_id[0]}")
            raise HTTPException(status_code=500, detail=f"No prompt found for agent 'generate_follow_up_questions' with tech_stack_id {tech_stack_id}")
        else:
            # Use the prompt from database and replace placeholders
            template_prompt = agent_prompt.prompt
            placeholders = {}
            
            # Get placeholders from database
            if agent_prompt.placeholders:
                placeholders = agent_prompt.placeholders
            
            # Replace placeholders in the template
            message = TemplateUtility.replace_placeholders(template_prompt, placeholders)
            print("message", message)

            max_retries = 2
            for attempt in range(max_retries):
                try:
                    chat_result = agents['user_proxy'].initiate_chat(
                        agents['dynamic_question_assistant'],
                        message=f"""
                        For the given question: {question.question},
                        {message}"""
                    )
                    xml_content = chat_result.summary
                    qa_dict = self.xml_to_dict2(xml_content)
                    return qa_dict
                except ValueError as e:
                    if "Failed to parse XML" in str(e):
                        print(f"XML parsing failed on attempt {attempt + 1}/{max_retries}: {str(e)}")
                        if attempt == max_retries - 1:
                            raise HTTPException(status_code=500, detail=f"Failed to generate valid XML after {max_retries} attempts: {str(e)}")
                        continue
                    else:
                        raise e

    def generate_resume(self, llm_id, tech_stack_id, resume: bytes):
        print(f"Starting generate_resume")
        agents = self.create_dynamic_agents(llm_id, tech_stack_id)
        # Convert bytes to a PDF reader object
        pdf_reader = PyPDF2.PdfReader(BytesIO(resume))
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text() or ""
        
        agent_prompt = self.session.query(AgentPrompts).filter(
            AgentPrompts.agent_name == 'generate_question_by_resume',
            AgentPrompts.tech_stack_id == tech_stack_id
        ).first()
        
        if not agent_prompt:
            print(f"No prompt found for agent 'generate_question_by_resume' with tech_stack_id {tech_stack_id}")
            raise HTTPException(status_code=500, detail=f"No prompt found for agent 'generate_question_by_resume' with tech_stack_id {tech_stack_id}")
        else:
            # Use the prompt from database and replace placeholders
            template_prompt = agent_prompt.prompt
            placeholders = {}

            # Get placeholders from database
            if agent_prompt.placeholders:
                placeholders = agent_prompt.placeholders
            
            # Replace placeholders in the template
            message = TemplateUtility.replace_placeholders(template_prompt, placeholders)
            print("message", message)
        code_problem = f"""
        {text}
        {message}"""
        chat_result = agents['user_proxy'].initiate_chat(
            agents['resume_assistant'], message=code_problem, n_results=2
        )
        xml_content = chat_result.summary
        qa_list = self.xml_to_dict_list1(xml_content)
        return qa_list

    def generate_jd_question(self, jd_file: bytes, llm_id: Optional[int] = None, tech_stack_id: Optional[int] = None):
        max_retries = 2
        for attempt in range(max_retries):
            try:
                agents = self.create_dynamic_agents(llm_id, tech_stack_id)
                # Convert bytes to a PDF reader object
                pdf_reader = PyPDF2.PdfReader(BytesIO(jd_file))
                text = ""
                for page in pdf_reader.pages:
                    text += page.extract_text() or ""
                # Generate dynamic seed for unique questions
                dynamic_seed = self._generate_dynamic_seed(text)
                # Select random focus areas and question styles
                focus_areas = random.sample(self._get_question_focus_areas(), 2)
                question_styles = random.sample(self._get_question_styles(), 2)
                # Add randomization elements to the prompt
                randomization_elements = [
                    f"Focus primarily on: {focus_areas[0]} and {focus_areas[1]}",
                    f"Use question styles: {question_styles[0]} and {question_styles[1]}",
                    f"Generation seed: {dynamic_seed}",
                    f"Timestamp: {datetime.now().isoformat()}"
                ]

                agent_prompt = self.session.query(AgentPrompts).filter(
                    AgentPrompts.agent_name == 'generate_question_by_jd',
                    AgentPrompts.tech_stack_id == tech_stack_id
                ).first()
            
                if not agent_prompt:
                    print(f"No prompt found for agent 'generate_question_by_jd' with tech_stack_id {tech_stack_id}")
                    raise HTTPException(status_code=500, detail=f"No prompt found for agent 'generate_question_by_jd' with tech_stack_id {tech_stack_id}")
                else:
                    # Use the prompt from database and replace placeholders
                    template_prompt = agent_prompt.prompt
                    placeholders = {}
                    # Get placeholders from database
                    if agent_prompt.placeholders:
                        placeholders = agent_prompt.placeholders
                    # Replace placeholders in the template
                    message = TemplateUtility.replace_placeholders(template_prompt, placeholders)
                    print("message", message)
                code_problem = f"""
                Based on the provided job description context: {text},
                generate a UNIQUE and DIVERSE structured list of interview questions and answers.
                IMPORTANT RANDOMIZATION INSTRUCTIONS:
                {chr(10).join(randomization_elements)}
                {message}"""
                chat_result = agents['user_proxy'].initiate_chat(
                    agents['jd_assistant'], message=code_problem, n_results=2
                )
                xml_content = chat_result.summary
                qa_list = self.xml_to_dict_list1(xml_content)
                return qa_list
            except Exception as e:
                print(f"Error processing JD file on attempt {attempt + 1}/{max_retries}: {e}")
                if attempt == max_retries - 1:
                    print(f"Failed to process JD file after {max_retries} attempts")
                    return []
                continue

    def generate_dynamic_domain(self, domain: str, llm_id: int, tech_stack_id: int):
        agents = self.create_dynamic_agents(llm_id, tech_stack_id)
        agent_prompt = self.session.query(AgentPrompts).filter(
            AgentPrompts.agent_name == 'generate_question_by_domain',
            AgentPrompts.tech_stack_id == tech_stack_id
        ).first()
        
        if not agent_prompt:
            print(f"No prompt found for agent 'generate_question_by_domain' with tech_stack_id {tech_stack_id}")
            raise HTTPException(status_code=500, detail=f"No prompt found for agent 'generate_question_by_domain' with tech_stack_id {tech_stack_id}")
        else:
            # Use the prompt from database and replace placeholders
            template_prompt = agent_prompt.prompt
            placeholders = {}

            # Get placeholders from database
            if agent_prompt.placeholders:
                placeholders = agent_prompt.placeholders
            
            # Replace placeholders in the template
            message = TemplateUtility.replace_placeholders(template_prompt, placeholders)
            print("message", message)

        chat_result = agents['user_proxy'].initiate_chat(
            agents['domain_assistant'],
            message=f"""
            For the given domain == {domain},
            {message}"""
        )
        xml_content = chat_result.summary
        qa_dict = self.xml_to_dict2(xml_content)
        return qa_dict

    async def generate_file_based_question(self, file: bytes, llm_id: int, tech_stack_id: int):
        agents = self.create_dynamic_agents(llm_id, tech_stack_id)
        agent_prompt = self.session.query(AgentPrompts).filter(
            AgentPrompts.agent_name == 'generate_answer_for_file_questions',
            AgentPrompts.tech_stack_id == tech_stack_id
        ).first()
        
        if not agent_prompt:
            print(f"No prompt found for agent 'generate_answer_for_file_questions' with tech_stack_id {tech_stack_id}")
            raise HTTPException(status_code=500, detail=f"No prompt found for agent 'generate_answer_for_file_questions' with tech_stack_id {tech_stack_id}")
        else:
            # Use the prompt from database and replace placeholders
            template_prompt = agent_prompt.prompt
            placeholders = {}

            # Get placeholders from database
            if agent_prompt.placeholders:
                placeholders = agent_prompt.placeholders
            
            # Replace placeholders in the template
            message = TemplateUtility.replace_placeholders(template_prompt, placeholders)
            print("message", message)

        try:
            if isinstance(file, memoryview):
                text = file.tobytes().decode('utf-8')
            else:
                text = file.decode('utf-8')
            chat_result = agents['user_proxy'].initiate_chat(
                agents['file_based_assistant'],
                message=f"""
                For given list of question == {text},
                {message}"""
            )
            xml_content = chat_result.summary
            qa_list = self.xml_to_dict_list1(xml_content)
            return qa_list
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    def calculate_similarity(self, user_answer: str, reference_answer: str) -> tuple:
        if len(user_answer.strip()) < 10:
            return 0.0, 0.0
        user_answer = user_answer.lower().strip()
        reference_answer = reference_answer.lower().strip()
        vectorizer = TfidfVectorizer()
        try:
            user_vector = vectorizer.fit_transform([user_answer])
            correct_vector = vectorizer.transform([reference_answer])
            similarity_score = float(cosine_similarity(user_vector, correct_vector)[0][0])
        except Exception:
            similarity_score = 0.0
        user_tokens = user_answer.split()
        correct_tokens = reference_answer.split()
        if not user_tokens or not correct_tokens:
            bleu_score = 0.0
        else:
            bleu_score = float(sentence_bleu([correct_tokens], user_tokens))
        return similarity_score, bleu_score

    def simple_context_match(self, user_answer: str, reference_answer: str) -> float:
        user_words = set(user_answer.lower().split())
        ref_words = set(reference_answer.lower().split())
        intersection = len(user_words.intersection(ref_words))
        union = len(user_words.union(ref_words))
        context_score = intersection / union if union > 0 else 0.0
        return min(1.0, context_score)

    def ensure_json_loaded(self, data):
        # Check if data is a JSON string
        if isinstance(data, str):
            try:
                parsed_data = json.loads(data)
                if isinstance(parsed_data, list) and all(isinstance(item, dict) for item in parsed_data):
                    return parsed_data
                else:
                    print("Error: JSON string does not contain a list of dictionaries.")
                    return []
            except json.JSONDecodeError as e:
                print("JSON Decode Error:", e)
                return []
        elif isinstance(data, list) and all(isinstance(item, dict) for item in data):
            return data
        else:
            print("Invalid input: expected JSON string or list of dictionaries.")
            return []

    def evaluate_answers(self, qa_pairs: List[Dict], llm_id: int, tech_stack_id: int, user_id: str, use_llm: bool = True) -> Dict:
        final_results = {
            'overall_score': 0.0,
            'question_scores': []
        }
        print(f"Starting evaluate_answers with llm_id: {llm_id}, tech_stack_id: {tech_stack_id}, user_id: {user_id}, use_llm: {use_llm}")
        
        # Validate input qa_pairs
        if not isinstance(qa_pairs, list):
            print(f"Error: qa_pairs is not a list: {qa_pairs}")
            raise HTTPException(status_code=500, detail="Invalid qa_pairs format: must be a list")
        for qa in qa_pairs:
            if not all(key in qa for key in ['question', 'user_answer', 'reference_answer']):
                print(f"Error: Invalid qa_pair missing required keys: {qa}")
                raise HTTPException(status_code=500, detail="Invalid qa_pair: missing required keys (question, user_answer, reference_answer)")

        # Retrieve LLM configuration
        llm_config = self.session.query(LLMs).filter(LLMs.id == llm_id).first()
        if not llm_config:
            print(f"Error: LLM configuration not found for ID: {llm_id}")
            raise HTTPException(status_code=500, detail=f"LLM configuration not found for ID: {llm_id}")

        # Retrieve agent prompt with fallback
        agent_prompt = self.session.query(AgentPrompts).filter(
            AgentPrompts.agent_name == 'evaluate_answer',
            AgentPrompts.tech_stack_id == tech_stack_id
        ).first()
        if not agent_prompt:
            print(f"No prompt found for agent 'evaluate_answer' with tech_stack_id {tech_stack_id}")
            template_prompt = """
            Evaluate the candidate's answer for correctness, clarity, and completeness. Provide a single paragraph comment without mentioning the reference answer, including:
            - How correct the response is (e.g., percentage or general assessment).
            - What key points the candidate is lacking or misunderstood.
            - Suggestions for improvement (e.g., clarity, precision, or inclusion of key concepts).
            """
            placeholders = {}
        else:
            template_prompt = agent_prompt.prompt
            placeholders = agent_prompt.placeholders if agent_prompt.placeholders else {}
        prompt = TemplateUtility.replace_placeholders(template_prompt, placeholders)
        print(f"Agent prompt: {prompt}")

        print(f"Input qa_pairs: {qa_pairs}")
        total_weight = 0
        total_score = 0.0

        # Check if CrewAI is available
        if Crew is None or Task is None or Agent is None or LLM is None:
            print("Warning: CrewAI is not available, falling back to basic evaluation")
            use_llm = False

        # Initialize context match agent only if CrewAI is available
        context_match_agent = None
        if use_llm and Crew is not None:
            try:
                context_match_agent = Agent(
                    role='Technical Answer Evaluator',
                    goal='Accurately evaluate the contextual similarity between technical answers',
                    backstory="""Expert in analyzing technical answers with deep understanding of:
                    - Core concepts and principles
                    - Different valid approaches to solutions
                    - Technical terminology and synonyms
                    - Implementation variations
                    - Best practices and patterns""",
                    verbose=True,
                    allow_delegation=False,
                    llm=LLM(
                        model=f"{llm_config.prefix}/{llm_config.model}",
                        api_key=f"{llm_config.key}"
                    )
                )
            except Exception as e:
                print(f"Error creating context_match_agent: {str(e)}")
                use_llm = False
                context_match_agent = None

        # Calculate basic scores first
        context_match_scores = []
        for i, qa_pair in enumerate(qa_pairs):
            try:
                similarity_score, bleu_score = self.calculate_similarity(
                    qa_pair['user_answer'],
                    qa_pair['reference_answer']
                )
                context_match_score = self.simple_context_match(
                    qa_pair['user_answer'],
                    qa_pair['reference_answer']
                )
                # Use similarity_score as fallback if context_match_score is 0.0 for non-empty answers
                if context_match_score == 0.0 and qa_pair['user_answer'].strip().lower() != "no answer":
                    context_match_score = similarity_score * 0.5  # Scale down to be conservative
                    print(f"Warning: context_match_score is 0.0 for QA pair {i+1}, using scaled similarity_score: {context_match_score}")
                total_score += context_match_score
                total_weight += 1
                context_match_scores.append(context_match_score)
                print(f"Processed QA pair {i+1}: similarity_score={similarity_score}, bleu_score={bleu_score}, context_match_score={context_match_score}")
            except Exception as e:
                print(f"Error processing QA pair {i+1}: {str(e)}")
                context_match_scores.append(0.0)
                total_weight += 1
                print(f"Set context_match_score to 0.0 for QA pair {i+1} due to error")

        print(f"Total score before normalization: {total_score}, Total weight: {total_weight}")

        # COMBINED ANALYSIS FOR AI COMMENTS AND OVERALL METRICS
        ai_comments = []
        overall_metrics = {}
        
        if use_llm and context_match_agent is not None and Crew is not None and Task is not None:
            try:
                # Create comprehensive prompt for combined analysis
                combined_analysis_prompt = f"""
                Analyze the following interview session with {len(qa_pairs)} questions and provide:

                1. INDIVIDUAL AI COMMENTS: For each question, provide detailed feedback based on the candidate's actual response
                2. OVERALL METRICS: Assess communication skills, grammatical correctness, clarity, and conclusion

                INTERVIEW DATA:
                """
                
                # Add all Q&A pairs to the prompt
                for i, qa_pair in enumerate(qa_pairs, 1):
                    combined_analysis_prompt += f"""
                
                QUESTION {i}:
                Question: {qa_pair['question']}
                Candidate's Answer: {qa_pair['user_answer']}
                Expected Answer Context: {qa_pair['reference_answer']}
                Calculated Score: {context_match_scores[i-1]:.2f}
                """

                combined_analysis_prompt += f"""

                INSTRUCTIONS:
                1. For AI COMMENTS: Analyze each candidate response individually and provide constructive feedback without mentioning the reference answer. Focus on:
                - Technical accuracy and understanding shown
                - Completeness of the response
                - Areas where the candidate demonstrated knowledge
                - Specific areas for improvement
                - Suggestions for better answers

                2. For OVERALL METRICS: Evaluate across all responses:
                - Communication skills (structure, coherence, professionalism)
                - Grammatical correctness (grammar, syntax, language usage)
                - Clarity (understandability and precision)
                - Overall conclusion

                OUTPUT FORMAT (JSON):
                {{
                    "ai_comments": [
                        {{"question": "Question 1 text", "ai_comment": "Detailed feedback for question 1"}},
                        {{"question": "Question 2 text", "ai_comment": "Detailed feedback for question 2"}},
                        // ... for all questions
                    ],
                    "overall_metrics": {{
                        "communication_skills": "Assessment of communication effectiveness",
                        "communication_skills_percentage": 0.75,
                        "grammatical_correctness": "Assessment of grammar and language usage",
                        "grammatical_correctness_percentage": 0.80,
                        "clarity": "Assessment of clarity and understandability",
                        "clarity_percentage": 0.70,
                        "conclusion": "Overall summary of candidate's performance"
                    }}
                }}

                SCORING GUIDELINES (0.0 to 1.0):
                - 0.9-1.0: Exceptional
                - 0.8-0.89: Excellent  
                - 0.7-0.79: Good
                - 0.6-0.69: Moderate
                - 0.5-0.59: Average
                - 0.4-0.49: Below average
                - 0.3-0.39: Poor
                - 0.2-0.29: Very poor
                - 0.1-0.19: Minimal
                - 0.0-0.09: None

                {prompt}
                """

                task = Task(
                    description=combined_analysis_prompt,
                    expected_output="JSON object with ai_comments array and overall_metrics object",
                    agent=context_match_agent
                )
                
                crew = Crew(
                    agents=[context_match_agent],
                    tasks=[task],
                    process=Process.sequential,
                    verbose=True
                )
                
                result = crew.kickoff()
                raw_result = str(result.raw) if hasattr(result, 'raw') else str(result)
                print(f"LLM raw result for combined analysis: {raw_result}")
                
                # Clean and parse the result
                cleaned_result = raw_result.strip()
                if cleaned_result.startswith('```json') and cleaned_result.endswith('```'):
                    cleaned_result = cleaned_result[7:-3].strip()
                elif cleaned_result.startswith('```') and cleaned_result.endswith('```'):
                    cleaned_result = cleaned_result[3:-3].strip()
                
                print(f"Cleaned LLM result: {cleaned_result}")
                
                try:
                    combined_analysis = json.loads(cleaned_result)
                    if isinstance(combined_analysis, dict):
                        # Extract AI comments
                        if 'ai_comments' in combined_analysis and isinstance(combined_analysis['ai_comments'], list):
                            ai_comments = combined_analysis['ai_comments']
                            # Clean newlines in AI comments
                            for comment in ai_comments:
                                if 'ai_comment' in comment:
                                    comment['ai_comment'] = comment['ai_comment'].replace('\n', ' ')
                        
                        # Extract overall metrics
                        if 'overall_metrics' in combined_analysis and isinstance(combined_analysis['overall_metrics'], dict):
                            overall_metrics = combined_analysis['overall_metrics']
                            # Clean newlines in text fields
                            for key in ['communication_skills', 'grammatical_correctness', 'clarity', 'conclusion']:
                                if key in overall_metrics:
                                    overall_metrics[key] = overall_metrics[key].replace('\n', ' ')
                            
                            # Convert numerical scores to percentages
                            for key in ['communication_skills_percentage', 'grammatical_correctness_percentage', 'clarity_percentage']:
                                if key in overall_metrics:
                                    try:
                                        overall_metrics[key] = float(overall_metrics[key]) * 100
                                    except (ValueError, TypeError):
                                        overall_metrics[key] = 0.0
                                        
                    else:
                        print(f"Error: LLM did not return a valid JSON object: {combined_analysis}")
                        
                except json.JSONDecodeError as e:
                    print(f"JSON Decode Error in combined analysis: {e}")
                    print(f"Problematic JSON: {cleaned_result}")
                    
            except Exception as e:
                print(f"Error generating combined analysis with CrewAI: {str(e)}")

        # Generate fallback comments and metrics if LLM analysis failed
        if not ai_comments:
            print("Generating fallback AI comments based on calculated scores")
            for i, qa_pair in enumerate(qa_pairs):
                context_match_score = context_match_scores[i]
                user_answer = qa_pair['user_answer'].strip()
                
                if user_answer.lower() in ['no answer', '', 'n/a']:
                    comment = "No response was provided for this question. Consider preparing specific examples and explanations for similar technical concepts in future interviews."
                elif context_match_score >= 0.8:
                    comment = f"Excellent response demonstrating strong understanding of the concept. The answer shows {context_match_score*100:.1f}% alignment with expected knowledge areas. Well articulated with good technical depth."
                elif context_match_score >= 0.6:
                    comment = f"Good response with {context_match_score*100:.1f}% relevance to the question. Shows solid understanding but could benefit from more specific examples or deeper explanation of key concepts."
                elif context_match_score >= 0.4:
                    comment = f"Partial understanding evident with {context_match_score*100:.1f}% relevance. The response touches on some relevant points but lacks completeness. Consider elaborating on core concepts and providing concrete examples."
                elif context_match_score >= 0.2:
                    comment = f"Limited understanding shown with {context_match_score*100:.1f}% relevance to the expected answer. The response shows basic awareness but misses key technical details. Focus on studying fundamental concepts more thoroughly."
                else:
                    comment = f"Response shows minimal relevance ({context_match_score*100:.1f}%) to the question asked. Consider reviewing the fundamental concepts and practicing with similar technical questions."
                
                ai_comments.append({
                    'question': qa_pair['question'],
                    'ai_comment': comment
                })

        # Replace the fallback overall metrics section (around lines 850-900) with this dynamic version:

        if not overall_metrics:
            print("Generating fallback overall metrics")
            # Check if all answers are "No answer"
            all_no_answer = all(qa_pair['user_answer'].strip().lower() in ['no answer', '', 'n/a'] for qa_pair in qa_pairs)
            
            if all_no_answer:
                overall_metrics = {
                    'communication_skills': 'No communication is evident as there are no answers provided.',
                    'communication_skills_percentage': 0.0,
                    'grammatical_correctness': 'Not applicable, as no text is present.',
                    'grammatical_correctness_percentage': 0.0,
                    'clarity': 'No clarity can be assessed due to the absence of responses.',
                    'clarity_percentage': 0.0,
                    'conclusion': 'The candidate failed to provide any answers, resulting in a complete lack of communication, grammatical correctness, and clarity. The evaluation is therefore not possible.'
                }
            else:
                # Calculate averages for partial answers
                answered_pairs = [qa for qa in qa_pairs if qa['user_answer'].strip().lower() not in ['no answer', '', 'n/a']]
                if answered_pairs:
                    avg_score = sum(context_match_scores) / len(context_match_scores)
                    
                    # Analyze actual user answers for dynamic evaluation
                    answer_texts = [qa['user_answer'].strip() for qa in answered_pairs]
                    
                    # Communication Skills Analysis
                    total_words = sum(len(answer.split()) for answer in answer_texts)
                    avg_words_per_answer = total_words / len(answer_texts) if answer_texts else 0
                    
                    # Check for structured responses (contains lists, examples, explanations)
                    structured_responses = sum(1 for answer in answer_texts if 
                                            any(indicator in answer.lower() for indicator in 
                                                ['first', 'second', 'example', 'for instance', 'because', 'therefore', 'however', 'additionally']))
                    structured_ratio = structured_responses / len(answer_texts) if answer_texts else 0
                    
                    # Check for technical vocabulary usage
                    technical_indicators = sum(1 for answer in answer_texts if 
                                            len([word for word in answer.split() if len(word) > 6]) > 2)  # Technical terms are usually longer
                    tech_vocab_ratio = technical_indicators / len(answer_texts) if answer_texts else 0
                    
                    # Communication score based on actual content analysis
                    base_comm_score = avg_score * 40  # Base from correctness
                    word_score = min(30, avg_words_per_answer / 10)  # Up to 30 points for adequate length
                    structure_score = structured_ratio * 20  # Up to 20 points for structured responses
                    vocab_score = tech_vocab_ratio * 10  # Up to 10 points for technical vocabulary
                    comm_score = base_comm_score + word_score + structure_score + vocab_score
                    
                    # Generate dynamic communication assessment
                    if avg_words_per_answer < 10:
                        comm_detail = "very brief responses that lack detail and explanation"
                    elif avg_words_per_answer < 30:
                        comm_detail = "concise responses that could benefit from more elaboration"
                    elif avg_words_per_answer < 60:
                        comm_detail = "well-balanced responses with appropriate detail"
                    else:
                        comm_detail = "comprehensive responses demonstrating thorough explanation"
                        
                    if structured_ratio > 0.5:
                        structure_detail = "well-organized thoughts with clear logical flow"
                    elif structured_ratio > 0.2:
                        structure_detail = "some organizational structure in responses"
                    else:
                        structure_detail = "responses that would benefit from better organization"
                    
                    # Grammatical Analysis
                    grammar_issues = 0
                    for answer in answer_texts:
                        # Simple grammar checks
                        sentences = answer.split('.')
                        for sentence in sentences:
                            sentence = sentence.strip()
                            if sentence:
                                # Check for basic grammar patterns
                                if not sentence[0].isupper():  # Sentence doesn't start with capital
                                    grammar_issues += 0.5
                                if sentence.count('(') != sentence.count(')'):  # Unmatched parentheses
                                    grammar_issues += 0.5
                                if '  ' in sentence:  # Double spaces
                                    grammar_issues += 0.25
                    
                    total_sentences = sum(len([s for s in answer.split('.') if s.strip()]) for answer in answer_texts)
                    grammar_error_ratio = grammar_issues / max(total_sentences, 1)
                    
                    # Grammar score calculation
                    base_grammar = 80  # Start with good base
                    grammar_penalty = min(50, grammar_error_ratio * 100)  # Deduct based on errors
                    grammar_score = max(20, base_grammar - grammar_penalty + (avg_score * 20))
                    
                    # Dynamic grammar assessment
                    if grammar_error_ratio < 0.1:
                        grammar_detail = "excellent grammatical structure with minimal errors"
                    elif grammar_error_ratio < 0.3:
                        grammar_detail = "good grammatical structure with minor errors that don't impede understanding"
                    elif grammar_error_ratio < 0.5:
                        grammar_detail = "adequate grammar with some errors that occasionally affect clarity"
                    else:
                        grammar_detail = "grammar issues that significantly impact readability and professional presentation"
                    
                    # Clarity Analysis
                    unclear_indicators = sum(1 for answer in answer_texts if 
                                        any(unclear in answer.lower() for unclear in 
                                            ['um', 'uh', 'maybe', 'i think', 'not sure', 'kind of', 'sort of']))
                    unclear_ratio = unclear_indicators / len(answer_texts) if answer_texts else 0
                    
                    # Check for specific examples and concrete explanations
                    concrete_responses = sum(1 for answer in answer_texts if 
                                        any(concrete in answer.lower() for concrete in 
                                            ['example', 'instance', 'specifically', 'such as', 'like']))
                    concrete_ratio = concrete_responses / len(answer_texts) if answer_texts else 0
                    
                    # Clarity score calculation
                    base_clarity = 70
                    uncertainty_penalty = unclear_ratio * 30  # Deduct for uncertain language
                    concrete_bonus = concrete_ratio * 20  # Bonus for concrete examples
                    clarity_score = max(15, base_clarity - uncertainty_penalty + concrete_bonus + (avg_score * 15))
                    
                    # Dynamic clarity assessment
                    if concrete_ratio > 0.5 and unclear_ratio < 0.2:
                        clarity_detail = "clear and specific explanations with concrete examples"
                    elif concrete_ratio > 0.3 or unclear_ratio < 0.3:
                        clarity_detail = "generally clear explanations with some specific details"
                    elif unclear_ratio < 0.5:
                        clarity_detail = "understandable responses that could benefit from more specific examples"
                    else:
                        clarity_detail = "responses that lack clarity and would benefit from more concrete explanations"
                    
                    # Dynamic conclusion based on actual performance patterns
                    strong_areas = []
                    weak_areas = []
                    
                    if comm_score >= 70:
                        strong_areas.append("communication")
                    else:
                        weak_areas.append("response elaboration")
                        
                    if grammar_score >= 70:
                        strong_areas.append("grammar")
                    else:
                        weak_areas.append("grammatical accuracy")
                        
                    if clarity_score >= 70:
                        strong_areas.append("clarity")
                    else:
                        weak_areas.append("explanation clarity")
                    
                    if avg_score >= 0.7:
                        strong_areas.append("technical knowledge")
                    else:
                        weak_areas.append("technical understanding")
                    
                    # Generate dynamic conclusion
                    if strong_areas and not weak_areas:
                        conclusion = f"The candidate demonstrates strong performance across all evaluated areas ({', '.join(strong_areas)}), indicating readiness for the role."
                    elif len(strong_areas) > len(weak_areas):
                        conclusion = f"The candidate shows good competency in {', '.join(strong_areas)} but should focus on improving {', '.join(weak_areas)} for optimal performance."
                    elif strong_areas:
                        conclusion = f"The candidate has foundational skills in {', '.join(strong_areas)} but requires significant improvement in {', '.join(weak_areas)} before being job-ready."
                    else:
                        conclusion = f"The candidate needs substantial development in all key areas ({', '.join(weak_areas)}) and would benefit from additional training and practice."
                    
                    # Add specific recommendations based on patterns
                    if avg_words_per_answer < 20:
                        conclusion += " Recommend practicing more detailed explanations of technical concepts."
                    if grammar_error_ratio > 0.3:
                        conclusion += " Professional communication training would be beneficial."
                    if unclear_ratio > 0.4:
                        conclusion += " Focus on providing specific examples and avoiding uncertain language."
                    
                    overall_metrics = {
                        'communication_skills': f'The candidate provided {comm_detail} and demonstrated {structure_detail}.',
                        'communication_skills_percentage': min(100, max(0, comm_score)),
                        'grammatical_correctness': f'The responses show {grammar_detail}.',
                        'grammatical_correctness_percentage': min(100, max(0, grammar_score)),
                        'clarity': f'The candidate provided {clarity_detail}.',
                        'clarity_percentage': min(100, max(0, clarity_score)),
                        'conclusion': conclusion
                    }
                else:
                    # Fallback for edge cases
                    overall_metrics = {
                        'communication_skills': 'Unable to assess communication skills due to insufficient response content.',
                        'communication_skills_percentage': 0.0,
                        'grammatical_correctness': 'Cannot evaluate grammar without substantial text responses.',
                        'grammatical_correctness_percentage': 0.0,
                        'clarity': 'Clarity assessment not possible due to lack of detailed responses.',
                        'clarity_percentage': 0.0,
                        'conclusion': 'Insufficient response data to provide meaningful evaluation. Candidate should provide more detailed answers for proper assessment.'
                    }

        # Process AI comments and update question_scores
        for i, qa_pair in enumerate(qa_pairs):
            try:
                context_match_score = context_match_scores[i]
                
                # Find matching AI comment
                ai_comment = None
                if ai_comments:
                    # Try to find exact match first
                    for comment in ai_comments:
                        if comment.get('question', '').strip().lower() == qa_pair['question'].strip().lower():
                            ai_comment = comment['ai_comment']
                            break
                    
                    # If no exact match and we have enough comments, use by index
                    if ai_comment is None and i < len(ai_comments):
                        ai_comment = ai_comments[i].get('ai_comment', '')
                
                # Fallback comment if no AI comment found
                if not ai_comment:
                    ai_comment = f"The candidate's response shows {context_match_score*100:.1f}% relevance to the expected answer. Consider providing more detailed explanations and specific examples to improve the response quality."
                
                final_results['question_scores'].append({
                    'question': qa_pair['question'],
                    'correct_answer': qa_pair['reference_answer'],
                    'user_answer': qa_pair['user_answer'],
                    'weighted_score': context_match_score,
                    'ai_comment': ai_comment
                })
                print(f"Added question_score for question {i+1} with ai_comment: {ai_comment[:100]}...")
                
            except Exception as e:
                print(f"Error processing question_scores for QA pair {i+1}: {str(e)}")
                raise HTTPException(status_code=500, detail=f"Error processing question_scores for QA pair {i+1}: {str(e)}")

        # Normalize overall score
        final_results['overall_score'] = total_score / total_weight if total_weight > 0 else 0.0
        print(f"Calculated overall_score: {final_results['overall_score']}")

        # Update interview_answers and evaluation_result in the database
        try:
            print(f"Attempting to find interview with unique_id: {user_id}")
            interview = self.session.query(InterviewDetailsMain).filter(
                InterviewDetailsMain.unique_id == user_id
            ).first()
            print(f"Interview found for unique_id {user_id}: {interview is not None}")
            if interview:
                existing_answers = interview.interview_answers
                if isinstance(existing_answers, str):
                    try:
                        existing_answers = json.loads(existing_answers)
                    except json.JSONDecodeError as e:
                        print(f"Error parsing existing interview_answers: {str(e)}")
                        existing_answers = []
                existing_answers = existing_answers if isinstance(existing_answers, list) else []
                print(f"Existing interview_answers: {existing_answers}")
                
                updated_answers = []
                for i, qa_pair in enumerate(qa_pairs):
                    updated_answer = {
                        'question': qa_pair['question'],
                        'user_answer': qa_pair['user_answer'],
                        'reference_answer': qa_pair['reference_answer'],
                        'weighted_score': context_match_scores[i],
                        'ai_comment': final_results['question_scores'][i]['ai_comment']
                    }
                    updated_answers.append(updated_answer)
                    print(f"Updated answer for question {i+1}: {updated_answer}")
                    
                interview.interview_answers = json.dumps(updated_answers)
                print(f"Setting interview_answers to: {interview.interview_answers}")

                existing_evaluation = interview.evaluation_result
                if isinstance(existing_evaluation, str):
                    try:
                        existing_evaluation = json.loads(existing_evaluation)
                    except json.JSONDecodeError as e:
                        print(f"Error parsing existing evaluation_result: {str(e)}")
                        existing_evaluation = {}
                existing_evaluation = existing_evaluation if isinstance(existing_evaluation, dict) else {}
                
                updated_evaluation = {
                    **existing_evaluation,
                    'communication_skills': overall_metrics.get('communication_skills', ''),
                    'communication_skills_percentage': overall_metrics.get('communication_skills_percentage', 0.0),
                    'grammatical_correctness': overall_metrics.get('grammatical_correctness', ''),
                    'grammatical_correctness_percentage': overall_metrics.get('grammatical_correctness_percentage', 0.0),
                    'clarity': overall_metrics.get('clarity', ''),
                    'clarity_percentage': overall_metrics.get('clarity_percentage', 0.0),
                    'conclusion': overall_metrics.get('conclusion', '')
                }
                interview.evaluation_result = updated_evaluation
                print(f"Setting evaluation_result to: {interview.evaluation_result}")
                self.session.commit()
                print("Database commit successful")
            else:
                print(f"No interview found for unique_id {user_id}, skipping database update")
        except Exception as e:
            print(f"Error updating interview_answers or evaluation_result in database: {str(e)}")
            self.session.rollback()
            print("Database rollback performed")

        if use_llm:
            try:
                self.session.commit()
            except Exception as e:
                print(f"Error updating LLM quota in database: {str(e)}")
                self.session.rollback()

        final_results.update({
            'communication_skills': overall_metrics.get('communication_skills', ''),
            'communication_skills_percentage': overall_metrics.get('communication_skills_percentage', 0.0),
            'grammatical_correctness': overall_metrics.get('grammatical_correctness', ''),
            'grammatical_correctness_percentage': overall_metrics.get('grammatical_correctness_percentage', 0.0),
            'clarity': overall_metrics.get('clarity', ''),
            'clarity_percentage': overall_metrics.get('clarity_percentage', 0.0),
            'conclusion': overall_metrics.get('conclusion', '')
        })
        print("Returning final_results:", final_results)
        return final_results

    def evaluate_interview(self, user_id: str):
        try:
            interview = self.session.query(InterviewDetailsMain.interview_questions, InterviewDetailsMain.interview_answers, InterviewDetailsMain.evaluation_result, JDDetails.llm_id, JDDetails.tech_stack_id).join(
                JDDetails, JDDetails.job_id == InterviewDetailsMain.job_id
            ).filter(
                InterviewDetailsMain.unique_id == user_id,
                InterviewDetailsMain.status == 'completed'
            ).order_by(InterviewDetailsMain.scheduled_at.desc()).first()
            if not interview:
                print(f"No completed interview found for unique_id: {user_id}")
                raise HTTPException(status_code=404, detail="No completed interview found for this user")

            qa_pairs = interview.interview_answers
            print("Raw interview_answers from database:", qa_pairs)
            if isinstance(qa_pairs, str):
                try:
                    qa_pairs = json.loads(qa_pairs)
                    print("Parsed qa_pairs:", qa_pairs)
                except json.JSONDecodeError as e:
                    print(f"Error parsing interview_answers JSON: {str(e)}")
                    raise HTTPException(status_code=500, detail=f"Failed to parse interview_answers JSON: {str(e)}")
            elif not isinstance(qa_pairs, list):
                print(f"Error: interview_answers is not a list or JSON string: {qa_pairs}")
                raise HTTPException(status_code=500, detail="Invalid interview_answers format: must be a JSON string or list")

            llm_id = interview.llm_id
            tech_stack_id = interview.tech_stack_id

            if not isinstance(qa_pairs, list):
                print(f"Error: qa_pairs is not a list after parsing: {qa_pairs}")
                raise HTTPException(status_code=500, detail="Invalid qa_pairs format: must be a list")
            for qa in qa_pairs:
                if not all(key in qa for key in ['question', 'user_answer', 'reference_answer']):
                    print(f"Error: Invalid qa_pair missing required keys: {qa}")
                    raise HTTPException(status_code=500, detail="Invalid qa_pair: missing required keys (question, user_answer, reference_answer)")

            # Check if evaluation_result contains all required metrics
            existing_evaluation = interview.evaluation_result
            if isinstance(existing_evaluation, str):
                try:
                    existing_evaluation = json.loads(existing_evaluation)
                except json.JSONDecodeError as e:
                    print(f"Error parsing existing evaluation_result: {str(e)}")
                    existing_evaluation = {}
            existing_evaluation = existing_evaluation if isinstance(existing_evaluation, dict) else {}

            # Check if all QA pairs have weighted_score and ai_comment, and evaluation_result has all required metrics
            required_metrics = ['communication_skills', 'communication_skills_percentage', 'grammatical_correctness', 'grammatical_correctness_percentage', 'clarity', 'clarity_percentage', 'conclusion']
            if (qa_pairs and all(
                isinstance(qa, dict) and
                'weighted_score' in qa and
                'ai_comment' in qa
                for qa in qa_pairs
            ) and all(
                metric in existing_evaluation for metric in required_metrics
            )):
                total_score = sum(qa['weighted_score'] for qa in qa_pairs)
                total_weight = len(qa_pairs)
                final_results = {
                    'overall_score': total_score / total_weight if total_weight > 0 else 0.0,
                    'question_scores': [
                        {
                            'question': qa['question'],
                            'correct_answer': qa['reference_answer'],
                            'user_answer': qa['user_answer'],
                            'weighted_score': qa['weighted_score'],
                            'ai_comment': qa['ai_comment']
                        }
                        for qa in qa_pairs
                    ],
                    'communication_skills': existing_evaluation.get('communication_skills', ''),
                    'communication_skills_percentage': existing_evaluation.get('communication_skills_percentage', 0.0),
                    'grammatical_correctness': existing_evaluation.get('grammatical_correctness', ''),
                    'grammatical_correctness_percentage': existing_evaluation.get('grammatical_correctness_percentage', 0.0),
                    'clarity': existing_evaluation.get('clarity', ''),
                    'clarity_percentage': existing_evaluation.get('clarity_percentage', 0.0),
                    'conclusion': existing_evaluation.get('conclusion', '')
                }
                print("Returning existing results from database:", final_results)
                return final_results

            print("Calling evaluate_answers for new evaluation")
            evaluation_result = self.evaluate_answers(qa_pairs, llm_id, tech_stack_id, user_id)
            return evaluation_result
        except Exception as e:
            print(f"Error in evaluate_interview: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

    def extract_text_from_pdf_bytes(self, pdf_bytes: bytes) -> str:
        """Extract text from PDF bytes"""
        try:
            pdf_reader = PyPDF2.PdfReader(io.BytesIO(pdf_bytes))
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            return text.strip()
        except Exception as e:
            print(f"Error extracting text from PDF bytes: {e}")
            raise HTTPException(status_code=400, detail=f"Error extracting text from PDF: {e}")

    def setup_resume_agents(self, llm_config_list: List[Dict]) -> Dict:
        """Setup AutoGen agents for resume scoring"""
        
        # Assistant Agent for Resume Analysis
        assistant_prompt = """You are an expert HR professional and resume analyzer. Your task is to:

        1. SCORE the resume against the job description on a scale of 0.0 to 1.0 (decimal format) based on:
        - Skills match (30%)
        - Experience relevance (25%)
        - Education alignment (15%)
        - Keywords presence (20%)
        - Overall presentation (10%)

        2. GENERATE 6-8 concise summary points about the resume covering:
        - Key strengths and skills
        - Relevant experience highlights
        - Education and certifications
        - Notable achievements
        - Areas for improvement (if any)
        - Industry/domain fit

        IMPORTANT INSTRUCTIONS:
        - Always start your response with "RESUME SCORE: X.XX" where X.XX is the decimal score between 0.0 and 1.0
        - Follow with "SUMMARY POINTS:" and then list 6-8 bullet points
        - Be objective and professional in your analysis
        - Focus on factual information from the resume
        - Highlight both strengths and areas for improvement
        - Keep each summary point concise (1-2 sentences max)

        SCORING GUIDELINES:
        - 0.9-1.0: Exceptional match, perfect candidate
        - 0.8-0.89: Excellent match, highly qualified
        - 0.7-0.79: Good match, well qualified
        - 0.6-0.69: Moderate match, somewhat qualified
        - 0.5-0.59: Average match, basic qualifications
        - 0.4-0.49: Below average match, missing key requirements
        - 0.3-0.39: Poor match, significant gaps
        - 0.2-0.29: Very poor match, few relevant qualifications
        - 0.1-0.19: Minimal match, hardly any relevant experience
        - 0.0-0.09: No match, completely irrelevant

        Example format:
        RESUME SCORE: 0.85

        SUMMARY POINTS:
        • Strong technical skills in Python, Java, and cloud technologies
        • 5+ years of software development experience in fintech
        • Bachelor's degree in Computer Science from reputable university
        • Led team of 8 developers on major project implementations
        • Excellent problem-solving and analytical abilities
        • Experience with Agile methodologies and DevOps practices
        • Strong communication skills demonstrated through technical presentations
        • Could benefit from additional certifications in cloud platforms
        """
        
        domain_assistant = AssistantAgent(
            name="resume_analyzer",
            system_message=assistant_prompt,
            llm_config={"config_list": llm_config_list, "temperature": 0.1}
        )
        
        # User Proxy Agent
        user_proxy = UserProxyAgent(
            name="user_proxy",
            human_input_mode="NEVER",
            code_execution_config=False,
            max_consecutive_auto_reply=0,
        )
        
        return {
            'domain_assistant': domain_assistant,
            'user_proxy': user_proxy
        }

    def create_resume_message(self, job_description: str, resume_text: str) -> str:
        """Create message for resume analysis"""
        return f"""
        Please analyze the following resume against the job description and provide a score and summary points.

        JOB DESCRIPTION:
        {job_description}

        RESUME:
        {resume_text}

        Analyze how well this resume matches the job requirements and provide:
        1. A decimal score between 0.0 and 1.0 (where 1.0 is perfect match)
        2. 6-8 summary points covering the candidate's profile
        NO asterisks (*)
        NO bold text ()**
        NO colons in bullet points
        NO titles or headers within points
        Use plain text only in array

        Focus on skills alignment, experience relevance, and overall fit for the role.
        """

    def parse_resume_response(self, response_text: str) -> Dict:
        """Parse the assistant's response to extract score and summary points"""
        result = {
            'score': 0.0,
            'summary_points': [],
            'raw_response': response_text
        }
        
        lines = response_text.split('\n')
        
        # Extract score (looking for decimal format)
        for line in lines:
            if line.strip().startswith('RESUME SCORE:'):
                try:
                    score_part = line.split(':')[1].strip()
                    # Handle both "0.85" and "0.85/1.0" formats
                    if '/' in score_part:
                        score_part = score_part.split('/')[0]
                    result['score'] = float(score_part)
                except Exception as e:
                    print(f"Error parsing score: {e}")
                    pass
        
        # Extract summary points
        in_summary_section = False
        
        for line in lines:
            line = line.strip()
            
            # Check if we're entering the summary section
            if line.startswith('SUMMARY POINTS:'):
                in_summary_section = True
                continue
            # Check if we're leaving the summary section (optional - for multi-section documents)
            if in_summary_section and line.startswith(('CONCLUSION:', 'NEXT STEPS:', 'RECOMMENDATIONS:')):
                in_summary_section = False
                continue
            
            if in_summary_section and line:
                # Handle bullet points
                if line.startswith('•') or line.startswith('-') or line.startswith('*'):
                    result['summary_points'].append(line[1:].strip())
                
                # Handle numbered lists (improved)
                elif re.match(r'^\d+[\.\)]\s*', line):
                    # This handles "1. ", "1) ", "10. ", etc.
                    clean_line = re.sub(r'^\d+[\.\)]\s*', '', line)
                    result['summary_points'].append(clean_line)
                
                # Handle lines without bullet points (like your original format)
                else:
                    result['summary_points'].append(line)
        return result

    def get_score_resume(self, job_id: int, resume: bytes, domain: str) -> ResumeScoreResponse:
        """
        Score resume from text inputs
        Args:
            job_id: Job ID
            resume: Resume PDF bytes
            domain: Domain context
        Returns:
            ResumeScoreResponse with score and summary points
        """
        try:
            job = self.session.query(JDDetails).filter(JDDetails.job_id == job_id).first()
            if not job or not job.jd_file_path:
                print(f"Job or JD file path not found for job_id: {job_id}")
                return {"success": False, "message": "Job description path not found", "score": 0}

            # Extract blob path from the database
            jd_file_path = job.jd_file_path
            bucket_name = os.getenv("BUCKET_NAME")
            # Handle both full S3 URL and direct key formats
            if jd_file_path.startswith(f"s3://{bucket_name}/"):
                blob_path = jd_file_path[len(f"s3://{bucket_name}/"):]  # Remove s3://bucket_name/
            else:
                blob_path = jd_file_path  # Assume it's already the correct key
            print("jd_file_path from database:", jd_file_path)
            print("Extracted blob path:", blob_path)

            # Validate blob_path
            if not blob_path or blob_path.startswith('/'):
                print(f"Invalid blob path: {blob_path}")
                return {"success": False, "message": "Invalid JD file path format", "score": 0}

            # Extract text from resume PDF
            resume_text = self.extract_text_from_pdf_bytes(resume)
            print("Resume text length:", len(resume_text))

            # Initialize AWS S3 client
            s3_client = boto3.client(
                's3',
                aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
                aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
                region_name=os.getenv("AWS_REGION")
            )
            bucket_name = os.getenv("BUCKET_NAME")
            print("AWS_REGION:", os.getenv("AWS_REGION"))
            print("BUCKET_NAME:", bucket_name)
            print("AWS_ACCESS_KEY_ID:", os.getenv("AWS_ACCESS_KEY_ID")[:4] + "****")

            try:
                # Download JD file directly from S3
                response = s3_client.get_object(Bucket=bucket_name, Key=blob_path)
                blob_data = response['Body'].read()
                print("JD file downloaded, size:", len(blob_data))
                
                # Extract text from JD PDF
                jd_text = self.extract_text_from_pdf_bytes(blob_data)
                print("JD text length:", len(jd_text))
            except ClientError as e:
                print(f"ClientError retrieving JD from S3: {str(e)}")
                # Fallback to jd_summary_text if available
                jd_text = job.jd_summary_text or ""
                if not jd_text:
                    return {"success": False, "message": f"Error retrieving JD from S3 and no summary text available: {str(e)}", "score": 0}
                print("Falling back to jd_summary_text:", jd_text[:100] + "..." if len(jd_text) > 100 else jd_text)

            # Get LLM configuration
            llm_config_list = self.get_llm_config_by_id(job.llm_id)
            print("LLM config:", llm_config_list)

            # Setup agents
            agents = self.setup_resume_agents(llm_config_list)
            
            # Create message
            message = self.create_resume_message(jd_text, resume_text)
            
            # Execute chat
            chat_result = agents['user_proxy'].initiate_chat(
                agents['domain_assistant'],
                message=f"""
                For the given domain == {domain},
                {message}"""
            )
            
            # Extract response
            response = chat_result.chat_history[-1]['content']
            print("LLM response:", response[:100] + "..." if len(response) > 100 else response)
            
            # Parse response
            parsed_result = self.parse_resume_response(response)
            print("Parsed result:", parsed_result)
            
            return jsonable_encoder(ResumeScoreResponse(
                score=parsed_result['score'],
                summary_points=parsed_result['summary_points'],
                raw_response=parsed_result['raw_response']
            ))
            
        except Exception as e:
            print(f"Error scoring resume: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error scoring resume: {str(e)}")