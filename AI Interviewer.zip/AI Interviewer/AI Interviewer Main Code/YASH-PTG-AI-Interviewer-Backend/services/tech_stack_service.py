from database import Database
from models import TechStack, AgentPrompts
import pytz
from datetime import datetime

class TechStackService:
    def __init__(self, db: Database):
        self.db = db
        self.session = db.get_session()

    def create_tech_stack(self, tech_stack: str, created_by: str = None):
        # Check if tech stack already exists
        existing_tech_stack = self.session.query(TechStack).filter(TechStack.tech_stack == tech_stack).first()
        if existing_tech_stack:
            raise ValueError(f"Tech stack '{tech_stack}' already exists")
        
        # Get current local time (already in IST)
        current_time = datetime.now()
        print(f"Tech Stack Creation - Current time: {current_time}")
        
        tech_stack_obj = TechStack(
            tech_stack=tech_stack, 
            created_by=created_by,
            created_at=current_time,
            updated_at=current_time
        )
        self.session.add(tech_stack_obj)
        self.session.commit()
        
        # Replicate agent prompts from tech_stack_id=1
        template_prompts = self.session.query(AgentPrompts).filter(AgentPrompts.tech_stack_id == 1).all()
        for template in template_prompts:
            new_prompt = AgentPrompts(
                tech_stack_id=tech_stack_obj.id,
                agent_name=template.agent_name,
                prompt=template.prompt,
                placeholders=template.placeholders,
                type=template.type
            )
            self.session.add(new_prompt)
        self.session.commit()
        
        return tech_stack_obj.id

    def get_all_tech_stacks(self):
        return self.session.query(TechStack).all()

    def get_tech_stack_by_id(self, tech_stack_id: int):
        return self.session.query(TechStack).filter(TechStack.id == tech_stack_id).first()

    def update_tech_stack(self, tech_stack_id: int, tech_stack: str):
        tech_stack_obj = self.session.query(TechStack).filter(TechStack.id == tech_stack_id).first()
        if not tech_stack_obj:
            return False
        tech_stack_obj.tech_stack = tech_stack
        tech_stack_obj.updated_at = datetime.now()
        self.session.commit()
        return True

    def delete_tech_stack(self, tech_stack_id: int):
        tech_stack_obj = self.session.query(TechStack).filter(TechStack.id == tech_stack_id).first()
        if not tech_stack_obj:
            return False
        
        # First delete all associated agent prompts
        self.session.query(AgentPrompts).filter(AgentPrompts.tech_stack_id == tech_stack_id).delete()
        
        # Then delete the tech stack
        self.session.delete(tech_stack_obj)
        self.session.commit()
        return True