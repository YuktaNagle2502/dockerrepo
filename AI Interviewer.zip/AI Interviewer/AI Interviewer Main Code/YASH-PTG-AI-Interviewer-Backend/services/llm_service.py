from database import Database
from models import LLMs
import pytz
from datetime import datetime

class LLMService:
    def __init__(self, db: Database):
        self.db = db
        self.session = db.get_session()

    def create_llm(self, provider: str, prefix: str, model: str, key: str, created_by: str = None):
        # Get current local time (already in IST)
        current_time = datetime.now()
        print(f"LLM Creation - Current time: {current_time}")
        
        llm = LLMs(
            provider=provider, 
            prefix=prefix, 
            model=model, 
            key=key, 
            created_by=created_by,
            created_at=current_time,
            updated_at=current_time
        )
        self.session.add(llm)
        self.session.commit()
        return llm.id

    def get_all_llms(self):
        return self.session.query(LLMs).all()

    def get_llm_by_id(self, llm_id: int):
        return self.session.query(LLMs).filter(LLMs.id == llm_id).first()

    def update_llm(self, llm_id: int, provider: str = None, prefix: str = None, model: str = None, key: str = None):
        llm = self.session.query(LLMs).filter(LLMs.id == llm_id).first()
        if not llm:
            return False
        if provider: llm.provider = provider
        if prefix: llm.prefix = prefix
        if model: llm.model = model
        if key: llm.key = key
        llm.updated_at = datetime.now()
        self.session.commit()
        return True

    def delete_llm(self, llm_id: int):
        llm = self.session.query(LLMs).filter(LLMs.id == llm_id).first()
        if not llm:
            return False
        self.session.delete(llm)
        self.session.commit()
        return True