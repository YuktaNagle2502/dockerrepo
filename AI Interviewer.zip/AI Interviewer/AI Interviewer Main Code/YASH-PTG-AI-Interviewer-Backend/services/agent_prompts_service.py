from database import Database
from models import AgentPrompts

class AgentPromptsService:
    def __init__(self, db: Database):
        self.db = db
        self.session = db.get_session()

    def create_agent_prompt(self, tech_stack_id: int, agent_name: str, prompt: str = None, placeholders: dict = None, type: str = None):
        agent_prompt = AgentPrompts(
            tech_stack_id=tech_stack_id,
            agent_name=agent_name,
            prompt=prompt,
            placeholders=placeholders or {},
            type=type
        )
        self.session.add(agent_prompt)
        self.session.commit()
        return agent_prompt.id

    def get_all_agent_prompts(self):
        return self.session.query(AgentPrompts).all()

    def get_agent_prompt_by_id(self, prompt_id: int):
        return self.session.query(AgentPrompts).filter(AgentPrompts.id == prompt_id).first()

    def get_agent_prompts_by_tech_stack(self, tech_stack_id: int):
        return self.session.query(AgentPrompts).filter(AgentPrompts.tech_stack_id == tech_stack_id).all()

    def update_agent_prompt(self, prompt_id: int, tech_stack_id: int = None, agent_name: str = None, prompt: str = None, placeholders: dict = None, type: str = None):
        agent_prompt = self.session.query(AgentPrompts).filter(AgentPrompts.id == prompt_id).first()
        if not agent_prompt:
            return False
        if tech_stack_id: agent_prompt.tech_stack_id = tech_stack_id
        if agent_name: agent_prompt.agent_name = agent_name
        if prompt is not None: agent_prompt.prompt = prompt
        if placeholders is not None: agent_prompt.placeholders = placeholders
        if type is not None: agent_prompt.type = type
        self.session.commit()
        return True

    def delete_agent_prompt(self, prompt_id: int):
        agent_prompt = self.session.query(AgentPrompts).filter(AgentPrompts.id == prompt_id).first()
        if not agent_prompt:
            return False
        self.session.delete(agent_prompt)
        self.session.commit()
        return True

    def bulk_update_agent_prompts(self, updates: list):
        clean_updates = []
        for update in updates:
            clean_update = {k: v for k, v in update.items() if k != 'created_at'}
            clean_updates.append(clean_update)
        
        self.session.bulk_update_mappings(AgentPrompts, clean_updates)
        self.session.commit()
        return len(clean_updates)