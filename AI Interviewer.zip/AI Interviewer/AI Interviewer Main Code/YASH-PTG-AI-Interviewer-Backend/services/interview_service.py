# interview_service.py
from sqlalchemy import func, text
from sqlalchemy.orm import Session
from database import Database
from models import InterviewDetailsMain, JDDetails, UsersStats, LLMs
from decimal import Decimal
import json
from services.question_service import QuestionService
import os
from collections import defaultdict
import io
from sqlalchemy.orm.attributes import flag_modified
import csv
import uuid
from fastapi import BackgroundTasks
import requests
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from aiosmtplib import SMTP
from datetime import datetime, timedelta
import pytz
import PyPDF2
from email.mime.base import MIMEBase
from email import encoders
from io import BytesIO
import mimetypes
from utility.s3_utils import upload_file_to_s3, get_signed_s3_url, delete_s3_object, is_presigned_url_valid
import boto3
from botocore.exceptions import ClientError
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# AWS S3 Configuration
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION = os.getenv("AWS_REGION")
BUCKET_NAME = os.getenv("BUCKET_NAME")

# Initialize S3 client
s3_client = boto3.client(
    's3',
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY
)

class InterviewService:
    def __init__(self, db: Database):
        self.db = db
        self.session = db.get_session()

    def register_user(self, full_name: str, age: int, sex: str, phone: str):
        try:
            user = InterviewDetailsMain(
                unique_id=str(uuid.uuid4()),
                full_name=full_name,
                age=age,
                sex=sex,
                phone=phone,
                status='pending'
            )
            self.session.add(user)
            self.session.commit()
            return user.unique_id
        except Exception as e:
            self.session.rollback()
            print(f"Error registering user: {e}")
            return None

    def get_users(self):
        try:
            users = self.session.query(InterviewDetailsMain.unique_id, InterviewDetailsMain.full_name, InterviewDetailsMain.phone).order_by(InterviewDetailsMain.created_at.desc()).all()
            return users
        except Exception as e:
            print(f"Error fetching users: {e}")
            return []

    async def evaluate_resume_for_job(self, resume_content: bytes, job_id: int):
        """
        Evaluate a resume against a job description stored in S3.

        Args:
            resume_content: Resume PDF content (bytes)
            job_id: Job ID to compare resume against

        Returns:
            dict: Evaluation results with score
        """
        try:
            # Get job description details from the database
            job = self.session.query(JDDetails).filter(JDDetails.job_id == job_id).first()
            print("Job details:", job)
            if not job or not job.jd_file_path:
                return {"success": False, "message": "Job description path not found", "score": 0}

            # Extract S3 key from the database-stored path
            jd_file_path = job.jd_file_path
            s3_key = jd_file_path.replace(f"s3://{BUCKET_NAME}/", "") if jd_file_path.startswith(f"s3://{BUCKET_NAME}/") else jd_file_path
            print("Extracted S3 key:", s3_key)

            # Extract text from resume PDF
            resume_text = ""
            try:
                pdf_reader = PyPDF2.PdfReader(BytesIO(resume_content))
                print(f"pdf reader: {pdf_reader}")
                for page in pdf_reader.pages:
                    resume_text += page.extract_text() or ""
            except Exception as e:
                return {"success": False, "message": f"Error extracting text from resume: {str(e)}", "score": 0}

            # Download JD file from S3
            jd_text = ""
            try:
                response = s3_client.get_object(Bucket=BUCKET_NAME, Key=s3_key)
                jd_file_content = response['Body'].read()
                print("JD file downloaded, size:", len(jd_file_content))
                # Extract text from JD PDF
                pdf_reader = PyPDF2.PdfReader(BytesIO(jd_file_content))
                print("pdf reader for JD file:", pdf_reader)
                for page in pdf_reader.pages:
                    jd_text += page.extract_text() or ""
                    print("jd text", jd_text)
            except ClientError as e:
                error_code = e.response['Error']['Code']
                if error_code in ['NoSuchKey', 'AccessDenied']:
                    return {"success": False, "message": f"JD file not accessible: {str(e)}", "score": 0}
                raise

            # TF-IDF cosine similarity for better matching
            if not jd_text or not resume_text:
                score = 0.0
            else:
                vectorizer = TfidfVectorizer()
                vectors = vectorizer.fit_transform([jd_text, resume_text])
                score = cosine_similarity(vectors[0:1], vectors[1:2])[0][0]
                score = round(score, 2)

            # Extract keywords for additional info (optional, keeping for compatibility)
            jd_keywords = set(word.lower() for word in jd_text.split() if len(word) > 3 and word.isalnum())
            print("JD keywords:", jd_keywords)
            resume_words = set(word.lower() for word in resume_text.split() if len(word) > 3 and word.isalnum())
            print("Resume words:", resume_words)
            matching_keywords = jd_keywords.intersection(resume_words)
            print("Matching keywords:", matching_keywords)

            print("Match score:", score)
            return {
                "success": True,
                "score": score,
                "job_title": job.job_title,
                "matching_keywords": list(matching_keywords)[:10]
            }
        except Exception as e:
            return {"success": False, "message": f"Unexpected error: {str(e)}", "score": 0}

    async def schedule_interview(self, full_name: str, age: int, sex: str, email_id: str, job_id: int, phone: str, unique_id: str, user_image_path: str, resume: bytes, resume_path: str, domain: str, background_tasks: BackgroundTasks, scheduled_start_time: datetime = None):
        try:
            # Check if candidate has already applied for this job
            existing_application = self.session.query(InterviewDetailsMain).filter(
                InterviewDetailsMain.email_id == email_id,
                InterviewDetailsMain.job_id == job_id
            ).first()
            print("existing_application:", existing_application)
            if existing_application:
                return {
                    "statusCode": 409,
                    "success": False,
                    "message": f"You have already applied for this job position. Application ID: {existing_application.unique_id}",
                    "qualified": False,
                    "score": round(float(existing_application.resume_score), 2) if existing_application.resume_score else 0.00
                }

            # Use provided scheduled times or default to current time + 2 hours
            ist = pytz.timezone("Asia/Kolkata")
            current_time = datetime.now(ist)
            current_time_naive = current_time.replace(tzinfo=None)
            
            if not scheduled_start_time:
                scheduled_start_time = current_time_naive + timedelta(hours=2)
                
            slot_end_time = scheduled_start_time + timedelta(minutes=30)
            interview_end_time = scheduled_start_time + timedelta(hours=1)
            time_slot_str = f"{scheduled_start_time.strftime('%I:%M %p').lstrip('0')} to {slot_end_time.strftime('%I:%M %p').lstrip('0')}"
            
            # Fetch JD questions and basic questions
            jd_record = self.session.query(JDDetails).filter(JDDetails.job_id == job_id).first()
            if not jd_record:
                raise ValueError(f"No job found for job_id: {job_id}")

            question_service = QuestionService(self.db)
            jd_questions = []
            if jd_record.jd_file_path:
                try:
                    s3_key = jd_record.jd_file_path.replace(f"s3://{BUCKET_NAME}/", "") if jd_record.jd_file_path.startswith(f"s3://{BUCKET_NAME}/") else jd_record.jd_file_path
                    response = s3_client.get_object(Bucket=BUCKET_NAME, Key=s3_key)
                    jd_file_content = response['Body'].read()
                    jd_questions = question_service.generate_jd_question(jd_file_content, jd_record.llm_id, jd_record.tech_stack_id)
                except ClientError as e:
                    error_code = e.response['Error']['Code']
                    if error_code in ['NoSuchKey', 'AccessDenied']:
                        print(f"JD file not accessible: {s3_key}")
                        jd_questions = []
                    else:
                        raise

            jd_qualification_score = float(jd_record.jd_qualification_score) if jd_record.jd_qualification_score is not None else 0.60
            custom_questions = jd_record.jd_custom_questions_text if jd_record.jd_custom_questions_text else []
            initial_questions = jd_questions + custom_questions
            
            interview = InterviewDetailsMain(
                unique_id=unique_id,
                full_name=full_name,
                age=age,
                sex=sex,
                phone=phone,
                email_id=email_id,
                job_id=job_id,
                user_image_path=user_image_path,
                resume_path=resume_path,
                domain=domain,
                evaluation_result={},
                status='pending',
                resume_score=0,
                scheduled_at=scheduled_start_time,
                interview_end_time=interview_end_time,
                interview_questions=initial_questions
            )
            self.session.add(interview)
            self.session.commit()
            
            background_tasks.add_task(
                self._process_interview_background,
                unique_id, job_id, resume, resume_path, domain, jd_record, 
                full_name, email_id, scheduled_start_time, interview_end_time, 
                time_slot_str, round(jd_qualification_score, 2)
            )

            return {
                "success": True,
                "message": "Application submitted successfully. You will receive an email shortly with interview details.",
                "application_id": unique_id,
                "time_slot": time_slot_str,
                "interview_start": scheduled_start_time.strftime("%Y-%m-%d %H:%M:%S"),
                "interview_end": interview_end_time.strftime("%Y-%m-%d %H:%M:%S"),
                "jd_qualification_score": round(jd_qualification_score, 2)
            }
        
        except Exception as e:
            self.session.rollback()
            print(f"Error scheduling interview: {e}")
            return {"success": False, "message": str(e)}

    async def _process_interview_background(self, unique_id: str, job_id: int, resume: bytes, 
                                        resume_path: str, domain: str, jd_record, 
                                        full_name: str, email_id: str, 
                                        scheduled_start_time: datetime, interview_end_time: datetime,
                                        time_slot_str: str, jd_qualification_score: float):
        try:
            question_service = QuestionService(self.db)
            evaluation_result = question_service.get_score_resume(
                job_id=job_id,
                resume=resume,
                domain=domain,
            )
            score = evaluation_result.get("score", 0)
            
            interview = self.session.query(InterviewDetailsMain).filter(
                InterviewDetailsMain.unique_id == unique_id
            ).first()
            
            if not interview:
                print(f"Interview record not found for unique_id: {unique_id}")
                return
            
            interview.evaluation_result = evaluation_result
            interview.resume_score = score
            
            if score >= jd_qualification_score:
                interview.status = 'scheduled'
                self.session.commit()
                await self._send_interview_email(
                    full_name, email_id, job_id, unique_id,
                    scheduled_start_time, interview_end_time, time_slot_str
                )
                self._async_generate_questions(
                    unique_id, job_id, resume_path, domain, jd_record, resume
                )
                print(f"Interview scheduled for {full_name} (ID: {unique_id})")
            else:
                interview.status = 'cancelled'
                self.session.commit()
                print(f"Candidate {full_name} (ID: {unique_id}) not qualified. Score: {score}, Required: {jd_qualification_score}")

        except Exception as e:
            print(f"Error processing interview background task for {unique_id}: {e}")
            try:
                interview = self.session.query(InterviewDetailsMain).filter(
                    InterviewDetailsMain.unique_id == unique_id
                ).first()
                if interview:
                    interview.status = 'cancelled'
                    self.session.commit()
            except Exception as db_error:
                print(f"Error updating interview status to error: {db_error}")
                self.session.rollback()

    async def _generate_questions_background(self, unique_id: str, job_id: int, resume_path: str, domain: str, jd_record, resume: bytes):
        await self._async_generate_questions(unique_id, job_id, resume_path, domain, jd_record, resume)

    def _async_generate_questions(self, unique_id: str, job_id: int, resume_path: str, domain: str, jd_record, resume: bytes):
        try:
            print(f"Starting background question generation for {unique_id}")
            interview = self.session.query(InterviewDetailsMain).filter(
                InterviewDetailsMain.unique_id == unique_id
            ).first()
            
            if not interview:
                print(f"Interview record not found for unique_id: {unique_id}")
                return
            
            all_questions = interview.interview_questions or []
            question_service = QuestionService(self.db)
            resume_content = None
            
            print(f"Attempting to download resume for unique_id {unique_id}, resume_path: {resume_path}")
            try:
                s3_key = resume_path.replace(f"s3://{BUCKET_NAME}/", "") if resume_path.startswith(f"s3://{BUCKET_NAME}/") else resume_path
                response = s3_client.get_object(Bucket=BUCKET_NAME, Key=s3_key)
                resume_content = response['Body'].read()
                print(f"Resume downloaded, size: {len(resume_content)} bytes")
            except ClientError as e:
                error_code = e.response['Error']['Code']
                if error_code in ['NoSuchKey', 'AccessDenied']:
                    print(f"Resume file not accessible: {s3_key}")
                    resume_content = resume
                else:
                    raise

            if resume_content:
                try:
                    temp_resume_path = f"documents/{unique_id}_temp.pdf"
                    os.makedirs(os.path.dirname(temp_resume_path), exist_ok=True)
                    with open(temp_resume_path, 'wb') as pdf_file:
                        pdf_file.write(resume_content)
                    
                    resume_questions = question_service.generate_resume(
                        jd_record.llm_id, jd_record.tech_stack_id, resume=resume
                    )
                    print(f"Generated {len(resume_questions)} resume questions for {unique_id}")
                    all_questions += resume_questions
                    
                    try:
                        os.remove(temp_resume_path)
                    except Exception as cleanup_error:
                        print(f"Error cleaning up temporary file: {cleanup_error}")
                        
                except Exception as e:
                    print(f"Error generating resume questions for {unique_id}: {str(e)}")

            if domain:
                try:
                    domain_question = question_service.generate_dynamic_domain(
                        domain, jd_record.llm_id, jd_record.tech_stack_id
                    )
                    print(f"Generated domain question for {unique_id}: {domain}")
                    all_questions.append(domain_question)
                except Exception as e:
                    print(f"Error generating domain question for {unique_id}: {str(e)}")

            interview.interview_questions = all_questions
            flag_modified(interview, 'interview_questions')
            self.session.commit()
            
            print(f"Updated interview questions for {unique_id}. Total questions: {len(all_questions)}")
            
            # Close the database session
            self.session.close()
            
        except Exception as e:
            print(f"Error in background question generation for {unique_id}: {str(e)}")
            if 'db_session' in locals():
                self.session.rollback()
                self.session.close()

    async def _send_interview_email(self, full_name: str, email_id: str, job_id: int, unique_id: str, 
                                  scheduled_start_time: datetime, interview_end_time: datetime, time_slot_str: str):
        """Send interview invitation email"""
        try:
            job = self.session.query(JDDetails.job_title).filter(JDDetails.job_id == job_id).first()
            position_name = job.job_title if job else f"Position_{job_id}"

            # Calculate slot end time (30 minutes after start)
            slot_end_time = scheduled_start_time + timedelta(minutes=30)

            # For displaying date in human-readable format (email body)
            interview_date = scheduled_start_time.strftime("%Y-%m-%d")
            interview_time = scheduled_start_time.strftime("%I:%M %p IST")
            slot_end_time_str = slot_end_time.strftime("%I:%M %p IST")
            expiry_time_str = interview_end_time.strftime("%I:%M %p IST")

            # For ICS file — Convert to UTC as required by iCal spec
            # First localize the naive datetime to IST, then convert to UTC
            ist = pytz.timezone("Asia/Kolkata")
            start_time_utc = ist.localize(scheduled_start_time).astimezone(pytz.utc).strftime("%Y%m%dT%H%M%SZ")
            end_time_utc = ist.localize(interview_end_time).astimezone(pytz.utc).strftime("%Y%m%dT%H%M%SZ")

            # Email content
            from_email = os.getenv("SENDER_EMAIL")
            smtp_password = os.getenv("SMTP_PASSWORD")

            if not from_email or not smtp_password:
                raise ValueError("SENDER_EMAIL or SMTP_PASSWORD environment variables are not set")

            subject = f"Invitation to Online Interview for {position_name} at Yash Technologies"

            html_body = f"""
            <html>
            <body>
                <p>Dear {full_name},</p>
                <p>Thank you for your application for the <strong>{position_name}</strong> position at Yash Technologies. We are pleased to invite you to an online interview to further discuss your qualifications and potential alignment with our team.</p>
                
                <p><strong>Interview Details:</strong></p>
                <p>
                    <strong>Date:</strong> {interview_date}<br>
                    <strong>Time Slot:</strong> {time_slot_str}<br>
                    <strong>Interview Closes At:</strong> {expiry_time_str}<br>
                </p>

                <p><strong>Meeting Access:</strong></p>
                <p>Please join using this link:<br>
                
                <a href="https://interviewer.yashtech.link/interviewer/{unique_id}">Interview Link</a></p>
                
                <p><i>Note:</i> You can access the interview link anytime during your scheduled time slot. The interview will automatically close at {expiry_time_str}, which is 1 hour after the start time.</p>

                <p>Best regards,<br>
                HR Team<br>
                Recruitment Manager<br>
                Yash Technologies<br>
                hr@yash.com</p>
            </body>
            </html>
            """

            # Construct ICS content
            organizer_email = "hr@yash.com"
            location = f"https://interviewer.yashtech.link/interviewer/{unique_id}"
            uid = f"{unique_id}@yash.com"

            # ICS content - no indentation
            ics_content = f"""BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Yash Technologies//Interview Scheduler//EN
CALSCALE:GREGORIAN
METHOD:REQUEST
BEGIN:VEVENT
UID:{uid}
DTSTAMP:{datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")}
DTSTART:{start_time_utc}
DTEND:{end_time_utc}
SUMMARY:Interview for {position_name} - Yash Technologies
DESCRIPTION:Online Interview for {position_name}\\nJoin link: {location}
LOCATION:{location}
ORGANIZER;CN=HR Team:MAILTO:{organizer_email}
ATTENDEE;CN={full_name};RSVP=TRUE:MAILTO:{email_id}
SEQUENCE:0
STATUS:CONFIRMED
TRANSP:OPAQUE
END:VEVENT
END:VCALENDAR"""

            # Create email with calendar invite
            msg = MIMEMultipart("mixed")
            msg["From"] = from_email
            msg["To"] = email_id
            msg["Subject"] = subject

            # Attach HTML body
            alt_part = MIMEMultipart("alternative")
            alt_part.attach(MIMEText(html_body, "html"))
            msg.attach(alt_part)

            # Attach ICS
            calendar_part = MIMEText(ics_content, "calendar;method=REQUEST", _charset="utf-8")
            calendar_part.add_header("Content-Disposition", "attachment; filename=invite.ics")
            msg.attach(calendar_part)

            # Send Email via SMTP
            try:
                smtp = SMTP(
                    hostname="smtp.gmail.com",
                    port=587,
                    start_tls=True
                )
                await smtp.connect()
                await smtp.login(from_email, smtp_password)
                await smtp.send_message(msg)
                await smtp.quit()
                print(f"📧 Invite sent to {email_id}")
            except Exception as e:
                print(f"❌ Failed to send email: {e}")
                
        except Exception as e:
            print(f"Error sending interview email: {str(e)}")

    async def create_initial_jd_record(self, jd_file: bytes, job_title: str, job_location: str,
                                    jd_summary_text: str = None, llm_id: str = None,
                                    tech_stack_id: str = None, jd_expiration: datetime = None, jd_qualification_score: float = None):
        try:
            ist = pytz.timezone("Asia/Kolkata")
            if not jd_expiration:
                jd_expiration = datetime.now(ist).replace(tzinfo=None) + timedelta(days=30)
            else:
                jd_expiration = jd_expiration.replace(tzinfo=None)
            
            jd = JDDetails(
                job_title=job_title,
                job_location=job_location,
                jd_summary_text=jd_summary_text,
                jd_expiration=jd_expiration,
                llm_id=int(llm_id) if llm_id else None,
                tech_stack_id=int(tech_stack_id) if tech_stack_id else None,
                jd_qualification_score=jd_qualification_score
            )
            
            self.session.add(jd)
            self.session.commit()
            
            generated_job_id = jd.job_id
            print(f"Created initial JD record with job_id: {generated_job_id}")
            
            return generated_job_id
            
        except Exception as e:
            self.session.rollback()
            print(f"Error in create_initial_jd_record: {e}")
            return None

    async def process_jd_background_tasks(self, job_id: int, jd_custom_questions_file,
                                        jd_file_content: bytes, jd_custom_questions_content: bytes,
                                        job_title: str, job_location: str):
        try:
            print(f"Starting background processing for job_id: {job_id}")
            
            db = Database()
            session = db.get_session()
            
            jd = session.query(JDDetails).filter(JDDetails.job_id == job_id).first()
            if not jd:
                print(f"JD record not found for job_id: {job_id}")
                return
            
            session.commit()
            
            print(f"Uploading JD file for job_id: {job_id}")
            content_type = "application/pdf"
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            s3_key = f"ai-interviewer/fileupload/jd_files/{job_title.replace(' ', '_')}_{job_location.replace(' ', '_')}_{timestamp}.pdf"
            jd_file_path = await upload_file_to_s3(s3_key, jd_file_content, content_type=content_type)
            jd.jd_file_path = jd_file_path
            session.commit()
            print(f"JD file uploaded successfully for job_id: {job_id}")
            
            print(f"Generating JD questions for job_id: {job_id}")
            question_service = QuestionService(db)
            jd_questions = question_service.generate_jd_question(jd_file_content, jd.llm_id, jd.tech_stack_id)
            jd.jd_questions = jd_questions if jd_questions else []
            session.commit()
            print(f"Generated {len(jd_questions or [])} JD questions for job_id: {job_id}")
            
            if jd_custom_questions_content:
                try:
                    print(f"Processing custom questions for job_id: {job_id}")
                    text_questions = await question_service.generate_file_based_question(
                        jd_custom_questions_content, jd.llm_id, jd.tech_stack_id
                    )
                    jd.jd_custom_questions_text = text_questions
                    print(f"Generated {len(text_questions or [])} custom questions for job_id: {job_id}")
                    
                    if jd_custom_questions_file:
                        content_type = jd_custom_questions_file.content_type
                        original_filename = jd_custom_questions_file.filename
                        ext = original_filename.split(".")[-1] if "." in original_filename else mimetypes.guess_extension(content_type) or "txt"
                        s3_key = f"ai-interviewer/fileupload/jd_custom_question_files/{job_title.replace(' ', '_')}_{job_location.replace(' ', '_')}_{timestamp}.{ext}"
                        jd_custom_questions_path = await upload_file_to_s3(s3_key, jd_custom_questions_content, content_type=content_type)
                        jd.jd_custom_questions_path = jd_custom_questions_path
                        print(f"Custom questions file uploaded successfully for job_id: {job_id}")
                    
                except Exception as e:
                    print(f"Error processing custom questions for job_id {job_id}: {str(e)}")
                    jd.jd_custom_questions_text = []
            
            else:
                jd.jd_custom_questions_text = []
            
            session.commit()
            print(f"Background processing completed successfully for job_id: {job_id}")
            
        except Exception as e:
            print(f"Error in background processing for job_id {job_id}: {str(e)}")
            try:
                jd.error_message = str(e)
                session.commit()
            except:
                pass
            
        finally:
            try:
                db.close(session)
            except:
                pass

    def update_interview_answers(self, unique_id: str, answers: str) -> tuple[bool, str | None]:
        try:
            self.update_expired_interviews()
            interview = self.session.query(InterviewDetailsMain).filter(
                InterviewDetailsMain.unique_id == unique_id,
                InterviewDetailsMain.status != 'expired'
            ).first()
            job_id = interview.job_id
            if not interview:
                return False, "Interview not found or already expired."
            interview.interview_answers = json.loads(answers)
            interview.status = 'completed'
            self.session.commit()
            try:
                streaming_app_url = os.getenv("STREAMING_APP_URL")
                if not streaming_app_url:
                    return False, "STREAMING_APP_URL is not set."
                response = requests.get(f"{streaming_app_url}/status?interview_id={unique_id}")
                response.raise_for_status()
                user_stat = UsersStats(interview_id=unique_id, job_id=job_id, file_data=response.content)
                self.session.add(user_stat)
                self.session.commit()
                clear_response = requests.post(f"{streaming_app_url}/clear-status?interview_id={unique_id}")
                clear_response.raise_for_status()
                return True, None
            except Exception as e:
                print("Unexpected error during facestreaming:", e)
        except requests.exceptions.RequestException as e:
            self.session.rollback()
            return False, f"Streaming app error: {str(e)}"
        
        except json.JSONDecodeError:
            self.session.rollback()
            return False, "Invalid JSON in answers."
        
        except Exception as e:
            self.session.rollback()
            return False, f"Unexpected error: {str(e)}"

    def update_expired_interviews(self):
        try:
            ist = pytz.timezone("Asia/Kolkata")
            current_time = datetime.now(ist).replace(tzinfo=None)
            
            # Query interviews that need expiration check or cleanup
            active_interviews = self.session.query(
                InterviewDetailsMain,
                JDDetails.jd_expiration
            ).join(
                JDDetails, InterviewDetailsMain.job_id == JDDetails.job_id
            ).filter(
                InterviewDetailsMain.status.in_(['scheduled', 'pending', 'expired'])
            ).all()
            
            jds_to_expire = set()
            interviews_to_cleanup = []
            
            for interview, jd_expiration in active_interviews:
                interview_expired = False
                
                # Check if JD has expired
                if jd_expiration and current_time > jd_expiration:
                    if interview.status != 'expired':
                        interview.status = 'expired'
                    jds_to_expire.add(interview.job_id)
                    interviews_to_cleanup.append(interview)
                    interview_expired = True
                
                # Check if interview slot has expired
                if not interview_expired and interview.status == 'scheduled':
                    slot_end_time = interview.scheduled_at + timedelta(minutes=30)
                    if current_time > slot_end_time:
                        interview.status = 'expired'
                        interviews_to_cleanup.append(interview)
                
                # Add already expired interviews to cleanup if they have files
                if interview.status == 'expired' and not interview_expired:
                    if interview.resume_path or interview.user_image_path:
                        interviews_to_cleanup.append(interview)
            
            # Commit status changes
            self.session.commit()
            
            # Clean up S3 files for expired JDs
            for job_id in jds_to_expire:
                try:
                    jd_record = self.session.query(JDDetails).filter(JDDetails.job_id == job_id).first()
                    if jd_record:
                        if jd_record.jd_file_path:
                            from utility.s3_utils import delete_s3_object
                            delete_s3_object(jd_record.jd_file_path)
                        if jd_record.jd_custom_questions_path:
                            from utility.s3_utils import delete_s3_object
                            delete_s3_object(jd_record.jd_custom_questions_path)
                except Exception as e:
                    print(f"Error deleting JD files for job {job_id}: {e}")
            
            # Clean up S3 files for expired interviews
            for interview in interviews_to_cleanup:
                try:
                    if interview.resume_path:
                        resume_s3_path = f"s3://{BUCKET_NAME}/{interview.resume_path.lstrip('/')}"
                        from utility.s3_utils import delete_s3_object
                        delete_s3_object(resume_s3_path)
                    
                    if interview.user_image_path:
                        user_image_s3_path = f"s3://{BUCKET_NAME}/{interview.user_image_path.lstrip('/')}"
                        from utility.s3_utils import delete_s3_object
                        delete_s3_object(user_image_s3_path)
                except Exception as e:
                    print(f"Error deleting files for interview {interview.unique_id}: {e}")
            
            return True
            
        except Exception as e:
            print(f"Error updating expired interviews: {e}")
            self.session.rollback()
            return False

    def is_interview_accessible(self, unique_id: str) -> dict:
        try:
            interview = self.session.query(InterviewDetailsMain).filter(
                InterviewDetailsMain.unique_id == unique_id
            ).first()
            
            if not interview:
                return {
                    "accessible": False,
                    "message": "Interview not found"
                }
            
            if interview.status == 'completed':
                return {
                    "accessible": False,
                    "message": "This interview has already been completed and is no longer accessible.",
                    "expiry_time": None
                }
            elif interview.status == 'expired':
                return {
                    "accessible": False,
                    "message": "Interview has been expired and is no longer accessible."
                }
            elif interview.status == 'cancelled':
                return {
                    "accessible": False,
                    "message": "Interview has been cancelled and is no longer accessible"
                }
            elif interview.status == 'pending':
                return {
                    "accessible": False,
                    "message": "Interview is pending approval and is not accessible for now"
                }
            
            ist = pytz.timezone("Asia/Kolkata")
            current_time = datetime.now(ist).replace(tzinfo=None)
            
            scheduled_start = interview.scheduled_at
            slot_end = scheduled_start + timedelta(minutes=30)
            interview_expiry = interview.interview_end_time or scheduled_start + timedelta(hours=1)
            
            if current_time < scheduled_start:
                time_until = scheduled_start - current_time
                hours = time_until.seconds // 3600
                minutes = (time_until.seconds % 3600) // 60
                
                return {
                    "accessible": False,
                    "message": f"Interview has not started yet. Your access window begins at {scheduled_start.strftime('%I:%M %p')} on {scheduled_start.strftime('%Y-%m-%d')}."
                }
            
            if current_time > slot_end:
                return {
                    "accessible": False,
                    "message": f"Your access window has expired. You could only join between {scheduled_start.strftime('%I:%M %p')} and {slot_end.strftime('%I:%M %p')} on {scheduled_start.strftime('%Y-%m-%d')}."
                }
            
            return {
                "accessible": True,
                "message": "Interview is accessible",
                "expiry_time": interview_expiry.strftime("%Y-%m-%d %H:%M:%S")
            }
            
        except Exception as e:
            print(f"Error checking interview accessibility: {e}")
            return {
                "accessible": False,
                "message": f"Error checking interview accessibility: {str(e)}"
            }

    def get_interview_details(self, unique_id: str):
        try:
            print(f"Querying interview_details_main for unique_id: {unique_id}")
            self.update_expired_interviews()
            interview = self.session.query(InterviewDetailsMain).filter(InterviewDetailsMain.unique_id == unique_id).first()
            if not interview:
                print(f"No interview found in database for unique_id: {unique_id}")
                all_ids = self.session.query(InterviewDetailsMain.unique_id).all()
                print(f"Available unique_ids in database: {[id[0] for id in all_ids]}")
                return None
            print(f"Found interview for unique_id: {unique_id}, details: full_name={interview.full_name}, status={interview.status}, recording_urls={interview.recording_urls}")
            return interview
        except Exception as e:
            print(f"Error querying interview for unique_id {unique_id}: {str(e)}")
            return None

    def get_questions(self, unique_id: str):
        try:
            self.update_expired_interviews()
            interview = self.session.query(InterviewDetailsMain.interview_questions).filter(InterviewDetailsMain.unique_id == unique_id).first()
            print("interview:", interview)
            return interview[0] if interview else None
        except Exception as e:
            print(f"Error fetching questions: {e}")
            return None

    def get_all_interviews(self):
        try:
            self.update_expired_interviews()
            
            try:
                interviews = self.session.query(
                    InterviewDetailsMain.unique_id,
                    InterviewDetailsMain.user_image_path,
                    InterviewDetailsMain.status,
                    InterviewDetailsMain.scheduled_at,
                    InterviewDetailsMain.full_name,
                    InterviewDetailsMain.phone,
                    JDDetails.job_title
                ).join(
                    JDDetails, InterviewDetailsMain.job_id == JDDetails.job_id
                ).filter(
                    InterviewDetailsMain.status.in_(['scheduled', 'completed'])
                ).order_by(InterviewDetailsMain.scheduled_at.desc()).all()
            except Exception as e:
                print(f"Error querying user_image_path, falling back to user_image: {e}")
                interviews = self.session.query(
                    InterviewDetailsMain.unique_id,
                    InterviewDetailsMain.user_image,
                    InterviewDetailsMain.status,
                    InterviewDetailsMain.scheduled_at,
                    InterviewDetailsMain.full_name,
                    InterviewDetailsMain.phone,
                    JDDetails.job_title
                ).join(
                    JDDetails, InterviewDetailsMain.job_id == JDDetails.job_id
                ).filter(
                    InterviewDetailsMain.status.in_(['scheduled', 'completed'])
                ).order_by(InterviewDetailsMain.scheduled_at.desc()).all()
            
            return interviews
        except Exception as e:
            print(f"Error fetching interviews: {e}")
            return []

    def cancel_interview(self, unique_id: str):
        try:
            self.update_expired_interviews()
            interview = self.session.query(InterviewDetailsMain).filter(
                InterviewDetailsMain.unique_id == unique_id,
                InterviewDetailsMain.status != 'expired'
            ).first()
            if not interview:
                return False
            interview.status = 'cancelled'
            self.session.commit()
            return True
        except Exception as e:
            print(f"Error cancelling interview: {e}")
            return False

    def get_completed_interview_users(self):
        try:
            users = self.session.query(
                InterviewDetailsMain.unique_id,
                InterviewDetailsMain.full_name,
                InterviewDetailsMain.phone
            ).filter(InterviewDetailsMain.status == 'completed').distinct().order_by(InterviewDetailsMain.full_name).all()
            return users
        except Exception as e:
            print(f"Error fetching completed interview users: {e}")
            return []

    async def get_jd_questions(self, job_id: int):
        try:
            jd_record = self.session.query(JDDetails).filter(JDDetails.job_id == job_id).first()
            if not jd_record:
                print(f"No record found for job_id {job_id} in jd_details table")
                return None, False
            if jd_record.jd_questions is None:
                print(f"jd_questions is NULL for job_id {job_id}")
                return None, True
            print(f"Found jd_questions for job_id {job_id}: {jd_record.jd_questions}")
            return jd_record.jd_questions, True
        except Exception as e:
            print(f"Error fetching JD questions for job_id {job_id}: {e}")
            return None, False

    def get_jd(self, job_id: int):
        try:
            jd_record = self.session.query(JDDetails).filter(JDDetails.job_id == job_id).first()
            if not jd_record:
                print(f"No record found for job_id {job_id} in jd_details table")
                return None, False
            
            jd_file_path = jd_record.jd_file_path
            if jd_file_path:
                try:
                    s3_key = jd_file_path.replace(f"s3://{BUCKET_NAME}/", "") if jd_file_path.startswith(f"s3://{BUCKET_NAME}/") else jd_file_path
                    s3_url = f"s3://{BUCKET_NAME}/{s3_key}"
                    jd_file_path = get_signed_s3_url(s3_url)
                except Exception as e:
                    print(f"Error generating JD file URL: {str(e)}")
                    jd_file_path = None
            
            jd_custom_questions_path = jd_record.jd_custom_questions_path
            if jd_custom_questions_path:
                try:
                    s3_key = jd_custom_questions_path.replace(f"s3://{BUCKET_NAME}/", "") if jd_custom_questions_path.startswith(f"s3://{BUCKET_NAME}/") else jd_custom_questions_path
                    s3_url = f"s3://{BUCKET_NAME}/{s3_key}"
                    jd_custom_questions_path = get_signed_s3_url(s3_url)
                except Exception as e:
                    print(f"Error generating custom questions URL: {str(e)}")
                    jd_custom_questions_path = None
            
            return {
                "job_id": jd_record.job_id,
                "job_title": jd_record.job_title,
                "job_location": jd_record.job_location,
                "jd_questions": jd_record.jd_questions,
                "jd_summary_text": jd_record.jd_summary_text,
                "jd_file_path": jd_file_path,
                "created_at": jd_record.created_at,
                "jd_expiration": jd_record.jd_expiration.isoformat() if jd_record.jd_expiration else None,
                "jd_custom_questions_path": jd_custom_questions_path
            }, True
        except Exception as e:
            print(f"Error fetching JD questions for job_id {job_id}: {e}")
            return None, False

    def get_status_data(self, user_id: str):
        try:
            print("user_id:", user_id)
            result = self.session.query(UsersStats.file_data).filter(
                UsersStats.interview_id == user_id
            ).order_by(UsersStats.upload_date.desc()).first()
            print("result:", result)
            if not result:
                return None
            csv_string = result.file_data.decode('utf-8')
            csvfile = io.StringIO(csv_string)
            data_groups = defaultdict(lambda: {
                'Timestamp': '',
                'Status': 0,
                'Engaged_Frames': 0,
                'Disengaged_Frames': 0
            })
            reader = csv.DictReader(csvfile)
            
            for row in reader:
                timestamp = row['Timestamp']
                data_groups[timestamp]['Timestamp'] = timestamp
                data_groups[timestamp]['Status'] = row['Status']
                data_groups[timestamp]['Engaged_Frames'] += int(row['Engaged_Frames'])
                data_groups[timestamp]['Disengaged_Frames'] += int(row['Disengaged_Frames'])
            return [group for group in data_groups.values()]
        except Exception as e:
            print(f"Error fetching status data: {e}")
            raise

    def get_all_jobs(self):
        try:
            jobs = self.session.query(
                JDDetails.job_id,
                JDDetails.job_title,
                JDDetails.job_location,
                JDDetails.created_at,
                JDDetails.jd_summary_text,
                JDDetails.jd_expiration
            ).order_by(JDDetails.created_at.desc()).all()
            
            return [
                {
                    "job_id": job.job_id,
                    "job_title": job.job_title,
                    "job_location": job.job_location,
                    "created_at": job.created_at.isoformat() if job.created_at else None,
                    "jd_summary_text": job.jd_summary_text if job.jd_summary_text else None,
                    "jd_expiration": job.jd_expiration.isoformat() if job.jd_expiration else None
                }
                for job in jobs
            ]
        except Exception as e:
            print(f"Error fetching jobs: {e}")
            return []

    async def update_job(self, jd_custom_questions_file, jd_file_uploadfile, job_id: int, job_title: str, job_location: str, jd_file_content: bytes = None, jd_custom_questions_text: bytes = None, jd_summary_text: str = None, llm_id: str = None, tech_stack_id: str = None, jd_expiration: datetime = None, jd_qualification_score: float = None):
        try:
            job = self.session.query(JDDetails).filter(JDDetails.job_id == job_id).first()
            if not job:
                return {"success": False, "error": f"Job with ID {job_id} not found"}

            original_title = job.job_title
            original_location = job.job_location
            original_questions = job.jd_questions
            original_text_questions = job.jd_custom_questions_text
            original_summary_text = job.jd_summary_text
            original_llm_id = job.llm_id
            original_tech_stack_id = job.tech_stack_id
            original_expiration = job.jd_expiration
            original_jd_qualification_score = job.jd_qualification_score

            job.job_title = job_title
            job.job_location = job_location
            
            if tech_stack_id is not None:
                try:
                    tech_stack_id_int = int(tech_stack_id)
                    from models import AgentPrompts
                    tech_stack_exists = self.session.query(AgentPrompts).filter(AgentPrompts.tech_stack_id == tech_stack_id_int).first()
                    if not tech_stack_exists:
                        return {"success": False, "error": f"Invalid tech_stack_id {tech_stack_id}: Not found in database"}
                    job.tech_stack_id = tech_stack_id_int
                except ValueError:
                    return {"success": False, "error": f"Invalid tech_stack_id {tech_stack_id}: Must be an integer"}
            if llm_id is not None:
                try:
                    llm_id_int = int(llm_id)
                    llm_exists = self.session.query(LLMs).filter(LLMs.id == llm_id_int).first()
                    if not llm_exists:
                        return {"success": False, "error": f"Invalid llm_id {llm_id}: Not found in database"}
                    job.llm_id = llm_id_int
                except ValueError:
                    return {"success": False, "error": f"Invalid llm_id {llm_id}: Must be an integer"}
                
            if jd_summary_text is not None:
                job.jd_summary_text = jd_summary_text
            if jd_expiration is not None:
                ist = pytz.timezone("Asia/Kolkata")
                job.jd_expiration = jd_expiration.replace(tzinfo=None)
            if jd_qualification_score is not None:
                job.jd_qualification_score = round(jd_qualification_score, 2)

            question_service = QuestionService(self.db)
            updated_questions = []

            if jd_file_content and len(jd_file_content) > 0:
                try:
                    new_questions = question_service.generate_jd_question(jd_file_content, job.llm_id, job.tech_stack_id)
                    if not new_questions:
                        raise ValueError("Failed to generate questions from JD file")
                    job.jd_questions = new_questions

                    if job.jd_file_path:
                        delete_s3_object(job.jd_file_path)

                    content_type = jd_file_uploadfile.content_type
                    original_filename = jd_file_uploadfile.filename
                    ext = original_filename.split(".")[-1] if "." in original_filename else mimetypes.guess_extension(content_type) or "bin"
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    s3_key = f"ai-interviewer/fileupload/jd_files/{job_title.replace(' ', '_')}_{job_location.replace(' ', '_')}_{timestamp}.{ext}"
                    jd_file_path = await upload_file_to_s3(s3_key, jd_file_content, content_type=content_type)
                    job.jd_file_path = jd_file_path

                except Exception as file_error:
                    self.session.rollback()
                    print(f"Error processing JD file for job {job_id}: {file_error}")
                    return {"success": False, "error": f"Failed to process JD file: {str(file_error)}"}

            if jd_custom_questions_text and len(jd_custom_questions_text) > 0:
                try:
                    new_text_questions = await question_service.generate_file_based_question(jd_custom_questions_text, job.llm_id, job.tech_stack_id)
                    if not new_text_questions:
                        raise ValueError("Failed to generate questions from text file")
                    job.jd_custom_questions_text = new_text_questions

                    if job.jd_custom_questions_path:
                        delete_s3_object(job.jd_custom_questions_path)

                    content_type = jd_custom_questions_file.content_type
                    original_filename = jd_custom_questions_file.filename
                    ext = original_filename.split(".")[-1] if "." in original_filename else mimetypes.guess_extension(content_type) or "bin"
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    s3_key = f"ai-interviewer/fileupload/jd_custom_question_files/{job_title.replace(' ', '_')}_{job_location.replace(' ', '_')}_{timestamp}.{ext}"
                    jd_custom_questions_path = await upload_file_to_s3(s3_key, jd_custom_questions_text, content_type=content_type)
                    job.jd_custom_questions_path = jd_custom_questions_path

                    updated_questions.extend(new_text_questions)

                except Exception as text_file_error:
                    self.session.rollback()
                    print(f"Error processing text file for job {job_id}: {text_file_error}")
                    return {"success": False, "error": f"Failed to process text file: {str(text_file_error)}"}

            if updated_questions:
                interviews = self.session.query(InterviewDetailsMain).filter(
                    InterviewDetailsMain.job_id == job_id,
                    InterviewDetailsMain.status.in_(['scheduled', 'pending'])
                ).all()
                for interview in interviews:
                    existing_questions = interview.interview_questions or []
                    domain_resume_questions = [
                        q for q in existing_questions 
                        if not any(q['question'] == eq['question'] for eq in job.jd_questions or [])
                        and not any(q['question'] == eq['question'] for eq in job.jd_custom_questions_text or [])
                    ]
                    interview.interview_questions = domain_resume_questions + updated_questions

            try:
                self.session.commit()
                print(f"Successfully updated job {job_id}")
            except Exception as commit_error:
                self.session.rollback()
                print(f"Error committing job update {job_id}: {commit_error}")
                return {"success": False, "error": f"Failed to save changes: {str(commit_error)}"}

            return {
                "success": True,
                "data": {
                    "job_id": job.job_id,
                    "job_title": job.job_title,
                    "job_location": job.job_location,
                    "created_at": job.created_at.isoformat() if job.created_at else None,
                    "jd_questions_count": len(job.jd_questions) if job.jd_questions else 0,
                    "jd_text_questions_count": len(job.jd_custom_questions_text) if job.jd_custom_questions_text else 0,
                    "jd_file_updated": jd_file_content is not None and len(jd_file_content) > 0,
                    "text_questions_updated": jd_custom_questions_text is not None and len(jd_custom_questions_text) > 0,
                    "jd_summary_text_updated": jd_summary_text is not None,
                    "llm_id_updated": llm_id is not None,
                    "tech_stack_id_updated": tech_stack_id is not None,
                    "jd_expiration_updated": jd_expiration is not None,
                    "jd_expiration": job.jd_expiration.isoformat() if job.jd_expiration else None,
                    "jd_qualification_score_updated": jd_qualification_score is not None,
                    "jd_qualification_score": round(float(job.jd_qualification_score), 2) if job.jd_qualification_score is not None else None
                }
            }
        except Exception as e:
            self.session.rollback()
            print(f"Error updating job: {e}")
            return {"success": False, "error": str(e)}

    def delete_job(self, job_id: int):
        try:
            job = self.session.query(JDDetails).filter(JDDetails.job_id == job_id).first()
            if not job:
                return False
            
            if job.jd_file_path:
                delete_s3_object(job.jd_file_path)
            if job.jd_custom_questions_path:
                delete_s3_object(job.jd_custom_questions_path)
            self.session.delete(job)
            self.session.commit()
            return True
        except Exception as e:
            self.session.rollback()
            print(f"Error deleting job: {e}")
            return False

    def update_interview_recording(self, unique_id: str, recording_url: str) -> bool:
        try:
            interview = self.session.query(InterviewDetailsMain).filter_by(unique_id=unique_id).first()
            if not interview:
                print(f"No interview found for unique_id: {unique_id}")
                return False
            
            if interview.recording_urls is None:
                interview.recording_urls = []
            
            if recording_url not in interview.recording_urls:
                interview.recording_urls.append(recording_url)
                self.session.commit()
                print(f"Updated recording URL for unique_id: {unique_id}")
                return True
            else:
                print(f"Recording URL already exists for unique_id: {unique_id}")
                return True
        except Exception as e:
            self.session.rollback()
            print(f"Error updating recording URL for unique_id {unique_id}: {e}")
            return False
        
    def get_interview(self, unique_id: str) -> dict:
        session = self.db.get_session()
        try:
            result = session.execute(
                text("SELECT * FROM interview_details_main WHERE unique_id = :unique_id"),
                {"unique_id": unique_id}
            ).fetchone()
            if not result:
                return {}
            return {
                "unique_id": result.unique_id,
                "recording_urls": result.recording_urls or [],
                "status": result.status
            }
        finally:
            session.close()

    def get_interview_candidate_details(self, unique_id: str) -> dict:
        try:
            interview = self.session.query(
                InterviewDetailsMain.full_name,
                InterviewDetailsMain.age,
                InterviewDetailsMain.phone,
                InterviewDetailsMain.email_id,
                InterviewDetailsMain.sex,
                InterviewDetailsMain.user_image_path,
                InterviewDetailsMain.domain,
                InterviewDetailsMain.resume_score,
                InterviewDetailsMain.scheduled_at,
                InterviewDetailsMain.evaluation_result,
                JDDetails.job_title,
                JDDetails.job_location,
                JDDetails.jd_qualification_score
            ).join(
                JDDetails, InterviewDetailsMain.job_id == JDDetails.job_id
            ).filter(
                InterviewDetailsMain.unique_id == unique_id
            ).first()

            if not interview:
                return {"success": False, "message": f"No interview found for unique_id: {unique_id}"}

            summary_points = []
            if interview.evaluation_result and isinstance(interview.evaluation_result, dict):
                summary_points = interview.evaluation_result.get("summary_points", [])

            resume_score = float(interview.resume_score) if isinstance(interview.resume_score, Decimal) else interview.resume_score
            jd_qualification_score = float(interview.jd_qualification_score) if interview.jd_qualification_score is not None else 0.60
            qualified = resume_score >= jd_qualification_score

            user_image_url = None
            if interview.user_image_path:
                try:
                    s3_key = interview.user_image_path.replace(f"s3://{BUCKET_NAME}/", "") if interview.user_image_path.startswith(f"s3://{BUCKET_NAME}/") else interview.user_image_path
                    s3_url = f"s3://{BUCKET_NAME}/{s3_key}"
                    user_image_url = get_signed_s3_url(s3_url)
                except Exception as e:
                    print(f"Error generating user_image_url: {str(e)}")
                    user_image_url = None

            return {
                "success": True,
                "data": {
                    "unique_id": unique_id,
                    "full_name": interview.full_name,
                    "age": interview.age,
                    "phone": interview.phone,
                    "email_id": interview.email_id,
                    "sex": interview.sex,
                    "user_image_url": user_image_url,
                    "domain": interview.domain,
                    "resume_score": resume_score,
                    "scheduled_at": interview.scheduled_at.isoformat() if interview.scheduled_at else None,
                    "job_title": interview.job_title,
                    "job_location": interview.job_location,
                    "summary_points": summary_points,
                    "qualified": qualified,
                    "jd_qualification_score": jd_qualification_score
                }
            }

        except Exception as e:
            print(f"Error fetching interview candidate details for unique_id {unique_id}: {str(e)}")
            return {"success": False, "message": f"Error fetching details: {str(e)}"}

    async def share_interview_link(self, unique_id: str):
        try:
            interview = self.session.query(InterviewDetailsMain).filter(
                InterviewDetailsMain.unique_id == unique_id
            ).first()
            
            if not interview:
                return {"success": False, "message": "Interview not found"}
            
            if interview.status != 'scheduled':
                return {"success": False, "message": f"Interview is not scheduled. Current status: {interview.status}"}
            
            job = self.session.query(JDDetails).filter(
                JDDetails.job_id == interview.job_id
            ).first()
            
            if not job:
                return {"success": False, "message": "Job details not found"}
            
            position_name = job.job_title
            scheduled_start_time = interview.scheduled_at
            slot_end_time = scheduled_start_time + timedelta(minutes=30)
            interview_expiry_time = scheduled_start_time + timedelta(hours=1)
            
            interview_date = scheduled_start_time.strftime("%Y-%m-%d")
            interview_time = scheduled_start_time.strftime("%I:%M %p IST")
            slot_end_time_str = slot_end_time.strftime("%I:%M %p IST")
            expiry_time_str = interview_expiry_time.strftime("%I:%M %p IST")
            
            start_time_utc = scheduled_start_time.astimezone(pytz.utc).strftime("%Y%m%dT%H%M%SZ")
            end_time_utc = interview_expiry_time.astimezone(pytz.utc).strftime("%Y%m%dT%H%M%SZ")
            
            from_email = os.getenv("SENDER_EMAIL")
            smtp_password = os.getenv("SMTP_PASSWORD")
            
            if not from_email or not smtp_password:
                raise ValueError("SENDER_EMAIL or SMTP_PASSWORD environment variables are not set")
            
            subject = f"Interview Link for {position_name} at Yash Technologies"
            
            html_body = f"""
            <html>
            <body>
                <p>Dear {interview.full_name},</p>
                <p>Here are your interview details for the <strong>{position_name}</strong> position at Yash Technologies.</p>
                
                <p><strong>Interview Details:</strong></p>
                <p>
                    <strong>Date:</strong> {interview_date}<br>
                    <strong>Access Window:</strong> {interview_time} - {slot_end_time_str}<br>
                    <strong>Interview Closes At:</strong> {expiry_time_str}<br>
                </p>

                <p><strong>Meeting Access:</strong></p>
                <p>Please join using this link:<br>
                <a href="https://interviewer.yashtech.link/interviewer/{unique_id}">Interview Link</a></p>
                
                <p><i>Note:</i> You can access the interview link anytime between {interview_time} and {slot_end_time_str}. The interview will automatically close at {expiry_time_str}, which is 1 hour after the start time.</p>

                <p>Best regards,<br>
                HR Team<br>
                Recruitment Manager<br>
                Yash Technologies<br>
                hr@yash.com</p>
            </body>
            </html>
            """
            
            organizer_email = "hr@yash.com"
            location = f"https://interviewer.yashtech.link/interviewer/{unique_id}"
            uid = f"{unique_id}@yash.com"
            
            ics_content = f"""BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Yash Technologies//Interview Scheduler//EN
CALSCALE:GREGORIAN
METHOD:REQUEST
BEGIN:VEVENT
UID:{uid}
DTSTAMP:{datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")}
DTSTART:{start_time_utc}
DTEND:{end_time_utc}
SUMMARY:Interview for {position_name} - Yash Technologies
DESCRIPTION:Online Interview for {position_name}\\nJoin link: {location}
LOCATION:{location}
ORGANIZER;CN=HR Team:MAILTO:{organizer_email}
ATTENDEE;CN={interview.full_name};RSVP=TRUE:MAILTO:{interview.email_id}
SEQUENCE:0
STATUS:CONFIRMED
TRANSP:OPAQUE
END:VEVENT
END:VCALENDAR"""
        
            msg = MIMEMultipart("mixed")
            msg["From"] = from_email
            msg["To"] = interview.email_id
            msg["Subject"] = subject
            
            alt_part = MIMEMultipart("alternative")
            alt_part.attach(MIMEText(html_body, "html"))
            msg.attach(alt_part)
            
            calendar_part = MIMEText(ics_content, "calendar;method=REQUEST", _charset="utf-8")
            calendar_part.add_header("Content-Disposition", "attachment; filename=invite.ics")
            msg.attach(calendar_part)
            
            try:
                smtp = SMTP(
                    hostname="smtp.gmail.com",
                    port=587,
                    start_tls=True
                )
                await smtp.connect()
                await smtp.login(from_email, smtp_password)
                await smtp.send_message(msg)
                await smtp.quit()
                print(f"📧 Invite sent to {interview.email_id}")
            except Exception as e:
                print(f"❌ Failed to send email: {e}")
                pass

            return {
                "success": True,
                "message": f"Interview link shared successfully with {interview.full_name}",
                "email_sent_to": interview.email_id,
            }
        except Exception as e:
            self.session.rollback()
            print(f"Error scheduling interview: {e}")
            return {"success": False, "message": str(e)}