from fastapi import WebSocket,WebSocketDisconnect
from database import Database
import asyncio
import os
import time
from deepgram import DeepgramClient, LiveTranscriptionEvents, LiveOptions, Microphone
from dotenv import load_dotenv
import aiohttp
import logging

load_dotenv()
logger = logging.getLogger(__name__)

class SpeechService:
    def __init__(self, db: Database):
        self.db = db
        self.session = db.get_session()

    class ConversationManager:
        def __init__(self):
            self.temp_msg = ""
            self.final_msg = ""
            self.stop_listening = asyncio.Event()
            self.last_active_time = time.time()

        def handle_full_sentence(self, full_sentence):
            self.temp_msg = full_sentence
            self.stop_listening.set()

        async def listen_for_response(self):
            try:
                msg = await self.get_transcript(self.handle_full_sentence)
                if msg:
                    self.final_msg += msg.lower().strip() + "\n"
            except Exception as e:
                print(f"Error while listening: {str(e)}")

        async def get_transcript(self, callback):
            transcript_collector = []
            transcription_complete = asyncio.Event()
            try:
                deepgram = DeepgramClient(os.environ.get("DEEPGRAM_API_KEY"))
                dg_connection = deepgram.listen.live.v("1")
                async def on_message(**kwargs):
                    try:
                        result = kwargs.get('result')
                        sentence = result.channel.alternatives[0].transcript
                        if not result.speech_final:
                            transcript_collector.append(sentence)
                        else:
                            transcript_collector.append(sentence)
                            full_sentence = " ".join(transcript_collector)
                            if len(full_sentence.strip()) > 0:
                                full_sentence = full_sentence.strip()
                                callback(full_sentence)
                                transcription_complete.set()
                    except Exception as e:
                        print(f"Error in on_message: {e}")
                dg_connection.on(LiveTranscriptionEvents.Transcript, on_message)
                options = LiveOptions(
                    model="nova-2",
                    punctuate=True,
                    language="en-US",
                    encoding="linear16",
                    channels=1,
                    sample_rate=16000,
                    endpointing=600,
                    smart_format=True
                )
                dg_connection.start(options)
                microphone = Microphone(dg_connection.send)
                microphone.start()
                await transcription_complete.wait()
                microphone.finish()
                await dg_connection.finish()
            except Exception as e:
                print(f"Could not open socket: {e}")
                return None
            ans = " ".join(transcript_collector)
            transcript_collector.clear()
            return ans

        async def main(self):
            try:
                listen_task = asyncio.create_task(self.listen_for_response())
                await listen_task
            except Exception as e:
                print(f"Error in main execution: {str(e)}")
                return ""

    async def process_questions(self):
        try:
            manager = self.ConversationManager()
            await manager.main()
            response = manager.final_msg if manager.final_msg else "No speech detected"
            return {"status": "success", "text": response}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    async def stream_audio(self, websocket: WebSocket):
        try:
            await websocket.accept()
            while True:
                try:
                    text = await websocket.receive_text()
                    print(f"Received text for TTS: {text}")
                    DEEPGRAM_URL = f"https://api.deepgram.com/v1/speak?model=aura-asteria-en&output_format=mp3"
                    headers = {
                        "Authorization": f"Token {os.environ.get('DEEPGRAM_API_KEY')}",
                        "Content-Type": "application/json"
                    }
                    payload = {"text": text}
                    async with aiohttp.ClientSession() as session:
                        async with session.post(DEEPGRAM_URL, headers=headers, json=payload) as response:
                            if response.status != 200:
                                error_text = await response.text()
                                logger.error(f"Deepgram API Error: {response.status} - {error_text}")
                                return
                            audio_data = await response.read()
                            chunk_size = 16384
                            for i in range(0, len(audio_data), chunk_size):
                                chunk = audio_data[i:i + chunk_size]
                                await websocket.send_bytes(chunk)
                    await asyncio.sleep(0.1)
                except WebSocketDisconnect:
                    print("Client disconnected during streaming")
                    break
                except Exception as e:
                    print(f"Error processing TTS request: {e}")
                    break
        except Exception as e:
            print(f"WebSocket connection error: {e}")
        finally:
            try:
                await websocket.close()
            except:
                pass