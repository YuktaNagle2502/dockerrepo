from database import Database
from models import TabSwitchingActivity, InterviewDetailsMain
from datetime import datetime
import pytz

def get_ist_time():
    """Get current time in IST timezone"""
    ist = pytz.timezone("Asia/Kolkata")
    current_time = datetime.now(ist)
    return current_time.replace(tzinfo=None)

class TabSwitchingService:
    def __init__(self, db: Database):
        self.db = db
    
    def create_tab_switching_record(self, interview_id: str, screenshot_url: str, 
                                  blob_name: str, timestamp: datetime) -> dict:
        """Create a new tab switching activity record"""
        session = self.db.get_session()
        try:
            # Verify interview exists
            interview_exists = session.query(InterviewDetailsMain).filter_by(
                unique_id=interview_id
            ).first()
            
            if not interview_exists:
                return {"success": False, "message": "Interview not found"}
            
            # Create new record
            tab_switch_record = TabSwitchingActivity(
                interview_id=interview_id,
                screenshot_url=screenshot_url,
                blob_name=blob_name,
                timestamp=timestamp,
            )
            
            session.add(tab_switch_record)
            session.commit()
            
            return {
                "success": True, 
                "message": "Tab switching activity recorded",
                "activity_id": tab_switch_record.id
            }
            
        except Exception as e:
            session.rollback()
            return {"success": False, "message": f"Error creating record: {str(e)}"}
        finally:
            session.close()
    
    def get_tab_switching_activities(self, interview_id: str) -> dict:
        """Get all tab switching activities for an interview"""
        session = self.db.get_session()
        try:
            # Verify interview exists
            interview_exists = session.query(InterviewDetailsMain).filter_by(
                unique_id=interview_id
            ).first()
            
            if not interview_exists:
                return {"success": False, "message": "Interview not found"}
            
            # Get activities
            activities = session.query(TabSwitchingActivity).filter_by(
                interview_id=interview_id
            ).order_by(TabSwitchingActivity.timestamp.desc()).all()
            
            activity_list = []
            for activity in activities:
                activity_list.append({
                    "id": activity.id,
                    "interview_id": activity.interview_id,
                    "screenshot_url": activity.screenshot_url,
                    "blob_name": activity.blob_name,
                    "timestamp": activity.timestamp.isoformat()
                })
            
            return {
                "success": True,
                "total_activities": len(activity_list),
                "activities": activity_list
            }
        except Exception as e:
            return {"success": False, "message": f"Error retrieving activities: {str(e)}"}
        finally:
            session.close()
    
    def get_interview_suspicious_activities_summary(self, interview_id: str) -> dict:
        """Get summary of suspicious activities for an interview"""
        session = self.db.get_session()
        try:
            # Count tab switches
            tab_switches = session.query(TabSwitchingActivity).filter_by(
                interview_id=interview_id
            ).count()
            
            # Get first and last tab switch times
            first_switch = session.query(TabSwitchingActivity).filter_by(
                interview_id=interview_id
            ).order_by(TabSwitchingActivity.timestamp.asc()).first()
            
            last_switch = session.query(TabSwitchingActivity).filter_by(
                interview_id=interview_id
            ).order_by(TabSwitchingActivity.timestamp.desc()).first()
            
            return {
                "success": True,
                "interview_id": interview_id,
                "total_tab_switches": tab_switches,
                "has_suspicious_activity": tab_switches > 0,
                "first_switch_time": first_switch.timestamp.isoformat() if first_switch else None,
                "last_switch_time": last_switch.timestamp.isoformat() if last_switch else None
            }
            
        except Exception as e:
            return {"success": False, "message": f"Error getting summary: {str(e)}"}
        finally:
            session.close()
    
    def update_screenshot_url(self, activity_id: int, new_url: str) -> dict:
        """Update screenshot URL for an activity (when regenerating presigned URLs)"""
        session = self.db.get_session()
        try:
            activity = session.query(TabSwitchingActivity).filter_by(id=activity_id).first()
            
            if not activity:
                return {"success": False, "message": "Activity not found"}
            
            activity.screenshot_url = new_url
            session.commit()
            
            return {"success": True, "message": "Screenshot URL updated"}
            
        except Exception as e:
            session.rollback()
            return {"success": False, "message": f"Error updating URL: {str(e)}"}
        finally:
            session.close()
    
    def delete_tab_switching_activity(self, activity_id: int) -> dict:
        """Delete a tab switching activity"""
        session = self.db.get_session()
        try:
            activity = session.query(TabSwitchingActivity).filter_by(id=activity_id).first()
            
            if not activity:
                return {"success": False, "message": "Activity not found"}
            
            blob_name = activity.blob_name  # Return this so caller can delete from S3
            session.delete(activity)
            session.commit()
            
            return {
                "success": True, 
                "message": "Activity deleted",
                "blob_name": blob_name
            }
            
        except Exception as e:
            session.rollback()
            return {"success": False, "message": f"Error deleting activity: {str(e)}"}
        finally:
            session.close()
    
    def get_activities_by_date_range(self, interview_id: str, start_date: datetime, 
                                   end_date: datetime) -> dict:
        """Get tab switching activities within a date range"""
        session = self.db.get_session()
        try:
            activities = session.query(TabSwitchingActivity).filter(
                TabSwitchingActivity.interview_id == interview_id,
                TabSwitchingActivity.timestamp >= start_date,
                TabSwitchingActivity.timestamp <= end_date
            ).order_by(TabSwitchingActivity.timestamp.desc()).all()
            
            activity_list = []
            for activity in activities:
                activity_list.append({
                    "id": activity.id,
                    "interview_id": activity.interview_id,
                    "screenshot_url": activity.screenshot_url,
                    "blob_name": activity.blob_name,
                    "timestamp": activity.timestamp.isoformat()
                })
            
            return {
                "success": True,
                "total_activities": len(activity_list),
                "activities": activity_list
            }
            
        except Exception as e:
            return {"success": False, "message": f"Error retrieving activities: {str(e)}"}
        finally:
            session.close()
    
    def get_all_interviews_with_suspicious_activity(self) -> dict:
        """Get all interviews that have suspicious tab switching activity"""
        session = self.db.get_session()
        try:
            result = session.query(
                InterviewDetailsMain.unique_id,
                InterviewDetailsMain.full_name,
                InterviewDetailsMain.phone,
                InterviewDetailsMain.status,
                session.query(TabSwitchingActivity).filter_by(
                    interview_id=InterviewDetailsMain.unique_id
                ).count().label('tab_switch_count')
            ).filter(
                session.query(TabSwitchingActivity).filter_by(
                    interview_id=InterviewDetailsMain.unique_id
                ).exists()
            ).all()
            
            interviews_list = []
            for interview in result:
                interviews_list.append({
                    "interview_id": interview.unique_id,
                    "candidate_name": interview.full_name,
                    "candidate_phone": interview.phone,
                    "status": interview.status,
                    "tab_switch_count": interview.tab_switch_count
                })
            
            return {
                "success": True,
                "total_interviews": len(interviews_list),
                "interviews": interviews_list
            }
            
        except Exception as e:
            return {"success": False, "message": f"Error retrieving interviews: {str(e)}"}
        finally:
            session.close()