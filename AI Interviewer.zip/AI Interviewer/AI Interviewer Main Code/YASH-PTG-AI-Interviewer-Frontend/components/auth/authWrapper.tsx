"use client";

import { useEffect, useState } from "react";
import { useKeycloak } from "@/context/keycloakContext";

interface AuthWrapperProps {
  children: React.ReactNode;
}

export default function AuthWrapper({ children }: AuthWrapperProps) {
  const { keycloak, initialized } = useKeycloak();
  const [isAuthenticating, setIsAuthenticating] = useState(true);

  useEffect(() => {
    if (initialized && keycloak) {
      if (!keycloak.authenticated) {
        // Only redirect if we haven't already started authentication
        if (!sessionStorage.getItem("keycloak-auth-attempted")) {
          sessionStorage.setItem("keycloak-auth-attempted", "true");
          keycloak.login();
        }
      } else {
        // User is authenticated, load profile and store data
        loadUserData();
        setIsAuthenticating(false);
      }
    }
  }, [keycloak, initialized]);

  const loadUserData = async () => {
    if (!keycloak) return;

    try {
      // Store access token
      if (keycloak.token) {
        localStorage.setItem("accessToken", keycloak.token);
      }

      // Load user profile
      const profile = await keycloak.loadUserProfile();
      localStorage.setItem("user_id", profile.id || "");
      localStorage.setItem("user_email", profile.email || "");
      localStorage.setItem("user_name", profile.firstName || "");

      // Parse token for roles
      if (keycloak.token) {
        const tokenParts = keycloak.token.split(".");
        if (tokenParts.length === 3) {
          try {
            const payload = JSON.parse(atob(tokenParts[1]));
            const realmRoles = payload.realm_access?.roles || [];
            const clientRoles =
              payload.resource_access?.["your-client-id"]?.roles || [];

            localStorage.setItem(
              "user_roles",
              JSON.stringify({
                realmRoles,
                clientRoles,
              })
            );
          } catch (e) {
            console.error("Error parsing token for roles:", e);
          }
        }
      }

      // Clear the auth attempt flag on successful authentication
      sessionStorage.removeItem("keycloak-auth-attempted");
    } catch (error) {
      console.error("Failed to load user data:", error);
      setIsAuthenticating(false);
    }
  };

  // Show loading while initializing or authenticating
  if (!initialized || isAuthenticating) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-lg">Loading...</p>
      </div>
    );
  }

  // Show redirecting message if not authenticated
  if (!keycloak?.authenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-lg">Redirecting to login...</p>
      </div>
    );
  }

  return <>{children}</>;
}
