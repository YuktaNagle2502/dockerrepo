"use client";

import * as React from "react";
import { Label, Pie, PieChart } from "recharts";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";

// Define the type for the input data
interface EngagementData {
  Timestamp: string;
  Status: string;
  Engaged_Frames: number;
  Disengaged_Frames: number;
}

// Define the props interface
interface EngagementPieChartProps {
  data: EngagementData[];
}

export function EngagementPieChart({ data }: EngagementPieChartProps) {
  // Aggregate engagement data
  const engagedFrames = data.reduce(
    (acc, item) => acc + item.Engaged_Frames,
    0
  );
  const disengagedFrames = data.reduce(
    (acc, item) => acc + item.Disengaged_Frames,
    0
  );
  const totalFrames = engagedFrames + disengagedFrames;

  // Prepare chart data
  const chartData = [
    { status: "Engaged", value: engagedFrames, fill: "var(--color-engaged)" },
    {
      status: "Disengaged",
      value: disengagedFrames,
      fill: "var(--color-disengaged)",
    },
  ];

  const chartConfig: ChartConfig = {
    engaged: {
      label: "Engaged",
      color: "hsl(var(--chart-1))",
    },
    disengaged: {
      label: "Disengaged",
      color: "hsl(var(--chart-2))",
    },
  };

  // Calculate engagement percentage
  const engagementPercentage =
    totalFrames > 0 ? ((engagedFrames / totalFrames) * 100).toFixed(1) : "0.0";

  return (
    <Card className="w-full h-full ">
      <CardHeader>
        <CardTitle>Engagement Analysis</CardTitle>
        <CardDescription>Tracked Engagement Frames</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col items-center gap-1">
        <ChartContainer
          config={chartConfig}
          className="w-full max-w-[250px] aspect-square"
        >
          <PieChart>
            <ChartTooltip
              cursor={false}
              content={<ChartTooltipContent hideLabel />}
            />
            <Pie
              data={chartData}
              dataKey="value"
              nameKey="status"
              innerRadius={60}
              outerRadius={80}
            >
              <Label
                content={({ viewBox }) => {
                  if (viewBox && "cx" in viewBox && "cy" in viewBox) {
                    return (
                      <text
                        x={viewBox.cx}
                        y={viewBox.cy}
                        textAnchor="middle"
                        dominantBaseline="middle"
                      >
                        <tspan
                          x={viewBox.cx}
                          y={viewBox.cy}
                          className="fill-foreground text-3xl font-bold"
                        >
                          {engagedFrames.toLocaleString()}
                        </tspan>
                        <tspan
                          x={viewBox.cx}
                          y={(viewBox.cy || 0) + 24}
                          className="fill-muted-foreground flex-wrap p-4"
                        >
                          Engaged
                        </tspan>
                      </text>
                    );
                  }
                }}
              />
            </Pie>
          </PieChart>
        </ChartContainer>
      </CardContent>

      <CardFooter>
        <div className="grid w-full grid-cols-2 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold">{engagementPercentage}%</div>
            <div className="text-xs text-muted-foreground">Engagement</div>
          </div>
          <div>
            <div className="text-2xl font-bold">{totalFrames}</div>
            <div className="text-xs text-muted-foreground">Total Frames</div>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
}
