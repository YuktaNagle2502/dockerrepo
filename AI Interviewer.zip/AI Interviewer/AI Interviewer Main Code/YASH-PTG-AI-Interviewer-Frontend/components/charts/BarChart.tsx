"use client"

import React from 'react'
import { TrendingUp } from "lucide-react"
import { Bar, BarChart, CartesianGrid, XAxis } from "recharts"

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"

interface BarCompProps {
  data: Array<{
    Timestamp: string,
    Status: string,
    Engaged_Frames: number,
    Disengaged_Frames: number
  }>
}

export function BarComp({ data }: BarCompProps) {
  // Transform data for chart
  const chartData = data.slice(-6).map((entry, index) => ({
    timestamp: entry.Timestamp.split(' ')[1], // Use time
    engaged: entry.Engaged_Frames,
    disengaged: entry.Disengaged_Frames
  }));

  const chartConfig = {
    engaged: {
      label: "Engaged Frames",
      color: "hsl(var(--chart-1))",
    },
    disengaged: {
      label: "Disengaged Frames",
      color: "hsl(var(--chart-2))",
    },
  } satisfies ChartConfig

  return (
    <Card className="w-full h-full">
      <CardHeader className=''>
        <CardTitle>Frame Engagement Analysis</CardTitle>
        <CardDescription>Detailed Engagement Breakdown</CardDescription>
      </CardHeader>
      <CardContent className='mt-12'>
        <ChartContainer config={chartConfig}>
          <BarChart accessibilityLayer data={chartData}>
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="timestamp"
              tickLine={false}
              tickMargin={10}
              axisLine={false}
            />
            <ChartTooltip
              cursor={false}
              content={<ChartTooltipContent indicator="dashed" />}
            />
            <Bar dataKey="engaged" fill="var(--color-engaged)" radius={4} />
            <Bar dataKey="disengaged" fill="var(--color-disengaged)" radius={4} />
          </BarChart>
        </ChartContainer>
      </CardContent>
      <CardFooter className="flex-col items-start gap-2 text-sm mt-16">
        <div className="flex gap-2 font-medium leading-none">
          Engagement Analysis <TrendingUp className="h-4 w-4" />
        </div> 
        <div className="leading-none text-muted-foreground">
          Showing frame engagement over time
        </div>
      </CardFooter>
    </Card>
  )
}