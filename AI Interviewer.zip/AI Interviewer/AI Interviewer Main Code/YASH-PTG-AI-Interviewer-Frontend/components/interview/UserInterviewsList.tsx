import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Search,
  Trash2,
  AlertCircle,
  Video,
  Download,
  Copy,
  ExternalLink,
  Loader2,
  Eye,
  X,
  ChevronLeft,
  ChevronRight,
  FileText,
  FileUser,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { authFetch } from "@/lib/authFetch";

interface Interview {
  id: number;
  unique_id: string;
  user_image_path: string;
  user_image_url: string;
  url: string;
  status: "pending" | "scheduled" | "completed" | "cancelled";
  scheduled_at: string;
  candidate_name: string;
  candidate_phone: string;
  recording_url: string[];
  job_title: string; // <-- Add this line
}

interface RecordingFile {
  name: string;
  size: number;
  size_mb: number;
  last_modified: string;
  url: string;
  type: string;
}

interface ResumeResponse {
  resume_url: string;
  blob_name: string;
  expiry_hours: number;
  unique_id: string;
}

export const UserInterviewsList = () => {
  const router = useRouter();
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [jobTitleSearchTerm, setJobTitleSearchTerm] = useState("");
  const [recordingsLoading, setRecordingsLoading] = useState<string | null>(
    null
  );
  const [recordings, setRecordings] = useState<RecordingFile[]>([]);
  const [selectedInterviewId, setSelectedInterviewId] = useState<string | null>(
    null
  );
  const [downloadingRecording, setDownloadingRecording] = useState<
    string | null
  >(null);
  const [resumeLoading, setResumeLoading] = useState<string | null>(null);
const [resumeModalUrl, setResumeModalUrl] = useState<string | null>(null);


  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const { toast } = useToast();

  const fetchInterviews = async () => {
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/get_interviews`
      );
      if (!response.ok) throw new Error("Failed to fetch interviews");
      const data = await response.json();
      setInterviews(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch interviews",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchResume = async (uniqueId: string) => {
  try {
    setResumeLoading(uniqueId);

    const response = await authFetch(
      `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/generate_resume_url/${uniqueId}`
    );
  console.log("Resume fetch response:", response);
    if (!response.ok) {
      throw new Error("Failed to fetch resume URL");
    }

    const data: ResumeResponse = await response.json();

    if (data.resume_url) {
      setResumeModalUrl(data.resume_url); // Open modal with resume URL
    } else {
      throw new Error("Resume URL not found in response");
    }
  } catch (error) {
    toast({
      title: "Error",
      description:
        error instanceof Error ? error.message : "Failed to fetch resume",
      variant: "destructive",
    });
  } finally {
    setResumeLoading(null);
  }
};


  const fetchRecordings = async (uniqueId: string) => {
    try {
      setRecordingsLoading(uniqueId);
      setSelectedInterviewId(uniqueId);

      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/get_interview_recordings_url/${uniqueId}`
      );

      if (!response.ok) throw new Error("Failed to fetch interview details");

      const data = await response.json();
      console.log("Fetched recordings data:", data);

      // Convert recording_urls to RecordingFile format
      const userRecordings: RecordingFile[] = (data.recording_urls || []).map(
        (url: string, index: number) => ({
          name: `recording_${uniqueId}_${index + 1}.webm`,
          size: 0,
          size_mb: 0,
          last_modified: data.scheduled_at,
          url,
          type: "combined",
        })
      );

      setRecordings(userRecordings);

      if (userRecordings.length === 0) {
        toast({
          title: "No Recordings Found",
          description: `No recordings found for interview session ${uniqueId}`,
          variant: "default",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch recordings",
        variant: "destructive",
      });
      setRecordings([]);
    } finally {
      setRecordingsLoading(null);
    }
  };

  // New function to get presigned URL and download
  // Updated handleDownloadWithPresignedUrl function with debugging
  const handleDownloadWithPresignedUrl = async (
    uniqueId: string,
    filename: string
  ) => {
    try {
      setDownloadingRecording(filename);
      setDownloadProgress(0); // Reset progress
      console.log("Getting download URL for:", uniqueId);

      // Get download URL from backend
      const apiUrl = `${process.env.NEXT_PUBLIC_BACKEND_URL}/recording/download-url/${uniqueId}`;
      const response = await authFetch(apiUrl);

      console.log("Response status:", response.status);

      if (!response.ok) {
        let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
        try {
          const errorData = await response.json();
          console.log("Error response:", errorData);
          errorMessage = errorData.detail || errorData.message || errorMessage;
        } catch (e) {
          console.log("Could not parse error response");
        }
        throw new Error(errorMessage);
      }

      const data = await response.json();
      console.log("Download URL response:", data);

      if (!data.download_url) {
        throw new Error("Download URL not found in response");
      }
      console.log("Download URL:", data.download_url);

      // Download the file using the provided URL with progress
      console.log("Downloading file from:", data.download_url);
      const fileResponse = await fetch(data.download_url);

      if (!fileResponse.ok) {
        throw new Error(
          `File download failed: ${fileResponse.status} ${fileResponse.statusText}`
        );
      }

      // Stream the response and track progress
      const contentLength =
        Number(fileResponse.headers.get("Content-Length")) || 0;
      const reader = fileResponse.body?.getReader();
      const chunks: Uint8Array[] = [];
      let receivedLength = 0;

      while (reader) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          chunks.push(value);
          receivedLength += value.length;
          if (contentLength) {
            setDownloadProgress(
              Math.round((receivedLength / contentLength) * 100)
            );
          }
        }
      }

      const blob = new Blob(chunks);
      console.log("Downloaded blob size:", blob.size);

      const downloadFilename = data.filename || filename;

      // Create download link and trigger download
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = downloadFilename;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      window.URL.revokeObjectURL(url);

      toast({
        title: "Download Completed",
        description: `Downloaded ${downloadFilename} (${data.file_size_mb} MB)`,
      });

      setDownloadProgress(100); // Ensure progress is 100% at end

      console.log("Download completed successfully");
    } catch (error) {
      console.error("Download error:", error);
      toast({
        title: "Download Failed",
        description:
          error instanceof Error
            ? error.message
            : "Failed to download recording",
        variant: "destructive",
      });
      setDownloadProgress(0);
    } finally {
      setDownloadingRecording(null);
      setTimeout(() => setDownloadProgress(0), 2000); // Hide progress after short delay
    }
  };

  const handleCancelInterview = async (uniqueId: string) => {
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/cancel_interview/${uniqueId}`,
        {
          method: "DELETE",
        }
      );

      if (!response.ok) throw new Error("Failed to cancel interview");

      setInterviews((prevInterviews) =>
        prevInterviews.map((interview) =>
          interview.unique_id === uniqueId
            ? { ...interview, status: "cancelled" as const }
            : interview
        )
      );

      toast({
        title: "Success",
        description: "Interview cancelled successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to cancel interview",
        variant: "destructive",
      });
    }
  };

  // Keep the original download function as fallback
  const handleDownloadRecording = (url: string, filename: string) => {
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.target = "_blank";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatFileSize = (sizeInMB: number) => {
    if (sizeInMB < 1) {
      return `${(sizeInMB * 1024).toFixed(0)} KB`;
    }
    return `${sizeInMB.toFixed(2)} MB`;
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  useEffect(() => {
    fetchInterviews();
  }, []);

  // Reset to first page when search term changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);

  const filteredInterviews = interviews.filter(
    (interview) =>
      interview.candidate_name
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) &&
      (jobTitleSearchTerm === "" ||
        (interview.job_title &&
          interview.job_title
            .toLowerCase()
            .includes(jobTitleSearchTerm.toLowerCase())))
  );

  // Pagination calculations
  const totalPages = Math.ceil(filteredInterviews.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedInterviews = filteredInterviews.slice(startIndex, endIndex);

  // Pagination handlers
  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <TooltipProvider>
      <Card className="w-full bg-transparent border-0 shadow-none">
        <CardHeader>
          <CardTitle>Scheduled Interviews</CardTitle>
          <CardDescription>
            View and manage all scheduled interviews
          </CardDescription>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by candidate name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by job title..."
                value={jobTitleSearchTerm}
                onChange={(e) => setJobTitleSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="max-h-[600px] overflow-y-auto">
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="text-center space-y-2">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                    <p className="text-gray-500 dark:text-gray-300">
                      Loading...
                    </p>
                  </div>
                </div>
              ) : (
                <Table>
                  <TableHeader className="sticky top-0 bg-background z-10 border-b">
                    <TableRow>
                      <TableHead className="bg-background">Candidate</TableHead>
                      <TableHead className="bg-background">Contact</TableHead>
                      <TableHead className="bg-background">Status</TableHead>
                      <TableHead className="bg-background">
                        Scheduled Date
                      </TableHead>
                      <TableHead className="">Resume</TableHead>
                      <TableHead className="bg-background">Actions</TableHead>
                      <TableHead className="bg-background">Summary</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedInterviews.length === 0 ? (
                      <TableRow>
                        <TableCell
                          colSpan={7}
                          className="text-center py-8 text-muted-foreground"
                        >
                          {searchTerm
                            ? "No interviews found matching your search."
                            : "No interviews found."}
                        </TableCell>
                      </TableRow>
                    ) : (
                      paginatedInterviews.map((interview) => (
                        <TableRow key={interview.unique_id}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <img
                                src={interview.user_image_url}
                                alt={interview.candidate_name}
                                className="w-8 h-8 rounded-full object-cover"
                              />
                              <span className="font-medium">
                                {interview.candidate_name}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>{interview.candidate_phone}</TableCell>
                          {/* <TableCell>
                          <a
                            href={`interviewer/${interview.unique_id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-500 hover:underline"
                          >
                            View Interview
                          </a>
                        </TableCell> */}
                          <TableCell>
                            <span
                              className={`px-2 py-1 rounded-full text-sm ${
                                interview.status === "completed"
                                  ? "bg-green-100 text-green-800"
                                  : interview.status === "cancelled"
                                  ? "bg-red-100 text-red-800"
                                  : interview.status === "pending"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-blue-100 text-blue-800"
                              }`}
                            >
                              {interview.status.charAt(0).toUpperCase() +
                                interview.status.slice(1)}
                            </span>
                          </TableCell>
                          <TableCell>
                            {new Date(interview.scheduled_at).toLocaleString()}
                          </TableCell>
                          <TableCell className="p-2">
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="w-10 h-10 p-0"
                                  onClick={() =>
                                    fetchResume(interview.unique_id)
                                  }
                                  disabled={
                                    resumeLoading === interview.unique_id
                                  }
                                >
                                  {resumeLoading === interview.unique_id ? (
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                  ) : (
                                    <Download className="w-4 h-4" />
                                  )}
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>View Resume</p>
                              </TooltipContent>
                            </Tooltip>
                          </TableCell>
                          <TableCell className="p-0">
                            <div className="flex gap-2 p-2">
                              {/* View Stats Button */}
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="w-10 h-10 p-0"
                                    disabled={interview.status !== "completed"}
                                    onClick={() =>
                                      window.open(
                                        `/userstats/${interview.unique_id}`,
                                        "_blank"
                                      )
                                    }
                                  >
                                    <Eye className="w-4 h-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>View Analytics</p>
                                </TooltipContent>
                              </Tooltip>

                              {/* Recordings Button with Dialog */}
                              <Dialog>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <DialogTrigger asChild>
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="w-10 h-10 p-0"
                                        disabled={
                                          interview.status !== "completed"
                                        }
                                        onClick={() =>
                                          fetchRecordings(interview.unique_id)
                                        }
                                      >
                                        {recordingsLoading ===
                                        interview.unique_id ? (
                                          <Loader2 className="w-4 h-4 animate-spin" />
                                        ) : (
                                          <Video className="w-4 h-4" />
                                        )}
                                      </Button>
                                    </DialogTrigger>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>View Recordings</p>
                                  </TooltipContent>
                                </Tooltip>
                                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                                  <DialogHeader>
                                    <DialogTitle className="flex items-center gap-2">
                                      <Video className="w-5 h-5 text-blue-500" />
                                      Interview Recordings -{" "}
                                      {interview.candidate_name}
                                    </DialogTitle>
                                    <DialogDescription>
                                      Session ID: {interview.unique_id}
                                    </DialogDescription>
                                  </DialogHeader>

                                  <div className="mt-4">
                                    {recordingsLoading ===
                                    interview.unique_id ? (
                                      <div className="flex justify-center items-center p-8">
                                        <Loader2 className="w-8 h-8 animate-spin" />
                                        <span className="ml-2">
                                          Loading recordings...
                                        </span>
                                      </div>
                                    ) : recordings.length === 0 ? (
                                      <div className="text-center p-8 text-gray-500">
                                        <Video className="w-12 h-12 mx-auto mb-4 opacity-50" />
                                        <p>
                                          No recordings found for this interview
                                          session.
                                        </p>
                                        <p className="text-sm mt-2">
                                          Recordings are only available for
                                          completed interviews.
                                        </p>
                                      </div>
                                    ) : (
                                      <div className="space-y-4">
                                        {/* <div className="text-sm text-gray-600 mb-4">
                                      Found {recordings.length} recording(s) • Total size: {formatFileSize(recordings.reduce((sum, rec) => sum + rec.size_mb, 0))}
                                    </div> */}

                                        {recordings.map((recording, index) => (
                                          <div
                                            key={index}
                                            className="border rounded-lg p-4 hover:bg-muted/50 transition-colors"
                                          >
                                            <div className="flex items-center justify-between">
                                              <div className="flex-1">
                                                <div className="flex items-center gap-2 mb-2">
                                                  <Video className="w-4 h-4 text-blue-500" />
                                                  <span className="font-medium text-sm">
                                                    {recording.name}
                                                  </span>
                                                  <Button
                                                    variant="outline"
                                                    size="sm"
                                                    onClick={() =>
                                                      handleDownloadWithPresignedUrl(
                                                        interview.unique_id,
                                                        recording.name
                                                      )
                                                    }
                                                    disabled={
                                                      downloadingRecording ===
                                                      recording.name
                                                    }
                                                    className="flex items-center gap-1"
                                                  >
                                                    {downloadingRecording ===
                                                    recording.name ? (
                                                      <Loader2 className="w-3 h-3 animate-spin" />
                                                    ) : (
                                                      <Download className="w-3 h-3" />
                                                    )}
                                                    Download
                                                  </Button>
                                                  {/* <span className={`px-2 py-1 rounded-full text-xs ${
                                                recording.type === 'combined'
                                                  ? 'bg-green-100 text-green-800'
                                                  : recording.type === 'camera'
                                                  ? 'bg-blue-100 text-blue-800'
                                                  : 'bg-purple-100 text-purple-800'
                                              }`}>
                                                {recording.type.charAt(0).toUpperCase() + recording.type.slice(1)}
                                              </span> */}

                                                  {downloadingRecording &&
                                                    downloadProgress > 0 && (
                                                      <div className="w-full mb-4">
                                                        <div className="flex items-center gap-2">
                                                          <span className="text-xs text-muted-foreground">
                                                            Downloading:{" "}
                                                            {
                                                              downloadingRecording
                                                            }
                                                          </span>
                                                          <span className="text-xs">
                                                            {downloadProgress}%
                                                          </span>
                                                        </div>
                                                        <div className="w-full bg-gray-200 rounded h-2 mt-1">
                                                          <div
                                                            className="bg-blue-500 h-2 rounded"
                                                            style={{
                                                              width: `${downloadProgress}%`,
                                                            }}
                                                          ></div>
                                                        </div>
                                                      </div>
                                                    )}
                                                </div>
                                                <div className="text-sm text-gray-600 space-y-1">
                                                  {/* <div>Size: {formatFileSize(recording.size_mb)}</div>
                                              <div>Modified: {formatDateTime(recording.last_modified)}</div> */}
                                                </div>
                                              </div>
                                              <div className="flex gap-2 ml-4">
                                                {/* <Button
                                              variant="outline"
                                              size="sm"
                                              onClick={() => window.open(recording.url, '_blank')}
                                              className="flex items-center gap-1"
                                            >
                                              <ExternalLink className="w-3 h-3" />
                                              View
                                            </Button> */}
                                                {/* <Button
                                              variant="outline"
                                              size="sm"
                                              onClick={() => handleDownloadWithPresignedUrl(interview.unique_id, recording.name)}
                                              disabled={downloadingRecording === recording.name}
                                              className="flex items-center gap-1"
                                            >
                                              {downloadingRecording === recording.name ? (
                                                <Loader2 className="w-3 h-3 animate-spin" />
                                              ) : (
                                                <Download className="w-3 h-3" />
                                              )}
                                              Download
                                            </Button> */}
                                              </div>
                                            </div>
                                          </div>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                </DialogContent>
                              </Dialog>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="w-10 h-10 p-0"
                                    onClick={async () => {
                                      const link = `${window.location.origin}/interviewer/${interview.unique_id}`;
                                      await navigator.clipboard.writeText(link);
                                      toast({
                                        title: "Link Copied",
                                        description:
                                          "Interview link copied to clipboard.",
                                      });
                                    }}
                                  >
                                    <Copy className="w-4 h-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Copy Link</p>
                                </TooltipContent>
                              </Tooltip>
                              {/* Cancel Button */}
                              <Dialog>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <DialogTrigger asChild>
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="w-10 h-10 p-0"
                                        disabled={
                                          interview.status !== "scheduled" &&
                                          interview.status !== "pending"
                                        }
                                      >
                                        <X className="w-4 h-4 text-red-500" />
                                      </Button>
                                    </DialogTrigger>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>Cancel Interview</p>
                                  </TooltipContent>
                                </Tooltip>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle className="flex items-center gap-2">
                                      <AlertCircle className="w-5 h-5 text-destructive" />
                                      Confirm Cancellation
                                    </DialogTitle>
                                    <DialogDescription>
                                      Are you sure you want to cancel the
                                      interview with {interview.candidate_name}?
                                      This action cannot be undone.
                                    </DialogDescription>
                                  </DialogHeader>
                                  <div className="flex justify-end gap-2">
                                    <DialogClose asChild>
                                      <Button variant="outline">
                                        No, keep it
                                      </Button>
                                    </DialogClose>
                                    <DialogClose asChild>
                                      <Button
                                        variant="destructive"
                                        onClick={() =>
                                          handleCancelInterview(
                                            interview.unique_id
                                          )
                                        }
                                      >
                                        Yes, cancel it
                                      </Button>
                                    </DialogClose>
                                  </div>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </TableCell>
                           <TableCell className="p-0">
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="w-10 h-10 p-0"
                                    // disabled={interview.status !== "completed"}
                                    onClick={() =>
                                      window.open(
                                        `/interview_summary/${interview.unique_id}`,
                                        "_blank"
                                      )
                                    }
                                  >
                                    <FileUser className="w-4 h-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Summary</p>
                                </TooltipContent>
                              </Tooltip>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              )}
            </div>
          </div>

          {/* Pagination Controls */}
          {!loading && filteredInterviews.length > 0 && (
            <div className="flex items-center justify-between space-x-2 py-4">
              <div className="text-sm text-muted-foreground">
                Showing {startIndex + 1} to{" "}
                {Math.min(endIndex, filteredInterviews.length)} of{" "}
                {filteredInterviews.length} interviews
              </div>

              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={goToPreviousPage}
                  disabled={currentPage === 1}
                  className="flex items-center gap-1"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </Button>

                {/* Page Numbers */}
                <div className="flex items-center space-x-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                    (page) => {
                      // Show first page, last page, current page, and pages around current page
                      const showPage =
                        page === 1 ||
                        page === totalPages ||
                        (page >= currentPage - 1 && page <= currentPage + 1);

                      if (!showPage && page === 2 && currentPage > 4) {
                        return (
                          <span
                            key={page}
                            className="px-2 text-muted-foreground"
                          >
                            ...
                          </span>
                        );
                      }

                      if (
                        !showPage &&
                        page === totalPages - 1 &&
                        currentPage < totalPages - 3
                      ) {
                        return (
                          <span
                            key={page}
                            className="px-2 text-muted-foreground"
                          >
                            ...
                          </span>
                        );
                      }

                      if (!showPage) return null;

                      return (
                        <Button
                          key={page}
                          variant={currentPage === page ? "default" : "outline"}
                          size="sm"
                          onClick={() => goToPage(page)}
                          className="w-8 h-8 p-0"
                        >
                          {page}
                        </Button>
                      );
                    }
                  )}
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={goToNextPage}
                  disabled={currentPage === totalPages}
                  className="flex items-center gap-1"
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
<Dialog open={!!resumeModalUrl} onOpenChange={(open) => !open && setResumeModalUrl(null)}>
  <DialogContent className="max-w-3xl h-[80vh] flex flex-col">
    <DialogHeader>
      <DialogTitle>Resume Preview</DialogTitle>
    </DialogHeader>
    {resumeModalUrl ? (
      <iframe
        src={resumeModalUrl}
        title="Resume PDF"
        className="flex-1 w-full h-full border rounded"
        style={{ minHeight: "70vh" }}
      />
    ) : (
      <div>Loading...</div>
    )}
  </DialogContent>
</Dialog>
    </TooltipProvider>
  );
};

export default UserInterviewsList;
