//new logic

'use client';

import React, { useState, useEffect, useRef } from 'react';

interface TranscriptionProps {
  apiKey: string;
}

const LiveTranscription: React.FC<TranscriptionProps> = ({ apiKey }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState('');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const webSocketRef = useRef<WebSocket | null>(null);
  const lastActivityRef = useRef<number>(Date.now());
  const silenceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isSpeakingRef = useRef<boolean>(false);
  const speechEndTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const stopRecording = () => {
    console.log('Stopping recording...');
    
    // Clear all timeouts
    if (silenceTimeoutRef.current) {
      clearTimeout(silenceTimeoutRef.current);
      silenceTimeoutRef.current = null;
    }
    if (speechEndTimeoutRef.current) {
      clearTimeout(speechEndTimeoutRef.current);
      speechEndTimeoutRef.current = null;
    }

    // Stop media recorder
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
        mediaRecorderRef.current.stream.getTracks().forEach(track => {
          track.stop();
          track.enabled = false;
        });
      } catch (err) {
        console.error('Error stopping media recorder:', err);
      }
    }

    // Close WebSocket
    if (webSocketRef.current && webSocketRef.current.readyState === WebSocket.OPEN) {
      webSocketRef.current.close();
    }

    setIsRecording(false);
    setIsConnected(false);
    isSpeakingRef.current = false;
  };

  const checkForSilence = () => {
    const now = Date.now();
    const timeSinceLastActivity = now - lastActivityRef.current;
    console.log('Time since last activity:', timeSinceLastActivity);
    
    if (timeSinceLastActivity > 1000) { // 1 second of silence
      console.log('Silence detected, stopping recording');
      stopRecording();
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });

      if (!MediaRecorder.isTypeSupported('audio/webm')) {
        setError('Browser not supported');
        return;
      }

      // Create WebSocket URL with specific parameters
      const wsUrl = new URL('wss://api.deepgram.com/v1/listen');
      wsUrl.searchParams.append('endpointing', 'true');
      wsUrl.searchParams.append('vad', 'true');
      wsUrl.searchParams.append('vad_turnoff', '500');
      wsUrl.searchParams.append('punctuate', 'true');
      wsUrl.searchParams.append('interim_results', 'true');
      wsUrl.searchParams.append('utterance_end_ms', '2000');

      const socket = new WebSocket(wsUrl.toString(), [
        'token',
        apiKey
      ]);

      webSocketRef.current = socket;

      socket.onopen = () => {
        setIsConnected(true);
        console.log('WebSocket Connected');

        const mediaRecorder = new MediaRecorder(stream, {
          mimeType: 'audio/webm'
        });

        mediaRecorderRef.current = mediaRecorder;

        let chunks: BlobPart[] = [];
        mediaRecorder.addEventListener('dataavailable', async (event) => {
          if (event.data.size > 0 && socket.readyState === WebSocket.OPEN) {
            chunks.push(event.data);
            const blob = new Blob(chunks, { type: 'audio/webm' });
            socket.send(blob);
            chunks = [];
            
            lastActivityRef.current = Date.now();
            
            // Reset silence detection timer
            if (silenceTimeoutRef.current) {
              clearTimeout(silenceTimeoutRef.current);
            }
            silenceTimeoutRef.current = setTimeout(checkForSilence, 1000);
          }
        });

        mediaRecorder.start(250);
        setIsRecording(true);
        isSpeakingRef.current = false;
        lastActivityRef.current = Date.now();
      };

      socket.onmessage = (message) => {
        try {
          const received = JSON.parse(message.data);
          console.log('Received message:', received);
          if (received.type==='UtteranceEnd'){
            console.log("utterence reached")
            stopRecording()
          }

          // Handle speech events
          if (received.type === 'Metadata') {
            console.log('Metadata event:', received.event);
            if (received.event === 'SpeechStarted') {
              console.log('Speech started');
              isSpeakingRef.current = true;
              lastActivityRef.current = Date.now();
              
              // Clear speech end timeout if it exists
              if (speechEndTimeoutRef.current) {
                clearTimeout(speechEndTimeoutRef.current);
                speechEndTimeoutRef.current = null;
              }
            } else if (received.event === 'SpeechEnded') {
              console.log('Speech ended');
              isSpeakingRef.current = false;
              
              // Set a timeout to stop recording if no new speech starts
              speechEndTimeoutRef.current = setTimeout(() => {
                if (!isSpeakingRef.current) {
                  console.log('No new speech detected after end, stopping');
                  stopRecording();
                }
              }, 1000);
            }
            return;
          }

          const transcript = received.channel?.alternatives?.[0]?.transcript;
          
          if (transcript) {
            lastActivityRef.current = Date.now();
            
            if (received.is_final) {
              console.log('Final transcript:', transcript);
              setTranscription(prev => prev + transcript + ' ');
              
              // If this is marked as speech_final, prepare to stop
            //   if (received.speech_final) {
            //     console.log('Speech final received');
            //     setTimeout(() => {
            //       if (!isSpeakingRef.current) {
            //         stopRecording();
            //       }
            //     }, 1000);
            //   }
            }
          }

        } catch (err) {
          console.error('Error processing message:', err);
        }
      };

      socket.onclose = () => {
        console.log('WebSocket Disconnected');
        setIsConnected(false);
      };

      socket.onerror = (error) => {
        console.error('WebSocket Error:', error);
        setError('Connection error occurred');
        stopRecording();
      };

    } catch (err) {
      console.error('Error starting recording:', err);
      setError('Failed to start recording');
    }
  };

  useEffect(() => {
    return () => {
      stopRecording();
    };
  }, []);

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <div className="mb-4 space-y-4">
        <div className="flex flex-col items-center gap-4">
          <button
            onClick={isRecording ? stopRecording : startRecording}
            className={`px-6 py-3 rounded-lg ${
              isRecording 
                ? 'bg-red-500 hover:bg-red-600' 
                : 'bg-blue-500 hover:bg-blue-600'
            } text-white font-medium text-lg transition-colors`}
          >
            {isRecording ? 'Stop Recording' : 'Start Recording'}
          </button>

          <div className="text-sm text-gray-500">
            Status: {isConnected ? 'Connected' : 'Not Connected'} | 
            {isRecording ? ' Recording...' : ' Not Recording'}
          </div>
        </div>

        {error && (
          <div className="text-red-500 font-medium text-center">
            {error}
          </div>
        )}

        <div className="p-6 bg-gray-100 rounded-lg min-h-[200px] shadow-inner">
          <h3 className="font-medium mb-3 text-gray-700">Transcription:</h3>
          <p className="whitespace-pre-wrap text-gray-800 leading-relaxed">
            {transcription || 'Start recording to see transcription...'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default LiveTranscription;