import React, { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, Monitor, ArrowLeftRight, Upload, CheckCircle, Clock, HardDrive, AlertTriangle, X, Minimize2, Eye } from "lucide-react";
import Question from "@/components/question/Question";
import { useInterviewStore } from "@/stores/interview-store";
import { useDirectRecording } from "@/hooks/useDirectS3Upload";
import { useTabSwitchingDetection } from "@/hooks/useTabSwitchingDetection";

interface InterviewRulesPageProps {
  interviewId: string;
}

const InterviewRulesPage: React.FC<InterviewRulesPageProps> = ({
  interviewId,
}) => {
  const [isagreed, setisagreed] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [targetFPS] = useState(5);
  const [isInterviewOver, setIsInterviewOver] = useState(false);
  const [questionAnswer, setQuestionAnswer] = useState([
    {
      question: "What is react",
      reference_answer: "I know the answer",
      user_answer: "i dont know the answer",
      ai_comment: "This is a comment from AI",
    },
  ]);
  const [isScreenShareActive, setIsScreenShareActive] = useState(false);
  const [screenPermissionDenied, setScreenPermissionDenied] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [isCameraLeft, setIsCameraLeft] = useState(true);
  const [screenRecordingReady, setScreenRecordingReady] = useState(false);

  // Enhanced tab switching warning states
  const [showTabSwitchWarning, setShowTabSwitchWarning] = useState(false);
  const [tabSwitchCount, setTabSwitchCount] = useState(0);
  const [lastSwitchType, setLastSwitchType] = useState('tab_switch'); // 'tab_switch', 'minimization', 'window_blur'
  const previousTabStateRef = useRef(true);
  const previousWindowFocusRef = useRef(true);
 
  // Use enhanced hook
  const {
    isRecording,
    isUploading,
    uploadProgress,
    error: recordingError,
    totalChunks,
    totalSizeMB,
    recordingDurationMinutes,
    startRecording,
    stopRecordingAndUpload,
    cleanup,
    canStartRecording,
    canStopRecording,
    hasRecordedData,
    memoryUsageMB
  } = useDirectRecording(interviewId);

  const combinedStreamRef = useRef<MediaStream | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const screenVideoRef = useRef<HTMLVideoElement>(null);
  const gumVideoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameExtractionRef = useRef<number | null>(null);
  const webSocketRef = useRef<WebSocket | null>(null);
  const lastFrameTimeRef = useRef<number>(0);
  const isMountedRef = useRef(true);
  const cleanupCompleteRef = useRef(false);

  const { interviewQuestions } = useInterviewStore();

  const interviewRules = [
    "Please ensure you are in a quiet, well-lit environment",
    "Check your internet connection and audio/video settings",
    "Close all other applications and browser tabs",
    "Have a pen and paper ready for any notes",
    "Dress professionally as you would for an in-person interview",
    "Be prepared to join the interview 10 minutes before the scheduled time",
    "You must allow screen sharing of your entire screen for interview monitoring",
    "Screen sharing of individual windows or browser tabs is not permitted",
    "Your interview will be recorded and stored securely in the cloud",
    // "Do not minimize the browser window or switch to other applications during the interview",
  ];
 
  // Tab switching detection
  const { isTabActive, captureScreenshot, reportTabSwitch } = useTabSwitchingDetection(
    interviewId,
    isagreed && !isInterviewOver && isScreenShareActive && isCameraActive
  );
 
  // Enhanced monitoring for tab switching and window focus
  useEffect(() => {
    if (!isagreed || isInterviewOver || !isScreenShareActive || !isCameraActive) return;
 
    const handleVisibilityChange = () => {
      const isCurrentlyVisible = !document.hidden;
      const wasVisible = previousTabStateRef.current;
 
      if (!isCurrentlyVisible && wasVisible) {
        // Tab was hidden - could be tab switch or minimization
        setLastSwitchType('tab_switch');
        setTabSwitchCount(prev => prev + 1);
        setShowTabSwitchWarning(true);
      }
 
      previousTabStateRef.current = isCurrentlyVisible;
    };
 
    const handleWindowBlur = () => {
      const wasWindowFocused = previousWindowFocusRef.current;
     
      if (wasWindowFocused) {
        // Window lost focus - likely minimization or alt+tab
        setLastSwitchType('minimization');
        setTabSwitchCount(prev => prev + 1);
        setShowTabSwitchWarning(true);
      }
     
      previousWindowFocusRef.current = false;
    };
 
    const handleWindowFocus = () => {
      previousWindowFocusRef.current = true;
    };
 
    // Set initial states
    previousTabStateRef.current = !document.hidden;
    previousWindowFocusRef.current = document.hasFocus();
 
    // Add event listeners
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);
 
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }, [isagreed, isInterviewOver,isScreenShareActive, isCameraActive]);
 
  // Enhanced Tab Switch Warning Modal Component
  const TabSwitchWarningModal = () => {
    if (!showTabSwitchWarning) return null;
 
    const getWarningContent = () => {
      switch (lastSwitchType) {
        case 'minimization':
          return {
            title: "Window Minimization Detected!",
            icon: <Minimize2 className="mr-3 h-6 w-6 animate-pulse" />,
            mainMessage: "Do not minimize the browser window during the interview!",
            description: "We detected that you minimized the browser window or switched to another application. This action has been recorded.",
            reminders: [
              "• Keep the interview window open and active",
              "• Do not minimize the browser window",
              "• Do not switch to other applications",
              "• Multiple violations may result in interview termination"
            ]
          };
        case 'tab_switch':
        default:
          return {
            title: "Tab Switching Detected!",
            icon: <AlertTriangle className="mr-3 h-6 w-6 animate-pulse" />,
            mainMessage: "Do not switch tabs during the interview!",
            description: "We detected that you switched away from this interview tab. This action has been recorded.",
            reminders: [
              "• Stay focused on this interview tab",
              "• Do not switch to other browser tabs",
              "• Do not open new tabs or windows",
              "• Multiple violations may affect your interview evaluation"
            ]
          };
      }
    };
 
    const warningContent = getWarningContent();
 
    return (
      <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 backdrop-blur-sm">
        <Card className="w-full max-w-md mx-4 shadow-2xl rounded-2xl bg-white dark:bg-gray-900 border-red-500/20 border-2">
          <CardHeader className="bg-red-50 dark:bg-red-900/20 rounded-t-2xl">
            <CardTitle className="flex items-center text-xl font-semibold text-red-600 dark:text-red-400">
              {warningContent.icon}
              {warningContent.title}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 bg-white dark:bg-gray-900">
            <div className="space-y-4">
              <div className="text-gray-700 dark:text-gray-300">
                <p className="font-medium text-red-600 dark:text-red-400 mb-2">
                  Warning: {warningContent.mainMessage}
                </p>
                <p className="text-sm mb-2">
                  {warningContent.description}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Total violations detected: <span className="font-bold text-red-600">{tabSwitchCount}</span>
                </p>
              </div>
             
              <div className="text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 p-3 rounded-lg border border-red-200 dark:border-red-700">
                <p className="font-semibold mb-1">Important Reminders:</p>
                <ul className="space-y-1">
                  {warningContent.reminders.map((reminder, index) => (
                    <li key={index}>{reminder}</li>
                  ))}
                </ul>
              </div>
 
              <div className="flex justify-center pt-2">
                <Button
                  onClick={() => setShowTabSwitchWarning(false)}
                  className="bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-6 rounded-lg transition-all duration-300"
                >
                  <Eye className="mr-2 h-4 w-4" />
                  I Understand, Resume Interview
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };
 
  const setupFrameExtraction = useCallback(() => {
    const video = gumVideoRef.current;
    const canvas = canvasRef.current;

    if (!video || !canvas || !webSocketRef.current) return null;

    const frameInterval = 1000 / targetFPS;

    const extractAndSendFrame = (timestamp: number) => {
      try {
        if (
          !lastFrameTimeRef.current ||
          timestamp - lastFrameTimeRef.current >= frameInterval
        ) {
          if (
            webSocketRef.current &&
            webSocketRef.current.readyState === WebSocket.OPEN &&
            isMountedRef.current
          ) {
            canvas.width = 640;
            canvas.height = 360;

            const context = canvas.getContext("2d");
            if (!context) {
              console.error("Failed to get 2D context from canvas");
              return;
            }
            context.drawImage(video, 0, 0, canvas.width, canvas.height);

            canvas.toBlob(
              (blob) => {
                if (
                  blob &&
                  webSocketRef.current?.readyState === WebSocket.OPEN &&
                  isMountedRef.current
                ) {
                  blob
                    .arrayBuffer()
                    .then((buffer) => {
                      try {
                        webSocketRef.current?.send(buffer);
                      } catch (sendError) {
                        console.error("Error sending frame via WebSocket:", sendError);
                      }
                    })
                    .catch((bufferError) => {
                      console.error("Error converting blob to array buffer:", bufferError);
                    });
                }
              },
              "image/jpeg",
              0.7
            );

            lastFrameTimeRef.current = timestamp;
          }
        }

        if (isMountedRef.current) {
          frameExtractionRef.current = requestAnimationFrame(extractAndSendFrame);
        }
      } catch (error) {
        console.error("Error during frame extraction:", error);
        if (isMountedRef.current) {
          setErrorMsg(`Frame extraction error: ${String(error)}`);
        }
      }
    };

    frameExtractionRef.current = requestAnimationFrame(extractAndSendFrame);

    return () => {
      if (frameExtractionRef.current) {
        cancelAnimationFrame(frameExtractionRef.current);
        frameExtractionRef.current = null;
      }
    };
  }, [targetFPS]);

  const startWebSocketConnection = useCallback(() => {
    if (!process.env.NEXT_PUBLIC_BACKEND_URL2) {
      console.error('NEXT_PUBLIC_BACKEND_URL2 is not defined');
      setErrorMsg('Backend URL not configured');
      return;
    }

    if (webSocketRef.current) {
      webSocketRef.current.close();
    }

    try {
      const socket = new WebSocket(
        `${process.env.NEXT_PUBLIC_BACKEND_URL2}/frame-stream/${interviewId}`
      );

      socket.onopen = () => {
        console.log("WebSocket connection established");
      };

      socket.onmessage = (event) => {
        if (isMountedRef.current) {
          try {
            const engagementResult = JSON.parse(event.data);
            console.log("Engagement Result:", engagementResult);
          } catch (parseError) {
            console.error("Error parsing WebSocket message:", parseError);
          }
        }
      };

      socket.onerror = (error) => {
        console.error("WebSocket error:", error);
        if (isMountedRef.current) {
          setErrorMsg("WebSocket connection error");
        }
      };

      socket.onclose = () => {
        console.log("WebSocket connection closed");
      };

      webSocketRef.current = socket;
    } catch (error) {
      console.error("Error creating WebSocket:", error);
      if (isMountedRef.current) {
        setErrorMsg("Failed to establish WebSocket connection");
      }
    }
  }, [interviewId]);

  const startScreenRecording = async (): Promise<boolean> => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        setErrorMsg("Screen sharing is not supported in this browser");
        return false;
      }

      const displayMediaOptions: DisplayMediaStreamOptions = {
        video: {
          width: { ideal: 1920 },
          height: { ideal: 1080 },
          frameRate: { ideal: 30 },
        },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100,
        } as MediaTrackConstraints,
      };

      const screenStream = await navigator.mediaDevices.getDisplayMedia(
        displayMediaOptions
      );

      const videoTrack = screenStream.getVideoTracks()[0];
      if (!videoTrack) {
        screenStream.getTracks().forEach((track) => track.stop());
        setErrorMsg("No video track found in screen stream");
        return false;
      }

      const settings = videoTrack.getSettings();

      if (settings.displaySurface !== "monitor") {
        screenStream.getTracks().forEach((track) => track.stop());
        setErrorMsg(
          "Please select 'Entire Screen' option. Window or tab sharing is not allowed."
        );
        setScreenPermissionDenied(true);
        return false;
      }

      if (screenVideoRef.current) {
        screenVideoRef.current.srcObject = screenStream;
      }

      screenStreamRef.current = screenStream;

      videoTrack.addEventListener("ended", () => {
        if (isMountedRef.current) {
          setIsScreenShareActive(false);
          setErrorMsg("Screen sharing was stopped. Interview cannot continue.");
        }
      });

      setIsScreenShareActive(true);
      setScreenRecordingReady(true);
      return true;
    } catch (error) {
      console.error("Error accessing screen capture:", error);
      setErrorMsg(
        "Screen sharing is required to start the interview. Please allow screen sharing and select 'Entire Screen'."
      );
      setScreenPermissionDenied(true);
      return false;
    }
  };

  const startCamera = async (): Promise<boolean> => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setErrorMsg("Camera access is not supported in this browser");
        return false;
      }

      const cameraStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 44100,
        },
        video: {
          width: 1280,
          height: 720,
          frameRate: 30,
        },
      });

      if (gumVideoRef.current) {
        gumVideoRef.current.srcObject = cameraStream;
      }

      cameraStreamRef.current = cameraStream;
      setIsCameraActive(true);
      return true;
    } catch (error) {
      console.error("Error accessing camera:", error);
      setErrorMsg(`Error accessing camera: ${String(error)}`);
      return false;
    }
  };

  const startCombinedRecording = async () => {
    if (!cameraStreamRef.current || !screenStreamRef.current) {
      setErrorMsg("Both camera and screen streams are required");
      return false;
    }

    try {
      const combinedStream = new MediaStream();

      // Add screen video track
      const screenVideoTrack = screenStreamRef.current.getVideoTracks()[0];
      if (screenVideoTrack) {
        combinedStream.addTrack(screenVideoTrack);
      }

      // Add camera audio track
      const cameraAudioTrack = cameraStreamRef.current.getAudioTracks()[0];
      if (cameraAudioTrack) {
        combinedStream.addTrack(cameraAudioTrack);
      }

      // Add screen audio track if available
      const screenAudioTrack = screenStreamRef.current.getAudioTracks()[0];
      if (screenAudioTrack) {
        combinedStream.addTrack(screenAudioTrack);
      }

      combinedStreamRef.current = combinedStream;

      // Start recording with Option 1 approach (buffer in memory)
      const recordingStarted = await startRecording(combinedStream);
     
      if (recordingStarted) {
        startWebSocketConnection();
        setupFrameExtraction();
        return true;
      } else {
        setErrorMsg("Failed to start recording");
        return false;
      }
    } catch (error) {
      console.error("Error creating combined stream:", error);
      setErrorMsg(`Error starting recording: ${String(error)}`);
      return false;
    }
  };
 
  const TabSwitchingIndicator = () => {
    if (!isagreed || isInterviewOver || !isScreenShareActive || !isCameraActive) return null;
   
    return (
      <div className="absolute top-4 right-4 flex items-center space-x-2 text-xs">
        <div
          className={`h-2 w-2 rounded-full ${
            isTabActive ? 'bg-green-500' : 'bg-red-500'
          } animate-pulse`}
        />
        <span className="text-gray-600 dark:text-gray-400">
          {isTabActive ? 'Window Active' : 'Window Inactive'}
        </span>
      </div>
    );
  };
 
  const stopAllStreams = () => {
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach((track) => track.stop());
      cameraStreamRef.current = null;
    }

    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((track) => track.stop());
      screenStreamRef.current = null;
    }

    if (combinedStreamRef.current) {
      combinedStreamRef.current.getTracks().forEach((track) => track.stop());
      combinedStreamRef.current = null;
    }

    if (webSocketRef.current) {
      if (webSocketRef.current.readyState === WebSocket.OPEN ||
          webSocketRef.current.readyState === WebSocket.CONNECTING) {
        webSocketRef.current.close();
      }
      webSocketRef.current = null;
    }

    if (frameExtractionRef.current) {
      cancelAnimationFrame(frameExtractionRef.current);
      frameExtractionRef.current = null;
    }

    if (gumVideoRef.current) {
      gumVideoRef.current.srcObject = null;
    }

    if (screenVideoRef.current) {
      screenVideoRef.current.srcObject = null;
    }

    // Cleanup recording
    cleanup();

    setIsCameraActive(false);
    setIsScreenShareActive(false);
    setErrorMsg("");
    setScreenRecordingReady(false);
    cleanupCompleteRef.current = true;
  };

  const handleagreedrules = async () => {
    if (!screenRecordingReady) {
      setErrorMsg("Screen recording is not ready. Please allow screen sharing first.");
      return;
    }

    setisagreed(true);
    setErrorMsg("");

    if (interviewQuestions && interviewQuestions.length > 0) {
      const cameraStarted = await startCamera();
      if (cameraStarted) {
        // Small delay to ensure streams are ready
        setTimeout(() => {
          startCombinedRecording();
        }, 1000);
      }
    } else {
      setErrorMsg("No interview questions available");
    }
  };

  const handleFinishInterview = async () => {
    try {
      setIsProcessing(true);
     
      // Stop recording and upload to Azure (Option 1 approach)
      const uploadSuccess = await stopRecordingAndUpload();
     
      if (!uploadSuccess) {
        setErrorMsg("Failed to complete recording upload");
        return;
      }

      // Submit interview answers
      const formData = new FormData();
      const answersJSON = JSON.stringify(questionAnswer.slice(1));
      formData.append("unique_id", `${interviewId}`);
      formData.append("questions", answersJSON);

      if (!process.env.NEXT_PUBLIC_BACKEND_URL) {
        throw new Error('Backend URL not configured');
      }

      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/update_interview`,
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to update interview: ${response.statusText}`);
      }

      try {
        await response.json();
        setSubmitSuccess(true);
      } catch (jsonError) {
        console.warn("Failed to parse JSON response:", jsonError);
        setSubmitSuccess(true);
      }

      stopAllStreams();

      await new Promise<void>((resolve) => {
        const checkCleanup = () => {
          if (cleanupCompleteRef.current) {
            resolve();
          } else {
            setTimeout(checkCleanup, 100);
          }
        };
        checkCleanup();
      });

      if (isMountedRef.current) {
        setIsInterviewOver(true);
      }

      if (typeof window !== 'undefined') {
        window.postMessage(
          { type: "INTERVIEW_ENDED", unique_id: interviewId },
          "*"
        );
      }
    } catch (error) {
      console.error("Error finishing interview:", error);
      if (isMountedRef.current) {
        setErrorMsg(`Error finishing interview: ${String(error)}`);
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleToggleLayout = () => {
    setIsCameraLeft(!isCameraLeft);
  };

  // Update error message to include recording errors
  const displayError = errorMsg || recordingError;

  // Initialize screen recording when component mounts
  useEffect(() => {
    isMountedRef.current = true;
    cleanupCompleteRef.current = false;
    
    // Start screen recording automatically when the rules page loads
    const initializeScreenRecording = async () => {
      if (interviewQuestions && interviewQuestions.length > 0) {
        await startScreenRecording();
      }
    };

    initializeScreenRecording();
   
    return () => {
      isMountedRef.current = false;
      stopAllStreams();
    };
  }, [interviewQuestions]);

  // Hidden recording status - functionality preserved but UI removed

  return (
   
    <div className="w-full h-screen flex flex-col items-center bg-gradient-to-b to-gray-100 p-4 md:p-8">
      {/* Enhanced Tab Switch Warning Modal */}
      <TabSwitchWarningModal />
 
      {/* Processing Warning Modal */}
      {isProcessing && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 backdrop-blur-sm">
          <Card className="w-full max-w-md mx-4 shadow-2xl rounded-2xl bg-white dark:bg-black border-primary/20">
            <CardHeader className="bg-primary/5 dark:bg-black rounded-t-2xl">
              <CardTitle className="flex items-center text-xl font-semibold text-primary dark:text-white">
                <Clock className="mr-3 h-6 w-6 animate-spin text-primary" />
                Interview Processing
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 bg-white dark:bg-black">
              <div className="text-center space-y-4">
                <div className="text-black dark:text-gray-300">
                  <p className="font-medium mb-2">Please do not close this window!</p>
                </div>
               
                {isUploading && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-center space-x-2 text-sm text-black dark:text-gray-400">
                      <Upload className="h-4 w-4 animate-bounce" />
                      <span>Interview is still in progress</span>
                    </div>
                    {uploadProgress && uploadProgress.percentage !== undefined &&(
                      <div className="w-full bg-gray-200 dark:bg-black rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all duration-300"
                          style={{ width: `${uploadProgress.percentage}%` }}
                        />
                      </div>
                    )}
                  </div>
                )}
               
                <div className="text-xs text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
                  This process may take a few minutes depending on your internet connection.
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {!isagreed ? (
        <Card className="w-full max-w-2xl shadow-xl rounded-2xl bg-white dark:bg-black">
          <CardHeader className="bg-primary/5 dark:bg-black rounded-t-2xl">
            <CardTitle className="flex items-center text-2xl font-semibold text-primary dark:text-white">
              <AlertCircle className="mr-3 h-6 w-6" /> Interview Rules and Regulations
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 bg-white dark:bg-black">
            <ul className="space-y-2 mb-4 max-h-48 overflow-y-auto pr-2">
              {interviewRules.map((rule, index) => (
                <li
                  key={index}
                  className="flex items-start text-sm md:text-base"
                >
                  <span className="mr-3 text-primary font-bold">•</span>
                  {rule}
                </li>
              ))}
            </ul>
            
            {/* Screen recording status indicator */}
            {screenRecordingReady && (
              <div className="mb-4 p-3 bg-green-50 border border-green-200 text-green-700 rounded-lg">
                <div className="flex items-center">
                  <CheckCircle className="mr-2 h-5 w-5" />
                  <span className="font-semibold">Screen Sharing Active</span>
                </div>
                <p className="mt-2 text-sm">
                  Screen recording is active now. You can now proceed with the interview.
                </p>
              </div>
            )}
            
            {screenPermissionDenied && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg">
                <div className="flex items-center">
                  <Monitor className="mr-2 h-5 w-5" />
                  <span className="font-semibold">Screen Sharing Required</span>
                </div>
                <p className="mt-2 text-sm">
                  You must allow screen sharing and select "Entire Screen"
                  option to proceed with the interview.
                </p>
                <Button
                  onClick={startScreenRecording}
                  className="mt-2 bg-red-600 hover:bg-red-700 text-white"
                  size="sm"
                >
                  Try Again
                </Button>
              </div>
            )}
            
            <div className="flex justify-center">
              <Button
                onClick={handleagreedrules}
                className="w-full max-w-sm bg-primary hover:bg-primary/90 transition-all duration-300 font-semibold py-2 rounded-lg"
                disabled={!screenRecordingReady}
              >
                {screenRecordingReady ? 'I Agree & Start Interview' : 'Waiting for Screen Share...'}
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col md:flex-row w-full max-w-7xl h-[calc(100vh-4rem)] gap-6">
          <div className={`flex flex-col items-center space-y-4 p-6 bg-white dark:bg-black rounded-2xl shadow-lg transition-all duration-300
  ${isCameraLeft ? 'md:order-1 w-full md:w-1/3' : 'md:order-2 w-full md:w-2/3'}`}>
            <div className="relative w-full max-w-md">
              <video
                ref={gumVideoRef}
                id="gum"
                className={`w-full ${isCameraLeft ? 'h-[420px]' : 'h-[210px]'} aspect-video bg-black rounded-2xl shadow-md border border-gray-200 dark:border-gray-700 object-cover`}
                playsInline
                autoPlay
                muted
              />
              <TabSwitchingIndicator />
              {/* Camera layout toggle button */}
              {!isCameraLeft && (
                <div className="absolute top-2 right-2">
                  <Button
                    onClick={handleToggleLayout}
                    className="bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-700 dark:text-white p-2 rounded-full"
                    variant="ghost"
                  >
                    <ArrowLeftRight className="h-5 w-5" />
                  </Button>
                </div>
              )}
              <div className="absolute top-2 left-2 bg-green-500 h-3 w-3 rounded-full animate-pulse" />
             
              {/* Basic recording indicator only */}
              {isRecording && (
                <div className="absolute bottom-2 left-2 bg-red-500 h-3 w-3 rounded-full animate-pulse" />
              )}
            </div>
           
            <video
              ref={screenVideoRef}
              className="hidden"
              playsInline
              autoPlay
              muted
            />
            <canvas
              ref={canvasRef}
              className="w-[50px] aspect-video bg-black hidden"
            />
           
            {displayError && (
              <div className="text-red-500 text-sm text-center max-w-md p-4 bg-red-50 dark:bg-gray-900 rounded-lg border border-red-200 dark:border-red-700">
                {displayError}
              </div>
            )}
          </div>
         
          <div className={`flex flex-col items-center justify-between p-6 bg-white dark:bg-black rounded-2xl shadow-lg transition-all duration-300 ${isCameraLeft ? 'md:order-2 w-full md:w-2/3' : 'md:order-1 w-full md:w-1/3'}`}>
            <div className="w-full max-w-3xl mx-auto flex-1 overflow-auto text-black dark:text-white p-2 sm:p-4">
              <Question
                interviewId={interviewId}
                isInterviewOver={isInterviewOver}
                setIsInterviewOver={setIsInterviewOver}
                questionAnswer={questionAnswer}
                setQuestionAnswer={setQuestionAnswer}
              />
             
              {isInterviewOver && !isProcessing && (
                <div className="flex justify-center mt-6">
                  <Button
                    onClick={handleFinishInterview}
                    disabled={isUploading || (!isRecording && !hasRecordedData)}
                    className="bg-primary hover:bg-primary/90 font-semibold py-3 px-6 rounded-lg disabled:opacity-50"
                  >
                    {isUploading
                      ? 'Processing...'
                      : 'Finish Interview'
                    }
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InterviewRulesPage;