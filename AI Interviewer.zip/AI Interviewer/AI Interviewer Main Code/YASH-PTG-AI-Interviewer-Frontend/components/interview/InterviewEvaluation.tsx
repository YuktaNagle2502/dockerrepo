import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import EvaluationDialog from "@/components/dialogs/EvaluationDialog";
import { authFetch } from "@/lib/authFetch";

interface EvaluationResult {
  overall_score: number;
  question_scores: {
    question: string;
    correct_answer: string;
    user_answer: string;
    ai_comment: string;
    weighted_score: number;
  }[];
}
interface InterviewEvaluationProps {
  user_Id: string;
}

export const InterviewEvaluation: React.FC<InterviewEvaluationProps> = ({
  user_Id,
}) => {
  const [evaluationResult, setEvaluationResult] =
    useState<EvaluationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const { toast } = useToast();

  const handleEvaluate = async () => {
    setEvaluationResult(null);
    setIsLoading(true);

    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/question/evaluate/${user_Id}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      console.log("Response status:", response.status);
      const responseText = await response.text();

      if (!response.ok) {
        throw new Error(
          `HTTP error! status: ${response.status}, message: ${responseText}`
        );
      }

      const result = JSON.parse(responseText);
      console.log("Evaluation result:", result);
      setEvaluationResult(result);

      toast({
        title: "Evaluation Complete",
        description: "Interview answers have been evaluated successfully.",
      });
    } catch (err) {
      console.error("Full error:", err);
      toast({
        title: "Evaluation Error",
        description: `Failed to evaluate interview: ${
          err instanceof Error ? err.message : "Unknown error"
        }`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4 w-full">
      <Button
        // onClick={() => setDialogOpen(true)}
        className="w-full"
        disabled={isLoading}
        onClick={handleEvaluate}
      >
        {isLoading ? "Evaluating..." : "Evaluate The Candidate"}
      </Button>

      {/* <EvaluationDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onEvaluate={handleEvaluate}
      /> */}

      {evaluationResult && (
        <Card>
          <CardHeader>
            <CardTitle>Interview Evaluation Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span
                  className={`font-semibold ${
                    evaluationResult.overall_score >= 0.7
                      ? "text-green-600"
                      : evaluationResult.overall_score >= 0.5
                      ? "text-yellow-600"
                      : "text-red-600"
                  }`}
                >
                  Overall Score:{" "}
                  {(evaluationResult.overall_score * 100).toFixed(2)}%
                </span>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-semibold">Detailed Feedback:</h3>
                {evaluationResult.question_scores.map((item, index) => (
                  <Card key={index}>
                    <CardContent className="p-4 space-y-2">
                      <div>
                        <span className="font-semibold">Question:</span>
                        <p>{item.question}</p>
                      </div>
                      <div>
                        <span className="font-semibold">Your Answer:</span>
                        <p>{item.user_answer}</p>
                      </div>
                      <div>
                        <span className="font-semibold">AI Comment:</span>
                        <p>{item.ai_comment}</p>
                      </div>

                      <div className="flex justify-between items-center">
                        <span
                          className={`font-semibold ${
                            item.weighted_score >= 0.7
                              ? "text-green-600"
                              : item.weighted_score >= 0.5
                              ? "text-yellow-600"
                              : "text-red-600"
                          }`}
                        >
                          Score: {(item.weighted_score * 100).toFixed(2)}%
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default InterviewEvaluation;
