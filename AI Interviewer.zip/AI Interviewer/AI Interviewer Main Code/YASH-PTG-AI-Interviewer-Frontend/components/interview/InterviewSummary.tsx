import React, { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { authFetch } from "@/lib/authFetch";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { useToast } from "@/hooks/use-toast";

// Types
interface EngagementData {
  Timestamp: string;
  Status: "engaged" | "disengaged";
  Engaged_Frames: number;
  Disengaged_Frames: number;
}

interface QuestionScore {
  question: string;
  correct_answer: string;
  user_answer: string;
  weighted_score: number;
  ai_comment: string;
}

interface EvaluationData {
  overall_score: number;
  question_scores: QuestionScore[];
  communication_skills: string;
  grammatical_correctness: string;
  clarity: string;
  conclusion: string;
  final_remarks: FinalRemarks;
}

interface FinalRemarks {
  communication_skills: string;
  grammatical_correctness: string;
  clarity: string;
  conclusion: string;
}

interface TabSwitchingActivity {
  id: number;
  interview_id: string;
  screenshot_url: string;
  blob_name: string;
  timestamp: string;
}

interface CandidateDetails {
  unique_id: string;
  full_name: string;
  age: number;
  phone: string;
  email_id: string;
  sex: string;
  user_image_path: string;
  user_image_url: string;
  domain: string;
  resume_score: number;
  scheduled_at: string;
  job_title: string;
  job_location: string;
  summary_points: string[];
}

const InterviewSummary: React.FC = () => {
  const params = useParams();
  const id = params.id as string;
  const { toast } = useToast();

  const [engagementData, setEngagementData] = useState<EngagementData[]>([]);
  const [evaluationData, setEvaluationData] = useState<EvaluationData | null>(null);
  const [loading, setLoading] = useState(true);
  const [candidateLoading, setCandidateLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0); // New state for upload progress
  const [error, setError] = useState<string | null>(null);
  const [tabSwitchingActivities, setTabSwitchingActivities] = useState<TabSwitchingActivity[]>([]);
  const [candidateDetails, setCandidateDetails] = useState<CandidateDetails | null>(null);
  const [imageLoadFailed, setImageLoadFailed] = useState(false);

  useEffect(() => {
    if (id) {
      fetchCandidateDetails(id);
      fetchInterviewData(id);
      fetchTabSwitchingActivities(id);
    }
  }, [id]);

  const fetchCandidateDetails = async (interviewId: string) => {
    try {
      setCandidateLoading(true);
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/candidate-details/${interviewId}`
      );
      if (!response.ok) {
        throw new Error("Failed to fetch candidate details");
      }
      const result = await response.json();
      if (result.success && result.data) {
        console.log("Candidate details fetched:", result.data);
        setCandidateDetails(result.data);
      } else {
        console.warn("No candidate details found or invalid response:", result);
        setCandidateDetails(null);
      }
    } catch (error) {
      console.error("Error fetching candidate details:", error);
      setCandidateDetails(null);
    } finally {
      setCandidateLoading(false);
    }
  };

  const renderCandidateDetails = () => {
    if (candidateLoading) {
      return (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6 border border-gray-200 flex flex-col md:flex-row interview-card pdf-bg-white pdf-border pdf-spacing">
          <div className="text-center w-full">
            <p className="text-gray-600 text-lg">Loading candidate details...</p>
          </div>
        </div>
      );
    }

    if (!candidateDetails) {
      return (
        <div className="bg-white rounded-lg shadow-md p-6 mb-6 border border-gray-200 flex flex-col md:flex-row interview-card pdf-bg-white pdf-border pdf-spacing">
          <div className="text-center w-full">
            <p className="text-red-500 text-lg">Failed to load candidate details</p>
          </div>
        </div>
      );
    }

    const formattedName =
      candidateDetails.full_name.charAt(0).toUpperCase() +
      candidateDetails.full_name.slice(1);

    return (
      <div className="bg-white rounded-lg shadow-md p-6 mb-6 border border-gray-200 flex flex-col md:flex-row interview-card pdf-bg-white pdf-border pdf-spacing">
        <div className="w-full md:w-2/5 pr-4 mb-4 md:mb-0">
          <img
            src={imageLoadFailed ? "/default-avatar.png" : candidateDetails.user_image_url || "/default-avatar.png"}
            onError={(e) => {
              if (!imageLoadFailed) {
                console.error("Failed to load candidate image:", candidateDetails.user_image_url);
                setImageLoadFailed(true);
                e.currentTarget.src = "/default-avatar.png";
              }
            }}
            alt={formattedName}
            className="w-full h-auto object-contain"
            style={{ maxHeight: "300px", borderRadius: "8px", marginBottom: "16px" }}
            crossOrigin="anonymous"
          />
        </div>
        <div className="w-full md:w-3/5 flex flex-col">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-3xl font-semibold text-gray-800 pdf-header pdf-text">
              {formattedName}
            </h2>
            <span className="text-blue-800 text-xl px-3 py-1 rounded-full font-semibold">
              Resume Score: {(candidateDetails.resume_score * 100).toFixed(0)}%
            </span>
          </div>
          <p className="text-lg text-gray-600 mb-1 pdf-text-muted">
            {candidateDetails.job_title && candidateDetails.job_location
              ? `${candidateDetails.job_title} - ${candidateDetails.job_location}`
              : null}
          </p>
          <div className="pt-4">
            {[
              { label: "Email", value: candidateDetails.email_id },
              { label: "Phone", value: candidateDetails.phone },
              { label: "Age", value: candidateDetails.age },
              { label: "Gender", value: candidateDetails.sex },
            ].map(({ label, value }) =>
              value ? (
                <div key={label} className="mb-2 flex">
                  <p className="text-xs text-black uppercase mr-1">{label}:</p>
                  <p className="text-xs text-black uppercase mr-1">{value}</p>
                </div>
              ) : null
            )}
          </div>
        </div>
      </div>
    );
  };

  const fetchTabSwitchingActivities = async (interviewId: string) => {
    try {
      console.log("Fetching tab switching activities for interview:", interviewId);
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/tab-switching/get_tab_switching_activities/${interviewId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
        }
      );

      if (response.status === 403) {
        console.error("403 Forbidden: Authentication failed");
        throw new Error("Authentication failed. Please check your credentials or refresh your session.");
      }

      if (response.status === 401) {
        console.error("401 Unauthorized: Invalid or expired token");
        throw new Error("Unauthorized. Please log in again.");
      }

      if (!response.ok) {
        const errorText = await response.text();
        console.error("API Error:", response.status, errorText);
        throw new Error(`Failed to fetch tab switching activities: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      console.log("Received tab switching data:", data);

      if (data.status === "success" && Array.isArray(data.activities)) {
        setTabSwitchingActivities(data.activities);
        console.log("Successfully set tab switching activities:", data.activities.length, "items");
      } else {
        console.warn("Unexpected data format:", data);
        setTabSwitchingActivities([]);
      }
    } catch (error) {
      console.error("Error fetching tab switching activities:", error);
      setTabSwitchingActivities([]);
    }
  };

  const renderTabSwitchingScreenshots = () => {
    if (!tabSwitchingActivities.length) return null;

    return (
      <div className="bg-white rounded-xl shadow-lg p-8 mb-8 border border-gray-200">
        <div className="flex items-center mb-6">
          <div className="bg-red-100 p-2 rounded-lg mr-4">
            <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"
              />
            </svg>
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-800">Suspicious Activities</h3>
            <p className="text-gray-600 text-sm">Detected {tabSwitchingActivities.length} suspicious activities</p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {tabSwitchingActivities.map((activity) => (
            <div
              key={activity.id}
              className="bg-gray-50 rounded-lg overflow-hidden shadow-sm border border-gray-200"
            >
              <img
                src={activity.screenshot_url}
                alt={`Tab switching screenshot ${activity.id}`}
                className="w-full h-full object-cover"
                crossOrigin="anonymous"
              />
              <div className="p-3">
                <p className="text-xs text-gray-500 font-medium">
                  {new Date(activity.timestamp).toLocaleString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const fetchInterviewData = async (interviewId: string) => {
    try {
      setLoading(true);
      const engagementResponse = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/status_api_data/${interviewId}`
      );
      if (!engagementResponse.ok) {
        throw new Error("Failed to fetch engagement data");
      }
      const engagementResult = await engagementResponse.json();
      setEngagementData(engagementResult);

      const evaluationResponse = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/question/evaluate/${interviewId}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      if (!evaluationResponse.ok) {
        throw new Error("Failed to fetch evaluation data");
      }
      const evaluationResult = await evaluationResponse.json();
      setEvaluationData(evaluationResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  const processEngagementData = () => {
    return engagementData.map((item, index) => ({
      time: new Date(item.Timestamp).toLocaleTimeString(),
      timestamp: item.Timestamp,
      engagedFrames: item.Engaged_Frames,
      disengagedFrames: item.Disengaged_Frames,
      status: item.Status,
      engagementRate: (item.Engaged_Frames / (item.Engaged_Frames + item.Disengaged_Frames)) * 100,
    }));
  };

  const calculateEngagementStats = () => {
    if (!engagementData.length)
      return { totalEngaged: 0, totalDisengaged: 0, avgEngagement: 0 };

    const totalEngaged = engagementData.reduce((sum, item) => sum + item.Engaged_Frames, 0);
    const totalDisengaged = engagementData.reduce((sum, item) => sum + item.Disengaged_Frames, 0);
    const avgEngagement = (totalEngaged / (totalEngaged + totalDisengaged)) * 100;

    return { totalEngaged, totalDisengaged, avgEngagement };
  };

  const processScoreData = () => {
    if (!evaluationData) return [];

    return evaluationData.question_scores.map((score, index) => ({
      question: `Q${index + 1}`,
      score: (score.weighted_score * 100).toFixed(1),
      fullQuestion: score.question.substring(0, 50) + "...",
    }));
  };

  // const uploadPDFToS3 = async () => {
  //   setUploading(true);
  //   setUploadProgress(0); // Reset progress
  //   try {
  //     const input = document.getElementById("pdf-content");
  //     if (!input) {
  //       toast({
  //         title: "Export Error",
  //         description: "Could not find content to export.",
  //         variant: "destructive",
  //       });
  //       return;
  //     }
  //     const canvas = await html2canvas(input, {
  //       scale: 2,
  //       useCORS: true,
  //       backgroundColor: "#fff",
  //     });
  //     const imgData = canvas.toDataURL("image/png");
  //     const pdf = new jsPDF({
  //       orientation: "portrait",
  //       unit: "pt",
  //       format: "a4",
  //     });
  //     const pageWidth = pdf.internal.pageSize.getWidth();
  //     const pageHeight = pdf.internal.pageSize.getHeight();
  //     const imgProps = pdf.getImageProperties(imgData);
  //     const pdfWidth = pageWidth;
  //     const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

  //     let position = 0;
  //     pdf.addImage(imgData, "PNG", 0, position, pdfWidth, pdfHeight);

  //     if (pdfHeight > pageHeight) {
  //       let remainingHeight = pdfHeight - pageHeight;
  //       let pageCount = 1;
  //       while (remainingHeight > 0) {
  //         pdf.addPage();
  //         position = -pageHeight * pageCount;
  //         pdf.addImage(imgData, "PNG", 0, position, pdfWidth, pdfHeight);
  //         remainingHeight -= pageHeight;
  //         pageCount++;
  //       }
  //     }

  //     const pdfName = `Interview_Summary_${id}.pdf`;
  //     const pdfBlob = pdf.output("blob");

  //     const formData = new FormData();
  //     formData.append("file", pdfBlob, pdfName);

  //     // Simulate progress for the upload (since authFetch doesn't support progress events natively)
  //     const simulateProgress = () => {
  //       let progress = 0;
  //       const interval = setInterval(() => {
  //         progress += 10;
  //         setUploadProgress(Math.min(progress, 90)); // Cap at 90% until upload completes
  //         if (progress >= 90) clearInterval(interval);
  //       }, 200);
  //       return () => clearInterval(interval);
  //     };

  //     const stopProgressSimulation = simulateProgress();

  //     const uploadResponse = await authFetch(
  //       `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/upload_summary_report/${id}`,
  //       {
  //         method: "POST",
  //         body: formData,
  //       }
  //     );

  //     stopProgressSimulation(); // Stop progress simulation

  //     if (!uploadResponse.ok) {
  //       const errorText = await uploadResponse.text();
  //       console.error("Failed to upload PDF to S3:", uploadResponse.status, errorText);
  //       toast({
  //         title: "Upload Error",
  //         description: `Failed to upload PDF to S3: ${errorText}`,
  //         variant: "destructive",
  //       });
  //       return;
  //     }

  //     setUploadProgress(100); // Complete progress
  //     const uploadResult = await uploadResponse.json();
  //     console.log("PDF uploaded to S3 successfully:", uploadResult);
  //     toast({
  //       title: "Upload Success",
  //       description: "PDF uploaded to S3 successfully.",
  //     });

  //     // Trigger download
  //     const pdfUrl = window.URL.createObjectURL(pdfBlob);
  //     const link = document.createElement("a");
  //     link.href = pdfUrl;
  //     link.download = pdfName;
  //     document.body.appendChild(link);
  //     link.click();
  //     document.body.removeChild(link);
  //     window.URL.revokeObjectURL(pdfUrl);

  //   } catch (error) {
  //     console.error("Error uploading PDF to S3:", error);
  //     toast({
  //       title: "Upload Error",
  //       description: `An error occurred while uploading PDF to S3: ${
  //         error instanceof Error ? error.message : "Unknown error"
  //       }`,
  //       variant: "destructive",
  //     });
  //     setUploadProgress(0);
  //   } finally {
  //     setUploading(false);
  //     setTimeout(() => setUploadProgress(0), 2000); // Hide progress after 2 seconds
  //   }
  // };

  const chartData = processEngagementData();
  const engagementStats = calculateEngagementStats();
  const scoreData = processScoreData();

  const COLORS = ["#3B82F6", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6"];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="mt-6 text-gray-600 text-lg">Loading interview summary...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 flex items-center justify-center">
        <div className="text-center bg-white p-8 rounded-xl shadow-lg">
          <div className="text-red-500 text-2xl mb-4">⚠️ Error</div>
          <p className="text-gray-600 mb-6">{error}</p>
          <button
            onClick={() => fetchInterviewData(id)}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4">
        <div id="pdf-content" className="bg-white shadow-2xl rounded-2xl border border-gray-200 overflow-hidden pdf-content">
          <div className="text-black p-8 pdf-header">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-4xl font-bold tracking-tight mb-2 pdf-text">
                  Interview Summary Report
                </h1>
                <div className="flex items-center space-x-4 text-grey-300">
                  <span className="text-sm pdf-text-muted">
                    Interview ID: <span className="font-mono font-semibold">{id}</span>
                  </span>
                  <span className="text-sm pdf-text-muted">•</span>
                  <span className="text-sm pdf-text-muted">Generated: {new Date().toLocaleDateString()}</span>
                </div>
              </div>
              <div className="relative mt-6 md:mt-0">
                {/* <button
                  onClick={uploadPDFToS3}
                  disabled={uploading}
                  className={`flex items-center px-6 py-3 text-blue-600 bg-white border border-blue-600 rounded-lg font-semibold shadow-sm transition-colors ${
                    uploading ? "opacity-50 cursor-not-allowed" : "hover:bg-blue-50 hover:shadow-md"
                  }`}
                >
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    />
                  </svg>
                  {uploading ? "Uploading..." : "Upload PDF to S3"}
                </button> */}
                {/* {uploading && uploadProgress > 0 && (
                  <div className="w-full mt-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-600">
                        Uploading: Interview_Summary_{id}.pdf
                      </span>
                      <span className="text-xs">{uploadProgress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded h-2 mt-1">
                      <div
                        className="bg-blue-500 h-2 rounded"
                        style={{ width: `${uploadProgress}%` }}
                      ></div>
                    </div>
                  </div>
                )} */}
              </div>
            </div>
          </div>

          <div className="p-8">
            {renderCandidateDetails()}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              {evaluationData && (
                <div className="md:col-span-1 bg-purple-200 text-gray-800 rounded-xl shadow-lg p-6">
                  <div className="flex items-center mb-4">
                    <div className="bg-white bg-opacity-30 p-2 rounded-lg mr-3">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <h3 className="text-lg font-semibold">Overall Score</h3>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold mb-2">{(evaluationData.overall_score * 100).toFixed(1)}%</div>
                    <div className="text-gray-600 text-sm">Performance Rating</div>
                  </div>
                </div>
              )}
              <div className="bg-green-100 text-gray-800 rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="bg-white bg-opacity-30 p-2 rounded-lg mr-3">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-semibold">Engagement</h3>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold mb-2">{engagementStats.avgEngagement.toFixed(1)}%</div>
                  <div className="text-gray-600 text-sm">Average Rate</div>
                </div>
              </div>
              <div className="bg-yellow-100 text-gray-800 rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="bg-white bg-opacity-30 p-2 rounded-lg mr-3">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-semibold">Engaged</h3>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold mb-2">{engagementStats.totalEngaged.toLocaleString()}</div>
                  <div className="text-gray-600 text-sm">Total Frames</div>
                </div>
              </div>
              <div className="bg-red-100 text-gray-800 rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <div className="bg-white bg-opacity-30 p-2 rounded-lg mr-3">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21"
                      />
                    </svg>
                  </div>
                  <h3 className="text-lg font-semibold">Disengaged</h3>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold mb-2">{engagementStats.totalDisengaged.toLocaleString()}</div>
                  <div className="text-gray-600 text-sm">Total Frames</div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
              <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
                <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
                  <div className="bg-blue-100 p-2 rounded-lg mr-3">
                    <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                      />
                    </svg>
                  </div>
                  Engagement Timeline
                </h3>
                <ResponsiveContainer width="100%" height={280}>
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#f8fafc",
                        border: "1px solid #e2e8f0",
                        borderRadius: "8px",
                        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="engagementRate"
                      stroke="#3B82F6"
                      strokeWidth={3}
                      name="Engagement Rate (%)"
                      dot={{ fill: "#3B82F6", strokeWidth: 2, r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              {evaluationData && (
                <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
                  <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
                    <div className="bg-green-100 p-2 rounded-lg mr-3">
                      <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    Question Scores
                  </h3>
                  <ResponsiveContainer width="100%" height={280}>
                    <BarChart data={scoreData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                      <XAxis dataKey="question" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#f8fafc",
                          border: "1px solid #e2e8f0",
                          borderRadius: "8px",
                          boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                        }}
                      />
                      <Bar dataKey="score" fill="#10B981" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
              <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
                <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center">
                  <div className="bg-purple-100 p-2 rounded-lg mr-3">
                    <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                      />
                    </svg>
                  </div>
                  Distribution
                </h3>
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie
                      data={[
                        { name: "Engaged", value: engagementStats.totalEngaged },
                        { name: "Disengaged", value: engagementStats.totalDisengaged },
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {[
                        { name: "Engaged", value: engagementStats.totalEngaged },
                        { name: "Disengaged", value: engagementStats.totalDisengaged },
                      ].map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
            {renderTabSwitchingScreenshots()}
            {evaluationData && (
              <div className="bg-white rounded-xl shadow-lg p-8 mb-8 border border-gray-200 print-page-break" id="detailed-question-analysis">
                <div className="flex items-center mb-8">
                  <div className="bg-blue-100 p-3 rounded-lg mr-4">
                    <svg className="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 pdf-header">Detailed Question Analysis</h3>
                    <p className="text-gray-600">Performance breakdown for each interview question</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {evaluationData.question_scores.map((score, index) => (
                    <div key={index} className="bg-gray-50 rounded-xl p-6 border border-gray-200 hover:shadow-md transition-shadow avoid-break">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center">
                          <h4 className="text-lg font-semibold text-gray-800">Question {index + 1}</h4>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-blue-600">{(score.weighted_score * 100).toFixed(1)}%</div>
                          <div className="text-xs text-gray-500">Score</div>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <div className="bg-white p-4 rounded-lg border border-gray-200">
                          <p className="text-xs text-gray-500 uppercase tracking-wide mb-2 font-medium">Question</p>
                          <p className="text-sm text-gray-800 leading-relaxed">{score.question}</p>
                        </div>
                        <div className="bg-white p-4 rounded-lg border border-gray-200">
                          <p className="text-xs text-gray-500 uppercase tracking-wide mb-2 font-medium">Candidate Answer</p>
                          <p className="text-sm text-gray-800 leading-relaxed bg-blue-50 p-3 rounded-lg">
                            {score.user_answer || "No answer provided"}
                          </p>
                        </div>
                        <div className="bg-white p-4 rounded-lg border border-gray-200">
                          <p className="text-xs text-gray-500 uppercase tracking-wide mb-2 font-medium">AI Assessment</p>
                          <div className="flex items-start">
                            <div className="bg-yellow-100 p-2 rounded-lg mr-3 flex-shrink-0">
                              <svg className="w-4 h-4 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                                />
                              </svg>
                            </div>
                            <p className="text-sm text-gray-700 leading-relaxed">{score.ai_comment}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {evaluationData && (
              <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl shadow-lg p-8 border border-gray-200 interview-card pdf-gradient-fix pdf-border pdf-spacing">
                <div className="flex items-center mb-8">
                  <div className="bg-indigo-100 p-3 rounded-lg mr-4">
                    <svg className="w-7 h-7 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                      />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 pdf-header pdf-text">Final Assessment</h3>
                    <p className="text-gray-600 pdf-text-muted">Comprehensive evaluation summary</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center mb-4">
                      <div className="bg-blue-100 p-2 rounded-lg mr-3">
                        <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                          />
                        </svg>
                      </div>
                      <h4 className="text-lg font-semibold text-gray-800">Communication Skills</h4>
                    </div>
                    <p className="text-gray-700 leading-relaxed pdf-text">{evaluationData.communication_skills}</p>
                  </div>
                  <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center mb-4">
                      <div className="bg-green-100 p-2 rounded-lg mr-3">
                        <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <h4 className="text-lg font-semibold text-gray-800">Grammar & Language</h4>
                    </div>
                    <p className="text-gray-700 leading-relaxed">{evaluationData.grammatical_correctness}</p>
                  </div>
                  <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center mb-4">
                      <div className="bg-purple-100 p-2 rounded-lg mr-3">
                        <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                      </div>
                      <h4 className="text-lg font-semibold text-gray-800">Clarity & Expression</h4>
                    </div>
                    <p className="text-gray-700 leading-relaxed">{evaluationData.clarity}</p>
                  </div>
                  <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                    <div className="flex items-center mb-4">
                      <div className="bg-yellow-100 p-2 rounded-lg mr-3">
                        <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                          />
                        </svg>
                      </div>
                      <h4 className="text-lg font-semibold text-gray-800">Overall Conclusion</h4>
                    </div>
                    <p className="text-gray-700 leading-relaxed">{evaluationData.conclusion}</p>
                  </div>
                </div>
              </div>
            )}
            <div className="mt-12 pt-8 border-t border-gray-200 text-center">
              <div className="flex items-center justify-center space-x-4 text-gray-400">
                <div className="flex items-center">
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="text-sm">Generated on {new Date().toLocaleString()}</span>
                </div>
                <span>•</span>
                <span className="text-sm">AI-Powered Interview Analysis</span>
                <span>•</span>
                <span className="text-sm">Confidential Report</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InterviewSummary;