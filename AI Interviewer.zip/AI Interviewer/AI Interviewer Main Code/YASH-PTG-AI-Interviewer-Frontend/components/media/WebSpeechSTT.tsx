import React, { useEffect, useRef, useCallback } from "react";

declare global {
  interface Window {
    webkitSpeechRecognition: any;
  }
}

interface WebSpeechSTTProps {
  onTranscriptionResult: (text: string) => void;
  onError: (error: string) => void;
  isListening: boolean;
  setIsListening: (value: boolean) => void;
}

const WebSpeechSTT: React.FC<WebSpeechSTTProps> = ({
  onTranscriptionResult,
  onError,
  isListening,
  setIsListening,
}) => {
  const recognitionRef = useRef<any>(null);
  const retryTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const retryCountRef = useRef(0);
  const MAX_RETRIES = 3;
  const RETRY_DELAY = 3000; // 1 second

  const cleanup = useCallback(() => {
    if (retryTimeoutRef.current) {
      clearTimeout(retryTimeoutRef.current);
      retryTimeoutRef.current = null;
    }

    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (error) {
        console.error("Error stopping recognition:", error);
      }
      recognitionRef.current = null;
    }
  }, []);

  const initializeRecognition = useCallback(() => {
    cleanup();

    try {
      recognitionRef.current = new window.webkitSpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;

      // Increase timeout to prevent early closure
      recognitionRef.current.maxAlternatives = 1;

      let finalTranscript = "";
      let hasReceivedResult = false;

      recognitionRef.current.onresult = (event: any) => {
        hasReceivedResult = true;
        const transcript = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join("");

        if (event.results[0].isFinal) {
          finalTranscript = transcript;
          onTranscriptionResult(transcript);
        }
      };

      recognitionRef.current.onspeechend = () => {
        if (!hasReceivedResult && retryCountRef.current < MAX_RETRIES) {
          // If no result was received, attempt to restart
          retryTimeoutRef.current = setTimeout(() => {
            retryCountRef.current += 1;
            startListening();
          }, RETRY_DELAY);
        } else {
          cleanup();
          setIsListening(false);
        }
      };

      recognitionRef.current.onend = () => {
        if (!hasReceivedResult && retryCountRef.current < MAX_RETRIES) {
          // If connection ended without results, retry
          retryTimeoutRef.current = setTimeout(() => {
            retryCountRef.current += 1;
            startListening();
          }, RETRY_DELAY);
        } else {
          cleanup();
          setIsListening(false);
        }
      };

      recognitionRef.current.onerror = (error: any) => {
        console.error("Speech recognition error:", error);

        if (
          error.error === "network" ||
          error.error === "service-not-allowed"
        ) {
          // Network or service errors might be temporary, retry
          if (retryCountRef.current < MAX_RETRIES) {
            retryTimeoutRef.current = setTimeout(() => {
              retryCountRef.current += 1;
              startListening();
            }, RETRY_DELAY);
          } else {
            onError(`Failed after ${MAX_RETRIES} retries: ${error.message}`);
            cleanup();
            setIsListening(false);
          }
        } else {
          onError(error.message);
          cleanup();
          setIsListening(false);
        }
      };

      // Add connection state handlers
      recognitionRef.current.onaudiostart = () => {
        console.log("Audio recording started");
      };

      recognitionRef.current.onaudioend = () => {
        console.log("Audio recording ended");
      };

      recognitionRef.current.onnomatch = () => {
        if (retryCountRef.current < MAX_RETRIES) {
          retryTimeoutRef.current = setTimeout(() => {
            retryCountRef.current += 1;
            startListening();
          }, RETRY_DELAY);
        } else {
          onError("No speech was recognized");
          cleanup();
          setIsListening(false);
        }
      };
    } catch (error) {
      console.error("Error initializing speech recognition:", error);
      onError("WebSpeech API not supported in this browser");
      cleanup();
      setIsListening(false);
    }
  }, [onTranscriptionResult, onError, setIsListening, cleanup]);

  const startListening = useCallback(() => {
    try {
      if (!recognitionRef.current) {
        initializeRecognition();
      }

      recognitionRef.current.start();
      setIsListening(true);
      retryCountRef.current = 0;
    } catch (error) {
      console.error("Error starting speech recognition:", error);
      if (error instanceof Error && error.name === "InvalidStateError") {
        // Recognition is already running, stop it and restart
        cleanup();
        retryTimeoutRef.current = setTimeout(() => {
          startListening();
        }, RETRY_DELAY);
      } else {
        onError("Failed to start speech recognition");
        cleanup();
        setIsListening(false);
      }
    }
  }, [initializeRecognition, setIsListening, onError, cleanup]);

  useEffect(() => {
    if (isListening) {
      startListening();
    } else {
      cleanup();
    }

    return () => {
      cleanup();
    };
  }, [isListening, startListening, cleanup]);

  return null;
};

export default WebSpeechSTT;
