// import React, { useRef, useEffect } from 'react';

// interface DeepgramSTTProps {
//   onTranscriptionResult: (text: string) => void;
//   onError: (error: string) => void;
//   isListening: boolean;
//   setIsListening: (value: boolean) => void;
//   apiKey: string;
// }

// const DeepgramSTT: React.FC<DeepgramSTTProps> = ({
//   onTranscriptionResult,
//   onError,
//   isListening,
//   setIsListening,
//   apiKey
// }) => {
//   const mediaRecorderRef = useRef<MediaRecorder | null>(null);
//   const webSocketRef = useRef<WebSocket | null>(null);
//   const streamRef = useRef<MediaStream | null>(null);
//   const setupTimeoutRef = useRef<NodeJS.Timeout | null>(null);
//   const silenceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
//   const speechEndTimeoutRef = useRef<NodeJS.Timeout | null>(null);
//   const lastActivityRef = useRef<number>(Date.now());
// const transcriptBufferRef = useRef<string>('');
//   const isSpeakingRef = useRef<boolean>(false);

//   const forceStop = () => {
//     console.log('Force stopping...');
// if (transcriptBufferRef.current.trim()) {
//   onTranscriptionResult(transcriptBufferRef.current.trim());
// }
//     setIsListening(false);
//     cleanup();
//   };

//   const cleanup = () => {
//     console.log('Cleaning up resources...');

//     // Clear all timeouts
//     if (setupTimeoutRef.current) {
//       clearTimeout(setupTimeoutRef.current);
//       setupTimeoutRef.current = null;
//     }
//     if (silenceTimeoutRef.current) {
//       clearTimeout(silenceTimeoutRef.current);
//       silenceTimeoutRef.current = null;
//     }
//     if (speechEndTimeoutRef.current) {
//       clearTimeout(speechEndTimeoutRef.current);
//       speechEndTimeoutRef.current = null;
//     }

//     // Stop media recorder
//     if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
//       try {
//         mediaRecorderRef.current.stop();
//       } catch (err) {
//         console.error('Error stopping media recorder:', err);
//       }
//       mediaRecorderRef.current = null;
//     }

//     // Stop all audio tracks
//     if (streamRef.current) {
//       streamRef.current.getTracks().forEach(track => {
//         track.stop();
//         track.enabled = false;
//       });
//       streamRef.current = null;
//     }

//     // Close WebSocket
//     if (webSocketRef.current) {
//       try {
//         if (webSocketRef.current.readyState === WebSocket.OPEN) {
//           webSocketRef.current.close();
//         }
//       } catch (err) {
//         console.error('Error closing websocket:', err);
//       }
//       webSocketRef.current = null;
//     }

//     // Reset references
// transcriptBufferRef.current = '';
// isSpeakingRef.current = false;
// lastActivityRef.current = Date.now();
//   };

//   const startListening = async () => {
//     try {
//       cleanup();

//       console.log('Starting Deepgram listening...');
//       const stream = await navigator.mediaDevices.getUserMedia({
//         audio: {
//           echoCancellation: true,
//           noiseSuppression: true,
//           autoGainControl: true
//         }
//       });
//       streamRef.current = stream;

//       if (!MediaRecorder.isTypeSupported('audio/webm')) {
//         throw new Error('Browser does not support WebM audio recording');
//       }

//       const wsUrl = new URL('wss://api.deepgram.com/v1/listen');
//       wsUrl.searchParams.append('punctuate', 'true');
//       wsUrl.searchParams.append('endpointing', 'true');
//       wsUrl.searchParams.append('vad', 'true');
//       wsUrl.searchParams.append('vad_turnoff', '500');
//       wsUrl.searchParams.append('interim_results', 'true');
//       wsUrl.searchParams.append('utterance_end_ms', '2000');

//       const socket = new WebSocket(wsUrl.toString(), [
//         'token',
//         apiKey
//       ]);

//       webSocketRef.current = socket;

//       socket.onopen = () => {
//         console.log('Deepgram WebSocket opened');
//         const mediaRecorder = new MediaRecorder(stream, {
//           mimeType: 'audio/webm'
//         });

//         mediaRecorderRef.current = mediaRecorder;

//         mediaRecorder.addEventListener('dataavailable', async (event) => {
//           if (event.data.size > 0 && socket.readyState === WebSocket.OPEN) {
//             socket.send(event.data);
//             lastActivityRef.current = Date.now();
//           }
//         });

//         mediaRecorder.start(250);
//         lastActivityRef.current = Date.now();
//         setIsListening(true);
//       };

// socket.onmessage = (message) => {
//   try {
//     const received = JSON.parse(message.data);

//     // Handle utterance end
//     if (received.type === 'UtteranceEnd') {
//       console.log('Utterance end received');
//       forceStop();
//       return;
//     }

//     // Handle speech events
//     if (received.type === 'Metadata') {
//       if (received.event === 'SpeechStarted') {
//         console.log('Speech started');
//         isSpeakingRef.current = true;
//         lastActivityRef.current = Date.now();

//         // Clear speech end timeout if exists
//         if (speechEndTimeoutRef.current) {
//           clearTimeout(speechEndTimeoutRef.current);
//           speechEndTimeoutRef.current = null;
//         }
//       } else if (received.event === 'SpeechEnded') {
//         console.log('Speech ended');
//         isSpeakingRef.current = false;

//         // Set timeout to stop if no new speech starts
//         speechEndTimeoutRef.current = setTimeout(() => {
//           if (!isSpeakingRef.current) {
//             console.log('No new speech detected after end, stopping');
//             forceStop();
//           }
//         }, 1000);
//       }
//       return;
//     }

//     // Handle transcript
//     const transcript = received.channel?.alternatives?.[0]?.transcript;
//     if (transcript) {
//       lastActivityRef.current = Date.now();

//       if (received.is_final) {
//         transcriptBufferRef.current += transcript + ' ';
//         console.log('Final transcript:', transcriptBufferRef.current);
//       }
//     }

//   } catch (err) {
//     console.error('Error processing message:', err);
//   }
// };

//       socket.onclose = () => {
//         console.log('Deepgram WebSocket closed');
//         forceStop();
//       };

//       socket.onerror = (error) => {
//         console.error('Deepgram WebSocket error:', error);
//         onError('Connection error occurred');
//         forceStop();
//       };

//     } catch (err) {
//       console.error('Error starting Deepgram:', err);
//       onError('Failed to start recording');
//       forceStop();
//     }
//   };

//   useEffect(() => {
//     if (isListening) {
//       setupTimeoutRef.current = setTimeout(() => {
//         startListening();
//       }, 500);
//     } else {
//       cleanup();
//     }

// return () => {
//   cleanup();
// };
//   }, [isListening]);

//   return null;
// };

// export default DeepgramSTT;

import React, { useRef, useEffect, useState } from "react";

interface DeepgramSTTProps {
  onTranscriptionResult: (text: string) => void;
  onError: (error: string) => void;
  isListening: boolean;
  setIsListening: (value: boolean) => void;
  clickNextQuestion: boolean;
  setClickNextQuestion: (value: boolean) => void;
  // apiKey: string;
}

const DeepgramSTT: React.FC<DeepgramSTTProps> = ({
  onTranscriptionResult,
  onError,
  isListening,
  setIsListening,
  clickNextQuestion,
  setClickNextQuestion,
  // apiKey,
}) => {
  // const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const webSocketRef = useRef<WebSocket | null>(null);
  // const streamRef = useRef<MediaStream | null>(null);
  const setupTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const silenceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const speechEndTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastActivityRef = useRef<number>(Date.now());
  const transcriptBufferRef = useRef<string>("");
  const isSpeakingRef = useRef<boolean>(false);
  const [transcript, setTranscript] = useState("");
  const wsRef = useRef<WebSocket | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startListening = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      const wsUrl = process.env.NEXT_PUBLIC_BACKEND_URL?.replace(
        "http://",
        "ws://"
      );
      // const ws = new WebSocket("ws://localhost:8000/ws/stt");
      const ws = new WebSocket(`${wsUrl}/speech/stt`);
      wsRef.current = ws;

      ws.onmessage = (message) => {
        // console.log("msg:::::", msg.data);
        // setTranscript((prev) => prev + " " + msg.data);
        try {
          const received = message.data;
          console.log("message", message);
          // Handle utterance end
          if (received.type === "UtteranceEnd") {
            console.log("Utterance end received");
            stopListening();
            return;
          }

          // Handle speech events
          if (received.type === "Metadata") {
            if (received.event === "SpeechStarted") {
              console.log("Speech started");
              isSpeakingRef.current = true;
              lastActivityRef.current = Date.now();

              // Clear speech end timeout if exists
              if (speechEndTimeoutRef.current) {
                clearTimeout(speechEndTimeoutRef.current);
                speechEndTimeoutRef.current = null;
              }
            } else if (received.event === "SpeechEnded") {
              console.log("Speech ended");
              isSpeakingRef.current = false;

              // Set timeout to stop if no new speech starts
              speechEndTimeoutRef.current = setTimeout(() => {
                if (!isSpeakingRef.current) {
                  console.log("No new speech detected after end, stopping");
                  stopListening();
                }
              }, 1000);
            }
            return;
          }

          // Handle transcript
          const transcript = message.data;
          if (transcript) {
            console.log("transcript:", transcript);
            lastActivityRef.current = Date.now();
            // if (received.is_final) {
            transcriptBufferRef.current += transcript + " ";
            console.log("Final transcript:", transcriptBufferRef.current);
            // }
          }
        } catch (err) {
          console.error("Error processing message:", err);
        }
      };
      ws.onclose = () => {
        console.log("WebSocket closed");
        stopListening();
      };

      ws.onopen = () => {
        mediaRecorder.start(250);
        mediaRecorder.ondataavailable = (e) => {
          if (e.data.size > 0 && ws.readyState === WebSocket.OPEN) {
            ws.send(e.data);
          }
        };
        setIsListening(true);
      };
    } catch (err) {
      console.error("Error starting recording:", err);
    }
  };

  const stopListening = () => {
    console.log(
      "transcriptBufferRef.current.trim()",
      transcriptBufferRef.current.trim(),
      " clickNextQuestion:",
      clickNextQuestion
    );
    if (transcriptBufferRef.current.trim() || clickNextQuestion) {
      setClickNextQuestion(false);
      if (transcriptBufferRef.current.trim()) {
        onTranscriptionResult(transcriptBufferRef.current.trim());
      } else if (clickNextQuestion) {
        onTranscriptionResult("No answer");
      }
      setIsListening(false);
    }
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current = null;
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    transcriptBufferRef.current = "";
    isSpeakingRef.current = false;
    lastActivityRef.current = Date.now();

    // setIsListening(false);
  };

  useEffect(() => {
    if (isListening) {
      // setupTimeoutRef.current = setTimeout(() => {
      startListening();
      // }, 500);
    } else {
      // onTranscriptionResult(transcript);
      // console.log("Final Transcript:", transcript);
      // setTranscript("");
      stopListening();
    }
  }, [isListening]);
  return null;
};

export default DeepgramSTT;
