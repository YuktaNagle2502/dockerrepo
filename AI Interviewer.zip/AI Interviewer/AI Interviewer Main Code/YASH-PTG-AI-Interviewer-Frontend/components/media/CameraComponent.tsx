import React, { useState, useRef, useEffect } from "react";
import { Camera } from "react-camera-pro";
import { useToast } from "@/hooks/use-toast";
import { authFetch } from "@/lib/authFetch";
import { ToastProvider, ToastTitle, ToastDescription } from "@/components/ui/toast";
import { Toaster } from "@/components/ui/toaster";

const CameraComponent: React.FC<{
  userImageUrl: string; // Changed from userImage to userImageUrl to clarify it's a URL
  image: any;
  setProceed: React.Dispatch<React.SetStateAction<boolean>>;
  setImage: React.Dispatch<React.SetStateAction<any>>;
  interview_id: any;
}> = ({ userImageUrl, image, setImage, setProceed, interview_id }) => {
  const camera = useRef<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleTakePhoto = () => {
    if (camera.current) {
      const capturedImage = camera.current.takePhoto();
      setImage(capturedImage);
    }
  };

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        console.log("Checking interview status for ID:", interview_id);
      } catch (error) {
        console.error("Error fetching interview status:", error);
      }
    };

    if (interview_id) {
      fetchStatus();
    }
  }, [interview_id]);

  const handleProceed = async () => {
     console.log("Proceed button clicked", { image, userImageUrl });
    // Validate both images are available
    if (!image || !userImageUrl) {
      setError("Both captured and stored images are required");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Create FormData
      const formData = new FormData();

      // Convert captured image (base64) to File
      const unknownImageFile = await base64ToFile(image, "unknown_image.jpg");

      // Fetch the stored image from Azure URL and convert to File
      const knownImageFile = await urlToFile(userImageUrl, "known_image.jpg");

      // Add both images to FormData
      formData.append("known_image", knownImageFile);
      formData.append("unknown_image", unknownImageFile);

      // Log FormData contents for debugging
      for (let pair of formData.entries()) {
        console.log(pair[0], pair[1]);
      }

      // Make API call
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL3}/compare_faces/`,
        {
          method: "POST",
          body: formData,
        }
      );

      // Check response
      if (!response.ok) {
        setProceed(true); // Temporary bypass for testing (remove in production)
        const errorText = await response.text();
        throw new Error(
          `HTTP error! status: ${response.status}, message: ${errorText}`
        );
      }

      // Parse response
      const result = await response.json();

      // Show toast based on match result
      if (result.match) {
        toast({
          title: "Face Verification",
          description: "Faces Match!",
        });
        setProceed(true);
      } else {
        toast({
          title: "Face Verification",
          description: "Faces Do Not Match",
          variant: "destructive",
        });
      }

      console.log("Face Recognition Result:", result);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "An unexpected error occurred"
      );
      console.log("API Error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Utility function to convert base64 to File (for captured image)
  const base64ToFile = async (base64: string, filename: string): Promise<File> => {
    const response = await fetch(base64); // Fetch base64 data
    const blob = await response.blob();
    return new File([blob], filename, { type: "image/jpeg" });
  };

  // Utility function to convert URL to File (for Azure image)
const urlToFile = async (url: string, filename: string): Promise<File> => {
  const response = await fetch(url, {
    method: "GET",
    mode: "cors", // Ensure CORS mode
  });
  if (!response.ok) {
    throw new Error(`Failed to fetch image from ${url}: ${response.statusText}`);
  }
  const blob = await response.blob();
  return new File([blob], filename, { type: "image/jpeg" });
};

  return (
    <ToastProvider>
      <div className="h-[20vh] flex-row items-center space-y-4 px-[40vh] py-8">
        {image === null ? (
          <div className="flex flex-col items-center gap-5 justify-center">
            <Camera
              ref={camera}
              errorMessages={{
                noCameraAccessible: "No camera found",
                permissionDenied: "Camera permission denied",
                switchCamera: "Unable to switch camera",
              }}
              aspectRatio={16 / 9}
              facingMode="user"
            />
            <button
              onClick={handleTakePhoto}
              className="mt-2 bg-blue-500 text-white px-4 py-2 rounded"
            >
              Take photo
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-6">
            <img
              src={image}
              alt="Taken photo"
              className="w-full max-w-[600px] max-h-[400px] rounded shadow-lg"
            />
            <div className="flex flex-row justify-center gap-8 w-full">
              <button
                onClick={() => {
                  setImage(null);
                }}
                disabled={isLoading}
                className="bg-blue-500 text-white px-4 py-2 rounded disabled:opacity-50"
              >
                X Clear Photo
              </button>
              <button
                onClick={handleProceed}
                disabled={isLoading}
                className="bg-blue-500 text-white px-4 py-2 rounded disabled:opacity-50"
              >
                {isLoading ? "Processing..." : "Proceed ->"}
              </button>
            </div>
          </div>
        )}
        <Toaster />
      </div>
    </ToastProvider>
  );
};

export default CameraComponent;