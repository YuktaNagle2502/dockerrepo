import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function WebRTCRecorder() {
  // State variables
  const [isRecording, setIsRecording] = useState(false);
  const [recordedBlobs, setRecordedBlobs] = useState<Blob[]>([]);
  const [supportedMimeTypes, setSupportedMimeTypes] = useState<string[]>([]);
  const [selectedMimeType, setSelectedMimeType] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [targetFPS] = useState(10); // Set desired FPS (e.g., 10 FPS)

  // Refs
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const gumVideoRef = useRef<HTMLVideoElement>(null);
  const recordedVideoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameExtractionRef = useRef<number | null>(null);
  const webSocketRef = useRef<WebSocket | null>(null);
  const lastFrameTimeRef = useRef<number>(0);

  // Get supported MIME types
  const getSupportedMimeTypes = (): string[] => {
    const possibleTypes = [
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm;codecs=h264,opus',
      'video/webm;codecs=av01,opus',
      'video/x-matroska;codecs=hvc1,opus',
      'video/mp4;codecs=h264,aac',
      'video/mp4;codecs=vp9,mp4a.40.2',
      'video/mp4;codecs=avc1,mp4a.40.2',
      'video/mp4;codecs=hvc1,mp4a.40.2',
      'video/mp4;codecs=av01,mp4a.40.2',
      'video/mp4',
    ];

    return possibleTypes.filter(mimeType => 
      MediaRecorder.isTypeSupported(mimeType)
    );
  };

  // Convert MIME type to file extension
  const mimeTypeToFileExtension = (mimeType: string) => {
    switch (mimeType.split(';', 1)[0]) {
      case 'video/mp4': return 'mp4';
      case 'video/webm': return 'webm';
      case 'video/x-matroska': return 'mkv';
      default: throw new Error(`Unsupported MIME type: ${mimeType}`);
    }
  };

  // Utility to convert data URI to Blob
  const dataURItoBlob = (dataURI: string) => {
    const byteString = atob(dataURI.split(',')[1]);
    const mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }

    return new Blob([ab], { type: mimeString });
  };

  // Frame extraction and WebSocket sending with FPS control
  const setupFrameExtraction = useCallback(() => {
    const video = gumVideoRef.current;
    const canvas = canvasRef.current;
   
    if (!video || !canvas || !webSocketRef.current) return null;

    const frameInterval = 1000 / targetFPS; // Calculate interval between frames

    const extractAndSendFrame = (timestamp: number) => {
      // Only process frame if enough time has passed since last frame
      if (!lastFrameTimeRef.current || timestamp - lastFrameTimeRef.current >= frameInterval) {
        if (webSocketRef.current && webSocketRef.current.readyState === WebSocket.OPEN) {
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;

          const context = canvas.getContext('2d');
          context?.drawImage(video, 0, 0, canvas.width, canvas.height);

          const frameBlob = dataURItoBlob(canvas.toDataURL('image/jpeg', 0.7));
       
          frameBlob.arrayBuffer().then(buffer => {
            webSocketRef.current?.send(buffer);
          });

          lastFrameTimeRef.current = timestamp; // Update last frame time
        }
      }

      frameExtractionRef.current = requestAnimationFrame(extractAndSendFrame);
    };

    frameExtractionRef.current = requestAnimationFrame(extractAndSendFrame);
    
    return () => {
      if (frameExtractionRef.current) {
        cancelAnimationFrame(frameExtractionRef.current);
      }
    };
  }, [targetFPS]);

  // Start WebSocket connection
  const startWebSocketConnection = useCallback(() => {
    if (webSocketRef.current) {
      webSocketRef.current.close();
    }

    const socket = new WebSocket(`${process.env.NEXT_PUBLIC_BACKEND_URL2}/frame-stream`);

    console.log('Connecting to WebSocket...');

    socket.onopen = () => {
      console.log('WebSocket connection established');
    };

    socket.onmessage = (event) => {
      const engagementResult = JSON.parse(event.data);
      console.log('Received engagement result:', engagementResult);
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      setErrorMsg('WebSocket connection error');
    };

    socket.onclose = () => {
      console.log('WebSocket connection closed');
    };

    webSocketRef.current = socket;
  }, []);

  // Start camera
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true },
        video: { width: 1280, height: 720 }
      });

      if (gumVideoRef.current) {
        gumVideoRef.current.srcObject = stream;
      }

      streamRef.current = stream;
      
      const supportedTypes = getSupportedMimeTypes();
      setSupportedMimeTypes(supportedTypes);
      
      if (supportedTypes.length > 0) {
        setSelectedMimeType(supportedTypes[0]);
      }

      setIsCameraActive(true);
      startWebSocketConnection();
      setupFrameExtraction();
    } catch (error) {
      console.error('Error accessing media devices:', error);
      setErrorMsg(`Error accessing media devices: ${String(error)}`);
    }
  };

  // Start recording
  const startRecording = () => {
    if (!streamRef.current) return;

    const blobs: Blob[] = [];
    setRecordedBlobs(blobs);

    try {
      const options = { mimeType: selectedMimeType };
      const mediaRecorder = new MediaRecorder(streamRef.current, options);

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          blobs.push(event.data);
          setRecordedBlobs([...blobs]);
        }
      };

      mediaRecorder.onstop = () => {
        if (recordedVideoRef.current && blobs.length > 0) {
          const superBuffer = new Blob(blobs, { type: selectedMimeType });
          recordedVideoRef.current.src = URL.createObjectURL(superBuffer);
          recordedVideoRef.current.load();
        }
      };

      mediaRecorder.start();
      mediaRecorderRef.current = mediaRecorder;
      setIsRecording(true);
    } catch (error) {
      console.error('Error creating MediaRecorder:', error);
      setErrorMsg(`Error creating MediaRecorder: ${String(error)}`);
    }
  };

  // Stop recording
  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // Download recorded video
  const downloadRecording = () => {
    if (recordedBlobs.length === 0) return;

    const blob = new Blob(recordedBlobs, { type: selectedMimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = `recording.${mimeTypeToFileExtension(selectedMimeType)}`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 100);
  };

  // Stop camera and connections
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
  
    if (webSocketRef.current) {
      if (webSocketRef.current.readyState === WebSocket.OPEN) {
        webSocketRef.current.close();
      }
      webSocketRef.current = null;
    }
  
    if (frameExtractionRef.current) {
      cancelAnimationFrame(frameExtractionRef.current);
      frameExtractionRef.current = null;
    }
  
    if (gumVideoRef.current) {
      gumVideoRef.current.srcObject = null;
    }
  
    streamRef.current = null;
    setIsCameraActive(false);
    setIsRecording(false);
    setErrorMsg('');
  };

  // Cleanup on component unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div className="max-w-xl mx-auto p-4 space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <video 
          ref={gumVideoRef} 
          id="gum" 
          className="w-full h-[200px] bg-black object-cover"
          playsInline 
          autoPlay 
          muted 
        />
        <video 
          ref={recordedVideoRef} 
          id="recorded" 
          className="w-full h-[200px] bg-black object-cover"
          playsInline 
          controls
        />
      </div>

      <canvas 
        ref={canvasRef} 
        className="w-full aspect-video bg-black hidden"
      />

      <div className="flex gap-4 items-center">
        <Button 
          onClick={startCamera} 
          disabled={isCameraActive}
        >
          Start Camera
        </Button>
        <Button 
          onClick={stopCamera}
          disabled={!isCameraActive}
        >
          Stop Camera
        </Button>
        <Button 
          onClick={isRecording ? stopRecording : startRecording}
          disabled={!streamRef.current}
        >
          {isRecording ? 'Stop Recording' : 'Start Recording'}
        </Button>
        <Button 
          onClick={downloadRecording}
          disabled={recordedBlobs.length === 0}
        >
          Download
        </Button>

        <Select 
          value={selectedMimeType} 
          onValueChange={setSelectedMimeType}
          disabled={isRecording}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select Format" />
          </SelectTrigger>
          <SelectContent>
            {supportedMimeTypes.map(type => (
              <SelectItem key={type} value={type}>{type}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {errorMsg && (
        <div className="text-red-500 mt-4">{errorMsg}</div>
      )}
    </div>
  );
}