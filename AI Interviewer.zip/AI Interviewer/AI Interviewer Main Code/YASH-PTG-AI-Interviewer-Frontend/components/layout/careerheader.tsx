"use client";

import Link from "next/link";
import Image from "next/image";
import logo from "@/public/yash_logo.png";

export default function Header() {
  return (
    <header className="py-4 px-4 md:px-6 flex items-center justify-between">
      <Link href="/job_description" className="text-2xl font-bold">
        <Image src={logo} width={80} height={30} alt="Logo" />
      </Link>
    </header>
  );
}
