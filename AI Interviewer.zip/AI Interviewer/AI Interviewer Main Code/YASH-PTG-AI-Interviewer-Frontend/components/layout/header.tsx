"use client";

import Link from "next/link";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import logo from "@/public/yash_logo.png";
import { useTheme } from "next-themes";
import { Moon, Sun } from "lucide-react";
import { useKeycloak } from "@/context/keycloakContext";

export default function Header() {
  const { theme, setTheme } = useTheme();
  const toggleTheme = () => setTheme(theme === "dark" ? "light" : "dark");

  const { keycloak, authenticated } = useKeycloak();
  const [showLogout, setShowLogout] = useState(false);

  // Debug logging
  console.log(
    "Header - authenticated:",
    authenticated !== undefined ? authenticated : "Not defined"
  );
  console.log("Header - keycloak:", keycloak);
  console.log("Header - keycloak.authenticated:", keycloak?.authenticated);
  // console.log('User name:', keycloak.tokenParsed?.name);
  // console.log('User email:', keycloak.tokenParsed?.email);

  // Check if keycloak is ready
  if (!keycloak) {
    return null; // or a loading spinner
  }
  const handleLogout = () => {
    localStorage.removeItem("accessToken");
    if (keycloak) {
      keycloak.logout({ redirectUri: window.location.origin });
    }
  };

  const userName = keycloak.tokenParsed?.name || "User";
  const avatarLetter = userName.charAt(0).toUpperCase();

  return (
    <header className="py-4 px-4 md:px-6 flex items-center justify-between">
      <Link href="/job_description" className="text-2xl font-bold">
        <Image src={logo} width={80} height={30} alt="Logo" />
      </Link>
      <div className="flex items-center">
        {/* Show user's avatar and name if authenticated */}

        <div className="flex items-center space-x-6 ml-4">
          <Button variant="outline" size="icon" onClick={toggleTheme}>
            {theme === "dark" ? (
              <Sun className="h-[1.2rem] w-[1.2rem]" />
            ) : (
              <Moon className="h-[1.2rem] w-[1.2rem]" />
            )}
            <span className="sr-only">Toggle theme</span>
          </Button>

          <nav>
            <ul className="flex space-x-6 items-center">
              <li>
                <Link
                  href="/registered_users"
                  className="text-muted-foreground hover:text-foreground"
                >
                  Registered Users
                </Link>
              </li>
              <li>
                <Link
                  href="/job_description"
                  className="text-muted-foreground hover:text-foreground"
                >
                  JD
                </Link>
              </li>
              <li>
                <Link
                  href="/careers"
                  className="text-muted-foreground hover:text-foreground"
                >
                  Careers
                </Link>
              </li>
              <li>
                <Link
                  href="/model"
                  className="text-muted-foreground hover:text-foreground"
                >
                  Models
                </Link>
              </li>
               <li>
                <Link
                  href="/prompts"
                  className="text-muted-foreground hover:text-foreground"
                >
                  Prompt 
                </Link>
              </li>
              <li>
                <Link
                  href="/access-denied"
                  className="text-muted-foreground hover:text-foreground"
                >
                  AccessDeniedPage
                </Link>
              </li>

              {(authenticated || keycloak?.authenticated) && (
                <li className="relative">
                  <button
                    className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-200 text-gray-800 font-bold hover:bg-gray-300 transition-colors"
                    onClick={() => setShowLogout(!showLogout)}
                  >
                    {avatarLetter}
                  </button>

                  {/* Logout dropdown - positioned below avatar */}
                  {showLogout && (
                    <div className="absolute top-full right-0 mt-2 z-50">
                      <Button
                        variant="outline"
                        onClick={handleLogout}
                        className="whitespace-nowrap shadow-lg"
                      >
                        Logout
                      </Button>
                    </div>
                  )}
                </li>
              )}

              {/* Show sign in button if not authenticated */}
              {!(authenticated || keycloak?.authenticated) && (
                <li>
                  <Button variant="outline" onClick={() => keycloak.login()}>
                    Sign In
                  </Button>
                </li>
              )}
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
}
