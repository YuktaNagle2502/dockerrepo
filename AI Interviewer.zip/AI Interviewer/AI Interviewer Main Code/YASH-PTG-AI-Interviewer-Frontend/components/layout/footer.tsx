import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="py-6 px-4 md:px-6 border-t">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
        <p className="text-sm text-muted-foreground">© 2025 Yash Technologies. All rights reserved.</p>
        <nav className="mt-4 md:mt-0">
          <ul className="flex space-x-4">
            <li><Link href="#" className="text-sm text-muted-foreground hover:text-foreground">Privacy Policy</Link></li>
            <li><Link href="#" className="text-sm text-muted-foreground hover:text-foreground">Terms of Service</Link></li>
            <li><Link href="#" className="text-sm text-muted-foreground hover:text-foreground">Contact Us</Link></li>
          </ul>
        </nav>
      </div>
    </footer>
  )
}

