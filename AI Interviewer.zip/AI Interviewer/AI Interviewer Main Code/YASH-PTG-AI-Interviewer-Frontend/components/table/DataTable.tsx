import React from 'react';
import {
    Table,
    TableBody,
    TableCaption,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"

interface DataEntry {
    Timestamp: string;
    Status: number;
    Engaged_Frames: number;
    Disengaged_Frames: number;
}

interface DataTableProps {
    invoices: DataEntry[];
    caption?: string;
}

export function DataTable({ 
    invoices, 
    caption = "Data Table" 
}: DataTableProps) {
    return (
        <Table>
            <TableCaption className="font-bold">{caption}</TableCaption>
            <TableHeader>
                <TableRow>
                    <TableHead className="font-bold text-sm">Timestamp</TableHead>
                    <TableHead className="font-bold text-sm">Status</TableHead>
                    <TableHead className="font-bold text-sm">Engaged Frames</TableHead>
                    <TableHead className="font-bold text-sm">Disengaged Frames</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {invoices.map((entry, index) => (
                    <TableRow key={index}>
                        <TableCell>{entry.Timestamp}</TableCell>
                        <TableCell>{entry.Status}</TableCell>
                        <TableCell>{entry.Engaged_Frames}</TableCell>
                        <TableCell>{entry.Disengaged_Frames}</TableCell>
                    </TableRow>
                ))}
            </TableBody>
        </Table>
    )
}