import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mic, Speaker } from "lucide-react";
import DeepgramSTT from "@/components/media/DeepgramSTT";
import { Button } from "@/components/ui/button";

interface InterviewQuestionPageProps {
  interviewId: string;
  isInterviewOver: boolean;
  setIsInterviewOver: (value: boolean) => void;
  questionAnswer: Array<{
    question: string;
    reference_answer: string;
    user_answer: string;
    ai_comment: string;
  }>;
  setQuestionAnswer: React.Dispatch<
    React.SetStateAction<
      Array<{
        question: string;
        reference_answer: string;
        user_answer: string;
        ai_comment: string;
      }>
    >
  >;
}

const InterviewQuestionPage: React.FC<InterviewQuestionPageProps> = ({
  interviewId,
  isInterviewOver,
  setIsInterviewOver,
  questionAnswer,
  setQuestionAnswer,
}) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(-1); // Start at -1
  const [displayedQuestionIndex, setDisplayedQuestionIndex] = useState(0);
  const [error, setError] = useState("");
  const [isStaticLoading, setIsStaticLoading] = useState(false);
  const [isDynamicLoading, setIsDynamicLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [clickNextQuestion, setClickNextQuestion] = useState(false);

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showListening, setShowListening] = useState(false);
  const [interviewQuestions, setInterviewQuestions] = useState<
    Array<{
      question: string;
      answer: string;
    }>
  >([]);
  const [staticQuestionCount, setStaticQuestionCount] = useState(0);
  const [dynamicQuestionCount, setDynamicQuestionCount] = useState(0);
  const [isProcessingQuestion, setIsProcessingQuestion] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const wsRef = useRef<WebSocket | null>(null);
  const latestQuestionsRef = useRef<
    Array<{
      question: string;
      answer: string;
    }>
  >([]);

  useEffect(() => {
    latestQuestionsRef.current = interviewQuestions;
  }, [interviewQuestions]);

  // Fetch initial questions
  useEffect(() => {
    const fetchInterviewQuestions = async () => {
      if (interviewQuestions.length > 0) return;

      try {
        setIsStaticLoading(true);
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/get_question/${interviewId}`
        );

        if (!response.ok) {
          throw new Error("Failed to fetch interview questions");
        }

        const data = await response.json();
        if (data) {
          console.log("data:", data);
          const parsedQuestions = data.data;
          console.log("parsedQuestions:", parsedQuestions);
          setInterviewQuestions(parsedQuestions);
          setStaticQuestionCount(parsedQuestions.length);
        } else {
          setError("No questions found for this interview");
        }
      } catch (error) {
        console.error("Error fetching interview questions:", error);
        setError("Failed to load questions");
      } finally {
        setIsStaticLoading(false);
      }
    };

    fetchInterviewQuestions();
  }, [interviewId, interviewQuestions.length]);

  useEffect(() => {
    let timer: NodeJS.Timeout | undefined;
    if (isListening) {
      timer = setTimeout(() => {
        setShowListening(true);
      }, 3000); // 3-second delay
    } else {
      setShowListening(false); // Reset when not listening
    }

    return () => {
      if (timer) clearTimeout(timer); // Cleanup on unmount or state change
    };
  }, [isListening]);

  const cleanupConnections = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    if (wsRef.current) {
      if (wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.close();
      }
      wsRef.current = null;
    }
    audioChunksRef.current = [];
    setIsSpeaking(false);
  };

  const speakQuestion = async (question: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      cleanupConnections();

      const wsUrl = process.env.NEXT_PUBLIC_BACKEND_URL?.replace(
        "http://",
        "ws://"
      );
      console.log("Connecting to WebSocket URL:", wsUrl);
      wsRef.current = new WebSocket(`${wsUrl}/speech/tts`);

      setIsSpeaking(true);
      let isAudioStarted = false;

      wsRef.current.onopen = () => {
        console.log("TTS WebSocket opened");
        wsRef.current?.send(question);
      };

      wsRef.current.onmessage = async (event) => {
        if (event.data instanceof Blob) {
          try {
            audioChunksRef.current.push(event.data);

            if (!isAudioStarted) {
              isAudioStarted = true;

              await new Promise((resolve) => setTimeout(resolve, 500));

              const audioBlob = new Blob(audioChunksRef.current, {
                type: "audio/mp3",
              });
              const audioUrl = URL.createObjectURL(audioBlob);

              audioRef.current = new Audio(audioUrl);
              audioRef.current.onended = () => {
                URL.revokeObjectURL(audioUrl);
                setIsSpeaking(false);
                cleanupConnections();
                resolve();
              };

              audioRef.current.onerror = (error) => {
                console.error("Audio playback error:", error);
                cleanupConnections();
                reject(error);
              };

              await audioRef.current.play();
            }
          } catch (error) {
            console.error("Audio processing error:", error);
            cleanupConnections();
            reject(error);
          }
        }
      };

      wsRef.current.onerror = (error) => {
        console.error("TTS WebSocket error:", error);
        cleanupConnections();
        reject(error);
      };

      wsRef.current.onclose = () => {
        console.log("TTS WebSocket closed");
      };
    });
  };

  const handleInterviewProgress = () => {
    const nextIndex = currentQuestionIndex + 1;

    if (nextIndex >= latestQuestionsRef.current.length) {
      console.log("Interview complete");
      setIsInterviewOver(true);
    } else {
      setCurrentQuestionIndex(nextIndex);
      setDisplayedQuestionIndex(nextIndex);
      setTimeout(() => processQuestion(nextIndex), 200);
    }
  };

  const handleTranscriptionResult = async (text: string) => {
    console.log("Received answer:", text);
    const currentQuestion = interviewQuestions[currentQuestionIndex];

    setQuestionAnswer((prev) => [
      ...prev,
      {
        question: currentQuestion.question,
        reference_answer: currentQuestion.answer,
        user_answer: text,
        ai_comment: text, 
      },
    ]);

    setIsListening(false);

    if (
      currentQuestionIndex >= staticQuestionCount - 1 &&
      dynamicQuestionCount < 2
    ) {
      console.log("Attempting to fetch dynamic question");
      try {
        setIsDynamicLoading(true);
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BACKEND_URL}/question/generate_dynamic_question_autogen_resume/${interviewId}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              question: currentQuestion.question,
              reference_answer: currentQuestion.answer,
              user_answer: text,
              ai_comment: text, // Assuming you want to store the AI comment as well
            }),
          }
        );

        if (response.ok) {
          const data = await response.json();
          console.log("Received dynamic question:", data);
          setIsDynamicLoading(false);

          // Update ref and state together
          const newQuestions = [...interviewQuestions, data];
          latestQuestionsRef.current = newQuestions;

          setInterviewQuestions(newQuestions);
          console.log("Updated questions array:", newQuestions);

          // Short delay to ensure state updates
          await new Promise((resolve) => setTimeout(resolve, 100));

          setDynamicQuestionCount((prev) => prev + 1);

          const nextIndex = currentQuestionIndex + 1;
          console.log("Preparing to process dynamic question:", {
            nextIndex,
            totalQuestions: newQuestions.length,
            nextQuestion: newQuestions[nextIndex]?.question,
          });

          setCurrentQuestionIndex(nextIndex);
          setDisplayedQuestionIndex(nextIndex);

          // Wait for state updates
          await new Promise((resolve) => setTimeout(resolve, 100));

          // Verify question exists before processing
          if (latestQuestionsRef.current[nextIndex]) {
            console.log("Starting dynamic question processing");
            await processQuestion(nextIndex);
          } else {
            console.error("Dynamic question not found in state");
          }
        }
      } catch (error) {
        console.error("Error fetching dynamic question:", error);
      } finally {
      }
    } else {
      handleInterviewProgress();
    }
  };

  const processQuestion = async (questionIndex: number) => {
    console.log("Processing question attempt:", {
      questionIndex,
      totalQuestions: latestQuestionsRef.current.length,
      availableQuestions: latestQuestionsRef.current,
    });

    if (questionIndex >= latestQuestionsRef.current.length) {
      console.error("Question index out of bounds:", {
        questionIndex,
        totalQuestions: latestQuestionsRef.current.length,
      });
      return;
    }

    if (isProcessingQuestion) {
      console.log("Already processing a question");
      return;
    }

    const questionToProcess = latestQuestionsRef.current[questionIndex];
    console.log("questionToProcess:", questionToProcess);
    if (!questionToProcess) {
      console.error("Question not found in ref");
      return;
    }

    setIsProcessingQuestion(true);

    try {
      setIsListening(false);
      console.log("Starting TTS for question:", questionToProcess.question);

      await speakQuestion(questionToProcess.question);
      console.log("TTS completed");

      await new Promise((resolve) => setTimeout(resolve, 500));

      console.log("Starting STT");
      setIsListening(true);
    } catch (error) {
      console.error("Error processing question:", error);
      setError("Failed to process question");
    } finally {
      setIsProcessingQuestion(false);
    }
  };

  // Start interview when questions are loaded
  useEffect(() => {
    if (
      interviewQuestions.length > 0 &&
      !isInterviewOver &&
      currentQuestionIndex === -1
    ) {
      setCurrentQuestionIndex(0);
      processQuestion(0);
    }
  }, [interviewQuestions, isInterviewOver, currentQuestionIndex]);

  useEffect(() => {
    return () => {
      cleanupConnections();
    };
  }, []);

  if (isStaticLoading || isDynamicLoading) {
    return (
     <Card className="w-[750px] ml-[-30px] mt-10 min-h-[200px] border-0 bg-white dark:bg-black">
  <CardContent className="flex items-center justify-center py-16">
    <div className="flex items-center gap-3 text-center text-xl text-gray-500 dark:text-white">
      <svg
        className="animate-spin h-6 w-6 text-blue-500"
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 24 24"
      >
        <circle
          className="opacity-25"
          cx="12"
          cy="12"
          r="10"
          stroke="currentColor"
          strokeWidth="4"
        />
        <path
          className="opacity-75"
          fill="currentColor"
          d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
        />
      </svg>
      Loading question...
    </div>
  </CardContent>
</Card>

    );
  }

  if (error) {
    return (
      <Card className="w-[750px] ml-[-30px] mt-10 min-h-[200px]">
        <CardContent className="flex items-center justify-center py-16">
          <div className="text-center text-xl text-red-500">Error: {error}</div>
        </CardContent>
      </Card>
    );
  }

  if (isInterviewOver) {
    return (
      <Card className="w-[50vw] mt-10 min-h-[80px]">
        <CardContent className="py-8">
          <div className="text-center text-xl">
            Interview completed
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-[700px] mt-10 min-h-[200px] ml-17">
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Interview Question</span>
          {/* <span className="text-sm text-gray-500">
            Using: Deepgram
          </span> */}
            </CardTitle>
    </CardHeader>
    <CardContent className="pb-6">
      <div className="text-center text-xl font-medium mb-6 px-4 py-4 min-h-[80px] flex items-center justify-center">
        {interviewQuestions[displayedQuestionIndex]?.question ||
          "Loading question..."}
      </div>

        <div className="w-full bg-gray-200 h-1 mb-6">
          <div
            className="bg-blue-500 h-1 transition-all duration-500"
            style={{
              width: `${
                ((displayedQuestionIndex + 1) / (staticQuestionCount + 2)) * 100
              }%`,
            }}
          />
        </div>

        <div className="status mb-4">
          {isSpeaking ? (
            <div className="flex items-center justify-center gap-2 text-blue-500">
              <Speaker className="animate-pulse" />
              <span>Speaking question...</span>
            </div>
          ) : isListening ? (
            <div className="flex items-center justify-center gap-2 text-green-500">
              <Mic className="animate-pulse" />
              <span>Listening for your answer...</span>
            </div>
          ) : null}
        </div>

        {isListening && (
          <div className="flex justify-center mb-4">
            <Button
              variant="outline"
              className="w-[15vh] bg-green-500 hover:bg-green-600 text-white text-center"
              size="sm"
              onClick={() => {
                setClickNextQuestion(true);
                setIsListening(false);
              }}
            >
              Next Question
            </Button>
          </div>
        )}

        <DeepgramSTT
          onTranscriptionResult={handleTranscriptionResult}
          onError={setError}
          isListening={isListening}
          setIsListening={setIsListening}
          clickNextQuestion={clickNextQuestion}
          setClickNextQuestion={setClickNextQuestion}
        />
      </CardContent>
    </Card>
  );
};

export default InterviewQuestionPage;