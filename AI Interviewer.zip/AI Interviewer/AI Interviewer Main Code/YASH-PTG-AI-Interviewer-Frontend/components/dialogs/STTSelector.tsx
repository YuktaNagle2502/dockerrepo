import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

export type STTMethod = 'webspeech' | 'deepgram';

interface STTSelectorProps {
  onSelect: (method: STTMethod) => void;
  selectedMethod: STTMethod | null;
}

const STTSelector: React.FC<STTSelectorProps> = ({ onSelect, selectedMethod }) => {
  return (
    <div className="flex justify-center gap-4 mb-8">
      {/* <Card 
        className={`w-48 cursor-pointer transition-all ${
          selectedMethod === 'webspeech' 
            ? 'ring-2 ring-blue-500 bg-blue-50 dark:bg-gray-900' 
            : 'hover:bg-gray-50 dark:hover:bg-gray-800'
        }`}
        onClick={() => onSelect('webspeech')}
      >
        <CardContent className="flex flex-col items-center justify-center p-6">
          <div className="text-xl mb-2">🎤</div>
          <div className="font-medium text-center text-black dark:text-white">WebSpeech API</div>
          <div className="text-sm text-gray-500 dark:text-gray-400 text-center mt-2">
            Browser-native speech recognition
          </div>
        </CardContent>
      </Card> */}

      <Card 
        className={`w-48 cursor-pointer transition-all ${
          selectedMethod === 'deepgram' 
            ? 'ring-2 ring-blue-500 bg-blue-50 dark:bg-gray-900' 
            : 'hover:bg-gray-50 dark:hover:bg-gray-800'
        }`}
        onClick={() => onSelect('deepgram')}
      >
        <CardContent className="flex flex-col items-center justify-center p-6">
          <div className="text-xl mb-2">🎙️</div>
          <div className="font-medium text-center text-black dark:text-white">Deepgram API</div>
          <div className="text-sm text-gray-500 dark:text-gray-400 text-center mt-2">
            Professional speech recognition
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default STTSelector;