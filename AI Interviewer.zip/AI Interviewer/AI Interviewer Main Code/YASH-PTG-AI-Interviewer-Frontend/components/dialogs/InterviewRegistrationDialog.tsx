"use client";

import React, { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import * as z from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { authFetch } from "@/lib/authFetch";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

// Enhanced form validation schema with stricter validations
const formSchema = z.object({
  fullName: z.string().min(1, "Full name is required"),
  age: z
    .string()
    .min(1, "Age is required")
    .regex(/^[1-9][0-9]?$/, "Age must be a valid number between 1-99")
    .refine((val) => {
      const num = parseInt(val);
      return num >= 18 && num <= 99;
    }, "Age must be between 18 and 99"),
  sex: z.string().min(1, "Gender is required"),
  phone: z
    .string()
    .min(1, "Phone number is required")
    .regex(
      /^[0-9]{10}$/,
      "Phone number must be exactly 10 digits with no special characters"
    ),
  email: z
    .string()
    .min(1, "Email is required")
    .email("Please enter a valid email address")
    .regex(
      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
      "Email format is invalid"
    ),
  job_id: z.string().min(1, "Job ID is required"),
  scheduled_date: z
    .string()
    .min(1, "Scheduled date is required")
    .regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format"),
  time_slot: z.string().min(1, "Time slot is required"),
  domain: z.string().optional(),
  resume: z.instanceof(File, { message: "Resume is required" }),
  user_img: z.instanceof(File, { message: "Profile image is required" }),
  File_based: z.instanceof(File).optional(),
  uuid: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

interface InterviewRegistrationDialogProps {
  children: React.ReactNode;
  job_id: number;
  job_title?: string;
  onRegistrationSuccess?: () => void;
}

export default function InterviewRegistrationDialog({
  children,
  job_id,
  job_title,
  onRegistrationSuccess,
}: InterviewRegistrationDialogProps) {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState<boolean>(false);

  // Available time slots
  const timeSlots = [
    "8AM to 8:30AM",
    "8:30AM to 9AM",
    "9AM to 9:30AM",
    "9:30AM to 10AM",
    "10AM to 10:30AM",
    "10:30AM to 11AM",
    "11AM to 11:30AM",
    "11:30AM to 12PM",
    "12PM to 12:30PM",
    "12:30PM to 1PM",
    "1PM to 1:30PM",
    "1:30PM to 2PM",
    "2PM to 2:30PM",
    "2:30PM to 3PM",
    "3PM to 3:30PM",
    "3:30PM to 4PM",
    "4PM to 4:30PM",
    "4:30PM to 5PM",
    "5PM to 5:30PM",
    "5:30PM to 6PM",
    "6PM to 6:30PM",
    "6:30PM to 7PM",
    "7PM to 7:30PM",
    "7:30PM to 8PM",
    "8PM to 8:30PM",
    "8:30PM to 9PM",
  ];

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      age: "",
      sex: "",
      phone: "",
      resume: undefined,
      email: "",
      job_id: job_id.toString(),
      scheduled_date: "",
      time_slot: "",
      user_img: undefined,
      domain: "",
      File_based: undefined,
      uuid: uuidv4(),
    },
  });

  // Helper function to handle phone number input (only allow digits)
  const handlePhoneInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, ""); // Remove all non-digit characters
    e.target.value = value;
    return value;
  };

  // Helper function to handle age input (only allow 1-2 digits)
  const handleAgeInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, ""); // Remove all non-digit characters
    if (value.length <= 2) {
      e.target.value = value;
      return value;
    } else {
      e.target.value = value.slice(0, 2); // Limit to 2 digits
      return value.slice(0, 2);
    }
  };

  // Helper function to convert file to base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          resolve(reader.result);
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // Function to check candidate qualification
  const checkCandidateQualification = async (uniqueId: string): Promise<boolean> => {
    try {
      const BASE_URL = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";
      const response = await authFetch(`${BASE_URL}/interview/candidate-details/${uniqueId}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        console.error("Failed to check qualification:", response.status);
        return true; // Return true to not block the process if API fails
      }

      const data = await response.json();
      console.log("Qualification check response:", data);

      if (data.success && data.data) {
        return data.data.qualified === true;
      }

      return true; // Default to qualified if response structure is unexpected
    } catch (error) {
      console.error("Error checking qualification:", error);
      return true; // Return true to not block the process if API fails
    }
  };

  // Form submission handler
  async function onSubmit(values: FormValues): Promise<void> {
    try {
      // Validate required files
      if (!values.resume || !(values.resume instanceof File)) {
        throw new Error("Resume must be a valid file");
      }

      if (!values.user_img || !(values.user_img instanceof File)) {
        throw new Error("User image must be a valid file");
      }

      const formData = new FormData();

      // Convert user image to base64
      const user_img_content = await fileToBase64(values.user_img);

      // Append all required fields
      formData.append("full_name", values.fullName);
      formData.append("unique_id", values.uuid);
      formData.append("age", values.age.toString());
      formData.append("sex", values.sex);
      formData.append("phone", values.phone);
      formData.append("email_id", values.email);
      formData.append("job_id", values.job_id.toString());
      formData.append("scheduled_date", values.scheduled_date);
      formData.append("time_slot", values.time_slot);
      formData.append("resume", values.resume);
      formData.append("user_image", user_img_content);

      // Optional: domain
      formData.append("domain", values.domain ?? "null");

      // DEBUG log
      console.log("Submitting form data:");
      for (const pair of formData.entries()) {
        console.log(`${pair[0]}: ${pair[1]}`);
      }

      // API Call
      const BASE_URL =
        process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";
      const response = await fetch(`${BASE_URL}/interview/schedule_interview`, {
        method: "POST",
        body: formData,
      });

      console.log("Response status:", response.status);
      console.log(
        "Response headers:",
        Object.fromEntries(response.headers.entries())
      );

      if (!response.ok) {
        const errorData = await response.json();
        console.error("Error response:", errorData);
        throw new Error(errorData.detail || "Registration failed");
      }

      const responseData = await response.json();
      console.log("Success response:", responseData);

      // Check candidate qualification after successful registration
      const isQualified = await checkCandidateQualification(values.uuid);

      if (!isQualified) {
        toast({
          title: "Registration Unsuccessful",
          description: "Candidate not qualified",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Success",
          description: "User registered successfully and qualified for the position",
        });
        
        // Call the success callback only if qualified
        onRegistrationSuccess?.();
      }

      // Reset form and close dialog regardless of qualification
      form.reset({
        fullName: "",
        age: "",
        sex: "",
        phone: "",
        resume: undefined,
        email: "",
        job_id: job_id.toString(),
        scheduled_date: "",
        time_slot: "",
        user_img: undefined,
        domain: "",
        File_based: undefined,
        uuid: uuidv4(), // Generate new UUID for next registration
      });

      // Close the dialog
      setIsOpen(false);

    } catch (error) {
      console.error("Submit error:", error);
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to register user",
        variant: "destructive",
      });
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[560px] max-h-[100vh]">
        <DialogHeader>
          <DialogTitle>
            {job_title ? `Register for ${job_title}` : "Register for Interview"}
          </DialogTitle>
          <DialogDescription>
            Fill in your details to register for the interview
            {job_title && ` for ${job_title}`}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="h-[80vh] overflow-y-auto p-4"
          >
            <div className="flex flex-wrap gap-4">
              <div className="flex-1 min-w-[300px]">
                <FormField
                  control={form.control}
                  name="job_id"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="after:content-['*'] after:ml-0.5 after:text-red-500">
                        Job ID
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Enter Job ID"
                          {...field}
                          readOnly
                          // className="bg-gray-50 cursor-not-allowed"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Full Name and Age */}
              <div className="flex-1 min-w-[300px]">
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="after:content-['*'] after:ml-0.5 after:text-red-500">
                        Full Name
                      </FormLabel>
                      <FormControl>
                        <Input placeholder="Enter full name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex-1 min-w-[300px]">
                <FormField
                  control={form.control}
                  name="age"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="after:content-['*'] after:ml-0.5 after:text-red-500">
                        Age
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Enter age"
                          {...field}
                          onChange={(e) => {
                            const value = handleAgeInput(e);
                            field.onChange(value);
                          }}
                          maxLength={2}
                        />
                      </FormControl>
                      <FormDescription>
                        Age must be between 18 and 99
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Gender and Phone */}
              <div className="flex-1 min-w-[300px]">
                <FormField
                  control={form.control}
                  name="sex"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="after:content-['*'] after:ml-0.5 after:text-red-500">
                        Gender
                      </FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select gender" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex-1 min-w-[300px]">
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="after:content-['*'] after:ml-0.5 after:text-red-500">
                        Phone Number
                      </FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Enter phone number"
                          {...field}
                          onChange={(e) => {
                            const value = handlePhoneInput(e);
                            field.onChange(value);
                          }}
                          maxLength={10}
                        />
                      </FormControl>
                      <FormDescription>
                        Phone number must be exactly 10 digits (no special
                        characters)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Email */}
              <div className="flex-1 min-w-[300px]">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="after:content-['*'] after:ml-0.5 after:text-red-500">
                        Email
                      </FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          placeholder="Enter valid email address"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Please enter a valid email address (e.g.,
                        user@example.com)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Scheduled Date */}
              <div className="flex-1 min-w-[300px]">
                <FormField
                  control={form.control}
                  name="scheduled_date"
                  render={({ field }) => {
                    const today = new Date();
                    const minDate = today.toISOString().split("T")[0];
                    const maxDateObj = new Date(today);
                    maxDateObj.setDate(today.getDate() + 6); // today + 6 = 7 days including today
                    const maxDate = maxDateObj.toISOString().split("T")[0];

                    return (
                      <FormItem>
                        <FormLabel className="after:content-['*'] after:ml-0.5 after:text-red-500">
                          Scheduled Date
                        </FormLabel>
                        <FormControl>
                          <Input
                            type="date"
                            {...field}
                            min={minDate}
                            max={maxDate}
                          />
                        </FormControl>
                        <FormDescription>
                          Select your preferred interview date (within next 7 days)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    );
                  }}
                />
              </div>

              {/* Time Slot */}
              <div className="flex-1 min-w-[300px]">
                <FormField
                  control={form.control}
                  name="time_slot"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="after:content-['*'] after:ml-0.5 after:text-red-500">
                        Time Slot
                      </FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select time slot" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {timeSlots.map((slot) => (
                            <SelectItem key={slot} value={slot}>
                              {slot}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Choose your preferred interview time slot
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Domain and Resume */}
              <div className="flex-1 min-w-[300px]">
                <FormField
                  control={form.control}
                  name="domain"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Domain (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter domain" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex-1 min-w-[300px]">
                <FormField
                  control={form.control}
                  name="resume"
                  render={({ field: { onChange, value, ...field } }) => (
                    <FormItem>
                      <FormLabel className="after:content-['*'] after:ml-0.5 after:text-red-500">
                        Resume
                      </FormLabel>
                      <FormControl>
                        <Input
                          type="file"
                          accept=".pdf,.doc,.docx"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            onChange(file);
                          }}
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Upload your resume (PDF or Word document)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Profile Image */}
              <div className="w-full">
                <FormField
                  control={form.control}
                  name="user_img"
                  render={({ field: { onChange, value, ...field } }) => (
                    <FormItem>
                      <FormLabel className="after:content-['*'] after:ml-0.5 after:text-red-500">
                        Profile Image
                      </FormLabel>
                      <FormControl>
                        <div className="space-y-2">
                          <Input
                            type="file"
                            accept="image/*"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              onChange(file);
                            }}
                            {...field}
                          />
                          {value && (
                            <div className="mt-2">
                              <img
                                src={URL.createObjectURL(value)}
                                alt="Preview"
                                className="w-32 h-32 object-cover rounded"
                              />
                            </div>
                          )}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Submit Button */}
              <div className="w-full mt-6">
                <Button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  disabled={form.formState.isSubmitting}
                >
                  {form.formState.isSubmitting ? "Submitting..." : "Register"}
                </Button>
              </div>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}