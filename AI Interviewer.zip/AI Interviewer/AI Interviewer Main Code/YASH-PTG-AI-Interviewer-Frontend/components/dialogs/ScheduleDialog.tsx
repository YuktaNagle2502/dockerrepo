"use client";

import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { authFetch } from "@/lib/authFetch";

interface User {
  id: string;
  fullName: string;
  phone: string;
}

interface ScheduleDialogProps {
  open: boolean;
  onClose: () => void;
  onSchedule: (userId: string) => Promise<void>;
}

const ScheduleDialog: React.FC<ScheduleDialogProps> = ({
  open,
  onClose,
  onSchedule,
}) => {
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUser, setSelectedUser] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await authFetch(
          `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/get_users`
        );
        if (!response.ok) {
          throw new Error("Failed to fetch users");
        }
        const data: User[] = await response.json();
        setUsers(data);
      } catch (error) {
        console.error("Failed to fetch users:", error);
      } finally {
        setLoading(false);
      }
    };

    if (open) {
      void fetchUsers();
      setSelectedUser(""); // Reset selection when dialog opens
    }
  }, [open]);

  const handleSchedule = async () => {
    if (selectedUser) {
      try {
        await onSchedule(selectedUser);
        onClose();
      } catch (error) {
        console.error("Failed to schedule interview:", error);
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Schedule Interview</DialogTitle>
          <DialogDescription>
            Select a candidate to schedule the interview for
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 pt-4">
          <Select
            value={selectedUser}
            onValueChange={setSelectedUser}
            disabled={loading}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a candidate" />
            </SelectTrigger>
            <SelectContent>
              {users.map((user) => (
                <SelectItem key={user.id} value={user.id}>
                  {user.fullName} ({user.phone})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              onClick={() => void handleSchedule()}
              disabled={!selectedUser || loading}
            >
              Schedule Interview
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ScheduleDialog;
