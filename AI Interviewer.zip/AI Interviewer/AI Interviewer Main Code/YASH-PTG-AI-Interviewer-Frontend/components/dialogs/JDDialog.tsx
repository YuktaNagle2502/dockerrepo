import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { authFetch } from "@/lib/authFetch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const BASE_URL = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";

interface JDDialogProps {
  onClose: () => void;
  onJobCreated?: () => void;
}

interface ModelData {
  id: number;
  provider: string;
  prefix: string;
  model: string;
  key: string;
}

interface TechStackData {
  id: number;
  tech_stack: string;
  created_at: string;
}

const JDDialog: React.FC<JDDialogProps> = ({ onClose, onJobCreated }) => {
  const [open, setOpen] = useState(true);
  const [jobTitle, setJobTitle] = useState("");
  const [jobLocation, setJobLocation] = useState("");
  const [models, setModels] = useState("");
  const [domain, setDomain] = useState("");
  const [jdFile, setJdFile] = useState<File | null>(null);
  const [jdQuestionsFile, setJdQuestionsFile] = useState<File | null>(null);
  const [jdSummary, setJdSummary] = useState<string>("");
  const [expiryDate, setExpiryDate] = useState("");
  const [expiryTime, setExpiryTime] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [availableModels, setAvailableModels] = useState<ModelData[]>([]);
  const [availableTechStacks, setAvailableTechStacks] = useState<
    TechStackData[]
  >([]);
  const [isLoadingModels, setIsLoadingModels] = useState(false);
  const [isLoadingTechStacks, setIsLoadingTechStacks] = useState(false);
  const [jdQualificationScore, setResumeScore] = useState<string>("");
  const { toast } = useToast();

  useEffect(() => {
    const fetchModels = async () => {
      setIsLoadingModels(true);
      try {
        const response = await authFetch(`${BASE_URL}/llm/llm`);

        if (!response.ok) {
          throw new Error("Failed to fetch models");
        }

        const modelsData = await response.json();
        console.log("Fetched models:", modelsData);
        setAvailableModels(modelsData);
      } catch (error) {
        console.error("Error fetching models:", error);
        toast({
          title: "Warning",
          description:
            "Failed to load models. You can still proceed without selecting a model.",
          variant: "destructive",
        });
      } finally {
        setIsLoadingModels(false);
      }
    };
    const fetchTechStacks = async () => {
      setIsLoadingTechStacks(true);
      try {
        const response = await authFetch(`${BASE_URL}/tech-stack/tech-stack`);

        if (!response.ok) {
          throw new Error("Failed to fetch tech stacks");
        }

        const techStacksData = await response.json();
        console.log("Fetched tech stacks:", techStacksData); 
        setAvailableTechStacks(techStacksData);
      } catch (error) {
        console.error("Error fetching tech stacks:", error);
        toast({
          title: "Warning",
          description:
            "Failed to load tech stacks. You can still proceed without selecting a tech stack.",
          variant: "destructive",
        });
      } finally {
        setIsLoadingTechStacks(false);
      }
    };

    fetchModels();
    fetchTechStacks();
  }, [toast]);

  const handleResumeScoreChange = (value: string) => {
    if (/^\d{0,3}$/.test(value) && Number(value) <= 100) {
      setResumeScore(value);
    }
  };

  const handleGenerate = async () => {
    if (!jobTitle.trim()) {
      toast({
        title: "Validation Error",
        description: "Job title is required",
        variant: "destructive",
      });
      return;
    }

    if (!jobLocation.trim()) {
      toast({
        title: "Validation Error",
        description: "Job location is required",
        variant: "destructive",
      });
      return;
    }

    if (!jdFile) {
      toast({
        title: "Validation Error",
        description: "Please upload a PDF file",
        variant: "destructive",
      });
      return;
    }

    if (jdFile.type !== "application/pdf") {
      toast({
        title: "Invalid File Type",
        description: "Please upload a valid PDF file",
        variant: "destructive",
      });
      return;
    }

    const maxSizeInMB = 10;
    if (jdFile.size > maxSizeInMB * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: `Please upload a file smaller than ${maxSizeInMB}MB`,
        variant: "destructive",
      });
      return;
    }

    if (!expiryDate || !expiryTime) {
      toast({
        title: "Validation Error",
        description: "JD expiry date and time are required",
        variant: "destructive",
      });
      return;
    }

    if (!jdSummary.trim()) {
      toast({
        title: "Validation Error",
        description: "Job summary is required",
        variant: "destructive",
      });
      return;
    }

    let jdQualificationScoreDecimal = undefined;
    if (jdQualificationScore.trim()) {
      const scoreNum = Number(jdQualificationScore);
      if (isNaN(scoreNum) || scoreNum < 0 || scoreNum > 100) {
        toast({
          title: "Validation Error",
          description: "Resume score must be between 0 and 100",
          variant: "destructive",
        });
        return;
      }
      jdQualificationScoreDecimal = scoreNum / 100;
    }

    const formData = new FormData();
    formData.append("jd_file", jdFile);
    formData.append("job_title", jobTitle.trim());
    formData.append("job_location", jobLocation.trim());
    formData.append("jd_summary_text", jdSummary);

    // Append the new fields with correct parameter names
    if (models.trim()) {
      formData.append("llm_id", models.trim());
    }
    if (domain.trim()) {
      formData.append("tech_stack_id", domain.trim());
    }

    if (jdQuestionsFile) {
      formData.append("jd_custom_questions_file", jdQuestionsFile);
    }

    const jdExpiration = `${expiryDate} ${expiryTime}:00`;
    formData.append("jd_expiration", jdExpiration);
    if (jdQualificationScoreDecimal !== undefined) {
      formData.append(
        "jd_qualification_score",
        jdQualificationScoreDecimal.toString()
      );
    }

    setIsLoading(true);

    try {
      console.log("Sending request with data:", {
        job_title: jobTitle.trim(),
        job_location: jobLocation.trim(),
        llm_id: models.trim(),
        domain_id: domain.trim(),
        file_name: jdFile.name,
        file_size: jdFile.size,
        file_type: jdFile.type,
        questions_file: jdQuestionsFile
          ? {
              name: jdQuestionsFile.name,
              size: jdQuestionsFile.size,
              type: jdQuestionsFile.type,
            }
          : null,
      });

      const response = await authFetch(
        `${BASE_URL}/jd/jd_questions_generation`,
        {
          method: "POST",
          body: formData,
        }
      );

      const responseText = await response.text();
      console.log("Response status:", response.status);
      console.log("Response text:", responseText);

      if (!response.ok) {
        let errorMessage = "Failed to process JD info";
        try {
          const errorData = JSON.parse(responseText);
          if (errorData.detail) {
            if (Array.isArray(errorData.detail)) {
              errorMessage = errorData.detail
                .map((err: any) => `${err.loc?.join(".")} - ${err.msg}`)
                .join("; ");
            } else if (typeof errorData.detail === "string") {
              errorMessage = errorData.detail;
            }
          } else if (errorData.message) {
            errorMessage = errorData.message;
          }
        } catch (parseError) {
          errorMessage = responseText || errorMessage;
        }
        throw new Error(errorMessage);
      }

      let responseData;
      try {
        responseData = JSON.parse(responseText);
        console.log("Success response:", responseData);
      } catch (parseError) {
        console.log("Response is not JSON, treating as success");
      }

      toast({
        title: "Success",
        description: "JD questions generated successfully",
      });

      setJobTitle("");
      setJobLocation("");
      setModels("");
      setDomain("");
      setJdFile(null);
      setJdQuestionsFile(null); // Reset the questions file
      setJdSummary("");
      setOpen(false);

      onClose(); // Call the onClose prop to update parent state
      if (onJobCreated) {
        onJobCreated(); // Call the onJobCreated callback to refresh the job list
      }
    } catch (error) {
      console.error("Error generating JD questions:", error);
      toast({
        title: "Error",
        description: (error as Error).message || "Failed to process JD info",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setJdFile(null);

    if (file.type !== "application/pdf") {
      toast({
        title: "Invalid File Type",
        description: "Please upload a PDF file only",
        variant: "destructive",
      });
      e.target.value = "";
      return;
    }

    const maxSizeInMB = 10;
    if (file.size > maxSizeInMB * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: `Please upload a file smaller than ${maxSizeInMB}MB`,
        variant: "destructive",
      });
      e.target.value = "";
      return;
    }

    setJdFile(file);
    console.log("File selected:", {
      name: file.name,
      size: file.size,
      type: file.type,
    });
  };

  const handleQuestionsFileChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) {
      setJdQuestionsFile(null);
      return;
    }

    if (file.type !== "text/plain") {
      toast({
        title: "Invalid File Type",
        description: "Please upload a .txt file only",
        variant: "destructive",
      });
      e.target.value = "";
      return;
    }

    const maxSizeInMB = 5;
    if (file.size > maxSizeInMB * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: `Please upload a file smaller than ${maxSizeInMB}MB`,
        variant: "destructive",
      });
      e.target.value = "";
      return;
    }

    setJdQuestionsFile(file);
    console.log("Questions file selected:", {
      name: file.name,
      size: file.size,
      type: file.type,
    });
  };

  return (
    <div className="inline-block">
      <Dialog
        open={open}
        onOpenChange={(isOpen) => {
          setOpen(isOpen);
          if (!isOpen) onClose();
        }}
      >
        <DialogContent className="sm:max-w-[525px] flex flex-col max-h-[90vh]">
          <div className="sticky top-0 z-10 bg-white dark:bg-black">
            <DialogHeader>
              <DialogTitle>Create Job Description!!</DialogTitle>
              <DialogDescription>
                Upload job description PDF and provide job details
              </DialogDescription>
            </DialogHeader>
          </div>
          <div className="grid gap-4 py-4 px-1 overflow-y-auto flex-1">
            <div className="grid gap-2">
              <Label htmlFor="jobTitle">Job Title *</Label>
              <Input
                id="jobTitle"
                type="text"
                placeholder="e.g., Sr. Consultant - SAP ABAP HANA Job"
                value={jobTitle}
                onChange={(e) => setJobTitle(e.target.value)}
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="jobSummary">Job Summary *</Label>
              <Input
                id="jobSummary"
                type="text"
                placeholder="This is a job summary"
                value={jdSummary}
                onChange={(e) => setJdSummary(e.target.value)}
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="jobLocation">Job Location *</Label>
              <Select value={jobLocation} onValueChange={setJobLocation}>
                <SelectTrigger id="jobLocation">
                  <SelectValue placeholder="Select location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Indore">Indore</SelectItem>
                  <SelectItem value="Bangalore">Bangalore</SelectItem>
                  <SelectItem value="Pune">Pune</SelectItem>
                  <SelectItem value="Mumbai">Mumbai</SelectItem>
                  <SelectItem value="Gurugao">Gurugao</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="expiryDate">JD Expiry Date *</Label>
              <Input
                id="expiryDate"
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="expiryTime">JD Expiry Time *</Label>
              <Input
                id="expiryTime"
                type="time"
                value={expiryTime}
                onChange={(e) => setExpiryTime(e.target.value)}
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="models">Models</Label>
              <Select
                value={models}
                onValueChange={setModels}
                disabled={isLoadingModels}
              >
                <SelectTrigger id="llm_id">
                  <SelectValue
                    placeholder={
                      isLoadingModels ? "Loading models..." : "Select model"
                    }
                  />
                </SelectTrigger>
                <SelectContent>
                  {availableModels.map((modelData) => (
                    <SelectItem
                      key={modelData.id}
                      value={modelData.id.toString()}
                    >
                      {modelData.model} ({modelData.provider})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {isLoadingModels && (
                <p className="text-xs text-muted-foreground flex items-center">
                  <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                  Loading available models...
                </p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="techstack">Prompts</Label>
              <Select
                value={domain}
                onValueChange={setDomain}
                disabled={isLoadingTechStacks}
              >
                <SelectTrigger id="tech_stack_id">
                  <SelectValue
                    placeholder={
                      isLoadingTechStacks ? "Loading Prompts" : "Select Prompts"
                    }
                  />
                </SelectTrigger>
                <SelectContent>
                  {availableTechStacks.map((techStackData) => (
                    <SelectItem
                      key={techStackData.id}
                      value={techStackData.id.toString()}
                    >
                      {techStackData.tech_stack}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {isLoadingTechStacks && (
                <p className="text-xs text-muted-foreground flex items-center">
                  <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                  Loading available tech stacks...
                </p>
              )}
              {availableTechStacks.length === 0 && !isLoadingTechStacks && (
                <p className="text-xs text-muted-foreground">
                  No tech stacks available
                </p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="jdQualificationScore">Resume Score (%)</Label>
              <div className="flex gap-2">
                <Select
                  value={jdQualificationScore}
                  onValueChange={setResumeScore}
                >
                  <SelectTrigger id="jdQualificationScore">
                    <SelectValue placeholder="Select %" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="40">40%</SelectItem>
                    <SelectItem value="50">50%</SelectItem>
                    <SelectItem value="60">60%</SelectItem>
                    <SelectItem value="70">70%</SelectItem>
                    <SelectItem value="80">80%</SelectItem>
                    <SelectItem value="90">90%</SelectItem>
                    <SelectItem value="100">100%</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  type="number"
                  min={0}
                  max={100}
                  step={1}
                  placeholder="Manual entry"
                  value={jdQualificationScore}
                  onChange={(e) => handleResumeScoreChange(e.target.value)}
                  className="w-28"
                />
              </div>
              {jdQualificationScore && (
                <p className="text-xs text-muted-foreground">
                  {/* Will be sent as: {(Number(jdQualificationScore) / 100).toFixed(2)} */}
                </p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="jobQuestions">
                Job Questions (optional .txt file)
              </Label>
              <Input
                id="jobQuestions"
                type="file"
                accept=".txt"
                onChange={handleQuestionsFileChange}
              />
              {jdQuestionsFile && (
                <p className="text-xs text-muted-foreground">
                  Selected: {jdQuestionsFile.name} (
                  {(jdQuestionsFile.size / 1024).toFixed(2)} KB)
                </p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="jdFile">Job Description *</Label>
              <Input
                id="jdFile"
                type="file"
                accept=".pdf"
                onChange={handleFileChange}
                required
              />
              {jdFile && (
                <p className="text-sm text-gray-600">
                  Selected: {jdFile.name} (
                  {(jdFile.size / 1024 / 1024).toFixed(2)} MB)
                </p>
              )}
            </div>
            <Button
              onClick={handleGenerate}
              disabled={
                isLoading || !jobTitle.trim() || !jobLocation.trim() || !jdFile
              }
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                "Create Job Description"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default JDDialog;
