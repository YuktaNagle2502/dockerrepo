import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { authFetch } from "@/lib/authFetch";

interface CompletedInterview {
  user_id: string;
  candidate_name: string;
  candidate_phone: string;
}

interface EvaluationDialogProps {
  open: boolean;
  onClose: () => void;
  onEvaluate: (userId: string) => Promise<void>;
}

const EvaluationDialog: React.FC<EvaluationDialogProps> = ({
  open,
  onClose,
  onEvaluate,
}) => {
  const [interviews, setInterviews] = useState<CompletedInterview[]>([]);
  const [selectedUser, setSelectedUser] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchCompletedInterviews = async () => {
      try {
        const response = await authFetch(
          `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/interviews/completed/users`
        );
        if (!response.ok) {
          throw new Error("Failed to fetch completed interviews");
        }
        const data: CompletedInterview[] = await response.json();
        setInterviews(data);
      } catch (error) {
        console.error("Failed to fetch completed interviews:", error);
      } finally {
        setLoading(false);
      }
    };

    if (open) {
      void fetchCompletedInterviews();
      setSelectedUser(""); // Reset selection when dialog opens
    }
  }, [open]);

  const handleEvaluate = async () => {
    if (selectedUser) {
      await onEvaluate(selectedUser);
      onClose();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Evaluate Interview</DialogTitle>
          <DialogDescription>
            Select a completed interview to evaluate
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 pt-4">
          <Select
            value={selectedUser}
            onValueChange={setSelectedUser}
            disabled={loading}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a completed interview" />
            </SelectTrigger>
            <SelectContent>
              {interviews.map((interview) => (
                <SelectItem key={interview.user_id} value={interview.user_id}>
                  {interview.candidate_name} ({interview.candidate_phone})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              onClick={() => void handleEvaluate()}
              disabled={!selectedUser || loading}
            >
              Evaluate Interview
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EvaluationDialog;
