import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export interface InterviewQuestion {
    question: string;
    answer: string;
}

export interface UserInterviewQuestion {
    question: string;
    reference_answer: string;
    user_answer: string;
    ai_comment?: string;
}

interface InterviewStore {
    interviewQuestions: InterviewQuestion[];
    UserInterviewQuestion: UserInterviewQuestion[];
    isInterviewCompleted: boolean;
    uploadedImage: string; // Just store the base64 string

    setInterviewQuestions: (questions: InterviewQuestion[]) => void;
    setUserInterviewQuestion: (questions: UserInterviewQuestion[]) => void;
    clearInterviewQuestions: () => void;
    clearUserInterviewQuestion: () => void;
    addInterviewQuestion: (question: InterviewQuestion) => void;
    addUserInterviewQuestion: (question: UserInterviewQuestion) => void;
    setInterviewCompleted: (completed: boolean) => void;
    setUploadedImage: (image?: File) => Promise<void>;
    clearUploadedImage: () => void;
}

// Helper function to convert File to Base64
const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
            if (typeof reader.result === 'string') {
                resolve(reader.result);
            }
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};

export const useInterviewStore = create<InterviewStore>()(
    persist(
        (set) => ({
            interviewQuestions: [],
            UserInterviewQuestion: [],
            isInterviewCompleted: false,
            uploadedImage: '',  // Initialize as empty string

            setInterviewQuestions: (questions) => set({ interviewQuestions: questions }),
            setUserInterviewQuestion: (questions) => set({ UserInterviewQuestion: questions }),
            clearInterviewQuestions: () => set({ interviewQuestions: [] }),
            clearUserInterviewQuestion: () => set({ UserInterviewQuestion: [] }),
            addInterviewQuestion: (question) => set((state) => ({
                interviewQuestions: [...state.interviewQuestions, question]
            })),
            addUserInterviewQuestion: (question) => set((state) => ({
                UserInterviewQuestion: [...state.UserInterviewQuestion, question]
            })),
            setInterviewCompleted: (completed) => set({ isInterviewCompleted: completed }),

            setUploadedImage: async (image?: File) => {
                if (image instanceof File) {
                    try {
                        const base64 = await fileToBase64(image);
                        set({ uploadedImage: base64 });
                    } catch (error) {
                        console.error('Error processing image:', error);
                        set({ uploadedImage: '' });
                    }
                } else {
                    set({ uploadedImage: '' });
                }
            },

            clearUploadedImage: () => set({ uploadedImage: '' }),
        }),
        {
            name: 'interview-storage',
            storage: createJSONStorage(() => localStorage),
            partialize: (state) => ({
                interviewQuestions: state.interviewQuestions,
                UserInterviewQuestion: state.UserInterviewQuestion,
                isInterviewCompleted: state.isInterviewCompleted,
                uploadedImage: state.uploadedImage
            })
        }
    )
);