'use client'

import { useParams } from 'next/navigation';
import InterviewSummary from "@/components/interview/InterviewSummary";

export default function InterviewSummaryPage() {
  const params = useParams();
  const id = params.id as string;

  if (!id) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <InterviewSummary />
    </>
  );
}