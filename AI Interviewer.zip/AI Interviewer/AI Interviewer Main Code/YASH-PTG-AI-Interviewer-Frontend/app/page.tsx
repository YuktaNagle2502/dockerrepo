"use client";

import { useEffect } from "react";
import { useKeycloak } from "@/context/keycloakContext";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, Moon, Sun, LogOut } from "lucide-react";
import { AppSidebar } from "@/components/layout/app-sidebar";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Separator } from "@/components/ui/separator";
import Link from "next/link";
import { useTheme } from "next-themes";
import { useRouter, usePathname } from "next/navigation";

export default function Home() {
  const { keycloak, initialized, authenticated, logout, hasValidToken } =
    useKeycloak();
  const { theme, setTheme } = useTheme();
  const router = useRouter();
  const pathname = usePathname();

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  useEffect(() => {
    // If no valid token and not authenticated, redirect to login (but not if already on /login)
    if (
      initialized &&
      !authenticated &&
      !hasValidToken &&
      pathname !== "/login"
    ) {
      router.push("/login");
    }
  }, [initialized, authenticated, hasValidToken, router, pathname]);

  // Show loading while checking authentication
  if (!initialized) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
      </div>
    );
  }

  // If not authenticated and no valid token, show loading while redirecting
  if (!authenticated && !hasValidToken) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Redirecting to login...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <SidebarProvider>
        <div className="flex flex-1 overflow-hidden">
          <AppSidebar />
          <SidebarInset className="flex flex-col">
            {/* Fixed Header */}
            <header className="flex h-16 justify-between px-4 shrink-0 items-center gap-2 border-b bg-background">
              <div className="flex items-center gap-2 px-4">
                <SidebarTrigger className="-ml-1" />
                <Separator orientation="vertical" className="mr-2 h-4" />
                <Breadcrumb>
                  <BreadcrumbList>
                    <BreadcrumbItem>
                      <BreadcrumbPage>Home</BreadcrumbPage>
                    </BreadcrumbItem>
                  </BreadcrumbList>
                </Breadcrumb>
              </div>
              <div className="flex items-center justify-center gap-5">
                <Link
                  href="/careers"
                  className="text-muted-foreground hover:text-foreground"
                >
                  Careers
                </Link>
                <Button variant="outline" size="icon" onClick={toggleTheme}>
                  {theme === "dark" ? (
                    <Sun className="h-[1.2rem] w-[1.2rem]" />
                  ) : (
                    <Moon className="h-[1.2rem] w-[1.2rem]" />
                  )}
                  <span className="sr-only">Toggle theme</span>
                </Button>
                <Button variant="outline" size="icon" onClick={logout}>
                  <LogOut className="h-[1.2rem] w-[1.2rem]" />
                  <span className="sr-only">Logout</span>
                </Button>
              </div>
            </header>

            {/* Scrollable Main Content */}
            <main className="flex-1 overflow-y-auto">
              {/* Hero Section */}
              <section className="py-20 px-4 md:px-6 text-center">
                <h1 className="text-4xl md:text-6xl font-bold mb-6">
                  Welcome to Our AI Interviewer
                </h1>
                <p className="text-xl mb-8 text-muted-foreground max-w-2xl mx-auto">
                  Discover the power of our innovative solution that will
                  revolutionize your workflow and boost your productivity.
                </p>
                <Link href="/interview">
                  {/* <Button size="lg" className="mr-4">
                    Get Started
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button> */}
                </Link>
                {/* <Button size="lg" variant="outline">
                  Learn More
                </Button> */}
              </section>

              {/* Features Section */}
              <section className="py-20 px-4 md:px-6 bg-muted">
                <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
                  Key Features
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                  {[
                    "Easy Integration",
                    "Powerful Analytics",
                    "Secure & Reliable",
                  ].map((feature, index) => (
                    <div
                      key={index}
                      className="flex flex-col items-center text-center"
                    >
                      <CheckCircle className="h-12 w-12 mb-4 text-primary" />
                      <h3 className="text-xl font-semibold mb-2">{feature}</h3>
                      <p className="text-muted-foreground">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua.
                      </p>
                    </div>
                  ))}
                </div>
              </section>
            </main>

            {/* Fixed Footer */}
            <Footer />
          </SidebarInset>
        </div>
      </SidebarProvider>
    </div>
  );
}
