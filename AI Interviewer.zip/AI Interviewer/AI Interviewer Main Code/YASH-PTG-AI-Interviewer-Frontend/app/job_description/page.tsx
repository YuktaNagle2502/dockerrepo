"use client";

import { useEffect, useState, useCallback } from "react";
import {
  FaEdit,
  FaTrash,
  FaBuilding,
  FaCalendarAlt,
  FaEye,
} from "react-icons/fa";
import {
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  FileText,
  MapPin,
  Calendar,
  Loader2,
  X,
  LogOut,
} from "lucide-react";
import { authFetch } from "@/lib/authFetch";
import { AppSidebar } from "@/components/layout/app-sidebar";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Separator } from "@/components/ui/separator";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useTheme } from "next-themes";
import { Sun, Moon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

import JDDialogue from "@/components/dialogs/JDDialog";
import { cn } from "@/lib/utils";
import { useKeycloak } from "@/context/keycloakContext";
import { useRoleProtection } from "@/hooks/useRoleProtection"; // ← ADD THIS IMPORT

// Replace this with your actual backend base URL
const BASE_URL = process.env.NEXT_PUBLIC_BACKEND_URL;

interface ApiJob {
  job_id: number;
  job_title: string;
  job_location: string;
  created_at: string;
  jd_summary_text: string | null;
  jd_expiration?: string;
}

type Job = {
  id: number;
  title: string;
  location: string;
  date: string;
  createdAt: Date;
  summary: string | null;
  jd_expiration?: string;
};

type UpdateJobData = {
  jobTitle: string;
  jobLocation: string;
  jobSummary?: string;
  jdQuestions?: File;
  jdFile?: File;
  jdExpirationDate?: string;
  jdExpirationTime?: string;
  llmId?: string;
  techStackId?: string;
};

interface ModelData {
  id: number;
  provider: string;
  prefix: string;
  model: string;
  key: string;
}

interface TechStackData {
  id: number;
  tech_stack: string;
  created_at: string;
}

interface JobDetails {
  job_id: number;
  job_title: string;
  job_location: string;
  jd_file_path: string;
  jd_summary_text: string | null;
  created_at: string;
  jd_expiration?: string;
}

function PDFModal({
  open,
  onClose,
  pdfUrl,
  jobTitle,
}: {
  open: boolean;
  onClose: () => void;
  pdfUrl: string;
  jobTitle: string;
}) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="flex-shrink-0 px-6 py-4 border-b">
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="text-lg font-semibold">
                Job Description - {capitalizeFirstLetter(jobTitle)}
              </DialogTitle>
              <DialogDescription className="text-sm text-muted-foreground">
                View the complete job description document
              </DialogDescription>
            </div>
            {/* <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button> */}
          </div>
        </DialogHeader>

        <div className="flex-1 min-h-0 p-4">
          {pdfUrl ? (
            <div className="w-full h-full min-h-[70vh] border rounded-lg overflow-hidden">
              <iframe
                src={pdfUrl}
                className="w-full h-full"
                title={`Job Description - ${jobTitle}`}
                style={{ minHeight: "70vh" }}
              >
                <p>
                  Your browser does not support iframes.
                  <a
                    href={pdfUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline"
                  >
                    Click here to view the PDF
                  </a>
                </p>
              </iframe>
            </div>
          ) : (
            <div className="flex items-center justify-center h-64">
              <div className="text-center space-y-2">
                <FileText className="mx-auto h-12 w-12 text-gray-400" />
                <p className="text-gray-500">
                  No job description file available
                </p>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="flex-shrink-0 px-6 py-4 border-t !border-0 !border-transparent">
          <div className="flex gap-2">
            {pdfUrl && (
              <Button
                variant="outline"
                onClick={() => window.open(pdfUrl, "_blank")}
              >
                <FaEye className="h-4 w-4 mr-2" />
                Open in New Tab
              </Button>
            )}
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}


function JobCard({
  job,
  onEdit,
  onDelete,
  onShowJD,
}: {
  job: Job;
  onEdit: (id: number) => void;
  onDelete: (id: number) => void;
  onShowJD: (id: number) => void;
}) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  return (
    <>
      <Card className="group hover:shadow-lg transition-all duration-200 border-l-4 border-l-blue-500 mb-4">
        <CardHeader className="pb-4">
          <div className="flex items-start justify-between">
            <div className="flex-1 space-y-3">
              <CardTitle className="text-xl font-semibold text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                {capitalizeFirstLetter(job.title)}
              </CardTitle>
          
              {job.summary && (
                <div className="mt-2">
                  <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                    {job.summary}
                  </p>
                </div>
              )}

              <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-300">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <span>{job.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <span>Created {job.date}</span>
                </div>
                {job.jd_expiration && (
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    <span
                      className={cn(
                        "font-medium",
                        isJobExpired(job)
                          ? "text-red-600 dark:text-red-400"
                          : "text-orange-600 dark:text-orange-400"
                      )}
                    >
                      {isJobExpired(job) ? "Expired:" : "Expires:"}{" "}
                      {new Date(job.jd_expiration).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                )}
                {!job.summary && (
                  <Badge variant="outline" className="text-xs">
                    No Summary
                  </Badge>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2 ml-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onShowJD(job.id)}
                className="hover:bg-green-50 hover:text-green-600 hover:border-green-300"
              >
                <FaEye className="h-4 w-4 mr-2" />
                Show JD
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onEdit(job.id)}
                className="hover:bg-blue-50 hover:text-blue-600 hover:border-blue-300"
              >
                <FaEdit className="h-4 w-4 mr-2" />
                Edit
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowDeleteDialog(true)}
                className="hover:bg-red-50 hover:text-red-600 hover:border-red-300"
              >
                <FaTrash className="h-4 w-4 mr-2" />
                Delete
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the job
              posting for "{capitalizeFirstLetter(job.title)}".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                onDelete(job.id);
                setShowDeleteDialog(false);
              }}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function EditJobModal({
  job,
  open,
  onClose,
  onUpdate,
}: {
  job: Job;
  open: boolean;
  onClose: () => void;
  onUpdate: (id: number, data: UpdateJobData) => Promise<void>;
}) {
  const [jobTitle, setJobTitle] = useState(job.title);
  const [jobLocation, setJobLocation] = useState(job.location);
  const [jdFile, setJdFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { theme, setTheme } = useTheme();
  const [jdSummary, setJdSummary] = useState<string>(job.summary || "");
  const [jdQuestionsFile, setJdQuestionsFile] = useState<File | null>(null);
  const [jdQuestionsFileName, setJdQuestionsFileName] = useState<string | null>(
    null
  );
  const [jdExpirationDate, setJdExpirationDate] = useState(
    job.jd_expiration ? job.jd_expiration.split(" ")[0] : ""
  );
  const [jdExpirationTime, setJdExpirationTime] = useState(
    job.jd_expiration ? job.jd_expiration.split(" ")[1]?.slice(0, 5) : ""
  );
  const [models, setModels] = useState("");
  const [domain, setDomain] = useState("");
  const [availableModels, setAvailableModels] = useState<ModelData[]>([]);
  const [availableTechStacks, setAvailableTechStacks] = useState<
    TechStackData[]
  >([]);
  const [isLoadingModels, setIsLoadingModels] = useState(false);
  const [isLoadingTechStacks, setIsLoadingTechStacks] = useState(false);
  const [jdQualificationScore, setJdQualificationScore] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    const fetchModels = async () => {
      setIsLoadingModels(true);
      try {
        const response = await authFetch(`${BASE_URL}/llm/llm`);

        if (!response.ok) {
          throw new Error("Failed to fetch models");
        }

        const modelsData = await response.json();
        console.log("Fetched models:", modelsData);
        setAvailableModels(modelsData);
      } catch (error) {
        console.error("Error fetching models:", error);
        toast({
          title: "Warning",
          description:
            "Failed to load models. You can still proceed without selecting a model.",
          variant: "destructive",
        });
      } finally {
        setIsLoadingModels(false);
      }
    };

    const fetchTechStacks = async () => {
      setIsLoadingTechStacks(true);
      try {
        const response = await authFetch(`${BASE_URL}/tech-stack/tech-stack`);

        if (!response.ok) {
          throw new Error("Failed to fetch tech stacks");
        }

        const techStacksData = await response.json();
        console.log("Fetched tech stacks:", techStacksData);
        setAvailableTechStacks(techStacksData);
      } catch (error) {
        console.error("Error fetching tech stacks:", error);
        toast({
          title: "Warning",
          description:
            "Failed to load tech stacks. You can still proceed without selecting a tech stack.",
          variant: "destructive",
        });
      } finally {
        setIsLoadingTechStacks(false);
      }
    };

    if (open) {
      fetchModels();
      fetchTechStacks();
    }
  }, [open, toast]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const updateData: UpdateJobData = {
        jobTitle,
        jobLocation,
        jobSummary: jdSummary || undefined,
        jdQuestions: jdQuestionsFile || undefined,
        jdFile: jdFile || undefined,
        jdExpirationDate,
        jdExpirationTime,
        llmId: models || undefined,
        techStackId: domain || undefined,
      };

      await onUpdate(job.id, updateData);
      onClose();
    } catch (error) {
      console.error("Error updating job:", error);
      toast({
        title: "Update Failed",
        description: "Failed to update job. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    setJobTitle(job.title);
    setJobLocation(job.location);
    setJdSummary(job.summary || "");
    setJdExpirationDate(job.jd_expiration ? job.jd_expiration.split(" ")[0] : "");
    setJdExpirationTime(job.jd_expiration ? job.jd_expiration.split(" ")[1]?.slice(0, 5) : "");
    // Reset other fields as needed
  }, [job]);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>Edit Job Posting</DialogTitle>
          <DialogDescription>
            Update the details for this job posting. Changes will be saved
            immediately.
          </DialogDescription>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto pr-2">
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="jobTitle">Job Title</Label>
              <Input
                id="jobTitle"
                value={jobTitle}
                onChange={(e) => {
                  const value = e.target.value;
                  setJobTitle(value.charAt(0).toUpperCase() + value.slice(1));
                }}
                placeholder="Enter job title"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="jobSummary">Job Summary</Label>
              <Textarea
                id="jobSummary"
                placeholder="Enter a brief job summary..."
                value={jdSummary}
                onChange={(e) => setJdSummary(e.target.value)}
                rows={4}
                className="resize-none"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400">
                A brief description of the job role and requirements
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="jobLocation">Job Location</Label>
              <Select value={jobLocation} onValueChange={setJobLocation}>
                <SelectTrigger id="jobLocation">
                  <SelectValue placeholder="Select location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Indore">Indore</SelectItem>
                  <SelectItem value="Bangalore">Bangalore</SelectItem>
                  <SelectItem value="Pune">Pune</SelectItem>
                  <SelectItem value="Mumbai">Mumbai</SelectItem>
                  <SelectItem value="Gurugao">Gurugao</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="models">Models</Label>
              <Select
                value={models}
                onValueChange={setModels}
                disabled={isLoadingModels}
              >
                <SelectTrigger id="models">
                  <SelectValue
                    placeholder={
                      isLoadingModels ? "Loading models..." : "Select model"
                    }
                  />
                </SelectTrigger>
                <SelectContent>
                  {availableModels.map((modelData) => (
                    <SelectItem
                      key={modelData.id}
                      value={modelData.id.toString()}
                    >
                      {modelData.model} ({modelData.provider})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {isLoadingModels && (
                <p className="text-xs text-muted-foreground flex items-center">
                  <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                  Loading available models...
                </p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="techstack">Prompts</Label>
              <Select
                value={domain}
                onValueChange={setDomain}
                disabled={isLoadingTechStacks}
              >
                <SelectTrigger id="techstack">
                  <SelectValue
                    placeholder={
                      isLoadingTechStacks
                        ? "Loading Prompts..."
                        : "Select Prompts"
                    }
                  />
                </SelectTrigger>
                <SelectContent>
                  {availableTechStacks.map((techStackData) => (
                    <SelectItem
                      key={techStackData.id}
                      value={techStackData.id.toString()}
                    >
                      {techStackData.tech_stack}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {isLoadingTechStacks && (
                <p className="text-xs text-muted-foreground flex items-center">
                  <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                  Loading available tech stacks...
                </p>
              )}
              {availableTechStacks.length === 0 && !isLoadingTechStacks && (
                <p className="text-xs text-muted-foreground">
                  No tech stacks available
                </p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="jobQuestions">
                Job Questions (optional .txt file)
              </Label>
              <Input
                id="jobQuestions"
                type="file"
                accept=".txt"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;

                  if (file.type !== "text/plain") {
                    toast({
                      title: "Invalid File Type",
                      description: "Please upload a .txt file only",
                      variant: "destructive",
                    });
                    e.target.value = "";
                    return;
                  }
                  setJdQuestionsFile(file);
                  setJdQuestionsFileName(file.name);
                }}
              />
              {jdQuestionsFileName && (
                <p className="text-xs text-muted-foreground">
                  Selected: {jdQuestionsFileName}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="jdFile">Job Description File (Optional)</Label>
              <Input
                id="jdFile"
                type="file"
                accept=".pdf,.doc,.docx,.txt"
                onChange={(e) => setJdFile(e.target.files?.[0] || null)}
              />
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Upload a new file to replace the existing job description
              </p>
            </div>
          
            <div className="space-y-2">
              <Label htmlFor="jdQualificationScore">
                JD Qualification Score (%)
              </Label>
              <div className="flex gap-2">
                <Select
                  value={jdQualificationScore}
                  onValueChange={setJdQualificationScore}
                >
                  <SelectTrigger id="jdQualificationScore">
                    <SelectValue placeholder="Select %" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="40">40%</SelectItem>
                    <SelectItem value="50">50%</SelectItem>
                    <SelectItem value="60">60%</SelectItem>
                    <SelectItem value="70">70%</SelectItem>
                    <SelectItem value="80">80%</SelectItem>
                    <SelectItem value="90">90%</SelectItem>
                    <SelectItem value="100">100%</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  type="number"
                  min={0}
                  max={100}
                  step={1}
                  placeholder="Manual entry"
                  value={jdQualificationScore}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (/^\d{0,3}$/.test(val) && Number(val) <= 100)
                      setJdQualificationScore(val);
                  }}
                  className="w-28"
                />
              </div>
              {jdQualificationScore && (
                <p className="text-xs text-muted-foreground">
                  Will be sent as:{" "}
                  {(Number(jdQualificationScore) / 100).toFixed(2)}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="jdExpirationDate">JD Expiry Date</Label>
              <Input
                id="jdExpirationDate"
                type="date"
                value={jdExpirationDate}
                onChange={(e) => setJdExpirationDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="jdExpirationTime">JD Expiry Time</Label>
              <Input
                id="jdExpirationTime"
                type="time"
                value={jdExpirationTime}
                onChange={(e) => setJdExpirationTime(e.target.value)}
              />
            </div>
          </div>
        </div>
        <DialogFooter className="flex-shrink-0 border-t pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            disabled={isLoading}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isLoading}
            onClick={handleSubmit}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            {isLoading ? "Updating..." : "Update Job"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function JobDescriptionPage() {
  const [showJDDialog, setShowJDDialog] = useState(false);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [editingJob, setEditingJob] = useState<Job | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [jobIdSearch, setJobIdSearch] = useState("");
  const [locationFilter, setLocationFilter] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const jobsPerPage = 5;
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  const { keycloak, initialized, authenticated, logout, hasValidToken } =
    useKeycloak();
  const [showPDFModal, setShowPDFModal] = useState(false);
  const [currentPDFUrl, setCurrentPDFUrl] = useState("");
  const [currentJobTitle, setCurrentJobTitle] = useState("");
  const [isLoadingPDF, setIsLoadingPDF] = useState(false);

  // ← ADD ROLE PROTECTION HOOK
const { isCheckingAuth, isRedirectingToLogin, isRedirectingToAccessDenied, isAuthorized } = useRoleProtection();


  

  const fetchJobs = useCallback(async () => {
    try {
      setIsLoading(true);
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/jd/jobs`
      );

      if (!response.ok) {
        throw new Error("Failed to fetch jobs");
      }

      const data: { jobs: ApiJob[] } = await response.json();
      console.log("Fetched jobs from DB:", data);

      if (Array.isArray(data.jobs)) {
        const normalizedJobs = data.jobs.map((job) => ({
          id: job.job_id,
          title: job.job_title,
          location: job.job_location,
          date: new Date(job.created_at).toLocaleDateString(),
          createdAt: new Date(job.created_at),
          summary: job.jd_summary_text,
          jd_expiration: job.jd_expiration,
        }));
        setJobs(normalizedJobs);
      } else {
        console.error("Unexpected data format:", data);
        setJobs([]);
      }
    } catch (error) {
      console.error("Error fetching jobs:", error);
      setJobs([]);
      toast({
        title: "Error",
        description: "Failed to fetch jobs. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  const handleShowJD = useCallback(
    async (jobId: number) => {
      try {
        setIsLoadingPDF(true);
        const job = jobs.find((j) => j.id === jobId);

        const response = await authFetch(`${BASE_URL}/jd/${jobId}`);

        if (!response.ok) {
          throw new Error("Failed to fetch job details");
        }

        const jobDetails: JobDetails = await response.json();

        if (jobDetails.jd_file_path) {
          setCurrentPDFUrl(jobDetails.jd_file_path);
          setCurrentJobTitle(job?.title || jobDetails.job_title);
          setShowPDFModal(true);
        } else {
          toast({
            title: "No File Available",
            description:
              "This job doesn't have a job description file attached.",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error("Error fetching job details:", error);
        toast({
          title: "Error",
          description: "Failed to load job description. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsLoadingPDF(false);
      }
    },
    [jobs, toast]
  );

  const updateJob = useCallback(
    async (id: number, updateData: UpdateJobData) => {
      try {
        const formData = new FormData();
        formData.append("job_title", updateData.jobTitle);
        formData.append("job_location", updateData.jobLocation);

        if (updateData.jobSummary) {
          formData.append("jd_summary_text", updateData.jobSummary);
        }

        if (updateData.jdQuestions instanceof File) {
          formData.append("jd_custom_questions_file", updateData.jdQuestions);
        }

        if (updateData.jdFile) {
          formData.append("jd_file", updateData.jdFile);
        }

        if (updateData.jdExpirationDate && updateData.jdExpirationTime) {
          const jdExpiration = `${updateData.jdExpirationDate} ${updateData.jdExpirationTime}:00`;
          formData.append("jd_expiration", jdExpiration);
        }

        if (updateData.llmId) {
          formData.append("llm_id", updateData.llmId);
        }

        if (updateData.techStackId) {
          formData.append("tech_stack_id", updateData.techStackId);
        }

        const response = await authFetch(
          `${process.env.NEXT_PUBLIC_BACKEND_URL}/jd/update/${id}`,
          {
            method: "POST",
            body: formData,
          }
        );

        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Failed to update job: ${errorText}`);
        }

        console.log(`Job ${id} updated successfully`);
        toast({
          title: "Success",
          description: "Job updated successfully!",
        });
        await fetchJobs();
      } catch (error) {
        console.error("Update error:", error);
        toast({
          title: "Update Failed",
          description:
            error instanceof Error ? error.message : "Failed to update job",
          variant: "destructive",
        });
        throw error;
      }
    },
    [fetchJobs, toast]
  );

  const handleEdit = useCallback(
    (id: number) => {
      const jobToEdit = jobs.find((job) => job.id === id);
      if (jobToEdit) {
        setEditingJob(jobToEdit);
      }
    },
    [jobs]
  );

  const handleDelete = useCallback(
    async (id: number) => {
      try {
        const response = await authFetch(
          `${process.env.NEXT_PUBLIC_BACKEND_URL}/jd/${id}`,
          {
            method: "DELETE",
          }
        );

        if (!response.ok) {
          const errorText = await response.text();
          toast({
            title: "Delete Failed",
            description: errorText || `Failed to delete job with ID ${id}`,
            variant: "destructive",
          });
          throw new Error(`Failed to delete job with ID ${id}: ${errorText}`);
        }

        console.log(`Job ${id} deleted successfully`);
        toast({
          title: "Success",
          description: "Job deleted successfully!",
        });
        setJobs((prev) => prev.filter((job) => job.id !== id));
      } catch (error: any) {
        console.error("Delete error:", error);
        toast({
          title: "Delete Error",
          description:
            error?.message || "An error occurred while deleting the job.",
          variant: "destructive",
        });
      }
    },
    [toast]
  );

  const handleJobCreated = useCallback(() => {
    setShowJDDialog(false);
    fetchJobs(); 
  }, [fetchJobs]);

  useEffect(() => {
    fetchJobs();
  }, [fetchJobs]);


  const filteredJobs = jobs.filter(
    (job) =>
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
      job.location.toLowerCase().includes(locationFilter.toLowerCase()) &&
      (jobIdSearch === "" || job.id.toString() === jobIdSearch.trim()) &&
      !isJobExpired(job) 
  );


  const totalPages = Math.ceil(filteredJobs.length / jobsPerPage);
  const paginatedJobs = filteredJobs.slice(
    (currentPage - 1) * jobsPerPage,
    currentPage * jobsPerPage
  );

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, jobIdSearch, locationFilter]);

  // ← ADD AUTHORIZATION CHECKS
if (isCheckingAuth) {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
    </div>
  );
}

if (isRedirectingToLogin) {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
        <p>Redirecting to login...</p>
      </div>
    </div>
  );
}

if (isRedirectingToAccessDenied) {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
        <p>Checking permissions...</p>
      </div>
    </div>
  );
}

if (!isAuthorized) {
  return null;
}

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="flex flex-col h-screen">
        {/* Fixed Header */}
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4 justify-between bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
          <div className="flex items-center">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbPage>Job Descriptions</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
          <div className="flex items-center gap-4">
            <a
              href="/careers"
              className="text-base font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Careers
            </a>
            <Button variant="outline" size="icon" onClick={toggleTheme}>
              {theme === "dark" ? (
                <Sun className="h-[1.2rem] w-[1.2rem]" />
              ) : (
                <Moon className="h-[1.2rem] w-[1.2rem]" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
            <Button variant="outline" size="icon" onClick={logout}>
              <LogOut className="h-[1.2rem] w-[1.2rem]" />
              <span className="sr-only">Logout</span>
            </Button>
          </div>
        </header>

        <div className="flex-1 overflow-auto">
          <div className="flex flex-col gap-4 p-4">
            <div className="max-w-7xl mx-auto w-full space-y-6">
              <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
                <div>
                  <h1 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
                    Job Descriptions
                  </h1>
                  <p className="text-gray-600 dark:text-gray-300">
                    Manage and organize your job postings and descriptions
                  </p>
                </div>
                <Button
                  onClick={() => setShowJDDialog(true)}
                  className="bg-blue-500 text-white flex items-center hover:bg-blue-600 focus:bg-blue-600 active:bg-blue-700"
                  size="sm"
                >
                  <Plus className="h-4 w-4" />
                  Create Job
                </Button>
              </div>

              <div className="grid gap-4 md:grid-cols-4">
                <Card className="bg-blue-50 dark:bg-blue-950 shadow">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">
                      Total Jobs
                    </CardTitle>
                    <FaBuilding className="h-8 w-8 text-blue-400 dark:text-blue-50" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">
                      {jobs.length}
                    </div>
                    <p className="text-xs text-muted-foreground dark:text-white">
                      Active job postings
                    </p>
                  </CardContent>
                </Card>
                <Card className="bg-green-50 dark:bg-green-950 shadow ">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">
                      With Summary
                    </CardTitle>
                    <FileText className="h-8 w-8 text-green-400 dark:text-green-50" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">
                      {jobs.filter((job) => job.summary).length}
                    </div>
                    <p className="text-xs text-muted-foreground dark:text-white">
                      Jobs with summaries
                    </p>
                  </CardContent>
                </Card>
                <Card className="bg-yellow-50 dark:bg-yellow-900 shadow !border-0 !border-transparent">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">
                      Locations
                    </CardTitle>
                    <MapPin className="h-8 w-8 text-yellow-400 dark:text-yellow-50" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">
                      {new Set(jobs.map((job) => job.location)).size}
                    </div>
                    <p className="text-xs text-muted-foreground dark:text-white">
                      Unique locations
                    </p>
                  </CardContent>
                </Card>
                <Card className="bg-purple-50 border-0 shadow dark:bg-purple-900/70 ">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">
                      This Month
                    </CardTitle>
                    <FaCalendarAlt className="h-8 w-8 text-purple-400 dark:text-purple-50" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">
                      {
                        jobs.filter((job) => {
                          const jobDate = new Date(job.createdAt);
                          const now = new Date();
                          return (
                            jobDate.getMonth() === now.getMonth() &&
                            jobDate.getFullYear() === now.getFullYear()
                          );
                        }).length
                      }
                    </div>
                    <p className="text-xs text-muted-foreground dark:text-white">
                      Jobs added this month
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Search and Filter Section */}
              <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div className="flex flex-1 gap-4">
                  <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                    <Input
                      placeholder="Search by job title..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                    <Input
                      placeholder="Search by job id."
                      value={jobIdSearch}
                      onChange={(e) => setJobIdSearch(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="relative max-w-sm">
                    <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                    <Input
                      placeholder="Filter by location..."
                      value={locationFilter}
                      onChange={(e) => setLocationFilter(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                  <span>
                    Showing {filteredJobs.length} of {jobs.length} jobs
                  </span>
                </div>
              </div>

              {isLoading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="text-center space-y-2">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                    <p className="text-gray-500 dark:text-gray-300">
                      Loading...
                    </p>
                  </div>
                </div>
              ) : (
                <>
                  {paginatedJobs.length > 0 ? (
                    <div className="space-y-4">
                      {paginatedJobs.map((job) => (
                        <JobCard
                          key={job.id}
                          job={job}
                          onEdit={handleEdit}
                          onDelete={handleDelete}
                          onShowJD={handleShowJD}
                        />
                      ))}
                    </div>
                  ) : (
                    <Card className="text-center py-12">
                      <CardContent>
                        <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                        <CardTitle className="text-xl text-gray-600 dark:text-gray-300 mb-2">
                          No jobs found
                        </CardTitle>
                        <CardDescription className="mb-4">
                          {searchTerm || locationFilter
                            ? "Try adjusting your search filters"
                            : "Get started by creating your first job posting"}
                        </CardDescription>
                        {!searchTerm && !locationFilter && (
                          <Button
                            onClick={() => setShowJDDialog(true)}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            <Plus className="mr-2 h-4 w-4" />
                            Create First Job
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {totalPages > 1 && (
                    <div className="flex items-center justify-center gap-4 mt-8 pb-8">
                      <Button
                        variant="outline"
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage((prev) => prev - 1)}
                      >
                        Previous
                      </Button>
                      <span className="text-sm text-gray-600 dark:text-gray-300">
                        Page {currentPage} of {totalPages}
                      </span>
                      <Button
                        variant="outline"
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage((prev) => prev + 1)}
                      >
                        Next
                      </Button>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </SidebarInset>

      {showJDDialog && (
        <JDDialogue
          key="jd-dialog"
          onClose={() => setShowJDDialog(false)}
          onJobCreated={handleJobCreated}
        />
      )}

      {editingJob && (
        <EditJobModal
          job={editingJob}
          open={!!editingJob}
          onClose={() => setEditingJob(null)}
          onUpdate={updateJob}
        />
      )}

      <PDFModal
        open={showPDFModal}
        onClose={() => {
          setShowPDFModal(false);
          setCurrentPDFUrl("");
          setCurrentJobTitle("");
        }}
        pdfUrl={currentPDFUrl}
        jobTitle={currentJobTitle}
      />

      {isLoadingPDF && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 flex items-center space-x-3">
            <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
            <span className="text-gray-900 dark:text-white">
              Loading job description...
            </span>
          </div>
        </div>
      )}
    </SidebarProvider>
  );
}

function capitalizeFirstLetter(str: string | undefined | null): string {
  if (!str) return "";
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function isJobExpired(job: { jd_expiration?: string }): boolean {
  if (!job.jd_expiration) return false;
  return new Date(job.jd_expiration) < new Date();
}
