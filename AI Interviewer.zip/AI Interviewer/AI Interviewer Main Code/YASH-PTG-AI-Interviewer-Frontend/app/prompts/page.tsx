"use client";

import { AppSidebar } from "@/components/layout/app-sidebar";
import {
  Moon,
  Sun,
  Plus,
  Pencil,
  Trash2,
  RefreshCw, AlertTriangle,
  LogOut,
} from "lucide-react";
import { useTheme } from "next-themes";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Separator } from "@/components/ui/separator";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import React, { useState, useEffect, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import * as z from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { authFetch } from "@/lib/authFetch";
import Link from "next/link";
import { useKeycloak } from "@/context/keycloakContext";
import { useRoleProtection } from "@/hooks/useRoleProtection";

// Types
interface TechStack {
  id: number;
  tech_stack: string;
  is_default: boolean;
  created_by: string;
  created_at?: string;
  updated_at?: string;
}

// Form schemas - moved outside component
const createTechStackSchema = z.object({
  tech_stack: z.string().min(1, "Tech stack name is required"),
});

const updateTechStackSchema = z.object({
  tech_stack: z.string().min(1, "Tech stack name is required"),
});

type CreateTechStackFormValues = z.infer<typeof createTechStackSchema>;
type UpdateTechStackFormValues = z.infer<typeof updateTechStackSchema>;

export default function TechStackManagementPage() {
  // ✅ ALL HOOKS MOVED TO THE TOP - BEFORE ANY CONDITIONAL RETURNS
  const { toast } = useToast();
  const [techStacks, setTechStacks] = useState<TechStack[]>([]);
  const [loading, setLoading] = useState(true);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedTechStack, setSelectedTechStack] = useState<TechStack | null>(null);
  const { theme, setTheme } = useTheme();
  const { keycloak, initialized, authenticated, logout, hasValidToken } = useKeycloak();
  const { isCheckingAuth, isRedirectingToLogin, isRedirectingToAccessDenied, isAuthorized } = useRoleProtection();

  // ✅ FORM HOOKS MOVED TO THE TOP
  const createForm = useForm<CreateTechStackFormValues>({
    resolver: zodResolver(createTechStackSchema),
    defaultValues: {
      tech_stack: "",
    },
  });

  const updateForm = useForm<UpdateTechStackFormValues>({
    resolver: zodResolver(updateTechStackSchema),
    defaultValues: {
      tech_stack: "",
    },
  });

  // ✅ useCallback MOVED TO THE TOP - BEFORE CONDITIONAL RETURNS
  const fetchTechStacks = useCallback(async () => {
    setLoading(true);
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/tech-stack/tech-stack`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("Response :", response);
      if (!response.ok) {
        throw new Error("Failed to fetch tech stacks");
      }

      const data = await response.json();
      setTechStacks(Array.isArray(data) ? data : []);

      toast({
        title: "Tech Stacks Loaded",
        description: "Successfully fetched all tech stacks.",
        duration: 2000,
      });
    } catch (err) {
      console.error("Fetch error:", err);
      toast({
        title: "Error",
        description: "Failed to fetch tech stacks.",
        variant: "destructive",
        duration: 2000,
      });
      setTechStacks([]);
    } finally {
      setLoading(false);
    }
  }, [toast]);

  // ✅ useEffect MOVED TO THE TOP - BEFORE CONDITIONAL RETURNS
  useEffect(() => {
    fetchTechStacks();
  }, [fetchTechStacks]);

  // ✅ CONDITIONAL RETURNS NOW COME AFTER ALL HOOKS
  if (isCheckingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (isRedirectingToLogin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Redirecting to login...</p>
        </div>
      </div>
    );
  }

  if (isRedirectingToAccessDenied) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Checking permissions...</p>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return null;
  }

  // ✅ ALL FUNCTIONS AND HANDLERS AFTER HOOKS AND CONDITIONAL RETURNS
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  // Create Prompt Template
  const onCreateSubmit = async (values: CreateTechStackFormValues) => {
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/tech-stack/tech-stack`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(values),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to create tech stack");
      }

      toast({
        title: "Success",
        description: "Tech stack created successfully.",
      });

      createForm.reset();
      setCreateDialogOpen(false);
      await fetchTechStacks();
    } catch (error) {
      console.error("Create error:", error);
      toast({
        title: "Error",
        description: "Failed to create tech stack.",
        variant: "destructive",
      });
    }
  };

  // Update Prompt Template
  const onUpdateSubmit = async (values: UpdateTechStackFormValues) => {
    if (!selectedTechStack) return;

    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/tech-stack/tech-stack/${selectedTechStack.id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(values),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to update tech stack");
      }

      toast({
        title: "Success",
        description: "Tech stack updated successfully.",
      });

      updateForm.reset();
      setUpdateDialogOpen(false);
      setSelectedTechStack(null);
      await fetchTechStacks();
    } catch (error) {
      console.error("Update error:", error);
      toast({
        title: "Error",
        description: "Failed to update tech stack.",
        variant: "destructive",
      });
    }
  };

  // Delete Prompt Template
  const handleDelete = async () => {
    if (!selectedTechStack) return;

    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/tech-stack/tech-stack/${selectedTechStack.id}`,
        {
          method: "DELETE",
        }
      );

      if (!response.ok) {
        throw new Error("Failed to delete tech stack");
      }

      setTechStacks((prev) =>
        prev.filter((ts) => ts.id !== selectedTechStack.id)
      );

      toast({
        title: "Success",
        description: "Tech stack deleted successfully.",
      });

      setDeleteDialogOpen(false);
      setSelectedTechStack(null);
    } catch (error) {
      console.error("Delete error:", error);
      toast({
        title: "Error",
        description: "Failed to delete tech stack.",
        variant: "destructive",
      });
    }
  };

  // Handle update dialog open
  const handleUpdateOpen = (techStack: TechStack) => {
    if (techStack.is_default) return; // Prevent opening if it's default
    setSelectedTechStack(techStack);
    updateForm.reset({
      tech_stack: techStack.tech_stack,
    });
    setUpdateDialogOpen(true);
  };

  // Handle delete dialog open
  const handleDeleteOpen = (techStack: TechStack) => {
    if (techStack.is_default) return; // Prevent opening if it's default
    setSelectedTechStack(techStack);
    setDeleteDialogOpen(true);
  };

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="flex flex-col h-screen">
        {/* Fixed Header */}
        <header className="flex h-16 justify-between px-4 shrink-0 items-center gap-2 sticky top-0 z-10 bg-background border-b">
          <div className="flex items-center gap-2 px-4">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem className="hidden md:block">
                  <BreadcrumbLink asChild>
                    <Link href="/job_description">Home</Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="hidden md:block" />
                <BreadcrumbItem>
                  <BreadcrumbPage>Prompt Template Management</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
          <div className="flex items-center justify-center gap-4">
             <a
              href="/careers"
              className="text-base font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Careers
            </a>
            <Button variant="outline" size="icon" onClick={toggleTheme}>
              {theme === "dark" ? (
                <Sun className="h-[1.2rem] w-[1.2rem]" />
              ) : (
                <Moon className="h-[1.2rem] w-[1.2rem]" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
            <Button variant="outline" size="icon" onClick={logout}>
              <LogOut className="h-[1.2rem] w-[1.2rem]" />
              <span className="sr-only">Logout</span>
            </Button>
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-auto">
          <div className="p-6">
            <div className="min-h-[calc(100vh-4rem)] rounded-xl bg-muted/50 p-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Prompt Template Management</CardTitle>
                      <CardDescription>
                        Manage your technology stack configurations
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={fetchTechStacks}
                        disabled={loading}
                      >
                        <RefreshCw className={`h-4 w-4${loading ? ' animate-spin' : ''}`} />
                        Refresh
                      </Button>
                      <Dialog
                        open={createDialogOpen}
                        onOpenChange={setCreateDialogOpen}
                      >
                        <DialogTrigger asChild>
                          <Button
                            size="sm"
                            className="bg-blue-500 text-white flex items-center hover:bg-blue-600 focus:bg-blue-600 active:bg-blue-700"
                          >
                            <Plus className="h-4 w-4" />
                            Add Prompt Template
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[425px]">
                          <DialogHeader>
                            <DialogTitle>
                              Create New Prompt Template
                            </DialogTitle>
                            <DialogDescription>
                              Add a new technology stack to your configuration.
                            </DialogDescription>
                          </DialogHeader>
                          <Form {...createForm}>
                            <div
                              onSubmit={createForm.handleSubmit(onCreateSubmit)}
                              className="space-y-4"
                            >
                              <FormField
                                control={createForm.control}
                                name="tech_stack"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Prompt Template Name</FormLabel>
                                    <FormControl>
                                      <Input
                                        placeholder="e.g., React, Python, Node.js, Java"
                                        {...field}
                                      />
                                    </FormControl>
                                    <FormDescription>
                                      Enter the name of the technology stack
                                    </FormDescription>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <DialogFooter>
                                <Button
                                  onClick={createForm.handleSubmit(
                                    onCreateSubmit
                                  )}
                                   className="bg-blue-500 text-white flex items-center hover:bg-blue-600 focus:bg-blue-600 active:bg-blue-700"
                                >
                                  Create Prompt Template
                                </Button>
                              </DialogFooter>
                            </div>
                          </Form>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="flex items-center justify-center h-64">
                      <div className="text-center space-y-2">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                        <p className="text-gray-500 dark:text-gray-300">
                          Loading ...
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse border border-gray-200 dark:border-gray-700">
                        <thead>
                          <tr className="bg-gray-50 dark:bg-gray-800">
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">S.No</th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">Prompt Template</th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">Created By</th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {techStacks.length === 0 ? (
                            <tr>
                              <td colSpan={4} className="border border-gray-200 dark:border-gray-700 px-4 py-8 text-center">
                                No tech stacks found. Create your first tech stack configuration.
                              </td>
                            </tr>
                          ) : (
                            techStacks.map((techStack, index) => (
                              <tr key={techStack.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2 font-medium">
                                  {index + 1}
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  <div className="flex items-center gap-2">
                                    <Link 
                                      href={`/agent-prompt?techStackId=${techStack.id}&techStackName=${encodeURIComponent(techStack.tech_stack)}`}
                                      className="text-blue-600 dark:text-blue-400 hover:underline"
                                    >
                                      {techStack.tech_stack}
                                    </Link>
                                    {techStack.is_default && (
                                      <span className="px-2 py-1 text-xs bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 rounded-full">
                                        Default
                                      </span>
                                    )}
                                  </div>
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  {techStack.created_by}
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  <div className="flex gap-2 items-center">
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleUpdateOpen(techStack)}
                                      disabled={techStack.is_default}
                                      className={techStack.is_default ? "opacity-50 cursor-not-allowed" : ""}
                                      title={techStack.is_default ? "Cannot edit default tech stack" : "Edit tech stack"}
                                    >
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleDeleteOpen(techStack)}
                                      disabled={techStack.is_default}
                                      className={techStack.is_default ? "opacity-50 cursor-not-allowed" : ""}
                                      title={techStack.is_default ? "Cannot delete default tech stack" : "Delete tech stack"}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </SidebarInset>

      {/* Update Dialog */}
      <Dialog open={updateDialogOpen} onOpenChange={setUpdateDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Update Prompt Template</DialogTitle>
            <DialogDescription>
              Update the technology stack configuration.
            </DialogDescription>
          </DialogHeader>
          <Form {...updateForm}>
            <div
              onSubmit={updateForm.handleSubmit(onUpdateSubmit)}
              className="space-y-4"
            >
              <FormField
                control={updateForm.control}
                name="tech_stack"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prompt Template Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g., React, Python, Node.js, Java"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="submit"
                  onClick={updateForm.handleSubmit(onUpdateSubmit)}
                  className="bg-blue-500 text-white flex items-center hover:bg-blue-600 focus:bg-blue-600 active:bg-blue-700"
                >
                  Update Prompt Template
                </Button>
              </DialogFooter>
            </div>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the
              tech stack configuration for "{selectedTechStack?.tech_stack}".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </SidebarProvider>
  );
}