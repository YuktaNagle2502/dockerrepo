"use client";

import { AppSidebar } from "@/components/layout/app-sidebar";
import {
  Moon,
  Sun,
  Plus,
  Pencil,
  Trash2,
  RefreshCw,
  Loader2,
  LogOut,
} from "lucide-react";
import { useTheme } from "next-themes";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Separator } from "@/components/ui/separator";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import React, { useState, useEffect, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
// Table components using basic HTML with Tailwind classes
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import * as z from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { authFetch } from "@/lib/authFetch";
import Link from "next/link";
import { useKeycloak } from "@/context/keycloakContext";
import { useRoleProtection } from "@/hooks/useRoleProtection";

// Types
interface LLM {
  id: number;
  provider: string;
  prefix: string;
  model: string;
  key: string;
  is_default: boolean;
  created_by: string | null;
  created_at?: string;
  updated_at?: string;
}

// Form schemas - moved outside component
const createLLMSchema = z.object({
  provider: z.string().min(1, "Provider is required"),
  prefix: z.string().min(1, "Prefix is required"),
  model: z.string().min(1, "Model is required"),
  key: z.string().min(1, "API Key is required"),
});

const updateLLMSchema = z.object({
  provider: z.string().min(1, "Provider is required"),
  prefix: z.string().optional(),
  model: z.string().min(1, "Model is required"),
  key: z.string().optional(),
});

type CreateLLMFormValues = z.infer<typeof createLLMSchema>;
type UpdateLLMFormValues = z.infer<typeof updateLLMSchema>;

export default function LLMManagementPage() {
  // ✅ ALL HOOKS MOVED TO THE TOP - BEFORE ANY CONDITIONAL RETURNS
  const { toast } = useToast();
  const [llms, setLlms] = useState<LLM[]>([]);
  const [loading, setLoading] = useState(true);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedLLM, setSelectedLLM] = useState<LLM | null>(null);
  const { theme, setTheme } = useTheme();
  const { keycloak, initialized, authenticated, logout, hasValidToken } = useKeycloak();
  const { isCheckingAuth, isRedirectingToLogin, isRedirectingToAccessDenied, isAuthorized } = useRoleProtection();

  // ✅ FORM HOOKS MOVED TO THE TOP
  const createForm = useForm<CreateLLMFormValues>({
    resolver: zodResolver(createLLMSchema),
    defaultValues: {
      provider: "",
      prefix: "",
      model: "",
      key: "",
    },
  });

  const updateForm = useForm<UpdateLLMFormValues>({
    resolver: zodResolver(updateLLMSchema),
    defaultValues: {
      provider: "",
      prefix: "",
      model: "",
      key: "",
    },
  });

  // ✅ useCallback MOVED TO THE TOP - BEFORE CONDITIONAL RETURNS
  const fetchLLMs = useCallback(async () => {
    setLoading(true);
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/llm/llm`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
    
      if (!response.ok) {
        throw new Error("Failed to fetch LLMs");
      }
      console.log("Response :", response);
      const data = await response.json();
      setLlms(Array.isArray(data) ? data : []);

      toast({
        title: "LLMs Loaded",
        description: "Successfully fetched all LLMs.",
        duration: 2000,
      });
    } catch (err) {
      console.error("Fetch error:", err);
      toast({
        title: "Error",
        description: "Failed to fetch LLMs.",
        variant: "destructive",
        duration: 2000,
      });
      setLlms([]);
    } finally {
      setLoading(false);
    }
  }, [toast]);

  // ✅ useEffect MOVED TO THE TOP - BEFORE CONDITIONAL RETURNS
  useEffect(() => {
    fetchLLMs();
  }, [fetchLLMs]);

  // ✅ CONDITIONAL RETURNS NOW COME AFTER ALL HOOKS
  if (isCheckingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (isRedirectingToLogin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Redirecting to login...</p>
        </div>
      </div>
    );
  }

  if (isRedirectingToAccessDenied) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Checking permissions...</p>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return null;
  }

  // ✅ ALL FUNCTIONS AND HANDLERS AFTER HOOKS AND CONDITIONAL RETURNS
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  // Create LLM
  const onCreateSubmit = async (values: CreateLLMFormValues) => {
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/llm/llm`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(values),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to create LLM");
      }

      toast({
        title: "Success",
        description: "LLM created successfully.",
      });

      createForm.reset();
      setCreateDialogOpen(false);
      await fetchLLMs();
    } catch (error) {
      console.error("Create error:", error);
      toast({
        title: "Error",
        description: "Failed to create LLM.",
        variant: "destructive",
      });
    }
  };

  // Update LLM
  const onUpdateSubmit = async (values: UpdateLLMFormValues) => {
    if (!selectedLLM) return;

    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/llm/llm/${selectedLLM.id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(values),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to update LLM");
      }

      toast({
        title: "Success",
        description: "LLM updated successfully.",
      });

      updateForm.reset();
      setUpdateDialogOpen(false);
      setSelectedLLM(null);
      await fetchLLMs();
    } catch (error) {
      console.error("Update error:", error);
      toast({
        title: "Error",
        description: "Failed to update LLM.",
        variant: "destructive",
      });
    }
  };

  // Delete LLM
  const handleDelete = async () => {
    if (!selectedLLM) return;

    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/llm/llm/${selectedLLM.id}`,
        {
          method: "DELETE",
        }
      );

      if (!response.ok) {
        throw new Error("Failed to delete LLM");
      }

      setLlms((prev) => prev.filter((llm) => llm.id !== selectedLLM.id));

      toast({
        title: "Success",
        description: "LLM deleted successfully.",
      });

      setDeleteDialogOpen(false);
      setSelectedLLM(null);
    } catch (error) {
      console.error("Delete error:", error);
      toast({
        title: "Error",
        description: "Failed to delete LLM.",
        variant: "destructive",
      });
    }
  };

  // Handle update dialog open
  const handleUpdateOpen = (llm: LLM) => {
    if (llm.is_default) return; // Prevent opening if it's default
    setSelectedLLM(llm);
    updateForm.reset({
      provider: llm.provider,
      prefix: llm.prefix,
      model: llm.model,
      key: "", // Don't prefill the key for security
    });
    setUpdateDialogOpen(true);
  };

  // Handle delete dialog open
  const handleDeleteOpen = (llm: LLM) => {
    if (llm.is_default) return; // Prevent opening if it's default
    setSelectedLLM(llm);
    setDeleteDialogOpen(true);
  };

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="flex flex-col h-screen">
        {/* Fixed Header */}
        <header className="flex h-16 justify-between px-4 shrink-0 items-center gap-2 sticky top-0 z-10 bg-background border-b">
          <div className="flex items-center gap-2 px-4">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem className="hidden md:block">
                  <BreadcrumbLink asChild>
                    <Link href="/job_description">Home</Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="hidden md:block" />
                <BreadcrumbItem>
                  <BreadcrumbPage>LLM Management</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
          <div className="flex items-center justify-center gap-4">
             <a
              href="/careers"
              className="text-base font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Careers
            </a>
            <Button variant="outline" size="icon" onClick={toggleTheme}>
              {theme === "dark" ? (
                <Sun className="h-[1.2rem] w-[1.2rem]" />
              ) : (
                <Moon className="h-[1.2rem] w-[1.2rem]" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
            <Button variant="outline" size="icon" onClick={logout}>
              <LogOut className="h-[1.2rem] w-[1.2rem]" />
              <span className="sr-only">Logout</span>
            </Button>
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-auto">
          <div className="p-6">
            <div className="min-h-[calc(100vh-4rem)] rounded-xl bg-muted/50 p-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>LLM Management</CardTitle>
                      <CardDescription>
                        Manage your Large Language Models configuration
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={fetchLLMs}
                        disabled={loading}
                      >
                        <RefreshCw
                          className={`h-4 w-4  ${
                            loading ? "animate-spin" : ""
                          }`}
                        />
                        Refresh
                      </Button>
                      <Dialog
                        open={createDialogOpen}
                        onOpenChange={setCreateDialogOpen}
                      >
                        <DialogTrigger asChild>
                          <Button
                            size="sm"
                            className="bg-blue-500 text-white flex items-center hover:bg-blue-600 focus:bg-blue-600 active:bg-blue-700"
                          >
                            <Plus className="h-4 w-4" />
                            Add LLM
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[425px]">
                          <DialogHeader>
                            <DialogTitle>Create New LLM</DialogTitle>
                            <DialogDescription>
                              Add a new Large Language Model configuration.
                            </DialogDescription>
                          </DialogHeader>
                          <Form {...createForm}>
                            <div
                              onSubmit={createForm.handleSubmit(onCreateSubmit)}
                              className="space-y-4"
                            >
                              <FormField
                                control={createForm.control}
                                name="provider"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Provider</FormLabel>
                                    <Select
                                      onValueChange={field.onChange}
                                      defaultValue={field.value}
                                    >
                                      <FormControl>
                                        <SelectTrigger>
                                          <SelectValue placeholder="Select provider" />
                                        </SelectTrigger>
                                      </FormControl>
                                      <SelectContent>
                                        <SelectItem value="OpenAI">
                                          OpenAI
                                        </SelectItem>
                                        <SelectItem value="Anthropic">
                                          Anthropic
                                        </SelectItem>
                                        <SelectItem value="Google">
                                          Google
                                        </SelectItem>
                                        <SelectItem value="Cohere">
                                          Cohere
                                        </SelectItem>
                                        <SelectItem value="Hugging Face">
                                          Hugging Face
                                        </SelectItem>
                                        <SelectItem value="Other">
                                          Other
                                        </SelectItem>
                                      </SelectContent>
                                    </Select>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={createForm.control}
                                name="prefix"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Prefix</FormLabel>
                                    <FormControl>
                                      <Input
                                        placeholder="e.g., gpt, claude"
                                        {...field}
                                      />
                                    </FormControl>
                                    <FormDescription>
                                      Model prefix identifier
                                    </FormDescription>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={createForm.control}
                                name="model"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Model</FormLabel>
                                    <FormControl>
                                      <Input
                                        placeholder="e.g., gpt-4, claude-3"
                                        {...field}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={createForm.control}
                                name="key"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>API Key</FormLabel>
                                    <FormControl>
                                      <Input
                                        type="password"
                                        placeholder="Enter API key"
                                        {...field}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <DialogFooter>
                                <Button
                                  onClick={createForm.handleSubmit(
                                    onCreateSubmit
                                  )}
                                  className="bg-blue-600 hover:bg-blue-700 text-white"
                                >
                                  Create LLM
                                </Button>
                              </DialogFooter>
                            </div>
                          </Form>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="flex items-center justify-center h-64">
                      <div className="text-center space-y-2">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                        <p className="text-gray-500 dark:text-gray-300">
                          Loading...
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse border border-gray-200 dark:border-gray-700">
                        <thead>
                          <tr className="bg-gray-50 dark:bg-gray-800">
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              S.No
                            </th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              Provider
                            </th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              Prefix
                            </th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              Model
                            </th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              API Key
                            </th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              Created By
                            </th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {llms.length === 0 ? (
                            <tr>
                              <td
                                colSpan={7}
                                className="border border-gray-200 dark:border-gray-700 px-4 py-8 text-center"
                              >
                                No LLMs found. Create your first LLM
                                configuration.
                              </td>
                            </tr>
                          ) : (
                            llms.map((llm, index) => (
                              <tr
                                key={llm.id}
                                className="hover:bg-gray-50 dark:hover:bg-gray-800"
                              >
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2 font-medium">
                                  {index + 1}
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  <div className="flex items-center gap-2">
                                    {llm.provider}
                                    {llm.is_default && (
                                      <span className="px-2 py-1 text-xs bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 rounded-full">
                                        Default
                                      </span>
                                    )}
                                  </div>
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  {llm.prefix}
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  {llm.model}
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  <span className="font-mono text-sm">
                                    {llm.key ? "••••••••••••••••" : "N/A"}
                                  </span>
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  {llm.created_by || "System"}
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  <div className="flex gap-2">
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleUpdateOpen(llm)}
                                      disabled={llm.is_default}
                                      className={llm.is_default ? "opacity-50 cursor-not-allowed" : ""}
                                    >
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleDeleteOpen(llm)}
                                      disabled={llm.is_default}
                                      className={llm.is_default ? "opacity-50 cursor-not-allowed" : ""}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </SidebarInset>

      {/* Update Dialog */}
      <Dialog open={updateDialogOpen} onOpenChange={setUpdateDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Update LLM</DialogTitle>
            <DialogDescription>
              Update the LLM configuration. Leave API key empty to keep current
              key.
            </DialogDescription>
          </DialogHeader>
          <Form {...updateForm}>
            <div
              onSubmit={updateForm.handleSubmit(onUpdateSubmit)}
              className="space-y-4"
            >
              <FormField
                control={updateForm.control}
                name="provider"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Provider</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select provider" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="OpenAI">OpenAI</SelectItem>
                        <SelectItem value="Anthropic">Anthropic</SelectItem>
                        <SelectItem value="Google">Google</SelectItem>
                        <SelectItem value="Cohere">Cohere</SelectItem>
                        <SelectItem value="Hugging Face">
                          Hugging Face
                        </SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={updateForm.control}
                name="prefix"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prefix</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., gpt, claude" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={updateForm.control}
                name="model"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Model</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., gpt-4, claude-3" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={updateForm.control}
                name="key"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>API Key (Optional)</FormLabel>
                    <FormControl>
                      <Input
                        type="password"
                        placeholder="Leave empty to keep current key"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Leave empty to keep the current API key
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="submit"
                  onClick={updateForm.handleSubmit(onUpdateSubmit)}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Update LLM
                </Button>
              </DialogFooter>
            </div>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the LLM
              configuration for "{selectedLLM?.provider} - {selectedLLM?.model}
              ".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </SidebarProvider>
  );
}