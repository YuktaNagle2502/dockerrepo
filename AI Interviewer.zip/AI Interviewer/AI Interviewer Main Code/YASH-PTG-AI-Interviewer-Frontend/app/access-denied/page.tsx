"use client";
 
import React from 'react';
import { Button } from "@/components/ui/button";
import { Lock, UserCheck, ArrowLeft, HelpCircle } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useKeycloak } from "@/context/keycloakContext";
 
export default function AccessDeniedPage() {
  const router = useRouter();
  const { logout } = useKeycloak();
 
  const handleLoginClick = () => {
    console.log('Log in as different user clicked');
    logout();
    router.push('/login');
  };
 
  const handleGoBackClick = () => {
    console.log('Go back clicked');
    router.push('https://apphub.yashtech.link/');
  };
 
  const handleHelpClick = () => {
    console.log('Need help clicked');
    // Add help/support logic here
  };
 
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '100vh',
      padding: '20px',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    }}>
      <div style={{
        padding: '50px 40px',
        borderRadius: '16px',
        textAlign: 'center',
        maxWidth: '520px',
        width: '100%',
        position: 'relative',
        overflow: 'hidden'
      }}>
        {/* Decorative element */}
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: '4px',
        }} />
 
        {/* Lock Icon with background */}
        <div style={{
          marginBottom: '24px',
          display: 'flex',
          justifyContent: 'center'
        }}>
          <div style={{
            width: '80px',
            height: '80px',
            borderRadius: '50%',
            backgroundColor: '#fff2f0',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            border: '3px solid #ffccc7'
          }}>
            <Lock
              style={{
                fontSize: '36px',
                color: '#ff4d4f',
                width: '36px',
                height: '36px'
              }}
            />
          </div>
        </div>
 
        {/* Main Title */}
        <h2 style={{
          fontSize: '26px',
          fontWeight: '600',
          color: '#262626',
          marginBottom: '16px',
          lineHeight: '1.3',
          margin: '0 0 16px 0'
        }}>
          Access Restricted
        </h2>
 
        {/* Friendly explanation */}
        <p style={{
          fontSize: '16px',
          color: '#595959',
          marginBottom: '24px',
          lineHeight: '1.6',
          margin: '0 0 24px 0'
        }}>
          We're sorry, but you don't have the necessary permissions to view this page.
          This could be because your session has expired or you need different access rights.
        </p>
 
        {/* Helpful suggestions */}
        <div style={{
          backgroundColor: '#f6ffed',
          border: '1px solid #b7eb8f',
          borderRadius: '8px',
          padding: '16px',
          marginBottom: '32px',
          textAlign: 'left'
        }}>
          <span style={{
            color: '#52c41a',
            fontSize: '14px',
            fontWeight: '600'
          }}>
            💡 What you can try:
          </span>
          <ul style={{
            margin: '8px 0 0 0',
            paddingLeft: '20px',
            color: '#595959',
            fontSize: '14px'
          }}>
            <li>Sign in with a different account that has access</li>
            <li>Go back to the previous page</li>
            <li>Contact your administrator for access</li>
          </ul>
        </div>
 
        {/* Action Buttons */}
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '24px',
          width: '100%'
        }}>
          <div style={{
            display: 'flex',
            gap: '12px',
            width: '100%',
            justifyContent: 'center'
          }}>
            <Button
              onClick={handleLoginClick}
              style={{
                backgroundColor: '#1890ff',
                borderColor: '#1890ff',
                fontWeight: '500',
                height: '46px',
                padding: '0 24px',
                fontSize: '15px',
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(24, 144, 255, 0.3)',
                color: 'white',
                border: 'none',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              <UserCheck style={{ width: '16px', height: '16px' }} />
              Switch Account
            </Button>
 
            <Button
              variant="outline"
              onClick={handleGoBackClick}
              style={{
                fontWeight: '500',
                height: '46px',
                padding: '0 24px',
                fontSize: '15px',
                borderRadius: '8px',
                borderColor: '#d9d9d9',
                backgroundColor: 'white',
                color: '#262626',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              {/* <ArrowLeft style={{ width: '16px', height: '16px' }} /> */}
              Launcher
            </Button>
          </div>
 
          {/* Divider */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            margin: '16px 0',
            gap: '16px'
          }}>
            <div style={{
              flex: 1,
              height: '1px',
              backgroundColor: '#d9d9d9'
            }} />
            <span style={{
              color: '#8c8c8c',
              fontSize: '14px'
            }}>
              or
            </span>
            <div style={{
              flex: 1,
              height: '1px',
              backgroundColor: '#d9d9d9'
            }} />
          </div>
 
          <Button
            variant="link"
            onClick={handleHelpClick}
            style={{
              color: '#722ed1',
              fontSize: '15px',
              fontWeight: '500',
              padding: '0',
              height: 'auto',
              textDecoration: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px'
            }}
          >
            <HelpCircle style={{ width: '16px', height: '16px' }} />
            Need help? Contact support
          </Button>
        </div>
      </div>
 
      {/* Footer text */}
      <p style={{
        color: 'rgba(255, 255, 255, 0.8)',
        fontSize: '14px',
        marginTop: '24px',
        textAlign: 'center',
        margin: '24px 0 0 0'
      }}>
        If you believe this is an error, please contact your system administrator
      </p>
    </div>
  );
}
 