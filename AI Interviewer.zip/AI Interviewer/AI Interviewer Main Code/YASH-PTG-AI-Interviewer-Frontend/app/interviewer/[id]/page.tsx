"use client";

import { useTheme } from "next-themes";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
// import { InterviewSidebar } from "@/components/layout/Interviewsidebar";
import InterviewRulesPage from "@/components/interview/Interviewrules";
import { useEffect, useState } from "react";
import { useInterviewStore } from "@/stores/interview-store";
import CameraComponent from "@/components/media/CameraComponent";
import { useParams } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import { authFetch } from "@/lib/authFetch";
import { Moon, Sun, Clock } from "lucide-react";

interface InterviewDetails {
  id: number;
  unique_id: string;
  user_image: string; // This will now be the Azure URL
  user_image_path: string; // The blob path stored in database
  url: string;
  interview_questions: string | null;
  interview_answers: string | null;
  status: "pending" | "scheduled" | "completed" | "cancelled";
  scheduled_at: string;
  candidate_name: string;
  candidate_phone: string;
}

function Interviewpage() {
  const params = useParams();
  const interviewId = params?.id as string;
  const { toast } = useToast();

  const [image, setImage] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const { theme, setTheme } = useTheme();
  const [isCameraStarted, setIsCameraStarted] = useState(false);
  const [proceed, setProceed] = useState(false);
  const { interviewQuestions, setInterviewQuestions, clearInterviewQuestions } =
    useInterviewStore();
  const [interviewDetails, setInterviewDetails] =
    useState<InterviewDetails | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [isInterviewTime, setIsInterviewTime] = useState(false);
  const [scheduledTime, setScheduledTime] = useState<Date | null>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const parseScheduledTime = (errorMessage: string): Date | null => {
    const timeRegex = /(\d{2}:\d{2} [AP]M) on (\d{4}-\d{2}-\d{2})/;
    const match = errorMessage.match(timeRegex);
    
    if (match) {
      const [, time, date] = match;
      const dateTimeString = `${date} ${time}`;
      return new Date(dateTimeString);
    }
    return null;
  };

  const formatTimeLeft = (seconds: number) => {
    const days = Math.floor(seconds / (24 * 3600));
    const hours = Math.floor((seconds % (24 * 3600)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (days > 0) {
      return `${days}d ${hours}h ${minutes}m ${secs}s`;
    } else if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    } else {
      return `${minutes}m ${secs}s`;
    }
  };

  const fetchInterviewDetails = async (uniqueId: string, silent = false) => {
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/interview/${uniqueId}`
      );

      console.log(uniqueId);

      if (!response.ok) {
        let errorMsg = `HTTP error! status: ${response.status}`;
        try {
          const errorData = await response.json();
          if (errorData.detail) {
            errorMsg =
              typeof errorData.detail === "string"
                ? errorData.detail
                : JSON.stringify(errorData.detail);
          } else if (errorData.message) {
            errorMsg = errorData.message;
          }
        } catch {
          // fallback to status text if JSON parsing fails
          errorMsg = response.statusText || errorMsg;
        }
        
        // Parse scheduled time from error message
        const parsedTime = parseScheduledTime(errorMsg);
        if (parsedTime) {
          setScheduledTime(parsedTime);
          const now = new Date().getTime();
          const target = parsedTime.getTime();
          const difference = Math.floor((target - now) / 1000);
          
          if (difference > 0) {
            setTimeLeft(difference);
            setIsInterviewTime(false);
          } else {
            setIsInterviewTime(true);
          }
        }
        
        throw new Error(errorMsg);
      }

      const data = await response.json();
      
      // Ensure we're using the Azure URL for user_image
      // The backend should already return user_image as the Azure URL
      console.log("Interview data received:", data);
      console.log("User image URL:", data.user_image);
      
      setInterviewDetails(data);

      // Set interview questions if they exist
      if (data.questions) {
        setInterviewQuestions(data.questions);
      }

      return data.status === "scheduled" || data.status === "pending";
    } catch (error) {
      if (!silent) {
        console.error("Error fetching interview details:", error);
        setErrorMsg(
          error instanceof Error ? error.message : "Failed to fetch interview details"
        );
        toast({
          title: "Error",
          description:
            error instanceof Error
              ? error.message
              : "Failed to fetch interview details",
          variant: "destructive",
        });
      }
      return false;
    }
  };
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        if (interviewId) {
          await fetchInterviewDetails(interviewId);
        }
      } catch (error) {
        console.error("Error fetching interview data:", error);
        toast({
          title: "Error",
          description: "Failed to load interview data",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [interviewId]);

  useEffect(() => {
    if (scheduledTime) {
      const timer = setInterval(() => {
        const now = new Date().getTime();
        const target = scheduledTime.getTime();
        const difference = Math.floor((target - now) / 1000);

        if (difference <= 0) {
          setIsInterviewTime(true);
          setTimeLeft(0);
          clearInterval(timer);
          setIsTransitioning(true);
          // Wait a few seconds before retrying to allow server to update
          setTimeout(() => {
            fetchInterviewDetails(interviewId, true).finally(() => {
              setIsTransitioning(false);
            });
          }, 3000);
        } else {
          setTimeLeft(difference);
        }
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [scheduledTime]);

  useEffect(() => {
    return () => {
      clearInterviewQuestions();
    };
  }, []);

  if (isLoading) {
    return (
      <SidebarProvider>
        <SidebarInset className="h-screen flex flex-col">
          <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4 justify-between bg-background">
            <div className="flex items-center">
              <SidebarTrigger className="-ml-1" />
              <Separator orientation="vertical" className="mr-2 h-4" />
              <Breadcrumb>
                <BreadcrumbList>
                  <BreadcrumbItem className="hidden md:block"></BreadcrumbItem>
                  <BreadcrumbSeparator className="hidden md:block" />
                  <BreadcrumbItem>
                    <BreadcrumbPage>Interview</BreadcrumbPage>
                  </BreadcrumbItem>
                </BreadcrumbList>
              </Breadcrumb>
            </div>
            <div className="flex items-center">
              <Button variant="outline" size="icon" onClick={toggleTheme}>
                {theme === "dark" ? (
                  <Sun className="h-[1.2rem] w-[1.2rem]" />
                ) : (
                  <Moon className="h-[1.2rem] w-[1.2rem]" />
                )}
                <span className="sr-only">Toggle theme</span>
              </Button>
            </div>
          </header>
          <div className="flex-1 overflow-y-auto">
            <div className="flex justify-center items-center mt-10">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          </div>
        </SidebarInset>
      </SidebarProvider>
    );
  }

  // Show loader when transitioning after timer ends
  if (isTransitioning) {
    return (
      <SidebarProvider>
        <SidebarInset className="h-screen flex flex-col">
          <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4 justify-between bg-background">
            <div className="flex items-center">
              <SidebarTrigger className="-ml-1" />
              <Separator orientation="vertical" className="mr-2 h-4" />
              <Breadcrumb>
                <BreadcrumbList>
                  <BreadcrumbItem className="hidden md:block">
                    <BreadcrumbLink href="/job_description">Home</BreadcrumbLink>
                  </BreadcrumbItem>
                  <BreadcrumbSeparator className="hidden md:block" />
                  <BreadcrumbItem>
                    <BreadcrumbPage>Interview</BreadcrumbPage>
                  </BreadcrumbItem>
                </BreadcrumbList>
              </Breadcrumb>
            </div>
            <div className="flex items-center">
              <Button variant="outline" size="icon" onClick={toggleTheme}>
                {theme === "dark" ? (
                  <Sun className="h-[1.2rem] w-[1.2rem]" />
                ) : (
                  <Moon className="h-[1.2rem] w-[1.2rem]" />
                )}
                <span className="sr-only">Toggle theme</span>
              </Button>
            </div>
          </header>
          <div className="flex-1 overflow-y-auto bg-white dark:bg-black">
            <div className="flex justify-center items-start pt-20 px-4">
              <Card className="w-full max-w-lg shadow-2xl dark:shadow-[0_8px_48px_8px_rgba(255,255,255,0.18)] border-0 bg-white dark:bg-black backdrop-blur-sm">
                <CardHeader className="text-center pb-4">
                  <div className="flex justify-center mb-4">
                    <div className="relative">
                      <Clock className="h-14 w-14 text-black dark:text-white animate-pulse" />
                      <div className="absolute -inset-1 bg-black/10 dark:bg-white/10 rounded-full blur-md opacity-60"></div>
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold text-black dark:text-white mb-2">
                    Interview Starts In
                  </CardTitle>
                  <CardDescription className="text-base text-black dark:text-white leading-relaxed">
                    {errorMsg || ""}
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center pb-6">
                  <div className="rounded-xl p-4 mb-4 shadow bg-white dark:bg-black">
                    <div className="text-3xl font-bold mb-1 tracking-wide text-black dark:text-white">
                      {typeof formatTimeLeft === "function" && timeLeft !== null ? formatTimeLeft(timeLeft) : ""}
                    </div>
                    <div className="text-xs uppercase tracking-widest text-black dark:text-white">
                      Time Remaining
                    </div>
                  </div>
                  <p className="text-base leading-relaxed text-black dark:text-white">
                    Please wait until the scheduled time to access your interview.
                  </p>
                  <div className="mt-4 flex justify-center">
                    <div className="flex space-x-1">
                      <div className="w-1.5 h-1.5 bg-black dark:bg-white rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-black dark:bg-white rounded-full animate-bounce" style={{ animationDelay: '0.08s' }}></div>
                      <div className="w-1.5 h-1.5 bg-black dark:bg-white rounded-full animate-bounce" style={{ animationDelay: '0.16s' }}></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </SidebarInset>
      </SidebarProvider>
    );
  }

  // Show countdown timer if interview is scheduled for future
  if (scheduledTime && !isInterviewTime && timeLeft !== null) {
    return (
      <SidebarProvider>
        <SidebarInset className="h-screen flex flex-col">
          <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4 justify-between bg-background">
            <div className="flex items-center">
              <SidebarTrigger className="-ml-1" />
              <Separator orientation="vertical" className="mr-2 h-4" />
              <Breadcrumb>
                <BreadcrumbList>
                  <BreadcrumbItem className="hidden md:block">
                    <BreadcrumbLink href="/job_description">Home</BreadcrumbLink>
                  </BreadcrumbItem>
                  <BreadcrumbSeparator className="hidden md:block" />
                  <BreadcrumbItem>
                    <BreadcrumbPage>Interview</BreadcrumbPage>
                  </BreadcrumbItem>
                </BreadcrumbList>
              </Breadcrumb>
            </div>
            <div className="flex items-center">
              <Button variant="outline" size="icon" onClick={toggleTheme}>
                {theme === "dark" ? (
                  <Sun className="h-[1.2rem] w-[1.2rem]" />
                ) : (
                  <Moon className="h-[1.2rem] w-[1.2rem]" />
                )}
                <span className="sr-only">Toggle theme</span>
              </Button>
            </div>
          </header>
          <div className="flex-1 overflow-y-auto bg-white dark:bg-black">
            <div className="flex justify-center items-start pt-20 px-4">
              <Card className="w-full max-w-lg shadow-2xl dark:shadow-[0_8px_48px_8px_rgba(255,255,255,0.18)] border-0 bg-white dark:bg-black backdrop-blur-sm">
                <CardHeader className="text-center pb-4">
                  <div className="flex justify-center mb-4">
                    <div className="relative">
                      <Clock className="h-14 w-14 text-black dark:text-white animate-pulse" />
                      <div className="absolute -inset-1 bg-black/10 dark:bg-white/10 rounded-full blur-md opacity-60"></div>
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold text-black dark:text-white mb-2">
                    Interview Starts In
                  </CardTitle>
                  <CardDescription className="text-base text-black dark:text-white leading-relaxed">
                    {errorMsg || ""}
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center pb-6">
                  <div className="rounded-xl p-4 mb-4 shadow bg-white dark:bg-black">
                    <div className="text-3xl font-bold mb-1 tracking-wide text-black dark:text-white">
                      {typeof formatTimeLeft === "function" && timeLeft !== null ? formatTimeLeft(timeLeft) : ""}
                    </div>
                    <div className="text-xs uppercase tracking-widest text-black dark:text-white">
                      Time Remaining
                    </div>
                  </div>
                  <p className="text-base leading-relaxed text-black dark:text-white">
                    Please wait until the scheduled time to access your interview.
                  </p>
                  <div className="mt-4 flex justify-center">
                    <div className="flex space-x-1">
                      <div className="w-1.5 h-1.5 bg-black dark:bg-white rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-black dark:bg-white rounded-full animate-bounce" style={{ animationDelay: '0.08s' }}></div>
                      <div className="w-1.5 h-1.5 bg-black dark:bg-white rounded-full animate-bounce" style={{ animationDelay: '0.16s' }}></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </SidebarInset>
      </SidebarProvider>
    );
  }

  if (
    !interviewDetails ||
    (interviewDetails.status !== "scheduled" &&
      interviewDetails.status !== "pending")
  ) {
    return (
      <SidebarProvider>
        <SidebarInset className="h-screen flex flex-col">
          <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4 justify-between bg-background">
            <div className="flex items-center">
              <SidebarTrigger className="-ml-1" />
              <Separator orientation="vertical" className="mr-2 h-4" />
              <Breadcrumb>
                <BreadcrumbList>
                  <BreadcrumbItem className="hidden md:block">
                    <BreadcrumbLink href="/job_description">Home</BreadcrumbLink>
                  </BreadcrumbItem>
                  <BreadcrumbSeparator className="hidden md:block" />
                  <BreadcrumbItem>
                    <BreadcrumbPage>Interview</BreadcrumbPage>
                  </BreadcrumbItem>
                </BreadcrumbList>
              </Breadcrumb>
            </div>
            <div className="flex items-center">
              <Button variant="outline" size="icon" onClick={toggleTheme}>
                {theme === "dark" ? (
                  <Sun className="h-[1.2rem] w-[1.2rem]" />
                ) : (
                  <Moon className="h-[1.2rem] w-[1.2rem]" />
                )}
                <span className="sr-only">Toggle theme</span>
              </Button>
            </div>
          </header>

          {/* Scrollable Content Area */}
          <div className="flex-1 overflow-y-auto">
            <div className="flex justify-center items-center mt-10">
              <Card className="w-full mr-[15vh] max-w-md">
                <CardHeader>
                  <CardTitle className="text-lg text-destructive dark:text-red-400">
                    Interview Not Available
                  </CardTitle>
                  <CardDescription className="text-lg dark:text-gray-300">
                    {errorMsg ||
                      "The interview is either not scheduled or has already been completed."}
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>
          </div>
        </SidebarInset>
      </SidebarProvider>
    );
  }

  return (
    <SidebarProvider>
      <SidebarInset className="h-screen flex flex-col">
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4 justify-between bg-background">
          <div className="flex items-center">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem className="hidden md:block">
                  <BreadcrumbLink href="/job_description">Home</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="hidden md:block" />
                <BreadcrumbItem>
                  <BreadcrumbPage>Interview</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
          <div className="flex items-center">
            <Button variant="outline" size="icon" onClick={toggleTheme}>
              {theme === "dark" ? (
                <Sun className="h-[1.2rem] w-[1.2rem]" />
              ) : (
                <Moon className="h-[1.2rem] w-[1.2rem]" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
          </div>
        </header>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-h-0">
          {/* Title Section - Fixed */}
          {/* <div className="flex justify-center items-center py-8 px-4">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white text-center">
              AI Interviewer
            </h1>
          </div> */}

          {/* Dynamic Content Area - Scrollable if needed */}
          <div className="flex-1  px-4 pb-4">
            {!proceed && !isCameraStarted ? (
              <div className="flex justify-center items-center min-h-screen">
                <Card className="w-full max-w-md">
                  <CardHeader>
                    <CardTitle className="text-lg text-gray-900 dark:text-white">
                      Capture Your Photo
                    </CardTitle>
                    <CardDescription className="text-lg dark:text-gray-300">
                      Hello {interviewDetails?.candidate_name || "Candidate"}, please capture your
                      photo for the interview process.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="text-lg text-muted-foreground dark:text-gray-300">
                        Instructions:
                        <ul className="list-disc list-inside mt-2">
                          <li>Ensure you are in a well-lit area</li>
                          <li>Look directly at the camera</li>
                          <li>Make sure your face is clearly visible</li>
                        </ul>
                      </div>
                      <Button
                        onClick={() => setIsCameraStarted(true)}
                        className="w-full"
                      >
                        Start Camera
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : !proceed && isCameraStarted ? (
              <CameraComponent
                userImageUrl={interviewDetails?.user_image}
                image={image}
                setProceed={setProceed}
                setImage={setImage}
                interview_id={interviewId}
              />
            ) : (
              <InterviewRulesPage interviewId={interviewId} />
            )}
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}

export default function Page() {
  return <Interviewpage />;
}
