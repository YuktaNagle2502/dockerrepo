"use client";
 
import { useEffect, useRef } from "react";
import { useKeycloak } from "@/context/keycloakContext";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { LogIn } from "lucide-react";
import { redirect, useRouter } from "next/navigation";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import Link from "next/link";
 
export default function LoginPage() {
  const {
    keycloak,
    initialized,
    authenticated,
    login,
    hasValidToken,
    hasRequiredRole
  } = useKeycloak();
  const router = useRouter();
  const { theme, setTheme } = useTheme();
  const redirecting = useRef(false);
 
  useEffect(() => {
    // If user is already authenticated and has valid token
    if (authenticated && hasValidToken && initialized) {
      // Check if user has required role
      if (hasRequiredRole) {
        // User has required role, redirect to main app
        router.push("/job_description");
      } else {
        // User doesn't have required role, redirect to access denied
        router.push("/access-denied");
      }
    }
  }, [authenticated, hasValidToken, hasRequiredRole, initialized, router]);
 
  // Show loading while checking authentication
  if (!initialized) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
      </div>
    );
  }
 
  // If already authenticated, show loading while redirecting
  if (authenticated || hasValidToken) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Redirecting...</p>
        </div>
      </div>
    );
  }
 
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };
 
  return (
    <div className="min-h-screen flex flex-col bg-background p-4">
      {/* Top right header */}
      <div className="w-full flex justify-end items-center gap-4 mb-8">
        <Link
          href="/careers"
          className="text-base font-medium hover:underline text-foreground"
        >
          Careers
        </Link>
        <Button variant="outline" size="icon" onClick={toggleTheme}>
          {theme === "dark" ? (
            <Sun className="h-[1.2rem] w-[1.2rem]" />
          ) : (
            <Moon className="h-[1.2rem] w-[1.2rem]" />
          )}
          <span className="sr-only">Toggle theme</span>
        </Button>
      </div>
      {/* Centered login card */}
      <div className="flex flex-1 items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold">Welcome Back</CardTitle>
            <CardDescription>
              Sign in to access your AI Interviewer admin account
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={login}
              className="w-full"
              size="lg"
              disabled={!initialized}
            >
              <LogIn className="mr-2 h-4 w-4" />
              Sign in
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
 