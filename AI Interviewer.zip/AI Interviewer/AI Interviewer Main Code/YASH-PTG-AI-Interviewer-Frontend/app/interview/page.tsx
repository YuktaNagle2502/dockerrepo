"use client";

import { AppSidebar } from "@/components/layout/app-sidebar";
import { Moon, MoonIcon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { Camera } from "react-camera-pro";
import { Separator } from "@/components/ui/separator";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { InterviewSidebar } from "@/components/layout/Interviewsidebar";
// import InterviewRulesPage from "@/components/interview/Interviewrules";
import { useEffect, useState } from "react";
import { useInterviewStore } from "@/stores/interview-store";
import CameraComponent from "@/components/media/CameraComponent";

function Interviewpage() {
  const [image, setImage] = useState(null);
  const { theme, setTheme } = useTheme();
  const [isCameraStarted, setIsCameraStarted] = useState(false);
  const [proceed, setProceed] = useState(false);
  const { interviewQuestions, clearInterviewQuestions } = useInterviewStore();

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  useEffect(() => {
    console.log("Persisted Interview Questions:", interviewQuestions);
  }, [interviewQuestions]);

  return (
    <>
      <SidebarProvider>
        {/* <InterviewSidebar /> */}
        <SidebarInset>
          <div className="flex justify-center items-center heading text-5xl mt-8 ml-[-88px]">
            <h1>AI Interviewer</h1>
          </div>

          {interviewQuestions.length !== 0 &&
          proceed === false &&
          !isCameraStarted ? (
            <div className="flex justify-center items-center min-h-screen">
              <Card className="w-full max-w-md">
                <CardHeader>
                  <CardTitle className="text-lg">Capture Your Photo</CardTitle>
                  <CardDescription className="text-lg">
                    We need to capture your photo for the interview process.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div
                      className={`text-lg ${
                        theme === "dark" ? "text-white" : "text-black"
                      }`}
                    >
                      Instructions:
                      <ul className="list-disc list-inside mt-2">
                        <li>Ensure you are in a well-lit area</li>
                        <li>Look directly at the camera</li>
                        <li>Make sure your face is clearly visible</li>
                      </ul>
                    </div>
                    <Button
                      onClick={() => setIsCameraStarted(true)}
                      className="w-full"
                    >
                      Start Camera
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : interviewQuestions.length !== 0 &&
            proceed === false &&
            isCameraStarted ? (
            // <CameraComponent
            //   image={image}
            //   setProceed={setProceed}
            //   setImage={setImage}
            // />
            <></>
          ) : (
            // <InterviewRulesPage  />
            <></>
          )}
        </SidebarInset>
      </SidebarProvider>
    </>
  );
}

export default function Page() {
  return <Interviewpage />;
}
