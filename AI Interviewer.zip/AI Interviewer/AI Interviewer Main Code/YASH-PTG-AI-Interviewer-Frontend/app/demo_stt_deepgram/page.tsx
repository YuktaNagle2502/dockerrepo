import LiveTranscription from '@/components/interview/LiveTranscription';

export default function Home() {
  return (
    <LiveTranscription apiKey={process.env.NEXT_PUBLIC_DEEPGRAM_API_KEY || ''} />
  );
}