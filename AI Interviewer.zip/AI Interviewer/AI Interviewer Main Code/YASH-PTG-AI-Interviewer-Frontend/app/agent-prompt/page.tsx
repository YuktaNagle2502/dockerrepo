"use client";

import { AppSidebar } from "@/components/layout/app-sidebar";
import {
  Moon,
  Sun,
  Plus,
  Pencil,
  Trash2,
  RefreshCw,
  ArrowLeft,
  LogOut,
} from "lucide-react";
import { useTheme } from "next-themes";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Separator } from "@/components/ui/separator";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import React, { useState, useEffect, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import * as z from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { authFetch } from "@/lib/authFetch";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useKeycloak } from "@/context/keycloakContext";
import { useRoleProtection } from "@/hooks/useRoleProtection";

// Function to extract placeholders from prompt text
const extractPlaceholders = (text: string): string[] => {
  const placeholderRegex = /\{([^}]+)\}/g;
  const matches = [];
  let match;

  while ((match = placeholderRegex.exec(text)) !== null) {
    matches.push(match[1]);
  }

  return [...new Set(matches)]; // Remove duplicates
};

// Types
interface AgentPrompt {
  id: number;
  tech_stack_id: number;
  agent_name: string;
  prompt: string;
  placeholders: Record<string, string>;
  type: "ASSISTANT" | "AGENT" | "MESSAGE" | "TASK";
  created_at?: string;
  updated_at?: string;
}

interface TechStack {
  id: number;
  tech_stack: string;
}

// Form schemas
const createAgentPromptSchema = z.object({
  agent_name: z.string().min(1, "Agent name is required"),
  prompt: z.string().min(1, "Prompt is required"),
  type: z.enum(["ASSISTANT", "AGENT", "MESSAGE", "TASK"]),
  placeholders: z.string().optional(),
});

const updateAgentPromptSchema = z.object({
  prompt: z.string().min(1, "Prompt is required"),
  placeholders: z.string().optional(),
});

type CreateAgentPromptFormValues = z.infer<typeof createAgentPromptSchema>;
type UpdateAgentPromptFormValues = z.infer<typeof updateAgentPromptSchema>;

export default function AgentPromptPage() {
// ← ADD ROLE PROTECTION HOOK
// const { isCheckingAuth, isRedirectingToLogin, isRedirectingToAccessDenied, isAuthorized } = useRoleProtection();
// // ← ADD AUTHORIZATION CHECKS
// if (isCheckingAuth) {
//   return (
//     <div className="min-h-screen flex items-center justify-center">
//       <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
//     </div>
//   );
// }

// if (isRedirectingToLogin) {
//   return (
//     <div className="min-h-screen flex items-center justify-center">
//       <div className="text-center">
//         <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
//         <p>Redirecting to login...</p>
//       </div>
//     </div>
//   );
// }

// if (isRedirectingToAccessDenied) {
//   return (
//     <div className="min-h-screen flex items-center justify-center">
//       <div className="text-center">
//         <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
//         <p>Checking permissions...</p>
//       </div>
//     </div>
//   );
// }

// if (!isAuthorized) {
//   return null;
// }




  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const [agentPrompts, setAgentPrompts] = useState<AgentPrompt[]>([]);
  const [techStack, setTechStack] = useState<TechStack | null>(null);
  const [loading, setLoading] = useState(true);
  const [createPromptDialogOpen, setCreatePromptDialogOpen] = useState(false);
  const [updatePromptDialogOpen, setUpdatePromptDialogOpen] = useState(false);
  const [deletePromptDialogOpen, setDeletePromptDialogOpen] = useState(false);
  const [selectedAgentPrompt, setSelectedAgentPrompt] =
    useState<AgentPrompt | null>(null);
  const [detectedPlaceholders, setDetectedPlaceholders] = useState<string[]>(
    []
  );
  const { theme, setTheme } = useTheme();
  const { keycloak, initialized, authenticated, logout, hasValidToken } =
    useKeycloak();

  // Get URL parameters
  const techStackId = searchParams.get("techStackId");
  const techStackName = searchParams.get("techStackName");

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  // Create prompt form
  const createPromptForm = useForm<CreateAgentPromptFormValues>({
    resolver: zodResolver(createAgentPromptSchema),
    defaultValues: {
      agent_name: "",
      prompt: "",
      type: "ASSISTANT",
      placeholders: "",
    },
  });

  // Update prompt form (only prompt and placeholders)
  const updatePromptForm = useForm<UpdateAgentPromptFormValues>({
    resolver: zodResolver(updateAgentPromptSchema),
    defaultValues: {
      prompt: "",
      placeholders: "",
    },
  });

  // Function to handle real-time placeholder detection and auto-population
  const updatePlaceholdersFromPrompt = useCallback(
    (promptText: string) => {
      const placeholders = extractPlaceholders(promptText);
      setDetectedPlaceholders(placeholders);

      // Auto-generate placeholder JSON
      if (placeholders.length > 0) {
        const currentPlaceholders = updatePromptForm.getValues("placeholders");
        let existingPlaceholders: Record<string, string> = {};

        // Try to parse existing placeholders
        try {
          if (currentPlaceholders) {
            existingPlaceholders = JSON.parse(currentPlaceholders) as Record<
              string,
              string
            >;
          }
        } catch (e) {
          existingPlaceholders = {};
        }

        // Create new placeholder object with existing values preserved
        const newPlaceholders: Record<string, string> = {
          ...existingPlaceholders,
        };
        placeholders.forEach((placeholder) => {
          if (!(placeholder in newPlaceholders)) {
            newPlaceholders[placeholder] = `sample_${placeholder}`;
          }
        });

        // Remove placeholders that are no longer in the prompt
        Object.keys(newPlaceholders).forEach((key) => {
          if (!placeholders.includes(key)) {
            delete newPlaceholders[key];
          }
        });

        // Update the form field
        updatePromptForm.setValue(
          "placeholders",
          JSON.stringify(newPlaceholders, null, 2)
        );
      } else {
        // If no placeholders detected, clear the field
        updatePromptForm.setValue("placeholders", "");
      }
    },
    [updatePromptForm]
  );

  // Function to clean sample_ prefix when user starts typing
  const handlePlaceholderFocus = useCallback(() => {
    const currentValue = updatePromptForm.getValues("placeholders");

    if (currentValue) {
      try {
        const parsed = JSON.parse(currentValue) as Record<string, string>;
        const cleaned: Record<string, string> = {};

        let hasChanges = false;

        Object.keys(parsed).forEach((key) => {
          const value = parsed[key];
          if (typeof value === "string" && value.startsWith("sample_")) {
            cleaned[key] = "";
            hasChanges = true;
          } else {
            cleaned[key] = value;
          }
        });

        if (hasChanges) {
          updatePromptForm.setValue(
            "placeholders",
            JSON.stringify(cleaned, null, 2)
          );
        }
      } catch (e) {
        // If not valid JSON, don't modify
      }
    }
  }, [updatePromptForm]);

  // Fetch tech stack details
  const fetchTechStack = async () => {
    if (!techStackId) return;

    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/tech-stack/${techStackId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to fetch tech stack");
      }

      const data = await response.json();
      setTechStack(data);
    } catch (err) {
      console.error("Fetch tech stack error:", err);
      // If API fails, use the name from URL params
      if (techStackName) {
        setTechStack({
          id: parseInt(techStackId || "0"),
          tech_stack: decodeURIComponent(techStackName),
        });
      }
    }
  };

  // Fetch agent prompts
  const fetchAgentPrompts = async () => {
    if (!techStackId) return;

    setLoading(true);
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/agent-prompts/tech-stack/${techStackId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to fetch agent prompts");
      }

      const data = await response.json();
      setAgentPrompts(Array.isArray(data) ? data : []);

      toast({
        title: "Agent Prompts Loaded",
        description: "Successfully fetched all agent prompts.",
        duration: 2000,
      });
    } catch (err) {
      console.error("Fetch agent prompts error:", err);
      toast({
        title: "Error",
        description: "Failed to fetch agent prompts.",
        variant: "destructive",
        duration: 2000,
      });
      setAgentPrompts([]);
    } finally {
      setLoading(false);
    }
  };

  // Create agent prompt
  const onCreatePromptSubmit = async (values: CreateAgentPromptFormValues) => {
    if (!techStackId) return;

    try {
      let placeholders = {};
      if (values.placeholders) {
        try {
          placeholders = JSON.parse(values.placeholders);
        } catch (e) {
          toast({
            title: "Error",
            description: "Invalid JSON format for placeholders.",
            variant: "destructive",
          });
          return;
        }
      }

      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/agent-prompts`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            tech_stack_id: parseInt(techStackId),
            agent_name: values.agent_name,
            prompt: values.prompt,
            type: values.type,
            placeholders,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to create agent prompt");
      }

      toast({
        title: "Success",
        description: "Agent prompt created successfully.",
      });

      createPromptForm.reset();
      setCreatePromptDialogOpen(false);
      await fetchAgentPrompts();
    } catch (error) {
      console.error("Create agent prompt error:", error);
      toast({
        title: "Error",
        description: "Failed to create agent prompt.",
        variant: "destructive",
      });
    }
  };

  // Update agent prompt (only prompt and placeholders)
  const onUpdatePromptSubmit = async (values: UpdateAgentPromptFormValues) => {
    if (!selectedAgentPrompt || !techStackId) return;

    try {
      let placeholders = {};
      if (values.placeholders) {
        try {
          placeholders = JSON.parse(values.placeholders);
        } catch (e) {
          toast({
            title: "Error",
            description: "Invalid JSON format for placeholders.",
            variant: "destructive",
          });
          return;
        }
      }

      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/agent-prompts/${selectedAgentPrompt.id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            tech_stack_id: parseInt(techStackId),
            agent_name: selectedAgentPrompt.agent_name, // Keep existing agent name
            prompt: values.prompt,
            type: selectedAgentPrompt.type, // Keep existing type
            placeholders,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to update agent prompt");
      }

      toast({
        title: "Success",
        description: "Agent prompt updated successfully.",
      });

      updatePromptForm.reset();
      setUpdatePromptDialogOpen(false);
      setSelectedAgentPrompt(null);
      setDetectedPlaceholders([]);
      await fetchAgentPrompts();
    } catch (error) {
      console.error("Update agent prompt error:", error);
      toast({
        title: "Error",
        description: "Failed to update agent prompt.",
        variant: "destructive",
      });
    }
  };

  // Delete agent prompt
  const handleDeletePrompt = async () => {
    if (!selectedAgentPrompt) return;

    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/agent-prompts/${selectedAgentPrompt.id}`,
        {
          method: "DELETE",
        }
      );

      if (!response.ok) {
        throw new Error("Failed to delete agent prompt");
      }

      setAgentPrompts((prev) =>
        prev.filter((ap) => ap.id !== selectedAgentPrompt.id)
      );

      toast({
        title: "Success",
        description: "Agent prompt deleted successfully.",
      });

      setDeletePromptDialogOpen(false);
      setSelectedAgentPrompt(null);
    } catch (error) {
      console.error("Delete agent prompt error:", error);
      toast({
        title: "Error",
        description: "Failed to delete agent prompt.",
        variant: "destructive",
      });
    }
  };

  // Handle update prompt dialog open (only populate prompt and placeholders)
  const handleUpdatePromptOpen = (agentPrompt: AgentPrompt) => {
    setSelectedAgentPrompt(agentPrompt);
    updatePromptForm.reset({
      prompt: agentPrompt.prompt,
      placeholders: JSON.stringify(agentPrompt.placeholders, null, 2),
    });

    // Initialize detected placeholders from existing prompt
    const placeholders = extractPlaceholders(agentPrompt.prompt);
    setDetectedPlaceholders(placeholders);

    setUpdatePromptDialogOpen(true);
  };

  // Handle delete prompt dialog open
  const handleDeletePromptOpen = (agentPrompt: AgentPrompt) => {
    setSelectedAgentPrompt(agentPrompt);
    setDeletePromptDialogOpen(true);
  };

  useEffect(() => {
    if (techStackId) {
      fetchTechStack();
      fetchAgentPrompts();
    }
  }, [techStackId]);

  const getTypeColor = (type: string) => {
    switch (type) {
      case "ASSISTANT":
        return "bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200";
      case "AGENT":
        return "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200";
      case "MESSAGE":
        return "bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200";
      case "TASK":
        return "bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-200";
      default:
        return "bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200";
    }
  };

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="flex flex-col h-screen">
        {/* Fixed Header */}
        <header className="flex h-16 justify-between px-4 shrink-0 items-center gap-2 sticky top-0 z-10 bg-background border-b">
          <div className="flex items-center gap-2 px-4">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem className="hidden md:block">
                  <BreadcrumbLink asChild>
                    <Link href="/job_description">Home</Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="hidden md:block" />
                <BreadcrumbItem className="hidden md:block">
                  <BreadcrumbLink asChild>
                    <Link href="/prompts">Prompt Templates Management</Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="hidden md:block" />
                <BreadcrumbItem>
                  <BreadcrumbPage>
                    {techStack?.tech_stack || techStackName || "Loading..."}{" "}
                    Prompts
                  </BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
          <div className="flex items-center justify-center gap-4">
            {/* <Button
              variant="outline"
              size="sm"
              onClick={() => router.push("/prompts")}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Prompts Template
            </Button> */}
            <Button variant="outline" size="icon" onClick={toggleTheme}>
              {theme === "dark" ? (
                <Sun className="h-[1.2rem] w-[1.2rem]" />
              ) : (
                <Moon className="h-[1.2rem] w-[1.2rem]" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
            <Button variant="outline" size="icon" onClick={logout}>
              <LogOut className="h-[1.2rem] w-[1.2rem]" />
              <span className="sr-only">Logout</span>
            </Button>
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-auto">
          <div className="p-6">
            <div className="min-h-[calc(100vh-4rem)] rounded-xl bg-muted/50 p-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>
                        Agent Prompts for{" "}
                        {techStack?.tech_stack || techStackName}
                      </CardTitle>
                      <CardDescription>
                        Manage agent prompts for this technology stack
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={fetchAgentPrompts}
                        disabled={loading}
                      >
                        <RefreshCw
                          className={`h-4 w-4${loading ? "animate-spin" : ""}`}
                        />
                        Refresh
                      </Button>
                      <Dialog
                        open={createPromptDialogOpen}
                        onOpenChange={setCreatePromptDialogOpen}
                      >
                        <DialogTrigger asChild>
                          {/* <Button size="sm">
                            <Plus className="h-4 w-4 mr-2" />
                            Add Prompt
                          </Button> */}
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[600px]">
                          <DialogHeader>
                            <DialogTitle>Create New Agent Prompt</DialogTitle>
                            <DialogDescription>
                              Add a new agent prompt for{" "}
                              {techStack?.tech_stack || techStackName}.
                            </DialogDescription>
                          </DialogHeader>
                          <Form {...createPromptForm}>
                            <div className="space-y-4">
                              <FormField
                                control={createPromptForm.control}
                                name="agent_name"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Agent Name</FormLabel>
                                    <FormControl>
                                      <Input
                                        placeholder="e.g., Interview Assistant"
                                        {...field}
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={createPromptForm.control}
                                name="type"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Type</FormLabel>
                                    <Select
                                      onValueChange={field.onChange}
                                      defaultValue={field.value}
                                    >
                                      <FormControl>
                                        <SelectTrigger>
                                          <SelectValue placeholder="Select type" />
                                        </SelectTrigger>
                                      </FormControl>
                                      <SelectContent>
                                        <SelectItem value="ASSISTANT">
                                          ASSISTANT
                                        </SelectItem>
                                        <SelectItem value="AGENT">
                                          AGENT
                                        </SelectItem>
                                        <SelectItem value="MESSAGE">
                                          MESSAGE
                                        </SelectItem>
                                        <SelectItem value="TASK">
                                          TASK
                                        </SelectItem>
                                      </SelectContent>
                                    </Select>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={createPromptForm.control}
                                name="prompt"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Prompt</FormLabel>
                                    <FormControl>
                                      <Textarea
                                        placeholder="Enter your prompt template..."
                                        className="min-h-[100px]"
                                        {...field}
                                      />
                                    </FormControl>
                                    <FormDescription>
                                      Use {`{placeholder_name}`} for dynamic
                                      placeholders
                                    </FormDescription>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <FormField
                                control={createPromptForm.control}
                                name="placeholders"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Placeholders (JSON)</FormLabel>
                                    <FormControl>
                                      <Textarea
                                        placeholder='{"tech_stack": "React", "experience_level": "5-year"}'
                                        className="min-h-[80px] font-mono text-sm"
                                        {...field}
                                      />
                                    </FormControl>
                                    <FormDescription>
                                      Optional JSON object with placeholder
                                      values
                                    </FormDescription>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              <DialogFooter>
                                <Button
                                  onClick={createPromptForm.handleSubmit(
                                    onCreatePromptSubmit
                                  )}
                                >
                                  Create Prompt
                                </Button>
                              </DialogFooter>
                            </div>
                          </Form>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="flex items-center justify-center h-64">
                      <div className="text-center space-y-2">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                        <p className="text-gray-500 dark:text-gray-300">
                          Loading...
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse border border-gray-200 dark:border-gray-700">
                        <thead>
                          <tr className="bg-gray-50 dark:bg-gray-800">
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              S.No
                            </th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              Agent Name
                            </th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              Type
                            </th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              Prompt
                            </th>
                            <th className="border border-gray-200 dark:border-gray-700 px-4 py-2 text-left font-medium">
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {agentPrompts.length === 0 ? (
                            <tr>
                              <td
                                colSpan={5}
                                className="border border-gray-200 dark:border-gray-700 px-4 py-8 text-center"
                              >
                                No agent prompts found. Create your first agent
                                prompt.
                              </td>
                            </tr>
                          ) : (
                            agentPrompts.map((prompt, index) => (
                              <tr
                                key={prompt.id}
                                className="hover:bg-gray-50 dark:hover:bg-gray-800"
                              >
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2 font-medium">
                                  {index + 1}
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  {prompt.agent_name}
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  <span
                                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getTypeColor(
                                      prompt.type
                                    )}`}
                                  >
                                    {prompt.type}
                                  </span>
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2 max-w-xs">
                                  <div
                                    className="truncate"
                                    title={prompt.prompt}
                                  >
                                    {prompt.prompt}
                                  </div>
                                </td>
                                <td className="border border-gray-200 dark:border-gray-700 px-4 py-2">
                                  <div className="flex gap-2">
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() =>
                                        handleUpdatePromptOpen(prompt)
                                      }
                                    >
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                    {/* <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() =>
                                        handleDeletePromptOpen(prompt)
                                      }
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button> */}
                                  </div>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </SidebarInset>

      {/* Update Agent Prompt Dialog - Enhanced with Real-time Placeholder Detection */}
      <Dialog
        open={updatePromptDialogOpen}
        onOpenChange={setUpdatePromptDialogOpen}
      >
        <DialogContent className="sm:max-w-[800px] max-h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle>Update Agent Prompt</DialogTitle>
            <DialogDescription>
              Update the prompt and placeholders for "
              {selectedAgentPrompt?.agent_name}".
            </DialogDescription>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto pr-2">
            <Form {...updatePromptForm}>
              <div className="space-y-4 py-4">
                <FormField
                  control={updatePromptForm.control}
                  name="prompt"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Prompt</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Enter your prompt template..."
                          className="min-h-[300px] resize-none"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            // Real-time placeholder detection
                            updatePlaceholdersFromPrompt(e.target.value);
                          }}
                        />
                      </FormControl>
                      <FormDescription>
                        Use {`{placeholder_name}`} for dynamic placeholders.
                        Detected placeholders will auto-populate below.
                      </FormDescription>
                      {detectedPlaceholders.length > 0 && (
                        <div className="mt-2 p-2 bg-blue-50 dark:bg-blue-950 rounded-md">
                          <p className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-1">
                            Detected Placeholders:
                          </p>
                          <div className="flex flex-wrap gap-1">
                            {detectedPlaceholders.map((placeholder, index) => (
                              <span
                                key={index}
                                className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200"
                              >
                                {`{${placeholder}}`}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={updatePromptForm.control}
                  name="placeholders"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Placeholders (JSON)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder='{"tech_stack": "React", "experience_level": "5-year"}'
                          className="min-h-[120px] font-mono text-sm resize-none"
                          {...field}
                          onFocus={handlePlaceholderFocus}
                        />
                      </FormControl>
                      <FormDescription>
                        Automatically populated based on placeholders in your
                        prompt. Sample values will be cleared when you click to
                        edit.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </Form>
          </div>
          <DialogFooter className="flex-shrink-0 border-t pt-4">
            <Button
              onClick={updatePromptForm.handleSubmit(onUpdatePromptSubmit)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Update Prompt
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Agent Prompt Confirmation Dialog */}
      <AlertDialog
        open={deletePromptDialogOpen}
        onOpenChange={setDeletePromptDialogOpen}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the
              agent prompt "{selectedAgentPrompt?.agent_name}".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeletePrompt}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </SidebarProvider>
  );
}