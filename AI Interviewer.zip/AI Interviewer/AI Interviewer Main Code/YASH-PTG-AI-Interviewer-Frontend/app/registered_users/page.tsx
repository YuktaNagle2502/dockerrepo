"use client";

import { AppSidebar } from "@/components/layout/app-sidebar";
import { LogOut, Moon, Sun } from "lucide-react";
import ImageComp from "@/public/Amigos_Outdoors.svg";
import { Input } from "@/components/ui/input";
// import JDDialog from "@/components/dialogs/JDDialog";
import { useTheme } from "next-themes";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useInterviewStore } from "@/stores/interview-store";
import { Separator } from "@/components/ui/separator";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";

import { EngagementChart } from "@/components/charts/AreaChart";
import { BarComp } from "@/components/charts/BarChart";
import { EngagementPieChart } from "@/components/charts/PieChart";
import React, { useState, useEffect } from "react";
import { DataTable } from "@/components/table/DataTable";
import { RefreshCw, Upload, CirclePlus } from "lucide-react";
import { Label } from "@radix-ui/react-label";
import { useToast } from "@/hooks/use-toast";
import Image from "next/image";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import InterviewEvaluation from "@/components/interview/InterviewEvaluation";
import { v4 as uuidv4 } from "uuid";
import UserInterviewsList from "@/components/interview/UserInterviewsList";
import ScheduleDialog from "@/components/dialogs/ScheduleDialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import * as z from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { authFetch } from "@/lib/authFetch";
import Link from "next/link";
import { useKeycloak } from "@/context/keycloakContext";
import { useRoleProtection } from "@/hooks/useRoleProtection";

const formSchema = z.object({
  fullName: z.string().min(1, "Full name is required"),
  age: z.string().min(1, "Age is required"),
  sex: z.string().min(1, "Gender is required"),
  phone: z.string().min(1, "Phone number is required"),
  email: z.string().min(1, "Email is required").email("Invalid email format"),
  job_id: z.string().min(1, "Job ID is required"),
  domain: z.string().optional(), // Making domain optional
  resume: z.instanceof(File, { message: "Resume is required" }),
  user_img: z.instanceof(File, { message: "Profile image is required" }),
  File_based: z.instanceof(File).optional(),
  uuid: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

export default function Page() {
  // ✅ ALL HOOKS MUST BE CALLED BEFORE ANY CONDITIONAL RETURNS
  const { toast } = useToast(); // Moved to top
  const { theme, setTheme } = useTheme(); // Moved to top
  const { keycloak, initialized, authenticated, logout, hasValidToken } = useKeycloak(); // Moved to top
  
  // Role protection hook
  const { isCheckingAuth, isRedirectingToLogin, isRedirectingToAccessDenied, isAuthorized } = useRoleProtection();
  
  // Form hook
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      age: "",
      sex: "",
      phone: "",
      resume: undefined,
      email: "",
      job_id: "",
      user_img: undefined,
      domain: "",
      File_based: undefined,
      uuid: uuidv4(),
    },
  });

  // State hooks
  const [invoices, setInvoices] = useState([]);
  const [image, setImage] = useState("");
  const [loading, setLoading] = useState(true);
  const [file1, setFile1] = useState<File | null>(null);
  const [file2, setFile2] = useState<File | null>(null);
  const [processingFiles, setProcessingFiles] = useState(false);
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [interviewQuestions, setInterviewQuestions] = useState<InterviewQuestion[]>([]);
  const [question, setQuestion] = useState("");
  const [domain, setDomain] = useState("");
  const [Questionfile, setQuestionfile] = useState("");

  interface InterviewQuestion {
    question: string;
    answer: string;
  }

  // ✅ NOW ALL THE CONDITIONAL RETURNS COME AFTER ALL HOOKS
  if (isCheckingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (isRedirectingToLogin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Redirecting to login...</p>
        </div>
      </div>
    );
  }

  if (isRedirectingToAccessDenied) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Checking permissions...</p>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return null;
  }

  // ✅ ALL FUNCTIONS AND HANDLERS AFTER HOOKS AND CONDITIONAL RETURNS
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const fetchQuestions = async () => {
    try {
      if (!file1 || !file2) {
        toast({
          title: "Error",
          description: "Please select a file first.",
          variant: "destructive",
        });
        return;
      }

      // Handle resume questions
      const formData1 = new FormData();
      formData1.append("file", file1);

      const data1 = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/generate_question_autogen_resume`,
        {
          method: "POST",
          body: formData1,
        }
      );
      if (!data1.ok) {
        throw new Error("Failed to fetch resume questions");
      }
      const resumeResponse = await data1.json();
      console.log(resumeResponse);
      // Parse resume questions properly
      let resumeQuestions;
      try {
        if (typeof resumeResponse === "string") {
          resumeQuestions = JSON.parse(resumeResponse);
        } else {
          resumeQuestions = resumeResponse;
        }

        // Initialize state with resume questions
        setInterviewQuestions(
          Array.isArray(resumeQuestions) ? resumeQuestions : [resumeQuestions]
        );
      } catch (parseError) {
        console.error("Error parsing resume questions:", parseError);
        return;
      }

      // Handle JD questions
      const formData2 = new FormData();
      formData2.append("file", file2);

      const data2 = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/generate_question_autogen_jd`,
        {
          method: "POST",
          body: formData2,
        }
      );

      if (!data2.ok) {
        throw new Error("Failed to fetch jd questions");
      }

      const jdResponse = await data2.json();
      console.log(jdResponse);
      // Parse JD questions
      let jdQuestions: any;
      try {
        if (typeof jdResponse === "string") {
          jdQuestions = JSON.parse(jdResponse);
        } else {
          jdQuestions = jdResponse;
        }

        // Combine questions using functional update to ensure we have the latest state
        setInterviewQuestions((prevQuestions) => {
          // Ensure both are arrays before combining
          const currentQuestions = Array.isArray(prevQuestions)
            ? prevQuestions
            : [];
          const newQuestions = Array.isArray(jdQuestions)
            ? jdQuestions
            : [jdQuestions];

          const combinedQuestions = [...currentQuestions, ...newQuestions];
          return combinedQuestions;
        });

        toast({
          title: "Questions Generated",
          description: "Successfully Generated the Questions.",
        });
      } catch (parseError) {
        console.error("Error parsing JD questions:", parseError);
        toast({
          title: "Failed",
          description: "Error parsing JD questions response.",
          variant: "destructive",
        });
      }
    } catch (err) {
      console.error("Fetch Error:", err);
      toast({
        title: "Failed",
        description: "Error generating questions.",
        variant: "destructive",
      });
    }
  };

  const addInterviewQuestion = (newQuestion: any) => {
    setInterviewQuestions((prevQuestions) => {
      // Ensure prevQuestions is an array
      const currentQuestions = Array.isArray(prevQuestions)
        ? prevQuestions
        : [];

      // Handle both single question and array of questions
      const questionsToAdd = Array.isArray(newQuestion)
        ? newQuestion
        : [newQuestion];

      // Add new questions to the existing array
      const updatedQuestions = [...currentQuestions, ...questionsToAdd];

      return updatedQuestions;
    });
  };

  const clearContents = () => {
    setInterviewQuestions([]);
  };

  const fetchInvoices = async () => {
    setLoading(true);
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/status_api`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      if (!response.ok) {
        throw new Error("Failed to fetch invoices");
      }
      const data = await response.json();
      setInvoices(data);
      setLoading(false);
      toast({
        title: "Stats Refreshed",
        description: "Successfully fetched the latest invoices.",
        duration: 2000,
      });
    } catch (err) {
      setLoading(false);
      toast({
        title: "Error",
        description: "Failed to fetch Stats.",
        variant: "destructive",
        duration: 2000,
      });
    }
  };

  const handleFile1Change = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0] || null;
    setFile1(selectedFile);
  };

  const handleFile2Change = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0] || null;
    setFile2(selectedFile);
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          resolve(reader.result);
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleFile3Change = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile instanceof File) {
      try {
        const base64 = await fileToBase64(selectedFile);
        setImage(base64);
      } catch (error) {
        console.error("Error processing image:", error);
      }
    }
  };

  const processFiles = async () => {
    if (!file1 || !file2) {
      toast({
        title: "Upload Error",
        description: "Please upload both files.",
        variant: "destructive",
        duration: 2000,
      });
      return;
    }

    setProcessingFiles(true);
    const formData = new FormData();
    formData.append("file1", file1);
    formData.append("file2", file2);

    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/process_files`,
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        throw new Error("Failed to process files");
      }

      const result = await response.json();

      toast({
        title: "Files Processed",
        description: "Successfully processed the uploaded files.",
        duration: 2000,
      });
    } catch (err) {
      toast({
        title: "Processing Error",
        description: "Failed to process files.",
        variant: "destructive",
        duration: 2000,
      });
    } finally {
      setProcessingFiles(false);
    }
  };

  const handleQuestionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (question === "") {
      toast({
        title: "Question Error",
        description: "Please enter a question.",
        variant: "destructive",
      });
      return;
    }
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/question/generate_user_question`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ question: question }),
        }
      );
      const result = await response.json();
      addInterviewQuestion(result);
      toast({
        title: "Question Added",
        description: "Your question has been added successfully.",
      });
      setQuestion("");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit question.",
        variant: "destructive",
      });
    }
  };

  const handleDomainSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (domain === "") {
      toast({
        title: "Domain Error",
        description: "Please enter a domain.",
        variant: "destructive",
      });
      return;
    }
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/generate_domain_question`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ domain: domain }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to fetch domain questions");
      }

      const data = await response.json();

      let domainQuestions;
      try {
        domainQuestions = typeof data === "string" ? JSON.parse(data) : data;
        addInterviewQuestion(domainQuestions);

        toast({
          title: "Domain Questions Added",
          description: "Domain-specific questions have been added successfully.",
        });

        setDomain("");
      } catch (parseError) {
        console.error("Error parsing domain questions:", parseError);
        throw new Error("Failed to parse domain questions");
      }
    } catch (error) {
      console.error("Domain submission error:", error);
      toast({
        title: "Error",
        description: "Failed to submit domain or process questions.",
        variant: "destructive",
      });
    }
  };

  const handleschedule = async () => {
    if (!image || interviewQuestions.length === 0) {
      toast({
        title: "Error",
        description: "Missing required information for scheduling.",
        variant: "destructive",
      });
      return;
    }

    const uuid = uuidv4();
    const formData = new FormData();

    try {
      formData.append("name", uuid);
      formData.append("questions", JSON.stringify(interviewQuestions));
      formData.append("unique_id", uuid);
      formData.append("user_img", image);
      formData.append("url", "mynewurl/" + uuid);

      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/schedule_interview`,
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();

      toast({
        title: "Success",
        description: "Interview scheduled successfully.",
      });

      setScheduleDialogOpen(false);
      clearContents();
      setImage("");
    } catch (error) {
      console.error("Error scheduling interview:", error);
      toast({
        title: "Error",
        description: "Failed to schedule interview. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlefileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!Questionfile) {
      toast({
        title: "File Error",
        description: "Please select a file.",
        variant: "destructive",
      });
      return;
    }

    try {
      const fileInput = document.getElementById("questionFileInput") as HTMLInputElement;
      const file = fileInput.files?.[0];

      if (!file) {
        toast({
          title: "File Error",
          description: "No file selected.",
          variant: "destructive",
        });
        return;
      }

      const formData = new FormData();
      formData.append("file", file);

      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/generate_file_based`,
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        throw new Error("File upload failed");
      }

      const result = JSON.parse(await response.json());
      for (var i = 0; i < result.length; i++) {
        addInterviewQuestion(result[i]);
      }

      toast({
        title: "File Uploaded",
        description: "Your file has been uploaded successfully.",
      });

      setQuestionfile("");
      if (fileInput) {
        fileInput.value = "";
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload file.",
        variant: "destructive",
      });
    }
  };

  async function onSubmit(values: FormValues) {
    try {
      if (!values.resume || !(values.resume instanceof File)) {
        throw new Error("Resume must be a valid file");
      }
      if (!values.user_img || !(values.user_img instanceof File)) {
        throw new Error("User image must be a valid file");
      }

      const formData = new FormData();
      const user_img_content = await fileToBase64(values.user_img);

      formData.append("full_name", values.fullName);
      formData.append("unique_id", uuidv4());
      formData.append("age", values.age.toString());
      formData.append("sex", values.sex);
      formData.append("phone", values.phone);
      formData.append("email_id", values.email);
      formData.append("job_id", values.job_id.toString());
      formData.append("resume", values.resume);
      formData.append("user_image", user_img_content);

      if (values.domain) {
        formData.append("domain", values.domain);
      } else {
        formData.append("domain", "null");
      }
      if (values.File_based) {
        formData.append("File_based", values.File_based);
      } else {
        formData.append("File_based", "null");
      }

      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/schedule_interview`,
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        console.error("Error response:", errorData);
        throw new Error(errorData.detail || "Registration failed");
      }

      const responseData = await response.json();
      console.log("Success response:", responseData);

      toast({
        title: "Success",
        description: "User registered successfully",
      });

      form.reset();
    } catch (error) {
      console.error("Submit error:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to register user",
        variant: "destructive",
      });
    }
  }

  // JSX RETURN
  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="flex flex-col h-screen">
        {/* Fixed Header */}
        <header className="flex h-16 justify-between px-4 shrink-0 items-center gap-2 sticky top-0 z-10 bg-background border-b">
          <div className="flex items-center gap-2 px-4">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem className="hidden md:block">
                  <BreadcrumbLink asChild>
                    <Link href="/job_description">Home</Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="hidden md:block" />
                <BreadcrumbItem>
                  <BreadcrumbPage>Registered Users</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
          <div className="flex items-center justify-center gap-4">
            <a
              href="/careers"
              className="text-base font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Careers
            </a>
            <Button variant="outline" size="icon" onClick={toggleTheme}>
              {theme === "dark" ? (
                <Sun className="h-[1.2rem] w-[1.2rem]" />
              ) : (
                <Moon className="h-[1.2rem] w-[1.2rem]" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
            <Button variant="outline" size="icon" onClick={logout}>
              <LogOut className="h-[1.2rem] w-[1.2rem]" />
              <span className="sr-only">Logout</span>
            </Button>
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-auto">
          <div className="p-2">
            <div className="min-h-[calc(100vh-4rem)] rounded-xl mx-6 bg-muted/50">
              <UserInterviewsList />
            </div>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}