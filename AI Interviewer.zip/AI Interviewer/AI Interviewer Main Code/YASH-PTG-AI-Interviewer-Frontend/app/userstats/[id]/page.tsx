"use client";

import { AppSidebar } from "@/components/layout/app-sidebar";
import { Moon, Sun } from "lucide-react";
import ImageComp from "@/public/Amigos_Outdoors.svg";
import { Input } from "@/components/ui/input";
;
import { useTheme } from "next-themes";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useInterviewStore } from "@/stores/interview-store";
import { Separator } from "@/components/ui/separator";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";

import { EngagementChart } from "@/components/charts/AreaChart";
import { BarComp } from "@/components/charts/BarChart";
import { EngagementPieChart } from "@/components/charts/PieChart";
import React, { useState, useEffect } from "react";
import { DataTable } from "@/components/table/DataTable";
import { RefreshCw, Upload, CirclePlus } from "lucide-react";
import { Label } from "@radix-ui/react-label";
import { useToast } from "@/hooks/use-toast";
import Image from "next/image";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import InterviewEvaluation from "@/components/interview/InterviewEvaluation";
import { v4 as uuidv4 } from "uuid";
import UserInterviewsList from "@/components/interview/UserInterviewsList";
import ScheduleDialog from "@/components/dialogs/ScheduleDialog";
import { useParams } from "next/navigation";
import { authFetch } from "@/lib/authFetch";

export default function Page() {
  const params = useParams();
  const user_Id = params.id as string;
  const [user_Id_p, setUser_Id] = useState(user_Id);
  const { toast } = useToast();
  const [invoices, setInvoices] = useState([]);
  const [image, setImage] = useState("");
  const [loading, setLoading] = useState(true);
  const [file1, setFile1] = useState<File | null>(null);
  const [file2, setFile2] = useState<File | null>(null);
  const [processingFiles, setProcessingFiles] = useState(false);
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  interface InterviewQuestion {
    question: string;
    answer: string;
  }
  const [interviewQuestions, setInterviewQuestions] = useState<
    InterviewQuestion[]
  >([]);

  const [question, setQuestion] = useState("");
  const [domain, setDomain] = useState("");
  const [Questionfile, setQuestionfile] = useState("");

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const fetchQuestions = async () => {
    try {
      if (!file1 || !file2) {
        toast({
          title: "Error",
          description: "Please select a file first.",
          variant: "destructive",
        });
        return;
      }

      // Handle resume questions
      const formData1 = new FormData();
      formData1.append("file", file1);

      const data1 = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/generate_question_autogen_resume`,
        {
          method: "POST",
          body: formData1,
        }
      );
      if (!data1.ok) {
        throw new Error("Failed to fetch resume questions");
      }
      const resumeResponse = await data1.json();

      // Parse resume questions properly
      let resumeQuestions;
      try {
        if (typeof resumeResponse === "string") {
          resumeQuestions = JSON.parse(resumeResponse);
        } else {
          resumeQuestions = resumeResponse;
        }
        // console.log("Resume Questions:", resumeQuestions);

        // Initialize state with resume questions
        setInterviewQuestions(
          Array.isArray(resumeQuestions) ? resumeQuestions : [resumeQuestions]
        );
      } catch (parseError) {
        console.error("Error parsing resume questions:", parseError);
        return;
      }

      // Handle JD questions
      const formData2 = new FormData();
      formData2.append("file", file2);

      const data2 = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/generate_question_autogen_jd`,
        {
          method: "POST",
          body: formData2,
        }
      );

      if (!data2.ok) {
        throw new Error("Failed to fetch jd questions");
      }

      const jdResponse = await data2.json();

      // Parse JD questions
      let jdQuestions: any;
      try {
        if (typeof jdResponse === "string") {
          jdQuestions = JSON.parse(jdResponse);
        } else {
          jdQuestions = jdResponse;
        }
        // console.log("JD Questions:", jdQuestions);

        // Combine questions using functional update to ensure we have the latest state
        setInterviewQuestions((prevQuestions) => {
          // Ensure both are arrays before combining
          const currentQuestions = Array.isArray(prevQuestions)
            ? prevQuestions
            : [];
          const newQuestions = Array.isArray(jdQuestions)
            ? jdQuestions
            : [jdQuestions];

          const combinedQuestions = [...currentQuestions, ...newQuestions];
          // console.log("Combined Questions:", combinedQuestions);
          return combinedQuestions;
        });

        toast({
          title: "Questions Generated",
          description: "Successfully Generated the Questions.",
        });
      } catch (parseError) {
        console.error("Error parsing JD questions:", parseError);
        toast({
          title: "Failed",
          description: "Error parsing JD questions response.",
          variant: "destructive",
        });
      }
    } catch (err) {
      console.error("Fetch Error:", err);
      toast({
        title: "Failed",
        description: "Error generating questions.",
        variant: "destructive",
      });
    }
  };

  const addInterviewQuestion = (newQuestion: any) => {
    setInterviewQuestions((prevQuestions) => {
      // Ensure prevQuestions is an array
      const currentQuestions = Array.isArray(prevQuestions)
        ? prevQuestions
        : [];

      // Handle both single question and array of questions
      const questionsToAdd = Array.isArray(newQuestion)
        ? newQuestion
        : [newQuestion];

      // Add new questions to the existing array
      const updatedQuestions = [...currentQuestions, ...questionsToAdd];

      // console.log("Updated Questions:", updatedQuestions);
      return updatedQuestions;
    });
  };

  const clearContents = () => {
    setInterviewQuestions([]);
  };
  const fetchInvoices = async () => {
    setLoading(true);
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/status_api_data/${user_Id_p}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      if (!response.ok) {
        throw new Error("Failed to fetch invoices");
      }
      const data = await response.json();
      console.log(user_Id_p);
      console.log(data);
      setInvoices(data);
      setLoading(false);
      toast({
        title: "Stats Refreshed",
        description: "Successfully fetched the latest invoices.",
        duration: 2000,
      });
    } catch (err) {
      // console.log(err);
      setLoading(false);
      toast({
        title: "Error",
        description: "Failed to fetch Stats.",
        variant: "destructive",
        duration: 2000,
      });
    }
  };

  const handleFile1Change = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0] || null;
    setFile1(selectedFile);
  };

  const handleFile2Change = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0] || null;
    setFile2(selectedFile);
  };
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          resolve(reader.result);
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleFile3Change = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile instanceof File) {
      try {
        const base64 = await fileToBase64(selectedFile);
        setImage(base64);
        // // console.log(base64);
      } catch (error) {
        console.error("Error processing image:", error);
      }
    }
  };

  const processFiles = async () => {
    if (!file1 || !file2) {
      toast({
        title: "Upload Error",
        description: "Please upload both files.",
        variant: "destructive",
        duration: 2000,
      });
      return;
    }

    setProcessingFiles(true);
    const formData = new FormData();
    formData.append("file1", file1);
    formData.append("file2", file2);

    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/process_files`,
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        throw new Error("Failed to process files");
      }

      const result = await response.json();
      // console.log("Files processed successfully:", result);

      toast({
        title: "Files Processed",
        description: "Successfully processed the uploaded files.",
        duration: 2000,
      });
    } catch (err) {
      toast({
        title: "Processing Error",
        description: "Failed to process files.",
        variant: "destructive",
        duration: 2000,
      });
    } finally {
      setProcessingFiles(false);
    }
  };

  // New handlers for popover form submissions
  const handleQuestionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (question === "") {
      toast({
        title: "Question Error",
        description: "Please enter a question.",
        variant: "destructive",
      });
      return;
    }
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/question/generate_user_question`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ question: question }),
        }
      );
      const result = await response.json();
      // console.log(result);
      addInterviewQuestion(result); // Now using the new function
      toast({
        title: "Question Added",
        description: "Your question has been added successfully.",
      });
      setQuestion(""); // Clear input after submission
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit question.",
        variant: "destructive",
      });
    }
  };

  const handleDomainSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (domain === "") {
      toast({
        title: "Domain Error",
        description: "Please enter a domain.",
        variant: "destructive",
      });
      return;
    }
    try {
      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/generate_domain_question`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ domain: domain }),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to fetch domain questions");
      }

      const data = await response.json();

      // Parse the response if it's a string
      let domainQuestions;
      try {
        domainQuestions = typeof data === "string" ? JSON.parse(data) : data;

        // Add the questions using our addInterviewQuestion function
        // This will handle both single questions and arrays of questions
        addInterviewQuestion(domainQuestions);

        toast({
          title: "Domain Questions Added",
          description:
            "Domain-specific questions have been added successfully.",
        });

        setDomain(""); // Clear input after successful submission
      } catch (parseError) {
        console.error("Error parsing domain questions:", parseError);
        throw new Error("Failed to parse domain questions");
      }
    } catch (error) {
      console.error("Domain submission error:", error);
      toast({
        title: "Error",
        description: "Failed to submit domain or process questions.",
        variant: "destructive",
      });
    }
  };

  const handleschedule = async (userId: string) => {
    if (!userId || !image || interviewQuestions.length === 0) {
      toast({
        title: "Error",
        description: "Missing required information for scheduling.",
        variant: "destructive",
      });
      return;
    }

    const uuid = uuidv4();
    const formData = new FormData();

    try {
      // Add all required fields to formData
      formData.append("user_id", userId);
      formData.append("questions", JSON.stringify(interviewQuestions));
      formData.append("unique_id", uuid);
      formData.append("user_img", image);
      formData.append("url", "mynewurl/" + uuid);

      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/interview/schedule_interview`,
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();

      toast({
        title: "Success",
        description: "Interview scheduled successfully.",
      });

      // Clear the form and close dialog
      setScheduleDialogOpen(false);
      clearContents();
      setImage("");
    } catch (error) {
      console.error("Error scheduling interview:", error);
      toast({
        title: "Error",
        description: "Failed to schedule interview. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlefileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!Questionfile) {
      toast({
        title: "File Error",
        description: "Please select a file.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Create FormData to send the file
      const fileInput = document.getElementById(
        "questionFileInput"
      ) as HTMLInputElement;
      const file = fileInput.files?.[0];

      if (!file) {
        toast({
          title: "File Error",
          description: "No file selected.",
          variant: "destructive",
        });
        return;
      }

      const formData = new FormData();
      formData.append("file", file);

      const response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/generate_file_based`,
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        throw new Error("File upload failed");
      }

      const result = JSON.parse(await response.json());
      // console.log(result);
      for (var i = 0; i < result.length; i++) {
        addInterviewQuestion(result[i]);
      }
      // console.log(interviewQuestions);

      toast({
        title: "File Uploaded",
        description: "Your file has been uploaded successfully.",
      });

      // Clear the file input
      setQuestionfile("");
      if (fileInput) {
        fileInput.value = "";
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload file.",
        variant: "destructive",
      });
    }
  };
  useEffect(() => {
    fetchInvoices();
  }, []);

  // console.log(Questionfile);
  return (
    <SidebarProvider>
      {/* <AppSidebar /> */}
      <SidebarInset>
        {/* Fixed Header */}
        <header className="sticky top-0 z-50 flex h-16 justify-between px-4 shrink-0 items-center gap-2 bg-background border-b">
          <div className="flex items-center gap-2 px-4">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem className="hidden md:block">
                  <BreadcrumbLink href="/job_description">Home</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="hidden md:block" />
                <BreadcrumbItem>
                  <BreadcrumbPage>User States</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
          <div className="flex items-center justify-center gap-5">
            <Button variant="outline" size="icon" onClick={toggleTheme}>
              {theme === "dark" ? (
                <Sun className="h-[1.2rem] w-[1.2rem]" />
              ) : (
                <Moon className="h-[1.2rem] w-[1.2rem]" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
          </div>
        </header>

        {/* Invisible Scrollable Card Container */}
        <Card className="flex-1 border-0 shadow-none bg-transparent rounded-none">
          <CardContent className="p-0">
            <div className="flex flex-1 flex-col gap-4 p-2 pt-0 mt-4 max-h-[calc(100vh-64px)] overflow-y-auto">
              {invoices.length === 0 && (
                <div className="flex mt-4 justify-center items-center grid auto-rows-min gap-4">
                  <div className="min-h-[100vh] flex-row items-center justify-center w-full flex-1 rounded-xl  md:min-h-min">
                    <Image src={ImageComp} alt="Image" width={300} />
                    <Label className="text-2xl ml-[12vh] text-[hsl(var(--foreground))]">
                      Data Not Available
                    </Label>
                  </div>
                </div>
              )}
              {invoices.length > 0 && (
                <div>
                  <div className="grid auto-rows-min gap-4 p-6 md:grid-cols-3">
                    <div className="rounded-xl bg-muted/50">
                      <BarComp data={invoices} />
                    </div>
                    <div className=" rounded-xl bg-muted/50">
                      <EngagementPieChart data={invoices} />
                    </div>
                    <div className="aspect-video h-full p-4 rounded-xl bg-muted/50 overflow-auto w-full">
                      <DataTable
                        invoices={invoices}
                        caption="Engagement Timeline"
                      />
                    </div>
                  </div>
                  <div className="min-h-[100vh] flex-1 rounded-xl m-6 bg-muted/50 md:min-h-min">
                    <EngagementChart data={invoices} />
                  </div>
                </div>
              )}
              <Card className="justify-between items-center min-h-[100vh] flex rounded-xl mx-6 md:min-h-min p-4">
                <InterviewEvaluation user_Id={user_Id_p} />
              </Card>
            </div>
          </CardContent>
        </Card>
      </SidebarInset>
    </SidebarProvider>
  );
}