'use client';

import WebRTCRecorder from '@/components/media/WebRTCRecorder';

export default function page() {
  return <WebRTCRecorder />;
}