"use client";

import React, { useEffect, useState } from "react";
import type { NextPage } from "next";
import InterviewRegistrationDialog from "@/components/dialogs/InterviewRegistrationDialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import {
  CalendarIcon,
  Search,
  MapPin,
  Clock,
  Building2,
  Star,
  FileText,
} from "lucide-react";
import { format } from "date-fns";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { AppSidebar } from "@/components/layout/careersidebar";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Separator } from "@/components/ui/separator";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { useToast } from "@/hooks/use-toast";
import { FaBuilding, FaCalendarAlt } from "react-icons/fa";

// Types for API response and job object
interface ApiResponse {
  jobs: Job[];
}

interface Job {
  job_id: number;
  job_title: string;
  job_location: string;
  created_at: string;
  jd_summary_text?: string | null;
  jd_expiration?: string;
}

// Enhanced helper function to properly check job expiration
const isJobExpired = (job: Job): boolean => {
  if (!job.jd_expiration) return false;

  const expirationDate = new Date(job.jd_expiration);
  const currentDate = new Date();

  const isExpired = expirationDate < currentDate;

  // Optional: Add console logging for debugging
  if (process.env.NODE_ENV === "development") {
    console.log(`Job ${job.job_id} (${job.job_title}):`, {
      expiration: job.jd_expiration,
      expirationDate: expirationDate.toISOString(),
      currentDate: currentDate.toISOString(),
      isExpired,
    });
  }

  return isExpired;
};

// Capitalize the first letter of a string
const capitalizeFirstLetter = (str: string) =>
  str ? str.charAt(0).toUpperCase() + str.slice(1) : str;

// Enhanced Job Card Component with better expiration handling
function JobCard({ job }: { job: Job }) {
  const expired = isJobExpired(job);
  const { toast } = useToast();

  return (
    <Card
      className={cn(
        "group transition-all duration-200 border-l-4 mb-4",
        expired
          ? "border-l-red-400 bg-gray-50 dark:bg-gray-900/50 opacity-80"
          : "border-l-blue-500 hover:shadow-lg"
      )}
    >
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <div className="flex-1 space-y-3">
            {/* Job Title with expired styling */}
            <CardTitle
              className={cn(
                "text-xl font-semibold transition-colors",
                expired
                  ? "text-gray-500 dark:text-gray-400 line-through decoration-red-400"
                  : "text-gray-900 dark:text-white  group-hover:text-blue-600 dark:group-hover:text-blue-400"
              )}
            >
              {capitalizeFirstLetter(job.job_title)}
            </CardTitle>

            {/* Job Summary Display */}
            {job.jd_summary_text && (
              <div className="mt-2">
                <p
                  className={cn(
                    "text-sm leading-relaxed",
                    expired
                      ? "text-gray-400 dark:text-gray-500"
                      : "text-gray-600 dark:text-gray-400"
                  )}
                >
                  {job.jd_summary_text}
                </p>
              </div>
            )}

            <div className="flex items-center gap-4 text-sm flex-wrap">
              {/* Location */}
              <div
                className={cn(
                  "flex items-center gap-2",
                  expired
                    ? "text-gray-400 dark:text-gray-500"
                    : "text-gray-600 dark:text-gray-300"
                )}
              >
                <MapPin className="h-4 w-4" />
                <span>{job.job_location}</span>
              </div>

              {/* Created Date */}
              <div
                className={cn(
                  "flex items-center gap-2",
                  expired
                    ? "text-gray-400 dark:text-gray-500"
                    : "text-gray-600 dark:text-gray-300"
                )}
              >
                <Clock className="h-4 w-4" />
                <span>
                  Created{" "}
                  {new Date(job.created_at).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "short",
                    day: "numeric",
                  })}
                </span>
              </div>

              {/* Expiration Date */}
              {job.jd_expiration && (
                <div className="flex items-center gap-2">
                  <CalendarIcon className="h-4 w-4" />
                  <span
                    className={cn(
                      "font-medium",
                      expired
                        ? "text-red-600 dark:text-red-400"
                        : "text-orange-600 dark:text-orange-400"
                    )}
                  >
                    {expired ? "Expired:" : "Expires:"}{" "}
                    {new Date(job.jd_expiration).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                </div>
              )}

              {/* No Summary Badge */}
              {!job.jd_summary_text && (
                <Badge variant="outline" className="text-xs">
                  No Summary
                </Badge>
              )}

              {/* Status Badge */}
              {expired ? (
                <Badge
                  variant="destructive"
                  className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200 animate-pulse border-red-300"
                >
                  <Clock className="h-3 w-3 mr-1" />
                  Expired
                </Badge>
              ) : (
                <Badge className="bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-900 dark:text-green-200 border-green-300">
                  <Star className="h-3 w-3 mr-1" />
                  Active
                </Badge>
              )}
            </div>
          </div>

          {/* Action Button */}
          <div className="flex flex-col items-end gap-3 min-w-fit">
            {!expired ? (
              <InterviewRegistrationDialog
                job_id={job.job_id}
                job_title={job.job_title}
                onRegistrationSuccess={() =>
                  toast({
                    title: "Registration Successful",
                    description: `Registered for ${job.job_title} successfully!`,
                  })
                }
              >
                <Button
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-lg hover:shadow-xl transition-all duration-300 px-6"
                  size="sm"
                >
                  <Building2 className="h-4 w-4 mr-2" />
                  Apply Now
                </Button>
              </InterviewRegistrationDialog>
            ) : (
              <div className="relative">
                <Button
                  disabled
                  variant="outline"
                  size="sm"
                  className="px-6 opacity-50 cursor-not-allowed bg-gray-100 dark:bg-gray-800 text-gray-400 border-gray-300 dark:border-gray-600 filter blur-[0.5px]"
                >
                  <Clock className="h-4 w-4 mr-2" />
                  Application Closed
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Additional expired job notice */}
        {expired && (
          <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
            <div className="flex items-center gap-2 text-red-700 dark:text-red-300">
              <CalendarIcon className="h-4 w-4" />
              <span className="text-sm font-medium">
                This position is no longer accepting applications
              </span>
            </div>
          </div>
        )}
      </CardHeader>
    </Card>
  );
}

const CareersPage: NextPage = () => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [jobIdSearch, setJobIdSearch] = useState<string>("");
  const [location, setLocation] = useState<string>("");
  const [datePosted, setDatePosted] = useState<Date | undefined>();
  const [sortOrder, setSortOrder] = useState<"newest" | "oldest">("newest");
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [showExpired, setShowExpired] = useState<boolean>(false);
  const { theme, setTheme } = useTheme();
  const jobsPerPage = 5;
  const { toast } = useToast();

  useEffect(() => {
    const fetchJobs = async (): Promise<void> => {
      try {
        const BASE_URL =
          process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";
        const response = await fetch(`${BASE_URL}/jd/jobs`);

        if (!response.ok) {
          throw new Error(`Failed to fetch jobs: ${response.status}`);
        }

        const data: ApiResponse = await response.json();
        setJobs(data.jobs);
      } catch (error) {
        console.error("Error fetching jobs:", error);
        toast({
          title: "Error",
          description: "Failed to load jobs. Please try again later.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchJobs();
  }, [toast]);

  // Filter and sort jobs
  const filteredJobs = jobs
    .filter((job) => job.job_title && job.job_title.trim() !== "")
    .filter(
      (job) =>
        job.job_title.toLowerCase().includes(searchTerm.toLowerCase()) &&
        job.job_location.toLowerCase().includes(location.toLowerCase()) &&
        (jobIdSearch === "" || job.job_id.toString() === jobIdSearch.trim()) &&
        (!datePosted ||
          new Date(job.created_at).toDateString() === datePosted.toDateString())
    )
    .filter((job) => (showExpired ? isJobExpired(job) : !isJobExpired(job)))
    .sort((a, b) => {
      const dateA = new Date(a.created_at).getTime();
      const dateB = new Date(b.created_at).getTime();
      return sortOrder === "newest" ? dateB - dateA : dateA - dateB;
    });

  // Pagination logic
  const totalPages = Math.ceil(filteredJobs.length / jobsPerPage);
  const paginatedJobs = filteredJobs.slice(
    (currentPage - 1) * jobsPerPage,
    currentPage * jobsPerPage
  );

  const toggleTheme = (): void => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  // Reset to first page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, jobIdSearch, location, datePosted, showExpired, sortOrder]);

  // Calculate stats
  const activeJobs = jobs.filter((job) => !isJobExpired(job));
  const expiredJobs = jobs.filter((job) => isJobExpired(job));

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="flex flex-col h-screen">
        {/* Fixed Header - matching job descriptions page style */}
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4 justify-between bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
          <div className="flex items-center">
            <SidebarTrigger className="-ml-1" />
            <Separator orientation="vertical" className="mr-2 h-4" />
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem className="hidden md:block">
                  <BreadcrumbLink href="/job_description">Home</BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="hidden md:block" />
                <BreadcrumbItem>
                  <BreadcrumbPage>Careers</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={toggleTheme}>
              {theme === "dark" ? (
                <Sun className="h-[1.2rem] w-[1.2rem]" />
              ) : (
                <Moon className="h-[1.2rem] w-[1.2rem]" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-auto">
          <div className="flex flex-col gap-4 p-4">
            <div className="max-w-7xl mx-auto w-full space-y-6">
              {/* Header Section - matching job descriptions page */}
              <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
                <div>
                  <h1 className="text-3xl font-bold tracking-tight ">
                    Find Your Dream Career
                  </h1>
                  <p className="text-gray-600 dark:text-gray-300">
                    Discover exciting opportunities and grow your career with us
                  </p>
                </div>
              </div>

              {/* Enhanced Stats Cards with active/expired breakdown */}
              <div className="grid gap-4 md:grid-cols-4">
                <Card className="bg-blue-50 border-0 shadow dark:bg-blue-950">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-blue-100">
                      Total Jobs
                    </CardTitle>
                    <FaBuilding className="h-8 w-8 text-blue-400 dark:text-blue-200" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-blue-100">
                      {jobs.length}
                    </div>
                    <p className="text-xs text-muted-foreground dark:text-blue-200/80">
                      <span className="text-green-600 dark:text-green-300">
                        {activeJobs.length} active
                      </span>
                      {expiredJobs.length > 0 && (
                        <span>
                          ,{" "}
                          <span className="text-red-600 dark:text-red-300">
                            {expiredJobs.length} expired
                          </span>
                        </span>
                      )}
                    </p>
                  </CardContent>
                </Card>
                <Card className="bg-green-100 border-0 shadow dark:bg-green-950">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-green-100">
                      Active Jobs
                    </CardTitle>
                    <Star className="h-8 w-8 text-green-500 dark:text-green-200" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600 dark:text-green-200">
                      {activeJobs.length}
                    </div>
                    <p className="text-xs text-muted-foreground dark:text-green-200/80">
                      Available for applications
                    </p>
                  </CardContent>
                </Card>
                <Card className="bg-yellow-50 border-0 shadow dark:bg-yellow-900">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-yellow-100">
                      Locations
                    </CardTitle>
                    <MapPin className="h-8 w-8 text-yellow-400 dark:text-yellow-200" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-yellow-100">
                      {new Set(jobs.map((job) => job.job_location)).size}
                    </div>
                    <p className="text-xs text-muted-foreground dark:text-yellow-200/80">
                      Unique locations
                    </p>
                  </CardContent>
                </Card>
                <Card className="bg-purple-50 border-0 shadow dark:bg-purple-900/70">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-purple-100">
                      This Month
                    </CardTitle>
                    <FaCalendarAlt className="h-8 w-8 text-purple-400 dark:text-purple-200" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-purple-100">
                      {
                        jobs.filter((job) => {
                          const jobDate = new Date(job.created_at);
                          const now = new Date();
                          return (
                            jobDate.getMonth() === now.getMonth() &&
                            jobDate.getFullYear() === now.getFullYear()
                          );
                        }).length
                      }
                    </div>
                    <p className="text-xs text-muted-foreground dark:text-purple-200/80">
                      Jobs added this month
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Search and Filter Section - matching job descriptions page */}
              <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div className="flex flex-1 gap-4 flex-wrap">
                  <div className="relative flex-1 max-w-sm min-w-[200px]">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                    <Input
                      placeholder="Search by job title..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="relative flex-1 max-w-sm min-w-[200px]">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                    <Input
                      placeholder="Search by job id..."
                      value={jobIdSearch}
                      onChange={(e) => setJobIdSearch(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <div className="relative max-w-sm min-w-[200px]">
                    <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                    <Input
                      placeholder="Filter by location..."
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-[200px] justify-start text-left"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {datePosted ? (
                          format(datePosted, "PPP")
                        ) : (
                          <span>Date Posted</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent align="start" className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={datePosted}
                        onSelect={setDatePosted}
                      />
                    </PopoverContent>
                  </Popover>
                  <Select
                    value={sortOrder}
                    onValueChange={(value: "newest" | "oldest") =>
                      setSortOrder(value)
                    }
                  >
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Sort by date" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">Newest first</SelectItem>
                      <SelectItem value="oldest">Oldest first</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                  <span>
                    Showing {filteredJobs.length} of {jobs.length} jobs
                  </span>
                </div>
              </div>

              {/* Enhanced Show Expired Jobs Toggle */}
              <div className="flex items-center justify-between gap-4 pt-2 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="showExpired"
                      checked={showExpired}
                      onChange={() => setShowExpired(!showExpired)}
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <label
                      htmlFor="showExpired"
                      className="text-sm text-gray-600 dark:text-gray-300 select-none cursor-pointer"
                    >
                      Show Expired Jobs
                      {expiredJobs.length > 0 && (
                        <Badge variant="secondary" className="ml-2 text-xs">
                          {expiredJobs.length}
                        </Badge>
                      )}
                    </label>
                  </div>
                </div>

                {expiredJobs.length > 0 && (
                  <div className="text-xs text-gray-500 dark:text-gray-400">
                    {expiredJobs.length} expired job
                    {expiredJobs.length !== 1 ? "s" : ""} available to view
                  </div>
                )}
              </div>

              {/* Job Cards List */}
              {isLoading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="text-center space-y-2">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                    <p className="text-gray-500 dark:text-gray-300">
                      Loading opportunities...
                    </p>
                  </div>
                </div>
              ) : (
                <>
                  {paginatedJobs.length > 0 ? (
                    <div className="space-y-4">
                      {paginatedJobs.map((job) => (
                        <JobCard key={job.job_id} job={job} />
                      ))}
                    </div>
                  ) : (
                    <Card className="text-center py-12">
                      <CardContent>
                        <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                        <CardTitle className="text-xl text-gray-600 dark:text-gray-300 mb-2">
                          No jobs found
                        </CardTitle>
                        <CardDescription className="mb-4">
                          {searchTerm || location || jobIdSearch
                            ? "Try adjusting your search filters"
                            : "No job opportunities available at the moment"}
                        </CardDescription>
                        {!showExpired && expiredJobs.length > 0 && (
                          <Button
                            variant="outline"
                            onClick={() => setShowExpired(true)}
                            className="mt-2"
                          >
                            Show {expiredJobs.length} Expired Jobs
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {/* Pagination - matching job descriptions page */}
                  {totalPages > 1 && (
                    <div className="flex items-center justify-center gap-4 mt-8 pb-8">
                      <Button
                        variant="outline"
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage((prev) => prev - 1)}
                      >
                        Previous
                      </Button>
                      <span className="text-sm text-gray-600 dark:text-gray-300">
                        Page {currentPage} of {totalPages}
                      </span>
                      <Button
                        variant="outline"
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage((prev) => prev + 1)}
                      >
                        Next
                      </Button>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
};

export default CareersPage;
