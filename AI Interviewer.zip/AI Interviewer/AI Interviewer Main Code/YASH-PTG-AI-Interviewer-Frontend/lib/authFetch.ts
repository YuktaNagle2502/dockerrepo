import keycloak from "./keycloakInstance";

export const authFetch = async (
  url: string,
  options: RequestInit = {}
): Promise<Response> => {
  const accessToken = localStorage.getItem("accessToken");
  // console.log("Access Token used in header:", accessToken);
  const authHeaders: HeadersInit = {
    ...options.headers,
    Authorization: `Bearer ${accessToken}`,
    // "Content-Type": "application/json",
  };

  return fetch(url, {
    ...options,
    headers: authHeaders,
  });
};
