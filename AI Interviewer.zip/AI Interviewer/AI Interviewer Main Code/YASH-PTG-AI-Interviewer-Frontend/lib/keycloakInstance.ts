import Keycloak from "keycloak-js";

const keycloak = new Keycloak({

  url: "https://sso.yashtech.link/",
  realm: "yashtech_ai",
  clientId: "ai_interviewer",
});

export default keycloak;
