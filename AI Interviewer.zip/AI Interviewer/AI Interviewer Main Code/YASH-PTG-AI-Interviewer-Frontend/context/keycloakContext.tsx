// "use client";
 
// import {
//   ReactNode,
//   createContext,
//   useContext,
//   useEffect,
//   useState,
// } from "react";
// import keycloak from "../lib/keycloakInstance";
 
// const KeycloakContext = createContext({
//   keycloak: keycloak,
//   initialized: false,
// });
 
// export const KeycloakProvider = ({ children }: { children: ReactNode }) => {
//   const [initialized, setInitialized] = useState(false);
 
//   useEffect(() => {
//     keycloak
//       .init({
//         onLoad: "check-sso",
//         silentCheckSsoRedirectUri: `${window.location.origin}/silent-check-sso.html`,
//         pkceMethod: "S256",
//       })
//       .then((authenticated) => {
//         setInitialized(true);
 
//         //  Auto token refresh
//         setInterval(() => {
//           keycloak.updateToken(70).catch(() => {
//             keycloak.logout();
//           });
//         }, 60000);
//       })
//       .catch(console.error);
//   }, []);
 
//   return (
//     <KeycloakContext.Provider value={{ keycloak, initialized }}>
//       {children}
//     </KeycloakContext.Provider>
//   );
// };
 
// export const useKeycloak = () => useContext(KeycloakContext);
 
// "use client";
 
// import {
//   ReactNode,
//   createContext,
//   useContext,
//   useEffect,
//   useState,
// } from "react";
// import keycloak from "../lib/keycloakInstance";
 
// // Define the shape of the context
// interface KeycloakContextType {
//   keycloak: any;
//   initialized: boolean;
// }
 
// // Create the context with default values
// const KeycloakContext = createContext<KeycloakContextType>({
//   keycloak,
//   initialized: false,
// });
 
// // Props type for the provider
// interface KeycloakProviderProps {
//   children: ReactNode;
// }
 
// export const KeycloakProvider = ({ children }: KeycloakProviderProps) => {
//   const [initialized, setInitialized] = useState<boolean>(false);
 
//   useEffect(() => {
//     keycloak
//       .init({
//         onLoad: "check-sso",
//         silentCheckSsoRedirectUri: `${window.location.origin}/silent-check-sso.html`,
//         pkceMethod: "S256",
//       })
//       .then((authenticated: boolean) => {
//         setInitialized(true);
//         if (authenticated) {
//           // Access the access token from the keycloak object
//           const accessToken = keycloak.token;
//           if (accessToken) {
//             localStorage.setItem("accessToken", accessToken);
//           }
 
//           // Set token refresh
//           const intervalId = setInterval(() => {
//             keycloak
//               .updateToken(70)
//               .then((refreshed: boolean) => {
//                 if (refreshed && keycloak.token) {
//                   console.log("Token refreshed");
//                   localStorage.setItem("accessToken", keycloak.token);
//                 }
//               })
//               .catch(() => {
//                 console.error("Failed to refresh token");
//                 keycloak.login();
//               });
//           }, 60000); // Check for token refresh every minute
 
//           // Cleanup interval on component unmount
//           return () => clearInterval(intervalId);
//         } else {
//           console.log("User is not authenticated.");
//           keycloak.login();
//         }
//       })
//       .catch((error: unknown) => {
//         console.error(error);
//       });
//   }, []);
 
//   return (
//     <KeycloakContext.Provider value={{ keycloak, initialized }}>
//       {children}
//     </KeycloakContext.Provider>
//   );
// };
 
// export const useKeycloak = () => useContext(KeycloakContext);
// "use client";
// import {
//   ReactNode,
//   createContext,
//   useContext,
//   useEffect,
//   useState,
//   useRef,
// } from "react";
// import keycloak from "../lib/keycloakInstance";
 
// // Define the shape of the context
// interface KeycloakContextType {
//   keycloak: any;
//   initialized: boolean;
//   authenticated: boolean;
// }
 
// // Create the context with default values
// const KeycloakContext = createContext<KeycloakContextType>({
//   keycloak,
//   initialized: false,
//   authenticated: false,
// });
 
// // Props type for the provider
// interface KeycloakProviderProps {
//   children: ReactNode;
// }
 
// export const KeycloakProvider = ({ children }: KeycloakProviderProps) => {
//   const [initialized, setInitialized] = useState<boolean>(false);
//   const [authenticated, setAuthenticated] = useState<boolean>(false);
//   const intervalIdRef = useRef<NodeJS.Timeout | null>(null);
//   const initializationRef = useRef<boolean>(false);
 
//   useEffect(() => {
//     // Prevent double initialization
//     if (initializationRef.current) {
//       return;
//     }
//     initializationRef.current = true;
 
//     const initKeycloak = async () => {
//       try {
//         const isAuthenticated = await keycloak.init({
//           onLoad: "check-sso",
//           silentCheckSsoRedirectUri: `${window.location.origin}/silent-check-sso.html`,
//           pkceMethod: "S256",
//         });
 
//         setInitialized(true);
//         setAuthenticated(isAuthenticated);
 
//         if (isAuthenticated && keycloak.token) {
//           // Store token
//           localStorage.setItem("accessToken", keycloak.token);
 
//           // Set up token refresh interval
//           // intervalIdRef.current = setInterval(() => {
//           //   keycloak
//           //     .updateToken(70)
//           //     .then((refreshed: boolean) => {
//           //       if (refreshed && keycloak.token) {
//           //         console.log("Token refreshed");
//           //         localStorage.setItem("accessToken", keycloak.token);
//           //       }
//           //     })
//           //     .catch((error: unknown) => {
//           //       console.error("Failed to refresh token:", error);
//           //       // Clear stored token on refresh failure
//           //       localStorage.removeItem("accessToken");
//           //       keycloak.login();
//           //     });
//           // }, 60000);
//         } else if (!isAuthenticated) {
//           console.log("User is not authenticated.");
//           // Don't automatically redirect to login, let the app decide
//           // keycloak.login();
//         }
//       } catch (error) {
//         console.log("Keycloak initialization failed:", error);
//         setInitialized(true); // Still set initialized to true to prevent loading state
//       }
//     };
 
//     initKeycloak();
 
//     // Cleanup function
//     return () => {
//       if (intervalIdRef.current) {
//         clearInterval(intervalIdRef.current);
//         intervalIdRef.current = null;
//       }
//       // Reset initialization flag on cleanup (for Strict Mode)
//       initializationRef.current = false;
//     };
//   }, []); // Empty dependency array
 
//   // Don't render children until Keycloak is initialized
//   if (!initialized) {
//     // return <div className="text-center h-full">Loading authentication...</div>;
//     return (
//       <div style={{ paddingTop: "5rem" }}>
//         <div
//           className="flex justify-center items-center"
//           style={{ paddingTop: "2rem" }}
//         >
//           <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
//         </div>
//         <div className="flex justify-center items-center pt-4">
//           <div
//             className="h-10 w-10 border-primary"
//             style={{ marginRight: "20px" }}
//           >
//             <div>Loading...</div>
//           </div>
//         </div>
//       </div>
//     );
//   }
 
//   return (
//     <KeycloakContext.Provider value={{ keycloak, initialized, authenticated }}>
//       {children}
//     </KeycloakContext.Provider>
//   );
// };
 
// export const useKeycloak = () => {
//   const context = useContext(KeycloakContext);
//   if (!context) {
//     throw new Error("useKeycloak must be used within a KeycloakProvider");
//   }
//   return context;
// };
 
//context/keycloakContext.tsx
"use client";
import {
  ReactNode,
  createContext,
  useContext,
  useEffect,
  useState,
  useRef,
} from "react";
import { useRouter, usePathname } from "next/navigation";
import keycloak from "../lib/keycloakInstance";
 
// Define the shape of the context
interface KeycloakContextType {
  keycloak: any;
  initialized: boolean;
  authenticated: boolean;
  login: () => void;
  logout: () => void;
  hasValidToken: boolean;
  hasRequiredRole: boolean;
  userRoles: string[];
  hasRole: (role: string) => boolean;
  getUserRoles: () => string[];
}
 
// Create the context with default values
const KeycloakContext = createContext<KeycloakContextType>({
  keycloak,
  initialized: false,
  authenticated: false,
  login: () => {},
  logout: () => {},
  hasValidToken: false,
  hasRequiredRole: false,
  userRoles: [],
  hasRole: () => false,
  getUserRoles: () => [],
});
 
// Props type for the provider
interface KeycloakProviderProps {
  children: ReactNode;
}
 
export const KeycloakProvider = ({ children }: KeycloakProviderProps) => {
  const [initialized, setInitialized] = useState<boolean>(false);
  const [authenticated, setAuthenticated] = useState<boolean>(false);
  const [hasValidToken, setHasValidToken] = useState<boolean>(false);
  const [hasRequiredRole, setHasRequiredRole] = useState<boolean>(false);
  const [userRoles, setUserRoles] = useState<string[]>([]);
  const intervalIdRef = useRef<NodeJS.Timeout | null>(null);
  const initializationRef = useRef<boolean>(false);
  const router = useRouter();
  const pathname = usePathname();
 
  // Required role constant
  const REQUIRED_ROLE = 'ai_interviewer_client';
 
  // Check if current route requires authentication
  const isProtectedRoute = () => {
    const publicRoutes = ["/careers", "/login"];
    return !(
      publicRoutes.includes(pathname) || pathname.startsWith("/interviewer/")
    );
  };
 
  // Helper function to extract roles from token
  const getUserRolesHelper = (token: any): string[] => {
    const roles: string[] = [];
   
    try {
      const tokenPayload = JSON.parse(atob(token.split(".")[1]));
     
      // // Get realm roles
      // if (tokenPayload.realm_access?.roles) {
      //   roles.push(...tokenPayload.realm_access.roles);
      // }
     
      // Get resource/client roles
      if (tokenPayload.resource_access) {
        Object.values(tokenPayload.resource_access).forEach((resource: any) => {
          if (resource.roles) {
            roles.push(...resource.roles);
          }
        });
      }
    } catch (error) {
      console.error('Error parsing token for roles:', error);
    }
   
    return roles;
  };
 
  const getUserRoles = (): string[] => {
    return userRoles;
  };
 
  const hasRole = (role: string): boolean => {
    return userRoles.includes(role);
  };
 
  // Check for existing token in localStorage
  const checkExistingToken = () => {
    if (typeof window !== "undefined") {
      const token = localStorage.getItem("accessToken");
      if (token) {
        try {
          // Basic token validation (you might want to decode and check expiry)
          const tokenPayload = JSON.parse(atob(token.split(".")[1]));
          const currentTime = Date.now() / 1000;
 
          if (tokenPayload.exp > currentTime) {
            setHasValidToken(true);
            // Add role checking:
            const roles = getUserRolesHelper(token);
            setUserRoles(roles);
            setHasRequiredRole(roles.includes(REQUIRED_ROLE));
            return true;
          } else {
            // Token expired, remove it
            localStorage.removeItem("accessToken");
            setHasValidToken(false);
            // Reset role states:
            setUserRoles([]);
            setHasRequiredRole(false);
            return false;
          }
        } catch (error) {
          // Invalid token format, remove it
          localStorage.removeItem("accessToken");
          setHasValidToken(false);
          // Reset role states:
          setUserRoles([]);
          setHasRequiredRole(false);
          return false;
        }
      }
    }
    return false;
  };
 
  const login = () => {
    keycloak.login();
  };
 
  const logout = () => {
    localStorage.removeItem("accessToken");
    setAuthenticated(false);
    setHasValidToken(false);
    // Add role resets:
    setUserRoles([]);
    setHasRequiredRole(false);
    keycloak.logout();
  };
 
  useEffect(() => {
    // Check for existing token first
    const tokenExists = checkExistingToken();
 
    // Handle routing based on token presence
    if (typeof window !== "undefined") {
      if (tokenExists && pathname === "/login") {
        // If user has valid token but is on login page, redirect to home
        // router.push("/job_description");
        return;
      } else if (!tokenExists && isProtectedRoute() && pathname !== "/login") {
        // If no valid token and trying to access protected route, redirect to login
        localStorage.removeItem("accessToken");
        router.push("/login");
        return;
      }
    }
 
    // Prevent double initialization
    if (initializationRef.current) {
      return;
    }
    initializationRef.current = true;
 
    const initKeycloak = async () => {
      try {
        const isAuthenticated = await keycloak.init({
          onLoad: "check-sso",
          silentCheckSsoRedirectUri: `${window.location.origin}/silent-check-sso.html`,
          pkceMethod: "S256",
        });
 
        setInitialized(true);
        setAuthenticated(isAuthenticated);
 
        if (isAuthenticated && keycloak.token) {
          // Store token
          localStorage.setItem("accessToken", keycloak.token);
          setHasValidToken(true);
 
          // Add role checking:
          const roles = getUserRolesHelper(keycloak.token);
          setUserRoles(roles);
          setHasRequiredRole(roles.includes(REQUIRED_ROLE));
 
          // If user was on login page and now authenticated, redirect to home
          if (pathname === "/login") {
            // router.push("/job_description");
          }
 
          // Set up token refresh interval
          intervalIdRef.current = setInterval(() => {
            keycloak
              .updateToken(70)
              .then((refreshed: boolean) => {
                if (refreshed && keycloak.token) {
                  console.log("Token refreshed");
                  localStorage.setItem("accessToken", keycloak.token);
                  setHasValidToken(true);
                  // Add role checking for refreshed token:
                  const roles = getUserRolesHelper(keycloak.token);
                  setUserRoles(roles);
                  setHasRequiredRole(roles.includes(REQUIRED_ROLE));
                }
              })
              .catch((error: unknown) => {
                console.error("Failed to refresh token:", error);
                // Clear stored token on refresh failure
                localStorage.removeItem("accessToken");
                setHasValidToken(false);
                // Add role resets:
                setUserRoles([]);
                setHasRequiredRole(false);
                if (isProtectedRoute()) {
                  // router.push("/login");
                }
              });
          }, 60000);
        } else if (!isAuthenticated && !tokenExists && isProtectedRoute()) {
          // No authentication and no valid token, redirect to login if on protected route
          // router.push("/login");
          // window.location.href = "/login";
          // router.push("/login");
        }
      } catch (error) {
        console.log("Keycloak initialization failed:", error);
        setInitialized(true);
 
        // If initialization failed and no valid token, redirect to login for protected routes
        if (!hasValidToken && isProtectedRoute()) {
          // router.push("/login");
        }
      }
    };
 
    initKeycloak();
 
    // Cleanup function
    return () => {
      if (intervalIdRef.current) {
        clearInterval(intervalIdRef.current);
        intervalIdRef.current = null;
      }
      // Reset initialization flag on cleanup (for Strict Mode)
      initializationRef.current = false;
    };
  }, [pathname, router]); // Include pathname and router in dependencies
 
  // Don't render children until Keycloak is initialized
  if (!initialized) {
    return (
      <div style={{ paddingTop: "5rem" }}>
        <div
          className="flex justify-center items-center"
          style={{ paddingTop: "2rem" }}
        >
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
        </div>
        <div className="flex justify-center items-center pt-4">
          <div
            className="h-10 w-10 border-primary"
            style={{ marginRight: "20px" }}
          >
            <div>Loading...</div>
          </div>
        </div>
      </div>
    );
  }
 
  return (
    <KeycloakContext.Provider
      value={{
        keycloak,
        initialized,
        authenticated,
        login,
        logout,
        hasValidToken,
        hasRequiredRole,
        userRoles,
        hasRole,
        getUserRoles,
      }}
    >
      {children}
    </KeycloakContext.Provider>
  );
};
 
export const useKeycloak = () => {
  const context = useContext(KeycloakContext);
  if (!context) {
    throw new Error("useKeycloak must be used within a KeycloakProvider");
  }
  // window.location.href = "/login";
  return context;
};
 
 
 