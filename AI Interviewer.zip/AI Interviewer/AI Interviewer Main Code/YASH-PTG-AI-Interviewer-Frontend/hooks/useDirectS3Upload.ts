import { authFetch } from '@/lib/authFetch';
import { useState, useRef, useCallback } from 'react';

interface UploadProgress {
  stage: 'idle' | 'recording' | 'preparing' | 'uploading' | 'completed' | 'error';
  percentage: number;
  message: string;
}

interface RecordingStats {
  totalChunks: number;
  totalSizeMB: number;
  recordingDurationMinutes: number;
}

export const useDirectRecording = (interviewId: string) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress>({
    stage: 'idle',
    percentage: 0,
    message: 'Ready to start recording'
  });
  const [error, setError] = useState("");
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordingStartTimeRef = useRef<number>(0);

  const getRecordingStats = useCallback((): RecordingStats => {
    const totalSize = recordedChunksRef.current.reduce((sum, chunk) => sum + chunk.size, 0);
    const duration = recordingStartTimeRef.current 
      ? (Date.now() - recordingStartTimeRef.current) / 1000 / 60 
      : 0;
    
    return {
      totalChunks: recordedChunksRef.current.length,
      totalSizeMB: Number((totalSize / (1024 * 1024)).toFixed(2)),
      recordingDurationMinutes: Number(duration.toFixed(1))
    };
  }, []);

  const startRecording = useCallback(async (stream: MediaStream): Promise<boolean> => {
    try {
      console.log("🎬 Starting recording for interview:", interviewId);
      
      setError("");
      recordedChunksRef.current = [];
      
      const supportedTypes = [
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp8,opus', 
        'video/webm;codecs=h264,opus',
        'video/webm',
        'video/mp4'
      ];
      
      const mimeType = supportedTypes.find(type => 
        MediaRecorder.isTypeSupported(type)
      ) || 'video/webm';
      
      console.log("📹 Using codec:", mimeType);
      
      const options: MediaRecorderOptions = {
        mimeType,
        audioBitsPerSecond: 128000,
        videoBitsPerSecond: 2500000,
      };

      const mediaRecorder = new MediaRecorder(stream, options);

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
          
          const stats = getRecordingStats();
          setUploadProgress(prev => ({
            ...prev,
            stage: 'recording',
            message: `Recording: ${stats.totalChunks} segments, ${stats.totalSizeMB} MB, ${stats.recordingDurationMinutes} min`
          }));
          
          console.log(`📦 Chunk ${stats.totalChunks}: ${(event.data.size / 1024).toFixed(1)} KB`);
        }
      };

      mediaRecorder.onstop = () => {
        const stats = getRecordingStats();
        console.log(`⏹️ Recording stopped: ${stats.totalChunks} chunks, ${stats.totalSizeMB} MB total`);
        setIsRecording(false);
        
        setUploadProgress(prev => ({
          ...prev,
          stage: 'preparing',
          percentage: 0,
          message: `Recording complete: ${stats.totalSizeMB} MB ready for upload`
        }));
      };

      mediaRecorder.onerror = (event) => {
        console.error("❌ MediaRecorder error:", event);
        const errorMsg = "Recording error occurred";
        setError(errorMsg);
        setUploadProgress({
          stage: 'error',
          percentage: 0,
          message: errorMsg
        });
      };

      recordingStartTimeRef.current = Date.now();
      mediaRecorder.start(10000);
      mediaRecorderRef.current = mediaRecorder;
      setIsRecording(true);
      
      setUploadProgress({
        stage: 'recording',
        percentage: 0,
        message: 'Recording started - buffering in memory...'
      });

      // Call /recording/start endpoint
      try {
        await authFetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/recording/start`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ unique_id: interviewId }),
        });
      } catch (startError) {
        console.warn("Failed to call /recording/start, continuing anyway:", startError);
      }

      return true;
      
    } catch (err) {
      const errorMsg = `Failed to start recording: ${err}`;
      console.error("❌", errorMsg);
      setError(errorMsg);
      setUploadProgress({
        stage: 'error',
        percentage: 0,
        message: errorMsg
      });
      return false;
    }
  }, [interviewId, getRecordingStats]);

  const stopRecordingAndUpload = useCallback(async (): Promise<boolean> => {
    try {
      console.log("🛑 Stopping recording and starting upload...");
      setIsUploading(true);
      setError("");
      
      setUploadProgress({
        stage: 'preparing',
        percentage: 5,
        message: 'Stopping recording...'
      });
      
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }

      // Call /recording/stop endpoint
      try {
        await authFetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/recording/stop`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ unique_id: interviewId }),
        });
      } catch (stopError) {
        console.warn("Failed to call /recording/stop, continuing anyway:", stopError);
      }

      await new Promise(resolve => setTimeout(resolve, 2000));

      const stats = getRecordingStats();
      
      if (recordedChunksRef.current.length === 0) {
        throw new Error("No recording data found - please try recording again");
      }

      console.log(`📊 Final stats: ${stats.totalChunks} chunks, ${stats.totalSizeMB} MB`);

      setUploadProgress({
        stage: 'preparing',
        percentage: 15,
        message: 'Combining recording segments...'
      });
      
      const finalBlob = new Blob(recordedChunksRef.current, { 
        type: 'video/webm' // Explicitly set to video/webm
      });
      
      const finalSizeMB = (finalBlob.size / (1024 * 1024)).toFixed(2);
      console.log(`🎯 Combined recording: ${finalSizeMB} MB`);

      setUploadProgress({
        stage: 'preparing',
        percentage: 25,
        message: 'Getting secure upload URL...'
      });

      if (!process.env.NEXT_PUBLIC_BACKEND_URL) {
        throw new Error('Backend URL not configured in environment variables');
      }

      const urlResponse = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/recording/generate-upload-url`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ unique_id: interviewId }),
        }
      );

      if (!urlResponse.ok) {
        const errorText = await urlResponse.text();
        throw new Error(`Backend error: ${urlResponse.status} - ${errorText}`);
      }

      const uploadSession = await urlResponse.json();
      console.log("🔗 Got upload URL for:", uploadSession.s3_key);

      setUploadProgress({
        stage: 'uploading',
        percentage: 35,
        message: `Uploading ${finalSizeMB} MB to S3...`
      });

      const s3Response = await fetch(uploadSession.upload_url, {
        method: "PUT",
        body: finalBlob,
        headers: {
          'Content-Type': 'video/webm', // Explicitly set to match backend
        },
      });

      if (!s3Response.ok) {
        const errorText = await s3Response.text();
        throw new Error(`S3 upload failed: ${s3Response.status} - ${errorText}`);
      }

      console.log("☁️ S3 upload successful!");

      setUploadProgress({
        stage: 'uploading',
        percentage: 80,
        message: 'Upload successful - finalizing...'
      });

      const completeResponse = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/recording/complete-upload`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            unique_id: interviewId,
            s3_key: uploadSession.s3_key,
          }),
        }
      );

      if (!completeResponse.ok) {
        const errorText = await completeResponse.text();
        throw new Error(`Backend completion failed: ${completeResponse.status} - ${errorText}`);
      }

      const result = await completeResponse.json();
      console.log("✅ Upload fully completed:", result.s3_url);

      setUploadProgress({
        stage: 'completed',
        percentage: 100,
        message: `🎉 Upload complete! ${finalSizeMB} MB uploaded successfully`
      });

      recordedChunksRef.current = [];
      
      return true;
      
    } catch (err) {
      const errorMsg = `Upload failed: ${err}`;
      console.error("❌", errorMsg);
      setError(errorMsg);
      
      setUploadProgress({
        stage: 'error',
        percentage: 0,
        message: errorMsg
      });
      
      return false;
    } finally {
      setIsUploading(false);
    }
  }, [interviewId, getRecordingStats]);

  const cleanup = useCallback(() => {
    console.log("🧹 Cleaning up recording session...");
    
    if (mediaRecorderRef.current) {
      if (mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      mediaRecorderRef.current = null;
    }
    
    recordedChunksRef.current = [];
    recordingStartTimeRef.current = 0;
    
    setIsRecording(false);
    setIsUploading(false);
    setUploadProgress({
      stage: 'idle',
      percentage: 0,
      message: 'Ready to start recording'
    });
    setError("");
    
    console.log("✨ Cleanup completed");
  }, []);

  const stopRecordingOnly = useCallback(() => {
    console.log("⏹️ Force stopping recording...");
    
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    
    setIsRecording(false);
    const stats = getRecordingStats();
    
    setUploadProgress({
      stage: 'preparing',
      percentage: 0,
      message: `Recording stopped: ${stats.totalSizeMB} MB buffered, ready for upload`
    });

    // Call /recording/stop endpoint
    try {
      authFetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/recording/stop`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ unique_id: interviewId }),
      });
    } catch (stopError) {
      console.warn("Failed to call /recording/stop, continuing anyway:", stopError);
    }
  }, [interviewId, getRecordingStats]);

  const getStatus = useCallback(() => {
    const stats = getRecordingStats();
    return {
      isRecording,
      isUploading,
      uploadProgress,
      error,
      stats,
      canStartRecording: !isRecording && !isUploading,
      canStopRecording: isRecording && !isUploading,
      hasRecordedData: recordedChunksRef.current.length > 0
    };
  }, [isRecording, isUploading, uploadProgress, error, getRecordingStats]);

  return {
    isRecording,
    isUploading,
    uploadProgress,
    error,
    ...getRecordingStats(),
    startRecording,
    stopRecordingAndUpload,
    cleanup,
    stopRecordingOnly,
    getStatus,
    canStartRecording: !isRecording && !isUploading,
    canStopRecording: isRecording && !isUploading,
    hasRecordedData: recordedChunksRef.current.length > 0,
    memoryUsageMB: getRecordingStats().totalSizeMB
  };
};