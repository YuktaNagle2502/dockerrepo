// hooks/useTabSwitchingDetection.ts
import { authFetch } from '@/lib/authFetch';
import { useRef, useCallback, useEffect } from 'react';

// Define types for switch detection
type SwitchType = 'visibility_hidden' | 'window_blur' | 'page_hide' | 'unknown';

// Define the return type of the hook
interface TabSwitchingDetectionReturn {
  isTabActive: boolean;
  isWindowFocused: boolean;
  lastSwitchType: SwitchType;
  captureScreenshot: () => Promise<string | null>;
  reportTabSwitch: (screenshotData: string, switchType?: SwitchType) => Promise<void>;
  getCurrentState: () => {
    isTabActive: boolean;
    isWindowFocused: boolean;
    isDocumentHidden: boolean;
    hasDocumentFocus: boolean;
    lastSwitchType: SwitchType;
  };
}

// Define types for html2canvas if it exists on window
declare global {
  interface Window {
    html2canvas?: (
      element: HTMLElement,
      options?: {
        useCORS?: boolean;
        allowTaint?: boolean;
        scale?: number;
        width?: number;
        height?: number;
      }
    ) => Promise<HTMLCanvasElement>;
  }
}

export const useTabSwitchingDetection = (
  interviewId: string,
  isInterviewActive: boolean = false
): TabSwitchingDetectionReturn => {
  const isTabActiveRef = useRef<boolean>(true);
  const screenshotCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastSwitchTimeRef = useRef<number>(0);
  const isMountedRef = useRef<boolean>(true);
  const isWindowFocusedRef = useRef<boolean>(true);
  const lastSwitchTypeRef = useRef<SwitchType>('unknown');

  // Debounce to prevent multiple rapid captures
  const DEBOUNCE_DELAY: number = 2000; // 2 seconds

  const captureScreenshot = useCallback(async (): Promise<string | null> => {
    if (!isInterviewActive || !interviewId) return null;

    try {
      // Create a canvas to capture the current screen
      const canvas: HTMLCanvasElement = document.createElement('canvas');
      const ctx: CanvasRenderingContext2D | null = canvas.getContext('2d');
      
      if (!ctx) {
        console.error('Failed to get 2D context from canvas');
        return null;
      }

      // Set canvas size
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;

      // Try to capture using html2canvas if available, otherwise use a fallback
      if (window.html2canvas) {
        const screenshot: HTMLCanvasElement = await window.html2canvas(document.body, {
          useCORS: true,
          allowTaint: true,
          scale: 0.5, // Reduce quality to minimize size
          width: window.innerWidth,
          height: window.innerHeight
        });

        // Convert to base64
        const screenshotData: string = screenshot.toDataURL('image/jpeg', 0.7);
        return screenshotData;
      } else {
        // Fallback: Create a simple screenshot indicator
        ctx.fillStyle = '#f0f0f0';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = '#333';
        ctx.font = '24px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Tab Switch Detected', canvas.width / 2, canvas.height / 2);
        ctx.fillText(`Time: ${new Date().toLocaleString()}`, canvas.width / 2, canvas.height / 2 + 40);

        return canvas.toDataURL('image/jpeg', 0.7);
      }
    } catch (error) {
      console.error('Error capturing screenshot:', error);
      return null;
    }
  }, [interviewId, isInterviewActive]);

  const reportTabSwitch = useCallback(async (
    screenshotData: string,
    switchType: SwitchType = 'unknown'
  ): Promise<void> => {
    if (!interviewId || !screenshotData) return;

    try {
      const formData = new FormData();
      formData.append('interview_id', interviewId);
      formData.append('screenshot_data', screenshotData);
      formData.append('timestamp', new Date().toISOString());

      if (!process.env.NEXT_PUBLIC_BACKEND_URL) {
        console.error('Backend URL not configured');
        return;
      }

      const response: Response = await authFetch(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/tab-switching/report_tab_switching`,
        {
          method: 'POST',
          body: formData,
        }
      );

      if (!response.ok) {
        console.error('Failed to report tab switching:', response.statusText);
      } else {
        console.log(`Tab switching reported successfully - Type: ${switchType}`);
      }
    } catch (error) {
      console.error('Error reporting tab switching:', error);
    }
  }, [interviewId]);

  // Enhanced tab switch detection function
  const detectAndReportTabSwitch = useCallback(async (switchType: SwitchType): Promise<void> => {
    if (!isMountedRef.current || !isInterviewActive) return;

    const now: number = Date.now();
    lastSwitchTypeRef.current = switchType;
    
    // Debounce to prevent rapid firing
    if (now - lastSwitchTimeRef.current > DEBOUNCE_DELAY) {
      lastSwitchTimeRef.current = now;
     
      // Small delay to ensure the tab switch is complete
      setTimeout(async () => {
        if (isMountedRef.current) {
          const screenshot: string | null = await captureScreenshot();
          if (screenshot) {
            await reportTabSwitch(screenshot, switchType);
          }
        }
      }, 500);
    }
  }, [isInterviewActive, captureScreenshot, reportTabSwitch]);

  const handleVisibilityChange = useCallback(async (): Promise<void> => {
    if (!isMountedRef.current || !isInterviewActive) return;

    const isCurrentlyVisible: boolean = !document.hidden;

    // If tab becomes hidden (user switched away or minimized)
    if (!isCurrentlyVisible && isTabActiveRef.current) {
      isTabActiveRef.current = false;
      await detectAndReportTabSwitch('visibility_hidden');
    }
    // If tab becomes visible (user switched back)
    else if (isCurrentlyVisible && !isTabActiveRef.current) {
      isTabActiveRef.current = true;
    }
  }, [isInterviewActive, detectAndReportTabSwitch]);

  // Handle window focus/blur events (covers minimization and window switching)
  const handleWindowBlur = useCallback(async (): Promise<void> => {
    if (!isMountedRef.current || !isInterviewActive) return;

    // Window lost focus (minimized, switched to another app, etc.)
    if (isWindowFocusedRef.current) {
      isWindowFocusedRef.current = false;
      isTabActiveRef.current = false;
      await detectAndReportTabSwitch('window_blur');
    }
  }, [isInterviewActive, detectAndReportTabSwitch]);

  const handleWindowFocus = useCallback((): void => {
    if (!isMountedRef.current || !isInterviewActive) return;

    // Window gained focus
    if (!isWindowFocusedRef.current) {
      isWindowFocusedRef.current = true;
      isTabActiveRef.current = true;
    }
  }, [isInterviewActive]);

  // Handle page hide/show events (additional layer of detection)
  const handlePageHide = useCallback(async (): Promise<void> => {
    if (!isMountedRef.current || !isInterviewActive) return;

    if (isTabActiveRef.current) {
      isTabActiveRef.current = false;
      await detectAndReportTabSwitch('page_hide');
    }
  }, [isInterviewActive, detectAndReportTabSwitch]);

  const handlePageShow = useCallback((): void => {
    if (!isMountedRef.current || !isInterviewActive) return;

    if (!isTabActiveRef.current) {
      isTabActiveRef.current = true;
    }
  }, [isInterviewActive]);

  // Load html2canvas library dynamically
  useEffect(() => {
    if (!isInterviewActive) return;

    const loadHtml2Canvas = async (): Promise<void> => {
      if (!window.html2canvas) {
        try {
          const script: HTMLScriptElement = document.createElement('script');
          script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
          script.async = true;
          document.head.appendChild(script);

          script.onload = (): void => {
            console.log('html2canvas loaded successfully');
          };

          script.onerror = (): void => {
            console.warn('Failed to load html2canvas, using fallback screenshot method');
          };
        } catch (error) {
          console.warn('Error loading html2canvas:', error);
        }
      }
    };

    loadHtml2Canvas();
  }, [isInterviewActive]);

  useEffect(() => {
    if (!isInterviewActive) return;

    isMountedRef.current = true;
    isTabActiveRef.current = !document.hidden;
    isWindowFocusedRef.current = document.hasFocus();

    // Primary detection: visibilitychange (tab switching, minimizing)
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Secondary detection: window focus/blur (minimizing, app switching)
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);
    
    // Tertiary detection: page hide/show (additional coverage)
    window.addEventListener('pagehide', handlePageHide);
    window.addEventListener('pageshow', handlePageShow);

    // Additional detection for page unload
    const handleBeforeUnload = (): void => {
      // User is leaving the page entirely
      if (isMountedRef.current && isInterviewActive) {
        // Note: We can't make async calls in beforeunload reliably
        console.log('User is leaving the interview page');
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      isMountedRef.current = false;
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
      window.removeEventListener('pagehide', handlePageHide);
      window.removeEventListener('pageshow', handlePageShow);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [isInterviewActive, handleVisibilityChange, handleWindowBlur, handleWindowFocus, handlePageHide, handlePageShow]);

  // Utility function to get current state
  const getCurrentState = useCallback(() => ({
    isTabActive: isTabActiveRef.current,
    isWindowFocused: isWindowFocusedRef.current,
    isDocumentHidden: document.hidden,
    hasDocumentFocus: document.hasFocus(),
    lastSwitchType: lastSwitchTypeRef.current
  }), []);

  // Return hook state and methods
  return {
    isTabActive: isTabActiveRef.current,
    isWindowFocused: isWindowFocusedRef.current,
    lastSwitchType: lastSwitchTypeRef.current,
    captureScreenshot,
    reportTabSwitch,
    getCurrentState
  };
};
