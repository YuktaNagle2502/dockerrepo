// hooks/useRoleProtection.ts
"use client";

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useKeycloak } from '@/context/keycloakContext';

export function useRoleProtection() {
  const router = useRouter();
  const { 
    initialized, 
    authenticated, 
    hasValidToken, 
    hasRequiredRole 
  } = useKeycloak();

  useEffect(() => {
    if (initialized) {
      // If not authenticated or no valid token, redirect to login
      if (!authenticated || !hasValidToken) {
        router.push('/login');
        return;
      }

      // If authenticated but doesn't have required role, redirect to access denied
      if (!hasRequiredRole) {
        router.push('/access-denied');
        return;
      }
    }
  }, [initialized, authenticated, hasValidToken, hasRequiredRole, router]);

  // Return loading states
  const isCheckingAuth = !initialized;
  const isRedirectingToLogin = initialized && (!authenticated || !hasValidToken);
  const isRedirectingToAccessDenied = initialized && authenticated && hasValidToken && !hasRequiredRole;
  const isAuthorized = initialized && authenticated && hasValidToken && hasRequiredRole;

  return {
    isCheckingAuth,
    isRedirectingToLogin,
    isRedirectingToAccessDenied,
    isAuthorized
  };
}