import type { NextConfig } from "next";
const nextConfig: NextConfig = {
  reactStrictMode: false,
  output: "standalone",
  async redirects() {
    return [
      {
        source: "/",
        destination: "/job_description",
        permanent: true, // or false for temporary (302) redirect
      },
    ];
  },
};
export default nextConfig;
 