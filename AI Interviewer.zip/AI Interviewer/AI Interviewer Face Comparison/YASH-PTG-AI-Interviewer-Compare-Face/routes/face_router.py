import numpy as np
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from typing import Annotated
from services.face_service import FaceService
from image_utils import process_image_async
import asyncio
import logging

router = APIRouter()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@router.post("/compare_faces/")
async def compare_faces(
    known_image: Annotated[UploadFile, File()],
    unknown_image: Annotated[UploadFile, File()]
):
    logger.info(f"Processing images: {known_image.filename}, {unknown_image.filename}")
    try:
        # Add timeout to prevent hanging connections
        img1_task = process_image_async(known_image)
        img2_task = process_image_async(unknown_image)
        img1, img2 = await asyncio.wait_for(
            asyncio.gather(img1_task, img2_task), 
            timeout=30.0  # 30 second timeout
        )

        service = FaceService()
        # Add timeout to face verification
        result = await asyncio.wait_for(
            service.verify_faces(img1, img2), 
            timeout=60.0  # 60 second timeout for face comparison
        )

        if 'error' in result:
            logger.warning(f"Face verification error: {result.get('error')}")
            return JSONResponse(
                status_code=200,
                content={"match": False, "confidence": 0.0, "error": "Face verification failed"}
            )

        return {
            "match": result.get('match', False),
            "confidence": result.get('confidence', 0.0),
            "details": result.get('details', [])
        }

    except asyncio.TimeoutError:
        logger.error("Request timeout - processing took too long")
        return JSONResponse(
            status_code=408,
            content={"match": False, "confidence": 0.0, "error": "Request timeout"}
        )
    except ConnectionError as e:
        logger.error(f"Connection error: {str(e)}")
        return JSONResponse(
            status_code=503,
            content={"match": False, "confidence": 0.0, "error": "Service temporarily unavailable"}
        )
    except Exception as e:
        logger.error(f"Error processing images: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"match": False, "confidence": 0.0, "error": "Internal server error"}
        )