import os
import jwt
from jwt.exceptions import ExpiredSignatureError, InvalidTokenError
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.security.utils import get_authorization_scheme_param
from starlette.responses import JSONResponse
from dotenv import load_dotenv
load_dotenv()
CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",  # or specific origin
    "Access-Control-Allow-Methods": "*",
    "Access-Control-Allow-Headers": "*",
}

# Load Keycloak configuration from environment variables
KEYCLOAK_PUBLIC_KEY = os.getenv("KEYCLOAK_PUBLIC_KEY")
KEYCLOAK_ISSUER = os.getenv("KEYCLOAK_ISSUER")
KEYCLOAK_AUDIENCE = os.getenv("KEYCLOAK_AUDIENCE")
JWKS_URL = f"{KEYCLOAK_ISSUER}/protocol/openid-connect/certs"
KEYCLOAK_ISSUER = os.getenv("KEYCLOAK_ISSUER")

class KeycloakAuthMiddleware(BaseHTTPMiddleware):
    """Middleware to enforce authentication and role-based authorization."""

    async def dispatch(self, request: Request, call_next):

        path = request.url.path
        method = request.method
        if method == "OPTIONS":
            return JSONResponse(
                status_code=200,
                content={"message": "CORS preflight"},
                headers=CORS_HEADERS,
            )

        print("path print", path)

        # Allow public paths (like homepage or docs) to bypass authentication

        if (
            path == "/"
            or path.startswith("/docs")
            or path.startswith("/openapi.json")
            or path.startswith("/compare_faces")
            or path.startswith("/api/user/session/agent/chat")
            or path.startswith("/api/admin/application/clients")
        ):

            return await call_next(request)

        # Extract Authorization header

        auth_header = request.headers.get("Authorization")

        if not auth_header:

            return JSONResponse(
                status_code=401,
                content={"detail": "Missing Authorization Header"},
                headers=CORS_HEADERS,
            )

        scheme, token = get_authorization_scheme_param(auth_header)

        if scheme.lower() != "bearer" or not token:

            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid Authorization Header"},
                headers=CORS_HEADERS,
            )

        try:

            # Convert literal '\n' into actual newlines

            formatted_key = KEYCLOAK_PUBLIC_KEY.replace("\\n", "\n")

            print("path_key", formatted_key)

            payload = jwt.decode(
                token, formatted_key, algorithms=["RS256"], audience="account"
            )

            request.state.user = payload

        except ExpiredSignatureError:

            return JSONResponse(
                status_code=401,
                content={"detail": "Token has expired"},
                headers=CORS_HEADERS,
            )

        except InvalidTokenError:

            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid token"},
                headers=CORS_HEADERS,
            )

        # Authorization based on URL prefix

        required_role = []

        if path.startswith("/api/admin/"):

            required_role = ["admin", "manager"]

        elif path.startswith("/api/user/"):

            required_role = ["user"]

        if required_role:

            roles = payload.get("realm_access", {}).get("roles", [])

            if not any(role in roles for role in required_role):

                return JSONResponse(
                    status_code=403,
                    content={
                        "detail": f"You don't have '{required_role}' access: Unauthorized"
                    },
                )

        return await call_next(request)
