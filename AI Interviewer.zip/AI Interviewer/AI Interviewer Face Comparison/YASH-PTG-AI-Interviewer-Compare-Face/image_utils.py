import numpy as np
import cv2
from fastapi import UploadFile, HTTPException
from concurrent.futures import ThreadPoolExecutor
import functools
import asyncio
from mtcnn import MTCNN
 
ALLOWED_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.bmp', '.tiff'}
executor = ThreadPoolExecutor(max_workers=4)  # Increase workers
detector = MTCNN()
 
def enhance_image_quality(img_array: np.ndarray) -> np.ndarray:
    # Skip histogram equalization
    # img_yuv = cv2.cvtColor(img_array, cv2.COLOR_RGB2YUV)
    # img_yuv[:, :, 0] = cv2.equalizeHist(img_yuv[:, :, 0])
    # img_enhanced = cv2.cvtColor(img_yuv, cv2.COLOR_YUV2RGB)
    # return img_enhanced
    return img_array  # Return original image
 
def align_face(img_array: np.ndarray) -> np.ndarray:
    faces = detector.detect_faces(img_array)
    if not faces:
        raise ValueError("No faces detected in the image")
    # Use the first detected face
    keypoints = faces[0]['keypoints']
    # Simple alignment based on eye positions (example)
    left_eye = keypoints['left_eye']
    right_eye = keypoints['right_eye']
    # Implement alignment logic (e.g., rotate/scale based on eyes)
    return img_array  # Replace with actual alignment logic
 
async def process_image_async(file: UploadFile) -> np.ndarray:
    try:
        if file.size > 10 * 1024 * 1024:
            raise HTTPException(400, detail="File size exceeds 10MB limit")
       
        filename = file.filename.lower()
        if not any(filename.endswith(ext) for ext in ALLOWED_EXTENSIONS):
            raise HTTPException(400, detail="Invalid file type. Only PNG, JPG, JPEG, BMP, TIFF allowed")
 
        contents = await file.read()
        if len(contents) == 0:
            raise HTTPException(400, detail="Empty file received")
 
        loop = asyncio.get_event_loop()
        img_array = await loop.run_in_executor(
            executor,
            functools.partial(decode_and_process_image, contents)
        )
        return img_array
 
    except Exception as e:
        raise HTTPException(400, detail=str(e))
 
def decode_and_process_image(contents: bytes) -> np.ndarray:
    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
 
    if img is None:
        raise ValueError("Could not decode image - possibly corrupted")
 
    height, width = img.shape[:2]
    if height < 100 or width < 100:
        raise ValueError("Image resolution too low (minimum 100x100 pixels)")
 
    if height > 1024 or width > 1024:
        scale = min(1024/height, 1024/width)
        new_height, new_width = int(height * scale), int(width * scale)
        img = cv2.resize(img, (new_width, new_height), interpolation=cv2.INTER_AREA)  # Faster interpolation
 
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img_rgb = align_face(img_rgb)
    return enhance_image_quality(img_rgb)