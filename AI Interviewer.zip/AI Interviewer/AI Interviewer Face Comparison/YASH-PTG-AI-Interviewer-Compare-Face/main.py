from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes.face_router import router
import asyncio

app = FastAPI(title="Face Comparison")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for development; restrict in production
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)

app.include_router(router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=8001,
        timeout_keep_alive=120,  # Keep connections alive longer
        timeout_graceful_shutdown=30,  # Graceful shutdown timeout
        limit_max_requests=1000,  # Limit concurrent requests
        access_log=True
    )