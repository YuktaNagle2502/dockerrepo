 
import numpy as np
import cv2
import tempfile
import os
from deepface import DeepFace
from concurrent.futures import ThreadPoolExecutor
import functools
import asyncio
 
class FaceService:
    def __init__(self):
        self.executor = ThreadPoolExecutor(max_workers=4)  # Increase workers
 
    async def verify_faces(self, img1: np.ndarray, img2: np.ndarray) -> dict:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            self.executor,
            functools.partial(self._verify_faces_sync, img1, img2)
        )
        return result
 
    def _verify_faces_sync(self, img1: np.ndarray, img2: np.ndarray) -> dict:
        temp_path1 = None
        temp_path2 = None
        try:
            temp_path1 = self._save_temp_image(img1)
            temp_path2 = self._save_temp_image(img2)
 
            # Use ArcFace with mtcnn detector
            try:
                result = DeepFace.verify(
                    img1_path=temp_path1,
                    img2_path=temp_path2,
                    model_name="ArcFace",
                    detector_backend="mtcnn",  # Use MTCNN
                    distance_metric="cosine",
                    enforce_detection=True,
                    align=True
                )
                if isinstance(result, dict) and 'distance' in result:
                    distance = result['distance']
                    similarity = max(0, min(1, 1 - distance))
                    is_match = distance < 0.65  # Keep ArcFace threshold
                    return {
                        "similarity": round(similarity, 4),
                        "match": is_match,
                        "confidence": round(similarity, 4),
                        "details": [{"model": "ArcFace", "detector": "mtcnn", "similarity": similarity}]
                    }
                else:
                    return {"error": "No faces detected or verification failed", "similarity": 0.0}
            except Exception as e:
                return {"error": str(e), "similarity": 0.0}
 
        except Exception as e:
            return {"error": str(e), "similarity": 0.0}
        finally:
            self._cleanup_temp_files(temp_path1, temp_path2)
 
    def _save_temp_image(self, img_array: np.ndarray) -> str:
        with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as temp_file:
            temp_path = temp_file.name
            img_bgr = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
            cv2.imwrite(temp_path, img_bgr, [cv2.IMWRITE_JPEG_QUALITY, 95])
        return temp_path
 
    def _cleanup_temp_files(self, *file_paths: str) -> None:
        for file_path in file_paths:
            try:
                if file_path and os.path.exists(file_path):
                    os.unlink(file_path)
            except Exception:
                continue