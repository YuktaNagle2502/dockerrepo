
export default (dependencies) => async (event) => {
    console.log("event :- ", event);
    let receiveEvent;
    try {
        receiveEvent = JSON.parse(event.body);
    } catch (error) {
        console.error("Error parsing event body:", error);
        return dependencies.utility.errorResponse(400, "Invalid JSON format");
    }
    if (receiveEvent.group_name) {
        let connection;
        try {
            connection = await dependencies.utility.getRDSConnection(process.env.SECRET_MANAGER);
            await connection.execute("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
            await connection.beginTransaction();
            const addGroupResult = await addGroup(receiveEvent, connection);
            console.log("Add Group Result:", addGroupResult);
            await connection.commit();
            return dependencies.utility.successResponse("Group Added Successfully");
        } catch (error) {
            if (connection) {
                await connection.rollback();
            }
            console.error("Error during database operation:", error);
            return dependencies.utility.errorResponse(500, error.code);
        } finally {
            if (connection) {
                await connection.close(); 
            }
        }
    } else {
        return dependencies.utility.errorResponse(400, "Group not provided");
    }
 };
 const addGroup = async (receiveEvent, connection) => {
    const nameValue = receiveEvent.group_name || ""
    const descValue = receiveEvent.group_description || ""; 
    const typeValue = receiveEvent.group_type || ""; 
    console.log("Inserting group:", nameValue, descValue);
    try {
        const [result] = await connection.execute(
            "INSERT INTO `groups` (group_name, group_description, group_type) VALUES (?, ?, ?)",
            [nameValue, descValue, typeValue]
        );
        return result;
    } catch (error) {
        console.error("Error inserting group:", error);
        throw error;
    }
 };
 