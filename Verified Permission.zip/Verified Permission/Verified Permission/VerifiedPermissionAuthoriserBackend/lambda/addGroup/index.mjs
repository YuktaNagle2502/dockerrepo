import utility from '/opt/nodejs/utilities.mjs';
import createHandler from './handler.mjs';
 
export const handler = createHandler({ utility });