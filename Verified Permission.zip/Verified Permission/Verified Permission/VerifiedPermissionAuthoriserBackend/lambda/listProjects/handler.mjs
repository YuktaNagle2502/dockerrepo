export default dependencies => async (event) => {
  var connection
  try {
    connection = await dependencies.utility.getRDSConnection(process.env.SECRET_MANAGER)
    const { user_type } = event.queryStringParameters
    if (user_type == "Admin") {
      const response = await listAllProjects(event, connection)
      return dependencies.utility.successResponse(response);
    } else if (user_type == 'ApiOwner') {
      const response = await listUserProjects(event, connection);
      return dependencies.utility.successResponse(response);
    }
  } catch (error) {
    return dependencies.utility.errorResponse(error);
  }
}

const listUserProjects = async (event, connection) => {
  try {
    const { userId } = event.queryStringParameters;
    const [results] = await connection.execute('SELECT p.* FROM projects p JOIN user_project up ON p.project_id = up.fk_project_id WHERE up.fk_user_id =?', [userId]);
    await connection.end();

    return results
  } catch (error) {
    throw error;
  }

}
const listAllProjects = async (event, connection) => {
  try {
    const [results] = await connection.execute('SELECT p.* FROM projects p');
    await connection.end();

    return results
  } catch (error) {
    throw error;
  }
}
export { listUserProjects, listAllProjects };