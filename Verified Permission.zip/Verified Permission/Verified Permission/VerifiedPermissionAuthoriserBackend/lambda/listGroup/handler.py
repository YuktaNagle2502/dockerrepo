import os
import sys

if os.path.isdir("../../layers/dependencies/python"):
    sys.path.append("../../layers/dependencies/python")

import utility


def lambda_handler(event, context):
    try:
        # Establish connection to RDS
        conn = utility.getRDSConnection(os.environ['SECRET_MANAGER'])
    except Exception as e:
        print(e)
        sys.exit()
        return utility.error_response(500,"Internal Server Error")
    try:
        with conn.cursor() as cursor:
            # Fetch all groups
            sql_groups = "SELECT group_id, group_name, group_description FROM `groups` where group_type = 'ConsumerUser'"
            cursor.execute(sql_groups)
            group_rows = cursor.fetchall()
    except Exception as e:
        return utility.error_response(500, f"Error fetching data: {str(e)}")
    finally:
        conn.close()
    return utility.success_response(group_rows)