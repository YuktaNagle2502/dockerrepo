-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema access_management
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema access_management
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `access_management` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `access_management` ;

-- -----------------------------------------------------
-- Table `access_management`.`group`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `access_management`.`group` (
  `group_id` INT NOT NULL,
  `group_name` VARCHAR(45) NULL DEFAULT NULL,
  `group_description` VARCHAR(45) NULL DEFAULT NULL,
  `group_type` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`group_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `access_management`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `access_management`.`user` (
  `user_id` VARCHAR(45) NOT NULL,
  `user_name` VARCHAR(45) NOT NULL,
  `user_email` VARCHAR(45) NOT NULL,
  `user_type` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`user_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `access_management`.`user_group`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `access_management`.`user_group` (
  `user_group_id` INT NOT NULL,
  `user_id_fk` VARCHAR(45) NULL,
  `group_id_fk` INT NULL,
  PRIMARY KEY (`user_group_id`),
  INDEX `user_id_idx` (`user_id_fk` ASC) VISIBLE,
  INDEX `group_id_idx` (`group_id_fk` ASC) VISIBLE,
  CONSTRAINT `user_id_fk`
    FOREIGN KEY (`user_id_fk`)
    REFERENCES `access_management`.`user` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `group_id_fk`
    FOREIGN KEY (`group_id_fk`)
    REFERENCES `access_management`.`group` (`group_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `access_management`.`project`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `access_management`.`project` (
  `project_id` INT NOT NULL,
  `project_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`project_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `access_management`.`user_project`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `access_management`.`user_project` (
  `user_project_id` INT NOT NULL,
  `fk_user_id` VARCHAR(45) NULL,
  `fk_project_id` INT NULL,
  PRIMARY KEY (`user_project_id`),
  INDEX `user_id_idx` (`fk_user_id` ASC) VISIBLE,
  INDEX `project_id_idx` (`fk_project_id` ASC) VISIBLE,
  CONSTRAINT `fk_user_id`
    FOREIGN KEY (`fk_user_id`)
    REFERENCES `access_management`.`user` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_project_id`
    FOREIGN KEY (`fk_project_id`)
    REFERENCES `access_management`.`project` (`project_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
