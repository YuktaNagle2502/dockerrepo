import { GetSecretValueCommand, SecretsManagerClient } from '@aws-sdk/client-secrets-manager'
const Importer = require('mysql-import');
export default  dependencies =>  async (event) => {
    var importer;
    try {
        const secret_name = process.env.SECRET_MANAGER;
        const sm = new SecretsManagerClient({});
        const res = await sm.send(
            new GetSecretValueCommand({
                SecretId: secret_name,
            })
        );

        const secret = JSON.parse(res.SecretString);

        // await connection.execute("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
        importer = new Importer({
            host: secret.host,
            user: secret.username,
            password: secret.password,
            database: secret.dbname,
        });

        let response = await createTable(importer);
        console.log(response);
        return dependencies.utility.successResponse("queries executed");
    } catch (error) {
        return dependencies.utility.errorResponse(400, "queries not executed" + error);
    }
};

const createTable = async (importer) => {
    await importer
        .import("./dump.sql")
        .then(() => {
            var files_imported = importer.getImported();
            console.log(`${files_imported.length} SQL file(s) imported.`);
        })

};


