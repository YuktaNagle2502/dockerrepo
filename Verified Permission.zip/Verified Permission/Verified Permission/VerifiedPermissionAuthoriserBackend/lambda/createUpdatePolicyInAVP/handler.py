import os
import sys
import json
import boto3

if os.path.isdir("../../layers/dependencies/python"):
    sys.path.append("../../layers/dependencies/python")

import utility

# Initialize the AWS Verified Permissions client
vp_client = boto3.client("verifiedpermissions")

POLICY_STORE_ID = ""


def list_existing_policies(policy_store_id):
    response = vp_client.list_policies(policyStoreId=policy_store_id)
    print(response)
    return response.get("policies", [])


def update_policy(policy_store_id, policy_id, policy_statement):
    print("Update")
    print(policy_statement)
    vp_client.update_policy(
        policyStoreId=policy_store_id,
        policyId=policy_id,
        definition={
            "static": {"description": "Updated policy", "statement": policy_statement}
        },
    )


def create_new_policy(policy_store_id, policy_statement):
    print("New")
    print(policy_statement)
    vp_client.create_policy(
        policyStoreId=policy_store_id,
        definition={
            "static": {"description": "New policy", "statement": policy_statement}
        },
    )


def lambda_handler(event, context):
    # print(event)
    POLICY_STORE_ID = os.environ["POLICY_STORE_ID"]
    try:
        body= event.get("body")
        body = json.loads(body)
        project_name = body["project_name"]
        print(project_name)
        user_id = body["user_id"]
        swagger_content = json.loads(body["swagger_content"])
        print(swagger_content)

        default_stage = swagger_content["servers"][0]["variables"]["basePath"]["default"]
        base_url = swagger_content["servers"][0]["url"].replace("{basePath}", default_stage)
        paths = swagger_content["paths"]

        # Fetch existing policies
        existing_policies = list_existing_policies(POLICY_STORE_ID)

        # Dictionary to track actions for each group
        group_actions = {}

        for path, methods in paths.items():
            for method, details in methods.items():
                if "x-group-attached" in details:
                    for group in details["x-group-attached"]:
                        action = f'"{method.upper()} {path} {details["operationId"]}"'
                        if group not in group_actions:
                            group_actions[group] = []
                        group_actions[group].append(action)

        for group, actions in group_actions.items():
            policy_statement = f"""
            permit(
              principal == VERIFIED_AUTHORIZER::Group::"{group}",
              action in [{', '.join([f'VERIFIED_AUTHORIZER::Action::{action}' for action in actions])}],
              resource == VERIFIED_AUTHORIZER::Endpoint::"{base_url}"
            );
            """
            updated = False

            for policy in existing_policies:
                principal = policy.get("principal", {})
                resource = policy.get("resource", {})
                if (
                    principal.get("entityType") == "VERIFIED_AUTHORIZER::Group"
                    and principal.get("entityId") == group
                    and resource.get("entityType") == "VERIFIED_AUTHORIZER::Endpoint"
                    and resource.get("entityId") == base_url
                ):

                    # Extract existing actions from the policy statement
                    existing_statement = policy["definition"]["static"].get(
                        "statement", ""
                    )
                    existing_actions = []
                    if "action in [" in existing_statement:
                        existing_actions = (
                            existing_statement.split("action in [")[1]
                            .split("],")[0]
                            .replace("VERIFIED_AUTHORIZER::Action::", "")
                            .replace('"', "")
                            .split(", ")
                        )

                    # Merge actions if policy already exists
                    new_actions = set(existing_actions).union(set(actions))
                    updated_policy_statement = f"""
                    permit(
                      principal == VERIFIED_AUTHORIZER::Group::"{group}",
                      action in [{', '.join([f'VERIFIED_AUTHORIZER::Action::{action}' for action in new_actions])}],
                      resource == VERIFIED_AUTHORIZER::Endpoint::"{base_url}"
                    );
                    """
                    update_policy(
                        POLICY_STORE_ID, policy["policyId"], updated_policy_statement
                    )
                    updated = True
                    break

            if not updated:
                create_new_policy(POLICY_STORE_ID, policy_statement)

        return utility.success_response("PolicyUpdated")
    except Exception as e:
        return utility.error_response(500, f"Error fetching data: {str(e)}")