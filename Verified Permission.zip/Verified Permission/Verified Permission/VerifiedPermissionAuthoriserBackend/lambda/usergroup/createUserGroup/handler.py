import os
import sys

if os.path.isdir("../../../layers/dependencies/python"):
    sys.path.append("../../../layers/dependencies/python")

import utility
import json
import boto3
import pymysql

def lambda_handler(event, context):
    try:
        # Establish connection to RDS
        conn = utility.getRDSConnection(os.environ['SECRET_MANAGER'])
    except Exception as e:
        print(e)
        sys.exit()
        return utility.error_response(500, "Internal Server Error")

    try:
        print(event)
        body_data = json.loads(event['body'])
        group_id = body_data['group_id']
        user_id = user_id = body_data['user_id']

        if not group_id or not user_id:
            error_message = "group_id and user_id are required"
            return utility.error_response(400, error_message)

        with conn.cursor() as cursor:
            # Insert the new usergroup entry
            sql = "INSERT INTO user_group (group_id_fk, user_id_fk) VALUES (%s, %s)"
            cursor.execute(sql, (group_id, user_id))
            conn.commit()
    except Exception as e:
        print(f"Error inserting item: {e}")
        return utility.error_response(500, f"Error inserting item: {str(e)}")
    finally:
        conn.close()

    return utility.success_response("Item added successfully")

