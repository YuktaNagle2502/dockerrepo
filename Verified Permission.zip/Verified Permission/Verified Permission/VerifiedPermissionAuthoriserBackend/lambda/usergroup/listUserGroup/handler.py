import os
import sys

if os.path.isdir("../../../layers/dependencies/python"):
    sys.path.append("../../../layers/dependencies/python")

import json
import boto3
import pymysql
import utility
 
def lambda_handler(event, context):
    try:
        # Establish connection to RDS
        conn = utility.getRDSConnection(os.environ['SECRET_MANAGER'])
    except Exception as e:
        print(e)
        sys.exit()
        return utility.error_response(500,"Internal Server Error")
    try:
        with conn.cursor() as cursor:
            # Fetch users and their groups
            sql_users = """
            SELECT u.user_id, u.user_name, u.user_email, g.group_id
            FROM users u
            LEFT JOIN user_group ug ON u.user_id = ug.user_id_fk
            LEFT JOIN `groups` g ON ug.group_id_fk = g.group_id
            """
            cursor.execute(sql_users)
            user_rows = cursor.fetchall()
 
            # Fetch all groups
            sql_groups = "SELECT group_id, group_name FROM `groups`"
            cursor.execute(sql_groups)
            group_rows = cursor.fetchall()
 
            # Process user data
            users = {}
            for row in user_rows:
                user_id = row['user_id']
                user_name = row['user_name']
                user_email = row['user_email']
                group_id = row['group_id']
                
                if user_id not in users:
                    users[user_id] = {
                        "userId": user_id,
                        "userName": user_email,
                        "Groups": []
                    }
                if group_id:
                    users[user_id]["Groups"].append(group_id)
 
            # Convert users to list
            user_list = list(users.values())
 
            # Process group data
            groups = []
            for row in group_rows:
                group_id = row['group_id']
                group_name = row['group_name']
                groups.append({
                    "groupId": group_id,
                    "groupName": group_name
                })
 
    except Exception as e:
        return utility.error_response(500, f"Error fetching data: {str(e)}")
    finally:
        conn.close()
    print("User",user_list)
    return utility.success_response({"Users":user_list,"groups":groups})