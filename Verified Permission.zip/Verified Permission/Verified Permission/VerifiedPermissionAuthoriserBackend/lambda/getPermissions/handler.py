import boto3
import json
import os

def lambda_handler(event, context):
    vp_client = boto3.client('verifiedpermissions')

    policyStoreId = os.environ['policyStoreId']
    principalEntityId =  event['queryStringParameters']['principalEntityId']
    # List policies
    policy_response = vp_client.list_policies(
        policyStoreId=policyStoreId,
        filter={
            'principal': {
                'identifier': {
                    'entityType': 'VERIFIED_PERMISSIONS::Group',
                    'entityId': principalEntityId
                }
            },
            'policyType': 'STATIC'
        }
    )
    policies = policy_response.get('policies', [])
    requests = []
    # Fetch detailed policy info and construct requests
    for policy_summary in policies:
        policy_id = policy_summary['policyId']
        detailed_policy_response = vp_client.get_policy(
            policyStoreId=policyStoreId,
            policyId=policy_id
        )
        existing_statement = detailed_policy_response["definition"]["static"].get("statement", "")
        if "action in [" in existing_statement:
            existing_actions = existing_statement.split('action in [')[1].split('],')[0].replace('VERIFIED_PERMISSIONS::Action::', '').replace('"', '').split(', ')
            existing_actions = existing_actions[0].split(',')
        resource = detailed_policy_response['resource']['entityId']
        request = {
            'action': existing_actions,
            'resource': {
                'entityId': resource
            }
        }
        requests.append(request)
   

    return {
        'statusCode': 200,
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "OPTIONS,GET"
        },
        'body': json.dumps(requests)
    }
