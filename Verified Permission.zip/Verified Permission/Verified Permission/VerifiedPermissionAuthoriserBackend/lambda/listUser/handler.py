import os
import sys

if os.path.isdir("../../layers/dependencies/python"):
    sys.path.append("../../layers/dependencies/python")

import utility
import json

def lambda_handler(event, context):
    try:
        user_id = event['pathParameters']['id']
        # Establish connection to RDS
        conn = utility.getRDSConnection(os.environ['SECRET_MANAGER'])
    except Exception as e:
        print(e)
        sys.exit()
        return utility.error_response(500, "Internal Server Error")

    try:
        with conn.cursor() as cursor:
            # Fetch all users
            sql_users = "SELECT user_name, user_id, user_email, user_type FROM `users` WHERE user_id = %s"
            cursor.execute(sql_users, user_id)
            user_rows = cursor.fetchall()
    except Exception as e:
        return utility.error_response(500, f"Error fetching data: {str(e)}")
    finally:
        conn.close()

    return utility.success_response(user_rows)
