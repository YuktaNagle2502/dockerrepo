export default (dependencies) => async (event) => {
    console.log("event :- ", event);
    let receiveEvent;
    try {
        receiveEvent = JSON.parse(event.body);
    } catch (error) {
        console.error("Error parsing event body:", error);
        return dependencies.utility.errorResponse(400, "Invalid JSON format");
    }
    if (receiveEvent.group_id) {
        let connection;
        try {
            connection = await dependencies.utility.getRDSConnection(process.env.SECRET_MANAGER);
            await connection.execute("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
            await connection.beginTransaction();
            const deleteGroupResult = await deleteGroup(receiveEvent.group_id, connection);
            console.log("Delete Group Result:", deleteGroupResult);
            await connection.commit();
            return dependencies.utility.successResponse("Group Deleted Successfully");
        } catch (error) {
            if (connection) {
                await connection.rollback();
            }
            console.error("Error during database operation:", error);
            return dependencies.utility.errorResponse(500, "Internal Server Error");
        } finally {
            if (connection) {
                await connection.close();
            }
        }
    } else {
        return dependencies.utility.errorResponse(400, "Group ID not provided");
    }
};
const deleteGroup = async (groupId, connection) => {
    console.log("Deleting group with ID:", groupId);
    try {
        await connection.execute(
            "DELETE FROM `user_group` WHERE group_id_fk='" + groupId + "'"
        );
        const [result] = await connection.execute(
              "DELETE FROM `groups` WHERE group_id='" + groupId + "'"
        );
        return result;
    } catch (error) {
        console.error("Error deleting group:", error);
        throw error;
    }
};