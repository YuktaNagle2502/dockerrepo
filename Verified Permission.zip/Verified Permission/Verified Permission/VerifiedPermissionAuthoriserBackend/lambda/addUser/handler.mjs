import { CognitoIdentityProviderClient, AdminCreateUserCommand } from "@aws-sdk/client-cognito-identity-provider";
const cognito = new CognitoIdentityProviderClient({ region: "us-east-2" });
export default (dependencies) => async (event) => {
 console.log(event)
 let connection;
 try {
   const body = JSON.parse(event.body);
   const { user_name, user_email, user_type, group_id } = body;
   if (!user_name || !user_email || !user_type) {
     return {
       statusCode: 400,
       body: JSON.stringify({ message: 'Username, email, and user type are required' }),
     };
   }
   // Create user in Cognito  
   const params = {
     UserPoolId: 'us-east-2_lBqCdI9Wy',
     Username: user_name,
     UserAttributes: [
       { Name: 'name', Value: user_name },
       { Name: 'email', Value: user_email },
       { Name: 'email_verified', Value: 'true' }
     ]
   };
   const command = new AdminCreateUserCommand(params);
   const cognitoResponse = await cognito.send(command);
   const userId = cognitoResponse.User.Username;
   // Insert user into RDS
   connection = await dependencies.utility.getRDSConnection(process.env.SECRET_MANAGER);
   await insertUserToRDS( connection,userId, user_name, user_email, user_type, group_id);
   return  dependencies.utility.successResponse(userId);
 } catch (error) {
   console.error('Error:', error);
   return dependencies.utility.errorResponse(500, error.message);
 } finally {
   if (connection) {
     await connection.end();
   }
 }
};
 
async function insertUserToRDS( connection, userId, user_name, user_email, user_type, group_id) {
 try {
   const [rows] = await connection.execute(
     'INSERT INTO users (user_id, user_name, user_email, user_type) VALUES (?, ?, ?, ?)',
     [userId, user_name, user_email, user_type]
   );
   const [userGroup] = await connection.execute(
     'INSERT INTO user_group (user_id_fk, group_id_fk) VALUES (?, ?)',
     [userId, group_id]
   );
   await connection.end();
   return rows;
 } catch (error) {
   console.error('Error inserting user to RDS:', error);
   throw error;
 }
}