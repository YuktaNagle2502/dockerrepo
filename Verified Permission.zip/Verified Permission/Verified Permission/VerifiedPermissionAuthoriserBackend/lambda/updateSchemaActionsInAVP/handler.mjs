import { VerifiedPermissionsClient, GetSchemaCommand, PutSchemaCommand } from "@aws-sdk/client-verifiedpermissions";

const client = new VerifiedPermissionsClient({ region: process.env.AWS_REGION });

export default dependencies => async (event) => {
    try {
        const finalResult = event;
        const { swagger_content } = event;
        var result = event.swagger_content;
        console.log("Swagger Content", swagger_content);

        const appName = "VERIFIED_AUTHORIZER";
        const policy_store_id = process.env.AWS_POLICY_STORE_ID;
        const swaggerContent = JSON.parse(swagger_content);

        // Extract HTTP methods and endpoints from Swagger
        const newActions = extractActionsFromSwagger(swaggerContent);
        console.log("New Actions: ", JSON.stringify(newActions, null, 2));

        // Fetch existing schema from AWS Verified Permissions
        const existingSchema = await fetchExistingSchema(policy_store_id);
        console.log("Existing Schema: ", existingSchema);

        // Update the schema with the new actions
        const updatedSchema = updateSchema(existingSchema, newActions, appName);
        console.log("Updated Schema: ", JSON.stringify(updatedSchema, null, 2));

        // Update the policy store with the updated schema
        const response = await putSchema(policy_store_id, updatedSchema);

        const statusCode = response.$metadata.httpStatusCode;

        if (statusCode == 200) {
            return dependencies.utility.successResponse(finalResult);
        } else if (statusCode == 400) {
            return Error("Failed to update schema: ", response.$metadata.error);
        }
    } catch (error) {
        console.log("Failed to update schema:");
        return error;
    }
};

function extractActionsFromSwagger(swaggerContent) {
    const actions = {};
    const paths = swaggerContent.paths;

    for (const path in paths) {
        for (const method in paths[path]) {
            const methodDetails = paths[path][method];

            if (methodDetails['x-group-attached']) {
                const operationId = methodDetails.operationId || "UNKNOWN_OPERATION_ID"; // We will use a default value if operationId is missing
                const actionKey = `${method.toUpperCase()} ${path} ${operationId}`;
                actions[actionKey] = {
                    appliesTo: {
                        principalTypes: ["Group"],
                        resourceTypes: ["Endpoint"]
                    }
                };
            }
        }
    }
    return actions;
}

async function fetchExistingSchema(policyStoreId) {
    try {
        const command = new GetSchemaCommand({ policyStoreId: policyStoreId });
        const response = await client.send(command);
        return response.schema;
    } catch (error) {
        if (error.name === 'ResourceNotFoundException') {
            return {}; // Return an empty object if schema does not exist
        }
        throw new Error(`Failed to fetch existing schema: ${error.message}`);
    }
}

function updateSchema(existingSchema, newActions, appName) {
    console.log("Schema.....", existingSchema, appName);
    const parsedExistingSchema = JSON.parse(existingSchema);
    const existingAppSchema = parsedExistingSchema[appName];
    const existingEntityTypes = existingAppSchema.entityTypes || {};
    console.log("Existing Entities", existingEntityTypes);

    const existingActions = existingAppSchema.actions || {};
    const updatedActions = { ...existingActions };

    for (const actionKey in newActions) {
        const newPrincipalTypes = newActions[actionKey].appliesTo.principalTypes;
        if (updatedActions[actionKey]) {
            // Merge principalTypes
            const existingPrincipalTypes = new Set(updatedActions[actionKey].appliesTo.principalTypes);
            newPrincipalTypes.forEach(group => existingPrincipalTypes.add(group));
            updatedActions[actionKey].appliesTo.principalTypes = Array.from(existingPrincipalTypes);
        } else {
            updatedActions[actionKey] = newActions[actionKey];
        }
    }

    const updatedSchema = {
        [appName]: {
            entityTypes: existingEntityTypes,
            actions: updatedActions
        }
    };
    return updatedSchema;
}

async function putSchema(policyStoreId, updatedSchema) {
    try {
        const input = {
            policyStoreId: policyStoreId,
            definition: {
                cedarJson: JSON.stringify(updatedSchema),
            },
        };
        console.log("Inside PUT SCHEMA COMMAND===", input);
        const command = new PutSchemaCommand(input);
        const response = await client.send(command);
        console.log("PutSchemaCommand Response: ", JSON.stringify(response, null, 2));
        return response;
    } catch (error) {
        return {
            "$metadata": {
                "httpStatusCode": 400,
                "attempts": 1,
                "error": error.message
            }
        }
    }
}