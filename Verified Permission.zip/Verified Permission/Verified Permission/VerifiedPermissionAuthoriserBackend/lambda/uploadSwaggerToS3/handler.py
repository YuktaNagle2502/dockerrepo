import os
import sys
 
if os.path.isdir("../../../layers/dependencies/python"):
    sys.path.append("../../../layers/dependencies/python")
 
import utility
import json
import boto3
import pymysql
s3_client = boto3.client('s3')
def lambda_handler(event, context):
    try:
        # Establish connection to RDS
        conn = utility.getRDSConnection(os.environ['SECRET_MANAGER'])
    except Exception as e:
        print(e)
        return utility.error_response(500, "Internal Server Error")
    try:
        project_name = event['project_name']
        user_id = event['user_id']
        swagger_content = event['swagger_content']  # Assuming swagger_content is passed as a JSON string
        # Creating the filename
        filename = f"{project_name}_{user_id}.json"
        # Get the bucket name from environment variables
        bucket_name = os.environ['S3_BUCKET_NAME']
        #bucket_name = "apicodegenbucket"
        # Store the file in S3
        s3_client.put_object(
            Bucket=bucket_name,
            Key=filename,
            Body=swagger_content,
            ContentType='application/json'
        )
        print('File uploaded successfully','filename', filename)
        # Insert project_name into projects table

        try:
           with conn.cursor() as cursor:
               select_query = "SELECT fk_project_id FROM user_project WHERE fk_project_id IN (SELECT project_id FROM projects WHERE project_name = %s) AND fk_user_id = %s"
               cursor.execute(select_query, (project_name,user_id))
               result= cursor.fetchall()
               if not result:
                     try:
                         with conn.cursor() as cursor:
                             insert_project_query = "INSERT INTO projects (project_name) VALUES (%s)"
                             cursor.execute(insert_project_query, (project_name,))
                             project_id= cursor.lastrowid
                             conn.commit()
                             print('Project name inserted into projects table')
                             insert_query = "INSERT INTO user_project (fk_user_id, fk_project_id) VALUES (%s, %s)"
                             cursor.execute(insert_query, (user_id,project_id))
                             conn.commit()
                             print('Project mapping inserted into table')
                             event['project_id'] = project_id
                             return event

                     except Exception as e:
                         return {
                             'statusCode': 500,
                             'body': json.dumps({'error': str(e)})
                         }  
               else:
                    print("Same projects")
                    project_id= result[0]['fk_project_id']
                    event['project_id'] = project_id
                    return event
        except KeyError as e:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': f'Missing key: {str(e)}'})
                }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
    finally:
        conn.close()