import { CognitoIdentityProviderClient, AdminDeleteUserCommand } from "@aws-sdk/client-cognito-identity-provider";
export default (dependencies) => async (event) => {
   console.log("event", event);
   if (event.body !== undefined && event.body !== null) {
       let connection;
       const userParams = JSON.parse(event.body);
       try {
           const params = {
               UserPoolId: process.env.USER_POOL_ID,
               Username: userParams['user_id'],
           };
           const cognitoClient = new CognitoIdentityProviderClient({});
           const command = new AdminDeleteUserCommand(params);
           await cognitoClient.send(command);
           console.log("User deleted success cognito");
           connection = await dependencies.utility.getRDSConnection(process.env.SECRET_MANAGER);
           await connection.execute("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
           const user_id = userParams['user_id'];
           await connection.beginTransaction();
           try {
               await deleteFromUserGroup(connection, user_id);
           } catch (error) {
               return dependencies.utility.errorResponse(500, "Internal Server Error");
           }
           try {
               await deleteFromUserProject(connection, user_id);
           } catch (error) {
               return dependencies.utility.errorResponse(500, "Internal Server Error");
           }
           try {
               await deleteFromUser(connection, user_id);
           } catch (error) {
               return dependencies.utility.errorResponse(500, "Internal Server Error");
           }
           await connection.commit();
           return dependencies.utility.successResponse("User Deleted Successfully");
       } catch (error) {
           console.log("error: ", error);
           return dependencies.utility.errorResponse(500, "Internal Server Error");
       } finally {
           if (connection) {
               await connection.close();
           }
       }
   } else {
       return dependencies.utility.errorResponse(400, "Invalid Data");
   }
};
const deleteFromUserGroup = async (connection, user_id) => {
   console.log("user_id", user_id);
   await connection.execute("DELETE FROM `user_group` WHERE user_id_fk='" + user_id + "'");
   console.log("exe");
};
const deleteFromUserProject = async (connection, user_id) => {
   console.log("user_id", user_id);
   await connection.execute("DELETE FROM `user_project` WHERE fk_user_id='" + user_id + "'");
   console.log("exe");
};
const deleteFromUser = async (connection, user_id) => {
   console.log("user_id", user_id);
   await connection.execute("DELETE FROM `users` WHERE user_id='" + user_id + "'");
   console.log("exe");
};