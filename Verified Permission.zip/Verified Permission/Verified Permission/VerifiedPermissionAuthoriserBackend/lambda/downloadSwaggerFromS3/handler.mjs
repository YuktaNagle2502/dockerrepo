import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
const s3Client = new S3Client({});

export default dependencies => async (event) => {
  try {
    const getSwagger = await getSwaggerFromS3(event);
    return dependencies.utility.successResponse(getSwagger);
  } catch (error) {
    return dependencies.utility.errorResponse(error);
  }
}

const getSwaggerFromS3 = async (event) => {
  try {
    const { project_name, user_id } = event.queryStringParameters;
    const bucketName = process.env.S3_BUCKET;
    const objectKey = `${project_name}_${user_id}.json`;

    const params = {
      Bucket: bucketName,
      Key: objectKey
    };

    const data = await s3Client.send(new GetObjectCommand(params));
    const swaggerData = await data.Body.transformToString();
    return JSON.parse(swaggerData);
  } catch (error) {
    throw error; 
  }
};