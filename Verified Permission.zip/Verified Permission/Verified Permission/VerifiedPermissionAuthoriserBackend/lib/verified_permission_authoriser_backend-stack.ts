import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import {AVPStack} from "./avp/avp-stack";
import { RDSStack } from './rds/rds-stack';
import { APIStack } from './apiGateway/api-stack';
import { S3Stack } from './s3/s3-stack';

export class VerifiedPermissionAuthoriserBackendStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const avp_stack = new AVPStack(this, "Verified-Permissions")
    const policy_store_id = avp_stack.nestedStackResource?.getAtt("PolicyStoreId").toString();
    const rds_stack = new RDSStack(this, "RDS Stack",{
      env:{
        account:'094853031708',
        region:'us-east-2'
      }
    });
    const api_stack = new APIStack(this, "API-Gateway-Verified-Permissions")
    const s3_stack = new S3Stack(this, "S3 Stack")

  }
}
