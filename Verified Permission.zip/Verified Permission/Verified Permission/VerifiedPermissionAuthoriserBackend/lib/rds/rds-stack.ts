import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { InstanceClass, InstanceSize, InstanceType,SubnetType, Vpc, Peer, Port, SecurityGroup} from 'aws-cdk-lib/aws-ec2';
import { Credentials, DatabaseInstance, DatabaseInstanceEngine, MysqlEngineVersion } from 'aws-cdk-lib/aws-rds';
import { Secret } from 'aws-cdk-lib/aws-secretsmanager';
import {data} from '../../config/cdk-config.json';
 
export class RDSStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const engine = DatabaseInstanceEngine.mysql({ version: MysqlEngineVersion.VER_8_0_35});
    const instanceType = InstanceType.of(InstanceClass.T3, InstanceSize.SMALL);
 

     // Create master user details
     const userSecret = new Secret(this, "db-user-credentials", {
        secretName: data.SecretName,
        description: "Database user creadentials",
        generateSecretString: {
          secretStringTemplate: JSON.stringify({ username: "admin" }),
          generateStringKey: "password",
          passwordLength: 16,
          excludePunctuation: true
        }
      });
      cdk.Tags.of(userSecret).add("Name", "AVP-Application")
  
      // VPC
      const cofigVPC = Vpc.fromLookup(this, "config-vpc", { vpcId: data.vpcId });

      const dbSecurityGroup = new SecurityGroup(this, "RDS-SG", {
        securityGroupName: "RDS-SG",
        vpc: cofigVPC
      });
      cdk.Tags.of(dbSecurityGroup).add("Name", "AVP-Application")
  
      // adding Inbound rule
      dbSecurityGroup.addIngressRule(
        Peer.ipv4('0.0.0.0/0'),
        Port.tcp(data.port),
        `Allow port ${data.port} for database connection form only within the VPC`
      );
  
      // Creating RDS instance
      const dbInstance = new DatabaseInstance(this, 'AVP-Application', {
        vpc: cofigVPC,
        vpcSubnets: { subnetType: SubnetType.PUBLIC },
        instanceType,
        engine,
        securityGroups: [dbSecurityGroup],
        databaseName: data.database,
        credentials: Credentials.fromSecret(userSecret)
      })
      cdk.Tags.of(dbInstance).add("Name", "AVP-Application")

  }
}


