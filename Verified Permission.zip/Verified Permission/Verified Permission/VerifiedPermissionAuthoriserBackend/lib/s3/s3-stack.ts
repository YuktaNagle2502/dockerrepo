import * as s3 from 'aws-cdk-lib/aws-s3'
import * as iam from 'aws-cdk-lib/aws-iam'
import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';

export class S3Stack extends cdk.Stack {
    static nestedStackResource: any;
    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
      super(scope, id, props);
try{
 
 
 // S3 Bucket for Swagger files
  const swaggerBucket = new s3.Bucket(this, 'swaggerBucket', {
    bucketName: 'swagger-uploads-avp-authoriser'
  });

  cdk.Tags.of(swaggerBucket).add("Name", "Verified Permissions Authoriser")
  cdk.Tags.of(swaggerBucket).add("Created By", "Hrishabh Gohiya")

  swaggerBucket.addToResourcePolicy(
    new iam.PolicyStatement({
      principals: [new iam.ServicePrincipal('lambda.amazonaws.com')],
      actions: [
        "s3:PutObject"
      ],
      effect: iam.Effect.ALLOW,
      resources: [`${swaggerBucket.bucketArn}/*`]
    })
  )
  new cdk.CfnOutput(this, "BucketName", {
        value: swaggerBucket.bucketName
    })
}
catch (error) {
    console.error('Error creating Verified Permissions resources:', error);
  }
}
}