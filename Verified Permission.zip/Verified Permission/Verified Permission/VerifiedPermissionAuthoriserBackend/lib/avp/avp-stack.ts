import * as verifiedpermissions from 'aws-cdk-lib/aws-verifiedpermissions';
import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';

export class AVPStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);
    try {
      const AvpPolicyStore = new verifiedpermissions.CfnPolicyStore(this, 'AvpPolicyStore', {
        validationSettings: {
          mode: 'STRICT',
        },
        description: "Verified Permission Authoriser",
        schema: {
          cedarJson: JSON.stringify({
            "VERIFIED_AUTHORIZER": {
              "actions": {},
              "entityTypes": {
                "Group": {
                  "shape": {
                    "type": "Record",
                    "attributes": {}
                  }
                },
                "Endpoint": {
                  "shape": {
                    "type": "Record",
                    "attributes": {}
                  }
                }
              }
            }
          })
        },
      });

      new cdk.CfnOutput(this, "policy-store", {
        value: AvpPolicyStore.attrPolicyStoreId
      })

      cdk.Tags.of(AvpPolicyStore).add("Name", "Verified Permission Policy Store")
      cdk.Tags.of(AvpPolicyStore).add("Created By", "Hrishabh Gohiya")
      cdk.Tags.of(AvpPolicyStore).add("Name", "Verified Permission Schmea")
      cdk.Tags.of(AvpPolicyStore).add("Created By", "Rajkuwar Chaudhari")

    } catch (error) {
      console.error('Error creating Verified Permissions resources:', error);
    }
  }
}