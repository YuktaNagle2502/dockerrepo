import * as apiGateway from 'aws-cdk-lib/aws-apigateway';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import {data} from '../../config/cdk-config.json';
import * as stepfunctions from 'aws-cdk-lib/aws-stepfunctions';
import * as tasks from 'aws-cdk-lib/aws-stepfunctions-tasks';
import { S3Stack } from '../s3/s3-stack';  

export class APIStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);
    const authorizerLambdaArn = 'arn:aws:lambda:us-east-2:094853031708:function:VerifiedPermissionAuthori-lambdaAuthorizer53896656-dIj8Df3vDvJo';
    
    const authorizerFunction = lambda.Function.fromFunctionArn(this, 'ImportedAuthorizerFunction', authorizerLambdaArn);
   
    const lambdaAuthorizer = new apiGateway.RequestAuthorizer(this, 'MyLambdaAuthorizer', {
      handler: authorizerFunction,
      identitySources: [apiGateway.IdentitySource.header('Authorization')],
   });
    const S3Policy = new iam.PolicyDocument({
      statements: [new iam.PolicyStatement({
        actions: [
          "s3:putObject",
          "s3:getObject"
        ],
        effect: iam.Effect.ALLOW,
        resources: ["*"]
      })]
    })
    const SecretManager_Readonly = new iam.PolicyDocument({
      statements: [new iam.PolicyStatement({
        actions: [
          "secretsmanager:GetRandomPassword",
          "secretsmanager:GetResourcePolicy",
          "secretsmanager:GetSecretValue",
          "secretsmanager:DescribeSecret",
          "secretsmanager:ListSecretVersionIds",
          "secretsmanager:ListSecrets"
        ],
        effect: iam.Effect.ALLOW,
        resources: ["*"]
      })]
    })
  const lambdaRole = new iam.Role(this, "lambdaRole", {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      roleName: "LambdaRoleForRDSAccess",
      inlinePolicies: {
        S3Policy: S3Policy,
        SecretManager_Readonly: SecretManager_Readonly,
      },
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonCognitoPowerUser'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonRDSDataFullAccess')
      ],
    })


  // Attach policies to the role
  // Policy for logging
  lambdaRole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'));
  // Policy for accessing Secrets Manager
  lambdaRole.addToPolicy(new iam.PolicyStatement({
    effect: iam.Effect.ALLOW,
    actions: [
      'secretsmanager:GetSecretValue',
    ],
    resources: [
      secretsmanager.Secret.fromSecretNameV2(this, 'Secret', 'your-secret-name').secretArn,
    ],
  }));
  // Policy for Verified Permissions access
  lambdaRole.addToPolicy(new iam.PolicyStatement({
    effect: iam.Effect.ALLOW,
    actions: [
      'verifiedpermissions:GetSchema',
      'verifiedpermissions:PutSchema',
      "verifiedpermissions:CreatePolicy",
      "verifiedpermissions:IsAuthorized",
      "verifiedpermissions:GetPolicy"
    ],
    resources: [
      `arn:aws:verifiedpermissions:${cdk.Aws.REGION}:${cdk.Aws.ACCOUNT_ID}:policystore/*`,
    ],
  }));
  lambdaRole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName("AmazonRDSDataFullAccess"))
  lambdaRole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName("CloudWatchFullAccess"))
  lambdaRole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName("AWSLambdaExecute"))

      const dependenciesLayer = new lambda.LayerVersion(this, 'dependencies-layer', {
        compatibleRuntimes: [
          lambda.Runtime.NODEJS_18_X,
        ],
        code: lambda.Code.fromAsset('layers/dependencies'),
        description: 'Uses a 3rd party libraries',
      });
      
      const commonFunctionLayer = new lambda.LayerVersion(this, 'common-function-layer', {
        compatibleRuntimes: [
          lambda.Runtime.NODEJS_18_X
        ],
        code: lambda.Code.fromAsset('layers/common-functions'),
        description: 'Uses common function within the application',
      });
  
      cdk.Tags.of(commonFunctionLayer).add("Name", "Verfied-Permission-Application")

      const global = {
        runtime: lambda.Runtime.NODEJS_18_X,
        handler: 'index.handler',
        timeout: cdk.Duration.seconds(25),
        layers: [dependenciesLayer, commonFunctionLayer],
        environment: {
          LD_LIBRARY_PATH: "/opt:$LD_LIBRARY_PATH",
          SECRET_MANAGER: data.SecretName,
          USER_POOL_ID: data.UserPoolId
        }
      }    

       const api_gateway = new apiGateway.RestApi(this, 'VerfiedPermissionAuthoriserApiGateWay',{
        restApiName: "VerfiedPermissionAuthoriser",
        defaultCorsPreflightOptions: {
          allowHeaders: [
            'Content-Type',
            'X-Amz-Date',
            'Authorization',
            'X-Api-Key',
          ],
          allowMethods: ['OPTIONS', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
          allowOrigins: ['*'],
        }
      });
      cdk.Tags.of(api_gateway).add("Name", "VerfiedPermissionAuthoriserApiGateWay")
      

      const downloadS3 = api_gateway.root.addResource("download-swagger")
    const downloadSwaggerFromS3 = new lambda.Function(this, 'downloadSwaggerFromS3', {
      functionName: "downloadSwaggerFromS3",
      runtime: lambda.Runtime.NODEJS_18_X,
      code: lambda.Code.fromAsset('./lambda/downloadSwaggerFromS3'),
      handler: 'index.handler',
      role: lambdaRole,
      layers: [dependenciesLayer,commonFunctionLayer],
      environment: {
        S3_BUCKET: data.bucket_name
      }
    });
     
    
    downloadS3.addMethod(
      "GET",
      new apiGateway.LambdaIntegration(downloadSwaggerFromS3), {

        operationName: 'downloadSwagger',
  
      }
    );
    cdk.Tags.of(api_gateway).add(
      "Name",
      "VerfiedPermissionAuthoriserApiGateWay"
    );

    const pythonDependenciesLayer = new lambda.LayerVersion(
      this,
      "PythonDependenciesLayer",
      {
        compatibleRuntimes: [lambda.Runtime.PYTHON_3_10],
        code: lambda.Code.fromAsset("layers/dependencies"),
        description: "Python dependencies",
      }
    );
  


    const manageGroup = api_gateway.root.addResource("groups")
    const putGroupsRdsLambda = new lambda.Function(this, 'putGroupsRdsLambda', {
      ...{
       runtime: lambda.Runtime.NODEJS_18_X,
      code: lambda.Code.fromAsset('lambda/addGroup'),
      role: lambdaRole,
      handler: 'index.handler',
     }, ...global
    });

    const manageUser = api_gateway.root.addResource("users")
    const addUserLambda = new lambda.Function(this, 'addUserLambda', {
      ...{
       runtime: lambda.Runtime.NODEJS_18_X,
      code: lambda.Code.fromAsset('lambda/addUser'),
      role: lambdaRole,
      handler: 'index.handler',
     }, ...global
    });


    const listGroupsLambda = new lambda.Function(this, 'listGroupsLambda', {
      runtime: lambda.Runtime.PYTHON_3_10,
      code: lambda.Code.fromAsset('lambda/listGroup'),
      handler: 'handler.lambda_handler',
      layers: [pythonDependenciesLayer],
      role: lambdaRole,
      environment:{
        SECRET_MANAGER: "avp/mysql/secretDb"
      }
    });

    //delete group lambda
    const deleteGroupLambda = new lambda.Function(this, 'deleteGroupLambda', {
      ...{
       runtime: lambda.Runtime.NODEJS_18_X,
      code: lambda.Code.fromAsset('lambda/deleteGroup'),
      role: lambdaRole,
      handler: 'index.handler',
     }, ...global
    });
    
    const listUsersLambda = new lambda.Function(this, 'listUsersLambda', {
      runtime: lambda.Runtime.PYTHON_3_10,
      code: lambda.Code.fromAsset('lambda/listUsers'),
      handler: 'handler.lambda_handler',
      layers: [pythonDependenciesLayer],
      role: lambdaRole,
      environment:{
        SECRET_MANAGER: "avp/mysql/secretDb"
      }
    });

    const deleteUserLambda = new lambda.Function(this, 'deleteUserLambda', {
      ...{
        runtime: lambda.Runtime.NODEJS_18_X,
       code: lambda.Code.fromAsset('lambda/deleteUser'),
       role: lambdaRole,
       handler: 'index.handler',
      }, ...global
    });

    const listUserLambda = new lambda.Function(this, 'listUserLambda', {
      runtime: lambda.Runtime.PYTHON_3_10,
      code: lambda.Code.fromAsset('lambda/listUser'),
      handler: 'handler.lambda_handler',
      layers: [pythonDependenciesLayer],
      role: lambdaRole,
      environment:{
        SECRET_MANAGER: "avp/mysql/secretDb"
      }
    });

    manageGroup.addMethod("POST",new apiGateway.LambdaIntegration(putGroupsRdsLambda), {

      operationName: 'CreateGroups',
      authorizer: lambdaAuthorizer,
      authorizationType: apiGateway.AuthorizationType.CUSTOM,

    })
    manageGroup.addMethod("GET",new apiGateway.LambdaIntegration(listGroupsLambda), {

      operationName: 'GetGroups',
      authorizer: lambdaAuthorizer,
      authorizationType: apiGateway.AuthorizationType.CUSTOM,

    })
    manageGroup.addMethod("DELETE",new apiGateway.LambdaIntegration(deleteGroupLambda), {

      operationName: 'DeleteGroups',
      authorizer: lambdaAuthorizer,
      authorizationType: apiGateway.AuthorizationType.CUSTOM,

    })
    manageUser.addMethod("POST",new apiGateway.LambdaIntegration(addUserLambda), {

      operationName: 'CreateUsers',
      authorizer: lambdaAuthorizer,
      authorizationType: apiGateway.AuthorizationType.CUSTOM,

    })
    manageUser.addMethod("GET",new apiGateway.LambdaIntegration(listUsersLambda), {

      operationName: 'GetUsers',
      authorizer: lambdaAuthorizer,
      authorizationType: apiGateway.AuthorizationType.CUSTOM,

    })
    manageUser.addMethod("DELETE",new apiGateway.LambdaIntegration(deleteUserLambda), {

      operationName: 'DeleteUsers',
      authorizer: lambdaAuthorizer,
      authorizationType: apiGateway.AuthorizationType.CUSTOM,

    })

    
    const getUser = api_gateway.root.addResource('user');
    const userId = getUser.addResource('{id}');
    userId.addMethod('GET', new apiGateway.LambdaIntegration(listUserLambda), {

      operationName: 'GetUserById',
      authorizer: lambdaAuthorizer,
      authorizationType: apiGateway.AuthorizationType.CUSTOM,

    });
    
    
    // Upload Swagger to S3 Lambda Lambda (Python)
    const uploadToS3Lambda = new lambda.Function(this, 'uploadSwaggerToS3', {
      functionName: "uploadToS3Lambda",
      runtime: lambda.Runtime.PYTHON_3_10,
      code: lambda.Code.fromAsset('./lambda/uploadSwaggerToS3'),
      handler: 'handler.lambda_handler',
      role:lambdaRole,
      layers: [pythonDependenciesLayer],
      environment: {
        S3_BUCKET_NAME: data.bucket_name,
        SECRET_MANAGER: "avp/mysql/secretDb"
      }
    });
    

    // Second Lambda (Node.js)
    const updateSchemaInAVP = new lambda.Function(this, 'SecondLambda', {
      functionName: "updateSchemaInAVP",
      runtime: lambda.Runtime.NODEJS_18_X,
      code: lambda.Code.fromAsset('lambda/updateSchemaActionsInAVP'),
      handler: 'index.handler',
      role:lambdaRole,
      layers: [dependenciesLayer,commonFunctionLayer],
      environment:{
        S3_BUCKET_NAME : data.bucket_name,
        AWS_POLICY_STORE_ID: data.policy_store_id
      }
    });

    // Third Lambda (Python)
    const updateActionInAVP = new lambda.Function(this, 'ThirdLambda', {
      functionName: "updateActionInAVP",
      runtime: lambda.Runtime.PYTHON_3_10,
      code: lambda.Code.fromAsset('lambda/createUpdatePolicyInAVP'),
      handler: 'handler.lambda_handler',
      role:lambdaRole,
      layers: [pythonDependenciesLayer],
      environment: {
        SECRET_MANAGER: data.SecretName,
        POLICY_STORE_ID: data.policy_store_id
      }
    });

    const createDbTables = new lambda.Function(this, 'createDbTables', {
      functionName: "create-db-tables",
      runtime: lambda.Runtime.NODEJS_18_X,
      code: lambda.Code.fromAsset('lambda/db-tables/create-tables'),
      handler: 'index.handler',
      role: lambdaRole,
      layers: [dependenciesLayer,commonFunctionLayer],
      environment: {
        LD_LIBRARY_PATH: "/opt:$LD_LIBRARY_PATH",
        SECRET_MANAGER: data.SecretName
      }
    });

    // Step Function tasks
    const firstLambdaTask = new tasks.LambdaInvoke(
      this,
      "Upload Swagger to S3",
      {
        lambdaFunction: uploadToS3Lambda,
        outputPath: "$.Payload",
      }
    );

    const secondLambdaTask = new tasks.LambdaInvoke(
      this,
      "Create Schema in AWS Verified Permissions",
      {
        lambdaFunction: updateSchemaInAVP,
        outputPath: "$.Payload",
      }
    );

    const thirdLambdaTask = new tasks.LambdaInvoke(
      this,
      "Create Policies in AWS Verified Permissions",
      {
        lambdaFunction: updateActionInAVP,
        outputPath: "$.Payload",
      }
    );

    // Define Step Function workflow
    const definition = stepfunctions.Chain.start(firstLambdaTask)
      .next(secondLambdaTask)
      .next(thirdLambdaTask);

    //const chain = new stepfunctions.Pass(this, 'StartState');

    const stateMachine = new stepfunctions.StateMachine(this, "StateMachine", {
      definitionBody: stepfunctions.DefinitionBody.fromChainable(definition),
      timeout: cdk.Duration.minutes(5),
    });

    // Define a custom empty model
    const emptyModel = api_gateway.addModel("EmptyModel", {
      contentType: "application/json",
      schema: {
        schema: apiGateway.JsonSchemaVersion.DRAFT4,
        title: "EmptySchema",
        type: apiGateway.JsonSchemaType.OBJECT,
      },
    });

    const apiGatewayStepFunctionExecutionPolicy = new iam.PolicyDocument({
      statements: [new iam.PolicyStatement({
        actions: [
          'states:StartExecution',
          'states:DescribeExecution'
        ],
        effect: iam.Effect.ALLOW,
        resources: ['*']
      })]
    })

    // API Gateway integration with Step Function
    const startStepFunctionIntegration = new apiGateway.AwsIntegration({
      service: "states",
      action: "StartExecution",
      options: {
        credentialsRole: new iam.Role(this, "StepFunnctionStartExecutionRole", {
          roleName: "StepFunctionStack-StartAndFetchDetailsLambdaServiceRole",
          assumedBy: new iam.ServicePrincipal('apigateway.amazonaws.com'),
          inlinePolicies: {
            StartExceutionPolicy : apiGatewayStepFunctionExecutionPolicy 
          }
        }),
        requestTemplates: {
          "application/json": JSON.stringify({
            input: "$util.escapeJavaScript($input.json('$'))",
            stateMachineArn: stateMachine.stateMachineArn,
          }),
        },
        integrationResponses: [
          {
            statusCode: "200",
            responseTemplates: {
              "application/json": "",
            },
          },
        ],
      },
    });

    api_gateway.root
      .addResource("start-workflow")
      .addMethod("POST", startStepFunctionIntegration, {
        operationName: "start-workflow",
        authorizer: lambdaAuthorizer,
        authorizationType: apiGateway.AuthorizationType.CUSTOM,
        methodResponses: [
          {
            statusCode: "200",
            responseModels: {
              "application/json": emptyModel,
            },
          },
        ],
      });

      const createUserGroup = api_gateway.root.addResource("create-user-group")
      const createUserGroupLambda = new lambda.Function(this, 'createUserGroupLambda', {
        runtime: lambda.Runtime.PYTHON_3_10,
        code: lambda.Code.fromAsset('lambda/usergroup/createUserGroup'),
        handler: 'handler.lambda_handler',
        layers: [pythonDependenciesLayer],
        role: lambdaRole,
        environment:{
          SECRET_MANAGER: data.SecretName
        }
      });
  
      const listUserGroupLambda = new lambda.Function(this, 'listUserGroupLambda', {
        runtime: lambda.Runtime.PYTHON_3_10,
        code: lambda.Code.fromAsset('lambda/usergroup/listUserGroup'),
        handler: 'handler.lambda_handler',
        layers: [pythonDependenciesLayer],
        role: lambdaRole,
        environment:{
          SECRET_MANAGER: data.SecretName
        }
      });
  
      const deleteUserGroupLambda = new lambda.Function(this, 'deleteUserGroupLambda', {
        runtime: lambda.Runtime.PYTHON_3_10,
        code: lambda.Code.fromAsset('lambda/usergroup/deleteUserGroup'),
        handler: 'handler.lambda_handler',
        layers: [pythonDependenciesLayer],
        role: lambdaRole,
        environment:{
          SECRET_MANAGER: data.SecretName
        }
      });
      
      createUserGroup.addMethod("POST",new apiGateway.LambdaIntegration(createUserGroupLambda), {

        operationName: 'CreateUserGroup',
        authorizer: lambdaAuthorizer,
        authorizationType: apiGateway.AuthorizationType.CUSTOM,
  
      })
      createUserGroup.addMethod("GET",new apiGateway.LambdaIntegration(listUserGroupLambda), {

        operationName: 'GetUserGroup',
        authorizer: lambdaAuthorizer,
        authorizationType: apiGateway.AuthorizationType.CUSTOM,
  
      })
      createUserGroup.addMethod("PUT",new apiGateway.LambdaIntegration(deleteUserGroupLambda), {

        operationName: 'UpdateUserGroup',
        authorizer: lambdaAuthorizer,
        authorizationType: apiGateway.AuthorizationType.CUSTOM,
  
      })
  
      const listProjects = api_gateway.root.addResource("list-projects")
      const listUserProjectsLambda = new lambda.Function(this, 'listUserProjectLambda', {
        functionName:"listProjects",
        runtime: lambda.Runtime.NODEJS_18_X,
        code: lambda.Code.fromAsset('lambda/listProjects'),
        handler: 'index.handler',
        layers: [dependenciesLayer,commonFunctionLayer],
        role: lambdaRole,
        environment:{
          SECRET_MANAGER: data.SecretName,
          LD_LIBRARY_PATH: data.LD_LIBRARY_PATH,
        }
      });
      listProjects.addMethod("GET", new apiGateway.LambdaIntegration(listUserProjectsLambda), {

        operationName: 'GetProjects',
        authorizer: lambdaAuthorizer,
        authorizationType: apiGateway.AuthorizationType.CUSTOM,
  
      })

      const getPermissions = api_gateway.root.addResource("get-permissions")
      const getPermissionsLambda = new lambda.Function(this, 'getPermissionsLambda', {
        functionName:"get-permissions",
        runtime: lambda.Runtime.PYTHON_3_10,
        code: lambda.Code.fromAsset('lambda/getPermissions'),
        handler: 'handler.lambda_handler',
        layers: [pythonDependenciesLayer],
        role: lambdaRole,
        environment:{
          POLICY_STORE_ID: data.policy_store_id
        }
      });
      getPermissions.addMethod("GET", new apiGateway.LambdaIntegration(getPermissionsLambda), {

        operationName: 'GetPermissions',
        authorizer: lambdaAuthorizer,
        authorizationType: apiGateway.AuthorizationType.CUSTOM,
  
      })
    }

}
