import unittest
from unittest.mock import patch, MagicMock
import json
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lambda', 'usergroup', 'createUserGroup')))

from handler import lambda_handler

class TestLambdaHandler(unittest.TestCase):
    @patch('os.environ', {'SECRET_MANAGER': 'mocked_secret_manager_value'})
    @patch('utility.getRDSConnection')
    @patch('utility.success_response')
    def test_lambda_handler_success(self, mock_success_response, mock_get_rds_connection):
        
        mock_conn = MagicMock()
        mock_cursor = mock_conn.cursor().__enter__()
        mock_get_rds_connection.return_value = mock_conn
        event = {
        'body': json.dumps({'group_id': 'group1', 'user_id': 'user1'})
        }

        response = lambda_handler(event, None)

   
        self.assertEqual(response, mock_success_response.return_value)
        mock_success_response.assert_called_with("Item added successfully")
        mock_cursor.execute.assert_called_with("INSERT INTO user_group (group_id, user_id) VALUES (%s, %s)", ('group1', 'user1'))
        mock_conn.commit.assert_called()
        mock_conn.close.assert_called()

    @patch('os.environ', {'SECRET_MANAGER': 'mocked_secret_manager_value'})
    @patch('utility.getRDSConnection')
    @patch('utility.error_response')
    def test_lambda_handler_missing_parameters(self, mock_error_response,mock_get_rds_connection):
        mock_conn = MagicMock()
        mock_cursor = mock_conn.cursor().__enter__()
        mock_get_rds_connection.return_value = mock_conn
    
        event = {
        'body': json.dumps({'group_id': '', 'user_id': ''})
        }

        
        response = lambda_handler(event, None)

      
        self.assertEqual(response, mock_error_response.return_value)
        mock_error_response.assert_called_with(400, "group_id and user_id are required")
    @patch('os.environ', {'SECRET_MANAGER': 'mocked_secret_manager_value'})
    @patch('utility.getRDSConnection')
    def test_lambda_handler_rds_connection_error(self, mock_get_rds_connection):
        
        mock_get_rds_connection.side_effect = Exception("RDS connection error")

      
        with self.assertRaises(SystemExit):
            lambda_handler({}, None)
            
    @patch('os.environ', {'SECRET_MANAGER': 'mocked_secret_manager_value'})
    @patch('utility.getRDSConnection')
    @patch('utility.error_response')
    def test_lambda_handler_insert_error(self, mock_error_response, mock_get_rds_connection):
        
        mock_conn = MagicMock()
        mock_cursor = mock_conn.cursor().__enter__()
        mock_cursor.execute.side_effect = Exception("Insert error")
        mock_get_rds_connection.return_value = mock_conn
        event = {
        'body': json.dumps({'group_id': 'group1', 'user_id': 'user1'})
        }

       
        response = lambda_handler(event, None)

        
        self.assertEqual(response, mock_error_response.return_value)
        mock_error_response.assert_called_with(500, "Error inserting item: Insert error")
        mock_conn.close.assert_called()

if __name__ == '__main__':
    unittest.main()
