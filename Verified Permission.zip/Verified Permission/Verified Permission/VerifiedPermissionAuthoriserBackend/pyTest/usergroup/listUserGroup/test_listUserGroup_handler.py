import unittest
from unittest.mock import patch, MagicMock
import json
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lambda', 'usergroup', 'listUserGroup')))

from handler import lambda_handler

class TestLambdaHandler(unittest.TestCase):
    @patch('os.environ', {'SECRET_MANAGER': 'mocked_secret_manager_value'})
    @patch('utility.getRDSConnection')
    @patch('utility.success_response')
    def test_lambda_handler_success(self, mock_success_response, mock_get_rds_connection):
        # Arrange
        mock_conn = MagicMock()
        mock_cursor = mock_conn.cursor().__enter__()
        mock_get_rds_connection.return_value = mock_conn

        mock_user_rows = [
            {'user_id': 1, 'user_name': 'mockTest1', 'user_email': 'mock1@example.com', 'group_id': 1},
            {'user_id': 2, 'user_name': 'mockTest2', 'user_email': 'mock2@example.com', 'group_id': 2},
            {'user_id': 3, 'user_name': 'mockTest3', 'user_email': 'mock3@example.com', 'group_id': None}
        ]
        mock_group_rows = [
            {'group_id': 1, 'group_name': 'Admins'},
            {'group_id': 2, 'group_name': 'TeamOwner'}
        ]


        expected_response = {
            "statusCode": 200,
            "body": json.dumps({
                "Users": [
                    {"userId": 1, "userName": "mock1@example.com", "Groups": [1]},
                    {"userId": 2, "userName": "mock2@example.com", "Groups": [2]}
                ],
                "groups": [
                    {"groupId": 1, "groupName": "Admins"},
                    {"groupId": 2, "groupName": "Editors"}
                ]
            }),
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            }
        }

        # Act
        mock_success_response.return_value = expected_response
        response = lambda_handler(None, None)

        # Assert
        self.assertEqual(response, expected_response)
        mock_conn.close.assert_called()
    @patch('os.environ', {'SECRET_MANAGER': 'mocked_secret_manager_value'})
    @patch('utility.getRDSConnection')
    def test_lambda_handler_rds_connection_error(self, mock_get_rds_connection):
        # Arrange
        mock_get_rds_connection.side_effect = Exception("RDS connection error")

        # Act & Assert
        with self.assertRaises(SystemExit):
            lambda_handler({}, None)
    @patch('os.environ', {'SECRET_MANAGER': 'mocked_secret_manager_value'})
    @patch('utility.getRDSConnection')
    @patch('utility.error_response')
    def test_lambda_handler_fetch_data_exception(self, mock_error_response, mock_get_rds_connection):
        # Arrange
        mock_conn = MagicMock()
        mock_cursor = mock_conn.cursor().__enter__()
        mock_cursor.execute.side_effect = Exception("Fetch data error")
        mock_get_rds_connection.return_value = mock_conn
        expected_response = mock_error_response.return_value

        # Act
        response = lambda_handler(None, None)

        # Assert
        self.assertEqual(response, expected_response)
        mock_error_response.assert_called_with(500, "Error fetching data: Fetch data error")
        mock_conn.close.assert_called()

if __name__ == '__main__':
    unittest.main()
