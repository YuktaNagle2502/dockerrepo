import unittest
from unittest.mock import patch, MagicMock
import json
import boto3
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'lambda', 'createUpdatePolicyInAVP')))

# Assuming your lambda function is in a file named 'lambda_function.py'
from handler import lambda_handler, list_existing_policies, update_policy, create_new_policy, POLICY_STORE_ID
 
class TestLambdaFunction(unittest.TestCase):
    @patch('os.environ', {'POLICY_STORE_ID': 'mocked_policy_Store_value'})
    @patch('handler.vp_client')
    def test_lambda_handler(self, mock_vp_client):
        # Mocking list_policies response
        mock_vp_client.list_policies.return_value = {
            'policies': [
                {
                    'policyId': 'policy1',
                    'principal': {
                        'entityType': 'VERIFIED_PERMISSIONS::Group',
                        'entityId': 'group1'
                    },
                    'resource': {
                        'entityType': 'VERIFIED_PERMISSIONS::Endpoint',
'entityId': 'https://api.example.com'
                    },
                    'definition': {
                        'static': {
'statement': 'permit( principal == VERIFIED_PERMISSIONS::Group::"group1", action in [VERIFIED_PERMISSIONS::Action::"GET /path1 getOperation"], resource == VERIFIED_PERMISSIONS::Endpoint::"https://api.example.com" );'
                        }
                    }
                },
                {
                    'policyId': 'policy2',
                    'principal': {
                        'entityType': 'VERIFIED_PERMISSIONS::Group',
                        'entityId': 'group2'
                    },
                    'resource': {
                        'entityType': 'VERIFIED_PERMISSIONS::Endpoint',
'entityId': 'https://api.example.com'
                    },
                    'definition': {
                        'static': {
'statement': 'permit( principal == VERIFIED_PERMISSIONS::Group::"group2", action in [VERIFIED_PERMISSIONS::Action::"POST /path2 postOperation"], resource == VERIFIED_PERMISSIONS::Endpoint::"https://api.example.com" );'
                        }
                    }
                }
            ]
        }
 
        # Mocking update_policy and create_policy methods
        mock_vp_client.update_policy.return_value = {}
        mock_vp_client.create_policy.return_value = {}
 
        event = {
            'body': json.dumps({
                'project_name': 'TestProject',
                'user_id': 'testUser',
                'swagger_content': json.dumps({
"servers": [{"url": "https://api.example.com"}],
                    "paths": {
                        "/path1": {
                            "get": {
                                "operationId": "getOperation",
                                "x-group-attached": ["group1"]
                            }
                        },
                        "/path2": {
                            "post": {
                                "operationId": "postOperation",
                                "x-group-attached": ["group2"]
                            }
                        },
                        "/path3": {
                            "delete": {
                                "operationId": "deleteOperation",
                                "x-group-attached": ["group3"]
                            }
                        }
                    }
                })
            })
        }
        context = {}
 
        response = lambda_handler(event, context)
        self.assertEqual(response['statusCode'], 200)
        self.assertIn('PolicyUpdated', response['body'])
 
        # Verify update_policy and create_policy were called
        mock_vp_client.update_policy.assert_called()
        mock_vp_client.create_policy.assert_called()

    @patch('os.environ', {'POLICY_STORE_ID': 'mocked_policy_Store_value'})        
    @patch('boto3.client')
    @patch('utility.error_response')
    def test_lambda_handler_missing_parameters(self, mock_error_response, mock_boto_client):
        mock_error_response.return_value = {
            "statusCode": 400,
            "body": json.dumps("Missing required parameters")
        }
 
        event = {
            'body': json.dumps({
                'project_name': '',
                'user_id': '',
                'swagger_content': json.dumps({})
            })
        }
 
        response = lambda_handler(event, None)
        self.assertEqual(response, mock_error_response.return_value)
    @patch('os.environ', {'POLICY_STORE_ID': 'mocked_policy_Store_value'})
    @patch('boto3.client')
    @patch('utility.error_response')
    def test_lambda_handler_invalid_swagger(self, mock_error_response, mock_boto_client):
        mock_error_response.return_value = {
            "statusCode": 400,
            "body": json.dumps("Invalid swagger content")
        }
 
        event = {
            'body': json.dumps({
                'project_name': 'test_project',
                'user_id': 'user1',
                'swagger_content': 'invalid_json'
            })
        }
 
        response = lambda_handler(event, None)
        self.assertEqual(response, mock_error_response.return_value)
    @patch('os.environ', {'POLICY_STORE_ID': 'mocked_policy_Store_value'})
    @patch('boto3.client')
    @patch('utility.error_response')
    def test_lambda_handler_boto3_error(self, mock_error_response, mock_boto_client):
        mock_boto_client.side_effect = Exception("Boto3 error")
        mock_error_response.return_value = {
            "statusCode": 500,
            "body": json.dumps("Error processing request: Boto3 error")
        }
 
        event = {
            'body': json.dumps({
                'project_name': 'test_project',
                'user_id': 'user1',
                'swagger_content': json.dumps({
"servers": [{"url": "http://example.com"}],
                    "paths": {
                        "/test": {
                            "get": {
                                "operationId": "getTest",
                                "x-group-attached": ["group1"]
                            }
                        }
                    }
                })
            })
        }
 
        response = lambda_handler(event, None)
        self.assertEqual(response, mock_error_response.return_value)

if __name__ == '__main__':
    unittest.main()