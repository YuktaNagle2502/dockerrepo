import unittest
import json
import boto3
import sys
import os
from unittest.mock import patch, MagicMock

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'lambda', 'getPermissions')))

from handler import lambda_handler

class TestLambdaFunction(unittest.TestCase):
    def setUp(self):
        os.environ['policyStoreId'] = 'fh927812629djksg'
        self.event = {
            'queryStringParameters': {
                'principalEntityId': 'test-group-id'
            }
        }
        self.context = {}

    @patch('boto3.client')
    def test_lambda_handler(self, mock_boto3_client):
        # Mock the boto3 client responses
        vp_client = mock_boto3_client.return_value
        vp_client.list_policies.return_value = {
            'policies': [
                {'policyId': 'policy-1', 'policyType': 'STATIC'}
            ]
        }
        vp_client.get_policy.side_effect = [
            {
                'definition': {
                    'static': {
                        'statement': 'action in ["VERIFIED_PERMISSIONS::Action::Read", "VERIFIED_PERMISSIONS::Action::Write"]'
                    }
                },
                'resource': {'entityId': 'resource-1'}
            }
        ]

        # Call the lambda function
        response = lambda_handler(self.event, self.context)

        # Assert the response
        self.assertEqual(response['statusCode'], 200)
        self.assertEqual(response['headers']['Access-Control-Allow-Origin'], '*')
        self.assertEqual(response['headers']['Access-Control-Allow-Methods'], 'OPTIONS,GET')

        # Parse the response body
        response_body = json.loads(response['body'])
        self.assertEqual(len(response_body), 1)

        self.assertEqual(response_body[0]['action'], ['Read'])
        self.assertEqual(response_body[0]['resource']['entityId'], 'resource-1')


if __name__ == '__main__':
    unittest.main()