import unittest
import os
from unittest.mock import patch
from moto import mock_aws
import boto3
import json
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'lambda', 'uploadSwaggerToS3')))
from handler import lambda_handler

class TestLambdaFunction(unittest.TestCase):
    @mock_aws
    def setUp(self):
        os.environ['AWS_ACCESS_KEY_ID'] = 'testing'
        os.environ['AWS_SECRET_ACCESS_KEY'] = 'testing'
        os.environ['AWS_SECURITY_TOKEN'] = 'testing'
        os.environ['AWS_SESSION_TOKEN'] = 'testing'
        os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'
        os.environ['S3_BUCKET_NAME'] = 'apicodegenbucket'
        os.environ['SECRET_MANAGER'] = 'mocked_secret_manager_value'
 
        # Create a mock S3 bucket
        s3 = boto3.resource('s3', region_name='us-east-1')
        s3.create_bucket(Bucket='apicodegenbucket')
 
    @mock_aws
    @patch('handler.s3_client.put_object')
    @patch('utility.getRDSConnection')
    @patch('utility.success_response')
    def test_successful_file_upload(self,mock_success_response, mock_get_rds_connection, mock_put_object):
        mock_conn = MagicMock()
        mock_cursor = mock_conn.cursor().__enter__()
        mock_get_rds_connection.return_value = mock_conn
        mock_success_response.return_value = {"statusCode": 200, "body": "Success"}
       
        mock_put_object.return_value = None  # Mock the put_object method

        event = {
            'project_name': 'test_project',
            'user_id': '12345',
            'swagger_content': json.dumps({'swagger': '2.0', 'info': {'title': 'API', 'version': '1.0.0'}})
        }
        context = {}
        response = lambda_handler(event, context)
        self.assertEqual(response['project_name'], 'test_project')
        self.assertEqual(response['user_id'], '12345')
        self.assertIn('project_id', response)
        print('response of successfull upload', response)
        self.assertEqual(response, event)
        
        mock_put_object.assert_called_once_with(
           Bucket='apicodegenbucket',
           Key='test_project_12345.json',
           Body=event['swagger_content'],
           ContentType='application/json'
       )
       mock_cursor.execute.assert_any_call("INSERT INTO projects (project_name) VALUES (%s)", ('test_project',))
       mock_cursor.execute.assert_any_call("INSERT INTO user_project (fk_user_id, fk_project_id) VALUES (%s, %s)", ('12345', mock_cursor.lastrowid))
       mock_conn.commit.assert_called()
       mock_conn.close.assert_called()
    @mock_aws
    @patch('utility.getRDSConnection')
    def test_missing_key_in_event(self,mock_get_rds_connection):
        event = {
            'user_id': '12345',
            'swagger_content': json.dumps({'swagger': '2.0', 'info': {'title': 'API', 'version': '1.0.0'}})
        }
        context = {}
        response = lambda_handler(event, context)
        print('response of missisng Key', response)
        self.assertEqual(response['statusCode'], 400)
        self.assertIn('Missing key: \'project_name\'', response['body'])
 
    @mock_aws
    @patch('handler.s3_client.put_object')
    def test_general_exception_handling(self, mock_put_object):
        mock_put_object.side_effect = Exception('Something went wrong')
        event = {
            'project_name': 'test_project',
            'user_id': '12345',
            'swagger_content': json.dumps({'swagger': '2.0', 'info': {'title': 'API', 'version': '1.0.0'}})
        }
        context = {}
        response = lambda_handler(event, context)
        print('response of general exception', response)
        self.assertEqual(response['statusCode'], 500)
        self.assertIn('Something went wrong', response['body'])
    @mock_s3
    @patch('utility.getRDSConnection')
    def test_rds_connection_error(self, mock_get_rds_connection):
        mock_get_rds_connection.side_effect = Exception('RDS connection error')
        event = {
           'project_name': 'test_project',
           'user_id': '12345',
           'swagger_content': json.dumps({'swagger': '2.0', 'info': {'title': 'API', 'version': '1.0.0'}})
        }
        context = {}
        response = lambda_handler(event, context)
        self.assertEqual(response['statusCode'], 500)
        self.assertIn('Internal Server Error', response['body'])
    @mock_s3
    @patch('utility.getRDSConnection')
    def test_insert_project_error(self, mock_get_rds_connection):
        mock_conn = MagicMock()
        mock_cursor = mock_conn.cursor().__enter__()
        mock_cursor.execute.side_effect = Exception('Insert project error')
        mock_get_rds_connection.return_value = mock_conn
        event = {
           'project_name': 'test_project',
           'user_id': '12345',
           'swagger_content': json.dumps({'swagger': '2.0', 'info': {'title': 'API', 'version': '1.0.0'}})
        }
        context = {}
        response = lambda_handler(event, context)
        self.assertEqual(response['statusCode'], 500)
        self.assertIn('Insert project error', response['body'])
    @mock_s3
    @patch('utility.getRDSConnection')
    def test_insert_user_project_error(self, mock_get_rds_connection):
        mock_conn = MagicMock()
        mock_cursor = mock_conn.cursor().__enter__()
        mock_cursor.execute.side_effect = [None, Exception('Insert user_project error')]
        mock_get_rds_connection.return_value = mock_conn
        event = {
           'project_name': 'test_project',
           'user_id': '12345',
           'swagger_content': json.dumps({'swagger': '2.0', 'info': {'title': 'API', 'version': '1.0.0'}})
        }
        context = {}
        response = lambda_handler(event, context)
        self.assertEqual(response['statusCode'], 500)
        self.assertIn('Insert user_project error', response['body'])
if __name__ == '__main__':
   unittest.main()
    
