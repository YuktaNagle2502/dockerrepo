import { mockClient } from "aws-sdk-client-mock";
import { CognitoIdentityServiceProviderClient, AdminDeleteUserCommand } from "@aws-sdk/client-cognito-identity-provider";
import utility from "../../layers/common-functions/nodejs/utilities.mjs";
const dependencies = {
   utility: utility,
};
import { createConnection as _createConnection } from "mysql2/promise";
const handler = require("../../lambda/deleteUser/handler.mjs")(dependencies);
jest.mock("mysql2/promise", () => ({
   createConnection: jest.fn(),
}));
describe("delete-user-lambda", () => {
   let connection;
   const cognitoMock = mockClient(CognitoIdentityServiceProviderClient);
   beforeEach(() => {
       connection = {
           beginTransaction: jest.fn(),
           execute: jest.fn(),
           commit: jest.fn(),
           rollback: jest.fn(),
       };
       _createConnection.mockResolvedValue(connection);
       cognitoMock.reset();
       cognitoMock.on(AdminDeleteUserCommand).resolves({});
   });
   afterAll(() => {
       jest.restoreAllMocks();
   });
   it("should delete user from Cognito and MySQL database", async () => {
       const requestBody = { user_id: "mock-user-id" };
       const event = { body: JSON.stringify(requestBody) };
       const response = await handler(event);
       expect(cognitoMock).toHaveReceivedCommandWith(AdminDeleteUserCommand, {
           UserPoolId: process.env.USER_POOL_ID,
           Username: "mock-user-id",
       });
       expect(connection.beginTransaction).toHaveBeenCalledTimes(1);
       expect(connection.execute).toHaveBeenCalledWith("DELETE FROM `user_group` WHERE user_id_fk='mock-user-id'");
       expect(connection.execute).toHaveBeenCalledWith("DELETE FROM `user_project` WHERE fk_user_id='mock-user-id'");
       expect(connection.execute).toHaveBeenCalledWith("DELETE FROM `users` WHERE user_id='mock-user-id'");
       expect(connection.commit).toHaveBeenCalledTimes(1);
       expect(response.statusCode).toEqual(200);
       expect(JSON.parse(response.body)).toEqual("Updated Successfully");
   });
   it("should return error when event.body is not provided", async () => {
       const event = {};
       const response = await handler(event);
       expect(response.statusCode).toEqual(400);
       expect(JSON.parse(response.body).error).toEqual("Invalid Data");
   });
   it("should return error when Cognito deletion fails", async () => {
       cognitoMock.on(AdminDeleteUserCommand).rejects(new Error("Cognito Error"));
       const requestBody = { user_id: "mock-user-id" };
       const event = { body: JSON.stringify(requestBody) };
       const response = await handler(event);
       expect(connection.execute).not.toHaveBeenCalled();
       expect(response.statusCode).toEqual(500);
       expect(JSON.parse(response.body).error).toEqual("Internal Server Error");
   });
   it("should return error when database transaction fails", async () => {
       const requestBody = { user_id: "mock-user-id" };
       const event = { body: JSON.stringify(requestBody) };
       connection.execute.mockImplementationOnce(() => {
           throw new Error("MySQL Error");
       });
       const response = await handler(event);
       expect(connection.beginTransaction).toHaveBeenCalledTimes(1);
       expect(connection.execute).toHaveBeenCalledTimes(1);
       expect(response.statusCode).toEqual(500);
       expect(JSON.parse(response.body).error).toEqual("Internal Server Error");
   });
});