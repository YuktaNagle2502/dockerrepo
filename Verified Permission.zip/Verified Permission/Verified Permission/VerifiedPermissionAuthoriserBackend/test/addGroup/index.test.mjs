
import { mockClient } from "aws-sdk-client-mock";
import { GetSecretValueCommand, SecretsManagerClient } from "@aws-sdk/client-secrets-manager";
import utility from "../../layers/common-functions/nodejs/utilities.mjs";
const dependencies = {
    utility: utility
  };
import { createConnection as _createConnection, escape as _escape, format as _format } from "mysql2/promise";
const handler = require("../../lambda/addGroup/handler.mjs")(dependencies);
jest.mock("mysql2/promise", () => ({
  createConnection: jest.fn(),
  escape: jest.fn(),
  format: jest.fn(),
}));

describe("add-group-lambda", () => {
  let connection;
  const smMock = mockClient(SecretsManagerClient);
  smMock.on(GetSecretValueCommand).resolves({
    SecretString: JSON.stringify({
      host: "mock-host",
      username: "mock-username",
      password: "mock-password",
      database: "mock-database",
    }),
  });

  beforeAll(() => {
    // Create a mock MySQL connection
    connection = {
      beginTransaction: jest.fn(),
      execute: jest.fn(),
      commit: jest.fn(),
      rollback: jest.fn(),
    };
    _createConnection.mockResolvedValue(connection);
    _escape.mockImplementation((arg) => arg);
    _format.mockImplementation((arg) => arg);
  });

  afterAll(() => {
    jest.restoreAllMocks();
  });

  it("should insert data into the MySQL database", async () => {
    const requestBody = { 
      group_name: "mock-group",
      group_description:"mock-description",
      group_type:"mock-type"
   };
    const event = { body: JSON.stringify(requestBody) };
    const response = await handler(event);
    console.log(response);
   
    // Expect the mock MySQL connection's execute function to have been called with the correct SQL query and parameters
    expect(connection.execute).toHaveBeenCalledTimes(2);
    expect(connection.commit).toHaveBeenCalledTimes(1);
    expect(response.statusCode).toEqual(200);
    expect(JSON.parse(response.body)).toEqual("Group Added Successfully");
  });

  
  it("should return Group not provide", async () => {
    const requestBody = { group_name: null };
    const event = { body: JSON.stringify(requestBody) };
    const response = await handler(event);
    console.log(response)
    expect(response.statusCode).toEqual(400);
    expect(JSON.parse(response.body).error).toEqual("group not provided");
  });

  it("should return error during connection.execute", async () => {
    const requestBody = { 
      group_name: "mock-group",
      group_description:"mock-description",
      group_type:"mock-type"
     };
    const event = { body: JSON.stringify(requestBody) };
    connection.execute.mockImplementation(()=>{
      throw new Error("MySql Error");
    })
    const response = await handler(event);
    console.log(response)
 
    expect(connection.execute).toHaveBeenCalledTimes(3);
    expect(response.statusCode).toEqual(500);
    expect(JSON.parse(response.body).error).toEqual("Internal Server Error");
  });

  
});


