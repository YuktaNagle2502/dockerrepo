import { VerifiedPermissionsClient, GetSchemaCommand, PutSchemaCommand } from "@aws-sdk/client-verifiedpermissions";
import updateSchemaLambda from '../../lambda/updateSchemaActionsInAVP/handler.mjs';
 
jest.mock('@aws-sdk/client-verifiedpermissions', () => {
  const mockClientSend = jest.fn();
 
  return {
    VerifiedPermissionsClient: jest.fn(() => ({
      send: mockClientSend
    })),
    GetSchemaCommand: jest.fn(),
    PutSchemaCommand: jest.fn(),
    __esModule: true,
    mockClientSend
  };
});
 
const { mockClientSend } = require('@aws-sdk/client-verifiedpermissions');
 
const mockDependencies = {
  utility: {
    errorResponse: jest.fn()
  }
};
 
describe('updateSchemaLambda', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
 
  test('should update schema successfully', async () => {
    const event = {
      swagger_content: JSON.stringify({
        paths: {
          "/example": {
            get: {
              "x-group-attached": ["Admin", "Vendor"],
              operationId: "getExample"
            }
          }
        }
      })
    };
 
    const processEnv = process.env;
    process.env = {
      AWS_REGION: 'us-west-2',
      AWS_POLICY_STORE_ID: 'dummy-policy-store-id'
    };
 
    // Mock existing schema and successful PutSchemaCommand response
    mockClientSend
      .mockResolvedValueOnce({
        schema: JSON.stringify({
          "VERIFIED_AUTHORIZER": {
            "entityTypes": {
              "Endpoint": {
                "shape": {
                  "attributes": {},
                  "type": "Record"
                }
              },
              "Group": {
                "shape": {
                  "attributes": {},
                  "type": "Record"
                }
              }
            },
            "actions": {}
          }
        })
      }) // Mock existing schema
      .mockResolvedValueOnce({ $metadata: { httpStatusCode: 200 } }); // Mock successful PutSchemaCommand response
 
    const response = await updateSchemaLambda(mockDependencies)(event);
    console.log("Response: ",response);
 
    expect(response).toBe('Schema updated successfully');
 
    process.env = processEnv;
  });
 
  test('should handle schema update failure', async () => {
    const event = {
      swagger_content: JSON.stringify({
        paths: {
          "/example": {
            get: {
              "x-group-attached": ["Admin", "Vendor"],
              operationId: "getExample"
            }
          }
        }
      })
    };
 
    const processEnv = process.env;
    process.env = {
      AWS_REGION: 'us-west-2',
      AWS_POLICY_STORE_ID: 'dummy-policy-store-id'
    };
 
    // Mock existing schema and failed PutSchemaCommand response
    mockClientSend
      .mockResolvedValueOnce({
        schema: JSON.stringify({
          "VERIFIED_AUTHORIZER": {
            "entityTypes": {
              "Endpoint": {
                "shape": {
                  "attributes": {},
                  "type": "Record"
                }
              },
              "Group": {
                "shape": {
                  "attributes": {},
                  "type": "Record"
                }
              }
            },
            "actions": {}
          }
        })
      })
      .mockResolvedValueOnce({
        "$metadata": {
            "httpStatusCode": 400,
            "attempts": 1,
            "error": "Invalid Input"
        }
    });
 
    const response = await updateSchemaLambda(mockDependencies)(event);
    console.log("Response: ",response);
 
    expect(response.toString()).toBe("Error: Failed to update schema: ");
 
    process.env = processEnv;
  });
});