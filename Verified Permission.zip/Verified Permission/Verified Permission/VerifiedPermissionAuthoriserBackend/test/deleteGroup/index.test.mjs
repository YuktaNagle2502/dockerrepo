import handler from '../../lambda/deleteGroup/handler.mjs';
import * as utilities from '../../layers/common-functions/nodejs/utilities.mjs';

jest.mock('../../layers/common-functions/nodejs/utilities.mjs', () => {
    return {
      getRDSConnection: jest.fn().mockResolvedValue({
        execute: jest.fn(),
        end: jest.fn(),
      }),
      successResponse: jest.fn(),
      errorResponse: jest.fn(),
    };
  });
  
describe('deleteGroup Handler', () => {
   let mockEvent;
   let mockConnection;
   beforeEach(() => {
       mockEvent = {
           body: JSON.stringify({ group_id: 1 }),
       };
       mockConnection = {
           execute: jest.fn(),
           beginTransaction: jest.fn(),
           commit: jest.fn(),
           rollback: jest.fn(),
           close: jest.fn(),
       };
       utilities.getRDSConnection.mockResolvedValue(mockConnection);
   });
   afterEach(() => {
       jest.clearAllMocks();
   });
   it('should delete group successfully', async () => {
       mockConnection.execute.mockResolvedValue([{ affectedRows: 1 }]);
       const response = await handler({ utility: utilities })(mockEvent);
       expect(mockConnection.execute).toHaveBeenCalledTimes(3); // SET TRANSACTION, DELETE user_group, DELETE groups
       expect(mockConnection.commit).toHaveBeenCalledTimes(1);
       expect(utilities.successResponse).toHaveBeenCalledWith("Group Deleted Successfully");
       expect(response).toEqual(utilities.successResponse());
   });
   it('should return error for invalid JSON input', async () => {
       mockEvent.body = "invalid JSON";
       const response = await handler({ utility: utilities })(mockEvent);
       expect(utilities.errorResponse).toHaveBeenCalledWith(400, "Invalid JSON format");
       expect(response).toEqual(utilities.errorResponse());
   });
   it('should return error if group_id is not provided', async () => {
       mockEvent.body = JSON.stringify({});
       const response = await handler({ utility: utilities })(mockEvent);
       expect(utilities.errorResponse).toHaveBeenCalledWith(400, "Group ID not provided");
       expect(response).toEqual(utilities.errorResponse());
   });
   it('should handle database errors gracefully', async () => {
       mockConnection.execute.mockRejectedValue(new Error('DB Error'));
       const response = await handler({ utility: utilities })(mockEvent);
       expect(mockConnection.rollback).toHaveBeenCalledTimes(1);
       expect(utilities.errorResponse).toHaveBeenCalledWith(500, "Internal Server Error");
       expect(response).toEqual(utilities.errorResponse());
   });
   it('should close the connection after use', async () => {
       mockConnection.execute.mockResolvedValue([{ affectedRows: 1 }]);
       await handler({ utility: utilities })(mockEvent);
       expect(mockConnection.close).toHaveBeenCalledTimes(1);
   });
});