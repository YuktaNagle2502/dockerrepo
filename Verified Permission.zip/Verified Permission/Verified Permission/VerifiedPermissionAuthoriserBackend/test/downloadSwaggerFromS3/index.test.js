import { getSwaggerFromS3 } from "./lambda/downloadSwaggerFromS3";

jest.mock('@aws-sdk/client-s3', () => ({
  S3Client: jest.fn(() => ({
    send: jest.fn(),
  })),
  GetObjectCommand: jest.fn(),
}));

describe('getSwaggerFromS3', () => {
  beforeEach(() => {
    process.env.S3_BUCKET = 'test-bucket';
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should return data from S3', async () => {
    const s3Client = new S3Client({});
    const data = { Body: { transformToString: () => 'wagger-data' } };
    s3Client.send.mockImplementation(() => Promise.resolve(data));

    const event = { queryStringParameters: { project_name: 'project', user_id: 'user' } };
    const result = await getSwaggerFromS3(event);

    expect(s3Client.send).toHaveBeenCalledTimes(1);
    expect(s3Client.send).toHaveBeenCalledWith(new GetObjectCommand({
      Bucket: 'test-bucket',
      Key: 'project_user.json',
    }));
    expect(result).toEqual(JSON.parse('swagger-data'));
  });

  it('should throw an error if S3 throws an error', async () => {
    const s3Client = new S3Client({});
    const error = new Error('S3 error');
    s3Client.send.mockImplementation(() => Promise.reject(error));

    const event = { queryStringParameters: { project_name: 'project', user_id: 'user' } };

    await expect(getSwaggerFromS3(event)).rejects.toThrow(error);
  });
});