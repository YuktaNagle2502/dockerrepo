import { listAllProjects, listUserProjects } from "../../lambda/listProjects/handler.mjs";

jest.mock('../../layers/common-functions/nodejs/utilities.mjs', () => {
  return {
    getRDSConnection: jest.fn().mockResolvedValue({
      execute: jest.fn(),
      end: jest.fn(),
    }),
    successResponse: jest.fn(),
    errorResponse: jest.fn(),
  };
});

describe('listUserProjects', () => {
  it('should return user projects', async () => {
    const event = {
      queryStringParameters: { userId: 1 },
    };
    const connection = {
      execute: jest.fn(),
      end: jest.fn(),
    };
    connection.execute.mockResolvedValue([[{ id: 1, name: 'TestProject' }]]);

    const response = await listUserProjects(event, connection);

    expect(connection.execute).toHaveBeenCalledTimes(1);
    expect(response).toEqual([{ id: 1, name: 'TestProject' }]);
  });

  it('should throw error', async () => {
    const event = {
      queryStringParameters: { userId: 1 },
    };
    const connection = {
      execute: jest.fn(),
      end: jest.fn(),
    };
    connection.execute.mockRejectedValue(new Error('Error executing query'));

    await expect(listUserProjects(event, connection)).rejects.toThrow(
      'Error executing query'
    );
  });
});

describe('listAllProjects', () => {
  it('should return all projects', async () => {
    const event = {};
    const connection = {
      execute: jest.fn(),
      end: jest.fn(),
    };
    connection.execute.mockResolvedValue([[{ id: 1, name: 'TestProject' }]]);

    const response = await listAllProjects(event, connection);

    expect(connection.execute).toHaveBeenCalledTimes(1);
    expect(response).toEqual([{ id: 1, name: 'TestProject' }]);
  });

  it('should throw error', async () => {
    const event = {};
    const connection = {
      execute: jest.fn(),
      end: jest.fn(),
    };
    connection.execute.mockRejectedValue(new Error('Error executing query'));

    await expect(listAllProjects(event, connection)).rejects.toThrow(
      'Error executing query'
    );
  });
})