//this function is used to build the response in case of error
import { GetSecretValueCommand, SecretsManagerClient } from '@aws-sdk/client-secrets-manager';
import * as  mysql2 from 'mysql2/promise';

const errorResponse = (errorCode, errorMessage) => ({
    "statusCode": errorCode,
    "body": JSON.stringify({
      error: errorMessage
    }),
    "headers": { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
  });
  //this function is used to build the response in case of success
  const successResponse = (data) => {
    return {
      "statusCode": 200,
      "body": JSON.stringify(data),
      "headers": { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
    }
  };

  const getRDSConnection = async (secretName) =>{
    const secret_name = process.env.SECRET_MANAGER;
    const secret_manager = new SecretsManagerClient({});
    const res = await secret_manager.send(new GetSecretValueCommand({
        SecretId: secret_name,
    }));
  
    const secret = JSON.parse(res.SecretString);
    let connection = await mysql2.createConnection({
        host: secret.host,
        user: secret.username,
        password: secret.password,
        database: secret.dbname,
    });
    return connection;
  }

  export default {
    errorResponse,
    successResponse,
    getRDSConnection
  }