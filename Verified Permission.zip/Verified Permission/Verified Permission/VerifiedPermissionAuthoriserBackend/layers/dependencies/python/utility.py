import os
import json
import boto3
import pymysql

# Function to build error response
def error_response(error_code, error_message):
    return {
        "statusCode": error_code,
        "body": json.dumps({
            "error": error_message
        }),
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    }

# Function to build success response
def success_response(data):
    return {
        "statusCode": 200,
        "body": json.dumps(data),
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    }

def getRDSConnection(secret_name):
  client = boto3.client('secretsmanager')
  response = client.get_secret_value(SecretId=secret_name)
  secret = json.loads(response['SecretString'])
  print(secret)
  connection = pymysql.connect(host=secret['host'],
  user=secret['username'],
  password=secret['password'],
  database=secret['dbname'],
  connect_timeout=5, cursorclass=pymysql.cursors.DictCursor
  )
  return connection


