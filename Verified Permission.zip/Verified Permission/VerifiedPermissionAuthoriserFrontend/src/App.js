import React from 'react';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './components/Home';
// import AssignUser_Group from './components/AssignUser_Group';
import CreateGroups from './components/CreateGroups';
import CreateUsers from './components/CreateUsers';
import Navbar from './components/Navbar';
import SwaggerMapping from './components/swaggerMapping';
import UserGroups from './components/UserGroups'
import ListProjects from './components/ListProjects';
import Logout from './components/Logout'
import "react-toastify/dist/ReactToastify.css";

function App() {
  return (
    <>
    <Router>
    <Navbar />
        <Routes>
          <Route path='/home' element={<Home/>} />
          {/* <Route path='/assignUser_Group' element={<AssignUser_Group/>} /> */}
          <Route path='/createGroups' element={<CreateGroups/>} />
          <Route path='/createUsers' element={<CreateUsers/>} />
          <Route path="/uploadswagger" element={<SwaggerMapping />} />
          <Route path='/assignUser_Group' element={<UserGroups/>}/>
          <Route path='/listProjects' element={<ListProjects/>}/>
          <Route path='/logout' element={<Logout/>}/>
        </Routes>
      </Router>
    </>
  );
}

export default App;
