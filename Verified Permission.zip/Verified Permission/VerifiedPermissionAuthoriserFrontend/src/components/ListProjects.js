import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const ListProjects = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProjects = async () => {
      setLoading(true);
      try {
        const user_id = localStorage.getItem("user_id")
        const user_type = localStorage.getItem('user_type');
        const response = await axios.get(`${process.env.REACT_APP_BASE_API_URL}/list-projects?userId=${user_id}&user_type=${user_type}`,{
          headers: {
            "Content-Type": "application/json",
            "Authorization": localStorage.getItem("access_token")
          },
        });
        setProjects(response.data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };
    fetchProjects();
  }, []);
  const handleClick = async (project_name)=>{
    localStorage.setItem("project_name",project_name)
  }

  return (
    <div>
      <h1>Projects</h1>
      <div style={{
        padding: '20px',
        border: '1px solid #ddd'
      }}>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Name</th>
              </tr>
            </thead>
            <tbody>
              {projects.map((project) => (
                <tr key={project.project_id}>
                  <td>
                    <Link to={`/uploadswagger`}onClick={()=>handleClick(project.project_name)}>{project.project_name}</Link>
                    
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {error && <p style={{ color: 'red' }}>No Projects</p>}
      </div>
    </div>
  );
};

export default ListProjects;