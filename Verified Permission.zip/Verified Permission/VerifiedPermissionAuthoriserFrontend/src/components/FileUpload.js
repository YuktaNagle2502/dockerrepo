import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { Form } from "react-bootstrap";
import axios from "axios";


const FileUpload = ({ onFileUpload, onError}) => {

  const fetchProjects = async () => {
    const user_id = localStorage.getItem("user_id");
    const user_type = localStorage.getItem("user_type");
    try{
    const response = await axios.get(
      `${process.env.REACT_APP_BASE_API_URL}/list-projects?userId=${user_id}&user_type=${user_type}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: localStorage.getItem("access_token"),
        },
      }
    );
    return response.data;
  }
  catch(error){
    console.log(error)
  }
  };
  
  const handleFileChange = async (event) => {

    const file = event.target.files[0];

    if(!file) {
      toast.error("No file selected.");
      onError("No file selected.");
      return;
    }

    if (file.type !== "application/json") {
      toast.error("Please upload a valid JSON file.");
      onError("Invalid JSON file")
      return;
    }
    const fetchedProjects = await fetchProjects();
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = JSON.parse(e.target.result);
        if(!content.info || !content.info.title){
          throw new Error("Invalid JSON structure");
        }
        const contentTitle = content.info.title;
        onFileUpload(content);
        onError(null);
        const projectExists = fetchedProjects.find(
          (project) => project.project_name === contentTitle
        );
        if (projectExists) {
          toast.error("Swagger file with this title already exists.");
          onError("File already exists.")
          return;
        }
   
      } catch (error) {
        toast.error("Invalid JSON file.");
        onError("Invalid JSON file")
      }
    };
    reader.readAsText(file);
  };

  return (
    <Form.Group>
      <Form.Label>Upload Swagger JSON </Form.Label>
      <Form.Control
        type="file"
        accept="application/json"
        onChange={handleFileChange}
      />
    </Form.Group>
  );
};

export default FileUpload;
