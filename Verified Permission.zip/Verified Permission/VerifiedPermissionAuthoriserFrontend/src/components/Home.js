import React, { useEffect, useState } from "react";
import "../css/Home.css";
import { Link } from "react-router-dom";
import Loading from "./Loading";
import axios from "axios";
const Home = () => {
  console.log("userId:");
  const [loader, setLoader] = useState(true);
  const [allowedActions, setAllowedActions] = useState([]);
  const [userType, setUserType] = useState(null);
  const fetchUserDataAndPermissions = async () => {
    try {
      const userId = localStorage.getItem("user_id");
      const userResponse = await fetch(
        `${process.env.REACT_APP_BASE_API_URL}/user/${userId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": localStorage.getItem("access_token")
          },
        }
      );
      if (!userResponse.ok) {
        throw new Error("Network response was not ok.");
      }
      const userData = await userResponse.json();
      const userType = userData[0]["user_type"];
      localStorage.setItem("user_type", userType);
      setUserType(userType);
      const permissionsResponse = await axios.get(
        `https://qlrt0l86gd.execute-api.us-east-2.amazonaws.com/prod/get-permissions?principalEntityId=${userType}`,
        {
          headers: {
            "Content-Type": "application/json",
            "Authorization": localStorage.getItem("access_token")
          },
        }
      );
      const actions = permissionsResponse.data[0].action;
      console.log("actions:", actions);
      setAllowedActions(actions);
      localStorage.setItem("allowedActions", actions);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoader(false);
    }
  };
  useEffect(() => {
    fetchUserDataAndPermissions();
  }, []);
  return (
    <div className="home-container">
      <br /> <br />
      <center>
        <h1>Identity and Access Management</h1>
        {!loader ? (
          <div className="card-container">
            {allowedActions.length > 0 && (
              <>
                {(allowedActions.includes("POST /groups CreateGroups") ||
                  allowedActions.includes("GET /groups GetGroups")) && (
                  <Link to="/createGroups" className="card">
                    <h2>Groups</h2>
                  </Link>
                )}
                {(allowedActions.includes("POST /users CreateUsers") ||
                  allowedActions.includes("GET /users GetUsers")) && (
                  <Link to="/createUsers" className="card">
                    <h2>Users</h2>
                  </Link>
                )}
                {(allowedActions.includes("POST /create-user-group CreateUserGroup") ||
                  allowedActions.includes("PUT /create-user-group UpdateUserGroup") ||
                  allowedActions.includes("GET /create-user-group GetUserGroup")) && (
                  <Link to="/assignUser_Group" className="card">
                    <h2>User Group Association</h2>
                  </Link>
                )}
                {(allowedActions.includes("GET /download-swagger GetSwagger") ||
                  allowedActions.includes("POST /start-workflow CreateWorkflow")) && (
                  <Link to="/uploadswagger" className="card">
                    <h2>API Management</h2>
                  </Link>
                )}
                <Link to="/listProjects" className="card">
                  <h2>Projects</h2>
                </Link>
              </>
            )}
          </div>
        ) : (
          <Loading />
        )}
      </center>
    </div>
  );
};
export default Home;
