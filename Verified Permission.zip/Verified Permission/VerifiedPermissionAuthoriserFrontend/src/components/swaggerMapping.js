import React, { useState, useEffect } from "react";
import { Container, Row, Col, Button, Alert } from "react-bootstrap";
import FileUpload from "./FileUpload";
import TableDisplay from "./TableDisplay";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const SwaggerMapping = () => {
  const location = useLocation();
  const projectExists = location.state;
  const [swaggerData, setSwaggerData] = useState(null);
  const [groups, setGroups] = useState([]);
  const [permissions, setPermissions] = useState({});
  const [error, setError] = useState(null);
  const [jsonError, setJsonError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchGroups();
    if (localStorage.getItem("project_name")) {
      getDataFromS3();
    }
  }, []);
  // Fetch groups from API
  const fetchGroups = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_API_URL}/groups`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: localStorage.getItem("access_token"),
          },
        }
      );

      let groupArray = [];
      response.data.map((group) => {
        groupArray.push(group.group_name);
      });
      setGroups(groupArray);
    } catch (error) {
      setError("Error fetching groups");
    }
  };

  // Handle file upload and initialize permissions
  const handleFileUpload = (data) => {
    setSwaggerData(data);
    localStorage.setItem("project_name", data.info.title);
    initializePermissions(data);
    setJsonError(null);
  };

  const handleFileUploadError = (errorMessage) => {
    setJsonError(errorMessage);
  };

  // Check if file exists in S3
  const getDataFromS3 = async () => {
    try {
      const user_id = localStorage.getItem("user_id");
      const project_name = localStorage.getItem("project_name");
      const response = await axios.get(
        `${process.env.REACT_APP_BASE_API_URL}/download-swagger?user_id=${user_id}&project_name=${project_name}`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: localStorage.getItem("access_token"),
          },
        }
      );
      if (response.status === 200) {
        // File exists in S3, fetch it
        const swaggerData = response.data;
        handleFileUpload(swaggerData);
      } else {
        // File does not exist in S3, allow user to upload a new file
        setSwaggerData(null);
      }
    } catch (error) {
      setError("Upload your swagger");
    }
  };

  // Initialize permissions based on Swagger data
  const initializePermissions = (data) => {
    const initialPermissions = {};
    Object.entries(data.paths).forEach(([path, methods]) => {
      Object.entries(methods).forEach(([method, details]) => {
        const key = `${method} ${path}`;
        if (details["x-group-attached"]) {
          initialPermissions[key] = [...details["x-group-attached"]];
        } else {
          initialPermissions[key] = [];
        }
      });
    });
    setPermissions(initialPermissions);
  };

  // Handle group permission change (select/deselect)
  const handlePermissionChange = (method, path, group) => {
    const key = `${method} ${path}`;
    setPermissions((prevPermissions) => {
      const newPermissions = { ...prevPermissions };
      if (!newPermissions[key]) {
        newPermissions[key] = [];
      }
      if (newPermissions[key].includes(group)) {
        // Group is already selected, so deselect it
        newPermissions[key] = newPermissions[key].filter((g) => g !== group);
      } else {
        // Group is not selected, so select it
        newPermissions[key] = [...newPermissions[key], group];
      }
      return newPermissions; // Ensure to return a new object reference
    });
  };

  // Handle saving modified Swagger file by sending it to an API
  const handleSave = async () => {
   
    if (!swaggerData) {
      setError("No Swagger data to save.");
      return;
    }
    const modifiedSwagger = { ...swaggerData };
 
    Object.entries(permissions).forEach(([key, groups]) => {
      const [method, path] = key.split(" ");
      if (groups.length > 0) {
        modifiedSwagger.paths[path][method]["x-group-attached"] = groups;
      } else {
        delete modifiedSwagger.paths[path][method]["x-group-attached"];
      }
    });
    const bodyObject = {
      project_name: localStorage.getItem("project_name"),
      user_id: localStorage.getItem("user_id"),
      swagger_content: JSON.stringify(modifiedSwagger),
    };
    
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_BASE_API_URL}${process.env.REACT_APP_START_WORKFLOW_URL}`,
        bodyObject,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: localStorage.getItem("access_token"),
          },
        }
      );
      if (response.status === 200) {
        toast.success("Swagger file saved successfully.");
        navigate("/listProjects");
      } else {
        toast.error(`Error saving Swagger file: ${response.statusText}`);
        setSuccessMessage(null);
      }
    } catch (error) {
      setError(`Error saving Swagger file: ${error.message}`);
      setSuccessMessage(null);
    }
  };

  return (
    <Container>
      <Row className="mt-5">
        <Col>
          <h1>Swagger & Group Mapping</h1>
          {error && <Alert variant="danger">{error}</Alert>}
          <br />
          {successMessage && <Alert variant="success">{successMessage}</Alert>}
          <FileUpload onFileUpload={handleFileUpload} onError={handleFileUploadError}/>
        </Col>
      </Row>
      <Row className="mt-5">
        <Col>
          {swaggerData && groups.length > 0 && (
            <TableDisplay
              swaggerData={swaggerData}
              groups={groups}
              permissions={permissions}
              onPermissionChange={handlePermissionChange}
            />
          )}
        </Col>
      </Row>
      <Row className="mt-5">
        <Col>
          <br />
          <Button onClick={handleSave} disabled={!swaggerData || projectExists || jsonError }>
            Save Modified Swagger
          </Button>
        </Col>
        <ToastContainer position="top-center" />
      </Row>
    </Container>
  );
};

export default SwaggerMapping;
