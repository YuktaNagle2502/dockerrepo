import React, { useEffect } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import "../css/Navbar.css";
import { jwtDecode } from "jwt-decode";
function Navbar() {
  const location = useLocation();
  const redirecthomePath = [
    "/createGroups",
    "/createUsers",
    "/assignUser_Group",
    "/uploadswagger",
    "/listProjects",
  ];
  const isHomePage = location.pathname === "/home";
  const isAuthorizedPage =
    isHomePage || redirecthomePath.includes(location.pathname);
  let requestCount = 0;
  const cognitoDomain = process.env.REACT_APP_COGNITO_DOMAIN_URL;
  const clientId =
    process.env.REACT_APP_ENV === "local"
      ? "519kbs7h5rc4fqc9v5ise314ig"
      : "67kapta4rqg6pbdu96d42qsss1";
  const redirectUri = "http://localhost:3000/home";
  const scopes = "aws.cognito.signin.user.admin openid profile email";

  function getAuthorizationCode() {
    const params = new URLSearchParams(window.location.search);
    return params.get("code");
  }

  useEffect(() => {
    const authorizationCode = getAuthorizationCode();

    setTimeout(() => {
      if (!localStorage.getItem("id_token") && requestCount === 0) {
        fetch(`${cognitoDomain}/oauth2/token`, {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            grant_type: "authorization_code",
            client_id: clientId,
            redirect_uri: redirectUri,
            code: authorizationCode,
          }),
        })
          .then((response) => {
            if (response.ok) {
              return response.json();
            } else {
              throw new Error("Network response was not ok.");
            }
          })
          .then((data) => {
            localStorage.setItem("id_token", data.id_token);
            localStorage.setItem("refresh_token", data.refresh_token);
            localStorage.setItem("access_token", data.access_token);

            let idToken = localStorage.getItem("id_token");
            const decoded = jwtDecode(idToken);

            localStorage.setItem("user_id", decoded.sub);
            if (localStorage.getItem("user_id")) {
              window.location.reload();
            }
          })
          .catch((error) => {
            console.error("Error in authorization code:", error);
          });
      }
      requestCount++;
    }, 1000);
  }, []);
  const localDomainUrl = `${
    process.env.REACT_APP_COGNITO_DOMAIN_URL
  }/login?client_id=519kbs7h5rc4fqc9v5ise314ig&response_type=code&scope=${encodeURIComponent(
    scopes
  )}&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fhome`;
  const s3DomainUrl = `${
    process.env.REACT_APP_COGNITO_DOMAIN_URL
  }/login?client_id=67kapta4rqg6pbdu96d42qsss1&response_type=code&scope=${encodeURIComponent(
    scopes
  )}&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fhome`;
  const loginUrl =
    process.env.REACT_APP_ENV === "local" ? localDomainUrl : s3DomainUrl;
  return (
    <>
      <nav className="navbar">
        <div className="navbar-container">
          {isAuthorizedPage ? (
            <NavLink to="/home" className="navbar-logo">
              <h3 className="permission-name">Amazon Verified Permission</h3>
            </NavLink>
          ) : (
            <span className="navbar-logo">
              <h3 className="permission-name">Amazon Verified Permission</h3>
            </span>
          )}

          {!isAuthorizedPage && (
            <a href={loginUrl} className="navbar-logout">
              <h3 className="logout-btn">Login</h3>
            </a>
          )}

          {isAuthorizedPage && (
            <NavLink to="/logout" className="navbar-logout">
              <h3 className="logout-btn">Logout</h3>
            </NavLink>
          )}
        </div>
      </nav>
    </>
  );
}
export default Navbar;