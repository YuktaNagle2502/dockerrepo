import React from 'react'

const AssignUser_Group = () => {
  return (
    <div>
       <h1>Assign user to group</h1>
    </div>
  )
}

export default AssignUser_Group
