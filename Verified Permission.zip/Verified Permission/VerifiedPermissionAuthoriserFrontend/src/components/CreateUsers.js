import React, { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../css/CreateUser.css";
const CreateUsers = () => {
  const [email, setEmail] = useState("");
  const [users, setUsers] = useState([]);
  const [name, setName] = useState("");
  const [userType, setUserType] = useState("");
  const [groupName, setGroupName] = useState("");
  const [groups, setGroups] = useState([]);
  const [groupId, setGroupId] = useState("");
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [errors, setErrors] = useState({
    email: false,
    name: false,
    emailNameMismatch: false,
  });
  useEffect(() => {
    const fetchUsers = async () => {
      setLoadingUsers(true);
      try {
        const response = await fetch(
          `${process.env.REACT_APP_BASE_API_URL}/users`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              "Authorization": localStorage.getItem("access_token")
            },
          }
        );
        const data = await response.json();
        setUsers(data);
      } catch (error) {
        toast.error("Error fetching users: " + error.message);
        console.error("Error fetching users:", error);
      } finally {
        setLoadingUsers(false);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await fetch(
          `${process.env.REACT_APP_BASE_API_URL}/groups`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              "Authorization": localStorage.getItem("access_token")
            },
          }
        );
        const data = await response.json();
        setGroups(data);
      } catch (error) {
        console.error("Error fetching groups:", error);
      }
    };
    fetchGroups();
  }, []);
  const handleGroupChange = (e) => {
    const selectedGroupName = e.target.value;
    setGroupName(selectedGroupName);
    if (selectedGroupName === "ApiOwner") {
      setGroupId("12");
    } else if (selectedGroupName === "Admin") {
      setGroupId("1");
    } else {
      const selectedGroup = groups.find(
        (group) => group.group_name === selectedGroupName
      );
      if (selectedGroup) {
        setGroupId(selectedGroup.group_id);
      }
    }
  };
  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    let validationErrors = {
      email: false,
      name: false,
      emailNameMismatch: false,
    };
    if (!isValidEmail(email)) {
      validationErrors.email = true;
    }
    setErrors(validationErrors);
    if (validationErrors.email || validationErrors.emailNameMismatch) {
      toast.error("Please fix the errors in the form.");
      return;
    }
    let finalUserType = userType;
    if (
      userType === "SystemUser" &&
      (groupName === "ApiOwner" || groupName === "Admin")
    ) {
      finalUserType = groupName;
    }
    try {
      const response = await fetch(
        `${process.env.REACT_APP_BASE_API_URL}/users`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": localStorage.getItem("access_token")
          },
          body: JSON.stringify({
            user_name: email,
            user_email: email,
            user_type: finalUserType,
            group_id: groupId,
          }),
        }
      );
      if (response.ok) {
        toast.success("User created successfully!");
        window.location.reload();
        setEmail("");
        setName("");
        setUserType("");
        setGroupId("");
        const newUser = await response.json();
        setUsers([...users, newUser]);
      } else {
        const errorData = await response.json();
        toast.error(`Error creating user: ${errorData.message}`);
      }
    } catch (error) {
      toast.error("Error creating user: " + error.message);
    }
  };
  const handleDelete = async (userId) => {
    try {
      const response = await fetch(
        `${process.env.REACT_APP_BASE_API_URL}/users`,
        {
          method: "DELETE",
          body: JSON.stringify({
            user_id: userId,
          }),
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": localStorage.getItem("access_token")
          },
        }
      );
      if (response.ok) {
        toast.success("User deleted successfully!");
        setUsers(users.filter((user) => user.user_id !== userId));
      } else {
        const errorData = await response.json();
        toast.error(`Error deleting user: ${errorData.message}`);
      }
    } catch (error) {
      toast.error("Error deleting user: " + error.message);
    }
  };
  return (
    <div className="main-div">
      <div className="form-container">
        <center>
          <h2>Create User</h2>
        </center>
        <form className="form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email" className="label">
              Email:
            </label>
            <input
              type="email"
              id="email"
              className={`input ${errors.email ? "invalid" : ""}`}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            {errors.email && (
              <span className="error-message">Invalid email format</span>
            )}
          </div>
          <div className="form-group">
            <label htmlFor="name" className="label">
              Name:
            </label>
            <input
              type="text"
              id="name"
              className={`input ${errors.name ? "invalid" : ""}`}
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="userType" className="label">
              User Type:
            </label>
            <select
              id="userType"
              className="select"
              value={userType}
              onChange={(e) => setUserType(e.target.value)}
              required
            >
              <option value="">Select user type</option>
              <option value="SystemUser">System User</option>
              <option value="ConsumerUser">Consumer User</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="groupName" className="label">
              Group Name:
            </label>
            <select
              id="groupName"
              className="select"
              value={groupName}
              onChange={handleGroupChange}
              required
            >
              <option value="">Select group</option>
              {userType === "SystemUser" ? (
                <>
                  <option value="ApiOwner">Api Owner</option>
                  <option value="Admin">Admin</option>
                </>
              ) : (
                groups.map((group) => (
                  <option key={group.group_id} value={group.group_name}>
                    {group.group_name}
                  </option>
                ))
              )}
            </select>
          </div>
          <br />
          <button type="submit" className="submit-button">
            Save
          </button>
        </form>
      </div>
      <div className="user-list-container">
        <h2>List Users</h2>
        <br />
        {loadingUsers ? (
          <div className="loader">Loading..</div>
        ) : users.length > 0 ? (
          <table className="user-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Type</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.user_id}>
                  <td>{user.user_name}</td>
                  <td>{user.user_email}</td>
                  <td>{user.user_type}</td>
                  <td>
                    <button
                      className="delete-button"
                      onClick={() => handleDelete(user.user_id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div>No users found.</div>
        )}
      </div>
      <ToastContainer />
    </div>
  );
};
export default CreateUsers;
