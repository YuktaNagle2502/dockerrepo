import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../css/UserGroups.css'; // Assuming you have a CSS file for styling

const UserGroups = () => {
    const [data, setData] = useState(null);
    const [groupMemberships, setGroupMemberships] = useState({});

    useEffect(() => {
        // Fetch data from the GET API
        axios.get(`${process.env.REACT_APP_BASE_API_URL}/create-user-group`,{
            headers: {
              "Content-Type": "application/json",
              "Authorization": localStorage.getItem("access_token")
            },
          })
            .then(response => {
                
              
                const responseData = response.data
                console.log("Response", responseData);
                setData(responseData);

                initialGroupMapping(responseData)
            })
            .catch(error => console.error('Error fetching data:', error));
    }, []);


    const initialGroupMapping = (responseData) => {
        const initialUserGroupMapping = responseData.groups.reduce((acc, group) => {

            acc[group.groupId] = [];
            return acc;
        }, {});

        responseData.Users.forEach(user => {
            user.Groups.forEach(groupId => {
                if (!initialUserGroupMapping[groupId]) {
                    initialUserGroupMapping[groupId] = [];
                }
                initialUserGroupMapping[groupId].push(user.userId);
            });
        });
        setGroupMemberships(initialUserGroupMapping);
    }

    const handleCheckboxChange = (userId, groupId) => {
        data.Users.map(user => {
            if (user.userId === userId) {

                if (!user.Groups.includes(groupId)) {

                    let targetObj = data.Users.find(obj => obj.userId === userId);
                    if (targetObj) {
                        const groups = targetObj.Groups;
                        groups.push(groupId);

                    }

                }
                else {

                    let targetObj = data.Users.find(obj => obj.userId === userId);
                    if (targetObj) {
                        targetObj = targetObj.Groups.filter(function (item) {
                            return item !== groupId;
                        });

                    }
                }
            }

        })


        let updateGroupMapping = { ...groupMemberships }
        if (!updateGroupMapping[groupId].includes(userId)) {
            updateGroupMapping[groupId].push(userId)
            console.log("TestGroupId",groupId)
            console.log("TestUserId",userId)
            axios.post(`${process.env.REACT_APP_BASE_API_URL}/create-user-group`,{"group_id":groupId,"user_id":userId},{
                headers: {
                  "Content-Type": "application/json",
                  "Authorization": localStorage.getItem("access_token")
                },
              } )
            .then(response => console.log('Data Inserted successfully:', response))
            .catch(error => console.error('Error saving data:', error));

        }
        else {
            updateGroupMapping = {
                ...updateGroupMapping,
                [groupId]: updateGroupMapping[groupId].filter(
                    (item) => item !== userId
                ),
            };
            console.log("GroupId",groupId)
            console.log("UserId",userId)
            axios.put(
                `${process.env.REACT_APP_BASE_API_URL}/create-user-group`,
                { "group_id": groupId, "user_id": userId },{
                    headers: {
                      "Content-Type": "application/json",
                      "Authorization": localStorage.getItem("access_token")
                    },
                  }
            )
            .then(response => console.log('Data Deleted successfully:', response))
            .catch(error => console.error('Error Deleting  data:', error));
        }
        setGroupMemberships(updateGroupMapping)

    };


    if (!data) {
        return <div>Loading...</div>;
    }
    const allowedActions = localStorage.getItem("allowedActions");
    return (
        <div className="user-groups">
            <table className="user-groups-table">
                <thead>
                    <tr>
                        <th>Users</th>
                        {data.groups.map(group => (
                            <th key={group.groupId}>{group.groupName}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {data.Users.map(user => (
                        <tr key={user.userId}>
                            <td>{user.userName}</td>
                            {data.groups.map(group => (
                                <td key={group.groupId}>
                                    <input
                                        type="checkbox"
                                        checked={groupMemberships[group.groupId]?.includes(user.userId) || false}
                                        onChange={() => {
                                            if(allowedActions.includes('PUT /create-user-group')||allowedActions.includes('POST /create-user-group')){
                                                handleCheckboxChange(user.userId, group.groupId)
                                            }
                                        }
                                        }
                                    />
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default UserGroups;