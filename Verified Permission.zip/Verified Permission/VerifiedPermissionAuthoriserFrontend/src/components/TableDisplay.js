import React from 'react';
import { Table, Form } from 'react-bootstrap';
 
const TableDisplay = ({ swaggerData, groups, permissions, onPermissionChange }) => {
  const getPaths = () => {
    const paths = [];
    Object.entries(swaggerData.paths).forEach(([path, methods]) => {
      Object.keys(methods).forEach(method => {
        paths.push({ method, path });
      });
    });
    return paths;
  };
 
  const paths = getPaths();
 
  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>API Method</th>
          {groups.map(group => (
            <th key={group}>{group}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {paths.map(({ method, path }) => (
          <tr key={`${method} ${path}`}>
            <td>{`${method.toUpperCase()} ${path}`}</td>
            {groups.map(group => (
              <td key={group}>
                <Form.Check
                  type="checkbox"
                  checked={permissions[`${method} ${path}`]?.includes(group) || false}
                  onChange={() => onPermissionChange(method, path, group)}
                />
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </Table>
  );
};
 
export default TableDisplay;