import React, { useEffect, useState} from 'react';
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../css/CreateUser.css";
const CreateProject = () => {
  const [errorMessage, setErrorMessage] = useState('');
  const [loadingGroups, setLoadingGroups] = useState(false);
  const [groups, setGroups] = useState([]);
  const [formData, setFormData] = useState({
    group_name:'',
    group_description: '',
    group_type: 'ConsumerUser'
  
  });
  useEffect(() => {
    const fetchGroups = async () => {
      setLoadingGroups(true);
      try {
        const response = await fetch(
          `https://qlrt0l86gd.execute-api.us-east-2.amazonaws.com/prod/groups`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              "Authorization": localStorage.getItem("access_token")
            },
          }
          
        );
        const data = await response.json();
        console.log(data);
        setGroups(data);
      } catch (error) {
        console.error("Error fetching groups:", error);
      }
      finally{
        setLoadingGroups(false);
      }
    };
    fetchGroups();
  }, []);
  const handleDelete = async (group_id) => {
    try {
      const response = await fetch(
        "https://qlrt0l86gd.execute-api.us-east-2.amazonaws.com/prod/groups",
        {
          method: "DELETE",
          headers: {
            "Authorization": localStorage.getItem("access_token")
          },
          body: JSON.stringify({ group_id }),
        }
      );
  
      if (response.ok) {
        toast.success("Group deleted successfully!");
        setGroups(groups.filter((group) => group.group_id !== group_id));
      } else {
        const errorData = await response.json();
        toast.error(`Error deleting group: ${errorData.message}`);
      }
    } catch (error) {
      toast.error("Error deleting group: " + error.message);
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    console.log(formData);

    try {
      const response = await fetch(
        `https://qlrt0l86gd.execute-api.us-east-2.amazonaws.com/prod/groups`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            "Authorization": localStorage.getItem("access_token")
          },
          body: JSON.stringify(formData),
        }
      );
      if (response.ok) {
        const responseData = await response.json()
        toast.success("Group Created successfully!");
        window.location.reload();
        
      } else {
        const errorData = await response.json();
        if(errorData.error === 'ER_DUP_ENTRY')
          toast.error('Error creating group: Group already exists');
       
      }
    } catch (error) {
      toast.error(error.message);
      console.error('Error creating group:', error);
    }
  };

  console.log(formData);
  
 
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
    if (name === 'name') {
      if (/\s|-/.test(value)) {
        setErrorMessage('Invalid input');
      } else {
        setErrorMessage('');
      }
    }
  };


  return (
    <div className="main-div">
    <div className="form-container">
      <center><h2>Create Groups</h2></center>
    
      <form className="form" onSubmit={handleSubmit}>
      <div className="form-group">
     <br/>
      <label htmlFor="email" className="label">
              Group Name:
            </label>
            <input
            style={{height:'35px'}}
              required
              type='text'
              placeholder='Group Name'
              name='group_name'
              value={formData.name}
              onChange={handleInputChange}
            /><br></br>
           
            {errorMessage && (
              <div className='error-message'>{errorMessage}</div>
            )}
             </div>
             <div className="form-group">
             <label htmlFor="email" className="label">
              Group Description:
            </label>
            <input
             style={{height:'35px'}}
              required
              type='text'
              placeholder='Group Description'
              name='group_description'
              value={formData.description}
              onChange={({ target }) =>
                setFormData((prevData) => ({
                  ...prevData,
                  group_description: target.value,
                }))
              }
            /><br></br>
            </div>
            <center>
            <button className="submit-button-group" type='submit' >
              Save
            </button></center>
            <br />
          </form>
          </div>
          <div className="user-list-container">
        <h2>List Groups</h2><br/>
        {loadingGroups ? ( <div className="loader">Loading..</div>
        ) : groups.length > 0 ? (
        <table className="user-table">
          <thead>
            <tr>
              <th>Group Name</th>
              <th>Group Description</th>
              
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {groups.length > 0 ? (
              groups.map((group) => (
                <tr key={group.group_id}>
                  <td>{group.group_name}</td>
                  <td>{group.group_description}</td>
                  
                  <td>
                    <button
                      className="delete-button"
                      onClick={() => handleDelete(group.group_id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4">No groups found.</td>
              </tr>
            )}
          </tbody>
        </table>
         ) : (
          <div>No groups found.</div>
      )}
      </div>
      <ToastContainer position='top-center' />
        </div>
  );
};
export default CreateProject;
