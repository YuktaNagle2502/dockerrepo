import { useEffect } from "react";

const Logout = () => {

 useEffect(() => {

   localStorage.removeItem("user_id");
   localStorage.removeItem("refresh_token");
   localStorage.removeItem("id_token");
   localStorage.removeItem("access_token");
   
 }, []);
 return null; 
}
export default Logout;