import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { aws_cognito } from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';

export class VerifiedPermissionAuthoriserUserPoolStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const existingRole = iam.Role.fromRoleArn(this, 'ExistingRole', 'arn:aws:iam::094853031708:role/LambdaRoleForRDSAccess');

    const dependenciesLayer = new lambda.LayerVersion(this, 'dependencies-layer', {
      compatibleRuntimes: [
        lambda.Runtime.NODEJS_18_X,
      ],
      code: lambda.Code.fromAsset('layers/dependencies'),
      description: 'Uses a 3rd party libraries',
    });
    
    const commonFunctionLayer = new lambda.LayerVersion(this, 'common-function-layer', {
      compatibleRuntimes: [
        lambda.Runtime.NODEJS_18_X
      ],
      code: lambda.Code.fromAsset('layers/common-functions'),
      description: 'Uses common function within the application',
    });

    cdk.Tags.of(commonFunctionLayer).add("Name", "Verfied-Permission-Application-Pool")

    // Cognito userpool creation
    const cognitoUserpool = new aws_cognito.UserPool(this, 'verified-permission-authoriser-pool', {
      userPoolName: 'verified-permission-authoriser-pool',
      selfSignUpEnabled: false,
      signInAliases: {
        email: true,
      },
      autoVerify: {
        email: true,
      },
      standardAttributes: {
        fullname: {
          required: true,
          mutable: true,
        },
        email: {
          required: true,
          mutable: true,
        },
        phoneNumber: {
          required: true,
          mutable: true,
        },

      },
      customAttributes: {
        groups: new aws_cognito.StringAttribute({
          mutable: true,
        }),
      },
      passwordPolicy: {
        minLength: 6,
        requireLowercase: true,
        requireDigits: true,
        requireUppercase: true,
        requireSymbols: true,
      },
      accountRecovery: aws_cognito.AccountRecovery.EMAIL_ONLY,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
      advancedSecurityMode: aws_cognito.AdvancedSecurityMode.AUDIT,
    });

    // Create Cognito domain
    const cognitoDomain = new aws_cognito.UserPoolDomain(this, 'CognitoDomain', {
      userPool: cognitoUserpool,
      cognitoDomain: {
        domainPrefix: 'verifiedpermissionauthoriser', 
      },
    });

    // APP Client for Cognito
    const localappClient = cognitoUserpool.addClient('localapp-client', {
      userPoolClientName: "localapp-client",
      authFlows: {
        userPassword: true    // to authenticate username and password
      },
      oAuth: {
        flows: {
          authorizationCodeGrant: true,  // grants token to user
        },
        scopes: [
          aws_cognito.OAuthScope.OPENID,  // allows access to user identity
          aws_cognito.OAuthScope.EMAIL, // allows access to user email
          aws_cognito.OAuthScope.COGNITO_ADMIN,
          aws_cognito.OAuthScope.PROFILE
        ],
        callbackUrls: ['http://localhost:3000/home'],
        logoutUrls: ['http://localhost:3000/logout'],    
      }
    })
    const s3Client = cognitoUserpool.addClient('s3-client', {
      userPoolClientName: "s3-client",
      authFlows: {
        userPassword: true
      },
      oAuth: {
        flows: {
          authorizationCodeGrant: true,
        },
        scopes: [
          aws_cognito.OAuthScope.OPENID,
          aws_cognito.OAuthScope.EMAIL,
          aws_cognito.OAuthScope.COGNITO_ADMIN,
          aws_cognito.OAuthScope.PROFILE
        ],
        callbackUrls: ['http://localhost:3000/home'],
        logoutUrls: ['http://localhost:3000/logout'],
      }
    })

    //Create lambda function for lambda authorization
    const lambdaAuthorizer = new lambda.Function(this, 'lambdaAuthorizer', {
       runtime: lambda.Runtime.NODEJS_18_X,
       code: lambda.Code.fromAsset('lambda/lambdaAuthorizer'),
       handler: 'index.handler',
       role: existingRole,
       layers: [dependenciesLayer,commonFunctionLayer],
      environment:{
        policyStoreId: "Vsp7cakpSV6ToFg1sFCx2Q"
      }
    });
    
    new lambda.CfnPermission(this, 'LambdaInvokePermission', {
      action: 'lambda:InvokeFunction',
      principal: 'apigateway.amazonaws.com',
      functionName: lambdaAuthorizer.functionName,
      sourceArn: `arn:aws:execute-api:us-east-2:094853031708:qlrt0l86gd/authorizers/*`,
    });
  
    
    const preTokenGenerationLambda = new lambda.Function(this, 'preTokenGenerationLambda', {
      runtime: lambda.Runtime.NODEJS_18_X,
      code: lambda.Code.fromAsset('lambda/preTokenGeneration'),
      handler: 'index.handler',
      role: existingRole,
      layers: [dependenciesLayer,commonFunctionLayer],
      environment:{
        SECRET_MANAGER: "avp/mysql/secretDb"
      }
    });
 
    cognitoUserpool.addTrigger(aws_cognito.UserPoolOperation.PRE_TOKEN_GENERATION, preTokenGenerationLambda);

  }
}
