import { VerifiedPermissionsClient, BatchIsAuthorizedCommand } from "@aws-sdk/client-verifiedpermissions";
import { AWS } from "@aws-sdk";
import jwt from "jsonwebtoken";
const vpClient = new VerifiedPermissionsClient();

const generatePolicy = (principalId, effect, resource) => {
   const policyDocument = {
       Version: '2012-10-17',
       Statement: [{
           Action: 'execute-api:Invoke',
           Effect: effect,
           Resource: resource
       }]
   };
   return {
       principalId,
       policyDocument,
       context: {
           // Custom context values
           exampleKey: 'exampleValue'
       }
   };
};

export default (dependencies) => async (event, context) => {
  
 console.log(event)
 try {
   const policyStoreId = process.env.policyStoreId;
   if (!policyStoreId) {
     return dependencies.utility.errorResponse(500, "Missing policyStoreId environment variable");
   }
   console.log(policyStoreId)
   // Extract method name, API name, and operation ID
   const methodName = event.httpMethod;
   console.log(methodName)
   const apiName = event.requestContext?.resourcePath;
   console.log(apiName)
   const operationId = event.requestContext?.operationName;
   const actionName = `${methodName} ${apiName} ${operationId}`;
   console.log(actionName)
   // Decode JWT
   const token = event.headers.Authorization;
   if (!token) {
    return dependencies.utility.errorResponse(400, "Missing token in request body");
   }
   const cognito = new AWS.CognitoIdentityServiceProvider();
   const params = {
       AccessToken: token
   };
   try{
    await cognito.getUser(params).promise();
   }catch (error) {
       if (error.code === 'NotAuthorizedException') {
           return generatePolicy('user', 'Deny', event.methodArn);
       } else {
           return {
               statusCode: 500,
               body: JSON.stringify(`An error occurred: ${error.message}`)
           };
       }
   }
   const decoded = jwt.decode(token, { complete: true });
   console.log('decoded - ' + JSON.stringify(decoded))
   const principalEntityIds = decoded?.payload["custom:groups"] || [];
   console.log('principalEntityIds - ' + JSON.stringify(principalEntityIds));
   if(principalEntityIds === undefined || principalEntityIds.length === 0) {
    console.log('principalEntityIds is undefined');
    return generatePolicy('user', 'Deny', event.methodArn);
   }
   const domainName= event.requestContext.domainName;
   const stage= event.requestContext.stage;
   const resource = `https://${domainName}/${stage}`;
   console.log('resource',resource)
   if (!resource) {
    return dependencies.utility.errorResponse(400, "Missing resource in request body");
   }
   const entities = {
     entityList: [
       {
         identifier: {
           entityId: resource,
           entityType: "VERIFIED_AUTHORIZER::Endpoint",
         },
       },
     ],
   };
   const requests = principalEntityIds.map((principalEntityId) => ({
     principal: {
       entityType: "VERIFIED_AUTHORIZER::Group",
       entityId: principalEntityId,
     },
     action: {
       actionType: "VERIFIED_AUTHORIZER::Action",
       actionId: actionName,
     },
     resource: {
       entityType: "VERIFIED_AUTHORIZER::Endpoint",
       entityId: resource,
     },
   }));
   const batchRequest = {
     requests,
     entities,
     policyStoreId,
   };
   console.log(`batch_request>>${JSON.stringify(batchRequest)}`);
   const command = new BatchIsAuthorizedCommand(batchRequest);
   const response = await vpClient.send(command);
   const results = response.results || [];
   console.log(`results>>${JSON.stringify(results)}`);
   for (const result of results) {
     const decision = result.decision;
     console.log(decision,"decissionn")
     if (decision === "ALLOW") {
       return generatePolicy('user', 'Allow', event.methodArn);
     }
   }
    return generatePolicy('user', 'Deny', event.methodArn);
   
 } catch (error) {
   console.error(`Error: ${error}`);
   return dependencies.utility.errorResponse(500, "Internal server error");
 }
};
