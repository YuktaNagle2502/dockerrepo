export default (dependencies) => async (event, context) => {
    const user_id = event.request.userAttributes.sub;
    console.log(event);
    let connection;
    try {
        connection = await dependencies.utility.getRDSConnection(process.env.SECRET_MANAGER);
        await connection.execute("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
        await connection.beginTransaction();
 
        const [groupResults] = await connection.execute(
            "SELECT group_id_fk FROM `user_group` WHERE `user_id_fk` = ?",
            [user_id]
        );
        const groupIds = groupResults.map(row => row.group_id_fk);
        console.log("Group IDs:", groupIds);
        if (groupIds.length > 0) {
            // Fetch group names
            const placeholders = groupIds.map(() => '?').join(',');
            const query = `SELECT group_name FROM \`groups\` WHERE \`group_id\` IN (${placeholders})`;
            const [nameResults] = await connection.execute(query, groupIds);
            const groupNames = nameResults.map(row => row.group_name);
            console.log("Group Names:", groupNames);
            // Attach group names to event response
            event.response = {
                "claimsAndScopeOverrideDetails": {
                    "idTokenGeneration": {},
                    "accessTokenGeneration": {
                        "claimsToAddOrOverride": {
                            "custom:groups": groupNames,
                        }
                    }
                }
            };
        }
        await connection.commit();
        console.log(event.response);
        context.done(null, event);
    } catch (error) {
        if (connection) {
            await connection.rollback();
        }
        console.error("Error during database operation:", error);
        context.done(null, event);
        const response = {
            statusCode: 500,
            body: JSON.stringify('InternalError'),
        };
        return response;
    } finally {
        if (connection) {
            await connection.close();
        }
    }
 };