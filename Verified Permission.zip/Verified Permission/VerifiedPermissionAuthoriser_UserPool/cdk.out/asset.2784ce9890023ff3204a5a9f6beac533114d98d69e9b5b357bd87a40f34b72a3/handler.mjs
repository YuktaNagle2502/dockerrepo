import {
  VerifiedPermissionsClient,
  BatchIsAuthorizedCommand,
} from "@aws-sdk/client-verifiedpermissions";
// import { AWS } from "@aws-sdk";
import fetch from 'node-fetch';
import jwt from "jsonwebtoken";
import jwkToPem from "jwk-to-pem";
//import { CognitoIdentityProviderClient, GetUserCommand } from "@aws-sdk/client-cognito-identity-provider";
//const client = new CognitoIdentityProviderClient({ region: "us-east-2" });

const vpClient = new VerifiedPermissionsClient();
const generatePolicy = (principalId, effect, resource) => {
  const policyDocument = {
    Version: "2012-10-17",
    Statement: [
      {
        Action: "execute-api:Invoke",
        Effect: effect,
        Resource: resource,
      },
    ],
  };
  return {
    principalId,
    policyDocument,
    context: {
      exampleKey: "exampleValue",
    },
  };
};

export default (dependencies) => async (event, context) => {
  console.log(event);
  try {
    const policyStoreId = process.env.policyStoreId;
    if (!policyStoreId) {
      return dependencies.utility.errorResponse(
        500,
        "Missing policyStoreId environment variable"
      );
    }
    console.log(policyStoreId);
    const methodName = event.httpMethod;
    console.log(methodName);
    const apiName = event.requestContext?.resourcePath;
    console.log(apiName);
    const operationId = event.requestContext?.operationName;
    const actionName = `${methodName} ${apiName} ${operationId}`;
    console.log(actionName);
    const token = event.headers.Authorization;
    if (!token) {
      return dependencies.utility.errorResponse(
        400,
        "Missing token in request body"
      );
    }

    const decoded = jwt.decode(token, { complete: true });

    if (!decoded || !decoded.header || !decoded.header.kid) {
      return dependencies.utility.errorResponse(400, "Invalid token");
   }
    const jwksUrl = 'https://cognito-idp.us-east-2.amazonaws.com/us-east-2_lBqCdI9Wy/.well-known/jwks.json'; 
    const jwksResponse = await fetch(jwksUrl);
    const jwks = await jwksResponse.json();
    const jwk = jwks.keys.find(key => key.kid === kid);
    const pem = jwkToPem(jwk);
    const { kid } = decoded.header;

    jwt.verify(
      token,
      pem,
      { algorithms: ["RS256"] },
      function (err, decoded) {
        if (err) {
       // Token verification failed
       return dependencies.utility.errorResponse(401, "Token verification failed");
   }
   console.log("Verified Token:", decoded)
      }
    );
    //  const params = {
    //      AccessToken: token
    //  };
    try {
      //const command = new GetUserCommand(params);
      //const response = await client.send(command);
    } catch (error) {
      if (error.code === "NotAuthorizedException") {
        return generatePolicy("user", "Deny", event.methodArn);
      } else {
        return generatePolicy("user", "Deny", event.methodArn);
      }
    }

    console.log("decoded - " + JSON.stringify(decoded));
    const principalEntityIds = decoded?.payload["custom:groups"] || [];
    console.log("principalEntityIds - " + JSON.stringify(principalEntityIds));
    if (principalEntityIds === undefined || principalEntityIds.length === 0) {
      console.log("principalEntityIds is undefined");
      return generatePolicy("user", "Deny", event.methodArn);
    }
    const domainName = event.requestContext.domainName;
    const stage = event.requestContext.stage;
    const resource = `https://${domainName}/${stage}`;
    console.log("resource", resource);
    if (!resource) {
      return dependencies.utility.errorResponse(
        400,
        "Missing resource in request body"
      );
    }
    const entities = {
      entityList: [
        {
          identifier: {
            entityId: resource,
            entityType: "VERIFIED_AUTHORIZER::Endpoint",
          },
        },
      ],
    };
    const requests = principalEntityIds.map((principalEntityId) => ({
      principal: {
        entityType: "VERIFIED_AUTHORIZER::Group",
        entityId: principalEntityId,
      },
      action: {
        actionType: "VERIFIED_AUTHORIZER::Action",
        actionId: actionName,
      },
      resource: {
        entityType: "VERIFIED_AUTHORIZER::Endpoint",
        entityId: resource,
      },
    }));
    const batchRequest = {
      requests,
      entities,
      policyStoreId,
    };
    console.log(`batch_request>>${JSON.stringify(batchRequest)}`);
    const command = new BatchIsAuthorizedCommand(batchRequest);
    const response = await vpClient.send(command);
    const results = response.results || [];
    console.log(`results>>${JSON.stringify(results)}`);
    for (const result of results) {
      const decision = result.decision;
      console.log(decision, "decissionn");
      if (decision === "ALLOW") {
        return generatePolicy("user", "Allow", event.methodArn);
      }
    }
    return generatePolicy("user", "Deny", event.methodArn);
  } catch (error) {
    console.error(`Error: ${error}`);
    return dependencies.utility.errorResponse(500, "Internal server error");
  }
};
