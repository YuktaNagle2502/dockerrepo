
export default (dependencies) => async (event) => {
  // TODO implement
   const user_id= event.request.userAttributes.sub;
  console.log(event)
  let connection;
        try {
            connection = await dependencies.utility.getRDSConnection(process.env.SECRET_MANAGER);
            await connection.execute("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
            await connection.beginTransaction();
        const [result] = await connection.execute(
            "SELECT group_id_fk FROM `user_group` WHERE `user_id_fk` = ?",
            [user_id]
        );
            event.request.userAttributes['groups']=result;
            console.log("List Group Result:", result);
            await connection.commit();
           const response = {
    statusCode: 200,
    body: JSON.stringify(event),
  };
  return response;
        } catch (error) {
            if (connection) {
                await connection.rollback();
            }
            console.error("Error during database operation:", error);
            const response = {
    statusCode: 500,
    body: JSON.stringify('InternalError'),
  };
  return response;
        } finally {
            if (connection) {
                await connection.close(); 
            }}
  
};
