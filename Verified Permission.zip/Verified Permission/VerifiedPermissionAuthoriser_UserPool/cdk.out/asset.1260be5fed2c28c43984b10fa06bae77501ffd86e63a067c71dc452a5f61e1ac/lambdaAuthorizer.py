import boto3
import json
import os
 
def lambda_handler(event, context):
    vp_client = boto3.client('verifiedpermissions')
    
    # policyStoreId = '94HVj8RRrtniCzBNUB3L41'
    policyStoreId = os.environ['policyStoreId']
    print(event)
    methodName = event.httpMethod
    apiName =  event.requestContext.resourcePath
    operationId =  event.requestContext.operationId
    actionName = methodName+' /'+apiName+' '+operationId
    
    principalEntityIds = event['groups']
    resource = event['resource']
    entities = {
        'entityList': [
            {
                'identifier': {
                     'entityId': resource,
                     'entityType':'VERIFIED_PERMISSIONS::Endpoint'
                }
                }]
    }
    
    requests = []
    
    # List policies
    for principalEntityId in principalEntityIds:
        request = {
                'principal': {
                    'entityType': 'VERIFIED_PERMISSIONS::Group',
                    'entityId': principalEntityId
                },
                'action': {
                    'actionType': 'VERIFIED_PERMISSIONS::Action',
                    'actionId': actionName
                },
                'resource': {
                    'entityType': 'VERIFIED_PERMISSIONS::Endpoint',
                    'entityId': resource
                }
            }
        requests.append(request)
    

    batch_request = {
        'requests': requests,
        'entities': entities,
        'policyStoreId': policyStoreId
    }
    print(f"batch_request>>{batch_request}" )
    response = vp_client.batch_is_authorized(**batch_request)
 
    results = response['results']
    print(f"results>>{results}")
 
    for result in results:
        request = result['request']
        decision = result['decision']
        if decision=='ALLOW':
            return {
                'statusCode': 200,
                'body': json.dumps('ALLOW')
            }
      
    return {
        'statusCode': 401,
        'body': json.dumps('DENY')
    }