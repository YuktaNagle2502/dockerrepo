import {
  VerifiedPermissionsClient,
  BatchIsAuthorizedCommand,
} from "@aws-sdk/client-verifiedpermissions";
import jwt from "jsonwebtoken";
import jwkToPem from "jwk-to-pem";
import fetch from 'node-fetch';

const vpClient = new VerifiedPermissionsClient();
const generatePolicy = (principalId, effect, resource) => {
  const policyDocument = {
    Version: "2012-10-17",
    Statement: [
      {
        Action: "execute-api:Invoke",
        Effect: effect,
        Resource: resource,
      },
    ],
  };
  return {
    principalId,
    policyDocument,
    context: {
      exampleKey: "exampleValue",
    },
  };
};

export default (dependencies) => async (event, context) => {
  console.log(event);
  try {
    const policyStoreId = process.env.policyStoreId;
    if (!policyStoreId) {
      return generatePolicy("user", "Deny", event.methodArn);
    }
    const methodName = event.httpMethod;
    const apiName = event.requestContext?.resourcePath;
    const operationId = event.requestContext?.operationName;
    const actionName = `${methodName} ${apiName} ${operationId}`;
    const token = event.headers.Authorization;
    if (!token) {
      return generatePolicy("user", "Deny", event.methodArn);
    }

    const decoded = jwt.decode(token, { complete: true });
    const { kid } = decoded.header;

    if (!decoded || !decoded.header || !decoded.header.kid) {
      return generatePolicy("user", "Deny", event.methodArn);
    }
    const jwksUrl =
      "https://cognito-idp.us-east-2.amazonaws.com/us-east-2_lBqCdI9Wy/.well-known/jwks.json";
    const jwksResponse = await fetch(jwksUrl);
    const jwks = await jwksResponse.json();
    const jwk = jwks.keys.find((key) => key.kid === kid);
    const pem = jwkToPem(jwk);

    jwt.verify(token, pem, { algorithms: ["RS256"] }, function (err, decoded) {
      if (err) {
        return generatePolicy("user", "Deny", event.methodArn);
      }
    });

    const principalEntityIds = decoded?.payload["custom:groups"] || [];
    if (principalEntityIds === undefined || principalEntityIds.length === 0) {
      return generatePolicy("user", "Deny", event.methodArn);
    }
    const domainName = event.requestContext.domainName;
    const stage = event.requestContext.stage;
    const resource = `https://${domainName}/${stage}`;
    if (!resource) {
      return generatePolicy("user", "Deny", event.methodArn);
    }
    const entities = {
      entityList: [
        {
          identifier: {
            entityId: resource,
            entityType: "VERIFIED_AUTHORIZER::Endpoint",
          },
        },
      ],
    };
    const requests = principalEntityIds.map((principalEntityId) => ({
      principal: {
        entityType: "VERIFIED_AUTHORIZER::Group",
        entityId: principalEntityId,
      },
      action: {
        actionType: "VERIFIED_AUTHORIZER::Action",
        actionId: actionName,
      },
      resource: {
        entityType: "VERIFIED_AUTHORIZER::Endpoint",
        entityId: resource,
      },
    }));
    const batchRequest = {
      requests,
      entities,
      policyStoreId,
    };
    const command = new BatchIsAuthorizedCommand(batchRequest);
    const response = await vpClient.send(command);
    const results = response.results || [];
    for (const result of results) {
      const decision = result.decision;
      if (decision === "ALLOW") {
        return generatePolicy("user", "Allow", event.methodArn);
      }
    }
    return generatePolicy("user", "Deny", event.methodArn);
  } catch (error) {
    return generatePolicy("user", "Deny", event.methodArn);
  }
};
