 
 
import httpx
import time
import jwt
from jwt.exceptions import ExpiredSignatureError, InvalidTokenError
from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.security.utils import get_authorization_scheme_param
import logging, time
logger = logging.getLogger("main")
# In-memory cache for JWKS per issuer
JWKS_CACHE = {}  # Key: issuer, Value: {"jwks_uri": ..., "fetched_at": timestamp}
JWKS_TTL = 3600  # 1 hour

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",  # or specific origin
    "Access-Control-Allow-Methods": "*",
    "Access-Control-Allow-Headers": "*",
}

class KeycloakAuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        method = request.method
        if method == "OPTIONS":
            return JSONResponse(
                status_code=200,
                content={"message": "CORS preflight"},
                headers=CORS_HEADERS,
            )
        print("path print", path)
        # Public paths allowed without auth
        if (
            path == "/" or
            path.startswith("/docs") or
            path.startswith("/openapi.json")
        ):
            response = await call_next(request)
            return response
 
        auth_header = request.headers.get("Authorization")
        if not auth_header:
            return JSONResponse(status_code=401, content={"detail": "Missing Authorization Header"})
 
        scheme, token = get_authorization_scheme_param(auth_header)
        if scheme.lower() != "bearer" or not token:
            return JSONResponse(status_code=401, content={"detail": "Invalid Authorization Header"})
 
        try:
            # Decode unverified token to extract issuer
            unverified_payload = jwt.decode(token, options={"verify_signature": False})
            issuer = unverified_payload.get("iss")
            client_id = unverified_payload.get("azp")
            if not issuer or not issuer.startswith("https://sso.yashtech.link/realms/"):
                return JSONResponse(status_code=403, content={"detail": "Untrusted token issuer"})
 
            # Get JWKS URI for issuer (cached or fetched)
            jwks_uri = await get_jwks_uri_for_issuer(issuer)
 
            # Use PyJWKClient with JWKS URI to get signing key
            jwk_client = jwt.PyJWKClient(jwks_uri)
            signing_key = jwk_client.get_signing_key_from_jwt(token).key
 
            # Fully decode and validate token
            payload = jwt.decode(
                token,
                signing_key,
                algorithms=["RS256"],
                audience="account",  # Optionally: dynamically read expected audience
                issuer=issuer
            )
            request.state.user = payload
 
        except ExpiredSignatureError:
            return JSONResponse(status_code=401, content={"detail": "Token has expired"})
        except InvalidTokenError:
            return JSONResponse(status_code=401, content={"detail": "Invalid token"})
        except Exception as e:
            return JSONResponse(status_code=400, content={"detail": f"Token processing failed: {str(e)}"})
 
        response = await call_next(request)
        return response
 
# JWKS discovery and caching
async def get_jwks_uri_for_issuer(issuer: str) -> str:
    now = time.time()
    cache = JWKS_CACHE.get(issuer)
 
    if cache and now - cache["fetched_at"] < JWKS_TTL:
        return cache["jwks_uri"]
 
    async with httpx.AsyncClient() as client:
        discovery_url = f"{issuer}/.well-known/openid-configuration"
        discovery_res = await client.get(discovery_url)
        if discovery_res.status_code != 200:
            raise Exception(f"Failed to fetch OpenID config for issuer: {issuer}")
 
        jwks_uri = discovery_res.json()["jwks_uri"]
 
    JWKS_CACHE[issuer] = {"jwks_uri": jwks_uri, "fetched_at": now}
    return jwks_uri
 