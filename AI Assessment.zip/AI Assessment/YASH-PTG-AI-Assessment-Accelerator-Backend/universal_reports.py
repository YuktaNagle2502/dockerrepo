from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, LargeBinary
from sqlalchemy.orm import relationship, Session
from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List, Union
from database import Base
import uuid
import io
from models.models import User, Project,Report

# Pydantic Models
class ReportCreate(BaseModel):
    """Model for creating a new report"""
    user_id: int
    project_id: int
    module_name: str
    module_entity_id: int
    report_name: str
    report_type: str
    file_content: bytes
    mime_type: Optional[str] = None

class ReportResponse(BaseModel):
    """Model for report response"""
    id: int
    report_uuid: str
    user_id: int
    project_id: int
    module_name: str
    module_entity_id: int
    report_name: str
    report_type: str
    file_size: int
    mime_type: str
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class ReportListItem(BaseModel):
    """Simplified model for report listing"""
    id: int
    report_uuid: str
    module_name: str
    module_entity_id: int
    report_name: str
    report_type: str
    file_size: int
    created_at: datetime
    
    class Config:
        from_attributes = True

# Universal Report Manager Class
class UniversalReportManager:
    """Universal report storage and retrieval manager"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def save_report(
        self, 
        user_id: int,
        project_id: int,
        module_name: str,
        module_entity_id: int,
        report_name: str,
        file_content: Union[bytes, io.BytesIO],
        report_type: str = "pdf",
        mime_type: Optional[str] = None
    ) -> Report:
        """
        Save a report to the database
        
        Args:
            user_id: ID of the user creating the report
            project_id: ID of the associated project
            module_name: Name of the module (e.g., "pre_workshop")
            module_entity_id: ID of the entity within the module (e.g., session_id)
            report_name: Human-readable name for the report
            file_content: Report content as bytes or BytesIO
            report_type: Type of report (pdf, json, xlsx, html)
            mime_type: MIME type (auto-detected if not provided)
        
        Returns:
            Created or updated Report object
        """
        # Handle BytesIO objects
        if isinstance(file_content, io.BytesIO):
            file_content.seek(0)
            content_bytes = file_content.read()
        else:
            content_bytes = file_content
        
        # Auto-detect MIME type if not provided
        if not mime_type:
            mime_type = self._get_mime_type(report_type)
        
        # Generate unique UUID for the report
        report_uuid = str(uuid.uuid4())
        
        # Check if report already exists for this module entity
        existing_report = self.db.query(Report).filter(
            Report.user_id == user_id,
            Report.project_id == project_id,
            Report.module_name == module_name,
            Report.module_entity_id == module_entity_id,
            Report.report_type == report_type,
            Report.is_active == True
        ).first()
        
        if existing_report:
            # Update existing report
            existing_report.file_content = content_bytes
            existing_report.file_size = len(content_bytes)
            existing_report.report_name = report_name
            existing_report.mime_type = mime_type
            existing_report.updated_at = datetime.utcnow()
            self.db.commit()
            self.db.refresh(existing_report)
            return existing_report
        else:
            # Create new report
            new_report = Report(
                report_uuid=report_uuid,
                user_id=user_id,
                project_id=project_id,
                module_name=module_name,
                module_entity_id=module_entity_id,
                report_name=report_name,
                report_type=report_type,
                file_content=content_bytes,
                file_size=len(content_bytes),
                mime_type=mime_type
            )
            self.db.add(new_report)
            self.db.commit()
            self.db.refresh(new_report)
            return new_report
    
    def get_report_by_uuid(self, report_uuid: str, user_id: int) -> Optional[Report]:
        """Get a report by its UUID (with user access check)"""
        return self.db.query(Report).filter(
            Report.report_uuid == report_uuid,
            Report.user_id == user_id,
            Report.is_active == True
        ).first()
    
    def get_reports_by_module(
        self, 
        user_id: int, 
        module_name: str, 
        module_entity_id: Optional[int] = None,
        project_id: Optional[int] = None
    ) -> List[Report]:
        """Get all reports for a specific module"""
        query = self.db.query(Report).filter(
            Report.user_id == user_id,
            Report.module_name == module_name,
            Report.is_active == True
        )
        if module_entity_id is not None:
            query = query.filter(Report.module_entity_id == module_entity_id)
        if project_id is not None:
            query = query.filter(Report.project_id == project_id)
        return query.order_by(Report.created_at.desc()).all()
    
    def get_reports_by_project(self, user_id: int, project_id: int) -> List[Report]:
        """Get all reports for a specific project"""
        return self.db.query(Report).filter(
            Report.user_id == user_id,
            Report.project_id == project_id,
            Report.is_active == True
        ).order_by(Report.created_at.desc()).all()
    
    def get_user_reports(self, user_id: int, limit: int = 50) -> List[Report]:
        """Get all reports for a user"""
        return self.db.query(Report).filter(
            Report.user_id == user_id,
            Report.is_active == True
        ).order_by(Report.created_at.desc()).limit(limit).all()
    
    def delete_report(self, report_uuid: str, user_id: int) -> bool:
        """Soft delete a report"""
        report = self.get_report_by_uuid(report_uuid, user_id)
        if report:
            report.is_active = False
            report.updated_at = datetime.utcnow()
            self.db.commit()
            return True
        return False
    
    def get_report_content(self, report_uuid: str, user_id: int) -> Optional[bytes]:
        """Get the binary content of a report"""
        report = self.get_report_by_uuid(report_uuid, user_id)
        if report:
            return report.file_content
        return None
    
    def _get_mime_type(self, report_type: str) -> str:
        """Get MIME type based on report type"""
        mime_map = {
            "pdf": "application/pdf",
            "json": "application/json",
            "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "xls": "application/vnd.ms-excel",
            "html": "text/html",
            "txt": "text/plain",
            "csv": "text/csv",
            "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        }
        return mime_map.get(report_type.lower(), "application/octet-stream")

# Helper Functions for Integration
def save_module_report(
    db: Session,
    user_id: int,
    project_id: int,
    module_name: str,
    module_entity_id: int,
    report_name: str,
    file_content: Union[bytes, io.BytesIO],
    report_type: str = "pdf"
) -> Report:
    """
    Convenience function to save a report from any module
    
    Usage in modules:
    report = save_module_report(
        db=db,
        user_id=current_user.id,
        project_id=session.project_id,
        module_name="pre_workshop",
        module_entity_id=session_id,
        report_name=f"Pre-Workshop Report - {session.session_name}",
        file_content=pdf_content,
        report_type="pdf"
    )
    """
    manager = UniversalReportManager(db)
    return manager.save_report(
        user_id=user_id,
        project_id=project_id,
        module_name=module_name,
        module_entity_id=module_entity_id,
        report_name=report_name,
        file_content=file_content,
        report_type=report_type
    )

def get_module_reports(
    db: Session,
    user_id: int,
    module_name: str,
    module_entity_id: Optional[int] = None,
    project_id: Optional[int] = None
) -> List[ReportListItem]:
    """
    Convenience function to get reports for a module
    
    Usage:
    reports = get_module_reports(
        db=db,
        user_id=current_user.id,
        module_name="pre_workshop",
        module_entity_id=session_id
    )
    """
    manager = UniversalReportManager(db)
    reports = manager.get_reports_by_module(
        user_id=user_id,
        module_name=module_name,
        module_entity_id=module_entity_id,
        project_id=project_id
    )
    return [
        ReportListItem(
            id=report.id,
            report_uuid=report.report_uuid,
            module_name=report.module_name,
            module_entity_id=report.module_entity_id,
            report_name=report.report_name,
            report_type=report.report_type,
            file_size=report.file_size,
            created_at=report.created_at
        )
        for report in reports
    ]