from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional, List
from fastapi import Response
from fastapi.responses import JSONResponse
from pydantic import Field,ConfigDict
from typing import Any

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: int
    email: str
    full_name: str
    is_active: bool
    created_at: datetime
    
    class Config:
        from_attributes = True

class ProjectCreate(BaseModel):
    name: str
    description: Optional[str] = None

class ProjectResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    owner_id: int
    is_active: bool
    created_at: datetime
    
    class Config:
        from_attributes = True

class ProjectWithOwner(ProjectResponse):
    owner: UserResponse

class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse

class LoginResponse(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse
    message: str

class StandardResponse(BaseModel):
    """
    Standard response model for API responses
    """
    model_config = ConfigDict(
        json_encoders={
            datetime: lambda v: v.isoformat()
        },
        json_schema_extra={
            "example": {
                "success": True,
                "message": "Operation completed successfully",
                "data": {"id": 1, "name": "example"},
                "error": None
            }
        }
    )
    success: bool = Field(..., description="Indicates if the operation was successful")
    message: str = Field(..., description="Response message")
    data: Optional[Any] = Field(None, description="Optional data payload")
    error: Optional[Any] = Field(None, description="Optional error information")

def standard_response(status_code: int, success: bool, message: str, data: Optional[Any] = None, error: Optional[Any] = None) -> JSONResponse:
    """
    Standard response function for FastAPI responses
    
    Args:
        status_code: HTTP status code
        success: Boolean indicating success/failure
        message: Response message
        data: Optional data payload
        error: Optional error information
    
    Returns:
        FastAPI JSONResponse with specified status code
    """
    response_model = StandardResponse(
        success=success,
        message=message,
        data=data,
        error=error
    )
    
    # Use model_dump with mode='json' to handle datetime serialization
    return JSONResponse(content=response_model.model_dump(mode='json'), status_code=status_code)
