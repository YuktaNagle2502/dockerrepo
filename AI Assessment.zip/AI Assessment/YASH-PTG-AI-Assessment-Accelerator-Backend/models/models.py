# from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Text, JSON, LargeBinary
# from sqlalchemy.orm import relationship
# from database import Base
# from datetime import datetime

# class User(Base):
#     __tablename__ = "users"
#     id = Column(Integer, primary_key=True, index=True)
#     email = Column(String, unique=True, index=True, nullable=False)
#     hashed_password = Column(String, nullable=False)
#     full_name = Column(String, nullable=False)
#     is_active = Column(Boolean, default=True)
#     created_at = Column(DateTime, default=datetime.utcnow)
#     updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
#     projects = relationship("Project", back_populates="owner")

# class Project(Base):
#     __tablename__ = "projects"
#     id = Column(Integer, primary_key=True, index=True)
#     name = Column(String, nullable=False)
#     description = Column(Text)
#     owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
#     is_active = Column(Boolean, default=True)
#     created_at = Column(DateTime, default=datetime.utcnow)
#     updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
#     owner = relationship("User", back_populates="projects")
#     pre_workshop_sessions = relationship("PreWorkshopSession", back_populates="project")

# class PreWorkshopSession(Base):
#     __tablename__ = "pre_workshop_sessions"
#     id = Column(Integer, primary_key=True, index=True)
#     project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
#     session_name = Column(String, nullable=False)
#     description = Column(Text)
#     status = Column(String, default="draft")
#     excel_file_path = Column(String)
#     created_at = Column(DateTime, default=datetime.utcnow)
#     updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
#     project = relationship("Project", back_populates="pre_workshop_sessions")
#     questionnaire_responses = relationship("QuestionnaireResponse", back_populates="session")
#     generated_use_cases = relationship("GeneratedUseCase", back_populates="session")

# class QuestionnaireResponse(Base):
#     __tablename__ = "questionnaire_responses"
#     id = Column(Integer, primary_key=True, index=True)
#     session_id = Column(Integer, ForeignKey("pre_workshop_sessions.id"), nullable=False)
#     category = Column(String)
#     question = Column(Text, nullable=False)
#     description = Column(Text)
#     response = Column(Text, nullable=False)
#     additional_notes = Column(Text)
#     created_at = Column(DateTime, default=datetime.utcnow)
#     session = relationship("PreWorkshopSession", back_populates="questionnaire_responses")

# class GeneratedUseCase(Base):
#     __tablename__ = "generated_use_cases"
    
#     id = Column(Integer, primary_key=True, index=True)
#     session_id = Column(Integer, ForeignKey("pre_workshop_sessions.id"), nullable=False)
#     title = Column(String, nullable=False)
#     description = Column(Text, nullable=False)
#     aws_services = Column(JSON)  # List of AWS services
#     primary_genai_capability = Column(String)
#     business_category = Column(String)
#     customer_pain_points = Column(JSON)  # List of pain points
#     priority = Column(String)  # High/Medium/Low
#     complexity = Column(String)  # High/Medium/Low
#     estimated_effort = Column(String)
#     success_metrics = Column(JSON)  # List of metrics
#     aws_architecture = Column(Text)
#     cost_estimate = Column(String)
#     dependencies = Column(JSON)  # List of dependencies
#     risks = Column(JSON)  # List of risks
#     roi_potential = Column(String)  # High/Medium/Low
#     implementation_phases = Column(JSON)  # List of phases
#     is_selected = Column(Boolean, default=False)
#     created_at = Column(DateTime, default=datetime.utcnow)
#     # Relationships
#     session = relationship("PreWorkshopSession", back_populates="generated_use_cases")

# class Report(Base):
#     __tablename__ = "reports"
#     id = Column(Integer, primary_key=True, index=True)
#     report_uuid = Column(String, unique=True, index=True, nullable=False)
#     user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
#     project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
#     module_name = Column(String, nullable=False)
#     module_entity_id = Column(Integer, nullable=False)
#     report_name = Column(String, nullable=False)
#     report_type = Column(String, nullable=False)
#     file_content = Column(LargeBinary, nullable=False)
#     file_size = Column(Integer, nullable=False)
#     mime_type = Column(String, nullable=False)
#     is_active = Column(Boolean, default=True)
#     created_at = Column(DateTime, default=datetime.utcnow)
#     updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
#     user = relationship("User")
#     project = relationship("Project")

from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, Date, Numeric, ForeignKey, LargeBinary, ARRAY
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import JSON
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    email = Column(String, nullable=False, unique=True, index=True)
    hashed_password = Column(String)
    full_name = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    projects = relationship("Project", back_populates="owner")
    reports = relationship("Report", back_populates="user")


class Project(Base):
    __tablename__ = 'projects'
    
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    name = Column(String, nullable=False)
    description = Column(Text)
    owner_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    owner = relationship("User", back_populates="projects")
    reports = relationship("Report", back_populates="project")
    pre_workshop_sessions = relationship("PreWorkshopSession", back_populates="project")


class Report(Base):
    __tablename__ = 'reports'
    
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    report_uuid = Column(String, nullable=False, unique=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False)
    module_name = Column(String, nullable=False)
    module_entity_id = Column(Integer, nullable=False)
    report_name = Column(String, nullable=False)
    report_type = Column(String, nullable=False)
    file_content = Column(LargeBinary, nullable=False)
    file_size = Column(Integer, nullable=False)
    mime_type = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="reports")
    project = relationship("Project", back_populates="reports")


class PreWorkshopSession(Base):
    __tablename__ = 'pre_workshop_sessions'
    
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False)
    session_name = Column(String, nullable=False)
    description = Column(Text)
    status = Column(String)
    excel_file_path = Column(String)
    questionnaire_file_path = Column(Text)
    report_file_path = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    project = relationship("Project", back_populates="pre_workshop_sessions")
    questionnaire_responses = relationship("QuestionnaireResponse", back_populates="session")
    generated_use_cases = relationship("GeneratedUseCase", back_populates="session")


class QuestionnaireResponse(Base):
    __tablename__ = 'questionnaire_responses'
    
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    session_id = Column(Integer, ForeignKey('pre_workshop_sessions.id'), nullable=False)
    category = Column(String)
    question = Column(Text, nullable=False)
    description = Column(Text)
    response = Column(Text, nullable=False)
    additional_notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    session = relationship("PreWorkshopSession", back_populates="questionnaire_responses")


class GeneratedUseCase(Base):
    __tablename__ = 'generated_use_cases'
    
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    session_id = Column(Integer, ForeignKey('pre_workshop_sessions.id'), nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    aws_services = Column(JSON)
    primary_genai_capability = Column(String)
    business_category = Column(String)
    customer_pain_points = Column(JSON)
    priority = Column(String)
    complexity = Column(String)
    estimated_effort = Column(String)
    success_metrics = Column(JSON)
    aws_architecture = Column(Text)
    cost_estimate = Column(String)
    dependencies = Column(JSON)
    risks = Column(JSON)
    roi_potential = Column(String)
    implementation_phases = Column(JSON)
    is_selected = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    data_readiness_status = Column(String(50), default='Pending', nullable=True)
    data_compliance_status = Column(String(50), default='Pending', nullable=True)
    ai_profiling_status = Column(String(50), default='Pending', nullable=True)
    model_evaluation_status = Column(String(50), default='Pending', nullable=True)
    sprint_planning_status = Column(String(50), default='Pending', nullable=True)
    justification = Column(Text, nullable=True)
    
    # Relationships
    session = relationship("PreWorkshopSession", back_populates="generated_use_cases")
    assessment_reports = relationship("AssessmentReport", back_populates="use_case")
    data_compliance = relationship("DataCompliance", back_populates="use_case")
    data_readiness = relationship("DataReadiness", back_populates="use_case")
    model_evaluation = relationship("ModelEvaluation", back_populates="use_case")
    sprint_planning = relationship("SprintPlanning", back_populates="use_case")
    ai_profiling = relationship("AIProfiling", back_populates="use_case")


class AssessmentReport(Base):
    __tablename__ = 'assessment_reports'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    usecase_id = Column(Integer, ForeignKey('generated_use_cases.id'))
    assessment_stage = Column(String(50))
    report_type = Column(String(50))
    report_mimetype = Column(String(100))
    report_filename = Column(Text)
    report_path = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    use_case = relationship("GeneratedUseCase", back_populates="assessment_reports")


class DataCompliance(Base):
    __tablename__ = 'data_compliance'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    usecase_id = Column(Integer, ForeignKey('generated_use_cases.id'))
    overall_score = Column(Numeric(5, 2))
    risk_level = Column(Text)
    analysis_type = Column(String(50))
    analysis_report_text_md = Column(Text)
    risk_assessment_text_md = Column(JSON)
    generated_pdf_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    generated_json_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    generated_excel_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    recommendation_count=Column(Numeric(5, 2))
    # Relationships
    use_case = relationship("GeneratedUseCase", back_populates="data_compliance")
    pdf_report = relationship("AssessmentReport", foreign_keys=[generated_pdf_report_id])
    json_report = relationship("AssessmentReport", foreign_keys=[generated_json_report_id])
    excel_report = relationship("AssessmentReport", foreign_keys=[generated_excel_report_id])
    documents = relationship("DataComplianceDocument", back_populates="data_compliance")


class DataComplianceDocument(Base):
    __tablename__ = 'data_compliance_documents'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    data_compliance_id = Column(Integer, ForeignKey('data_compliance.id'))
    filename = Column(String(255))
    mimetype = Column(String(50))
    path = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    data_compliance = relationship("DataCompliance", back_populates="documents")


class DataReadiness(Base):
    __tablename__ = 'data_readiness'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    usecase_id = Column(Integer, ForeignKey('generated_use_cases.id'))
    assessment_depth = Column(String(255))
    is_generate_improvement_recommendations = Column(Boolean)
    is_include_compliance_assessment = Column(Boolean)
    is_include_ai_powered_analysis = Column(Boolean)
    readiness_score_count = Column(Numeric(5, 2))
    requirements_met_count = Column(Integer)
    data_quality_issues_count = Column(Integer)
    overall_status_text = Column(String(255))
    data_quality_issues = Column(Text)
    recommendations = Column(Text)
    analysis_report_text_md = Column(Text)
    analysis_type = Column(String(50))
    generated_pdf_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    generated_json_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    generated_excel_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    use_case = relationship("GeneratedUseCase", back_populates="data_readiness")
    pdf_report = relationship("AssessmentReport", foreign_keys=[generated_pdf_report_id])
    json_report = relationship("AssessmentReport", foreign_keys=[generated_json_report_id])
    excel_report = relationship("AssessmentReport", foreign_keys=[generated_excel_report_id])
    documents = relationship("DataReadinessDocument", back_populates="data_readiness")


class DataReadinessDocument(Base):
    __tablename__ = 'data_readiness_documents'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    data_readiness_id = Column(Integer, ForeignKey('data_readiness.id'))
    filename = Column(String(255))
    mimetype = Column(String(50))
    path = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    data_readiness = relationship("DataReadiness", back_populates="documents")


class LLMModel(Base):
    __tablename__ = 'llm_models'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    llm_provider = Column(String(255))
    model_code = Column(String(255))
    is_support_llm_as_judge = Column(Boolean)
    is_default = Column(Boolean)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    selected_models = relationship("SelectedModel", back_populates="llm_model")


class ModelEvaluation(Base):
    __tablename__ = 'model_evaluation'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    usecase_id = Column(Integer, ForeignKey('generated_use_cases.id'))
    model_tested_count = Column(Integer)
    test_cases_count = Column(Integer)
    average_accuracy = Column(Numeric(5, 2))
    best_model = Column(String(255))
    evaluation_summary_md = Column(Text)
    generated_pdf_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    generated_json_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    generated_excel_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    use_case = relationship("GeneratedUseCase", back_populates="model_evaluation")
    pdf_report = relationship("AssessmentReport", foreign_keys=[generated_pdf_report_id])
    json_report = relationship("AssessmentReport", foreign_keys=[generated_json_report_id])
    excel_report = relationship("AssessmentReport", foreign_keys=[generated_excel_report_id])
    selected_models = relationship("SelectedModel", back_populates="model_evaluation")
    model_rankings = relationship("ModelRanking", back_populates="model_evaluation")
    test_cases = relationship("TestCase", back_populates="model_evaluation")


class SelectedModel(Base):
    __tablename__ = 'selected_models'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    model_evaluation_id = Column(Integer, ForeignKey('model_evaluation.id'))
    llm_model_id = Column(Integer, ForeignKey('llm_models.id'))
    llm_key = Column(Text)
    use_llm_as_judge = Column(Boolean)
    timeout = Column(Integer)
    temperature = Column(Numeric(5, 2))
    max_retries = Column(Integer)
    max_tokens = Column(Integer)
    is_selected_for_evaluation = Column(Boolean)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    model_evaluation = relationship("ModelEvaluation", back_populates="selected_models")
    llm_model = relationship("LLMModel", back_populates="selected_models")


class ModelRanking(Base):
    __tablename__ = 'model_ranking'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    model_evaluation_id = Column(Integer, ForeignKey('model_evaluation.id'))
    rank = Column(Integer)
    model = Column(String(255))
    average_score = Column(Numeric(5, 2))
    binary_score = Column(Numeric(5, 2))
    average_response_time = Column(Numeric(5, 4))
    llm_judge_score = Column(Numeric(5, 2))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    model_evaluation = relationship("ModelEvaluation", back_populates="model_rankings")
    test_case_results = relationship("TestCaseResult", back_populates="model_ranking")


class PredefinedTestCase(Base):
    __tablename__ = 'predefined_test_cases'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    test_prompt = Column(Text)
    expected_answer = Column(Text)
    test_category = Column(String(255))
    difficulty_level = Column(String(50))
    evaluation_criteria = Column(ARRAY(String))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class TestCase(Base):
    __tablename__ = 'test_cases'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    model_evaluation_id = Column(Integer, ForeignKey('model_evaluation.id'))
    test_prompt = Column(Text)
    expected_answer = Column(Text)
    test_category = Column(String(255))
    difficulty_level = Column(String(50))
    evaluation_criteria = Column(ARRAY(String))
    test_case_type = Column(String(50))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    model_evaluation = relationship("ModelEvaluation", back_populates="test_cases")


class TestCaseResult(Base):
    __tablename__ = 'test_case_result'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    model_ranking_id = Column(Integer, ForeignKey('model_ranking.id'))
    test = Column(Text)
    is_correct = Column(Boolean)
    score = Column(Numeric(5, 2))
    response_time = Column(Numeric(5, 4))
    status = Column(String(50))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    response=Column(Text)
    judge_explanation=Column(Text)
    # Relationships
    model_ranking = relationship("ModelRanking", back_populates="test_case_results")


class Developer(Base):
    __tablename__ = 'developers'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    developer_title = Column(String(50))
    developer_tech_stack = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class SprintPlanning(Base):
    __tablename__ = 'sprint_planning'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    usecase_id = Column(Integer, ForeignKey('generated_use_cases.id'))
    project_type = Column(String(50))
    sprint_duration_weeks = Column(Integer)
    development_methodology = Column(String(50))
    total_sprints = Column(Integer)
    team_size = Column(Integer)
    project_start_date = Column(Date)
    include_comprehensive_testing_phases = Column(Boolean)
    include_deployment_and_monitoring_setup = Column(Boolean)
    include_documentation_tasks = Column(Boolean)
    include_risk_assessment = Column(Boolean, default=False)
    include_budget_estimation = Column(Boolean, default=False)
    include_detailed_resource_allocation = Column(Boolean, default=False)
    include_dependency_mapping = Column(Boolean, default=False)
    include_milestone_tracking = Column(Boolean, default=False)
    generate_detailed_task_breakdown = Column(Boolean, default=False)
    total_duration_weeks = Column(Integer)
    estimated_cost = Column(String(100))
    generated_pdf_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    generated_json_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    generated_excel_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    generated_content = Column(JSON)
    # Relationships
    use_case = relationship("GeneratedUseCase", back_populates="sprint_planning")
    pdf_report = relationship("AssessmentReport", foreign_keys=[generated_pdf_report_id])
    json_report = relationship("AssessmentReport", foreign_keys=[generated_json_report_id])
    excel_report = relationship("AssessmentReport", foreign_keys=[generated_excel_report_id])
    budget_breakdown = relationship("BudgetBreakdown", back_populates="sprint_planning")
    risk_assessment = relationship("RiskAssessment", back_populates="sprint_planning")
    selected_project_priorities = relationship("SelectedProjectPriority", back_populates="sprint_planning")
    selected_team_composition = relationship("SelectedTeamComposition", back_populates="sprint_planning")
    sprint_breakdown = relationship("SprintBreakdown", back_populates="sprint_planning")


class BudgetBreakdown(Base):
    __tablename__ = 'budget_breakdown'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    sprint_planning_id = Column(Integer, ForeignKey('sprint_planning.id'))
    category = Column(String(100))
    amount = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    sprint_planning = relationship("SprintPlanning", back_populates="budget_breakdown")


class RiskAssessment(Base):
    __tablename__ = 'risk_assessment'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    sprint_planning_id = Column(Integer, ForeignKey('sprint_planning.id'))
    risk_title = Column(String(200))
    impact = Column(String(100))
    mitigation = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    sprint_planning = relationship("SprintPlanning", back_populates="risk_assessment")


class SelectedProjectPriority(Base):
    __tablename__ = 'selected_project_priorities'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    sprint_planning_id = Column(Integer, ForeignKey('sprint_planning.id'))
    priority_title = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    sprint_planning = relationship("SprintPlanning", back_populates="selected_project_priorities")


class SelectedTeamComposition(Base):
    __tablename__ = 'selected_team_composition'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    sprint_planning_id = Column(Integer, ForeignKey('sprint_planning.id'))
    resource_title = Column(String(50))
    resource_quantity = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    sprint_planning = relationship("SprintPlanning", back_populates="selected_team_composition")


class SprintBreakdown(Base):
    __tablename__ = 'sprint_breakdown'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    sprint_planning_id = Column(Integer, ForeignKey('sprint_planning.id'))
    sprint_number = Column(Integer)
    goals_md = Column(Text)
    tasks_md = Column(Text)
    deliverables_md = Column(Text)
    sprint_weeks_duration = Column(Integer)
    total_tasks_count = Column(Integer)
    deliverables_count = Column(Integer)
    total_hours = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    sprint_planning = relationship("SprintPlanning", back_populates="sprint_breakdown")


class AIProfiling(Base):
    __tablename__ = 'ai_profiling'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    usecase_id = Column(Integer, ForeignKey('generated_use_cases.id'))
    file_analyzed = Column(String(255))
    quality_score = Column(Numeric(5, 2))
    analysis_type = Column(String(50))
    status = Column(String(50))
    analysis_report_text_md = Column(Text)
    include_analysis_metadata = Column(Boolean,default=True)
    include_full_analysis_content = Column(Boolean,default=True)
    generated_pdf_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    generated_json_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    generated_excel_report_id = Column(Integer, ForeignKey('assessment_reports.id'))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    use_case = relationship("GeneratedUseCase", back_populates="ai_profiling")
    pdf_report = relationship("AssessmentReport", foreign_keys=[generated_pdf_report_id])
    json_report = relationship("AssessmentReport", foreign_keys=[generated_json_report_id])
    excel_report = relationship("AssessmentReport", foreign_keys=[generated_excel_report_id])
    documents = relationship("AIProfilingDocument", back_populates="ai_profiling")


class AIProfilingDocument(Base):
    __tablename__ = 'ai_profiling_documents'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    ai_profiling_id = Column(Integer, ForeignKey('ai_profiling.id'))
    filename = Column(String(255))
    mimetype = Column(String(50))
    path = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    ai_profiling = relationship("AIProfiling", back_populates="documents")
