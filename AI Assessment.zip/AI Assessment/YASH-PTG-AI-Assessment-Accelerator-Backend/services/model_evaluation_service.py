import boto3
from openai import AzureOpenAI
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
import json
import os
from pathlib import Path
import asyncio
from groq import Groq
import time
import pandas as pd
from difflib import SequenceMatcher
import re
import logging
import aiohttp
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Pydantic Models
class ModelEvaluationRequest(BaseModel):
    models: List[str] = Field(..., description="List of models to evaluate")
    evaluation_type: str = Field(default="accuracy", description="Type of evaluation: accuracy, performance, comprehensive")
    use_llm_judge: bool = Field(default=True, description="Use LLM as judge for scoring")
    max_tokens: int = Field(default=1000, description="Maximum tokens for model responses")
    temperature: float = Field(default=0.7, description="Temperature for model responses")

class ModelEvaluationResponse(BaseModel):
    evaluation_id: str
    total_test_cases: int
    models_evaluated: List[str]
    overall_results: Dict[str, Any]
    detailed_results: List[Dict[str, Any]]
    best_performing_model: str
    worst_performing_model: str
    evaluation_summary: str
    generated_at: datetime

class ModelResult(BaseModel):
    model_name: str
    prompt: str
    response: str
    ground_truth: str
    is_correct: bool
    accuracy_score: float
    response_time: float
    judge_explanation: Optional[str] = None

class TestCase(BaseModel):
    prompt: str
    ground_truth: str
    category:str
    difficulty:str

class PricingRequest(BaseModel):
    model_id: str = Field(..., description="Model ID for pricing calculation")
    input_tokens: int = Field(..., description="Number of input tokens")
    output_tokens: int = Field(..., description="Number of output tokens")
    invocations: int = Field(default=1, description="Number of invocations")

class PricingResponse(BaseModel):
    model_id: str
    input_tokens: int
    output_tokens: int
    invocations: int
    input_cost: float
    output_cost: float
    total_cost_per_invocation: float
    total_cost_all_invocations: float
    cost_breakdown: Dict[str, Any]
    model_provider: str
    timestamp: datetime
# Supported Models Configuration
SUPPORTED_MODELS = {
     "groq": {
        "llama-3.3-70b-versatile": "Llama 3.3 70B",
        "llama3-8b-8192": "Llama 3 8B",
        "llama3-70b-8192": "Llama 3 70B",
        "mixtral-8x7b-32768": "Mixtral 8x7B",
        "gemma-7b-it": "Gemma 7B",
        "gemma2-9b-it": "Gemma 2 9B"
    },
    "openai": {
        "gpt3516k": "GPT-3.5 16K",
        "gpt-4.1": "GPT-4.1",
        "gpt-4.1-mini": "GPT-4.1 Mini",
        "gpt-4o": "GPT-4 Omni",
        "gpt-4o-mini": "GPT-4 Omni Mini",
        "gpt-4.1-nano": "GPT-4.1 Nano",
        "gpt-35-turbo":"gpt-35-turbo"
    },
    "gemini": {
        "gemini-1.5-flash": "Gemini 1.5 Flash",
        "gemini-1.5-pro": "Gemini 1.5 Pro",
        "gemini-2.0-flash-001": "Gemini 2.0 Flash",
        "gemini-2.5-pro": "Gemini 2.5 Pro",
        "gemini-2.5-flash": "Gemini 2.5 Flash"
    },
    "bedrock": {
        "ai21.jamba-1-5-large-v1:0": "AI21 Jamba 1.5 Large", 
        "amazon.nova-canvas-v1:0": "Amazon Nova Canvas",
        "amazon.nova-micro-v1:0": "Amazon Nova Micro",
        "amazon.nova-lite-v1:0": "Amazon Nova Lite",
        "amazon.nova-pro-v1:0": "Amazon Nova Pro",
        "anthropic.claude-3-haiku-20240307-v1:0": "Claude 3 Haiku",
        "anthropic.claude-3-sonnet-20240229-v1:0": "Claude 3 Sonnet",
        "us.meta.llama3-2-11b-instruct-v1:0": "Meta Llama 3.2 11B"
    },
    "anthropic": {
        "claude-opus-4-20250514": "Claude Opus 4",
        "claude-sonnet-4-20250514": "Claude Sonnet 4"
    },
    "other": {
        "source_model": "Source Model"
    }
}

# File Processing for Test Data
class TestDataProcessor:
    """Process CSV/Excel files containing prompt-ground truth pairs"""
    
    def __init__(self):
        self.supported_extensions = ['.csv', '.xlsx', '.xls']
    
    async def process_test_file(self, file_path: str, filename: str) -> List[TestCase]:
        """Process uploaded test file and extract test cases"""
        try:
            file_ext = Path(filename).suffix.lower()
            
            if file_ext not in self.supported_extensions:
                raise ValueError(f"Unsupported file type: {file_ext}")
            
            test_cases = []
            
            if file_ext == '.csv':
                test_cases = await self._process_csv(file_path)
            elif file_ext in ['.xlsx', '.xls']:
                test_cases = await self._process_excel(file_path)
            
            return test_cases
            
        except Exception as e:
            raise ValueError(f"Error processing test file: {str(e)}")
    
    async def _process_csv(self, file_path: str) -> List[TestCase]:
        """Process CSV file"""
        test_cases = []
        
        try:
            df = pd.read_csv(file_path)
            
            # Normalize column names (case-insensitive)
            df.columns = df.columns.str.strip().str.lower()
            
            # Look for prompt and ground_truth columns
            prompt_col = None
            ground_truth_col = None
            
            for col in df.columns:
                if 'prompt' in col:
                    prompt_col = col
                elif 'ground' in col and 'truth' in col:
                    ground_truth_col = col
                elif 'category' in col:
                    category_col = col
                elif 'difficulty' in col:
                    difficulty_col = col
                elif col in ['truth', 'answer', 'expected', 'target']:
                    ground_truth_col = col
            
            if not prompt_col or not ground_truth_col:
                raise ValueError("Required columns 'prompt' and 'ground_truth' not found")
            
            # Extract test cases
            for _, row in df.iterrows():
                prompt = str(row[prompt_col]).strip()
                ground_truth = str(row[ground_truth_col]).strip()
                category = str(row[category_col]).strip()
                difficulty = str(row[difficulty_col]).strip()
                
                if prompt and ground_truth and prompt != 'nan' and ground_truth != 'nan':
                    test_cases.append(TestCase(
                        prompt=prompt,
                        ground_truth=ground_truth,
                        category=category,
                        difficulty=difficulty,
                    ))
            
        except Exception as e:
            raise ValueError(f"Error processing CSV: {str(e)}")
        
        return test_cases
    
    async def _process_excel(self, file_path: str) -> List[TestCase]:
        """Process Excel file"""
        test_cases = []
        
        try:
            df = pd.read_excel(file_path)
            
            # Normalize column names (case-insensitive)
            df.columns = df.columns.str.strip().str.lower()
            
            # Look for prompt and ground_truth columns
            prompt_col = None
            ground_truth_col = None
            
            for col in df.columns:
                if 'prompt' in col:
                    prompt_col = col
                elif 'ground' in col and 'truth' in col:
                    ground_truth_col = col
                elif 'category' in col:
                    category_col = col
                elif 'difficulty' in col:
                    difficulty_col = col
                elif col in ['truth', 'answer', 'expected', 'target']:
                    ground_truth_col = col
            
            if not prompt_col or not ground_truth_col:
                raise ValueError("Required columns 'prompt' and 'ground_truth' not found")
            
            # Extract test cases
            for _, row in df.iterrows():
                prompt = str(row[prompt_col]).strip()
                ground_truth = str(row[ground_truth_col]).strip()
                category = str(row[category_col]).strip()
                difficulty = str(row[difficulty_col]).strip()

                if prompt and ground_truth and prompt != 'nan' and ground_truth != 'nan':
                    test_cases.append(TestCase(
                        prompt=prompt,
                        ground_truth=ground_truth,
                        category=category,
                        difficulty=difficulty
                    ))
            
        except Exception as e:
            raise ValueError(f"Error processing Excel: {str(e)}")
        
        return test_cases

# Model Clients
class BaseModelClient:
    """Abstract base class for all model clients"""
    
    def __init__(self, api_key: str, model_name: str):
        self.api_key = api_key
        self.model_name = model_name
    
    async def generate_response(self, prompt: str, **kwargs) -> str:
        """Generate response from the model"""
        raise NotImplementedError

class GroqClient(BaseModelClient):
    """Groq API client"""
    
    def __init__(self, api_key: str, model_name: str):
        super().__init__(api_key, model_name)
        self.client = Groq(api_key=api_key)
    
    async def generate_response(self, prompt: str, **kwargs) -> str:
        try:
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.client.chat.completions.create(
                    model=self.model_name,
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=kwargs.get('max_tokens', 1000),
                    temperature=kwargs.get('temperature', 0.7)
                )
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            raise Exception(f"Groq API error: {str(e)}")

class OpenAIClient(BaseModelClient):
    """Azure OpenAI API client"""

    def __init__(self, api_key: str, model_name: str):
        super().__init__(api_key, model_name)
        self.client = AzureOpenAI(
            api_key=api_key,
            api_version=os.getenv("API_VERSION"),
            azure_endpoint=os.getenv("API_URL")
        )
    
    async def generate_response(self, prompt: str, **kwargs) -> str:
        try:
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.client.chat.completions.create(
                    model=self.model_name,
                    messages=[{"role": "user", "content": prompt}],
                    # max_tokens=kwargs.get('max_tokens', 1000),
                    # temperature=kwargs.get('temperature', 0.7)
                )
            )
            print("response OpenAIClient:",response.choices[0].message.content.strip())
            return response.choices[0].message.content.strip()
        except Exception as e:
            raise Exception(f"OpenAI API error: {str(e)}")

class BedrockClient(BaseModelClient):
    """Amazon Bedrock API client"""

    def __init__(self, api_key: str, model_name: str):
        super().__init__(api_key, model_name)
        self.client = boto3.client(
            'bedrock-runtime',
            region_name=os.getenv('AWS_REGION', 'us-east-1'),
            aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY')
        )

    async def generate_response(self, prompt: str, **kwargs) -> str:
        try:
            request_body = self._build_request_body(prompt, **kwargs)
            
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.client.invoke_model(
                    modelId=self.model_name,
                    body=json.dumps(request_body),
                    contentType='application/json'
                )
            )
            
            response_body = json.loads(response['body'].read())
            return "Bedrock response not implemented yet"  # Placeholder for actual implementation
            
        except Exception as e:
            raise Exception(f"Bedrock API error: {str(e)}")

class BedrockClient(BaseModelClient):
    """Amazon Bedrock API client"""

    def __init__(self, api_key: str, model_name: str):
        super().__init__(api_key, model_name)
        # For Bedrock, we typically use AWS credentials instead of an API key
        # You can configure AWS credentials via environment variables, AWS credentials file, or IAM roles
        self.client = boto3.client(
            'bedrock-runtime',
            region_name=os.getenv('AWS_REGION', 'us-east-1'),
            aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY')
        )

    async def generate_response(self, prompt: str, **kwargs) -> str:
        try:
            # Different models have different request formats
            # This example uses Claude on Bedrock format
            request_body = self._build_request_body(prompt, **kwargs)
            
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.client.invoke_model(
                    modelId=self.model_name,
                    body=json.dumps(request_body),
                    contentType='application/json'
                )
            )
            
            # Parse the response
            response_body = json.loads(response['body'].read())
            # return self._extract_content(response_body)
            return "Bedrock response not implemented yet"  # Placeholder for actual implementation
            
        except Exception as e:
            raise Exception(f"Bedrock API error: {str(e)}")

    def _build_request_body(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Build request body based on model type"""
        
        # For Claude models (anthropic.claude-v2, anthropic.claude-instant-v1, etc.)
        if 'claude' in self.model_name.lower():
            return {
                "prompt": f"\n\nHuman: {prompt}\n\nAssistant:",
                "max_tokens_to_sample": kwargs.get('max_tokens', 1000),
                "temperature": kwargs.get('temperature', 0.7),
                "top_p": kwargs.get('top_p', 0.9),
                "stop_sequences": kwargs.get('stop_sequences', ["\n\nHuman:"])
            }
        
        # For Amazon Titan models
        elif 'titan' in self.model_name.lower():
            return {
                "inputText": prompt,
                "textGenerationConfig": {
                    "maxTokenCount": kwargs.get('max_tokens', 1000),
                    "temperature": kwargs.get('temperature', 0.7),
                    "topP": kwargs.get('top_p', 0.9),
                    "stopSequences": kwargs.get('stop_sequences', [])
                }
            }
        
        # For AI21 Jurassic models
        elif 'j2' in self.model_name.lower():
            return {
                "prompt": prompt,
                "maxTokens": kwargs.get('max_tokens', 1000),
                "temperature": kwargs.get('temperature', 0.7),
                "topP": kwargs.get('top_p', 0.9),
                "stopSequences": kwargs.get('stop_sequences', [])
            }
        
        # Default format (adjust based on your specific model)
        else:
            return {
                "prompt": prompt,
                "max_tokens": kwargs.get('max_tokens', 1000),
                "temperature": kwargs.get('temperature', 0.7)
            }

    def _extract_content(self, response_body: Dict[str, Any]) -> str:
        """Extract content from response based on model type"""
        
        # For Claude models
        if 'claude' in self.model_name.lower():
            return response_body.get('completion', '').strip()
        
        # For Amazon Titan models
        elif 'titan' in self.model_name.lower():
            return response_body.get('results', [])[0].get('outputText', '').strip() if response_body.get('results') else ''
        
        # For AI21 Jurassic models
        elif 'j2' in self.model_name.lower():
            return response_body.get('completions', [])[0].get('data', {}).get('text', '').strip() if response_body.get('completions') else ''
        
        # Default extraction
        return response_body.get('generated_text', '').strip()

class GeminiClient(BaseModelClient):
    """Google Gemini API client"""
    
    def __init__(self, api_key: str, model_name: str = "gemini-1.5-pro"):
        super().__init__(api_key, model_name)
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel(model_name)

    async def generate_response(self, prompt: str, **kwargs) -> str:
        try:
            print("generate_response GeminiClient")
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.model.generate_content(
                    prompt,
                    generation_config={
                        "temperature": kwargs.get("temperature", 0.7),
                        "max_output_tokens": kwargs.get("max_tokens", 1000),
                    }
                )
            )
            print("response:",response)
            return response.text.strip()
        except Exception as e:
            raise Exception(f"Gemini API error: {str(e)}")

# LLM Judge for Evaluation
class LLMJudge:
    """LLM-as-a-judge for evaluating response quality"""
    
    def __init__(self, judge_client: BaseModelClient):
        self.judge_client = judge_client
    
    async def evaluate_response(self, prompt: str, model_response: str, ground_truth: str) -> tuple[float, str]:
        """Evaluate a model response against ground truth using LLM as judge"""
        judge_prompt = f"""
You are an expert evaluator tasked with scoring the quality and correctness of AI model responses.

Original Question/Prompt: {prompt}

Ground Truth/Expected Answer: {ground_truth}

Model Response to Evaluate: {model_response}

Please evaluate the model response based on the following criteria:
1. Factual accuracy compared to the ground truth
2. Completeness of the answer
3. Relevance to the original question
4. Clarity and coherence

Provide your evaluation in the following format:
SCORE: [A number between 0-100, where 0 is completely wrong and 100 is perfect]
EXPLANATION: [Brief explanation of your scoring rationale]

Consider partial credit for responses that are partially correct or contain some relevant information.
If the model response contains the correct answer but has additional context, give it high marks (90-100).
If the model response is factually correct but verbose, still give it high marks (85-95).
"""
        try:
            judge_response = await self.judge_client.generate_response(judge_prompt)
            score, explanation = self._parse_judge_response(judge_response)
            return score, explanation
        except Exception as e:
            logger.error(f"Error in LLM judge evaluation: {str(e)}")
            fallback_score = self._smart_fuzzy_match(model_response, ground_truth)
            return fallback_score, f"Judge evaluation failed, used fuzzy matching: {str(e)}"
    
    def _parse_judge_response(self, judge_response: str) -> tuple[float, str]:
        """Parse the judge response to extract score and explanation"""
        try:
            lines = judge_response.strip().split('\n')
            score = 0.0
            explanation = "No explanation provided"
            
            for line in lines:
                line = line.strip()
                if line.upper().startswith('SCORE:'):
                    score_text = line.replace('SCORE:', '').replace('score:', '').strip()
                    score_match = re.search(r'(\d+(?:\.\d+)?)', score_text)
                    if score_match:
                        score = float(score_match.group(1))
                        score = max(0.0, min(100.0, score))
                elif line.upper().startswith('EXPLANATION:'):
                    explanation = line.replace('EXPLANATION:', '').replace('explanation:', '').strip()
            
            return score, explanation
        except Exception as e:
            logger.error(f"Error parsing judge response: {str(e)}")
            return 0.0, f"Failed to parse judge response: {str(e)}"
    
    def _smart_fuzzy_match(self, model_response: str, ground_truth: str) -> float:
        """Enhanced fuzzy matching with better logic"""
        model_clean = model_response.lower().strip()
        truth_clean = ground_truth.lower().strip()
        
        if truth_clean in model_clean:
            return 95.0
        if model_clean in truth_clean:
            return 90.0
        
        similarity = SequenceMatcher(None, model_clean, truth_clean).ratio()
        
        if similarity >= 0.9:
            return 85.0
        elif similarity >= 0.8:
            return 70.0
        elif similarity >= 0.6:
            return 50.0
        else:
            return 0.0

# Model Evaluator
class ModelEvaluator:
    """Main class for evaluating multiple models"""
    
    SUPPORTED_MODELS = SUPPORTED_MODELS
    
    def __init__(self, api_keys: Dict[str, str] = None):
        self.groq_api_key = api_keys.get("groq") if api_keys else os.getenv("GROQ_API_KEY")
        self.openai_api_key = api_keys.get("openai") if api_keys else os.getenv("AZURE_OPENAI_API_KEY")
        self.gemini_api_key = api_keys.get("gemini") if api_keys else os.getenv("GEMINI_API_KEY")
        self.anthropic_api_key = api_keys.get("Anthropic_API_KEY") if api_keys else os.getenv("ANTHROPIC_API_KEY")
        self.model_clients = {}
        self.judge = None
        
        if self.groq_api_key:
            judge_client = GroqClient(self.groq_api_key, "llama-3.3-70b-versatile")
            self.judge = LLMJudge(judge_client)
    
    def setup_model_clients(self, models: List[str]):
        """Setup model clients for evaluation"""
        self.model_clients = {}
        
        for model_name in models:
            if model_name in SUPPORTED_MODELS["groq"] and self.groq_api_key:
                self.model_clients[model_name] = GroqClient(self.groq_api_key, model_name)
            elif model_name in SUPPORTED_MODELS["openai"] and self.openai_api_key:
                self.model_clients[model_name] = OpenAIClient(self.openai_api_key, model_name)
            elif model_name in SUPPORTED_MODELS["gemini"] and self.gemini_api_key:
                self.model_clients[model_name] = GeminiClient(self.gemini_api_key, model_name)
            elif model_name in SUPPORTED_MODELS["bedrock"] and os.getenv("AWS_ACCESS_KEY_ID") and os.getenv("AWS_SECRET_ACCESS_KEY"):
                self.model_clients[model_name] = BedrockClient(
                    os.getenv("AWS_ACCESS_KEY_ID"),
                    model_name
                )
            else:
                logger.warning(f"Model {model_name} not supported or API key missing")
    
    async def evaluate_models(self, test_cases: List[TestCase], models: List[str], 
                            use_llm_judge: bool = True, **kwargs) -> Dict[str, Any]:
        """Evaluate multiple models against test cases"""
        self.setup_model_clients(models)
        
        if not self.model_clients:
            raise ValueError("No valid model clients configured")
        
        all_results = []
        model_summaries = {}
        
        for model_name, client in self.model_clients.items():
            logger.info(f"Evaluating model: {model_name}")
            logger.info(f"Evaluating client: {client}")
        
            model_results = []
            total_score = 0.0
            correct_count = 0
            total_time = 0.0
            
            for i, test_case in enumerate(test_cases):
                try:
                    start_time = time.time()
                    response = await client.generate_response(test_case.prompt, **kwargs)
                    response_time = time.time() - start_time
                    
                    if use_llm_judge and self.judge:
                        accuracy_score, judge_explanation = await self.judge.evaluate_response(
                            test_case.prompt, response, test_case.ground_truth
                        )
                        is_correct = accuracy_score >= 70.0
                    else:
                        is_correct = self._simple_match(response, test_case.ground_truth)
                        accuracy_score = 100.0 if is_correct else 0.0
                        judge_explanation = "Simple string matching used"
                    
                    result = ModelResult(
                        model_name=model_name,
                        prompt=test_case.prompt,
                        response=response,
                        ground_truth=test_case.ground_truth,
                        is_correct=is_correct,
                        accuracy_score=accuracy_score,
                        response_time=response_time,
                        judge_explanation=judge_explanation
                    )
                    
                    model_results.append(result.dict())
                    total_score += accuracy_score
                    if is_correct:
                        correct_count += 1
                    total_time += response_time
                    
                    logger.info(f"  Test {i+1}/{len(test_cases)}: Score {accuracy_score:.1f}%")
                    
                except Exception as e:
                    logger.error(f"Error evaluating {model_name} on test {i+1}: {str(e)}")
                    error_result = ModelResult(
                        model_name=model_name,
                        prompt=test_case.prompt,
                        response=f"ERROR: {str(e)}",
                        ground_truth=test_case.ground_truth,
                        is_correct=False,
                        accuracy_score=0.0,
                        response_time=0.0,
                        judge_explanation=f"Evaluation failed: {str(e)}"
                    )
                    model_results.append(error_result.dict())
            
            avg_score = round(total_score / len(test_cases), 2) if test_cases else 0
            accuracy_percentage = round((correct_count / len(test_cases) * 100), 2) if test_cases else 0
            avg_response_time = round(total_time / len(test_cases), 4) if test_cases else 0
            
            model_summaries[model_name] = {
                "model_name": model_name,
                "total_test_cases": len(test_cases),
                "correct_responses": correct_count,
                "accuracy_percentage": accuracy_percentage,
                "average_score": avg_score,
                "average_response_time": avg_response_time,
                "detailed_results": model_results
            }
            
            all_results.extend(model_results)
        
        overall_results = self._calculate_overall_results(model_summaries)
        print("overall_result:",overall_results)
        return {
            "model_summaries": model_summaries,
            "overall_results": overall_results,
            "all_results": all_results
        }
    
    def _simple_match(self, response: str, ground_truth: str) -> bool:
        """Simple string matching for binary accuracy"""
        response_clean = response.lower().strip()
        truth_clean = ground_truth.lower().strip()
        
        if response_clean == truth_clean:
            return True
        if truth_clean in response_clean:
            return True
        
        similarity = SequenceMatcher(None, response_clean, truth_clean).ratio()
        return similarity >= 0.8
    
    def _calculate_overall_results(self, model_summaries: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall evaluation results"""
        if not model_summaries:
            return {}
        
        sorted_models = sorted(
            model_summaries.items(),
            key=lambda x: x[1]["average_score"],
            reverse=True
        )
        
        best_model = sorted_models[0][0] if sorted_models else "None"
        worst_model = sorted_models[-1][0] if sorted_models else "None"
        
        scores = [summary["average_score"] for summary in model_summaries.values()]
        avg_score = sum(scores) / len(scores) if scores else 0
        variance = sum((score - avg_score) ** 2 for score in scores) / len(scores) if scores else 0
        
        total_test_cases = model_summaries[list(model_summaries.keys())[0]]["total_test_cases"] if model_summaries else 0
        
        return {
            "total_models": len(model_summaries),
            "total_test_cases": total_test_cases,
            "best_performing_model": best_model,
            "worst_performing_model": worst_model,
            "overall_average_score": avg_score,
            "overall_average_accuracy": avg_score,
            "performance_variance": variance,
            "model_rankings": [
                {
                    "model_name": model_name,
                    "rank": i + 1,
                    "average_score": summary["average_score"],
                    "average_accuracy_score": summary["average_score"],
                    "accuracy_percentage": summary["accuracy_percentage"],
                    "average_response_time": summary["average_response_time"]
                }
                for i, (model_name, summary) in enumerate(sorted_models)
            ]
        }