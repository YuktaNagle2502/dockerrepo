import re
import asyncio
from datetime import datetime
from groq import Groq
from typing import Optional, List, Dict, Any, Union
import google.generativeai as genai
from utils.compliance_utils import DataFileInfo
import os

class ComplianceAnalyzer:
    def __init__(self, api_key: str, model: str = "deepseek-r1-distill-llama-70b"):
        # self.client = Groq(api_key=api_key)
        genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
        self.client = genai.GenerativeModel('gemini-2.0-flash')
        self.model = model
        self.compliance_frameworks = {
            'gdpr': 'General Data Protection Regulation',
            'ccpa': 'California Consumer Privacy Act',
            'hipaa': 'Health Insurance Portability and Accountability Act',
            'sox': 'Sarbanes-Oxley Act',
            'pci_dss': 'Payment Card Industry Data Security Standard',
            'iso_27001': 'ISO/IEC 27001 Information Security Management',
            'aws_security': 'AWS Security Best Practices',
            'nist': 'NIST Cybersecurity Framework'
        }

    def extract_risk_info_from_content(content: str) -> list:
        """Extract risk information from the generated content"""
        risks = []
        
        # Look for risk assessment section
        lines = content.split('\n')
        in_risk_section = False
        
        for line in lines:
            line = line.strip()
            
            # Check if we're entering risk section
            if 'risk' in line.lower() and ('###' in line or '##' in line):
                in_risk_section = True
                continue
            
            # Check if we're leaving risk section
            if in_risk_section and ('###' in line or '##' in line) and 'risk' not in line.lower():
                break
            
            # Extract risk items
            if in_risk_section and line:
                if line.startswith(('*', '-', '•')):
                    risk = line[1:].strip()
                    if len(risk) > 15:  # Filter out very short lines
                        risks.append(risk)
        
        return risks[:8]  # Limit to top 8 risks

    def get_markdown_content(self,text):
        print("getting markdown content")
        start_marker = '```markdown'
        end_marker = '```'
        if start_marker not in text or end_marker not in text[start_marker.index(start_marker) + len(start_marker):]:
            return text
        start = text.find(start_marker) + len(start_marker)
        end = text.find(end_marker, start)
        if start != -1 and end != -1:
            return text[start:end].strip()
        return text
    
    async def analyze_compliance(self, use_case_data: dict, file_info: List[DataFileInfo], analysis_type: str = "comprehensive") -> dict:
        """Generate comprehensive compliance analysis"""
        # Prepare context for AI analysis
        context=[]
        for file in file_info:
            context_data=self._prepare_analysis_context(use_case_data, file, analysis_type)
            context.append(f"{file.filename}: {context_data}")

        context = "\n\n".join(context)

        sample_contents = []
        for file in file_info:
            if file.content is not None:
                content_str = str(file.content) if not isinstance(file.content, str) else file.content
                sample_contents.append(f"File: {file.filename}\nContent: {content_str}")

        sample_content = "\n\n".join(sample_contents)
        # Generate analysis using AI
        analysis_result = await self._generate_ai_analysis(context, analysis_type,sample_content)
        risk_assessment=await self.extract_risk_info_from_content(analysis_result)
        # Calculate compliance score
        
        compliance_score = self._calculate_compliance_score(analysis_result)
        
        # Determine risk level
        risk_levels=[]
        for file in file_info:
            risk = self._determine_risk_level(compliance_score, file)
            risk_levels.append(f"{file.filename}: {risk}")
    
        risk_level = "\n".join(risk_levels)
        
        return {
            'use_case_id': use_case_data.get('id'),
            'analysis_type': analysis_type,
            'generated_content': self.get_markdown_content(analysis_result),
            'compliance_score': compliance_score,
            'risk_level': risk_level,
            'risk_assessment':risk_assessment if risk_assessment else None,
            'recommendations_count': len(re.findall(r'## Recommendation', analysis_result)),
            'generated_at': datetime.utcnow()
        }

    def _prepare_analysis_context(self, use_case_data: dict, file_info: DataFileInfo, analysis_type: str) -> str:
        context = f"""
        # Use Case Information
        - **Title**: {use_case_data.get('title', 'N/A')}
        - **Description**: {use_case_data.get('description', 'N/A')}
        - **AWS Services**: {', '.join(use_case_data.get('aws_services', []))}
        - **Primary GenAI Capability**: {use_case_data.get('primary_genai_capability', 'N/A')}
        - **Business Category**: {use_case_data.get('business_category', 'N/A')}
        - **Priority**: {use_case_data.get('priority', 'N/A')}
        - **Complexity**: {use_case_data.get('complexity', 'N/A')}
        - **Customer Pain Points**: {', '.join(use_case_data.get('customer_pain_points', []))}
        
        # Data File Information
        - **Filename**: {file_info.filename}
        - **File Type**: {file_info.file_type}
        - **Size**: {file_info.size_bytes} bytes
        - **Records Count**: {file_info.records_count or 'N/A'}
        - **Columns Count**: {file_info.columns_count or 'N/A'}
        - **Contains PII**: {file_info.has_pii}
        - **Contains Sensitive Data**: {file_info.has_sensitive_data}
        
        # Analysis Type
        Analysis Focus: {analysis_type}
        
        # Compliance Frameworks to Consider
        {', '.join(self.compliance_frameworks.values())}
        """
        return context

    async def _generate_ai_analysis(self, context: str, analysis_type: str,sample_content:str) -> str:
        system_prompt = f"""
        You are an expert compliance analyst specializing in GenAI implementations, data privacy, and AWS security.
        Your task is to analyze the provided use case and data information to generate a comprehensive compliance report.
        
        Focus on the following areas:
        1. Data Privacy & Protection (GDPR, CCPA, etc.) and what specific Data privacy we should follow
        like Is it for Medical (Healthcare providers are subject to various laws and regulations, such as HIPAA in the US and GDPR in Europe)
        and other different different data privacy laws. You have to provide the specific data privacy laws that we should follow for this data.
        2. Security Compliance (ISO 27001, NIST, AWS Security)
        3. Industry-specific Regulations (HIPAA, SOX, PCI-DSS)
        4. AWS GenAI Service Compliance
        5. Data Governance & Integration
        6. Risk Assessment & Mitigation
        
        Generate a detailed compliance report in markdown format with the following structure:
        - Executive Summary
        - Compliance Status Overview
        - Detailed Analysis by Framework
        - Risk Assessment
        - Recommendations
        - Implementation Roadmap
        - AWS Service Specific Considerations
        
        Be specific about compliance requirements and provide actionable recommendations.
        """
        user_request = f"""
        Please analyze the following use case and data information for compliance:
        And provide what specific data privacy laws we should follow for this data.
        {context}
        This is the sample data for which you need to check what are the different 
        GDPR compliance we should follow {sample_content}
        Analyze the data and then decide what is this data is representing and what 
        are the different data privacy laws we should follow.
        Generate a comprehensive compliance and integration report in markdown format.
        Focus on {analysis_type} analysis and provide specific, actionable recommendations.
        ****Instruction to follow****
        - Use markdown format for the report
        - Do write as I need to provide the specific data privacy laws that we should follow for this data.
        - Make it like it is a compliance report
        """
        try:
            # response = await asyncio.get_event_loop().run_in_executor(
            #     None, 
            #     lambda: self.client.chat.completions.create(
            #         model=self.model,
            #         messages=[
            #             {"role": "system", "content": system_prompt},
            #             {"role": "user", "content": user_request}
            #         ],
            #         temperature=0.7
            #     )
            # )
            
            # return response.choices[0].message.content.strip().replace("<think>", "")
            prompt = f"{system_prompt}\n\n{user_request}"
            response = self.client.generate_content(
                prompt,
                generation_config=genai.types.GenerationConfig(
                temperature=0.8,
                )
            )
            content = response.text
            return content.strip()
        except Exception as e:
            return f"""
            # Compliance Analysis Error
            
            An error occurred while generating the compliance analysis: {str(e)}
            
            ## Manual Review Required
            
            Please review the following items manually:
            - Data privacy compliance for PII handling
            - Security requirements for GenAI implementation
            - Industry-specific regulatory requirements
            - AWS service compliance configurations
            """
        
    async def extract_risk_info_from_content(self,content: str) -> list:
        """Extract risk information from the generated content"""
        risks = []
        
        # Look for risk assessment section
        lines = content.split('\n')
        in_risk_section = False
        
        for line in lines:
            line = line.strip()
            
            # Check if we're entering risk section
            if 'risk' in line.lower() and ('###' in line or '##' in line):
                in_risk_section = True
                continue
            
            # Check if we're leaving risk section
            if in_risk_section and ('###' in line or '##' in line) and 'risk' not in line.lower():
                break
            
            # Extract risk items
            if in_risk_section and line:
                if line.startswith(('*', '-', '•')):
                    risk = line[1:].strip()
                    if len(risk) > 15:  # Filter out very short lines
                        risks.append(risk)
        
        return risks[:8]  # Limit to top 8 risks

    def _calculate_compliance_score(self, analysis_content: str) -> float:
        score = 100.0
        critical_issues = len(re.findall(r'critical|severe|high risk', analysis_content.lower()))
        high_issues = len(re.findall(r'high priority|important|significant', analysis_content.lower()))
        medium_issues = len(re.findall(r'medium|moderate|consider', analysis_content.lower()))
        score -= critical_issues * 20
        score -= high_issues * 10
        score -= medium_issues * 5
        return max(0.0, min(100.0, score))

    def _determine_risk_level(self, compliance_score: float, file_info: DataFileInfo) -> str:
        if compliance_score >= 90:
            base_risk = "Low"
        elif compliance_score >= 70:
            base_risk = "Medium"
        elif compliance_score >= 50:
            base_risk = "High"
        else:
            base_risk = "Critical"
        if file_info.has_pii or file_info.has_sensitive_data:
            risk_levels = ["Low", "Medium", "High", "Critical"]
            current_index = risk_levels.index(base_risk)
            if current_index < len(risk_levels) - 1:
                base_risk = risk_levels[current_index + 1]
        return base_risk
