from fastapi import HTTPException, status, UploadFile, Response
from sqlalchemy.orm import Session, joinedload
from typing import List, Dict, Any
import json
import os
import tempfile
import uuid
import logging
from datetime import datetime, timedelta
from pathlib import Path
from models.models import User, Project
from models.models import PreWorkshopSession, QuestionnaireResponse, GeneratedUseCase
from models.pydantic_models import standard_response  # Added import
from utils.s3_utils import generate_presigned_get_urls, delete_file, download_file, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, BUCKET_NAME
from utils.pre_workshop_utils import (
    PreWorkshopSessionCreate,
    PreWorkshopSessionResponse,
    PreWorkshopSessionDetail,
    ExcelUploadResponse,
    ReportRequest,
    BulkUseCaseSelection,
    process_excel_questionnaire,
    save_uploaded_file,
    generate_pdf_report,
    GenAIUseCasesGenerator,
    GeneratedUseCaseResponse,
    QuestionnaireResponseResponse,
    CustomUseCaseCreate,
    CustomUseCaseUpdate,
    cleanup_uploaded_file,
    upload_file
)
from dotenv import load_dotenv
load_dotenv()

class PreWorkshopService:
    def __init__(self, db: Session):
        self.db = db
        self.groq_api_key = os.getenv("GROQ_API_KEY")
        if not self.groq_api_key:
            print("Warning: GROQ_API_KEY not found in environment variables")
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        self.url_expirations = {}  # Store expiration timestamps (key: session_id or report_{session_id})

    def _verify_project_ownership(self, project_id: int, current_user: User) -> Project:
        project = self.db.query(Project).filter(
            Project.id == project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found or access denied"
            )
        return project

    def _verify_session_access(self, session_id: int, current_user: User) -> PreWorkshopSession:
        session = self.db.query(PreWorkshopSession).options(
            joinedload(PreWorkshopSession.questionnaire_responses),
            joinedload(PreWorkshopSession.generated_use_cases)
        ).filter(
            PreWorkshopSession.id == session_id
        ).first()
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )
        self._verify_project_ownership(session.project_id, current_user)
        return session

    def _refresh_presigned_url(self, session: PreWorkshopSession) -> tuple[str, datetime]:
        session_id = session.id
        s3_key = session.questionnaire_file_path
        if not s3_key:
            return None, None
        current_time = datetime.utcnow()
        expires_at = self.url_expirations.get(session_id)
        self.logger.info(f"Checking expiration for session {session_id}: expires_at={expires_at}")
        if expires_at and expires_at > current_time + timedelta(hours=1):
            return session.presigned_url, expires_at
        self.logger.info(f"Regenerating URL for session {session_id}")
        result = generate_presigned_get_urls(
            bucket_name=BUCKET_NAME,
            object_paths=[s3_key],
            access_key=AWS_ACCESS_KEY_ID,
            secret_key=AWS_SECRET_ACCESS_KEY,
            region=AWS_REGION
        )[0]
        if result['status'] == 'success':
            self.url_expirations[session_id] = result['expires_at']
            self.logger.info(f"New URL for session {session_id} expires at {result['expires_at'].isoformat()}")
            return result['url'], result['expires_at']
        else:
            self.logger.error(f"Failed to regenerate URL for session {session_id}: {result['error']}")
            return None, None

    def _refresh_report_presigned_url(self, session: PreWorkshopSession) -> tuple[str, datetime]:
        session_id = session.id
        s3_key = session.report_file_path
        if not s3_key:
            return None, None
        report_key = f"report_{session_id}"
        current_time = datetime.utcnow()
        expires_at = self.url_expirations.get(report_key)
        self.logger.info(f"Checking expiration for report {session_id}: expires_at={expires_at}")
        if expires_at and expires_at > current_time + timedelta(hours=1):
            return session.presigned_url, expires_at
        self.logger.info(f"Regenerating report URL for session {session_id}")
        result = generate_presigned_get_urls(
            bucket_name=BUCKET_NAME,
            object_paths=[s3_key],
            access_key=AWS_ACCESS_KEY_ID,
            secret_key=AWS_SECRET_ACCESS_KEY,
            region=AWS_REGION
        )[0]
        if result['status'] == 'success':
            self.url_expirations[report_key] = result['expires_at']
            self.logger.info(f"New report URL for session {session_id} expires at {result['expires_at'].isoformat()}")
            return result['url'], result['expires_at']
        else:
            self.logger.error(f"Failed to regenerate report URL for session {session_id}: {result['error']}")
            return None, None

    def create_session(self, session_data: PreWorkshopSessionCreate, current_user: User) -> List[Dict]:
        self._verify_project_ownership(session_data.project_id, current_user)
        db_session = PreWorkshopSession(
            project_id=session_data.project_id,
            session_name=session_data.session_name,
            description=session_data.description,
            status='draft'
        )
        self.db.add(db_session)
        self.db.commit()
        self.db.refresh(db_session)
        return [{
            "id": db_session.id,
            "project_id": db_session.project_id,
            "session_name": db_session.session_name,
            "description": db_session.description,
            "status": db_session.status,
            "questionnaire_file_path": db_session.questionnaire_file_path,
            "report_file_path": db_session.report_file_path,
            "presigned_url": None,
            "created_at": db_session.created_at.isoformat(),
            "updated_at": db_session.updated_at.isoformat(),
        }]

    def get_sessions_by_project(self, project_id: int, current_user: User) -> List[Dict]:
        self._verify_project_ownership(project_id, current_user)
        sessions = self.db.query(PreWorkshopSession).filter(
            PreWorkshopSession.project_id == project_id
        ).all()
        result = []
        for session in sessions:
            questionnaire_url, _ = self._refresh_presigned_url(session)
            report_url, _ = self._refresh_report_presigned_url(session)
            result.append({
                "id": session.id,
                "project_id": session.project_id,
                "session_name": session.session_name,
                "description": session.description,
                "status": session.status,
                "questionnaire_file_path": session.questionnaire_file_path,
                "report_file_path": session.report_file_path,
                "questionnaire_presigned_url": questionnaire_url,
                "report_presigned_url": report_url,
                "created_at": session.created_at.isoformat(),
                "updated_at": session.updated_at.isoformat(),
                "generated_use_cases": [
                    {"id": uc.id, "title": uc.title, "description": uc.description}
                    for uc in session.generated_use_cases
                ]
            })
        return result

    def get_session_detail(self, session_id: int, current_user: User) -> PreWorkshopSessionDetail:
        session = self._verify_session_access(session_id, current_user)
        db_session = self.db.query(PreWorkshopSession).options(
            joinedload(PreWorkshopSession.questionnaire_responses),
            joinedload(PreWorkshopSession.generated_use_cases)
        ).filter(PreWorkshopSession.id == session_id).first()
        questionnaire_url, _ = self._refresh_presigned_url(db_session)
        report_url, _ = self._refresh_report_presigned_url(db_session)
        responses = [
            QuestionnaireResponseResponse(
                id=resp.id,
                session_id=resp.session_id,
                category=resp.category,
                question=resp.question,
                description=resp.description,
                response=resp.response,
                additional_notes=resp.additional_notes,
                created_at=resp.created_at
            )
            for resp in db_session.questionnaire_responses
        ]
        use_cases = [
            GeneratedUseCaseResponse(
                id=uc.id,
                session_id=uc.session_id,
                title=uc.title,
                description=uc.description,
                aws_services=uc.aws_services,
                primary_genai_capability=uc.primary_genai_capability,
                business_category=uc.business_category,
                customer_pain_points=uc.customer_pain_points,
                priority=uc.priority,
                complexity=uc.complexity,
                estimated_effort=uc.estimated_effort,
                success_metrics=uc.success_metrics,
                aws_architecture=uc.aws_architecture,
                cost_estimate=uc.cost_estimate,
                dependencies=uc.dependencies,
                risks=uc.risks,
                roi_potential=uc.roi_potential,
                implementation_phases=uc.implementation_phases,
                is_selected=uc.is_selected,
                created_at=uc.created_at
            )
            for uc in db_session.generated_use_cases
        ]
        return PreWorkshopSessionDetail(
            id=db_session.id,
            project_id=db_session.project_id,
            session_name=db_session.session_name,
            description=db_session.description,
            status=db_session.status,
            questionnaire_file_path=db_session.questionnaire_file_path,
            report_file_path=db_session.report_file_path,
            created_at=db_session.created_at,
            updated_at=db_session.updated_at,
            questionnaire_responses=responses,
            generated_use_cases=use_cases,
            presigned_url=questionnaire_url,
            report_presigned_url=report_url
        )

    async def upload_questionnaire(self, session_id: int, upload_file_obj: UploadFile, current_user: User) -> ExcelUploadResponse:
        self.logger.info(f"Entering upload_questionnaire for session {session_id}, file: {upload_file_obj.filename}")
        session = self._verify_session_access(session_id, current_user)
        if not upload_file_obj.filename.endswith(('.xlsx', '.xls')):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid file type. Please upload an Excel file (.xlsx or .xls)"
            )
        # Retrieve project name
        project = self.db.query(Project).filter(Project.id == session.project_id).first()
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found"
            )
        temp_dir = os.path.join(tempfile.gettempdir(), "ai_assessment_temp")
        os.makedirs(temp_dir, exist_ok=True)
        temp_file_path = os.path.join(temp_dir, f"{uuid.uuid4()}{Path(upload_file_obj.filename).suffix}")
        self.logger.info(f"Using temp file path: {temp_file_path}")
        try:
            s3_key, presigned_url = await save_uploaded_file(
                upload_file_obj,
                session_id=session_id,
                session_name=session.session_name,
                folder_prefix="questionnaires",
                project_name=project.name  # Pass project name
            )
            expires_at = datetime.utcnow() + timedelta(seconds=604800)
            self.logger.info(f"File uploaded, S3 key: {s3_key}, presigned_url: {presigned_url}")
            download_file(
                bucket_name=BUCKET_NAME,
                s3_key=s3_key,
                local_path=temp_file_path,
                access_key=AWS_ACCESS_KEY_ID,
                secret_key=AWS_SECRET_ACCESS_KEY,
                region=AWS_REGION
            )
            self.logger.info(f"File downloaded to {temp_file_path}")
            questionnaire_responses = process_excel_questionnaire(temp_file_path)
            self.logger.info(f"Processed {len(questionnaire_responses)} responses")
            if not questionnaire_responses:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="No valid questionnaire responses found in Sheet1"
                )
            if session.questionnaire_file_path:
                self.logger.info(f"Deleting old S3 file: {session.questionnaire_file_path}")
                delete_file(
                    bucket_name=BUCKET_NAME,
                    s3_key=session.questionnaire_file_path,
                    access_key=AWS_ACCESS_KEY_ID,
                    secret_key=AWS_SECRET_ACCESS_KEY,
                    region=AWS_REGION
                )
            self.db.query(QuestionnaireResponse).filter(
                QuestionnaireResponse.session_id == session_id
            ).delete()
            for response_data in questionnaire_responses:
                db_response = QuestionnaireResponse(
                    session_id=session_id,
                    category=response_data['category'],
                    question=response_data['question'],
                    description=response_data['description'],
                    response=response_data['response'],
                    additional_notes=response_data['additional_notes']
                )
                self.db.add(db_response)
            session.questionnaire_file_path = s3_key
            session.status = "questionnaire_uploaded"
            session.updated_at = datetime.utcnow()
            self.db.commit()
            self.url_expirations[session_id] = expires_at
            responses_preview = [
                {
                    "category": resp['category'],
                    "question": resp['question'][:100] + "..." if len(resp['question']) > 100 else resp['question'],
                    "response": resp['response'][:200] + "..." if len(resp['response']) > 200 else resp['response']
                }
                for resp in questionnaire_responses[:5]
            ]
            cleanup_uploaded_file(temp_file_path)
            self.logger.info(f"Exiting upload_questionnaire for session {session_id}")
            return ExcelUploadResponse(
                message="Questionnaire responses uploaded successfully",
                total_responses=len(questionnaire_responses),
                session_status="questionnaire_uploaded",
                responses_preview=responses_preview,
                presigned_url=presigned_url
            )
        except Exception as e:
            self.logger.error(f"Exception in upload_questionnaire for session {session_id}: {str(e)}", exc_info=True)
            cleanup_uploaded_file(temp_file_path, s3_key if 's3_key' in locals() else None)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error processing Excel file: {str(e)}"
            )

    async def generate_use_cases(self, session_id: int, current_user: User) -> Dict[str, Any]:
        self.logger.info(f"Entering generate_use_cases for session {session_id}")
        if not self.groq_api_key:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="AI service not configured"
            )
        session = self._verify_session_access(session_id, current_user)
        responses = self.db.query(QuestionnaireResponse).filter(
            QuestionnaireResponse.session_id == session_id
        ).all()
        if not responses:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No questionnaire responses found. Please upload Excel file first."
            )
        response_texts = [resp.response for resp in responses]
        try:
            generator = GenAIUseCasesGenerator(self.groq_api_key)
            use_cases_data = await generator.generate_aws_genai_use_cases(response_texts)
            self.db.query(GeneratedUseCase).filter(
                GeneratedUseCase.session_id == session_id
            ).delete()
            
            # Save generated use cases to database
            
            saved_use_cases = []
            for use_case in use_cases_data:
                db_use_case = GeneratedUseCase(
                    session_id=session_id,
                    title=use_case.get('title', 'Unknown'),
                    description=use_case.get('description', ''),
                    aws_services=use_case.get('aws_services', []),
                    primary_genai_capability=use_case.get('primary_genai_capability', ''),
                    business_category=use_case.get('business_category', ''),
                    customer_pain_points=use_case.get('customer_pain_points', []),
                    priority=use_case.get('priority', 'Medium'),
                    complexity=use_case.get('complexity', 'Medium'),
                    estimated_effort=use_case.get('estimated_effort', ''),
                    success_metrics=use_case.get('success_metrics', []),
                    aws_architecture=use_case.get('aws_architecture', ''),
                    cost_estimate=use_case.get('cost_estimate', ''),
                    dependencies=use_case.get('dependencies', []),
                    risks=use_case.get('risks', []),
                    roi_potential=use_case.get('roi_potential', 'Medium'),
                    implementation_phases=use_case.get('implementation_phases', []),
                    justification=use_case.get('Justification', 'No justification provided'),
                    data_readiness_status="In Progress"
                )
                self.db.add(db_use_case)
            
                # Update session status
                saved_use_cases.append(db_use_case)
            session.status = "use_cases_generated"
            session.updated_at = datetime.utcnow()
            self.db.commit()
            self.logger.info(f"Exiting generate_use_cases for session {session_id}, generated {len(saved_use_cases)} use cases")
            return {
                "message": "Use cases generated successfully",
                "total_use_cases": len(use_cases_data),
                "session_status": "use_cases_generated"
            }
        except Exception as e:
            self.logger.error(f"Exception in generate_use_cases for session {session_id}: {str(e)}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error generating use cases: {str(e)}"
            )

    async def generate_report(self, session_id: int, report_request: ReportRequest, current_user: User) -> Response:
        self.logger.info(f"Entering generate_report for session {session_id}, type: {report_request.report_type}")
        session = self._verify_session_access(session_id, current_user)
        # Retrieve project name
        project = self.db.query(Project).filter(Project.id == session.project_id).first()
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found"
            )
        questionnaire_responses = self.db.query(QuestionnaireResponse).filter(
            QuestionnaireResponse.session_id == session_id
        ).all()
        use_cases = self.db.query(GeneratedUseCase).filter(
            GeneratedUseCase.session_id == session_id
        ).all()
        questionnaire_url, _ = self._refresh_presigned_url(session)
        if report_request.report_type == "pdf":
            self.logger.info(f"Preparing data for PDF report for session {session_id}")
            session_data = {
                "session_name": session.session_name or "N/A",
                "description": session.description or "N/A",
                "status": session.status or "N/A",
                "created_at": session.created_at.strftime("%Y-%m-%d %H:%M:%S") if session.created_at else "N/A",
                "updated_at": session.updated_at.strftime("%Y-%m-%d %H:%M:%S") if session.updated_at else "N/A",
                "presigned_url": questionnaire_url
            }
            questionnaire_data = [
                {
                    "category": resp.category or "General",
                    "question": resp.question or "N/A",
                    "description": resp.description or "",
                    "response": resp.response or "N/A",
                    "additional_notes": resp.additional_notes or ""
                }
                for resp in questionnaire_responses
            ]
            use_cases_data = [
                {
                    "title": uc.title or "N/A",
                    "description": uc.description or "N/A",
                    "aws_services": uc.aws_services or [],
                    "primary_genai_capability": uc.primary_genai_capability or "N/A",
                    "business_category": uc.business_category or "N/A",
                    "priority": uc.priority or "N/A",
                    "complexity": uc.complexity or "N/A",
                    "estimated_effort": uc.estimated_effort or "N/A",
                    "cost_estimate": uc.cost_estimate or "N/A",
                    "roi_potential": uc.roi_potential or "N/A"
                }
                for uc in use_cases
            ]
            try:
                self.logger.info(f"Generating PDF content for session {session_id}")
                pdf_content = generate_pdf_report(session_data, questionnaire_data, use_cases_data)
                self.logger.info(f"PDF content generated successfully for session {session_id}")
                filename = f"pre_workshop_report_{session_id}.pdf"
                report_key = f"report_{session_id}"
                current_time = datetime.utcnow()
                if session.report_file_path and report_key in self.url_expirations and self.url_expirations[report_key] > current_time + timedelta(hours=1):
                    self.logger.info(f"Reusing existing report for session {session_id}, key: {session.report_file_path}")
                    presigned_url, expires_at = self._refresh_report_presigned_url(session)
                    self.logger.info(f"Exiting generate_report for session {session_id}")
                    return standard_response(
                        status_code=200,
                        success=True,
                        message="Existing PDF report retrieved successfully",
                        data={
                            "report_file_path": session.report_file_path,
                            "presigned_url": presigned_url,
                            "expires_at": expires_at.isoformat() if expires_at else None
                        }
                    )
                self.logger.info(f"Uploading PDF to S3 for session {session_id}, filename: {filename}")
                s3_key, presigned_url, expires_at = upload_file(
                    bucket_name=BUCKET_NAME,
                    file_content=pdf_content,
                    session_id=session_id,
                    session_name=session.session_name or "session",
                    filename=filename,
                    access_key=AWS_ACCESS_KEY_ID,
                    secret_key=AWS_SECRET_ACCESS_KEY,
                    region=AWS_REGION,
                    expiration=604800,
                    folder_prefix="generated_usecases",
                    project_name=project.name  # Pass project name
                )
                self.logger.info(f"PDF uploaded to S3, key: {s3_key}, presigned_url: {presigned_url}")
                if session.report_file_path:
                    self.logger.info(f"Attempting to delete old report S3 file: {session.report_file_path}")
                    try:
                        delete_file(
                            bucket_name=BUCKET_NAME,
                            s3_key=session.report_file_path,
                            access_key=AWS_ACCESS_KEY_ID,
                            secret_key=AWS_SECRET_ACCESS_KEY,
                            region=AWS_REGION
                        )
                        self.logger.info(f"Successfully deleted old report S3 file: {session.report_file_path}")
                    except Exception as e:
                        self.logger.warning(f"Failed to delete old report S3 file for session {session_id}: {str(e)}")
                self.logger.info(f"Updating session {session_id} with report_file_path: {s3_key}")
                try:
                    session.report_file_path = s3_key
                    session.status = "completed"
                    session.updated_at = datetime.utcnow()
                    self.db.commit()
                    self.logger.info(f"Session {session_id} updated with report_file_path: {s3_key}")
                except Exception as e:
                    self.logger.error(f"Failed to update session {session_id} in database: {str(e)}", exc_info=True)
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail=f"Failed to update session in database: {str(e)}"
                    )
                self.url_expirations[report_key] = expires_at
                self.logger.info(f"Exiting generate_report for session {session_id}")
                return standard_response(
                    status_code=200,
                    success=True,
                    message="PDF report generated and stored successfully",
                    data={
                        "report_file_path": s3_key,
                        "presigned_url": presigned_url,
                        "expires_at": expires_at.isoformat()
                    }
                )
            except Exception as e:
                self.logger.error(f"Error generating or storing PDF report for session {session_id}: {str(e)}", exc_info=True)
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Error generating or storing PDF report: {str(e)}"
                )
        elif report_request.report_type == "json":
            self.logger.info(f"Generating JSON report for session {session_id}")
            report_data = {
                "session_info": {
                    "id": session.id,
                    "session_name": session.session_name,
                    "description": session.description,
                    "status": session.status,
                    "created_at": session.created_at.isoformat(),
                    "updated_at": session.updated_at.isoformat(),
                    "questionnaire_presigned_url": questionnaire_url
                },
                "questionnaire_responses": [
                    {
                        "id": resp.id,
                        "category": resp.category,
                        "question": resp.question,
                        "description": resp.description,
                        "response": resp.response,
                        "additional_notes": resp.additional_notes,
                        "created_at": resp.created_at.isoformat()
                    }
                    for resp in questionnaire_responses
                ],
                "generated_use_cases": [
                    {
                        "id": uc.id,
                        "title": uc.title,
                        "description": uc.description,
                        "aws_services": uc.aws_services,
                        "primary_genai_capability": uc.primary_genai_capability,
                        "business_category": uc.business_category,
                        "customer_pain_points": uc.customer_pain_points,
                        "priority": uc.priority,
                        "complexity": uc.complexity,
                        "estimated_effort": uc.estimated_effort,
                        "success_metrics": uc.success_metrics,
                        "aws_architecture": uc.aws_architecture,
                        "cost_estimate": uc.cost_estimate,
                        "dependencies": uc.dependencies,
                        "risks": uc.risks,
                        "roi_potential": uc.roi_potential,
                        "implementation_phases": uc.implementation_phases,
                        "is_selected": uc.is_selected
                    }
                    for uc in use_cases
                ]
            }
            self.logger.info(f"Updating session {session_id} for JSON report")
            try:
                session.status = "completed"
                session.updated_at = datetime.utcnow()
                self.db.commit()
                self.logger.info(f"Session {session_id} updated for JSON report")
            except Exception as e:
                self.logger.error(f"Failed to update session {session_id} for JSON report: {str(e)}", exc_info=True)
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Failed to update session in database: {str(e)}"
                )
            self.logger.info(f"Exiting generate_report for session {session_id}")
            return Response(
                content=json.dumps(report_data, indent=2),
                media_type="application/json",
                headers={
                    "Content-Disposition": f"attachment; filename=pre_workshop_report_{session_id}.json"
                }
            )
        else:
            self.logger.error(f"Invalid report type for session {session_id}: {report_request.report_type}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid report type. Supported types: pdf, json"
            )

    def select_use_cases(self, session_id: int, selection_data: BulkUseCaseSelection, current_user: User) -> Dict[str, Any]:
        self.logger.info(f"Entering select_use_cases for session {session_id}")
        session = self._verify_session_access(session_id, current_user)
        use_cases = self.db.query(GeneratedUseCase).filter(
            GeneratedUseCase.session_id == session_id,
            GeneratedUseCase.id.in_(selection_data.use_case_ids)
        ).all()
        if len(use_cases) != len(selection_data.use_case_ids):
            found_ids = [uc.id for uc in use_cases]
            missing_ids = [uc_id for uc_id in selection_data.use_case_ids if uc_id not in found_ids]
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Use cases not found: {missing_ids}"
            )
        updated_count = 0
        for use_case in use_cases:
            use_case.is_selected = selection_data.is_selected
            updated_count += 1
        self.db.commit()
        self.logger.info(f"Exiting select_use_cases for session {session_id}, updated {updated_count} use cases")
        action = "selected" if selection_data.is_selected else "deselected"
        return {
            "message": f"Successfully {action} {updated_count} use cases",
            "updated_use_cases": updated_count,
            "use_case_ids": selection_data.use_case_ids,
            "is_selected": selection_data.is_selected
        }

    def get_selected_use_cases(self, session_id: int, current_user: User) -> Dict[str, Any]:
        self.logger.info(f"Entering get_selected_use_cases for session {session_id}")
        session = self._verify_session_access(session_id, current_user)
        selected_use_cases = self.db.query(GeneratedUseCase).filter(
            GeneratedUseCase.session_id == session_id,
            GeneratedUseCase.is_selected == True
        ).all()
        self.logger.info(f"Exiting get_selected_use_cases for session {session_id}, found {len(selected_use_cases)} use cases")
        return {
            "session_id": session_id,
            "total_selected": len(selected_use_cases),
            "selected_use_cases": [
                {
                    "id": uc.id,
                    "title": uc.title,
                    "description": uc.description,
                    "priority": uc.priority,
                    "complexity": uc.complexity,
                    "roi_potential": uc.roi_potential,
                    "aws_services": uc.aws_services
                }
                for uc in selected_use_cases
            ]
        }

    def delete_session(self, session_id: int, current_user: User) -> Dict[str, str]:
        self.logger.info(f"Entering delete_session for session {session_id}")
        session = self._verify_session_access(session_id, current_user)
        if session.questionnaire_file_path:
            try:
                delete_file(
                    bucket_name=BUCKET_NAME,
                    s3_key=session.questionnaire_file_path,
                    access_key=AWS_ACCESS_KEY_ID,
                    secret_key=AWS_SECRET_ACCESS_KEY,
                    region=AWS_REGION
                )
                self.logger.info(f"Deleted questionnaire S3 file: {session.questionnaire_file_path}")
            except Exception as e:
                self.logger.error(f"Failed to delete questionnaire S3 file for session {session_id}: {str(e)}")
        if session.report_file_path:
            try:
                delete_file(
                    bucket_name=BUCKET_NAME,
                    s3_key=session.report_file_path,
                    access_key=AWS_ACCESS_KEY_ID,
                    secret_key=AWS_SECRET_ACCESS_KEY,
                    region=AWS_REGION
                )
                self.logger.info(f"Deleted report S3 file: {session.report_file_path}")
            except Exception as e:
                self.logger.error(f"Failed to delete report S3 file for session {session_id}: {str(e)}")
        self.db.query(QuestionnaireResponse).filter(
            QuestionnaireResponse.session_id == session_id
        ).delete()
        self.db.query(GeneratedUseCase).filter(
            GeneratedUseCase.session_id == session_id
        ).delete()
        self.db.delete(session)
        self.db.commit()
        if session_id in self.url_expirations:
            del self.url_expirations[session_id]
        if f"report_{session_id}" in self.url_expirations:
            del self.url_expirations[f"report_{session_id}"]
        self.logger.info(f"Exiting delete_session for session {session_id}")
        return {
            "id": session_id,
            "message": "Pre-workshop session deleted successfully"
        }

    def create_custom_use_case(self, session_id: int, use_case_data: CustomUseCaseCreate, current_user: User) -> Dict[str, Any]:
        self.logger.info(f"Entering create_custom_use_case for session {session_id}")
        session = self._verify_session_access(session_id, current_user)
        db_use_case = GeneratedUseCase(
            session_id=session_id,
            title=use_case_data.title,
            description=use_case_data.description,
            aws_services=use_case_data.aws_services,
            primary_genai_capability=use_case_data.primary_genai_capability,
            business_category=use_case_data.business_category,
            customer_pain_points=use_case_data.customer_pain_points,
            priority=use_case_data.priority,
            complexity=use_case_data.complexity,
            estimated_effort=use_case_data.estimated_effort,
            success_metrics=use_case_data.success_metrics,
            aws_architecture=use_case_data.aws_architecture,
            cost_estimate=use_case_data.cost_estimate,
            dependencies=use_case_data.dependencies,
            risks=use_case_data.risks,
            roi_potential=use_case_data.roi_potential,
            implementation_phases=use_case_data.implementation_phases,
            is_selected=use_case_data.is_selected,
            created_at=datetime.utcnow()
        )
        self.db.add(db_use_case)
        self.db.commit()
        self.db.refresh(db_use_case)
        self.logger.info(f"Exiting create_custom_use_case for session {session_id}, created use case {db_use_case.id}")
        return {
            "id": db_use_case.id,
            "title": db_use_case.title,
            "description": db_use_case.description,
            "aws_services": db_use_case.aws_services,
            "primary_genai_capability": db_use_case.primary_genai_capability,
            "business_category": db_use_case.business_category,
            "customer_pain_points": db_use_case.customer_pain_points,
            "priority": db_use_case.priority,
            "complexity": db_use_case.complexity,
            "estimated_effort": db_use_case.estimated_effort,
            "success_metrics": db_use_case.success_metrics,
            "aws_architecture": db_use_case.aws_architecture,
            "cost_estimate": db_use_case.cost_estimate,
            "dependencies": db_use_case.dependencies,
            "risks": db_use_case.risks,
            "roi_potential": db_use_case.roi_potential,
            "implementation_phases": db_use_case.implementation_phases,
            "is_selected": db_use_case.is_selected,
            "created_at": db_use_case.created_at.isoformat()
        }

    def update_use_case(self, session_id: int, use_case_id: int, use_case_data: CustomUseCaseUpdate, current_user: User) -> Dict[str, Any]:
        self.logger.info(f"Entering update_use_case for session {session_id}, use_case {use_case_id}")
        session = self._verify_session_access(session_id, current_user)
        use_case = self.db.query(GeneratedUseCase).filter(
            GeneratedUseCase.id == use_case_id,
            GeneratedUseCase.session_id == session_id
        ).first()
        if not use_case:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Use case not found"
            )
        update_data = use_case_data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(use_case, field, value)
        use_case.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(use_case)
        self.logger.info(f"Exiting update_use_case for session {session_id}, use_case {use_case_id}")
        return {
            "id": use_case.id,
            "title": use_case.title,
            "description": use_case.description,
            "aws_services": use_case.aws_services,
            "primary_genai_capability": use_case.primary_genai_capability,
            "business_category": use_case.business_category,
            "customer_pain_points": use_case.customer_pain_points,
            "priority": use_case.priority,
            "complexity": use_case.complexity,
            "estimated_effort": use_case.estimated_effort,
            "success_metrics": use_case.success_metrics,
            "aws_architecture": use_case.aws_architecture,
            "cost_estimate": use_case.cost_estimate,
            "dependencies": use_case.dependencies,
            "risks": use_case.risks,
            "roi_potential": use_case.roi_potential,
            "implementation_phases": use_case.implementation_phases,
            "is_selected": use_case.is_selected,
            "created_at": use_case.created_at.isoformat(),
            "updated_at": use_case.updated_at.isoformat()
        }

    def delete_use_case(self, session_id: int, use_case_id: int, current_user: User) -> Dict[str, Any]:
        self.logger.info(f"Entering delete_use_case for session {session_id}, use_case {use_case_id}")
        session = self._verify_session_access(session_id, current_user)
        use_case = self.db.query(GeneratedUseCase).filter(
            GeneratedUseCase.id == use_case_id,
            GeneratedUseCase.session_id == session_id
        ).first()
        if not use_case:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Use case not found"
            )
        use_case_data = {
            "id": use_case.id,
            "title": use_case.title,
            "session_id": use_case.session_id
        }
        self.db.delete(use_case)
        self.db.commit()
        self.logger.info(f"Exiting delete_use_case for session {session_id}, use_case {use_case_id}")
        return use_case_data

    def get_use_case(self, session_id: int, use_case_id: int, current_user: User) -> Dict[str, Any]:
        self.logger.info(f"Entering get_use_case for session {session_id}, use_case {use_case_id}")
        session = self._verify_session_access(session_id, current_user)
        use_case = self.db.query(GeneratedUseCase).filter(
            GeneratedUseCase.id == use_case_id,
            GeneratedUseCase.session_id == session_id
        ).first()
        if not use_case:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Use case not found"
            )
        self.logger.info(f"Exiting get_use_case for session {session_id}, use_case {use_case_id}")
        return {
            "id": use_case.id,
            "title": use_case.title,
            "description": use_case.description,
            "aws_services": use_case.aws_services,
            "primary_genai_capability": use_case.primary_genai_capability,
            "business_category": use_case.business_category,
            "customer_pain_points": use_case.customer_pain_points,
            "priority": use_case.priority,
            "complexity": use_case.complexity,
            "estimated_effort": use_case.estimated_effort,
            "success_metrics": use_case.success_metrics,
            "aws_architecture": use_case.aws_architecture,
            "cost_estimate": use_case.cost_estimate,
            "dependencies": use_case.dependencies,
            "risks": use_case.risks,
            "roi_potential": use_case.roi_potential,
            "implementation_phases": use_case.implementation_phases,
        }