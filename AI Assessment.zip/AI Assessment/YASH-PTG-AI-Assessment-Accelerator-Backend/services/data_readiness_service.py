from typing import Dict, Any, List
from groq import Groq
import json
import os
import logging
import asyncio
import google.generativeai as genai
from datetime import datetime
from utils.data_readiness_utils import FileProcessor, DataReadinessPDFGenerator, DataRequirement, DataFile, DataReadinessAnalysisResponse

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataReadinessAnalyzerService:
    """Service class for data readiness analysis and report generation"""
    
    SUPPORTED_EXTENSIONS = {
        '.csv': 'text/csv',
        '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        '.xls': 'application/vnd.ms-excel',
        '.txt': 'text/plain',
        '.json': 'application/json',
        '.parquet': 'application/parquet'
    }
    
    def __init__(self, api_key: str, model: str = "deepseek-r1-distill-llama-70b"):
        # self.client = Groq(api_key=api_key)
        genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
        self.client = genai.GenerativeModel('gemini-2.0-flash')
        self.model = model
        self.file_processor = FileProcessor()
        self.pdf_generator = DataReadinessPDFGenerator()
    
    async def analyze_data_readiness(self,use_case_data: Dict, data_files: List[DataFile],custom_parameters:str=None) -> Dict[str, Any]:
        """Analyze data readiness and generate markdown report"""
        try:
            # Process the uploaded file
            # data_file = await self.file_processor.process_file(file_path, filename)
            
            # Extract requirements
            requirements = self.extract_data_requirements(use_case_data)
            
            # Match data to requirements
            analysis = self.match_data_to_requirements(data_files, requirements)
            
            # Determine overall status
            score = analysis["overall_score"]
            if score >= 80:
                status = "Ready"
            elif score >= 50:
                status = "Partially Ready"
            else:
                status = "Not Ready"
            
            # Prepare context for AI analysis
            context = self._prepare_analysis_context(use_case_data, data_files, analysis, requirements)
            sample_data = str([{f"{file.filename}":file.sample_data} for file in data_files if file.sample_data])
            # Generate comprehensive markdown analysis
            markdown_content = await self._generate_ai_analysis(context, score, status,sample_data,use_case_data,custom_parameters)
            
            return {
                'use_case_id': use_case_data.get('id'),
                'analysis_type': "comprehensive",
                'generated_content': markdown_content,
                'readiness_score': score,
                'status': status,
                'files_count': 1,
                'generated_at': datetime.utcnow()
            }
        except Exception as e:
            logger.error(f"Error in data readiness analysis: {str(e)}")
            raise
    
    def generate_pdf(self, markdown_content: str) -> bytes:
        """Generate PDF from markdown content"""
        return self.pdf_generator.generate_pdf(markdown_content, "Data Readiness Assessment Report")
    
    def extract_data_requirements(self, use_case: Dict[str, Any]) -> List[DataRequirement]:
        """Extract specific data requirements from use case using rule-based and LLM analysis"""
        requirements = []
        
        # Get primary capability and services
        primary_capability = use_case.get('primary_genai_capability', '').lower()
        aws_services = [service.lower() for service in use_case.get('aws_services', [])]
        title = use_case.get('title', '').lower()
        
        # Rule-based requirements extraction
        if 'customer' in title and 'support' in title:
            requirements.append(DataRequirement(
                name="customer_support_data",
                description="Customer support tickets and interactions",
                required_columns=["customer_message", "response", "ticket_id", "timestamp"],
                data_type="structured",
                minimum_rows=100,
                criticality="critical",
                weight=0.4
            ))
            
        if 'chatbot' in title or 'lex' in ' '.join(aws_services):
            requirements.append(DataRequirement(
                name="conversation_data",
                description="Conversation logs or chat transcripts",
                required_columns=["user_input", "bot_response", "intent", "confidence"],
                data_type="structured",
                minimum_rows=500,
                criticality="critical",
                weight=0.4
            ))
            
        if 'comprehend' in ' '.join(aws_services) or primary_capability == 'nlp':
            requirements.append(DataRequirement(
                name="text_data",
                description="Text data for NLP analysis",
                required_columns=["text", "label", "category"],
                data_type="text",
                minimum_rows=200,
                criticality="important",
                weight=0.3
            ))
            
        if 'fraud' in title:
            requirements.append(DataRequirement(
                name="transaction_data",
                description="Transaction records with fraud labels",
                required_columns=["transaction_id", "amount", "user_id", "is_fraud", "timestamp"],
                data_type="structured",
                minimum_rows=1000,
                criticality="critical",
                weight=0.5
            ))
            
        if 'recommendation' in title:
            requirements.append(DataRequirement(
                name="user_interaction_data",
                description="User behavior and interaction data",
                required_columns=["user_id", "item_id", "rating", "timestamp"],
                data_type="structured",
                minimum_rows=1000,
                criticality="critical",
                weight=0.4
            ))
        
        # Add LLM-based requirements extraction
        try:
            llm_requirements = self._get_llm_requirements(use_case)
            requirements.extend(llm_requirements)
        except Exception as e:
            logger.warning(f"LLM requirements extraction failed: {str(e)}")
        
        return requirements
    
    def _get_llm_requirements(self, use_case: Dict[str, Any]) -> List[DataRequirement]:
        """Use LLM to extract additional requirements"""
        prompt = f"""
        Analyze this AI use case and identify the top 3 most critical data requirements:
        
        Use Case: {json.dumps(use_case, indent=2)}
        
        For each requirement, provide:
        1. Name (snake_case)
        2. Description
        3. Required columns (list)
        4. Minimum rows needed
        5. Criticality (critical/important/nice_to_have)
        
        Return as JSON array:
        [
            {{
                "name": "requirement_name",
                "description": "What this data is for",
                "required_columns": ["col1", "col2", "col3"],
                "minimum_rows": 100,
                "criticality": "critical"
            }}
        ]
        """
        
        try:
            # response = self.client.chat.completions.create(
            #     messages=[
            #         {"role": "system", "content": "You are a data requirements analyst. Provide specific, technical data requirements in JSON format."},
            #         {"role": "user", "content": prompt}
            #     ],
            #     model=self.model,
            #     temperature=0.1,
            #     max_tokens=1000
            # )
            
            # content = response.choices[0].message.content
            # # Extract JSON from response
            # start_idx = content.find('[')
            # end_idx = content.rfind(']') + 1
            # json_str = content[start_idx:end_idx]
            
            # requirements_data = json.loads(json_str)
            response = self.client.generate_content(
                prompt,
                generation_config=genai.types.GenerationConfig(
                temperature=0.1,
                max_output_tokens=1000,
                )
            )
            content = response.text
            print(content)
            start_idx = content.find('[')
            end_idx = content.rfind(']') + 1
            json_str = content[start_idx:end_idx]
            requirements_data = json.loads(json_str)
            
            requirements = []
            for req_data in requirements_data:
                weight = 0.5 if req_data['criticality'] == 'critical' else 0.3 if req_data['criticality'] == 'important' else 0.1
                requirements.append(DataRequirement(
                    name=req_data['name'],
                    description=req_data['description'],
                    required_columns=req_data['required_columns'],
                    data_type="structured",
                    minimum_rows=req_data['minimum_rows'],
                    criticality=req_data['criticality'],
                    weight=weight
                ))
            
            return requirements
            
        except Exception as e:
            logger.error(f"Error extracting LLM requirements: {str(e)}")
            return []
    
    def match_data_to_requirements(self, data_files: List[DataFile], requirements: List[DataRequirement]) -> Dict[str, Any]:
        """Match uploaded data files to requirements and calculate scores"""
        analysis = {
            "total_requirements": len(requirements),
            "met_requirements": 0,
            "partial_requirements": 0,
            "missing_requirements": 0,
            "requirement_details": [],
            "overall_score": 0.0
        }
        
        total_weight = sum(req.weight for req in requirements)
        weighted_score = 0.0
        
        for requirement in requirements:
            req_analysis = {
                "name": requirement.name,
                "description": requirement.description,
                "status": "missing",
                "matched_files": [],
                "score": 0.0,
                "issues": []
            }
            
            best_match_score = 0.0
            
            for data_file in data_files:
                if data_file.columns:
                    # Check column matching
                    matched_columns = []
                    for req_col in requirement.required_columns:
                        # Flexible matching (case-insensitive, partial matches)
                        for file_col in data_file.columns:
                            if (req_col.lower() in file_col.lower() or 
                                file_col.lower() in req_col.lower() or
                                self._calculate_similarity(req_col.lower(), file_col.lower()) > 0.7):
                                matched_columns.append(file_col)
                                break
                    
                    column_match_ratio = len(matched_columns) / len(requirement.required_columns)
                    
                    # Check row count
                    row_score = 1.0 if data_file.row_count >= requirement.minimum_rows else (data_file.row_count / requirement.minimum_rows)
                    
                    # Overall match score for this file
                    file_score = (column_match_ratio * 0.6 + row_score * 0.2 + data_file.data_quality_score * 0.2)
                    
                    if file_score > best_match_score:
                        best_match_score = file_score
                        req_analysis["matched_files"] = [data_file.filename]
                        req_analysis["score"] = file_score
                        
                        # Update file's matches
                        if requirement.name not in data_file.matches_requirements:
                            data_file.matches_requirements.append(requirement.name)
                        
                        # Add issues
                        if column_match_ratio < 1.0:
                            missing_cols = set(requirement.required_columns) - set(matched_columns)
                            req_analysis["issues"].append(f"Missing columns: {list(missing_cols)}")
                        
                        if row_score < 1.0:
                            req_analysis["issues"].append(f"Insufficient data volume: {data_file.row_count} rows (need {requirement.minimum_rows})")
            
            # Determine status
            if best_match_score >= 0.8:
                req_analysis["status"] = "met"
                analysis["met_requirements"] += 1
            elif best_match_score >= 0.4:
                req_analysis["status"] = "partial"
                analysis["partial_requirements"] += 1
            else:
                req_analysis["status"] = "missing"
                analysis["missing_requirements"] += 1
            
            analysis["requirement_details"].append(req_analysis)
            
            # Add to weighted score
            weighted_score += best_match_score * requirement.weight
        
        # Calculate overall score
        if total_weight > 0:
            analysis["overall_score"] = float(round((weighted_score / total_weight) * 100, 1))
        
        return analysis
    
    def _calculate_similarity(self, str1: str, str2: str) -> float:
        """Calculate similarity between two strings"""
        set1, set2 = set(str1), set(str2)
        intersection = set1.intersection(set2)
        union = set1.union(set2)
        return len(intersection) / len(union) if union else 0.0
    
    def _prepare_analysis_context(self, use_case_data: Dict, data_files: List[DataFile], analysis: Dict, requirements: List[DataRequirement]) -> str:
        """Prepare context for AI analysis"""
        files_summary = []
        for file in data_files:
            files_summary.append({
                "filename": file.filename,
                "type": file.file_type,
                "size_mb": file.size_mb,
                "rows": file.row_count,
                "columns": len(file.columns) if file.columns else 0,
                "quality_score": file.data_quality_score,
                "matches": file.matches_requirements
            })
        
        requirements_summary = []
        for req in requirements:
            req_analysis = next((r for r in analysis["requirement_details"] if r["name"] == req.name), {})
            requirements_summary.append({
                "name": req.name,
                "description": req.description,
                "required_columns": req.required_columns,
                "minimum_rows": req.minimum_rows,
                "criticality": req.criticality,
                "status": req_analysis.get("status", "unknown"),
                "score": req_analysis.get("score", 0.0),
                "issues": req_analysis.get("issues", [])
            })
        
        context = f"""
        # Use Case Information
        - **Title**: {use_case_data.get('title', 'N/A')}
        - **Description**: {use_case_data.get('description', 'N/A')}
        - **AWS Services**: {', '.join(use_case_data.get('aws_services', []))}
        - **Primary GenAI Capability**: {use_case_data.get('primary_genai_capability', 'N/A')}
        - **Business Category**: {use_case_data.get('business_category', 'N/A')}
        - **Priority**: {use_case_data.get('priority', 'N/A')}
        - **Complexity**: {use_case_data.get('complexity', 'N/A')}
        
        # Uploaded Files Analysis
        {json.dumps(files_summary, indent=2)}
        
        # Data Requirements Assessment
        {json.dumps(requirements_summary, indent=2)}
        
        # Overall Analysis Results
        - **Overall Score**: {analysis['overall_score']}%
        - **Total Requirements**: {analysis['total_requirements']}
        - **Met Requirements**: Old: {analysis['met_requirements']}
        - **Partial Requirements**: {analysis['partial_requirements']}
        - **Missing Requirements**: {analysis['missing_requirements']}
        """
        return context
    
    async def _generate_ai_analysis(self, context: str, score: float, status: str,sample_data:str,Usecase_data:Dict,custom_parameters:str) -> str:
        """Generate AI-powered comprehensive markdown analysis"""
        system_prompt = f"""
        You are a senior data scientist and AI consultant specializing in data readiness assessment for GenAI implementations.
        Your task is to analyze the provided data and generate a comprehensive data readiness report.
        
        Focus on the following areas:
        1. Executive Summary with clear recommendations
        2. Data Quality Assessment
        3. Requirements Coverage Analysis
        4. Identified Gaps and Issues
        5. Data Preparation Recommendations
        6. Implementation Readiness Assessment
        7. Next Steps and Action Items
        
        Generate a detailed report in markdown format with clear sections and actionable insights.
        Be specific about data quality issues and provide practical recommendations.
        """
        
        user_request = f"""
        Please analyze the following data readiness assessment and generate a comprehensive report:
        
        **Overall Readiness Score**: {score}%
        **Status**: {status}
        
        {context}
        
        And this is the sample uploaded data from different files by the user 
        {sample_data}

        This is the custom parameters provided by the user {custom_parameters} on behalf of which you 
        need to check the data readiness and generate the report.
        
        Generate a comprehensive data readiness assessment report Whether the sample data that
        is Provided is sufficient for this specific usercase {Usecase_data} There could be differnet different 
        data for this specific user and provide the detailed report what data actually not provided for 
        this usecase in markdown format.
        Provide drawback Uplaoded data wise why this data is not sufficient for this usecase.

        Also Suggest the required of Columns and the data for this specific useecase that is required for this 
        usecase and also provide the data quality issues that are found in the sample data.
        Also provide the tabular form of data for analysis .
        Provide specific, actionable recommendations and highlight critical issues that need attention.
        Structure the report with clear headings and bullet points for easy reading.
        """
        
        try:
            # response = await asyncio.get_event_loop().run_in_executor(
            #     None, 
            #     lambda: self.client.chat.completions.create(
            #         model=self.model,
            #         messages=[
            #             {"role": "system", "content": system_prompt},
            #             {"role": "user", "content": user_request}
            #         ],
            #         temperature=0.7,
            #         max_tokens=4000
            #     )
            # )
            response = self.client.generate_content(
                user_request,
                generation_config=genai.types.GenerationConfig(
                temperature=0.8,
                )
            )
            content=response.text.strip()
            return content.replace("<think>","")
            
        except Exception as e:
            return f"""
            # Data Readiness Assessment Report
            
            ## Executive Summary
            
            **Overall Readiness Score**: {score}%  
            **Status**: {status}
            
            An error occurred while generating the detailed analysis: {str(e)}
            
            ## Manual Review Required
            
            Please review the following items manually:
            - Data quality and completeness assessment
            - Requirements coverage validation
            - Column mapping and data type verification
            - Volume and sampling adequacy
            - Data preparation and cleaning needs
            
            ## Files Processed
            
            The system successfully processed the uploaded files but requires manual analysis for detailed assessment.
            
            ## Recommendations
            
            1. Verify data quality manually
            2. Ensure all required columns are present
            3. Check data volume adequacy
            4. Validate data formats and types
            5. Plan data preprocessing steps
            """