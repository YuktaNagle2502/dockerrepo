from sqlalchemy.orm import Session
from pydantic import EmailStr
from datetime import datetime, timedelta
from typing import Optional, List
from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
import jwt
from passlib.context import CryptContext
from models.pydantic_models import UserCreate, UserLogin, UserResponse, ProjectCreate, ProjectResponse, ProjectWithOwner, LoginResponse
from models.models import User, Project
from database import get_db

security = HTTPBearer()

class AuthService:
    def __init__(self, secret_key: str, algorithm: str, access_token_expire_minutes: int = 30):
        self.pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        self.secret_key = secret_key
        self.algorithm = algorithm
        self.access_token_expire_minutes = access_token_expire_minutes

    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify a plain password against its hashed version"""
        return self.pwd_context.verify(plain_password, hashed_password)

    def get_password_hash(self, password: str) -> str:
        """Hash a password using bcrypt"""
        return self.pwd_context.hash(password)

    def create_access_token(self, data: dict, expires_delta: Optional[timedelta] = None) -> str:
        """Create a JWT access token"""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=self.access_token_expire_minutes)
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, self.secret_key, algorithm=self.algorithm)
        return encoded_jwt

    def verify_token(self, token: str) -> str:
        """Verify and decode a JWT token"""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            email: str = payload.get("sub")
            if email is None:
                raise ValueError("Invalid token payload")
            return email
        except jwt.PyJWTError as e:
            raise ValueError(f"Could not validate credentials: {str(e)}")

    def get_current_user(self, credentials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)) -> User:
        """Get the current user from a JWT token"""
        email = self.verify_token(credentials.credentials)
        user = db.query(User).filter(User.email == email, User.is_active == True).first()
        print("user:",user)
        if user is None:
            raise ValueError("User not found or inactive")
        return user

    def register_user(self, user: UserCreate, db: Session) -> UserResponse:
        """Register a new user"""
        db_user = db.query(User).filter(User.email == user.email).first()
        if db_user:
            raise ValueError("Email already registered")
        
        hashed_password = self.get_password_hash(user.password)
        db_user = User(
            email=user.email,
            hashed_password=hashed_password,
            full_name=user.full_name,
            is_active=True,
            created_at=datetime.utcnow()
        )
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        
        return UserResponse.model_validate(db_user)

    def login_user(self, user_credentials: UserLogin, db: Session) -> LoginResponse:
        """Login user and return access token"""
        user = db.query(User).filter(User.email == user_credentials.email).first()
        if not user or not self.verify_password(user_credentials.password, user.hashed_password):
            raise ValueError("Incorrect email or password")
        
        if not user.is_active:
            raise ValueError("Inactive user")
        
        access_token = self.create_access_token(
            data={"sub": user.email},
            expires_delta=timedelta(minutes=self.access_token_expire_minutes)
        )
        
        return LoginResponse(
            access_token=access_token,
            token_type="bearer",
            user=UserResponse.model_validate(user),
            message="Login successful"
        )

    def create_project(self, project: ProjectCreate, current_user: User, db: Session) -> ProjectResponse:
        """Create a new project for the authenticated user"""
        existing_project = db.query(Project).filter(
            Project.name == project.name,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        
        if existing_project:
            # return ValueError("Project with this name already exists")
            raise ValueError("Project with this name already exists")
        
        db_project = Project(
            name=project.name,
            description=project.description,
            owner_id=current_user.id,
            is_active=True,
            created_at=datetime.utcnow()
        )
        db.add(db_project)
        db.commit()
        db.refresh(db_project)
        
        return ProjectResponse.model_validate(db_project)

    def get_user_projects(self, current_user: User, db: Session) -> List[ProjectResponse]:
        """Get all projects for the authenticated user"""
        projects = db.query(Project).filter(
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).all()
        
        return [ProjectResponse.model_validate(project) for project in projects]

    def get_project_by_id(self, project_id: int, current_user: User, db: Session) -> ProjectWithOwner:
        """Get a specific project by ID if owned by current user"""
        project = db.query(Project).filter(
            Project.id == project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        
        if not project:
            raise KeyError("Project not found")
        
        return ProjectWithOwner(
            id=project.id,
            name=project.name,
            description=project.description,
            owner_id=project.owner_id,
            is_active=project.is_active,
            created_at=project.created_at,
            owner=UserResponse.model_validate(project.owner)
        ).model_validate(project)

    def update_project(self, project_id: int, project_update: ProjectCreate, current_user: User, db: Session) -> ProjectResponse:
        """Update a project if owned by current user"""
        project = db.query(Project).filter(
            Project.id == project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        
        if not project:
            raise KeyError("Project not found")
        
        if project_update.name != project.name:
            existing_project = db.query(Project).filter(
                Project.name == project_update.name,
                Project.owner_id == current_user.id,
                Project.is_active == True,
                Project.id != project_id
            ).first()
            
            if existing_project:
                raise ValueError("Project with this name already exists")
        
        project.name = project_update.name
        project.description = project_update.description
        project.updated_at = datetime.utcnow()
        
        db.commit()
        db.refresh(project)
        
        return ProjectResponse.model_validate(project)

    def delete_project(self, project_id: int, current_user: User, db: Session) -> dict:
        """Soft delete a project if owned by current user"""
        project = db.query(Project).filter(
            Project.id == project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        
        if not project:
            raise KeyError("Project not found")
        
        project.is_active = False
        project.updated_at = datetime.utcnow()
        
        db.commit()
        
        return {
            "id":project_id,
            "message": "Project deleted successfully"
            }