from pydantic import BaseModel, Field
from datetime import datetime
from typing import Dict, Any, List
import json
import os
from groq import Groq
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Pydantic Models
class SprintPlanningRequest(BaseModel):
    use_case_id: int
    project_type: str = Field(default="web application", description="Type of project: web application, mobile app, data platform, etc.")
    sprint_duration: str = Field(default="2 weeks", description="Duration of each sprint")
    total_sprints: int = Field(default=4, description="Total number of sprints")
    team_size: int = Field(default=4, description="Total team members")
    
class SprintPlanningResponse(BaseModel):
    use_case_id: int
    project_type: str
    generated_content: Dict[str, Any]
    total_sprints: int
    estimated_duration: str
    estimated_cost: str
    generated_at: datetime

# Sprint Planning Content Generator
class SprintPlanningGenerator:
    def __init__(self):
        """Initialize the sprint planning generator with Groq API key."""
        self.groq_api_key = os.getenv("GROQ_API_KEY")
        if not self.groq_api_key:
            logger.warning("GROQ_API_KEY not found in environment variables")
        self.groq_client = Groq(api_key=self.groq_api_key)
    
    async def generate_sprint_content(self, use_case_data: Dict[str, Any], project_type: str = "web application") -> Dict[str, Any]:
        """Generate comprehensive sprint planning content using Groq LLM."""
        
        # Format use case data for the prompt
        use_case_description = json.dumps(use_case_data, indent=2)
        
        prompt = f"""
        You are a senior project manager and technical architect. Generate a comprehensive sprint planning document for the following project:

        Project Description: {use_case_description}
        Project Type: {project_type}

        Please provide a detailed response in the following JSON format:

        {{
            "project_overview": {{
                "title": "Project Title",
                "description": "Detailed project description",
                "objectives": ["objective1", "objective2", "objective3"],
                "scope": "Project scope description",
                "success_criteria": ["criteria1", "criteria2", "criteria3"]
            }},
            "technical_requirements": {{
                "technology_stack": ["tech1", "tech2", "tech3"],
                "architecture_pattern": "Architecture pattern description",
                "database_requirements": "Database requirements",
                "security_requirements": ["security1", "security2", "security3"]
            }},
            "aws_services": {{
                "compute": ["EC2", "Lambda", "ECS"],
                "storage": ["S3", "RDS", "DynamoDB"],
                "networking": ["VPC", "CloudFront", "API Gateway"],
                "security": ["IAM", "Cognito", "WAF"],
                "monitoring": ["CloudWatch", "X-Ray", "CloudTrail"],
                "estimated_monthly_cost": "$500-800"
            }},
            "team_structure": {{
                "total_developers": 4,
                "roles": [
                    {{"role": "Full-Stack Developer", "count": 2, "responsibilities": ["Frontend", "Backend", "API Development"]}},
                    {{"role": "DevOps Engineer", "count": 1, "responsibilities": ["Infrastructure", "CI/CD", "Monitoring"]}},
                    {{"role": "QA Engineer", "count": 1, "responsibilities": ["Testing", "Quality Assurance", "Bug Reporting"]}}
                ]
            }},
            "sprint_plan": {{
                "duration": "8 weeks",
                "total_sprints": 4,
                "sprints": [
                    {{
                        "sprint_number": 1,
                        "duration": "2 weeks",
                        "goals": ["Setup environment", "Basic authentication", "Database schema"],
                        "tasks": [
                            {{"task": "Project setup and repository creation", "effort": "8 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "AWS infrastructure setup", "effort": "16 hours", "assignee": "DevOps Engineer"}},
                            {{"task": "Database design and setup", "effort": "12 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "Basic authentication implementation", "effort": "20 hours", "assignee": "Full-Stack Developer"}}
                        ],
                        "deliverables": ["Environment setup", "Authentication system", "Database schema"]
                    }},
                    {{
                        "sprint_number": 2,
                        "duration": "2 weeks",
                        "goals": ["Core functionality", "API development", "Frontend foundation"],
                        "tasks": [
                            {{"task": "Core API development", "effort": "24 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "Frontend framework setup", "effort": "12 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "User interface design", "effort": "16 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "Testing framework setup", "effort": "8 hours", "assignee": "QA Engineer"}}
                        ],
                        "deliverables": ["Core APIs", "Frontend foundation", "Testing framework"]
                    }},
                    {{
                        "sprint_number": 3,
                        "duration": "2 weeks",
                        "goals": ["Feature completion", "Integration testing", "Performance optimization"],
                        "tasks": [
                            {{"task": "Feature implementation", "effort": "28 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "Integration testing", "effort": "16 hours", "assignee": "QA Engineer"}},
                            {{"task": "Performance optimization", "effort": "12 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "Security implementation", "effort": "16 hours", "assignee": "DevOps Engineer"}}
                        ],
                        "deliverables": ["Complete features", "Integration tests", "Performance optimization"]
                    }},
                    {{
                        "sprint_number": 4,
                        "duration": "2 weeks",
                        "goals": ["Final testing", "Deployment", "Documentation"],
                        "tasks": [
                            {{"task": "End-to-end testing", "effort": "20 hours", "assignee": "QA Engineer"}},
                            {{"task": "Production deployment", "effort": "16 hours", "assignee": "DevOps Engineer"}},
                            {{"task": "Documentation completion", "effort": "12 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "User training materials", "effort": "8 hours", "assignee": "Full-Stack Developer"}}
                        ],
                        "deliverables": ["Production deployment", "Complete documentation", "Training materials"]
                    }}
                ]
            }},
            "risks_and_mitigation": [
                {{"risk": "Technical complexity", "impact": "High", "mitigation": "Regular code reviews and technical spikes"}},
                {{"risk": "Resource availability", "impact": "Medium", "mitigation": "Cross-training and knowledge sharing"}},
                {{"risk": "Integration challenges", "impact": "Medium", "mitigation": "Early integration testing and API contracts"}}
            ],
            "budget_estimation": {{
                "development_cost": "$32,000-40,000",
                "aws_infrastructure": "$500-800/month",
                "third_party_services": "$200-400/month",
                "total_poc_cost": "$35,000-45,000"
            }}
        }}

        Generate realistic and detailed content for each section based on the project description provided.
        """
        
        try:
            response = self.groq_client.chat.completions.create(
                model="llama3-70b-8192",
                messages=[
                    {"role": "system", "content": "You are a senior project manager and technical architect with extensive experience in software development and AWS cloud infrastructure."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=4000
            )
            
            content = response.choices[0].message.content
            
            # Clean up the response to extract JSON
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0].strip()
            elif "```" in content:
                content = content.split("```")[1].split("```")[0].strip()
            
            return json.loads(content)
            
        except Exception as e:
            logger.error(f"Error generating content with Groq: {e}")
            return self._get_fallback_content()

    def _get_fallback_content(self) -> Dict[str, Any]:
        """Provide fallback content in case of API failure."""
        return {
            "project_overview": {
                "title": "Sample Project",
                "description": "This is a sample project generated as fallback content.",
                "objectives": ["Implement core functionality", "Ensure scalability", "Maintain security"],
                "scope": "Development of a full-stack web application with cloud deployment",
                "success_criteria": ["Successful deployment", "Performance benchmarks met", "Security compliance achieved"]
            },
            "technical_requirements": {
                "technology_stack": ["React.js", "Node.js", "Python", "PostgreSQL"],
                "architecture_pattern": "Microservices architecture with API Gateway",
                "database_requirements": "PostgreSQL for relational data, Redis for caching",
                "security_requirements": ["JWT authentication", "HTTPS encryption", "Input validation"]
            },
            "aws_services": {
                "compute": ["EC2", "Lambda", "ECS"],
                "storage": ["S3", "RDS", "DynamoDB"],
                "networking": ["VPC", "CloudFront", "API Gateway"],
                "security": ["IAM", "Cognito", "WAF"],
                "monitoring": ["CloudWatch", "X-Ray", "CloudTrail"],
                "estimated_monthly_cost": "$500-800"
            },
            "team_structure": {
                "total_developers": 4,
                "roles": [
                    {"role": "Full-Stack Developer", "count": 2, "responsibilities": ["Frontend", "Backend", "API Development"]},
                    {"role": "DevOps Engineer", "count": 1, "responsibilities": ["Infrastructure", "CI/CD", "Monitoring"]},
                    {"role": "QA Engineer", "count": 1, "responsibilities": ["Testing", "Quality Assurance", "Bug Reporting"]}
                ]
            },
            "sprint_plan": {
                "duration": "8 weeks",
                "total_sprints": 4,
                "sprints": [
                    {
                        "sprint_number": 1,
                        "duration": "2 weeks",
                        "goals": ["Setup environment", "Basic authentication", "Database schema"],
                        "tasks": [
                            {"task": "Project setup and repository creation", "effort": "8 hours", "assignee": "Full-Stack Developer"},
                            {"task": "AWS infrastructure setup", "effort": "16 hours", "assignee": "DevOps Engineer"}
                        ],
                        "deliverables": ["Environment setup", "Authentication system"]
                    }
                ]
            },
            "risks_and_mitigation": [
                {"risk": "Technical complexity", "impact": "High", "mitigation": "Regular code reviews and technical spikes"}
            ],
            "budget_estimation": {
                "development_cost": "$32,000-40,000",
                "aws_infrastructure": "$500-800/month",
                "third_party_services": "$200-400/month",
                "total_poc_cost": "$35,000-45,000"
            }
        }