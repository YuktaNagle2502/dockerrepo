import io
from fastapi import UploadFile
import pandas as pd
import json
from groq import Groq
from datetime import datetime
import logging
import os
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import BinaryIO, Optional, List, Dict, Any
# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataProfilerAPI:
    """
    API-based data profiling system using Groq API
    Supports CSV, TXT, Excel, JSON, and Parquet files
    """
    
    def __init__(self, groq_api_key: str):
        """Initialize the data profiler with Groq API key"""
        self.groq_client = Groq(api_key=groq_api_key)
        self.supported_formats = ['.csv', '.txt', '.parquet', '.xlsx', '.xls', '.json']
        self.logger = logger
        
    # async def load_data(self, file_path: str) -> pd.DataFrame:
    #     """Load data from various file formats"""
    #     file_ext = os.path.splitext(file_path)[1].lower()
        
    #     if file_ext not in self.supported_formats:
    #         raise ValueError(f"Unsupported file format: {file_ext}. Supported formats: {self.supported_formats}")
        
    #     try:
    #         if file_ext == '.csv':
    #             # Try different encodings and separators
    #             encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
    #             separators = [',', ';', '\t', '|']
                
    #             for encoding in encodings:
    #                 for sep in separators:
    #                     try:
    #                         df = pd.read_csv(file_path, encoding=encoding, sep=sep)
    #                         if len(df.columns) > 1:  # Valid CSV should have multiple columns
    #                             self.logger.info(f"Successfully loaded CSV with encoding: {encoding}, separator: {sep}")
    #                             return df
    #                     except:
    #                         continue
                
    #             # Fallback to basic CSV loading
    #             df = pd.read_csv(file_path)
                
    #         elif file_ext == '.txt':
    #             # Try to detect if it's a delimited file
    #             try:
    #                 with open(file_path, 'r', encoding='utf-8') as f:
    #                     first_line = f.readline()
    #                     if '\t' in first_line:
    #                         df = pd.read_csv(file_path, sep='\t')
    #                     elif ',' in first_line:
    #                         df = pd.read_csv(file_path, sep=',')
    #                     elif ';' in first_line:
    #                         df = pd.read_csv(file_path, sep=';')
    #                     elif '|' in first_line:
    #                         df = pd.read_csv(file_path, sep='|')
    #                     else:
    #                         # Plain text file - create single column DataFrame
    #                         with open(file_path, 'r', encoding='utf-8') as f:
    #                             content = f.read()
    #                         lines = content.split('\n')
    #                         df = pd.DataFrame({'text_content': lines})
    #             except Exception as e:
    #                 # Try with different encoding
    #                 try:
    #                     with open(file_path, 'r', encoding='latin-1') as f:
    #                         content = f.read()
    #                     lines = content.split('\n')
    #                     df = pd.DataFrame({'text_content': lines})
    #                 except:
    #                     raise ValueError(f"Could not read text file: {str(e)}")
                        
    #         elif file_ext in ['.xlsx', '.xls']:
    #             df = pd.read_excel(file_path)
                
    #         elif file_ext == '.json':
    #             with open(file_path, 'r', encoding='utf-8') as f:
    #                 data = json.load(f)
    #             if isinstance(data, list):
    #                 df = pd.DataFrame(data)
    #             else:
    #                 df = pd.DataFrame([data])
                        
    #         elif file_ext == '.parquet':
    #             try:
    #                 df = pd.read_parquet(file_path)
    #             except ImportError:
    #                 raise ValueError("pyarrow library not installed. Install with: pip install pyarrow")
                
    #         else:
    #             raise ValueError(f"Unsupported file format: {file_ext}")
                
    #         self.logger.info(f"Successfully loaded {file_ext} file with shape: {df.shape}")
    #         return df
            
    #     except Exception as e:
    #         self.logger.error(f"Error loading file: {str(e)}")
    #         raise
    
    async def load_data(self, file: UploadFile, file_ext: str) -> pd.DataFrame:
        """Load data from various file formats using a FastAPI UploadFile object.
        
        Args:
            file: FastAPI UploadFile object
            file_ext: File extension (e.g., '.csv', '.xlsx')
            
        Returns:
            pd.DataFrame: Loaded data in DataFrame format
        """
        file_ext = file_ext.lower()
        
        if file_ext not in self.supported_formats:
            raise ValueError(f"Unsupported file format: {file_ext}. Supported formats: {self.supported_formats}")
        
        try:
            if file_ext == '.csv':
                # Try different encodings and separators
                encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
                separators = [',', ';', '\t', '|']
                
                for encoding in encodings:
                    for sep in separators:
                        try:
                            # Reset file pointer to start
                            await file.seek(0)
                            # Read file content as bytes and decode
                            content = (await file.read()).decode(encoding)
                            df = pd.read_csv(io.StringIO(content), sep=sep)
                            if len(df.columns) > 1:  # Valid CSV should have multiple columns
                                self.logger.info(f"Successfully loaded CSV with encoding: {encoding}, separator: {sep}")
                                return df
                        except:
                            continue
                
                # Fallback to basic CSV loading
                await file.seek(0)
                content = (await file.read()).decode('utf-8')
                df = pd.read_csv(io.StringIO(content))
                
            elif file_ext == '.txt':
                # Try to detect if it's a delimited file
                try:
                    await file.seek(0)
                    first_line = (await file.read()).decode('utf-8').split('\n')[0]
                    if '\t' in first_line:
                        await file.seek(0)
                        content = (await file.read()).decode('utf-8')
                        df = pd.read_csv(io.StringIO(content), sep='\t')
                    elif ',' in first_line:
                        await file.seek(0)
                        content = (await file.read()).decode('utf-8')
                        df = pd.read_csv(io.StringIO(content), sep=',')
                    elif ';' in first_line:
                        await file.seek(0)
                        content = (await file.read()).decode('utf-8')
                        df = pd.read_csv(io.StringIO(content), sep=';')
                    elif '|' in first_line:
                        await file.seek(0)
                        content = (await file.read()).decode('utf-8')
                        df = pd.read_csv(io.StringIO(content), sep='|')
                    else:
                        # Plain text file - create single column DataFrame
                        await file.seek(0)
                        content = (await file.read()).decode('utf-8')
                        lines = content.split('\n')
                        df = pd.DataFrame({'text_content': lines})
                except Exception as e:
                    # Try with different encoding
                    try:
                        await file.seek(0)
                        content = (await file.read()).decode('latin-1')
                        lines = content.split('\n')
                        df = pd.DataFrame({'text_content': lines})
                    except:
                        raise ValueError(f"Could not read text file: {str(e)}")
                        
            elif file_ext in ['.xlsx', '.xls']:
                await file.seek(0)
                content = await file.read()
                df = pd.read_excel(io.BytesIO(content))
                
            elif file_ext == '.json':
                await file.seek(0)
                content = (await file.read()).decode('utf-8')
                data = json.loads(content)
                if isinstance(data, list):
                    df = pd.DataFrame(data)
                else:
                    df = pd.DataFrame([data])
                        
            elif file_ext == '.parquet':
                try:
                    await file.seek(0)
                    content = await file.read()
                    df = pd.read_parquet(io.BytesIO(content))
                except ImportError:
                    raise ValueError("pyarrow library not installed. Install with: pip install pyarrow")
                
            else:
                raise ValueError(f"Unsupported file format: {file_ext}")
                
            self.logger.info(f"Successfully loaded {file_ext} file with shape: {df.shape}")
            return df
            
        except Exception as e:
            self.logger.error(f"Error loading file: {str(e)}")
            raise

    def basic_profiling(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Perform basic statistical profiling of the dataset"""
        profile = {
            'basic_info': {
                'num_rows': len(df),
                'num_columns': len(df.columns),
                'memory_usage': df.memory_usage(deep=True).sum(),
                'file_size_mb': df.memory_usage(deep=True).sum() / (1024 * 1024)
            },
            'column_info': {},
            'data_types': {str(col): str(dtype) for col, dtype in df.dtypes.items()},
            'missing_values': {str(col): int(count) for col, count in df.isnull().sum().items()},
            'missing_percentage': {str(col): float(pct) for col, pct in (df.isnull().sum() / len(df) * 100).items()}
        }
        
        # Detailed column analysis
        for col in df.columns:
            col_str = str(col)
            col_profile = {
                'dtype': str(df[col].dtype),
                'non_null_count': int(df[col].count()),
                'null_count': int(df[col].isnull().sum()),
                'unique_count': int(df[col].nunique()),
                'unique_percentage': float((df[col].nunique() / len(df) * 100)) if len(df) > 0 else 0
            }
            
            # Numeric columns
            if pd.api.types.is_numeric_dtype(df[col]):
                try:
                    col_profile.update({
                        'min': float(df[col].min()) if pd.notna(df[col].min()) else None,
                        'max': float(df[col].max()) if pd.notna(df[col].max()) else None,
                        'mean': float(df[col].mean()) if pd.notna(df[col].mean()) else None,
                        'median': float(df[col].median()) if pd.notna(df[col].median()) else None,
                        'std': float(df[col].std()) if pd.notna(df[col].std()) else None,
                        'skewness': float(df[col].skew()) if pd.notna(df[col].skew()) else None,
                        'kurtosis': float(df[col].kurtosis()) if pd.notna(df[col].kurtosis()) else None
                    })
                except:
                    col_profile.update({
                        'min': None, 'max': None, 'mean': None, 'median': None, 
                        'std': None, 'skewness': None, 'kurtosis': None
                    })
                    
            # String columns
            elif pd.api.types.is_string_dtype(df[col]) or pd.api.types.is_object_dtype(df[col]):
                try:
                    str_series = df[col].astype(str)
                    col_profile.update({
                        'avg_length': float(str_series.str.len().mean()),
                        'min_length': int(str_series.str.len().min()),
                        'max_length': int(str_series.str.len().max()),
                        'most_common': {str(k): int(v) for k, v in df[col].value_counts().head(5).items()}
                    })
                except:
                    col_profile.update({
                        'avg_length': None, 'min_length': None, 'max_length': None,
                        'most_common': {}
                    })
                    
            # DateTime columns
            elif pd.api.types.is_datetime64_any_dtype(df[col]):
                try:
                    col_profile.update({
                        'min_date': str(df[col].min()),
                        'max_date': str(df[col].max()),
                        'date_range_days': int((df[col].max() - df[col].min()).days) if df[col].notna().any() else 0
                    })
                except:
                    col_profile.update({
                        'min_date': None, 'max_date': None, 'date_range_days': None
                    })
                    
            profile['column_info'][col_str] = col_profile
            
        return profile
    
    def calculate_data_quality_score(self, df: pd.DataFrame, basic_profile: Dict[str, Any]) -> float:
        """Calculate overall data quality score"""
        try:
            # Completeness score (percentage of non-null values)
            total_cells = basic_profile['basic_info']['num_rows'] * basic_profile['basic_info']['num_columns']
            total_missing = sum(basic_profile['missing_values'].values())
            completeness = ((total_cells - total_missing) / total_cells * 100) if total_cells > 0 else 0
            
            # Consistency score (check for obvious data issues)
            consistency = 100.0
            for col in df.columns:
                if df[col].dtype == 'object':
                    # Check for mixed data types in text columns
                    unique_vals = df[col].dropna().unique()
                    if len(unique_vals) > 0:
                        text_ratio = sum(1 for val in unique_vals if isinstance(val, str)) / len(unique_vals)
                        consistency *= text_ratio
            
            # Volume score (penalize very small datasets)
            volume_score = min(100.0, df.shape[0] / 100 * 100)  # Assume 100 rows is minimum good volume
            
            # Overall quality score
            quality_score = (completeness * 0.5 + consistency * 0.3 + volume_score * 0.2)
            return round(quality_score, 2)
        except:
            return 50.0  # Default score if calculation fails
    
    async def llm_analysis(self, df: pd.DataFrame, basic_profile: Dict[str, Any], filename: str) -> str:
        """Use Groq LLM to perform advanced analysis and generate markdown report"""
        
        # Prepare data summary for LLM
        sample_data = []
        try:
            if len(df) > 0:
                sample_data = df.head(100).to_dict('records')
                # Convert any non-serializable types to strings
                for record in sample_data:
                    for key, value in record.items():
                        if pd.isna(value) or value is None:
                            record[key] = "null"
                        elif not isinstance(value, (str, int, float, bool)):
                            record[key] = str(value)
        except Exception as e:
            self.logger.warning(f"Could not prepare sample data: {str(e)}")
        
        data_summary = {
            'shape': df.shape,
            'columns': [str(col) for col in df.columns],
            'dtypes': {str(col): str(dtype) for col, dtype in df.dtypes.items()},
            'sample_data': sample_data[:10] if sample_data else []  # Limit to 10 rows for prompt
        }
        
        # Calculate additional metrics
        total_cells = basic_profile['basic_info']['num_rows'] * basic_profile['basic_info']['num_columns']
        total_missing = sum(basic_profile['missing_values'].values())
        completeness_score = ((total_cells - total_missing) / total_cells * 100) if total_cells > 0 else 0
        
        # Create comprehensive prompt for LLM
        system_prompt = """
        You are a senior data analyst and data scientist with expertise in data profiling, quality assessment, and business intelligence.
        Your task is to analyze the provided dataset and generate a comprehensive data profiling report.
        
        Focus on the following areas:
        1. Executive Summary with key findings
        2. Data Quality Assessment and Scoring
        3. Column-by-Column Analysis
        4. Data Patterns and Insights Discovery
        5. Potential Data Issues and Anomalies
        6. Business Intelligence Opportunities
        7. Data Preprocessing Recommendations
        
        Generate a detailed report in markdown format with clear sections, tables where appropriate, and actionable insights.
        Use professional language and provide specific, data-driven observations.
        """
        
        user_request = f"""
        Please analyze the following dataset and generate a comprehensive data profiling report:
        
        **File Information:**
        - Filename: {filename}
        - Shape: {data_summary['shape']} (rows x columns)
        - Columns: {data_summary['columns']}
        - Data Types: {data_summary['dtypes']}
        - File Size: {basic_profile['basic_info']['file_size_mb']:.2f} MB
        - Data Completeness: {completeness_score:.2f}%
        
        **Missing Values Analysis:**
        {json.dumps(basic_profile['missing_values'], indent=2)}
        
        **Sample Data (first 10 rows):**
        {json.dumps(data_summary['sample_data'], indent=2)}
        
        **Column Statistics Summary:**
        {json.dumps({col: info for col, info in list(basic_profile['column_info'].items())[:5]}, indent=2)}
        
        Generate a comprehensive data profiling report in markdown format.
        Provide specific insights about data quality, patterns, and business value.
        Include actionable recommendations for data improvement and usage.
        """
        
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_request}
                ],
                temperature=0.2,
                max_tokens=4000
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            self.logger.error(f"Error in LLM analysis: {str(e)}")
            return self._generate_fallback_report(df, basic_profile, filename, completeness_score)
    
    def _generate_fallback_report(self, df: pd.DataFrame, basic_profile: Dict[str, Any], filename: str, completeness_score: float) -> str:
        """Generate a fallback report if LLM analysis fails"""
        
        report = f"""
# Data Profiling Report

## Executive Summary

**File**: {filename}  
**Dataset Shape**: {df.shape[0]:,} rows × {df.shape[1]} columns  
**Data Completeness**: {completeness_score:.2f}%  
**File Size**: {basic_profile['basic_info']['file_size_mb']:.2f} MB

## Data Quality Assessment

### Overall Metrics
- **Total Data Points**: {basic_profile['basic_info']['num_rows'] * basic_profile['basic_info']['num_columns']:,}
- **Missing Values**: {sum(basic_profile['missing_values'].values()):,}
- **Data Types**: {len(set(basic_profile['data_types'].values()))} unique types

### Column Analysis

| Column | Data Type | Non-Null Count | Unique Values | Missing % |
|--------|-----------|----------------|---------------|-----------|
"""
        
        for col, info in basic_profile['column_info'].items():
            missing_pct = basic_profile['missing_percentage'].get(col, 0)
            report += f"| {col[:20]}{'...' if len(col) > 20 else ''} | {info['dtype']} | {info['non_null_count']:,} | {info['unique_count']:,} | {missing_pct:.1f}% |\n"
        
        report += """

## Data Quality Issues

"""
        
        # Identify issues
        issues = []
        for col, missing_pct in basic_profile['missing_percentage'].items():
            if missing_pct > 50:
                issues.append(f"- **{col}**: High missing data ({missing_pct:.1f}%)")
            elif missing_pct > 20:
                issues.append(f"- **{col}**: Moderate missing data ({missing_pct:.1f}%)")
        
        if issues:
            report += "\n".join(issues)
        else:
            report += "- No significant data quality issues detected"
        
        report += """

## Recommendations

1. **Data Cleaning**: Address missing values in high-missing columns
2. **Data Validation**: Verify data types and formats
3. **Quality Monitoring**: Implement ongoing data quality checks
4. **Documentation**: Create data dictionary and metadata

## Analysis Limitations

This report was generated using basic profiling due to AI analysis unavailability.
For more detailed insights, please ensure AI service connectivity.
"""
        
        return report
    
    async def analyze_file(self, file: UploadFile, filename: str) -> Dict[str, Any]:
        """Main method to analyze a file and generate comprehensive report"""
        try:
            self.logger.info(f"Starting analysis for file: {filename}")
            file_ext = '.' + filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
            # Load data
            df = await self.load_data(file,file_ext)
            self.logger.info(f"Loaded data with shape: {df.shape}")
            
            # Basic profiling
            self.logger.info("Performing basic profiling...")
            basic_profile = self.basic_profiling(df)
            
            # Calculate quality score
            quality_score = self.calculate_data_quality_score(df, basic_profile)
            
            # LLM analysis to generate markdown report
            self.logger.info("Performing AI-powered analysis...")
            markdown_content = await self.llm_analysis(df, basic_profile, filename)
            
            self.logger.info("Analysis completed successfully!")
            
            return {
                'analysis_type': 'comprehensive',
                'generated_content': markdown_content,
                'file_analyzed': filename,
                'data_quality_score': quality_score,
                'generated_at': datetime.utcnow()
            }
            
        except Exception as e:
            self.logger.error(f"Analysis failed: {str(e)}")
            raise
