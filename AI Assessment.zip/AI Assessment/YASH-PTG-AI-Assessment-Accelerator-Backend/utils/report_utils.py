from sqlalchemy.orm import Session
from typing import List, Union, Optional
import io
from services.report_service import UniversalReportManager, ReportListItem, Report

def save_module_report(
    db: Session,
    user_id: int,
    project_id: int,
    module_name: str,
    module_entity_id: int,
    report_name: str,
    file_content: Union[bytes, io.BytesIO],
    report_type: str = "pdf"
) -> Report:
    """
    Convenience function to save a report from any module
    
    Usage in modules:
    from utils.report_utils import save_module_report
    
    # In your endpoint:
    report = save_module_report(
        db=db,
        user_id=current_user.id,
        project_id=session.project_id,
        module_name="pre_workshop",
        module_entity_id=session_id,
        report_name=f"Pre-Workshop Report - {session.session_name}",
        file_content=pdf_content,
        report_type="pdf"
    )
    """
    manager = UniversalReportManager(db)
    return manager.save_report(
        user_id=user_id,
        project_id=project_id,
        module_name=module_name,
        module_entity_id=module_entity_id,
        report_name=report_name,
        file_content=file_content,
        report_type=report_type
    )

def get_module_reports(
    db: Session,
    user_id: int,
    module_name: str,
    module_entity_id: Optional[int] = None,
    project_id: Optional[int] = None
) -> List[ReportListItem]:
    """
    Convenience function to get reports for a module
    
    Usage:
    reports = get_module_reports(
        db=db,
        user_id=current_user.id,
        module_name="pre_workshop",
        module_entity_id=session_id
    )
    """
    manager = UniversalReportManager(db)
    reports = manager.get_reports_by_module(
        user_id=user_id,
        module_name=module_name,
        module_entity_id=module_entity_id,
        project_id=project_id
    )
    
    return [
        ReportListItem(
            id=report.id,
            report_uuid=report.report_uuid,
            module_name=report.module_name,
            module_entity_id=report.module_entity_id,
            report_name=report.report_name,
            report_type=report.report_type,
            file_size=report.file_size,
            created_at=report.created_at
        )
        for report in reports
    ]