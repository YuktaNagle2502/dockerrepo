import os
import re
import json
import tempfile
import zipfile
import io
import pandas as pd
import PyPDF2
from docx import Document
from typing import Optional, List, Dict, Any, Union
from pydantic import BaseModel
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib import colors
from datetime import datetime


class DataFileInfo(BaseModel):
    filename: str
    file_type: str
    size_bytes: int
    records_count: Optional[int] = None
    columns_count: Optional[int] = None
    has_pii: bool = False
    has_sensitive_data: bool = False
    content: Optional[str] = None
    
class FileProcessor:
    SUPPORTED_EXTENSIONS = {
        '.csv': 'text/csv',
        '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        '.xls': 'application/vnd.ms-excel',
        '.txt': 'text/plain',
        '.json': 'application/json',
        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        '.pdf': 'application/pdf',
        '.zip': 'application/zip'
    }

    PII_PATTERNS = {
        'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        'phone': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        'ssn': r'\b\d{3}-\d{2}-\d{4}\b',
        'credit_card': r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',
        'ip_address': r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
        'passport': r'\b[A-Z]{1,2}\d{6,9}\b'
    }

    SENSITIVE_KEYWORDS = [
        'password', 'secret', 'token', 'api_key', 'private_key', 'confidential',
        'salary', 'income', 'medical', 'health', 'diagnosis', 'treatment',
        'financial', 'banking', 'account', 'transaction', 'payment'
    ]

    # def __init__(self, api_key: str = None):
    #     self.temp_dir = None
    #     self.api_key = api_key

    async def save_uploaded_file(self, upload_file, temp_dir: str = None) -> str:
        if temp_dir is None:
            temp_dir = tempfile.mkdtemp()
        file_path = os.path.join(temp_dir, upload_file.filename)
        content = await upload_file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        return file_path

    async def process_file(self, file_path: str, filename: str)-> DataFileInfo:
        file_size = os.path.getsize(file_path)
        file_ext = os.path.splitext(filename)[1].lower()
        if file_ext not in self.SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported file type: {file_ext}")
        file_info = DataFileInfo(
                filename=filename,
                file_type=self.SUPPORTED_EXTENSIONS[file_ext],
                size_bytes=file_size
            )
        file_info.filename = filename
        file_info.file_type = self.SUPPORTED_EXTENSIONS[file_ext]
        file_info.size_bytes = file_size
        file_info.records_count = None
        file_info.columns_count = None
        file_info.has_pii = False
        file_info.has_sensitive_data = False
        

        if file_ext == '.csv':
            await self._process_csv(file_path, file_info)
        elif file_ext in ['.xlsx', '.xls']:
            await self._process_excel(file_path, file_info)
        elif file_ext == '.txt':
            await self._process_text(file_path, file_info)
        elif file_ext == '.json':
            await self._process_json(file_path, file_info)
        elif file_ext == '.docx':
            await self._process_docx(file_path, file_info)
        elif file_ext == '.pdf':
            await self._process_pdf(file_path, file_info)
        elif file_ext == '.zip':
            await self._process_zip(file_path, file_info)

        return file_info

    def _detect_pii(self, content: str) -> bool:
        content_lower = content.lower()
        for pattern in self.PII_PATTERNS.values():
            if re.search(pattern, content, re.IGNORECASE):
                return True
        pii_keywords = ['email', 'phone', 'address', 'ssn', 'social security', 'passport', 'license']
        for keyword in pii_keywords:
            if keyword in content_lower:
                return True
        return False

    def _detect_sensitive_data(self, content: str) -> bool:
        content_lower = content.lower()
        for keyword in self.SENSITIVE_KEYWORDS:
            if keyword in content_lower:
                return True
        return False

    async def _process_csv(self, file_path: str, file_info: DataFileInfo):
        try:
            df = pd.read_csv(file_path, nrows=20)
            file_info.records_count = len(df)
            file_info.columns_count = len(df.columns)
            content = df.to_string()
            file_info.content=content
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
        except Exception:
            encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252']
            for encoding in encodings:
                try:
                    df = pd.read_csv(file_path, encoding=encoding, nrows=1000)
                    file_info.records_count = len(df)
                    file_info.columns_count = len(df.columns)
                    content = df.to_string()
                    file_info.has_pii = self._detect_pii(content)
                    file_info.has_sensitive_data = self._detect_sensitive_data(content)
                    break
                except:
                    continue

    async def _process_excel(self, file_path: str, file_info:DataFileInfo):
        import openpyxl
        from openpyxl import load_workbook
        try:
            df = pd.read_excel(file_path, nrows=20)
            file_info.records_count = len(df)
            file_info.columns_count = len(df.columns)
            content = df.to_string()
            file_info.content = content
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
        except Exception:
            try:
                workbook = load_workbook(file_path, read_only=True)
                sheet = workbook.active
                rows = list(sheet.iter_rows(max_row=1000, values_only=True))
                file_info.records_count = len(rows)
                file_info.columns_count = len(rows[0]) if rows else 0
                content = str(rows)
                file_info.has_pii = self._detect_pii(content)
                file_info.has_sensitive_data = self._detect_sensitive_data(content)
            except Exception as e:
                raise ValueError(f"Error processing Excel file: {str(e)}")

    async def _process_text(self, file_path: str, file_info:DataFileInfo):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            file_info.content = content
            file_info.records_count = len(content.splitlines())
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
        except UnicodeDecodeError:
            encodings = ['latin-1', 'iso-8859-1', 'cp1252']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    file_info.records_count = len(content.splitlines())
                    file_info.has_pii = self._detect_pii(content)
                    file_info.has_sensitive_data = self._detect_sensitive_data(content)
                    break
                except:
                    continue

    async def _process_json(self, file_path: str, file_info:DataFileInfo):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, list):
                file_info.records_count = len(data)
                file_info.columns_count = len(data[0].keys()) if data and isinstance(data[0], dict) else 0
            elif isinstance(data, dict):
                file_info.records_count = 1
                file_info.columns_count = len(data.keys())
            content = json.dumps(data, default=str)
            file_info.content = content
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
        except Exception as e:
            raise ValueError(f"Error processing JSON file: {str(e)}")

    async def _process_docx(self, file_path: str, file_info:DataFileInfo):
        try:
            doc = Document(file_path)
            content = "\n".join([paragraph.text for paragraph in doc.paragraphs])
            file_info.content = content
            file_info.records_count = len(doc.paragraphs)
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
        except Exception as e:
            raise ValueError(f"Error processing Word document: {str(e)}")

    async def _process_pdf(self, file_path: str, file_info:DataFileInfo):
        try:
            with open(file_path, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                content = ""
                for page in pdf_reader.pages:
                    content += page.extract_text()
            file_info.content = content
            file_info.records_count = len(pdf_reader.pages)
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
        except Exception as e:
            raise ValueError(f"Error processing PDF file: {str(e)}")

    async def _process_zip(self, file_path: str, file_info:DataFileInfo):
        try:
            with zipfile.ZipFile(file_path, 'r') as zip_ref:
                file_list = zip_ref.namelist()
                file_info.records_count = len(file_list)
                content = ""
                for file_name in file_list[:10]:
                    if zip_ref.getinfo(file_name).file_size < 1024 * 1024:
                        try:
                            with zip_ref.open(file_name) as f:
                                content += f.read().decode('utf-8', errors='ignore')
                        except:
                            continue
                file_info.has_pii = self._detect_pii(content)
                file_info.content = content
                file_info.has_sensitive_data = self._detect_sensitive_data(content)
        except Exception as e:
            raise ValueError(f"Error processing ZIP file: {str(e)}")

class SimpleCompliancePDFGenerator:
    """Generate clean, simple PDF reports from markdown content"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_simple_styles()
    
    def _setup_simple_styles(self):
        """Setup simple, clean paragraph styles"""
        # Title style - simple and clean
        self.title_style = ParagraphStyle(
            'SimpleTitle',
            parent=self.styles['Title'],
            fontSize=20,
            spaceAfter=24,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        
        # Subtitle style
        self.subtitle_style = ParagraphStyle(
            'SimpleSubtitle',
            parent=self.styles['Normal'],
            fontSize=12,
            spaceAfter=20,
            alignment=TA_CENTER,
            fontName='Helvetica'
        )
        
        # Heading styles - no colors or borders
        self.h1_style = ParagraphStyle(
            'SimpleH1',
            parent=self.styles['Heading1'],
            fontSize=16,
            spaceAfter=12,
            spaceBefore=20,
            fontName='Helvetica-Bold'
        )
        
        self.h2_style = ParagraphStyle(
            'SimpleH2',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=10,
            spaceBefore=16,
            fontName='Helvetica-Bold'
        )
        
        self.h3_style = ParagraphStyle(
            'SimpleH3',
            parent=self.styles['Heading3'],
            fontSize=12,
            spaceAfter=8,
            spaceBefore=12,
            fontName='Helvetica-Bold'
        )
        
        self.h4_style = ParagraphStyle(
            'SimpleH4',
            parent=self.styles['Heading4'],
            fontSize=11,
            spaceAfter=6,
            spaceBefore=10,
            fontName='Helvetica-Bold'
        )
        
        # Body text - clean and simple
        self.body_style = ParagraphStyle(
            'SimpleBody',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=6,
            alignment=TA_JUSTIFY,
            fontName='Helvetica'
        )
        
        # List styles - simple bullets
        self.bullet_style = ParagraphStyle(
            'SimpleBullet',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=4,
            leftIndent=20,
            bulletIndent=10,
            fontName='Helvetica'
        )
        
        self.numbered_style = ParagraphStyle(
            'SimpleNumbered',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=4,
            leftIndent=20,
            bulletIndent=10,
            fontName='Helvetica'
        )
        
        # Code style - minimal formatting
        self.code_style = ParagraphStyle(
            'SimpleCode',
            parent=self.styles['Code'],
            fontSize=9,
            spaceAfter=8,
            spaceBefore=4,
            fontName='Courier',
            leftIndent=20
        )
        
        # Quote style - simple indentation
        self.quote_style = ParagraphStyle(
            'SimpleQuote',
            parent=self.styles['Normal'],
            fontSize=10,
            leftIndent=30,
            rightIndent=30,
            spaceAfter=6,
            spaceBefore=4,
            fontName='Helvetica-Oblique'
        )

    def generate_pdf(self, markdown_content: str, title: str = "Compliance Report") -> bytes:
        """Generate simple PDF from markdown content"""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=72
        )
        
        # Parse markdown and build content
        content = self._parse_markdown_to_reportlab(markdown_content, title)
        
        # Build PDF
        doc.build(content)
        buffer.seek(0)
        return buffer.read()

    def _clean_text(self, text: str) -> str:
        """Clean and escape text for ReportLab"""
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        
        # Simple markdown formatting
        text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
        text = re.sub(r'\*(.*?)\*', r'<i>\1</i>', text)
        text = re.sub(r'`(.*?)`', r'<font name="Courier">\1</font>', text)
        
        return text

    def _parse_markdown_to_reportlab(self, markdown_content: str, title: str) -> List:
        """Parse markdown content to simple ReportLab elements"""
        content = []
        
        # Simple title page
        content.append(Paragraph(title, self.title_style))
        content.append(Spacer(1, 12))
        
        # Generation timestamp
        timestamp = datetime.now().strftime("%B %d, %Y")
        content.append(Paragraph(f"Generated: {timestamp}", self.subtitle_style))
        content.append(Spacer(1, 24))
        
        # Clean the markdown content
        cleaned_content = self._clean_text(markdown_content)
        
        # Split content into lines
        lines = cleaned_content.split('\n')
        
        in_code_block = False
        code_block_content = []
        in_list = False
        list_counter = 0
        
        for line in lines:
            line = line.strip()
            
            if not line:
                if not in_code_block:
                    content.append(Spacer(1, 6))
                    in_list = False
                    list_counter = 0
                continue
            
            # Handle code blocks
            if line.startswith('```'):
                if in_code_block:
                    if code_block_content:
                        code_text = '\n'.join(code_block_content)
                        content.append(Paragraph(code_text, self.code_style))
                        content.append(Spacer(1, 8))
                    code_block_content = []
                    in_code_block = False
                else:
                    in_code_block = True
                continue
            
            if in_code_block:
                code_block_content.append(line)
                continue
            
            # Handle headings - simple, no fancy styling
            if line.startswith('# '):
                text = line[2:].strip()
                content.append(Paragraph(text, self.h1_style))
                in_list = False
                list_counter = 0
                
            elif line.startswith('## '):
                text = line[3:].strip()
                content.append(Paragraph(text, self.h2_style))
                in_list = False
                list_counter = 0
                
            elif line.startswith('### '):
                text = line[4:].strip()
                content.append(Paragraph(text, self.h3_style))
                in_list = False
                list_counter = 0
                
            elif line.startswith('#### '):
                text = line[5:].strip()
                content.append(Paragraph(text, self.h4_style))
                in_list = False
                list_counter = 0
            
            # Handle lists - simple formatting
            elif line.startswith('- ') or line.startswith('* '):
                text = line[2:].strip()
                content.append(Paragraph(f"• {text}", self.bullet_style))
                in_list = True
                
            elif re.match(r'^\d+\.', line):
                if not in_list:
                    list_counter = 0
                    in_list = True
                list_counter += 1
                text = re.sub(r'^\d+\.\s*', '', line)
                content.append(Paragraph(f"{list_counter}. {text}", self.numbered_style))
            
            # Handle quotes - simple indentation
            elif line.startswith('>'):
                text = line[1:].strip()
                content.append(Paragraph(text, self.quote_style))
                in_list = False
            
            # Handle tables (basic support)
            elif '|' in line and not line.startswith('|--'):
                # Simple table row handling - you might want to enhance this
                cells = [cell.strip() for cell in line.split('|')[1:-1]]
                table_text = ' | '.join(cells)
                content.append(Paragraph(table_text, self.body_style))
                in_list = False
            
            # Handle regular paragraphs
            else:
                if line.strip():
                    content.append(Paragraph(line, self.body_style))
                    in_list = False
        
        # Handle any remaining code block
        if in_code_block and code_block_content:
            code_text = '\n'.join(code_block_content)
            content.append(Paragraph(code_text, self.code_style))
        
        return content
