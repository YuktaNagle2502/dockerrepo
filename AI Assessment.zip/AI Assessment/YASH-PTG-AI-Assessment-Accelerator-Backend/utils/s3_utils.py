import boto3
from botocore.exceptions import ClientError
from fastapi import HTTPException, status
import uuid
import re
import os
import logging
from datetime import datetime, timedelta
from typing import Tuple, List, Dict, Optional

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# AWS configuration
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
BUCKET_NAME = os.getenv("BUCKET_NAME")

def generate_presigned_get_urls(
    bucket_name: str,
    object_paths: List[str],
    access_key: str = AWS_ACCESS_KEY_ID,
    secret_key: str = AWS_SECRET_ACCESS_KEY,
    region: str = AWS_REGION,
    expiration: int = int(os.getenv("PRESIGNED_URL_EXPIRATION", 604800))
) -> List[Dict]:
    """
    Generate presigned URLs for downloading multiple objects from S3.
    
    Args:
        bucket_name: Name of the S3 bucket
        object_paths: List of object keys/paths in S3
        access_key: AWS access key ID
        secret_key: AWS secret access key
        region: AWS region (default: us-east-1)
        expiration: URL expiration time in seconds (default: from env or 7 days)
    
    Returns:
        List of dictionaries containing object path, presigned URL, expiration timestamp, or error
    """
    s3_client = boto3.client(
        's3',
        region_name=region,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key
    )
    results = []
    
    for path in object_paths:
        try:
            url = s3_client.generate_presigned_url(
                'get_object',
                Params={'Bucket': bucket_name, 'Key': path},
                ExpiresIn=expiration
            )
            expires_at = datetime.utcnow() + timedelta(seconds=expiration)
            results.append({
                'path': path,
                'url': url,
                'status': 'success',
                'expires_at': expires_at
            })
        except ClientError as e:
            logger.error(f"Failed to generate presigned URL for {path}: {str(e)}")
            results.append({'path': path, 'error': str(e), 'status': 'error'})
    
    return results

def upload_file(
    bucket_name: str,
    file_content: bytes,
    session_id: int,
    session_name: str,
    filename: str,
    access_key: str = AWS_ACCESS_KEY_ID,
    secret_key: str = AWS_SECRET_ACCESS_KEY,
    region: str = AWS_REGION,
    expiration: int = int(os.getenv("PRESIGNED_URL_EXPIRATION", 604800)),
    folder_prefix: Optional[str] = None,
    project_name: Optional[str] = None  # New parameter
) -> Tuple[str, str, datetime]:
    """
    Upload file to S3 and return the S3 key, presigned URL, and expiration timestamp
    
    Args:
        bucket_name: Name of the S3 bucket
        file_content: Content of the file to upload
        session_id: Session ID for path organization
        session_name: Session name for path organization
        filename: Original filename
        access_key: AWS access key ID
        secret_key: AWS secret access key
        region: AWS region (default: us-east-1)
        expiration: URL expiration time in seconds (default: from env or 7 days)
        folder_prefix: S3 folder prefix (e.g., 'data_readiness' or 'questionnaires')
        project_name: Project name to include after folder_prefix (optional)
    
    Returns:
        Tuple of (S3 key, presigned URL, expiration timestamp)
    """
    if not folder_prefix:
        raise ValueError("folder_prefix must be specified")
    
    s3_client = boto3.client(
        's3',
        region_name=region,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key
    )
    
    try:
        sanitized_session_name = re.sub(r'[^a-zA-Z0-9\-]', '_', session_name.strip()).strip('_')[:128] or "default_session"
        sanitized_project_name = re.sub(r'[^a-zA-Z0-9\-]', '_', project_name.strip()).strip('_')[:128] or "default_project" if project_name else None
        file_extension = os.path.splitext(filename)[1]
        unique_filename = f"session_{session_id}_{uuid.uuid4()}{file_extension}"
        # Construct S3 key with project_name after folder_prefix
        if sanitized_project_name:
            s3_key = f"{folder_prefix}/{sanitized_project_name}/{sanitized_session_name}/{session_id}/{unique_filename}"
        else:
            s3_key = f"{folder_prefix}/{sanitized_session_name}/{session_id}/{unique_filename}"
        
        s3_client.put_object(
            Bucket=bucket_name,
            Key=s3_key,
            Body=file_content
        )

        presigned_url = s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': bucket_name, 'Key': s3_key},
            ExpiresIn=expiration
        )
        expires_at = datetime.utcnow() + timedelta(seconds=expiration)
        
        return s3_key, presigned_url, expires_at
        
    except ClientError as e:
        logger.error(f"Failed to upload file to S3: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to upload file to S3: {str(e)}"
        )

def generate_presigned_put_urls(
    bucket_name: str,
    object_paths: List[str],
    access_key: str = AWS_ACCESS_KEY_ID,
    secret_key: str = AWS_SECRET_ACCESS_KEY,
    region: str = AWS_REGION,
    expiration: int = 604800
) -> List[Dict]:
    """
    Generate presigned URLs for uploading multiple objects to S3.
    
    Args:
        bucket_name: Name of the S3 bucket
        object_paths: List of object keys/paths in S3
        access_key: AWS access key ID
        secret_key: AWS secret access key
        region: AWS region (default: us-east-1)
        expiration: URL expiration time in seconds (default: 1 hour)
    
    Returns:
        List of dictionaries containing object path and presigned URL or error
    """
    s3_client = boto3.client(
        's3',
        region_name=region,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key
    )
    results = []
    
    for path in object_paths:
        try:
            url = s3_client.generate_presigned_url(
                'put_object',
                Params={'Bucket': bucket_name, 'Key': path},
                ExpiresIn=expiration
            )
            results.append({'path': path, 'url': url, 'status': 'success'})
        except ClientError as e:
            logger.error(f"Failed to generate presigned put URL for {path}: {str(e)}")
            results.append({'path': path, 'error': str(e), 'status': 'error'})
    
    return results

def generate_presigned_delete_urls(
    bucket_name: str,
    object_paths: List[str],
    access_key: str = AWS_ACCESS_KEY_ID,
    secret_key: str = AWS_SECRET_ACCESS_KEY,
    region: str = AWS_REGION,
    expiration: int = 604800
) -> List[Dict]:
    """
    Generate presigned URLs for deleting multiple objects from S3.
    
    Args:
        bucket_name: Name of the S3 bucket
        object_paths: List of object keys/paths in S3
        access_key: AWS access key ID
        secret_key: AWS secret access key
        region: AWS region (default: us-east-1)
        expiration: URL expiration time in seconds (default: 1 hour)
    
    Returns:
        List of dictionaries containing object path and presigned URL or error
    """
    s3_client = boto3.client(
        's3',
        region_name=region,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key
    )
    results = []
    
    for path in object_paths:
        try:
            url = s3_client.generate_presigned_url(
                'delete_object',
                Params={'Bucket': bucket_name, 'Key': path},
                ExpiresIn=expiration
            )
            results.append({'path': path, 'url': url, 'status': 'success'})
        except ClientError as e:
            logger.error(f"Failed to generate presigned delete URL for {path}: {str(e)}")
            results.append({'path': path, 'error': str(e), 'status': 'error'})
    
    return results

def delete_file(
    bucket_name: str,
    s3_key: str,
    access_key: str = AWS_ACCESS_KEY_ID,
    secret_key: str = AWS_SECRET_ACCESS_KEY,
    region: str = AWS_REGION
) -> None:
    """
    Delete file from S3
    
    Args:
        bucket_name: Name of the S3 bucket
        s3_key: S3 object key to delete
        access_key: AWS access key ID
        secret_key: AWS secret access key
        region: AWS region (default: us-east-1)
    """
    s3_client = boto3.client(
        's3',
        region_name=region,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key
    )
    
    try:
        s3_client.delete_object(
            Bucket=bucket_name,
            Key=s3_key
        )
    except ClientError as e:
        logger.error(f"Failed to delete S3 file {s3_key}: {str(e)}")

def download_file(
    bucket_name: str,
    s3_key: str,
    local_path: str,
    access_key: str = AWS_ACCESS_KEY_ID,
    secret_key: str = AWS_SECRET_ACCESS_KEY,
    region: str = AWS_REGION
) -> None:
    """
    Download file from S3 to local path
    
    Args:
        bucket_name: Name of the S3 bucket
        s3_key: S3 object key to download
        local_path: Local path to save the file
        access_key: AWS access key ID
        secret_key: AWS secret access key
        region: AWS region (default: us-east-1)
    """
    s3_client = boto3.client(
        's3',
        region_name=region,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key
    )
    
    try:
        s3_client.download_file(
            Bucket=bucket_name,
            Key=s3_key,
            Filename=local_path
        )
    except ClientError as e:
        logger.error(f"Failed to download file from S3: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to download file from S3: {str(e)}"
        )