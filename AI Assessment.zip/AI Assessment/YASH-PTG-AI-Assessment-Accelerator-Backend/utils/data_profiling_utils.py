import os
import tempfile
from fastapi import UploadFile, HTTPException, status
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.colors import HexColor, black, white, red, green, orange
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from reportlab.lib import colors
from datetime import datetime
import io
import re

async def save_uploaded_file(upload_file: UploadFile, temp_dir: str = None) -> str:
    if temp_dir is None:
        temp_dir = tempfile.mkdtemp()
    file_path = os.path.join(temp_dir, upload_file.filename)
    try:
        content = await upload_file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        return file_path
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving file: {str(e)}"
        )

class DataProfilingPDFGenerator:
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()

    def _setup_custom_styles(self):
        self.title_style = ParagraphStyle(
            'DataProfilingTitle', parent=self.styles['Title'], fontSize=24, spaceAfter=30,
            alignment=1, textColor=HexColor('#1a365d'), fontName='Helvetica-Bold'
        )
        self.subtitle_style = ParagraphStyle(
            'DataProfilingSubtitle', parent=self.styles['Normal'], fontSize=16, spaceAfter=20,
            alignment=1, textColor=HexColor('#2d3748'), fontName='Helvetica-Oblique'
        )
        self.h1_style = ParagraphStyle(
            'DataProfilingH1', parent=self.styles['Heading1'], fontSize=18, spaceAfter=15, spaceBefore=25,
            textColor=HexColor('#2b6cb0'), fontName='Helvetica-Bold', backColor=HexColor('#ebf8ff'),
            borderWidth=1, borderColor=HexColor('#3182ce'), borderPadding=8, leftIndent=10
        )
        self.h2_style = ParagraphStyle(
            'DataProfilingH2', parent=self.styles['Heading2'], fontSize=16, spaceAfter=12, spaceBefore=18,
            textColor=HexColor('#2c5282'), fontName='Helvetica-Bold', leftIndent=5
        )
        self.h3_style = ParagraphStyle(
            'DataProfilingH3', parent=self.styles['Heading3'], fontSize=14, spaceAfter=10, spaceBefore=15,
            textColor=HexColor('#3182ce'), fontName='Helvetica-Bold', leftIndent=10
        )
        self.body_style = ParagraphStyle(
            'DataProfilingBody', parent=self.styles['Normal'], fontSize=11, spaceAfter=8,
            textColor=HexColor('#2d3748'), alignment=4, leftIndent=20, rightIndent=20
        )
        self.bullet_style = ParagraphStyle(
            'DataProfilingBullet', parent=self.styles['Normal'], fontSize=11, spaceAfter=6,
            textColor=HexColor('#4a5568'), leftIndent=30, bulletIndent=20
        )

    def generate_pdf(self, markdown_content: str, title: str = "Data Profiling Report") -> bytes:
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer, pagesize=A4, rightMargin=50, leftMargin=50, topMargin=60, bottomMargin=60
        )
        content = self._parse_markdown_to_reportlab(markdown_content, title)
        doc.build(content)
        buffer.seek(0)
        return buffer.read()

    def _clean_text(self, text: str) -> str:
        text = text.replace('\\n', '\n').replace('\\\\', '\\')
        text = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
        text = re.sub(r'\*(.*?)\*', r'<i>\1</i>', text)
        text = re.sub(r'`(.*?)`', r'<font name="Courier">\1</font>', text)
        return text

    def _parse_markdown_to_reportlab(self, markdown_content: str, title: str):
        content = []
        content.append(Paragraph(title, self.title_style))
        content.append(Spacer(1, 20))
        timestamp = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        content.append(Paragraph(f"Generated on {timestamp}", self.subtitle_style))
        content.append(Spacer(1, 30))
        cleaned_content = self._clean_text(markdown_content)
        lines = cleaned_content.split('\n')
        in_table = False
        table_rows = []
        for line in lines:
            line = line.strip()
            if not line:
                if in_table:
                    if len(table_rows) > 1:
                        content.append(self._create_table(table_rows))
                    table_rows = []
                    in_table = False
                content.append(Spacer(1, 8))
                continue
            if '|' in line and line.count('|') >= 2:
                if not in_table:
                    in_table = True
                    table_rows = []
                cells = [cell.strip() for cell in line.split('|')[1:-1]]
                if cells and not all(cell in ['-', '--', '---', '----'] or cell.startswith('-') for cell in cells):
                    table_rows.append(cells)
                continue
            else:
                if in_table:
                    if len(table_rows) > 1:
                        content.append(self._create_table(table_rows))
                    table_rows = []
                    in_table = False
            if line.startswith('# '):
                text = line[2:].strip()
                content.append(Paragraph(text, self.h1_style))
            elif line.startswith('## '):
                text = line[3:].strip()
                content.append(Paragraph(text, self.h2_style))
            elif line.startswith('### '):
                text = line[4:].strip()
                content.append(Paragraph(text, self.h3_style))
            elif line.startswith('- ') or line.startswith('* '):
                text = line[2:].strip()
                content.append(Paragraph(f"• {text}", self.bullet_style))
            elif re.match(r'^\d+\.', line):
                text = re.sub(r'^\d+\.\s*', '', line)
                content.append(Paragraph(f"• {text}", self.bullet_style))
            else:
                if line.strip():
                    content.append(Paragraph(line, self.body_style))
        if in_table and len(table_rows) > 1:
            content.append(self._create_table(table_rows))
        return content

    def _create_table(self, rows):
        if not rows:
            return Spacer(1, 0)
        max_cols = max(len(row) for row in rows)
        col_width = 6.5 * inch / max_cols if max_cols > 0 else 1 * inch
        col_widths = [col_width] * max_cols
        table_data = []
        for i, row in enumerate(rows):
            while len(row) < max_cols:
                row.append('')
            cell_paragraphs = []
            for cell in row:
                if i == 0:
                    p = Paragraph(f"<b>{cell}</b>", self.styles['Normal'])
                else:
                    p = Paragraph(cell, self.styles['Normal'])
                cell_paragraphs.append(p)
            table_data.append(cell_paragraphs)
        table = Table(table_data, colWidths=col_widths)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), HexColor('#3182ce')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BACKGROUND', (0, 1), (-1, -1), HexColor('#f7fafc')),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#f7fafc'), colors.white])
        ]))
        return table
