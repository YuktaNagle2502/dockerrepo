from fastapi import HTTPException, UploadFile,status
from pathlib import Path
import pandas as pd
import tempfile
import os
import json
import uuid
from openpyxl import load_workbook
import logging
from typing import Dict, Any, List,Union,Optional
from dataclasses import dataclass

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class DataFile:
    """Represents an uploaded data file"""
    filename: str
    file_type: str
    size_mb: float
    columns: Optional[List[str]] = None
    row_count: Optional[int] = None
    sample_data: Optional[Dict] = None
    data_quality_score: float = 0.0
    matches_requirements: List[str] = None

class FileProcessor:
    SUPPORTED_EXTENSIONS = {
        '.csv': 'csv',
        '.xlsx': 'excel',
        '.xls': 'excel',
        '.json': 'json',
        '.parquet': 'parquet',
        '.txt': 'text'
    }

    # async def save_uploaded_file(self, upload_file: UploadFile, temp_dir: str = None) -> str:
    #     """
    #     Save an uploaded file to a temporary directory.
        
    #     Args:
    #         upload_file: FastAPI UploadFile object
    #         temp_dir: Optional directory to save the file; if None, a temp directory is created
            
    #     Returns:
    #         str: Path to the saved file
            
    #     Raises:
    #         HTTPException: If file saving fails
    #     """
    #     if temp_dir is None:
    #         temp_dir = tempfile.mkdtemp()
    #     file_path = os.path.join(temp_dir, upload_file.filename)
    #     try:
    #         content = await upload_file.read()
    #         with open(file_path, "wb") as f:
    #             f.write(content)
    #         return file_path
    #     except Exception as e:
    #         logger.error(f"Error saving file: {str(e)}")
    #         raise HTTPException(status_code=500, detail=f"Error saving file: {str(e)}")

    async def save_uploaded_file(self,upload_file: UploadFile, destination: Union[str, int] = None) -> str:
        """
        Save uploaded file to specified location
        
        Args:
            upload_file: The uploaded file object
            destination: Either a temp directory path (str) or session_id (int)
                        If None, creates a temporary directory
        
        Returns:
            str: Path to the saved file
        """
        
        # Determine file path based on destination type
        if destination is None:
            # Create temporary directory
            temp_dir = tempfile.mkdtemp()
            file_path = os.path.join(temp_dir, upload_file.filename)
            
        elif isinstance(destination, str):
            # Use provided temp directory
            file_path = os.path.join(destination, upload_file.filename)
            
        elif isinstance(destination, int):
            # Use session_id to create unique file in uploads directory
            uploads_dir = Path("uploads/pre_workshop")
            uploads_dir.mkdir(parents=True, exist_ok=True)
            
            file_extension = Path(upload_file.filename).suffix
            unique_filename = f"session_{destination}_{uuid.uuid4()}{file_extension}"
            file_path = uploads_dir / unique_filename
            
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Destination must be a string (temp_dir) or int (session_id)"
            )
        
        try:
            # Save file
            content = await upload_file.read()
            with open(file_path, "wb") as f:
                f.write(content)
            
            return str(file_path)
        
        except Exception as e:
            # Clean up if there was an error and file exists
            if isinstance(file_path, Path) and file_path.exists():
                file_path.unlink()
            elif isinstance(file_path, str) and os.path.exists(file_path):
                os.unlink(file_path)
                
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error saving file: {str(e)}"
            )

    async def process_file(self, file_path: str, filename: str) -> Dict[str, Any]:
        """
        Process a file and extract its contents based on file type.
        
        Args:
            file_path: Path to the file
            filename: Name of the file
            
        Returns:
            Dict[str, Any]: Processed file data with columns, row count, and column analysis
            
        Raises:
            HTTPException: If file type is unsupported or processing fails
        """
        try:
            file_path = Path(file_path)
            file_size_mb = file_path.stat().st_size / (1024 * 1024)
            file_type = file_path.suffix.lower()
            
            if file_type not in self.SUPPORTED_EXTENSIONS:
                raise ValueError(f"Unsupported file type: {file_type}")
            
            data_file = DataFile(
                filename=filename,
                file_type=file_type,
                size_mb=round(file_size_mb, 2),
                matches_requirements=[]
            )
            
            # Process based on file type
            if file_type == '.csv':
                await self._process_csv(file_path, data_file)
            elif file_type in ['.xlsx', '.xls']:
                await self._process_excel(file_path, data_file)
            elif file_type == '.txt':
                await self._process_text(file_path, data_file)
            elif file_type == '.json':
                await self._process_json(file_path, data_file)
            elif file_type == '.parquet':
                await self._process_parquet(file_path, data_file)
            
            return data_file
            
        except Exception as e:
            raise ValueError(f"Error processing file: {str(e)}")
        
    async def process_test_file(self, file_path: str, filename: str) -> List[Dict[str, str]]:
        """
        Process a test file specifically for model evaluation, extracting prompts and ground truths.
        
        Args:
            file_path: Path to the file
            filename: Name of the file
            
        Returns:
            List[Dict[str, str]]: List of test cases with prompt and ground_truth
            
        Raises:
            HTTPException: If file type is unsupported or required columns are missing
        """
        file_ext = Path(filename).suffix.lower()
        if file_ext not in ['.csv', '.xlsx', '.xls']:
            raise HTTPException(status_code=400, detail=f"Unsupported test file type: {file_ext}")
        
        try:
            if file_ext == '.csv':
                df = pd.read_csv(file_path)
            elif file_ext in ['.xlsx', '.xls']:
                df = pd.read_excel(file_path)
            
            df.columns = df.columns.str.strip().str.lower()
            prompt_col = next((col for col in df.columns if 'prompt' in col), None)
            ground_truth_col = next((col for col in df.columns if 'ground' in col and 'truth' in col or col in ['truth', 'answer', 'expected', 'target']), None)
            
            if not prompt_col or not ground_truth_col:
                raise HTTPException(status_code=400, detail="Required columns 'prompt' and 'ground_truth' not found")
            
            test_cases = []
            for _, row in df.iterrows():
                prompt = str(row[prompt_col]).strip()
                ground_truth = str(row[ground_truth_col]).strip()
                if prompt and ground_truth and prompt != 'nan' and ground_truth != 'nan':
                    test_cases.append({"prompt": prompt, "ground_truth": ground_truth})
            return test_cases
        except Exception as e:
            logger.error(f"Error processing test file: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error processing test file: {str(e)}")
        
    async def process_excel_questionnaire(self,file_path: str) -> List[Dict[str, Any]]:
        """
        Process Excel file and extract questionnaire responses from Sheet1
        Expected format:
        Column A: Category
        Column B: Question
        Column C: Description
        Column D: Customer_responses
        Column E: Additional Notes / Links
        """
        try:
            # Load workbook
            workbook = load_workbook(file_path, read_only=True)
            
            # Check if Sheet1 exists
            if "1.  Use Case Discovery" not in workbook.sheetnames:
                raise ValueError("Sheet1 not found in Excel file")
            
            sheet = workbook["1.  Use Case Discovery"]
            responses = []
            
            # Skip header row, start from row 2
            for row in sheet.iter_rows(min_row=2, values_only=True):
                if not row or all(cell is None for cell in row):
                    continue
                    
                category = row[0] if len(row) > 0 else None
                question = row[1] if len(row) > 1 else None
                description = row[2] if len(row) > 2 else None
                customer_response = row[3] if len(row) > 3 else None
                additional_notes = row[4] if len(row) > 4 else None
                
                # Skip rows without question or response
                if not question or not customer_response:
                    continue
                    
                # Clean up text data
                question = str(question).strip() if question else ""
                customer_response = str(customer_response).strip() if customer_response else ""
                
                # Skip empty responses
                if not customer_response or customer_response.lower() in ['', 'null', 'none']:
                    continue
                
                responses.append({
                    "category": str(category).strip() if category else None,
                    "question": question,
                    "description": str(description).strip() if description else None,
                    "response": customer_response,
                    "additional_notes": str(additional_notes).strip() if additional_notes else None
                })
            
            workbook.close()
            return responses
            
        except Exception as e:
            raise ValueError(f"Error processing Excel file: {str(e)}")
        
    async def _process_csv(self, file_path: str, data_file: DataFile):
        """Process CSV files"""
        try:
            df = pd.read_csv(file_path, nrows=1000)  # Sample first 1000 rows
            data_file.columns = df.columns.tolist()
            data_file.row_count = len(df)
            data_file.sample_data = df.head(3).to_dict('records')
            data_file.data_quality_score = self._calculate_data_quality_score(df)
        except Exception as e:
            # Try different encodings
            encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252']
            for encoding in encodings:
                try:
                    df = pd.read_csv(file_path, encoding=encoding, nrows=1000)
                    data_file.columns = df.columns.tolist()
                    data_file.row_count = len(df)
                    data_file.sample_data = df.head(3).to_dict('records')
                    data_file.data_quality_score = self._calculate_data_quality_score(df)
                    break
                except:
                    continue
    
    async def _process_excel(self, file_path: str, data_file: DataFile):
        """Process Excel files"""
        try:
            df = pd.read_excel(file_path, nrows=1000)
            data_file.columns = df.columns.tolist()
            data_file.row_count = len(df)
            data_file.sample_data = df.head(3).to_dict('records')
            data_file.data_quality_score = self._calculate_data_quality_score(df)
        except Exception as e:
            raise ValueError(f"Error processing Excel file: {str(e)}")
    
    async def _process_text(self, file_path: str, data_file: DataFile):
        """Process text files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            data_file.row_count = len(content.splitlines())
            data_file.sample_data = {"preview": content[:500] + "..." if len(content) > 500 else content}
            data_file.data_quality_score = 0.7 if len(content) > 100 else 0.3
        except UnicodeDecodeError:
            # Try different encodings
            encodings = ['latin-1', 'iso-8859-1', 'cp1252']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    data_file.row_count = len(content.splitlines())
                    data_file.sample_data = {"preview": content[:500] + "..." if len(content) > 500 else content}
                    data_file.data_quality_score = 0.7 if len(content) > 100 else 0.3
                    break
                except:
                    continue
    
    async def _process_json(self, file_path: str, data_file: DataFile):
        """Process JSON files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if isinstance(data, list):
                data_file.row_count = len(data)
                data_file.columns = list(data[0].keys()) if data and isinstance(data[0], dict) else None
                df = pd.DataFrame(data)
                data_file.data_quality_score = self._calculate_data_quality_score(df)
            elif isinstance(data, dict):
                data_file.row_count = 1
                data_file.columns = list(data.keys())
                data_file.data_quality_score = 0.5
            
            data_file.sample_data = data[:3] if isinstance(data, list) else data
        except Exception as e:
            raise ValueError(f"Error processing JSON file: {str(e)}")
    
    async def _process_parquet(self, file_path: str, data_file: DataFile):
        """Process Parquet files"""
        try:
            df = pd.read_parquet(file_path)
            data_file.columns = df.columns.tolist()
            data_file.row_count = len(df)
            data_file.sample_data = df.head(3).to_dict('records')
            data_file.data_quality_score = self._calculate_data_quality_score(df)
        except Exception as e:
            raise ValueError(f"Error processing Parquet file: {str(e)}")
    
    def _calculate_data_quality_score(self, df: pd.DataFrame) -> float:
        """Calculate data quality score based on completeness, consistency, etc."""
        if df.empty:
            return 0.0
        
        # Completeness score (percentage of non-null values)
        completeness = df.count().sum() / (df.shape[0] * df.shape[1])
        
        # Consistency score (check for obvious data issues)
        consistency = 1.0
        for col in df.columns:
            if df[col].dtype == 'object':
                # Check for mixed data types in text columns
                unique_vals = df[col].dropna().unique()
                if len(unique_vals) > 0:
                    text_ratio = sum(1 for val in unique_vals if isinstance(val, str)) / len(unique_vals)
                    consistency *= text_ratio
        
        # Volume score (penalize very small datasets)
        volume_score = min(1.0, df.shape[0] / 100)  # Assume 100 rows is minimum good volume
        
        # Overall quality score
        quality_score = (completeness * 0.5 + consistency * 0.3 + volume_score * 0.2)
        return round(quality_score, 2)
