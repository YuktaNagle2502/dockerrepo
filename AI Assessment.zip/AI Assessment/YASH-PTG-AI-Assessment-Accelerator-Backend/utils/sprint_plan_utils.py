from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.charts.barcharts import VerticalBarChart
import io
from datetime import datetime
from typing import Dict, Any
from services.sprint_planning_service import SprintPlanningGenerator
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SprintPlanningGeneratorUtil(SprintPlanningGenerator):
    def __init__(self):
        """Initialize the sprint planning generator with Groq API key."""
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()

    def _setup_custom_styles(self):
        """Setup custom styles for the PDF document."""
        self.styles = getSampleStyleSheet()
        # Title style
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Title'],
            fontSize=24,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=colors.HexColor('#1f4e79')
        )
        
        # Section header style
        self.section_style = ParagraphStyle(
            'SectionHeader',
            parent=self.styles['Heading1'],
            fontSize=16,
            spaceAfter=12,
            spaceBefore=20,
            textColor=colors.HexColor('#2c5282'),
            borderWidth=1,
            borderColor=colors.HexColor('#2c5282'),
            borderPadding=5
        )
        
        # Subsection style
        self.subsection_style = ParagraphStyle(
            'SubsectionHeader',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=10,
            spaceBefore=15,
            textColor=colors.HexColor('#4a5568')
        )
        
        # Body text style
        self.body_style = ParagraphStyle(
            'CustomBody',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=6,
            alignment=TA_JUSTIFY,
            leftIndent=0,
            rightIndent=0
        )
        
        # Bullet point style
        self.bullet_style = ParagraphStyle(
            'BulletPoint',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=4,
            leftIndent=20,
            bulletIndent=10
        )
        
        # Table cell style
        self.table_cell_style = ParagraphStyle(
            'TableCell',
            parent=self.styles['Normal'],
            fontSize=9,
            spaceAfter=2,
            alignment=TA_LEFT,
            leftIndent=2,
            rightIndent=2
        )
        
        # Table header style
        self.table_header_style = ParagraphStyle(
            'TableHeader',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=2,
            alignment=TA_LEFT,
            leftIndent=2,
            rightIndent=2,
            textColor=colors.white
        )

    def _create_table_cell(self, text: str, is_header: bool = False) -> Paragraph:
        """Create a properly formatted table cell with text wrapping."""
        if is_header:
            return Paragraph(str(text), self.table_header_style)
        else:
            return Paragraph(str(text), self.table_cell_style)

    def create_team_pie_chart(self, team_data: Dict[str, Any]) -> Drawing:
        """Create a pie chart showing team composition."""
        drawing = Drawing(200, 200)
        
        pie = Pie()
        pie.x = 50
        pie.y = 50
        pie.width = 100
        pie.height = 100
        
        # Extract team composition data
        roles = team_data.get('roles', [])
        pie.data = [role.get('count', 1) for role in roles]
        pie.labels = [role.get('role', 'Unknown') for role in roles]
        
        # Set colors
        colors_list = [colors.HexColor('#3182ce'), colors.HexColor('#38a169'), colors.HexColor('#d69e2e'), colors.HexColor('#e53e3e')]
        for i, color in enumerate(colors_list[:len(pie.data)]):
            pie.slices[i].fillColor = color
        
        drawing.add(pie)
        return drawing

    def create_sprint_timeline_chart(self, sprint_data: Dict[str, Any]) -> Drawing:
        """Create a timeline chart showing sprint progression."""
        drawing = Drawing(400, 200)
        
        # Create a simple bar chart showing sprint timeline
        chart = VerticalBarChart()
        chart.x = 50
        chart.y = 50
        chart.height = 100
        chart.width = 300
        
        # Sample data for sprints
        sprints = sprint_data.get('sprints', [])
        chart.data = [[len(sprint.get('tasks', [])) for sprint in sprints]]
        chart.categoryAxis.categoryNames = [f"Sprint {sprint.get('sprint_number', i+1)}" for i, sprint in enumerate(sprints)]
        chart.valueAxis.valueMin = 0
        chart.valueAxis.valueMax = max([len(sprint.get('tasks', [])) for sprint in sprints]) + 2 if sprints else 10
        
        chart.bars[0].fillColor = colors.HexColor('#3182ce')
        
        drawing.add(chart)
        return drawing

    def generate_pdf_report(self, content: Dict[str, Any], include_charts: bool = True) -> bytes:
        """Generate a comprehensive PDF report using ReportLab."""
        
        # Create PDF in memory
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
        story = []
        
        # Title
        title = content.get('project_overview', {}).get('title', 'Sprint Planning Document')
        story.append(Paragraph(title, self.title_style))
        story.append(Spacer(1, 12))
        
        # Document info
        story.append(Paragraph(f"Generated on: {datetime.now().strftime('%B %d, %Y')}", self.body_style))
        story.append(Spacer(1, 20))
        
        # Executive Summary
        story.append(Paragraph("Executive Summary", self.section_style))
        story.append(Paragraph(content.get('project_overview', {}).get('description', ''), self.body_style))
        story.append(Spacer(1, 12))
        
        # Project Overview
        story.append(Paragraph("Project Overview", self.section_style))
        
        overview = content.get('project_overview', {})
        story.append(Paragraph("Project Objectives:", self.subsection_style))
        for objective in overview.get('objectives', []):
            story.append(Paragraph(f"• {objective}", self.bullet_style))
        story.append(Spacer(1, 8))
        
        story.append(Paragraph("Success Criteria:", self.subsection_style))
        for criteria in overview.get('success_criteria', []):
            story.append(Paragraph(f"• {criteria}", self.bullet_style))
        story.append(Spacer(1, 12))
        
        # Technical Requirements
        story.append(Paragraph("Technical Requirements", self.section_style))
        
        tech_req = content.get('technical_requirements', {})
        story.append(Paragraph("Technology Stack:", self.subsection_style))
        for tech in tech_req.get('technology_stack', []):
            story.append(Paragraph(f"• {tech}", self.bullet_style))
        story.append(Spacer(1, 8))
        
        story.append(Paragraph("Architecture Pattern:", self.subsection_style))
        story.append(Paragraph(tech_req.get('architecture_pattern', ''), self.body_style))
        story.append(Spacer(1, 12))
        
        # AWS Services
        story.append(Paragraph("AWS Services Required", self.section_style))
        
        aws_services = content.get('aws_services', {})
        
        # Create AWS services table
        aws_data = [[
            self._create_table_cell('Service Category', True),
            self._create_table_cell('Services', True)
        ]]
        
        for category, services in aws_services.items():
            if isinstance(services, list):
                services_text = ', '.join(services)
                aws_data.append([
                    self._create_table_cell(category.replace('_', ' ').title()),
                    self._create_table_cell(services_text)
                ])
            elif category == 'estimated_monthly_cost':
                aws_data.append([
                    self._create_table_cell('Monthly Cost'),
                    self._create_table_cell(services)
                ])
        
        aws_table = Table(aws_data, colWidths=[2.5*inch, 3.5*inch])
        aws_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3182ce')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
            ('TOPPADDING', (0, 0), (-1, 0), 8),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f7fafc')),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#f7fafc'), colors.white])
        ]))
        
        story.append(aws_table)
        story.append(Spacer(1, 12))
        
        # Team Structure
        story.append(Paragraph("Team Structure", self.section_style))
        
        team_structure = content.get('team_structure', {})
        story.append(Paragraph(f"Total Developers Required: {team_structure.get('total_developers', 'TBD')}", self.body_style))
        story.append(Spacer(1, 8))
        
        # Team roles table
        team_data = [[
            self._create_table_cell('Role', True),
            self._create_table_cell('Count', True),
            self._create_table_cell('Key Responsibilities', True)
        ]]
        
        for role in team_structure.get('roles', []):
            responsibilities = ', '.join(role.get('responsibilities', []))
            team_data.append([
                self._create_table_cell(role.get('role', '')),
                self._create_table_cell(str(role.get('count', ''))),
                self._create_table_cell(responsibilities)
            ])
        
        team_table = Table(team_data, colWidths=[2*inch, 0.8*inch, 3.2*inch])
        team_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#38a169')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f0fff4')),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#f0fff4'), colors.white])
        ]))
        
        story.append(team_table)
        
        # Add team composition pie chart
        if include_charts:
            story.append(Spacer(1, 20))
            story.append(self.create_team_pie_chart(team_structure))
        
        story.append(Spacer(1, 20))
        
        # Sprint Plan
        story.append(Paragraph("Sprint Plan", self.section_style))
        
        sprint_plan = content.get('sprint_plan', {})
        story.append(Paragraph(f"Total Duration: {sprint_plan.get('duration', 'TBD')}", self.body_style))
        story.append(Paragraph(f"Number of Sprints: {sprint_plan.get('total_sprints', 'TBD')}", self.body_style))
        story.append(Spacer(1, 12))
        
        # Add sprint timeline chart
        if include_charts:
            story.append(self.create_sprint_timeline_chart(sprint_plan))
            story.append(Spacer(1, 20))
        
        # Individual sprint details
        for sprint in sprint_plan.get('sprints', []):
            story.append(Paragraph(f"Sprint {sprint.get('sprint_number', 'X')} - {sprint.get('duration', 'TBD')}", self.subsection_style))
            
            story.append(Paragraph("Goals:", self.body_style))
            for goal in sprint.get('goals', []):
                story.append(Paragraph(f"• {goal}", self.bullet_style))
            
            story.append(Paragraph("Key Tasks:", self.body_style))
            
            # Tasks table
            task_data = [[
                self._create_table_cell('Task', True),
                self._create_table_cell('Effort', True),
                self._create_table_cell('Assignee', True)
            ]]
            
            for task in sprint.get('tasks', []):
                task_data.append([
                    self._create_table_cell(task.get('task', '')),
                    self._create_table_cell(task.get('effort', '')),
                    self._create_table_cell(task.get('assignee', ''))
                ])
            
            task_table = Table(task_data, colWidths=[3.2*inch, 0.8*inch, 2*inch])
            task_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#d69e2e')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#fffbf0')),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#fffbf0'), colors.white])
            ]))
            
            story.append(task_table)
            story.append(Spacer(1, 8))
            
            story.append(Paragraph("Deliverables:", self.body_style))
            for deliverable in sprint.get('deliverables', []):
                story.append(Paragraph(f"• {deliverable}", self.bullet_style))
            
            story.append(Spacer(1, 12))
        
        # Risks and Mitigation
        story.append(Paragraph("Risks and Mitigation", self.section_style))
        
        risk_data = [[
            self._create_table_cell('Risk', True),
            self._create_table_cell('Impact', True),
            self._create_table_cell('Mitigation Strategy', True)
        ]]
        
        for risk in content.get('risks_and_mitigation', []):
            risk_data.append([
                self._create_table_cell(risk.get('risk', '')),
                self._create_table_cell(risk.get('impact', '')),
                self._create_table_cell(risk.get('mitigation', ''))
            ])
        
        risk_table = Table(risk_data, colWidths=[2*inch, 1*inch, 3*inch])
        risk_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e53e3e')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#fed7d7')),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#fed7d7'), colors.white])
        ]))
        
        story.append(risk_table)
        story.append(Spacer(1, 20))
        
        # Budget Estimation
        story.append(Paragraph("Budget Estimation", self.section_style))
        
        budget = content.get('budget_estimation', {})
        budget_data = [[
            self._create_table_cell('Cost Component', True),
            self._create_table_cell('Estimated Cost', True)
        ]]
        
        for component, cost in budget.items():
            budget_data.append([
                self._create_table_cell(component.replace('_', ' ').title()),
                self._create_table_cell(cost)
            ])
        
        budget_table = Table(budget_data, colWidths=[3*inch, 2*inch])
        budget_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#38a169')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f0fff4')),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#f0fff4'), colors.white])
        ]))
        
        story.append(budget_table)
        story.append(Spacer(1, 12))
        
        # Build PDF
        doc.build(story)
        
        # Get PDF data
        buffer.seek(0)
        pdf_data = buffer.getvalue()
        buffer.close()
        
        return pdf_data