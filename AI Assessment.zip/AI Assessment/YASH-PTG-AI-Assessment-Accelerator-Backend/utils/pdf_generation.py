from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.lib.colors import HexColor
import io
from datetime import datetime
import logging
from fastapi import HTTPException
from typing import List,Any
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PDFGenerator:
    def __init__(self):
        """Initialize PDF generator with common styles."""
        self.styles = getSampleStyleSheet()
        self._setup_common_styles()

    def _setup_common_styles(self):
        """Setup common PDF styles for consistent formatting."""
        self.title_style = ParagraphStyle(
            'CommonTitle',
            parent=self.styles['Title'],
            fontSize=24,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=HexColor('#1a365d'),
            fontName='Helvetica-Bold'
        )
        self.heading_style = ParagraphStyle(
            'CommonHeading',
            parent=self.styles['Heading1'],
            fontSize=16,
            spaceAfter=15,
            spaceBefore=20,
            textColor=HexColor('#2b6cb0'),
            fontName='Helvetica-Bold'
        )
        self.subheading_style = ParagraphStyle(
            'CommonSubHeading',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=10,
            spaceBefore=15,
            textColor=HexColor('#4a5568'),
            fontName='Helvetica-Bold'
        )
        self.body_style = ParagraphStyle(
            'CommonBody',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=8,
            alignment=TA_JUSTIFY,
            textColor=HexColor('#2d3748')
        )
        self.table_header_style = ParagraphStyle(
            'CommonTableHeader',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=2,
            alignment=TA_LEFT,
            textColor=colors.white,
            fontName='Helvetica-Bold'
        )
        self.table_cell_style = ParagraphStyle(
            'CommonTableCell',
            parent=self.styles['Normal'],
            fontSize=9,
            spaceAfter=2,
            alignment=TA_LEFT,
            leftIndent=2,
            rightIndent=2
        )

    def create_table_cell(self, text: str, is_header: bool = False) -> Paragraph:
        """
        Create a formatted table cell with text wrapping.
        
        Args:
            text: Text content for the cell
            is_header: Whether the cell is a header
            
        Returns:
            Paragraph: Formatted Paragraph object for the table cell
        """
        return Paragraph(str(text), self.table_header_style if is_header else self.table_cell_style)

    def create_standard_table(self, data: List[List[Any]], colWidths: List[float], header_color: str = '#3182ce') -> Table:
        """
        Create a standard formatted table.
        
        Args:
            data: List of lists containing table data
            colWidths: List of column widths in inches
            header_color: Hex color for the table header
            
        Returns:
            Table: Formatted ReportLab Table object
        """
        table_data = []
        for row in data:
            table_row = [self.create_table_cell(cell, is_header=(i == 0)) for i, cell in enumerate(row)]
            table_data.append(table_row)
        
        table = Table(table_data, colWidths=colWidths)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), HexColor(header_color)),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('BACKGROUND', (0, 1), (-1, -1), HexColor('#f7fafc'))
        ]))
        return table

    def generate_base_pdf(self, content_elements: List, title: str = "Report") -> bytes:
        """
        Generate a base PDF with common formatting.
        
        Args:
            content_elements: List of ReportLab flowables
            title: Title of the PDF document
            
        Returns:
            bytes: Generated PDF data
        """
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=50, leftMargin=50, topMargin=60, bottomMargin=60)
        
        story = []
        story.append(Paragraph(title, self.title_style))
        story.append(Spacer(1, 20))
        story.append(Paragraph(f"Generated on: {datetime.now().strftime('%B %d, %Y')}", self.body_style))
        story.append(Spacer(1, 20))
        story.extend(content_elements)
        
        try:
            doc.build(story)
            pdf_data = buffer.getvalue()
            buffer.close()
            return pdf_data
        except Exception as e:
            logger.error(f"Error generating PDF: {str(e)}")
            buffer.close()
            raise HTTPException(status_code=500, detail=f"Error generating PDF: {str(e)}")