from fastapi import HTTPException, status, UploadFile
import openpyxl
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from pathlib import Path
import uuid
import json
import os
import io
from openpyxl import load_workbook
from groq import Groq
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from models.models import PreWorkshopSession
from .s3_utils import upload_file, delete_file, download_file, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, BUCKET_NAME

# Pydantic Models
class PreWorkshopSessionCreate(BaseModel):
    project_id: int
    session_name: str
    description: Optional[str] = None

class PreWorkshopSessionResponse(BaseModel):
    id: int
    project_id: int
    session_name: str
    description: Optional[str]
    status: str
    questionnaire_file_path: Optional[str]
    report_file_path: Optional[str] 
    created_at: datetime
    updated_at: datetime
    presigned_url: Optional[str] = None
    
    class Config:
        from_attributes = True

class QuestionnaireResponseResponse(BaseModel):
    id: int
    session_id: int
    category: Optional[str]
    question: str
    description: Optional[str]
    response: str
    additional_notes: Optional[str]
    created_at: datetime
    
    class Config:
        from_attributes = True

class GeneratedUseCaseResponse(BaseModel):
    id: int
    session_id: int
    title: Optional[str] = None
    description: Optional[str] = None
    aws_services: Optional[List[str]] = None
    primary_genai_capability: Optional[str] = None
    business_category: Optional[str] = None
    customer_pain_points: Optional[List[str]] = None
    priority: Optional[str] = None
    complexity: Optional[str] = None
    estimated_effort: Optional[str] = None
    success_metrics: Optional[List[str]] = None
    aws_architecture: Optional[str] = None
    cost_estimate: Optional[str] = None
    dependencies: Optional[List[str]] = None
    risks: Optional[List[str]] = None
    roi_potential: Optional[str] = None
    implementation_phases: Optional[List[str]] = None
    is_selected: Optional[bool] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class PreWorkshopSessionDetail(BaseModel):
    id: int
    project_id: int
    session_name: str
    description: Optional[str] = None
    status: str
    questionnaire_file_path: Optional[str] = None
    report_file_path: Optional[str] = None 
    created_at: datetime
    updated_at: datetime
    questionnaire_responses: List[QuestionnaireResponseResponse] = []
    generated_use_cases: List[GeneratedUseCaseResponse] = []
    presigned_url: Optional[str] = None

    class Config:
        from_attributes = True

class ReportRequest(BaseModel):
    session_id: int
    report_type: str = "pdf"  # pdf, json
    include_sections: List[str] = ["questionnaire", "use_cases", "recommendations"]

class ExcelUploadResponse(BaseModel):
    message: str
    total_responses: int
    session_status: str
    responses_preview: List[Dict[str, Any]]
    presigned_url: Optional[str] = None

class BulkUseCaseSelection(BaseModel):
    use_case_ids: List[int]
    is_selected: bool = True
    
class CustomUseCaseCreate(BaseModel):
    title: str
    description: str
    aws_services: Optional[List[str]] = []
    primary_genai_capability: Optional[str] = None
    business_category: Optional[str] = None
    customer_pain_points: Optional[List[str]] = []
    priority: Optional[str] = "Medium"
    complexity: Optional[str] = "Medium"
    estimated_effort: Optional[str] = None
    success_metrics: Optional[List[str]] = []
    aws_architecture: Optional[str] = None
    cost_estimate: Optional[str] = None
    dependencies: Optional[List[str]] = []
    risks: Optional[List[str]] = []
    roi_potential: Optional[str] = "Medium"
    implementation_phases: Optional[List[str]] = []
    is_selected: Optional[bool] = False

class CustomUseCaseUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    aws_services: Optional[List[str]] = None
    primary_genai_capability: Optional[str] = None
    business_category: Optional[str] = None
    customer_pain_points: Optional[List[str]] = None
    priority: Optional[str] = None
    complexity: Optional[str] = None
    estimated_effort: Optional[str] = None
    success_metrics: Optional[List[str]] = None
    aws_architecture: Optional[str] = None
    cost_estimate: Optional[str] = None
    dependencies: Optional[List[str]] = None
    risks: Optional[List[str]] = None
    roi_potential: Optional[str] = None
    implementation_phases: Optional[List[str]] = None
    is_selected: Optional[bool] = None
    
class GenAIUseCasesGenerator:
    """Generate GenAI use cases from customer responses"""
    
    def __init__(self, api_key: str, model: str = "llama-3.3-70b-versatile"):
        self.client = Groq(api_key=api_key)
        self.model = model
    
    async def generate_aws_genai_use_cases(self, customer_responses: List[str]) -> List[Dict]:
        """Generate AWS-based GenAI use cases from customer responses"""
        combined_responses = "\n".join([f"- {response}" for response in customer_responses])
        
        system_prompt = """
        You are an expert AWS GenAI solutions architect specialized in identifying practical GenAI use cases for business problems.
        Your task is to analyze customer responses and generate specific, actionable AWS GenAI use cases that can be proposed to clients.
        
        Focus on AWS GenAI services like:
        - Amazon Bedrock (Claude, Titan, Jurassic models)
        - Amazon SageMaker (Custom ML models)
        - Amazon Comprehend (NLP)
        - Amazon Textract (Document analysis)
        - Amazon Transcribe (Speech-to-text)
        - Amazon Polly (Text-to-speech)
        - Amazon Rekognition (Image/Video analysis)
        - Amazon Lex (Conversational AI)
        - Amazon Kendra (Intelligent search)
        - Amazon CodeWhisperer (Code generation)
        - Amazon Personalize (Recommendations)
        
        IMPORTANT: Always respond with ONLY valid JSON format containing an array of use cases.
        Do not include any explanatory text, just the JSON array.
        """
        
        user_request = f"""
        Customer Responses Analysis:
        {combined_responses}
        
        Based on these customer responses, generate 10-15 specific AWS GenAI use cases that could address their requirements. For each use case, provide:
        
        Return ONLY this JSON structure with NO additional text:
        [
          {{
            "title": "Specific AWS GenAI Use Case Title",
            "description": "Detailed description of how AWS GenAI solves the customer problem",
            "aws_services": ["Amazon Bedrock", "Amazon SageMaker", "etc"],
            "primary_genai_capability": "Primary GenAI technology (e.g., LLM, NLP, Computer Vision)",
            "business_category": "Business category (e.g., Customer Service, Operations, Analytics)",
            "customer_pain_points": ["pain point 1", "pain point 2"],
            "priority": "High/Medium/Low",
            "complexity": "High/Medium/Low",
            "estimated_effort": "X weeks/months",
            "success_metrics": ["metric1", "metric2", "metric3"],
            "aws_architecture": "High-level AWS architecture description",
            "cost_estimate": "Estimated monthly AWS cost range",
            "dependencies": ["dependency1", "dependency2"],
            "risks": ["risk1", "risk2"],
            "roi_potential": "High/Medium/Low",
            "implementation_phases": ["phase1", "phase2", "phase3"],
            "Justification":"Justification how this usecase will solve the customer problem, How the ROI is calculated and what is the impact of
            this usecase for the particular customer needs",
          }}
        ]
        """
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_request}
                ],
                temperature=0.7,
                max_tokens=4000
            )
            
            ai_response = response.choices[0].message.content.strip()
            
            try:
                parsed_json = json.loads(ai_response)
                return parsed_json
            except json.JSONDecodeError:
                import re
                json_match = re.search(r'\[.*\]', ai_response, re.DOTALL)
                if json_match:
                    try:
                        parsed_json = json.loads(json_match.group())
                        return parsed_json
                        
                    except:
                        pass
                
                return [{
                    "title": "Error in AI Response",
                    "description": "Could not parse AI response into valid JSON",
                    "aws_services": ["N/A"],
                    "primary_genai_capability": "N/A",
                    "business_category": "Error",
                    "customer_pain_points": ["Invalid AI response"],
                    "priority": "High",
                    "complexity": "High",
                    "estimated_effort": "N/A",
                    "success_metrics": ["Fix AI response parsing"],
                    "aws_architecture": "N/A",
                    "cost_estimate": "N/A",
                    "dependencies": ["Valid AI response"],
                    "risks": ["Invalid JSON format"],
                    "roi_potential": "Low",
                    "implementation_phases": ["Debug response format"]
                }]
                
        except Exception as e:
            return [{
                "title": "API Error",
                "description": f"Error calling Groq API: {str(e)}",
                "aws_services": ["N/A"],
                "primary_genai_capability": "N/A",
                "business_category": "Error",
                "customer_pain_points": ["API connection failed"],
                "priority": "High",
                "complexity": "High",
                "estimated_effort": "N/A",
                "success_metrics": ["Fix API connection"],
                "aws_architecture": "N/A",
                "cost_estimate": "N/A",
                "dependencies": ["Valid API key"],
                "risks": ["API unavailable"],
                "roi_potential": "Low",
                "implementation_phases": ["Establish API connection"]
            }]

def process_excel_questionnaire(file_path: str) -> List[Dict[str, Any]]:
    """
    Process Excel file and extract questionnaire responses from Sheet1
    Expected format:
    Column A: Category
    Column B: Question
    Column C: Description
    Column D: Customer_responses
    Column E: Additional Notes / Links
    """
    try:
        workbook = load_workbook(file_path, read_only=True)
        
        if "1.  Use Case Discovery" not in workbook.sheetnames:
            raise ValueError("Sheet1 not found in Excel file")
        
        sheet = workbook["1.  Use Case Discovery"]
        responses = []
        
        for row in sheet.iter_rows(min_row=2, values_only=True):
            if not row or all(cell is None for cell in row):
                continue
                
            category = row[0] if len(row) > 0 else None
            question = row[1] if len(row) > 1 else None
            description = row[2] if len(row) > 2 else None
            customer_response = row[3] if len(row) > 3 else None
            additional_notes = row[4] if len(row) > 4 else None
            
            if not question or not customer_response:
                continue
                
            question = str(question).strip() if question else ""
            customer_response = str(customer_response).strip() if customer_response else ""
            
            if not customer_response or customer_response.lower() in ['', 'null', 'none']:
                continue
            
            responses.append({
                "category": str(category).strip() if category else None,
                "question": question,
                "description": str(description).strip() if description else None,
                "response": customer_response,
                "additional_notes": str(additional_notes).strip() if additional_notes else None
            })
        
        workbook.close()
        return responses
        
    except Exception as e:
        raise ValueError(f"Error processing Excel file: {str(e)}")

async def save_uploaded_file(
    file: UploadFile,
    session_id: int,
    session_name: str,
    folder_prefix: str,
    project_name: Optional[str] = None  # New parameter
) -> tuple[str, str]:
    """Save uploaded file to S3 and return the S3 key and presigned URL"""
    try:
        content = await file.read()
        s3_key, presigned_url, _ = upload_file(
            bucket_name=BUCKET_NAME,
            file_content=content,
            session_id=session_id,
            session_name=session_name,
            filename=file.filename,
            access_key=AWS_ACCESS_KEY_ID,
            secret_key=AWS_SECRET_ACCESS_KEY,
            region=AWS_REGION,
            folder_prefix=folder_prefix,
            project_name=project_name  # Pass project name
        )
        return s3_key, presigned_url
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving file to S3: {str(e)}"
        )

def generate_pdf_report(session_data: Dict, questionnaire_responses: List[Dict], use_cases: List[Dict]) -> bytes:
    """Generate PDF report for pre-workshop session"""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
    
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=20,
        spaceAfter=30,
        alignment=TA_CENTER
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        spaceAfter=12,
        spaceBefore=20
    )
    
    content = []
    
    content.append(Paragraph("Pre-Workshop Assessment Report", title_style))
    content.append(Spacer(1, 20))
    
    content.append(Paragraph("Session Information", heading_style))
    session_info = [
        ["Session Name:", session_data['session_name']],
        ["Description:", session_data.get('description', 'N/A')],
        ["Status:", session_data['status']],
        ["Created:", session_data['created_at']],
        ["Updated:", session_data['updated_at']]
    ]
    
    session_table = Table(session_info, colWidths=[2*inch, 4*inch])
    session_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.grey),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('BACKGROUND', (1, 0), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    content.append(session_table)
    content.append(Spacer(1, 20))
    
    content.append(Paragraph("Questionnaire Responses", heading_style))
    
    categories = {}
    for response in questionnaire_responses:
        category = response.get('category', 'General')
        if category not in categories:
            categories[category] = []
        categories[category].append(response)
    
    for category, responses in categories.items():
        if category and category != 'None':
            content.append(Paragraph(f"<b>{category}</b>", heading_style))
        
        for i, response in enumerate(responses, 1):
            content.append(Paragraph(f"<b>Q{i}: {response['question']}</b>", styles['Normal']))
            if response.get('description'):
                content.append(Paragraph(f"<i>{response['description']}</i>", styles['Normal']))
            content.append(Paragraph(f"<b>Answer:</b> {response['response']}", styles['Normal']))
            if response.get('additional_notes'):
                content.append(Paragraph(f"<i>Notes: {response['additional_notes']}</i>", styles['Normal']))
            content.append(Spacer(1, 10))
    
    content.append(PageBreak())
    
    content.append(Paragraph("Generated AWS GenAI Use Cases", heading_style))
    
    for i, use_case in enumerate(use_cases, 1):
        content.append(Paragraph(f"<b>Use Case {i}: {use_case['title']}</b>", heading_style))
        content.append(Paragraph(f"<b>Description:</b> {use_case['description']}", styles['Normal']))
        content.append(Spacer(1, 8))
        
        use_case_details = [
            ["AWS Services:", ", ".join(use_case.get('aws_services', []))],
            ["Primary GenAI Capability:", use_case.get('primary_genai_capability', 'N/A')],
            ["Business Category:", use_case.get('business_category', 'N/A')],
            ["Priority:", use_case.get('priority', 'N/A')],
            ["Complexity:", use_case.get('complexity', 'N/A')],
            ["Estimated Effort:", use_case.get('estimated_effort', 'N/A')],
            ["Cost Estimate:", use_case.get('cost_estimate', 'N/A')],
            ["ROI Potential:", use_case.get('roi_potential', 'N/A')]
        ]
        
        details_table = Table(use_case_details, colWidths=[2*inch, 4*inch])
        details_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        content.append(details_table)
        content.append(Spacer(1, 15))
    
    doc.build(content)
    buffer.seek(0)
    return buffer.read()

def cleanup_uploaded_file(temp_file_path: str, s3_key: Optional[str] = None) -> None:
    """Clean up temporary file and optionally S3 file."""
    try:
        if os.path.exists(temp_file_path):
            os.remove(temp_file_path)
            print(f"Deleted temporary file: {temp_file_path}")
    except Exception as e:
        print(f"Failed to delete temporary file {temp_file_path}: {str(e)}")
    if s3_key:
        try:
            delete_file(
                bucket_name=BUCKET_NAME,
                s3_key=s3_key,
                access_key=AWS_ACCESS_KEY_ID,
                secret_key=AWS_SECRET_ACCESS_KEY,
                region=AWS_REGION
            )
            print(f"Deleted S3 file: {s3_key}")
        except Exception as e:
            print(f"Failed to delete S3 file {s3_key}: {str(e)}")

def validate_excel_file(filename: str) -> bool:
    """Validate if file is Excel format"""
    return filename.endswith(('.xlsx', '.xls'))

def create_responses_preview(responses: List[Dict[str, Any]], limit: int = 5) -> List[Dict[str, Any]]:
    """Create a preview of questionnaire responses"""
    return [
        {
            "category": resp['category'],
            "question": resp['question'][:100] + "..." if len(resp['question']) > 100 else resp['question'],
            "response": resp['response'][:200] + "..." if len(resp['response']) > 200 else resp['response']
        }
        for resp in responses[:limit]
    ]