from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.platypus.flowables import KeepTogether
import io
from datetime import datetime
from fastapi import UploadFile, HTTPException, status
from services.model_evaluation_service import GroqClient
import os
import tempfile
from typing import Optional, List, Dict, Any, Union
import json
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ModelEvaluationPDFGenerator:
    """Generate PDF reports from model evaluation results"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        self.title_style = ParagraphStyle(
            'ModelEvalTitle',
            parent=self.styles['Title'],
            fontSize=24,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=colors.HexColor('#1a365d'),
            fontName='Helvetica-Bold'
        )
        
        self.heading_style = ParagraphStyle(
            'ModelEvalHeading',
            parent=self.styles['Heading1'],
            fontSize=16,
            spaceAfter=15,
            spaceBefore=20,
            textColor=colors.HexColor('#2b6cb0'),
            fontName='Helvetica-Bold'
        )
        
        self.subheading_style = ParagraphStyle(
            'ModelEvalSubHeading',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=10,
            spaceBefore=15,
            textColor=colors.HexColor('#4a5568'),
            fontName='Helvetica-Bold'
        )
        
        self.body_style = ParagraphStyle(
            'ModelEvalBody',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=8,
            textColor=colors.HexColor('#2d3748'),
            alignment=TA_JUSTIFY
        )
        
        self.code_style = ParagraphStyle(
            'ModelEvalCode',
            parent=self.styles['Normal'],
            fontSize=9,
            spaceAfter=5,
            textColor=colors.HexColor('#2d3748'),
            fontName='Courier',
            backColor=colors.HexColor('#f7fafc'),
            borderColor=colors.HexColor('#e2e8f0'),
            borderWidth=1,
            borderPadding=5
        )
    
    def _create_model_summaries(self, detailed_results: List[dict]) -> dict[str, dict]:
        """Create model summaries from detailed results"""
        model_summaries = {}
        
        for result in detailed_results:
            model_name = result['model_name']
            if model_name not in model_summaries:
                model_summaries[model_name] = {
                    'total_test_cases': 0,
                    'correct_responses': 0,
                    'total_score': 0,
                    'total_response_time': 0,
                    'test_cases': []
                }
            
            summary = model_summaries[model_name]
            summary['total_test_cases'] += 1
            summary['correct_responses'] += 1 if result['is_correct'] else 0
            summary['total_score'] += result['accuracy_score']
            summary['total_response_time'] += result['response_time']
            summary['test_cases'].append(result)
        
        for model_name, summary in model_summaries.items():
            summary['accuracy_percentage'] = (summary['correct_responses'] / summary['total_test_cases']) * 100
            summary['average_score'] = summary['total_score'] / summary['total_test_cases']
            summary['average_response_time'] = summary['total_response_time'] / summary['total_test_cases']
        
        return model_summaries
    
    def generate_pdf(self, results: dict[str, Any], title: str = "Model Evaluation Report") -> bytes:
        """Generate PDF from evaluation results"""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=50,
            leftMargin=50,
            topMargin=60,
            bottomMargin=60
        )
        
        content = []
        
        content.append(Paragraph(title, self.title_style))
        content.append(Spacer(1, 20))
        
        timestamp = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        content.append(Paragraph(f"Generated on {timestamp}", self.body_style))
        content.append(Paragraph(f"Evaluation ID: {results.get('evaluation_id', 'N/A')}", self.body_style))
        content.append(Spacer(1, 30))
        
        overall = results.get("overall_results", {})
        content.append(Paragraph("Executive Summary", self.heading_style))
        
        summary_data = [
            ["Metric", "Value"],
            ["Total Models Evaluated", str(overall.get("total_models", 0))],
            ["Total Test Cases", str(overall.get("total_test_cases", 0))],
            ["Best Performing Model", overall.get("best_performing_model", "N/A")],
            ["Worst Performing Model", overall.get("worst_performing_model", "N/A")],
            ["Overall Average Score", f"{overall.get('overall_average_score', 0):.2f}%"],
            ["Overall Average Accuracy", f"{overall.get('overall_average_accuracy', 0):.2f}%"],
            ["Performance Variance", f"{overall.get('performance_variance', 0):.2f}%"]
        ]
        
        summary_table = Table(summary_data, colWidths=[3*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3182ce')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f7fafc')),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')
        ]))
        
        content.append(summary_table)
        content.append(Spacer(1, 20))
        
        content.append(Paragraph("Model Performance Rankings", self.heading_style))
        
        rankings = overall.get("model_rankings", [])
        if rankings:
            ranking_data = [["Rank", "Model", "Avg Score", "Accuracy %", "Avg Response Time (s)"]]
            for ranking in rankings:
                ranking_data.append([
                    str(ranking["rank"]),
                    ranking["model_name"],
                    f"{ranking['average_score']:.2f}%",
                    f"{ranking['accuracy_percentage']:.2f}%",
                    f"{ranking['average_response_time']:.3f}s"
                ])
            
            ranking_table = Table(ranking_data, colWidths=[0.8*inch, 2*inch, 1.2*inch, 1.2*inch, 1.3*inch])
            ranking_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#38a169')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f0fff4')),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')
            ]))
            
            content.append(ranking_table)
        
        content.append(Spacer(1, 20))
        
        detailed_results = results.get("detailed_results", [])
        model_summaries = self._create_model_summaries(detailed_results)
        
        content.append(Paragraph("Detailed Model Results", self.heading_style))
        
        for model_name, summary in model_summaries.items():
            model_content = []
            model_content.append(Paragraph(f"Model: {model_name}", self.subheading_style))
            
            model_data = [
                ["Metric", "Value"],
                ["Total Test Cases", str(summary["total_test_cases"])],
                ["Correct Responses", str(summary["correct_responses"])],
                ["Accuracy Percentage", f"{summary['accuracy_percentage']:.2f}%"],
                ["Average Score", f"{summary['average_score']:.2f}%"],
                ["Average Response Time", f"{summary['average_response_time']:.3f}s"]
            ]
            
            model_table = Table(model_data, colWidths=[2.5*inch, 2*inch])
            model_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e2e8f0')),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')
            ]))
            
            model_content.append(model_table)
            model_content.append(Spacer(1, 15))
            
            model_content.append(Paragraph(f"Test Case Details for {model_name}", self.subheading_style))
            
            for i, test_case in enumerate(summary['test_cases'], 1):
                status_color = colors.HexColor('#22c55e') if test_case['is_correct'] else colors.HexColor('#ef4444')
                status_text = "✓ CORRECT" if test_case['is_correct'] else "✗ INCORRECT"
                
                test_case_data = [
                    [f"Test Case {i}", f"{status_text}", f"Score: {test_case['accuracy_score']}%", f"Time: {test_case['response_time']:.3f}s"]
                ]
                
                test_case_table = Table(test_case_data, colWidths=[1.5*inch, 1.5*inch, 1.5*inch, 1.5*inch])
                test_case_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8fafc')),
                    ('TEXTCOLOR', (1, 0), (1, 0), status_color),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')
                ]))
                
                model_content.append(test_case_table)
                
                details_data = [
                    ["Prompt", test_case['prompt'][:200] + "..." if len(test_case['prompt']) > 200 else test_case['prompt']],
                    ["Expected", test_case['ground_truth'][:200] + "..." if len(test_case['ground_truth']) > 200 else test_case['ground_truth']],
                    ["Actual Response", test_case['response'][:300] + "..." if len(test_case['response']) > 300 else test_case['response']],
                    ["Judge Explanation", test_case['judge_explanation']]
                ]
                
                details_table = Table(details_data, colWidths=[1.5*inch, 4.5*inch])
                details_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#ffffff')),
                    ('ALIGN', (0, 0), (0, -1), 'LEFT'),
                    ('ALIGN', (1, 0), (1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 8),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                    ('LEFTPADDING', (0, 0), (-1, -1), 5),
                    ('RIGHTPADDING', (0, 0), (-1, -1), 5),
                    ('TOPPADDING', (0, 0), (-1, -1), 5),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 5)
                ]))
                
                model_content.append(details_table)
                model_content.append(Spacer(1, 10))
            
            content.append(KeepTogether(model_content))
            content.append(PageBreak())
        
        content.append(Paragraph("Evaluation Summary", self.heading_style))
        summary_text = results.get("evaluation_summary", "No summary available")
        content.append(Paragraph(summary_text, self.body_style))
        
        doc.build(content)
        buffer.seek(0)
        return buffer.read()

async def save_uploaded_file(upload_file: UploadFile, temp_dir: str = None) -> str:
    """Save uploaded file to temporary location"""
    if temp_dir is None:
        temp_dir = tempfile.mkdtemp()
    
    file_path = os.path.join(temp_dir, upload_file.filename)
    
    try:
        content = await upload_file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        return file_path
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving file: {str(e)}"
        )

async def generate_evaluation_summary(results: dict[str, Any]) -> str:
    """Generate a human-readable evaluation summary"""
    overall = results.get("overall_results", {})
    model_summaries = results.get("model_summaries", {})
    
    if not overall or not model_summaries:
        return "No evaluation results available."
    
    summary_parts = []
    total_models = overall.get("total_models", 0)
    best_model = overall.get("best_performing_model", "Unknown")
    avg_score = overall.get("overall_average_score", 0)
    
    summary_parts.append(f"Evaluated {total_models} models with an overall average score of {avg_score:.2f}%.")
    summary_parts.append(f"Best performing model: {best_model}")
    
    rankings = overall.get("model_rankings", [])
    if rankings:
        summary_parts.append("\nModel Performance Rankings:")
        for i, ranking in enumerate(rankings[:3]):
            model_name = ranking["model_name"]
            score = ranking["average_score"]
            accuracy = ranking["accuracy_percentage"]
            summary_parts.append(f"{i+1}. {model_name}: {score:.2f}% avg score, {accuracy:.2f}% accuracy")
    
    if len(rankings) > 1:
        best_score = rankings[0]["average_score"]
        worst_score = rankings[-1]["average_score"]
        score_gap = best_score - worst_score
        
        if score_gap > 20:
            summary_parts.append(f"\nSignificant performance variation detected ({score_gap:.1f}% gap between best and worst models).")
        elif score_gap > 10:
            summary_parts.append(f"\nModerate performance variation ({score_gap:.1f}% gap between best and worst models).")
        else:
            summary_parts.append(f"\nConsistent performance across models ({score_gap:.1f}% gap).")
    
    client = GroqClient(api_key=os.getenv("GROQ_API_KEY"), model_name="llama3-70b-8192")
    response = await client.generate_response(
        prompt=f"""Summarize the model evaluation results in a concise manner from this data {summary_parts} and 
         provide me the detail model evaluation summary in md format.
         Do not generate the any table or any other format just generate the summary in md format.
         Try to provide me the your analysis based on the model performance and also provide me the
         performance of the models based on the overall performance and also provide me the best performing model and
         worst performing model and also provide me the overall average score of the models.
         generate the detailed summary of the model evaluation results.
         """
    )
    
    return response