from typing import Optional, List, Dict, Any, Union,Tuple
from enum import Enum
from dataclasses import dataclass
from pydantic import BaseModel, Field
from datetime import datetime
import pandas as pd
import os
import io
import re
from pathlib import Path
from fastapi import UploadFile, HTTPException, status
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.colors import HexColor
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer,Table, TableStyle, PageBreak,KeepTogether
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.lib import colors
from reportlab.lib.colors import HexColor
import tempfile

class DataReadinessStatus(Enum):
    READY = "ready"
    PARTIALLY_READY = "partially_ready"
    NOT_READY = "not_ready"

@dataclass
class DataRequirement:
    """Represents a specific data requirement for a use case"""
    name: str
    description: str
    required_columns: List[str]
    data_type: str
    minimum_rows: int
    criticality: str  # 'critical', 'important', 'nice_to_have'
    weight: float  # Weight for scoring (0-1)

@dataclass
class DataFile:
    """Represents an uploaded data file"""
    filename: str
    file_type: str
    size_mb: float
    columns: Optional[List[str]] = None
    row_count: Optional[int] = None
    sample_data: Optional[Dict] = None
    data_quality_score: float = 0.0
    matches_requirements: List[str] = None

@dataclass
class DataReadinessReport:
    """Represents the final data readiness assessment report"""
    use_case_title: str
    overall_status: DataReadinessStatus
    readiness_score: float  # 0-100
    requirements_analysis: Dict[str, Any]
    data_quality_issues: List[str]
    recommendations: List[str]
    detailed_analysis: str
    files_analyzed: List[DataFile]
    timestamp: str

class DataReadinessAnalysisResponse(BaseModel):
    use_case_id: int
    analysis_type: str
    generated_content: str
    readiness_score: float
    status: str
    files_count: int
    generated_at: datetime

class DataFileInfo(BaseModel):
    filename: str
    file_type: str
    size_mb: float
    row_count: Optional[int] = None
    columns_count: Optional[int] = None
    data_quality_score: float
    matches_requirements: List[str]

class FileProcessor:
    """Process various file types for data readiness analysis"""
    
    async def process_file(self, file_path: str, filename: str) -> DataFile:
        """Process uploaded file and extract metadata with quality assessment"""
        try:
            file_path = Path(file_path)
            file_size_mb = file_path.stat().st_size / (1024 * 1024)
            file_type = file_path.suffix.lower()
            
            from services.data_readiness_service import DataReadinessAnalyzerService
            if file_type not in DataReadinessAnalyzerService.SUPPORTED_EXTENSIONS:
                raise ValueError(f"Unsupported file type: {file_type}")
            
            data_file = DataFile(
                filename=filename,
                file_type=file_type,
                size_mb=round(file_size_mb, 2),
                matches_requirements=[]
            )
            
            # Process based on file type
            if file_type == '.csv':
                await self._process_csv(file_path, data_file)
            elif file_type in ['.xlsx', '.xls']:
                await self._process_excel(file_path, data_file)
            elif file_type == '.txt':
                await self._process_text(file_path, data_file)
            elif file_type == '.json':
                await self._process_json(file_path, data_file)
            elif file_type == '.parquet':
                await self._process_parquet(file_path, data_file)
            
            return data_file
            
        except Exception as e:
            raise ValueError(f"Error processing file: {str(e)}")
    
    async def _process_csv(self, file_path: str, data_file: DataFile):
        """Process CSV files"""
        try:
            df = pd.read_csv(file_path, nrows=20)  # Sample first 1000 rows
            data_file.columns = df.columns.tolist()
            data_file.row_count = len(df)
            data_file.sample_data = df.head(3).to_dict('records')
            data_file.data_quality_score = self._calculate_data_quality_score(df)
        except Exception as e:
            # Try different encodings
            encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252']
            for encoding in encodings:
                try:
                    df = pd.read_csv(file_path, encoding=encoding, nrows=1000)
                    data_file.columns = df.columns.tolist()
                    data_file.row_count = len(df)
                    data_file.sample_data = df.head(3).to_dict('records')
                    data_file.data_quality_score = self._calculate_data_quality_score(df)
                    break
                except:
                    continue
    
    async def _process_excel(self, file_path: str, data_file: DataFile):
        """Process Excel files"""
        try:
            df = pd.read_excel(file_path, nrows=20)
            data_file.columns = df.columns.tolist()
            data_file.row_count = len(df)
            data_file.sample_data = df.head(3).to_dict('records')
            data_file.data_quality_score = self._calculate_data_quality_score(df)
        except Exception as e:
            raise ValueError(f"Error processing Excel file: {str(e)}")
    
    async def _process_text(self, file_path: str, data_file: DataFile):
        """Process text files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            data_file.row_count = len(content.splitlines())
            data_file.sample_data = {"preview": content[:500] + "..." if len(content) > 500 else content}
            data_file.data_quality_score = 0.7 if len(content) > 100 else 0.3
        except UnicodeDecodeError:
            # Try different encodings
            encodings = ['latin-1', 'iso-8859-1', 'cp1252']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    data_file.row_count = len(content.splitlines())
                    data_file.sample_data = {"preview": content[:500] + "..." if len(content) > 500 else content}
                    data_file.data_quality_score = 0.7 if len(content) > 100 else 0.3
                    break
                except:
                    continue
    
    async def _process_json(self, file_path: str, data_file: DataFile):
        """Process JSON files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if isinstance(data, list):
                data_file.row_count = len(data)
                data_file.columns = list(data[0].keys()) if data and isinstance(data[0], dict) else None
                df = pd.DataFrame(data)
                data_file.data_quality_score = self._calculate_data_quality_score(df)
            elif isinstance(data, dict):
                data_file.row_count = 1
                data_file.columns = list(data.keys())
                data_file.data_quality_score = 0.5
            
            data_file.sample_data = data[:3] if isinstance(data, list) else data
        except Exception as e:
            raise ValueError(f"Error processing JSON file: {str(e)}")
    
    async def _process_parquet(self, file_path: str, data_file: DataFile):
        """Process Parquet files"""
        try:
            df = pd.read_parquet(file_path)
            data_file.columns = df.columns.tolist()
            data_file.row_count = len(df)
            data_file.sample_data = df.head(3).to_dict('records')
            data_file.data_quality_score = self._calculate_data_quality_score(df)
        except Exception as e:
            raise ValueError(f"Error processing Parquet file: {str(e)}")
    
    def _calculate_data_quality_score(self, df: pd.DataFrame) -> float:
        """Calculate data quality score based on completeness, consistency, etc."""
        if df.empty:
            return 0.0
        
        # Completeness score (percentage of non-null values)
        completeness = df.count().sum() / (df.shape[0] * df.shape[1])
        
        # Consistency score (check for obvious data issues)
        consistency = 1.0
        for col in df.columns:
            if df[col].dtype == 'object':
                # Check for mixed data types in text columns
                unique_vals = df[col].dropna().unique()
                if len(unique_vals) > 0:
                    text_ratio = sum(1 for val in unique_vals if isinstance(val, str)) / len(unique_vals)
                    consistency *= text_ratio
        
        # Volume score (penalize very small datasets)
        volume_score = min(1.0, df.shape[0] / 100)  # Assume 100 rows is minimum good volume
        
        # Overall quality score
        quality_score = (completeness * 0.5 + consistency * 0.3 + volume_score * 0.2)
        return round(quality_score, 2)

class DataReadinessPDFGenerator:
    """Generate PDF reports for data readiness analysis from markdown content"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        # Title style
        self.title_style = ParagraphStyle(
            'DataReadinessTitle',
            parent=self.styles['Title'],
            fontSize=24,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=HexColor('#1a365d'),
            fontName='Helvetica-Bold'
        )
        
        # Subtitle style
        self.subtitle_style = ParagraphStyle(
            'DataReadinessSubtitle',
            parent=self.styles['Normal'],
            fontSize=16,
            spaceAfter=20,
            alignment=TA_CENTER,
            textColor=HexColor('#2d3748'),
            fontName='Helvetica-Oblique'
        )
        
        # Heading styles
        self.h1_style = ParagraphStyle(
            'DataReadinessH1',
            parent=self.styles['Heading1'],
            fontSize=18,
            spaceAfter=15,
            spaceBefore=25,
            textColor=HexColor('#2b6cb0'),
            fontName='Helvetica-Bold',
            backColor=HexColor('#ebf8ff'),
            borderWidth=2,
            borderColor=HexColor('#3182ce'),
            borderPadding=10,
            leftIndent=0,
            rightIndent=0
        )
        
        self.h2_style = ParagraphStyle(
            'DataReadinessH2',
            parent=self.styles['Heading2'],
            fontSize=16,
            spaceAfter=12,
            spaceBefore=18,
            textColor=HexColor('#2c5282'),
            fontName='Helvetica-Bold',
            leftIndent=0
        )
        
        self.h3_style = ParagraphStyle(
            'DataReadinessH3',
            parent=self.styles['Heading3'],
            fontSize=14,
            spaceAfter=10,
            spaceBefore=15,
            textColor=HexColor('#3182ce'),
            fontName='Helvetica-Bold',
            leftIndent=10
        )
        
        # Body styles
        self.body_style = ParagraphStyle(
            'DataReadinessBody',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=8,
            textColor=HexColor('#2d3748'),
            alignment=TA_JUSTIFY,
            leftIndent=0,
            rightIndent=0
        )
        
        # List styles
        self.bullet_style = ParagraphStyle(
            'DataReadinessBullet',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=6,
            textColor=HexColor('#4a5568'),
            leftIndent=25,
            bulletIndent=15
        )
        # Table styles
        self.table_header_style = ParagraphStyle(
            'TableHeader',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=HexColor('#1a365d'),
            fontName='Helvetica-Bold',
            alignment=TA_CENTER
        )
        
        self.table_cell_style = ParagraphStyle(
            'TableCell',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=HexColor('#2d3748'),
            alignment=TA_LEFT
        )
        
        # Alert styles
        self.alert_critical_style = ParagraphStyle(
            'AlertCritical',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=HexColor('#fed7d7'),
            borderColor=HexColor('#e53e3e'),
            borderWidth=2,
            borderPadding=10,
            spaceAfter=12,
            spaceBefore=6,
            textColor=HexColor('#742a2a'),
            leftIndent=0,
            rightIndent=0
        )
        
        self.alert_warning_style = ParagraphStyle(
            'AlertWarning',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=HexColor('#fef5e7'),
            borderColor=HexColor('#ed8936'),
            borderWidth=2,
            borderPadding=10,
            spaceAfter=12,
            spaceBefore=6,
            textColor=HexColor('#744210'),
            leftIndent=0,
            rightIndent=0
        )
        
        self.alert_info_style = ParagraphStyle(
            'AlertInfo',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=HexColor('#ebf8ff'),
            borderColor=HexColor('#4299e1'),
            borderWidth=2,
            borderPadding=10,
            spaceAfter=12,
            spaceBefore=6,
            textColor=HexColor('#2c5282'),
            leftIndent=0,
            rightIndent=0
        )
        
        self.alert_success_style = ParagraphStyle(
            'AlertSuccess',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=HexColor('#f0fff4'),
            borderColor=HexColor('#48bb78'),
            borderWidth=2,
            borderPadding=10,
            spaceAfter=12,
            spaceBefore=6,
            textColor=HexColor('#22543d'),
            leftIndent=0,
            rightIndent=0
        )
        
        # Status badge styles
        self.status_not_ready_style = ParagraphStyle(
            'StatusNotReady',
            parent=self.styles['Normal'],
            fontSize=14,
            fontName='Helvetica-Bold',
            backColor=HexColor('#fed7d7'),
            borderColor=HexColor('#e53e3e'),
            borderWidth=2,
            borderPadding=8,
            textColor=HexColor('#742a2a'),
            alignment=TA_CENTER,
            spaceAfter=20,
            spaceBefore=10
        )
        
        self.status_ready_style = ParagraphStyle(
            'StatusReady',
            parent=self.styles['Normal'],
            fontSize=14,
            fontName='Helvetica-Bold',
            backColor=HexColor('#f0fff4'),
            borderColor=HexColor('#48bb78'),
            borderWidth=2,
            borderPadding=8,
            textColor=HexColor('#22543d'),
            alignment=TA_CENTER,
            spaceAfter=20,
            spaceBefore=10
        )
    
    def generate_pdf(self, markdown_content: str, title: str = "Data Readiness Assessment Report") -> bytes:
        """Generate PDF from markdown content"""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=50,
            leftMargin=50,
            topMargin=60,
            bottomMargin=60
        )
        
        # Parse markdown and build content
        content = self._parse_markdown_to_reportlab(markdown_content, title)
        
        # Build PDF
        doc.build(content)
        buffer.seek(0)
        return buffer.read()
    
    def _clean_text(self, text: str) -> str:
        """Clean and escape text for ReportLab"""
        if not text:
            return ""
        
        # Remove problematic characters and fix common issues
        text = str(text)
        text = text.replace('\\n', '\n')
        text = text.replace('\\\\', '\\')
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        text = text.replace('<think>', '')
        
        # Fix common markdown to HTML issues
        text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
        text = re.sub(r'\*(.*?)\*', r'<i>\1</i>', text)
        text = re.sub(r'`(.*?)`', r'<font name="Courier" color="#e53e3e" size="10">\1</font>', text)
        
        return text
    
    def _parse_table(self, table_lines: List[str]) -> Table:
        """Parse markdown table and return ReportLab Table with improved styling"""
        if len(table_lines) < 2:
            return None
            
        # Parse header
        header_line = table_lines[0]
        headers = [cell.strip() for cell in header_line.split('|')[1:-1]]
        
        # Skip separator line (table_lines[1])
        
        # Parse data rows
        rows = [headers]
        for line in table_lines[2:]:
            if line.strip():
                row_data = [cell.strip() for cell in line.split('|')[1:-1]]
                # Ensure row has same number of columns as header
                while len(row_data) < len(headers):
                    row_data.append('')
                rows.append(row_data[:len(headers)])
        
        # Create table data with proper formatting
        table_data = []
        for i, row in enumerate(rows):
            formatted_row = []
            for j, cell in enumerate(row):
                if i == 0:  # Header row
                    formatted_row.append(Paragraph(self._clean_text(cell), self.table_header_style))
                else:  # Data row
                    # Apply special styling for status columns
                    if 'Status' in headers[j] and cell.lower() in ['missing', 'not ready']:
                        cell_style = ParagraphStyle(
                            'TableCellStatus',
                            parent=self.table_cell_style,
                            textColor=HexColor('#e53e3e'),
                            fontName='Helvetica-Bold'
                        )
                    elif 'Status' in headers[j] and cell.lower() in ['ready', 'complete']:
                        cell_style = ParagraphStyle(
                            'TableCellStatus',
                            parent=self.table_cell_style,
                            textColor=HexColor('#48bb78'),
                            fontName='Helvetica-Bold'
                        )
                    else:
                        cell_style = self.table_cell_style
                    
                    formatted_row.append(Paragraph(self._clean_text(cell), cell_style))
            table_data.append(formatted_row)
        
        # Calculate column widths dynamically
        col_count = len(headers) if headers else 1
        available_width = 7 * inch  # Available page width minus margins
        col_width = available_width / col_count
        
        # Create table with proper column widths
        table = Table(table_data, colWidths=[col_width] * col_count)
        
        # Enhanced table styling
        table_style = TableStyle([
            # Header row styling
            ('BACKGROUND', (0, 0), (-1, 0), HexColor('#4a5568')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('TOPPADDING', (0, 0), (-1, 0), 12),
            
            # Data rows styling
            ('BACKGROUND', (0, 1), (-1, -1), colors.white),
            ('TEXTCOLOR', (0, 1), (-1, -1), HexColor('#2d3748')),
            ('ALIGN', (0, 1), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            
            # Grid styling
            ('GRID', (0, 0), (-1, -1), 1, HexColor('#cbd5e0')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, HexColor('#f7fafc')]),
            
            # Padding
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 1), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
        ])
        
        table.setStyle(table_style)
        return table
    
    def _extract_json_content(self, content: str) -> str:
        """Extract markdown content from JSON if present"""
        try:
            # Check if content is wrapped in JSON
            if content.strip().startswith('{') and '"generated_content"' in content:
                import json
                data = json.loads(content)
                return data.get('generated_content', content)
        except:
            pass
        return content
    
    def _detect_overall_status(self, line: str) -> str:
        """Detect the overall readiness status from the line"""
        line_lower = line.lower()
        if 'not ready' in line_lower:
            return 'not_ready'
        elif 'ready' in line_lower and 'not' not in line_lower:
            return 'ready'
        elif 'partial' in line_lower or 'incomplete' in line_lower:
            return 'warning'
        return None

    def _parse_markdown_to_reportlab(self, markdown_content: str, title: str) -> List:
        """Parse markdown content to ReportLab elements"""
        content = []
        # Extract actual markdown content from JSON wrapper if present
        markdown_content = self._extract_json_content(markdown_content)
        
        # Remove markdown code block wrapper if present
        if markdown_content.strip().startswith('```markdown'):
            markdown_content = markdown_content.strip()[11:]  # Remove ```markdown
        if markdown_content.strip().endswith('```'):
            markdown_content = markdown_content.strip()[:-3]  # Remove trailing ```
        

        # Add cover page
        content.append(Paragraph(title, self.title_style))
        content.append(Spacer(1, 20))
        
        # Add generation info
        timestamp = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        content.append(Paragraph(f"Generated on {timestamp}", self.subtitle_style))
        content.append(Spacer(1, 40))
        
        # Clean the markdown content
        cleaned_content = self._clean_text(markdown_content)
        
        # Split content into lines
        lines = cleaned_content.split('\n')
        
        in_code_block = False
        code_block_content = []
        in_list = False
        list_counter = 0
        in_table = False
        table_lines = []
        
        i = 0
        while i < len(lines):
            line = lines[i]
            original_line = line
            line = line.strip()
            
            if not line:
                if not in_code_block and not in_table:
                    content.append(Spacer(1, 8))
                    in_list = False
                    list_counter = 0
                i += 1
                continue
            
            # Handle code blocks
            if line.startswith('```'):
                if in_code_block:
                    # End code block
                    if code_block_content:
                        code_text = '\n'.join(code_block_content)
                        code_para = Paragraph(
                            f'<font name="Courier" size="9" color="#2d3748">{self._clean_text(code_text)}</font>',
                            ParagraphStyle('CodeBlock', 
                                         parent=self.styles['Normal'],
                                         backColor=HexColor('#f7fafc'),
                                         borderColor=HexColor('#cbd5e0'),
                                         borderWidth=1,
                                         borderPadding=10,
                                         leftIndent=0,
                                         rightIndent=0)
                        )
                        content.append(code_para)
                        content.append(Spacer(1, 10))
                    code_block_content = []
                    in_code_block = False
                else:
                    # Start code block
                    in_code_block = True
                i += 1
                continue
            
            if in_code_block:
                code_block_content.append(line)
                i += 1
                continue
             # Handle tables
            if '|' in line and not in_table:
                # Start of table
                in_table = True
                table_lines = [line]
                i += 1
                continue
            elif in_table:
                if '|' in line:
                    table_lines.append(line)
                    i += 1
                    continue
                else:
                    # End of table
                    table = self._parse_table(table_lines)
                    if table:
                        content.append(KeepTogether([table]))
                        content.append(Spacer(1, 15))
                    in_table = False
                    table_lines = []
                    
            # Handle overall status line (with percentage and status)
            if '**Overall Readiness:**' in line or 'Overall Readiness:' in line:
                # Extract the percentage and status
                status = self._detect_overall_status(line)
                clean_line = self._clean_text(line)
                if status == 'not_ready':
                    content.append(Paragraph(clean_line, self.status_not_ready_style))
                elif status == 'ready':
                    content.append(Paragraph(clean_line, self.status_ready_style))
                else:
                    content.append(Paragraph(clean_line, self.alert_warning_style))
            
            # Handle headings
            elif line.startswith('# '):
                text = line[2:].strip()
                # Remove any remaining markdown formatting
                text = re.sub(r'^#+\s*', '', text)
                content.append(Paragraph(text, self.h1_style))
                in_list = False
                list_counter = 0
                
            elif line.startswith('## '):
                text = line[3:].strip()
                text = re.sub(r'^#+\s*', '', text)
                content.append(Paragraph(text, self.h2_style))
                in_list = False
                list_counter = 0
                
            elif line.startswith('### '):
                text = line[4:].strip()
                text = re.sub(r'^#+\s*', '', text)
                content.append(Paragraph(text, self.h3_style))
                in_list = False
                list_counter = 0
            
            # Handle special alert content
            elif ('**recommendation' in line.lower() or '**action' in line.lower() or
                  'recommendation:' in line.lower() or 'action:' in line.lower()):
                text = line.replace('**', '').replace('*', '').strip()
                content.append(Paragraph(f"💡 <b>Recommendation:</b> {text}", self.alert_info_style))
                in_list = False
                
            elif ('not ready' in line.lower() or 'critical' in line.lower() or 'missing' in line.lower()) and '**' in line:
                text = line.replace('**', '').replace('*', '').strip()
                content.append(Paragraph(f"❌ {text}", self.alert_critical_style))
                in_list = False
                
            elif ('warning' in line.lower() or 'gap' in line.lower() or 'insufficient' in line.lower()) and '**' in line:
                text = line.replace('**', '').replace('*', '').strip()
                content.append(Paragraph(f"⚠️ {text}", self.alert_warning_style))
                in_list = False
                
            elif ('ready' in line.lower() or 'complete' in line.lower() or 'success' in line.lower()) and '**' in line:
                text = line.replace('**', '').replace('*', '').strip()
                content.append(Paragraph(f"✅ {text}", self.alert_success_style))
                in_list = False
            
            # Handle lists
            elif line.startswith('- ') or line.startswith('* '):
                text = line[2:].strip()
                content.append(Paragraph(f"• {text}", self.bullet_style))
                in_list = True
                
            elif re.match(r'^\d+\.', line):
                if not in_list:
                    list_counter = 0
                    in_list = True
                match = re.match(r'^(\d+)\.\s*(.*)', line)
                if match:
                    list_counter = int(match.group(1))
                    text = match.group(2)
                    content.append(Paragraph(f"{list_counter}. {text}", self.bullet_style))
            
            # Handle regular paragraphs
            else:
                if line.strip() and not line.startswith('---'): 
                    content.append(Paragraph(line, self.body_style))
                    in_list = False
            
            i += 1
        
        # Handle any remaining table
        if in_table and table_lines:
            table = self._parse_table(table_lines)
            if table:
                content.append(KeepTogether([table]))
                content.append(Spacer(1, 15))
        
        # Handle any remaining code block
        if in_code_block and code_block_content:
            code_text = '\n'.join(code_block_content)
            code_para = Paragraph(
                f'<font name="Courier" size="9">{self._clean_text(code_text)}</font>',
                ParagraphStyle('CodeBlock', 
                             parent=self.styles['Normal'],
                             backColor=HexColor('#f7fafc'),
                             borderColor=HexColor('#cbd5e0'),
                             borderWidth=1,
                             borderPadding=10)
            )
            content.append(code_para)
        return content

async def save_uploaded_file(upload_file: UploadFile, temp_dir: str = None) -> str:
    """Save uploaded file to temporary location"""
    if temp_dir is None:
        temp_dir = tempfile.mkdtemp()
    
    file_path = os.path.join(temp_dir, upload_file.filename)
    
    try:
        content = await upload_file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        return file_path
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving file: {str(e)}"
        )