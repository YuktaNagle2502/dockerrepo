from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Response,Request
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime
import json
import os
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
# Import database configuration and auth dependencies
from database import get_db
from models.models import User, Project
from models.models import PreWorkshopSession, QuestionnaireResponse, GeneratedUseCase
from models.pydantic_models import StandardResponse, standard_response
from services.pre_workshop_service import PreWorkshopService
from utils.pre_workshop_utils import (
    PreWorkshopSessionCreate,
    PreWorkshopSessionResponse,
    PreWorkshopSessionDetail,
    QuestionnaireResponseResponse,
    GeneratedUseCaseResponse,
    ExcelUploadResponse,
    ReportRequest,
    BulkUseCaseSelection,
    CustomUseCaseCreate,
    CustomUseCaseUpdate 
)

# Router
router = APIRouter(prefix="/pre-workshop", tags=["Pre-Workshop"])

async def get_current_user(keycloak_payload: dict,  db: Session = Depends(get_db)) -> User:
    """Get the current user from the Keycloak token payload"""
    # Extract email from Keycloak token payload
    email = keycloak_payload.get("email") or keycloak_payload.get("preferred_username")
    if not email:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload: email not found")
    # Query the database for the user
    user = db.query(User).filter(User.email == email, User.is_active == True).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found or inactive")
    return user

@router.post("/sessions", response_model=StandardResponse)
async def create_pre_workshop_session(
    session_data: PreWorkshopSessionCreate,
    request: Request,
    db: Session = Depends(get_db)
):
    """Create a new pre-workshop session"""
    try:
        service = PreWorkshopService(db)
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        create_session=service.create_session(session_data, current_user)
        return standard_response(
            status_code=200,
            success=True,
            message="Pre-workshop sessions created successfully",
            data=create_session
        )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to create pre-workshop session",
            error=str(e)
        )

@router.get("/sessions", response_model=StandardResponse)
async def get_pre_workshop_sessions(
    project_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """Get all pre-workshop sessions for a project"""
    try:
        service = PreWorkshopService(db)
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        sessions_by_project= service.get_sessions_by_project(project_id, current_user)
        return standard_response(
            status_code=200,
            success=True,
            message="Pre-workshop sessions retrieved successfully",
            data=sessions_by_project
        )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to retrieve pre-workshop sessions",
            error=str(e)
        )

@router.get("/sessions/{session_id}", response_model=StandardResponse)
async def get_pre_workshop_session(
    session_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """Get detailed pre-workshop session with responses and use cases"""
    try:
        service = PreWorkshopService(db)
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        session_detail = service.get_session_detail(session_id, current_user)
        return standard_response(
            status_code=200,
            success=True,
            message="Pre-workshop session retrieved successfully",
            data=session_detail
        )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to retrieve pre-workshop session",
            error=str(e)
        )

@router.post("/sessions/{session_id}/upload-questionnaire", response_model=StandardResponse)
async def upload_questionnaire_excel(
    session_id: int,
    request: Request,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload Excel file with questionnaire responses (Sheet1)"""
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        service = PreWorkshopService(db)
        upload_questionnaire= await service.upload_questionnaire(session_id, file, current_user)
        return standard_response(
            status_code=200,
            success=True,
            message="Upload questionnaire successfully",
            data=upload_questionnaire
        )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to upload questionnaire",
            error=str(e)
        )

@router.post("/sessions/{session_id}/generate-use-cases")
async def generate_use_cases(
    session_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """Generate AWS GenAI use cases from uploaded questionnaire responses"""
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        service = PreWorkshopService(db)
        generate_use_cases = await service.generate_use_cases(session_id, current_user)
        return standard_response(
            status_code=200,
            success=True,
            message="Use-Case generated successfully",
            data=generate_use_cases
        )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to generate use cases",
            error=str(e)
        )

@router.post("/sessions/{session_id}/generate-report")
async def generate_report(
    session_id: int,
    report_request: ReportRequest,
    request: Request,
    db: Session = Depends(get_db)
):
    """Generate and download pre-workshop report"""
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        service = PreWorkshopService(db)
        return await service.generate_report(session_id, report_request, current_user)
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to download pre-workshop report",
            error=str(e)
        )

@router.put("/sessions/{session_id}/use-cases/select")
async def select_use_cases(
    session_id: int,
    selection_data: BulkUseCaseSelection,
    request: Request,
    db: Session = Depends(get_db)
):
    """Select or deselect multiple use cases at once"""
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        service = PreWorkshopService(db)
        use_cases = service.select_use_cases(session_id, selection_data, current_user)
        return standard_response(
            status_code=200,
            success=True,
            message=use_cases['message'],
            data=use_cases
        )
    except Exception as e:
        return standard_response(   
            status_code=500,
            success=False,
            message="Failed to select or deselect use case",
            error=str(e)
        )

@router.get("/sessions/{session_id}/use-cases/selected")
async def get_selected_use_cases(
    session_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """Get all selected use cases for a session"""
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        service = PreWorkshopService(db)
        selected_use_cases = service.get_selected_use_cases(session_id, current_user)
        return standard_response(
            status_code=200,
            success=True,
            message="Use-case selected successfully",
            data=selected_use_cases
        )
    except Exception as e:
        return standard_response(   
            status_code=500,
            success=False,
            message="Failed to retrive selected use case",
            error=str(e)
        )

@router.delete("/sessions/{session_id}")
async def delete_pre_workshop_session(
    session_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """Delete a pre-workshop session"""
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        service = PreWorkshopService(db)
        deleted_session= service.delete_session(session_id, current_user)
        return standard_response(
            status_code=200,
            success=True,
            message="Session deleted successfully",
            data=deleted_session
        )
    except Exception as e:
        return standard_response(   
            status_code=500,
            success=False,
            message="Failed to delete session",
            error=str(e)
        )

@router.post("/sessions/{session_id}/use-cases", response_model=StandardResponse)
async def create_custom_use_case(
    session_id: int,
    use_case_data: CustomUseCaseCreate,
    request: Request,
    db: Session = Depends(get_db)
):
    """Create a new custom use case for a session"""
    try:
        service = PreWorkshopService(db)
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        new_use_case = service.create_custom_use_case(session_id, use_case_data, current_user)
        return standard_response(
            status_code=201,
            success=True,
            message="Custom use case created successfully",
            data=new_use_case
        )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to create new use case",
            error=str(e)
        )

@router.put("/sessions/{session_id}/use-cases/{use_case_id}", response_model=StandardResponse)
async def update_use_case(
    session_id: int,
    use_case_id: int,
    use_case_data: CustomUseCaseUpdate,
    request: Request,
    db: Session = Depends(get_db)
):
    """Update an existing use case"""
    try:
        service = PreWorkshopService(db)
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        updated_use_case = service.update_use_case(session_id, use_case_id, use_case_data, current_user)
        return standard_response(
            status_code=200,
            success=True,
            message="Use case updated successfully",
            data=updated_use_case
        )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to update use case",
            error=str(e)
        )

@router.delete("/sessions/{session_id}/use-cases/{use_case_id}", response_model=StandardResponse)
async def delete_use_case(
    session_id: int,
    use_case_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """Delete a specific use case"""
    try:
        service = PreWorkshopService(db)
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        deleted_use_case = service.delete_use_case(session_id, use_case_id, current_user)
        return standard_response(
            status_code=200,
            success=True,
            message="Use case deleted successfully",
            data=deleted_use_case
        )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to delete use case",
            error=str(e)
        )
    
@router.get("/sessions/{session_id}/use-cases/{use_case_id}", response_model=StandardResponse)
async def get_use_case(
    session_id: int,
    use_case_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """Get a single use case by ID"""
    try:
        service = PreWorkshopService(db)
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        use_case = service.get_use_case(session_id, use_case_id, current_user)
        return standard_response(
            status_code=200,
            success=True,
            message="Use case retrieved successfully",
            data=use_case
        )
    except HTTPException as he:
        return standard_response(
            status_code=he.status_code,
            success=False,
            message="Failed to retrieve use case",
            error=he.detail
        )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to retrieve use case",
            error=str(e)
        )
    
@router.get("/use_case/{use_case_id}/statuses", response_model=StandardResponse)
async def get_use_case_statuses(use_case_id: int, db: Session = Depends(get_db)):
    try:
        # Query the specific use case by ID
        use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == use_case_id).first()
        
        if not use_case:
            raise HTTPException(status_code=404, detail="Use case not found")
        
        # Return the status fields
        use_case_status={
            "use_case_id":use_case.id,
            "data_readiness_status":use_case.data_readiness_status,
            "data_compliance_status":use_case.data_compliance_status,
            "ai_profiling_status":use_case.ai_profiling_status,
            'model_evaluation_status':use_case.model_evaluation_status,
            "sprint_planning_status":use_case.sprint_planning_status
            }
        return standard_response(
                status_code=200,
                success=True,
                message="Use case status retrieved successfully",
                data=use_case_status
            )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message=f"Error fetching statuses: {str(e)}",
            error=str(e)
        )
        