from fastapi import APIRouter, Depends, HTTPException, status, Response, Form, Request, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from datetime import datetime, date
from typing import Dict, Any, List, Optional
import json
from sqlalchemy.orm import Session
from database import get_db
from services.auth_service import AuthService
from models.models import (
    AIProfiling, DataCompliance, DataReadiness, ModelEvaluation, User, Project, GeneratedUseCase, PreWorkshopSession,
    SprintPlanning, SprintBreakdown, BudgetBreakdown, RiskAssessment,
    SelectedProjectPriority, SelectedTeamComposition, Developer,
    AssessmentReport
)
from services.sprint_planning_service import SprintPlanningRequest, SprintPlanningResponse, SprintPlanningGenerator
import logging
from models.pydantic_models import StandardResponse, standard_response
from utils.sprint_plan_utils import SprintPlanningGeneratorUtil
from utils.s3_utils import upload_file, generate_presigned_get_urls, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, BUCKET_NAME
import asyncio

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Router
router = APIRouter(prefix="/sprint-planning", tags=["Sprint Planning"])

async def save_assessment_report(content: bytes, filename: str, report_type: str, 
                               mimetype: str, usecase_id: int, assessment_stage: str, 
                               db: Session) -> int:
    """Save assessment report to S3 and database, return report ID"""
    if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
        raise HTTPException(status_code=500, detail="S3 credentials not configured")
    
    # Retrieve project name
    use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == usecase_id).first()
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    session = db.query(PreWorkshopSession).filter(PreWorkshopSession.id == use_case.session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    project = db.query(Project).filter(Project.id == session.project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    folder_prefix = f"sprint_planning/{project.name}/{usecase_id}"
    session_id = usecase_id
    session_name = "sprint"
    
    loop = asyncio.get_event_loop()
    s3_key, presigned_url, expires_at = await loop.run_in_executor(
        None,
        lambda: upload_file(
            bucket_name=BUCKET_NAME,
            file_content=content,
            session_id=session_id,
            session_name=session_name,
            filename=filename,
            access_key=AWS_ACCESS_KEY_ID,
            secret_key=AWS_SECRET_ACCESS_KEY,
            region=AWS_REGION,
            folder_prefix=folder_prefix,
            expiration=604800  # 7 days
        )
    )
    
    report = AssessmentReport(
        usecase_id=usecase_id,
        assessment_stage=assessment_stage,
        report_type=report_type,
        report_mimetype=mimetype,
        report_filename=filename,
        report_path=s3_key
    )
    
    db.add(report)
    db.commit()
    db.refresh(report)
    
    return report.id

async def get_current_user(keycloak_payload: dict, db: Session = Depends(get_db)) -> User:
    """Get the current user from the Keycloak token payload"""
    email = keycloak_payload.get("email") or keycloak_payload.get("preferred_username")
    if not email:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload: email not found")
    user = db.query(User).filter(User.email == email, User.is_active == True).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found or inactive")
    return user

@router.post("/generate", response_model=StandardResponse)
async def generate_sprint_plan(
    request: Request,
    use_case_id: int = Form(...),
    project_type: str = Form(default="web application"),
    sprint_duration_weeks: int = Form(default=2),
    development_methodology: str = Form(default="Agile"),
    total_sprints: int = Form(default=4),
    team_size: int = Form(default=4),
    project_start_date: Optional[str] = Form(default=None),
    include_comprehensive_testing_phases: bool = Form(default=True),
    include_deployment_and_monitoring_setup: bool = Form(default=True),
    include_documentation_tasks: bool = Form(default=True),
    include_risk_assessment: bool = Form(default=True),
    include_budget_estimation: bool = Form(default=True),
    include_detailed_resource_allocation: bool = Form(default=True),
    include_dependency_mapping: bool = Form(default=True),
    include_milestone_tracking: bool = Form(default=True),
    generate_detailed_task_breakdown: bool = Form(default=True),
    project_priorities: List[str] = Form(default=["Quality", "Time to Market", "Cost Efficiency"]),
    team_composition: str = Form(...),
    db: Session = Depends(get_db)
):
    """
    Generate sprint planning document from use case
    """
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        try:
            team_composition: Dict[str, int] = json.loads(team_composition)
        except json.JSONDecodeError:
            return {"error": "Invalid team_composition JSON"}
        use_case = db.query(GeneratedUseCase).filter(
            GeneratedUseCase.id == use_case_id
        ).first()
        
        if not use_case:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error=f"No use case found with ID: {use_case_id}"
            )
        
        session = db.query(PreWorkshopSession).filter(
            PreWorkshopSession.id == use_case.session_id
        ).first()
        
        if not session:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error=f"No session found for use case ID: {use_case_id}"
            )

        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()

        if not project:
            return standard_response(
                status_code=status.HTTP_403_FORBIDDEN,
                success=False,
                message="Access denied to this use case",
                error="User does not have permission to access this use case"
            )
        
        existing_sprint_planning = db.query(SprintPlanning).filter(
            SprintPlanning.usecase_id == use_case_id
        ).first()
        
        if existing_sprint_planning:
            db.query(SprintBreakdown).filter(
                SprintBreakdown.sprint_planning_id == existing_sprint_planning.id
            ).delete()
            db.query(BudgetBreakdown).filter(
                BudgetBreakdown.sprint_planning_id == existing_sprint_planning.id
            ).delete()
            db.query(RiskAssessment).filter(
                RiskAssessment.sprint_planning_id == existing_sprint_planning.id
            ).delete()
            db.query(SelectedProjectPriority).filter(
                SelectedProjectPriority.sprint_planning_id == existing_sprint_planning.id
            ).delete()
            db.query(SelectedTeamComposition).filter(
                SelectedTeamComposition.sprint_planning_id == existing_sprint_planning.id
            ).delete()
            db.delete(existing_sprint_planning)
            db.commit()
        
        use_case_data = {
            'title': use_case.title,
            'description': use_case.description,
            'business_category': use_case.business_category,
            'primary_genai_capability': use_case.primary_genai_capability,
            'aws_services': use_case.aws_services,
            'complexity': use_case.complexity,
            'estimated_effort': use_case.estimated_effort,
            'success_metrics': use_case.success_metrics,
            'dependencies': use_case.dependencies,
            'risks': use_case.risks,
            'cost_estimate': use_case.cost_estimate,
            'roi_potential': use_case.roi_potential
        }
        
        generator = SprintPlanningGenerator()
        sprint_content = await generator.generate_sprint_content(use_case_data, project_type)
        
        sprint_plan = sprint_content.get('sprint_plan', {})
        budget = sprint_content.get('budget_estimation', {})
        
        start_date = None
        if project_start_date:
            try:
                start_date = datetime.strptime(project_start_date, "%Y-%m-%d").date()
            except ValueError:
                start_date = date.today()
        else:
            start_date = date.today()
        
        sprint_planning = SprintPlanning(
            usecase_id=use_case_id,
            project_type=project_type,
            sprint_duration_weeks=sprint_duration_weeks,
            development_methodology=development_methodology,
            total_sprints=total_sprints,
            team_size=team_size,
            project_start_date=start_date,
            include_comprehensive_testing_phases=include_comprehensive_testing_phases,
            include_deployment_and_monitoring_setup=include_deployment_and_monitoring_setup,
            include_documentation_tasks=include_documentation_tasks,
            include_risk_assessment=include_risk_assessment,
            include_budget_estimation=include_budget_estimation,
            include_detailed_resource_allocation=include_detailed_resource_allocation,
            include_dependency_mapping=include_dependency_mapping,
            include_milestone_tracking=include_milestone_tracking,
            generate_detailed_task_breakdown=generate_detailed_task_breakdown,
            total_duration_weeks=total_sprints * sprint_duration_weeks,
            estimated_cost=budget.get('total_poc_cost', 'TBD'),
            generated_content=sprint_content
        )
        use_case.sprint_planning_status = "Completed"
        db.add(sprint_planning)
        db.commit()
        db.refresh(sprint_planning)
        
        sprints = sprint_plan.get('sprints', [])
        for sprint in sprints:
            sprint_breakdown = SprintBreakdown(
                sprint_planning_id=sprint_planning.id,
                sprint_number=sprint.get('sprint_number', 1),
                goals_md=json.dumps(sprint.get('goals', [])),
                tasks_md=json.dumps(sprint.get('tasks', [])),
                deliverables_md=json.dumps(sprint.get('deliverables', [])),
                sprint_weeks_duration=sprint_duration_weeks,
                total_tasks_count=len(sprint.get('tasks', [])),
                deliverables_count=len(sprint.get('deliverables', [])),
                total_hours=sum([int(task.get('effort', '0 hours').split()[0]) for task in sprint.get('tasks', [])])
            )
            db.add(sprint_breakdown)
        
        if include_budget_estimation and 'budget_estimation' in sprint_content:
            budget_items = {
                'Development Cost': budget.get('development_cost', 'TBD'),
                'AWS Infrastructure': budget.get('aws_infrastructure', 'TBD'),
                'Third-party Services': budget.get('third_party_services', 'TBD'),
                'Total POC Cost': budget.get('total_poc_cost', 'TBD')
            }
            
            for category, amount in budget_items.items():
                budget_breakdown = BudgetBreakdown(
                    sprint_planning_id=sprint_planning.id,
                    category=category,
                    amount=amount
                )
                db.add(budget_breakdown)
        
        if include_risk_assessment and 'risks_and_mitigation' in sprint_content:
            risks = sprint_content.get('risks_and_mitigation', [])
            for risk in risks:
                risk_assessment = RiskAssessment(
                    sprint_planning_id=sprint_planning.id,
                    risk_title=risk.get('risk', 'Unknown Risk'),
                    impact=risk.get('impact', 'Medium'),
                    mitigation=risk.get('mitigation', 'TBD')
                )
                db.add(risk_assessment)
        print("project_priorities:",project_priorities)
        for priority in project_priorities:
            selected_priority = SelectedProjectPriority(
                sprint_planning_id=sprint_planning.id,
                priority_title=priority
            )
            db.add(selected_priority)
        
        if team_composition is None:
            team_composition = {
                "Full-Stack Developer": 2,
                "DevOps Engineer": 1,
                "QA Engineer": 1
            }
        
        for role, quantity in team_composition.items():
            selected_team = SelectedTeamComposition(
                sprint_planning_id=sprint_planning.id,
                resource_title=role,
                resource_quantity=quantity
            )
            db.add(selected_team)
        
        db.commit()
        
        # Prepare the response data
        sprint_planning_data = {
            "sprint_planning_id": sprint_planning.id,
            "use_case_id": use_case_id,
            "project_type": project_type,
            "generated_content": sprint_content,
            "total_sprints": total_sprints,
            "estimated_duration": f"{total_sprints * sprint_duration_weeks} weeks",
            "estimated_cost": sprint_planning.estimated_cost,
            "generated_at": sprint_planning.created_at,
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Sprint planning generated successfully",
            data=sprint_planning_data
        )
        
    except HTTPException as he:
        db.rollback()
        logger.error("Generation fail")
        return standard_response(
            status_code=he.status_code,
            success=False,
            message=he.detail,
            error=str(he.detail)
        )
    except Exception as e:
        db.rollback()
        logger.error(f"Error generating sprint plan: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Internal server error while generating sprint plan",
            error=str(e)
        )

@router.post("/generate-pdf")
async def generate_sprint_pdf(
    sprint_planning_id: int = Query(..., description="Sprint Planning ID"),
    title: str = Form(default="Sprint Planning Document"),
    include_charts: bool = Form(default=True),
    db: Session = Depends(get_db)
):
    """
    Generate PDF report from existing sprint planning and store in S3
    """
    try:
        logger.info(f"Starting PDF generation for sprint_planning_id={sprint_planning_id}")
        
        sprint_plan = db.query(SprintPlanning).filter(
            SprintPlanning.id == sprint_planning_id
        ).first()
        
        if not sprint_plan:
            logger.error(f"Sprint planning not found for id={sprint_planning_id}")
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Sprint planning not found",
                error=f"Sprint planning not found with ID: {sprint_planning_id}"
            )
            
        # Validate generated_content
        if not sprint_plan.generated_content or not isinstance(sprint_plan.generated_content, dict) or not sprint_plan.generated_content:
            logger.error(f"No valid content available for sprint_planning_id={sprint_planning_id}")
            return standard_response(
                status_code=status.HTTP_400_BAD_REQUEST,
                success=False,
                message="No valid content available for PDF generation",
                error={"type": "ValidationError", "detail": "No valid content available for PDF generation"}
            )

        # Retrieve project name
        use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == sprint_plan.usecase_id).first()
        if not use_case:
            logger.error(f"Use case not found for sprint_planning_id={sprint_planning_id}")
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error=f"No use case found for sprint planning ID: {sprint_planning_id}"
            )
        session = db.query(PreWorkshopSession).filter(PreWorkshopSession.id == use_case.session_id).first()
        if not session:
            logger.error(f"Session not found for use case ID: {sprint_plan.usecase_id}")
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error=f"No session found for use case ID: {sprint_plan.usecase_id}"
            )
        project = db.query(Project).filter(Project.id == session.project_id).first()
        if not project:
            logger.error(f"Project not found for session ID: {use_case.session_id}")
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Project not found",
                error=f"No project found for session ID: {use_case.session_id}"
            )

        logger.info(f"Retrieved sprint planning: id={sprint_plan.id}, usecase_id={sprint_plan.usecase_id}, generated_pdf_id={sprint_plan.generated_pdf_report_id}")
        
        if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
            logger.error("S3 credentials not configured")
            return standard_response(
                status_code=500,
                success=False,
                message="S3 credentials not configured",
                error={"type": "ConfigurationError", "detail": "S3 credentials not configured"}
            )
        
        logger.info(f"S3 configuration: bucket={BUCKET_NAME}, region={AWS_REGION}")
        
        pdf_report = None
        presigned_url = None
        expires_at = None
        
        if sprint_plan.generated_pdf_report_id:
            logger.info(f"Checking existing report with id={sprint_plan.generated_pdf_report_id}")
            pdf_report = db.query(AssessmentReport).filter(
                AssessmentReport.id == sprint_plan.generated_pdf_report_id,
                AssessmentReport.assessment_stage == "sprint_planning",
                AssessmentReport.report_type == "pdf"
            ).first()
            logger.info(f"Existing report found: {pdf_report.id if pdf_report else 'None'}, path={pdf_report.report_path if pdf_report else 'None'}")
        
        if pdf_report:
            logger.info(f"Refreshing presigned URL for existing report {pdf_report.id}")
            result = generate_presigned_get_urls(
                bucket_name=BUCKET_NAME,
                object_paths=[pdf_report.report_path],
                access_key=AWS_ACCESS_KEY_ID,
                secret_key=AWS_SECRET_ACCESS_KEY,
                region=AWS_REGION,
                expiration=604800  # 7 days
            )[0]
            if result['status'] == 'success':
                presigned_url = result['url']
                expires_at = result['expires_at']
                logger.info(f"Presigned URL generated: {presigned_url}, expires at {expires_at}")
            else:
                logger.error(f"Failed to generate presigned URL: {result.get('error', 'Unknown error')}")
                return standard_response(
                    status_code=500,
                    success=False,
                    message="Failed to generate presigned URL for existing report",
                    error={"type": "S3Error", "detail": result.get('error', 'Unknown error')}
                )
        else:
            logger.info(f"Generating new PDF for sprint_planning_id={sprint_planning_id}")
            sprint_content = sprint_plan.generated_content
            generator_util = SprintPlanningGeneratorUtil()
            pdf_data = generator_util.generate_pdf_report(sprint_content, include_charts=include_charts)
            logger.info(f"PDF content generated, size={len(pdf_data)} bytes")
            
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"sprint_planning_{sprint_planning_id}_{timestamp}.pdf"
            folder_prefix = f"sprint_planning/{project.name}/{sprint_plan.usecase_id}"
            session_id = sprint_planning_id
            session_name = "sprint"
            
            logger.info(f"Uploading PDF to S3: bucket={BUCKET_NAME}, folder_prefix={folder_prefix}, filename={filename}")
            try:
                s3_key, presigned_url, expires_at = upload_file(
                    bucket_name=BUCKET_NAME,
                    file_content=pdf_data,
                    session_id=session_id,
                    session_name=session_name,
                    filename=filename,
                    access_key=AWS_ACCESS_KEY_ID,
                    secret_key=AWS_SECRET_ACCESS_KEY,
                    region=AWS_REGION,
                    folder_prefix=folder_prefix,
                    expiration=604800  # 7 days
                )
                logger.info(f"Successfully uploaded PDF to S3: s3_key={s3_key}, presigned_url={presigned_url}, expires_at={expires_at}")
            except Exception as e:
                logger.error(f"Failed to upload PDF to S3: {str(e)}")
                return standard_response(
                    status_code=500,
                    success=False,
                    message="Failed to upload PDF to S3",
                    error=str(e)
                )
            
            pdf_report = AssessmentReport(
                usecase_id=sprint_plan.usecase_id,
                assessment_stage="sprint_planning",
                report_type="pdf",
                report_mimetype="application/pdf",
                report_filename=filename,
                report_path=s3_key
            )
            db.add(pdf_report)
            db.commit()
            logger.info(f"AssessmentReport created with id={pdf_report.id}, path={s3_key}")
            sprint_plan.generated_pdf_report_id = pdf_report.id
            
            db.commit()
            logger.info(f"Updated sprint_planning_id={sprint_planning_id} with generated_pdf_report_id={pdf_report.id}")
        
        response_data = {
            "presigned_url": presigned_url,
            "expires_at": expires_at.isoformat() if expires_at else None,
            "report_path": pdf_report.report_path if pdf_report else s3_key
        }
        logger.info(f"Returning response: presigned_url={presigned_url}, expires_at={expires_at}, report_path={response_data['report_path']}")
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="PDF report generated successfully",
            data=response_data
        )
        
    except Exception as e:
        logger.error(f"Error generating PDF: {str(e)}", exc_info=True)
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error generating PDF report",
            error=str(e)
        )

@router.get("/templates", response_model=StandardResponse)
async def get_sprint_templates(db: Session = Depends(get_db)):
    """
    Get available sprint planning templates and developers
    """
    try:
        developers = db.query(Developer).all()
        
        templates = {
            "web_application": {
                "name": "Web Application",
                "description": "Full-stack web application development",
                "default_sprints": 4,
                "default_duration": "2 weeks",
                "typical_team_size": 4,
                "key_technologies": ["React", "Node.js", "AWS", "Database"]
            },
            "mobile_app": {
                "name": "Mobile Application",
                "description": "Native or cross-platform mobile app development",
                "default_sprints": 6,
                "default_duration": "2 weeks",
                "typical_team_size": 5,
                "key_technologies": ["React Native", "Flutter", "iOS", "Android"]
            },
            "data_platform": {
                "name": "Data Platform",
                "description": "Big data processing and analytics platform",
                "default_sprints": 8,
                "default_duration": "2 weeks",
                "typical_team_size": 6,
                "key_technologies": ["AWS EMR", "Spark", "Kafka", "ML Services"]
            },
            "ai_ml_solution": {
                "name": "AI/ML Solution",
                "description": "Machine learning and AI-powered application",
                "default_sprints": 6,
                "default_duration": "2 weeks",
                "typical_team_size": 4,
                "key_technologies": ["SageMaker", "Lambda", "API Gateway", "S3"]
            },
            "microservices": {
                "name": "Microservices Architecture",
                "description": "Microservices-based distributed system",
                "default_sprints": 10,
                "default_duration": "2 weeks",
                "typical_team_size": 8,
                "key_technologies": ["Docker", "Kubernetes", "API Gateway", "Service Mesh"]
            }
        }
        
        developers_data = [
            {
                "id": dev.id,
                "title": dev.developer_title,
                "tech_stack": dev.developer_tech_stack.split(",") if dev.developer_tech_stack else []
            }
            for dev in developers
        ]
        
        templates_data = {
            "templates": templates,
            "total_templates": len(templates),
            "developers": developers_data,
            "total_developers": len(developers_data)
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Sprint planning templates retrieved successfully",
            data=templates_data
        )
        
    except Exception as e:
        logger.error(f"Error retrieving sprint templates: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error retrieving sprint planning templates",
            error=str(e)
        )

@router.get("/get_sprint_planning/{use_case_id}", response_model=StandardResponse)
async def get_sprint_planning_details(use_case_id: int, db: Session = Depends(get_db)):
    try:
        # Retrieve the sprint planning
        sprint_planning = db.query(SprintPlanning).filter(
            SprintPlanning.usecase_id == use_case_id
        ).first()

        if not sprint_planning:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Sprint planning not found",
                error=f"No sprint planning found with use case ID: {use_case_id}"
            )

        # Get associated report path
        report_path = None
        if sprint_planning.generated_pdf_report_id:
            report = db.query(AssessmentReport).filter(
                AssessmentReport.id == sprint_planning.generated_pdf_report_id
            ).first()
            if report:
                report_path = report.report_path

        # Get project priorities
        priorities = db.query(SelectedProjectPriority).filter(
            SelectedProjectPriority.sprint_planning_id == sprint_planning.id
        ).all()
        project_priorities = [p.priority_title for p in priorities]

        # Get team composition
        team_members = db.query(SelectedTeamComposition).filter(
            SelectedTeamComposition.sprint_planning_id == sprint_planning.id
        ).all()
        team_composition = {
            member.resource_title: member.resource_quantity for member in team_members
        }

        response_data = {
            "sprint_planning_id": sprint_planning.id,
            "use_case_id": sprint_planning.usecase_id,
            "project_type": sprint_planning.project_type,
            "generated_content": sprint_planning.generated_content,
            "total_sprints": sprint_planning.total_sprints,
            "estimated_duration": f"{sprint_planning.total_duration_weeks} weeks",
            "estimated_cost": sprint_planning.estimated_cost,
            "generated_at": sprint_planning.created_at,
            "report_path": report_path,
            "sprint_duration_weeks": sprint_planning.sprint_duration_weeks,
            "team_size": sprint_planning.team_size,
            "include_comprehensive_testing_phases": sprint_planning.include_comprehensive_testing_phases,
            "include_deployment_and_monitoring_setup": sprint_planning.include_deployment_and_monitoring_setup,
            "include_documentation_tasks": sprint_planning.include_documentation_tasks,
            "include_risk_assessment": sprint_planning.include_risk_assessment,
            "include_budget_estimation": sprint_planning.include_budget_estimation,
            "include_detailed_resource_allocation": sprint_planning.include_detailed_resource_allocation,
            "include_dependency_mapping": sprint_planning.include_dependency_mapping,
            "include_milestone_tracking": sprint_planning.include_milestone_tracking,
            "generate_detailed_task_breakdown": sprint_planning.generate_detailed_task_breakdown,
            "team_composition": team_composition,
            "project_priorities": project_priorities,
            "methodology":sprint_planning.development_methodology,
            "start_date":sprint_planning.project_start_date
        }

        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Sprint planning data retrieved successfully",
            data=response_data
        )

    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error retrieving sprint planning data",
            error=str(e)
        )
        

@router.get("/overall_scores/{use_case_id}")
def get_overall_scores(use_case_id: int, db: Session = Depends(get_db)):
    # Verify use case exists
    use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == use_case_id).first()
    if not use_case:
        # raise HTTPException(status_code=404, detail="Use case not found")
        return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error=f"Use case not found: {use_case_id}"
            )
    
    # Fetch related score entries (assuming one record per use case)
    data_compliance = db.query(DataCompliance).filter(DataCompliance.usecase_id == use_case_id).first()
    data_readiness = db.query(DataReadiness).filter(DataReadiness.usecase_id == use_case_id).first()
    model_evaluation = db.query(ModelEvaluation).filter(ModelEvaluation.usecase_id == use_case_id).first()
    ai_profiling = db.query(AIProfiling).filter(AIProfiling.usecase_id == use_case_id).first()
    
    response = {
        "usecase_id": use_case_id,
        "readinessScore": float(data_readiness.readiness_score_count) if data_readiness and data_readiness.readiness_score_count is not None else None,
        "complianceScore": float(data_compliance.overall_score) if data_compliance and data_compliance.overall_score is not None else None,
        "profilingScore": float(ai_profiling.quality_score) if ai_profiling and ai_profiling.quality_score is not None else None,
        "modelEvaluationScore": float(model_evaluation.average_accuracy) if model_evaluation and model_evaluation.average_accuracy is not None else None,
    }
    return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Overall score fetched",
            data=response
        )