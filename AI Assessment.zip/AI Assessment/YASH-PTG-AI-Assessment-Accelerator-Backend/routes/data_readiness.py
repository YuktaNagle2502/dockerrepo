from fastapi import APIRouter, Depends, HTTPException, Query, status, UploadFile, File, Response, Form, Request
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from database import get_db
from models.models import User, Project, GeneratedUseCase, PreWorkshopSession, DataReadiness, AssessmentReport, DataReadinessDocument
from services.data_readiness_service import DataReadinessAnalyzerService
from utils.data_readiness_utils import DataReadinessAnalysisResponse, save_uploaded_file,FileProcessor
from utils.s3_utils import upload_file, generate_presigned_get_urls, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, BUCKET_NAME
from pydantic import BaseModel, Field, ConfigDict
from models.pydantic_models import StandardResponse, standard_response
import os
import json
import shutil
import tempfile
import asyncio
import boto3
import logging
from botocore.exceptions import ClientError

router = APIRouter(prefix="/data-readiness", tags=["Data Readiness"])
file_processor=FileProcessor()
async def get_current_user(keycloak_payload: dict, db: Session = Depends(get_db)) -> User:
    """Get the current user from the Keycloak token payload"""
   
    # Extract email from Keycloak token payload
    email = keycloak_payload.get("email") or keycloak_payload.get("preferred_username")
    if not email:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload: email not found")
    # Query the database for the user
    user = db.query(User).filter(User.email == email, User.is_active == True).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found or inactive")
    return user

# Get API key from environment
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    print("Warning: GROQ_API_KEY not found in environment variables")

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Store expiration timestamps in memory (key: report_id, value: expires_at)
url_expirations = {}

async def get_current_user(keycloak_payload: dict, db: Session = Depends(get_db)) -> User:
    """Get the current user from the Keycloak token payload"""
    email = keycloak_payload.get("email") or keycloak_payload.get("preferred_username")
    if not email:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload: email not found")
    user = db.query(User).filter(User.email == email, User.is_active == True).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found or inactive")
    return user

def _refresh_report_presigned_url(report: AssessmentReport) -> tuple[str, datetime]:
    """Regenerate presigned URL if expired or about to expire"""
    report_id = report.id
    s3_key = report.report_path
    if not s3_key:
        return None, None
    
    # Check if URL is expired or about to expire (within 1 hour)
    current_time = datetime.utcnow()
    expires_at = url_expirations.get(report_id)
    logger.info(f"Checking expiration for report {report_id}: expires_at={expires_at}")
    if expires_at and expires_at > current_time + timedelta(hours=1):
        logger.info(f"URL for report {report_id} is still valid, returning existing")
        # We need to regenerate the URL since we don't store it
        pass
    
    # Regenerate URL
    logger.info(f"Regenerating URL for report {report_id}")
    result = generate_presigned_get_urls(
        bucket_name=BUCKET_NAME,
        object_paths=[s3_key],
        access_key=AWS_ACCESS_KEY_ID,
        secret_key=AWS_SECRET_ACCESS_KEY,
        region=AWS_REGION,
        expiration=604800  # 7 days
    )[0]
    if result['status'] == 'success':
        url_expirations[report_id] = result['expires_at']
        logger.info(f"New URL for report {report_id} expires at {result['expires_at'].isoformat()}")
        return result['url'], result['expires_at']
    else:
        logger.error(f"Failed to regenerate URL for report {report_id}: {result['error']}")
        return None, None

@router.post("/analyze")
async def analyze_data_readiness(
    request: Request,
    use_case_id: int = Form(...),
    files: List[UploadFile] = File(...),
    custom_parameters: str = Form(None,title="Custom Parameters", description="Custom parameters for data readiness analysis"),
    assessmentConfig: str = Form(...),
    db: Session = Depends(get_db)
):
    """
    Analyze data readiness for a specific use case with multiple uploaded data files
    
    This endpoint:
    1. Processes multiple uploaded data files
    2. Retrieves use case information from the database
    3. Analyzes data readiness using AI
    4. Returns comprehensive markdown analysis
    
    Parameters:
    - use_case_id: Form field with the use case ID
    - files: Multiple upload files (CSV, Excel, JSON, TXT, Parquet)
    """
    temp_dir = None
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        
        if not GROQ_API_KEY:
            return standard_response(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                success=False,
                message="AI service not configured",
                error={ "detail": "AI service not configured"}
            )
        # Validate files
        if not files or len(files) == 0:
            return standard_response(
                status_code=status.HTTP_400_BAD_REQUEST,
                success=False,
                message="At least one file must be uploaded",
                error={"detail": "At least one file must be uploaded"}
            )  
        
        # Parse assessment configuration
        try:
            config = json.loads(assessmentConfig)
        except json.JSONDecodeError:
            return standard_response(
                status_code=status.HTTP_400_BAD_REQUEST,
                success=False,
                message="Invalid assessment configuration format",
                error={"type": "ValidationError", "detail": "assessmentConfig must be valid JSON"}
            )

        # Get use case data
        use_case = db.query(GeneratedUseCase).filter(
            GeneratedUseCase.id == use_case_id
        ).first()
        
        if not use_case:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error={"type": "NotFound", "detail": "Use case not found"}
            )
        
        # Verify access to use case through session and project ownership
        session = db.query(PreWorkshopSession).filter(
            PreWorkshopSession.id == use_case.session_id
        ).first()
        
        if not session:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error={"type": "NotFound", "detail": "Session not found"}
            )
        
        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        
        if not project:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Access denied",
                error={"type": "AccessDenied", "detail": "Access denied"}
            )
        
        # Process uploaded file
        temp_dir = tempfile.mkdtemp()
        processed_files = []
        # Process each uploaded file
        for file in files:
            if file.size == 0:
                continue  # Skip empty files
                
            file_path = await save_uploaded_file(file, temp_dir)
            data_file = await file_processor.process_file(file_path, file.filename)
            processed_files.append(data_file)
        
        if not processed_files:
            return standard_response(
                status_code=status.HTTP_400_BAD_REQUEST,
                success=False,
                message="No valid files to process",
                error={"detail": "No valid files to process"}
            )
        file_path = await save_uploaded_file(file, temp_dir)
        
        # Prepare use case data
        use_case_data = {
            'id': use_case.id,
            'title': use_case.title,
            'description': use_case.description,
            'aws_services': use_case.aws_services,
            'primary_genai_capability': use_case.primary_genai_capability,
            'business_category': use_case.business_category,
            'customer_pain_points': use_case.customer_pain_points,
            'priority': use_case.priority,
            'complexity': use_case.complexity,
            'dependencies': use_case.dependencies,
            'risks': use_case.risks
        }
        
        # Analyze data readiness
        analyzer = DataReadinessAnalyzerService(GROQ_API_KEY)
        analysis_result = await analyzer.analyze_data_readiness(
            use_case_data, 
            processed_files,
            custom_parameters
        )
        
        # Check if DataReadiness record already exists for this use_case_id
        existing_readiness = db.query(DataReadiness).filter(
            DataReadiness.usecase_id == use_case_id
        ).first()
        
        if existing_readiness:
            # Update existing record
            existing_readiness.assessment_depth = config.get('depth', 'comprehensive')
            existing_readiness.is_generate_improvement_recommendations = config.get('generateRecommendations', True)
            existing_readiness.is_include_compliance_assessment = config.get('includeCompliance', False)
            existing_readiness.is_include_ai_powered_analysis = config.get('includeAI', True)
            existing_readiness.readiness_score_count = float(analysis_result.get('readiness_score', 0))
            existing_readiness.requirements_met_count = analysis_result.get('requirements_met_count', 0)
            existing_readiness.data_quality_issues_count = analysis_result.get('data_quality_issues_count', 0)
            existing_readiness.overall_status_text = analysis_result.get('status', 'Unknown')
            existing_readiness.data_quality_issues = json.dumps(analysis_result.get('data_quality_issues', []))
            existing_readiness.recommendations = json.dumps(analysis_result.get('recommendations', []))
            existing_readiness.analysis_report_text_md = analysis_result.get('generated_content', '')
            existing_readiness.analysis_type = analysis_result.get('analysis_type', 'comprehensive')
            data_readiness = existing_readiness
        else:
            # Create new DataReadiness record
            data_readiness = DataReadiness(
                usecase_id=use_case_id,
                assessment_depth=config.get('depth', 'comprehensive'),
                is_generate_improvement_recommendations=config.get('generateRecommendations', True),
                is_include_compliance_assessment=config.get('includeCompliance', False),
                is_include_ai_powered_analysis=config.get('includeAI', True),
                readiness_score_count=float(analysis_result.get('readiness_score', 0)),
                requirements_met_count=analysis_result.get('requirements_met_count', 0),
                data_quality_issues_count=analysis_result.get('data_quality_issues_count', 0),
                overall_status_text=analysis_result.get('status', 'Unknown'),
                data_quality_issues=json.dumps(analysis_result.get('data_quality_issues', [])),
                recommendations=json.dumps(analysis_result.get('recommendations', [])),
                analysis_report_text_md=analysis_result.get('generated_content', ''),
                analysis_type=analysis_result.get('analysis_type', 'comprehensive')
            )
            db.add(data_readiness)
        db.commit()
        db.refresh(data_readiness)
        
        # Handle document upload - check for existing documents and prevent duplicates
        uploaded_docs = []
        for file in files:
            # Save the uploaded document first
            document_path = await save_analysis_document(file, data_readiness.id, 'data_readiness',db)
            
            # Check if document with same filename already exists for this data readiness record
            existing_doc = db.query(DataReadinessDocument).filter(
                DataReadinessDocument.data_readiness_id == data_readiness.id,
                DataReadinessDocument.filename == file.filename
            ).first()
            
            if existing_doc:
                # Update existing document record with new path
                existing_doc.mimetype = file.content_type
                existing_doc.path = document_path
                
                uploaded_docs.append({
                    "filename": existing_doc.filename,
                    "mimetype": existing_doc.mimetype,
                    "path": existing_doc.path,
                    "is_updated": True
                })
            else:
                # Create new document record only if it doesn't exist
                data_readiness_document = DataReadinessDocument(
                    data_readiness_id=data_readiness.id,
                    filename=file.filename,
                    mimetype=file.content_type,
                    path=document_path
                )
                db.add(data_readiness_document)
                
                uploaded_docs.append({
                    "filename": file.filename,
                    "mimetype": file.content_type,
                    "path": document_path,
                    "is_updated": False
                })
        
        # Update use case status
        use_case.data_readiness_status = "Completed"
        if use_case.data_compliance_status == "Pending":
            use_case.data_compliance_status = "In Progress"
        
        db.commit()
        
        # Prepare response data
        response_data = {
            'data_readiness_id': data_readiness.id,
            'use_case_id': use_case_id,
            'analysis_type': analysis_result.get('analysis_type'),
            'readiness_score': analysis_result.get('readiness_score'),
            'status': analysis_result.get('status'),
            'requirements_met_count': analysis_result.get('requirements_met_count', 0),
            'data_quality_issues_count': analysis_result.get('data_quality_issues_count', 0),
            'files_analyzed': len(processed_files),
            'generated_at': analysis_result.get('generated_at'),
            'generated_content': analysis_result.get('generated_content', ''),
            'documents_uploaded': uploaded_docs
        }
        
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Data Readiness analysis completed successfully",
            data=response_data
        )
        
    except HTTPException as e:
        db.rollback()
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        db.rollback()
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message=f"Error analyzing data readiness: {str(e)}",
            error={"type": "Exception", "detail": str(e)}
        )
    
    finally:
        # Clean up temporary files
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)

@router.post("/generate-pdf")
async def generate_data_readiness_pdf(
    request: Request,
    data_readiness_id: int = Query(..., description="The ID of the data readiness analysis record"),
    use_case_id: int = Query(..., description="The ID of the use case"),
    db: Session = Depends(get_db)
):
    """
    Generate or fetch a PDF report for data readiness analysis and return a presigned URL for download.
    
    Parameters:
    - data_readiness_id: The ID of the data readiness analysis record
    - use_case_id: The ID of the use case (for validation and organization)
    """
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        
        if not GROQ_API_KEY:
            return standard_response(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                success=False,
                message="AI service not configured",
                error={"type": "ServiceUnavailable", "detail": "AI service not configured"}
            )
        
        if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
            return standard_response(
                status_code=500,
                success=False,
                message="S3 credentials not configured",
                error={"type": "ConfigurationError", "detail": "S3 credentials not configured"}
            )
        
        # Get data readiness record
        data_readiness = db.query(DataReadiness).filter(
            DataReadiness.id == data_readiness_id,
            DataReadiness.usecase_id == use_case_id
        ).first()
        
        if not data_readiness:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Data readiness analysis not found or doesn't match the use case",
                error={"type": "NotFound", "detail": "Data readiness analysis not found or doesn't match the use case"}
            )
        
        # Verify access through use case ownership
        use_case = db.query(GeneratedUseCase).filter(
            GeneratedUseCase.id == use_case_id
        ).first()
        
        if not use_case:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Associated use case not found",
                error={"type": "NotFound", "detail": "Associated use case not found"}
            )
        
        # Retrieve project name
        session = db.query(PreWorkshopSession).filter(
            PreWorkshopSession.id == use_case.session_id
        ).first()
        
        if not session:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error={"type": "NotFound", "detail": "Session not found"}
            )
        
        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        
        if not project:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Access denied",
                error={"type": "AccessDenied", "detail": "Access denied"}
            )
        
        # Check if PDF report already exists
        pdf_report = None
        presigned_url = None
        expires_at = None
        
        if data_readiness.generated_pdf_report_id:
            pdf_report = db.query(AssessmentReport).filter(
                AssessmentReport.id == data_readiness.generated_pdf_report_id
            ).first()
        
        if pdf_report:
            # For existing PDF, refresh presigned URL
            logger.info(f"Refreshing presigned URL for existing report {pdf_report.id}")
            presigned_url, expires_at = _refresh_report_presigned_url(pdf_report)
            if not presigned_url:
                return standard_response(
                    status_code=500,
                    success=False,
                    message="Failed to generate presigned URL for existing report",
                    error={"type": "S3Error", "detail": "Failed to generate presigned URL"}
                )
        else:
            # For new PDF, generate and upload
            logger.info(f"Generating new PDF report for data readiness {data_readiness_id}")
            analyzer = DataReadinessAnalyzerService(GROQ_API_KEY)
            pdf_content = analyzer.generate_pdf(data_readiness.analysis_report_text_md)
            
            # Upload PDF to S3
            folder_prefix = 'data_readiness/reports'
            session_id = data_readiness.id
            session_name = 'report'
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"data_readiness_report_{use_case_id}_{data_readiness_id}_{timestamp}.pdf"
            
            s3_key, presigned_url, expires_at = upload_file(
                BUCKET_NAME,
                pdf_content,
                session_id,
                session_name,
                filename,
                AWS_ACCESS_KEY_ID,
                AWS_SECRET_ACCESS_KEY,
                AWS_REGION,
                folder_prefix=folder_prefix,
                expiration=604800,
                project_name=project.name  # Pass project name
            )
            
            # Create or update AssessmentReport record
            if data_readiness.generated_pdf_report_id:
                pdf_report = db.query(AssessmentReport).filter(
                    AssessmentReport.id == data_readiness.generated_pdf_report_id
                ).first()
                if pdf_report:
                    pdf_report.report_path = s3_key
                    pdf_report.report_filename = filename
                    pdf_report.updated_at = datetime.utcnow()
            else:
                pdf_report = AssessmentReport(
                    usecase_id=use_case_id,
                    assessment_stage="data_readiness",
                    report_type="pdf",
                    report_mimetype="application/pdf",
                    report_filename=filename,
                    report_path=s3_key
                )
                db.add(pdf_report)
                db.flush()
                data_readiness.generated_pdf_report_id = pdf_report.id
            
            # Store the expiration in memory
            url_expirations[pdf_report.id] = expires_at
            
            db.commit()
            logger.info(f"New PDF report created with ID {pdf_report.id}")
        
        # Return simplified JSON response with only presigned URL and expiration
        response_data = {
            "presigned_url": presigned_url,
            "expires_at": expires_at.isoformat() if expires_at else None
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="PDF report generated successfully",
            data=response_data
        )
        
    except HTTPException as e:
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message=f"Error generating PDF: {str(e)}",
            error={"type": "Exception", "detail": str(e)}
        )
    
async def save_analysis_document(file: UploadFile, analysis_id: int, analysis_type: str, db: Session) -> str:
    """Save uploaded file to S3 and return the S3 key"""
    if analysis_type != 'data_readiness':
        raise ValueError("Only 'data_readiness' analysis type is supported for S3 upload")
    
    # Retrieve project name
    data_readiness = db.query(DataReadiness).filter(DataReadiness.id == analysis_id).first()
    if not data_readiness:
        raise HTTPException(status_code=404, detail="Data readiness record not found")
    use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == data_readiness.usecase_id).first()
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    session = db.query(PreWorkshopSession).filter(PreWorkshopSession.id == use_case.session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    project = db.query(Project).filter(Project.id == session.project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Read file content
    file.file.seek(0)
    file_content = await file.read()
    
    if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
        raise HTTPException(status_code=500, detail="S3 credentials not configured")
    
    # Set folder_prefix for data readiness documents
    folder_prefix = 'data_readiness/documents'
    
    # Use analysis_id as session_id, and a fixed session_name
    session_id = analysis_id
    session_name = 'analysis'
    
    # Upload to S3
    loop = asyncio.get_event_loop()
    s3_key, presigned_url, expires_at = await loop.run_in_executor(
        None,
        lambda: upload_file(
            BUCKET_NAME,
            file_content,
            session_id,
            session_name,
            file.filename,
            AWS_ACCESS_KEY_ID,
            AWS_SECRET_ACCESS_KEY,
            AWS_REGION,
            folder_prefix=folder_prefix,
            expiration=604800,
            project_name=project.name  # Pass project name
        )
    )
    
    return s3_key

@router.get("/supported-formats")
async def get_supported_formats():
    """Get list of supported file formats for data readiness analysis"""
    try:
        supported_data = {
            "supported_formats": list(DataReadinessAnalyzerService.SUPPORTED_EXTENSIONS.keys()),
            "format_descriptions": {
                ".csv": "Comma-separated values",
                ".xlsx": "Excel spreadsheet (2007+)",
                ".xls": "Excel spreadsheet (legacy)",
                ".txt": "Plain text file",
                ".json": "JSON data file",
                ".parquet": "Parquet columnar format"
            },
            "analysis_capabilities": [
                "Data quality assessment",
                "Requirements matching",
                "Column analysis",
                "Volume validation",
                "Completeness checking"
            ]
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Supported formats retrieved successfully",
            data=supported_data
        )
        
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error retrieving supported formats",
            error={"type": "Exception", "detail": str(e)}
        )

@router.get("/health")
async def health_check():
    """Health check endpoint for data readiness service"""
    try:
        health_data = {
            "status": "healthy",
            "ai_service": "available" if GROQ_API_KEY else "not_configured",
            "supported_formats": len(DataReadinessAnalyzerService.SUPPORTED_EXTENSIONS),
            "timestamp": datetime.utcnow().isoformat()
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Service is healthy",
            data=health_data
        )
        
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Health check failed",
            error={"type": "Exception", "detail": str(e)}
        )
    
@router.get("/get_data_readiness/{use_case_id}")
async def get_data_readiness(
    request: Request,
    use_case_id: int,
    db: Session = Depends(get_db)
):
    """
    Retrieve existing data readiness analysis for a given use case.

    Returns:
    - Data readiness metrics
    - Uploaded document paths
    - PDF report path
    - Assessment configuration
    """
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)

        use_case = db.query(GeneratedUseCase).filter(
            GeneratedUseCase.id == use_case_id
        ).first()

        if not use_case:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error={"type": "NotFound", "detail": "Use case not found"}
            )

        session = db.query(PreWorkshopSession).filter(
            PreWorkshopSession.id == use_case.session_id
        ).first()

        if not session:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error={"type": "NotFound", "detail": "Session not found"}
            )

        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()

        if not project:
            return standard_response(
                status_code=status.HTTP_403_FORBIDDEN,
                success=False,
                message="Access denied",
                error={"type": "AccessDenied", "detail": "Access denied"}
            )

        data_readiness = db.query(DataReadiness).filter(
            DataReadiness.usecase_id == use_case_id
        ).first()

        if not data_readiness:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="No data readiness analysis found",
                error={"type": "NotFound", "detail": "No analysis found for use case"}
            )

        # Uploaded documents
        documents = db.query(DataReadinessDocument).filter(
            DataReadinessDocument.data_readiness_id == data_readiness.id
        ).all()

        # uploaded_docs = [{
        #     "filename": doc.filename,
        #     "mimetype": doc.mimetype,
        #     "path": doc.path
        # } for doc in documents]

        s3 = boto3.client(
            's3',
            region_name=AWS_REGION,
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY
        )

        object_paths = [doc.path for doc in documents]
        presigned_urls = generate_presigned_get_urls(
            bucket_name=BUCKET_NAME,
            object_paths=object_paths,
            access_key=AWS_ACCESS_KEY_ID,
            secret_key=AWS_SECRET_ACCESS_KEY,
            region=AWS_REGION,
            expiration=604800  # 7 days
        )

        uploaded_docs = []
        for doc, url_info in zip(documents, presigned_urls):
            file_size = 0
            try:
                response = s3.head_object(Bucket=BUCKET_NAME, Key=doc.path)
                file_size = response.get('ContentLength', 0)
            except Exception as e:
                logger.warning(f"Could not retrieve size for {doc.path}: {e}")

            uploaded_docs.append({
                "filename": doc.filename,
                "mimetype": doc.mimetype,
                "path": url_info['url'] if url_info['status'] == 'success' else None,
                "size": file_size  # size in bytes
            })

        # Report path
        report_path = None
        if data_readiness.generated_pdf_report_id:
            pdf_report = db.query(AssessmentReport).filter(
                AssessmentReport.id == data_readiness.generated_pdf_report_id
            ).first()
            if pdf_report:
                report_path = pdf_report.report_path

        # Assessment config reconstruction
        assessment_config = {
            "depth": data_readiness.assessment_depth,
            "includeAI": data_readiness.is_include_ai_powered_analysis,
            "generateRecommendations": data_readiness.is_generate_improvement_recommendations,
            "includeCompliance": data_readiness.is_include_compliance_assessment
        }

        response_data = {
            "data_readiness_id": data_readiness.id,
            "use_case_id": use_case_id,
            "analysis_type": data_readiness.analysis_type,
            "readiness_score": data_readiness.readiness_score_count,
            "status": data_readiness.overall_status_text,
            "requirements_met_count": data_readiness.requirements_met_count,
            "data_quality_issues_count": data_readiness.data_quality_issues_count,
            "files_analyzed": len(uploaded_docs),
            "generated_at": data_readiness.updated_at,
            "generated_content": data_readiness.analysis_report_text_md,
            "documents_uploaded": uploaded_docs,
            "report_path": report_path,
            "assessment_config": assessment_config
        }

        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Data readiness analysis retrieved successfully",
            data=response_data
        )

    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Unexpected error occurred",
            error={"type": "Exception", "detail": str(e)}
        )
