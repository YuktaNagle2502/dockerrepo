from fastapi import APIRouter, Depends, HTTPException, Request, status, UploadFile, File, Response, Form, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from datetime import datetime
from typing import List, Dict, Any, Optional
import json
import uuid
from database import get_db
from models.models import (
    PredefinedTestCase, User, ModelEvaluation, SelectedModel, ModelRanking, TestCase, 
    TestCaseResult, LLMModel, AssessmentReport, GeneratedUseCase, PreWorkshopSession, Project
)
from models.pydantic_models import StandardResponse, standard_response
from services.model_evaluation_service import ModelEvaluator, TestDataProcessor, ModelEvaluationResponse, ModelEvaluationRequest, PricingResponse, PricingRequest
from utils.model_evaluation_utils import ModelEvaluationPDFGenerator, save_uploaded_file, generate_evaluation_summary
import logging
import shutil
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import tempfile
import os
from sqlalchemy.orm import Session
import pandas as pd
import io
from utils.pricing import PriceCalculator
from utils.s3_utils import upload_file, generate_presigned_get_urls, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, BUCKET_NAME
import asyncio

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Router
router = APIRouter(prefix="/model-evaluation", tags=["Model Evaluation"])

# Initialize processors
test_data_processor = TestDataProcessor()
pdf_generator = ModelEvaluationPDFGenerator()

async def save_analysis_document(file: UploadFile, analysis_id: int, analysis_type: str, db: Session) -> str:
    """Save uploaded file as analysis document and return the S3 key"""
    if analysis_type != 'model_evaluation':
        raise ValueError("Only 'model_evaluation' analysis type is supported for S3 upload")
    
    # Retrieve project name
    model_evaluation = db.query(ModelEvaluation).filter(ModelEvaluation.id == analysis_id).first()
    if not model_evaluation:
        raise HTTPException(status_code=404, detail="Model evaluation record not found")
    use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == model_evaluation.usecase_id).first()
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    session = db.query(PreWorkshopSession).filter(PreWorkshopSession.id == use_case.session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    project = db.query(Project).filter(Project.id == session.project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Read file content
    file.file.seek(0)
    file_content = await file.read()
    
    if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
        raise HTTPException(status_code=500, detail="S3 credentials not configured")
    
    # Set folder_prefix for model evaluation documents
    folder_prefix = f"model_evaluation/documents/{project.name}/analysis/{model_evaluation.usecase_id}"
    
    # Use analysis_id as session_id, and a fixed session_name
    session_id = analysis_id
    session_name = 'analysis'
    
    # Upload to S3
    loop = asyncio.get_event_loop()
    try:
        s3_key, presigned_url, expires_at = await loop.run_in_executor(
            None,
            lambda: upload_file(
                bucket_name=BUCKET_NAME,
                file_content=file_content,
                session_id=session_id,
                session_name=session_name,
                filename=file.filename,
                access_key=AWS_ACCESS_KEY_ID,
                secret_key=AWS_SECRET_ACCESS_KEY,
                region=AWS_REGION,
                folder_prefix=folder_prefix,
                expiration=604800
            )
        )
        logger.info(f"Successfully uploaded document to S3: s3_key={s3_key}")
        return s3_key
    except Exception as e:
        logger.error(f"Failed to upload document to S3: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to upload document to S3: {str(e)}")

async def save_assessment_report(content: bytes, filename: str, report_type: str, 
                               mimetype: str, usecase_id: int, assessment_stage: str, 
                               evaluation_id: int, db: Session) -> int:
    """Save assessment report to database and return report ID"""
    if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
        raise HTTPException(status_code=500, detail="S3 credentials not configured")
    
    # Retrieve project name
    use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == usecase_id).first()
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    session = db.query(PreWorkshopSession).filter(PreWorkshopSession.id == use_case.session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    project = db.query(Project).filter(Project.id == session.project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Adjusted folder_prefix to avoid redundant /evaluation/{evaluation_id}
    folder_prefix = f"model_evaluation/reports/{project.name}/report/{usecase_id}"
    session_id = evaluation_id
    session_name = "evaluation"
    
    loop = asyncio.get_event_loop()
    try:
        s3_key, presigned_url, expires_at = await loop.run_in_executor(
            None,
            lambda: upload_file(
                bucket_name=BUCKET_NAME,
                file_content=content,
                session_id=session_id,
                session_name=session_name,
                filename=filename,
                access_key=AWS_ACCESS_KEY_ID,
                secret_key=AWS_SECRET_ACCESS_KEY,
                region=AWS_REGION,
                folder_prefix=folder_prefix,
                expiration=604800
            )
        )
        logger.info(f"Successfully uploaded report to S3: s3_key={s3_key}")
    except Exception as e:
        logger.error(f"Failed to upload report to S3: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to upload report to S3: {str(e)}")
    
    report = AssessmentReport(
        usecase_id=usecase_id,
        assessment_stage=assessment_stage,
        report_type=report_type,
        report_mimetype=mimetype,
        report_filename=filename,
        report_path=s3_key
    )
    
    db.add(report)
    db.commit()
    db.refresh(report)
    
    return report.id

@router.post("/analyze", response_model=StandardResponse)
async def analyze_models(
    usecase_id: int = Form(..., description="Use case ID for evaluation"),
    models: str = Form(..., description="Comma-separated list of models to evaluate"),
    api_keys: str = Form(..., description="""{"openai":"azure_open_api_key","groq":"groq_api_key"}"""),
    file: UploadFile = File(..., description="CSV/Excel file with prompt,ground_truth columns"),
    use_llm_judge: bool = Form(True, description="Use LLM as judge for scoring"),
    max_tokens: int = Form(1000, description="Maximum tokens for responses"),
    temperature: float = Form(0.7, description="Temperature for model responses"),
    timeout: int = Form(30, description="Timeout for model responses"),
    max_retries: int = Form(3, description="Maximum retries for failed requests"),
    db: Session = Depends(get_db)
):
    """
    Analyze multiple AI models against test cases from uploaded file
    """
    temp_dir = tempfile.mkdtemp()
    try:
        # Validate use case
        use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == usecase_id).first()
        if not use_case:
            return standard_response(
                status_code=404,
                success=False,
                message="Use case not found",
                error=f"No use case found with ID {usecase_id}"
            )

        model_list = [model.strip() for model in models.split(",") if model.strip()]
        api_keys_dict = json.loads(api_keys)

        if not model_list:
            return standard_response(
                status_code=400,
                success=False,
                message="No models specified for evaluation",
                error="Model list cannot be empty"
            )

        if not file.filename.endswith(('.csv', '.xlsx', '.xls')):
            return standard_response(
                status_code=400,
                success=False,
                message="Invalid file type",
                error="Please upload a CSV or Excel file"
            )

        # Save and process uploaded file
        file_path = await save_uploaded_file(file, temp_dir)
        test_cases = await test_data_processor.process_test_file(file_path, file.filename)

        if not test_cases:
            return standard_response(
                status_code=400,
                success=False,
                message="No valid test cases found",
                error="File must contain valid test cases with required columns"
            )

        # Check for existing evaluation and clean up if exists
        existing_eval = db.query(ModelEvaluation).filter(ModelEvaluation.usecase_id == usecase_id).first()

        if existing_eval:
            db.query(TestCaseResult).filter(
                TestCaseResult.model_ranking_id.in_(
                    db.query(ModelRanking.id).filter(ModelRanking.model_evaluation_id == existing_eval.id)
                )
            ).delete(synchronize_session=False)
            db.query(ModelRanking).filter(ModelRanking.model_evaluation_id == existing_eval.id).delete(synchronize_session=False)
            db.query(SelectedModel).filter(SelectedModel.model_evaluation_id == existing_eval.id).delete(synchronize_session=False)
            db.query(TestCase).filter(TestCase.model_evaluation_id == existing_eval.id).delete(synchronize_session=False)
            existing_eval.model_tested_count = len(model_list)
            existing_eval.test_cases_count = len(test_cases)
            existing_eval.average_accuracy = 0.0
            existing_eval.best_model = ""
            existing_eval.evaluation_summary_md = ""
            model_evaluation = existing_eval
        else:
            model_evaluation = ModelEvaluation(
                usecase_id=usecase_id,
                model_tested_count=len(model_list),
                test_cases_count=len(test_cases),
                average_accuracy=0.0,
                best_model="",
                evaluation_summary_md=""
            )
            db.add(model_evaluation)
            db.commit()
            db.refresh(model_evaluation)

        # Upload file to S3 with the correct analysis_id
        file.file.seek(0)
        s3_key = await save_analysis_document(file, analysis_id=model_evaluation.id, analysis_type='model_evaluation', db=db)

        # Ensure LLMModel exists and create SelectedModel
        for model_name in model_list:
            provider = next((prov for prov, prov_models in ModelEvaluator.SUPPORTED_MODELS.items() if model_name in prov_models), None)
            if not provider:
                logger.warning(f"Model {model_name} not supported, skipping")
                continue

            llm_model = db.query(LLMModel).filter(
                LLMModel.model_code == model_name,
                LLMModel.llm_provider == provider
            ).first()

            if not llm_model:
                llm_model = LLMModel(
                    llm_provider=provider,
                    model_code=model_name,
                    is_support_llm_as_judge=use_llm_judge,
                    is_default=False
                )
                db.add(llm_model)
                db.commit()
                db.refresh(llm_model)

            selected_model = SelectedModel(
                model_evaluation_id=model_evaluation.id,
                llm_model_id=llm_model.id,
                llm_key=api_keys_dict.get(provider, ""),
                use_llm_as_judge=use_llm_judge,
                timeout=timeout,
                temperature=temperature,
                max_retries=max_retries,
                max_tokens=max_tokens,
                is_selected_for_evaluation=True
            )
            db.add(selected_model)

        # Add test cases
        for tc in test_cases:
            db.add(TestCase(
                model_evaluation_id=model_evaluation.id,
                test_prompt=tc.prompt,
                expected_answer=tc.ground_truth,
                test_category=tc.category,
                difficulty_level=tc.difficulty,
                evaluation_criteria=["accuracy", "relevance"],
                test_case_type="uploaded"
            ))

        db.commit()

        # Run evaluation with retry mechanism
        evaluator = ModelEvaluator(api_keys=api_keys_dict)
        results = await evaluator.evaluate_models(
            test_cases=test_cases,
            models=model_list,
            use_llm_judge=use_llm_judge,
            max_tokens=max_tokens,
            temperature=temperature
        )
        
        # Save results
        model_rankings = []
        for rank, (model_name, summary) in enumerate(sorted(results["model_summaries"].items(), key=lambda x: x[1]["average_score"] if "average_score" in x[1] else 0, reverse=True), 1):
            model_ranking = ModelRanking(
                model_evaluation_id=model_evaluation.id,
                rank=rank,
                model=model_name,
                average_score=summary["average_score"],
                binary_score=summary["accuracy_percentage"],
                average_response_time=min(float(summary["average_response_time"]), 0.0),
                llm_judge_score=summary["average_score"] if use_llm_judge else 0.0
            )
            db.add(model_ranking)
            db.commit()
            db.refresh(model_ranking)
            model_rankings.append(model_ranking)

            for result in summary["detailed_results"]:
                db.add(TestCaseResult(
                    model_ranking_id=model_ranking.id,
                    test=result["prompt"],
                    is_correct=result["is_correct"],
                    score=result["accuracy_score"],
                    response_time=min(float(result["response_time"]), 0.0),
                    response=result["response"],
                    judge_explanation=result["judge_explanation"],
                    status="completed"
                ))

        # Finalize evaluation record
        evaluation_summary = await generate_evaluation_summary(results)
        best_model = results["overall_results"].get("best_performing_model", {})
        model_evaluation.average_accuracy = results["overall_results"].get("overall_average_accuracy", 0.0)
        model_evaluation.best_model = best_model.get("model", "") if isinstance(best_model, dict) else str(best_model)
        model_evaluation.evaluation_summary_md = str(evaluation_summary)
        use_case.model_evaluation_status = "Completed"
        if use_case.sprint_planning_status == "Pending":
            use_case.sprint_planning_status = "In Progress"
        db.commit()

        return standard_response(
            status_code=200,
            success=True,
            message="Model evaluation completed successfully",
            data={
                "model_evaluation_id": model_evaluation.id,
                "total_test_cases": len(test_cases),
                "models_evaluated": model_list,
                "overall_results": results["overall_results"],
                "best_performing_model": model_evaluation.best_model,
                "average_accuracy": model_evaluation.average_accuracy,
                "evaluation_summary": model_evaluation.evaluation_summary_md,
                "generated_at": model_evaluation.created_at
            }
        )

    except Exception as e:
        db.rollback()
        logger.exception("Evaluation failed")
        return standard_response(
            status_code=500,
            success=False,
            message="Internal server error during model evaluation",
            error=str(e)
        )

    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

@router.post("/generate-pdf")
async def generate_evaluation_pdf(
    model_evaluation_id: int = Query(..., description="Model evaluation ID"),
    db: Session = Depends(get_db)
):
    """
    Generate or retrieve PDF report from model evaluation results
    """
    try:
        logger.info(f"Starting PDF generation for model_evaluation_id={model_evaluation_id}")
        
        model_evaluation = db.query(ModelEvaluation).filter(
            ModelEvaluation.id == model_evaluation_id
        ).first()
        
        if not model_evaluation:
            logger.error(f"Model evaluation not found for id={model_evaluation_id}")
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Model evaluation not found",
                error=f"No model evaluation found with ID {model_evaluation_id}"
            )
        
        # Retrieve project name
        use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == model_evaluation.usecase_id).first()
        if not use_case:
            raise HTTPException(status_code=404, detail="Use case not found")
        session = db.query(PreWorkshopSession).filter(PreWorkshopSession.id == use_case.session_id).first()
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        project = db.query(Project).filter(Project.id == session.project_id).first()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        
        logger.info(f"Retrieved model evaluation: id={model_evaluation.id}, usecase_id={model_evaluation.usecase_id}, generated_pdf_report_id={model_evaluation.generated_pdf_report_id}")
        
        if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
            logger.error("S3 credentials not configured")
            return standard_response(
                status_code=500,
                success=False,
                message="S3 credentials not configured",
                error={"type": "ConfigurationError", "detail": "S3 credentials not configured"}
            )
        
        logger.info(f"S3 configuration: bucket={BUCKET_NAME}, region={AWS_REGION}")
        
        pdf_report = None
        presigned_url = None
        expires_at = None
        
        if model_evaluation.generated_pdf_report_id:
            logger.info(f"Checking existing report with id={model_evaluation.generated_pdf_report_id}")
            pdf_report = db.query(AssessmentReport).filter(
                AssessmentReport.id == model_evaluation.generated_pdf_report_id
            ).first()
            logger.info(f"Existing report found: {pdf_report.id if pdf_report else 'None'}, path={pdf_report.report_path if pdf_report else 'None'}")
        
        if pdf_report:
            logger.info(f"Refreshing presigned URL for existing report {pdf_report.id}")
            result = generate_presigned_get_urls(
                bucket_name=BUCKET_NAME,
                object_paths=[pdf_report.report_path],
                access_key=AWS_ACCESS_KEY_ID,
                secret_key=AWS_SECRET_ACCESS_KEY,
                region=AWS_REGION,
                expiration=604800
            )[0]
            if result['status'] == 'success':
                presigned_url = result['url']
                expires_at = result['expires_at']
                logger.info(f"Presigned URL generated: {presigned_url}, expires at {expires_at}")
            else:
                logger.error(f"Failed to generate presigned URL: {result.get('error', 'Unknown error')}")
                return standard_response(
                    status_code=500,
                    success=False,
                    message="Failed to generate presigned URL for existing report",
                    error={"type": "S3Error", "detail": result.get('error', 'Unknown error')}
                )
        else:
            logger.info(f"Generating new PDF for model_evaluation_id={model_evaluation_id}")
            model_rankings = db.query(ModelRanking).filter(
                ModelRanking.model_evaluation_id == model_evaluation_id
            ).order_by(ModelRanking.rank).all()
            logger.info(f"Retrieved {len(model_rankings)} model rankings")
            
            test_cases = db.query(TestCase).filter(
                TestCase.model_evaluation_id == model_evaluation_id
            ).all()
            logger.info(f"Retrieved {len(test_cases)} test cases")
            
            results = {
                "evaluation_id": str(model_evaluation_id),
                "overall_results": {
                    "total_models": model_evaluation.model_tested_count,
                    "total_test_cases": model_evaluation.test_cases_count,
                    "best_performing_model": model_evaluation.best_model,
                    "worst_performing_model": "",
                    "overall_average_score": 0.0,
                    "overall_average_accuracy": float(model_evaluation.average_accuracy) if model_evaluation.average_accuracy else 0.0,
                    "performance_variance": 0.0,
                    "model_rankings": []
                },
                "detailed_results": [],
                "evaluation_summary": model_evaluation.evaluation_summary_md or "No summary available"
            }
            
            scores = []
            worst_model = None
            worst_score = float('inf')
            
            for ranking in model_rankings:
                avg_score = float(ranking.average_score) if ranking.average_score else 0.0
                scores.append(avg_score)
                
                if avg_score < worst_score:
                    worst_score = avg_score
                    worst_model = ranking.model
                
                results["overall_results"]["model_rankings"].append({
                    "rank": ranking.rank,
                    "model_name": ranking.model,
                    "average_score": avg_score,
                    "accuracy_percentage": float(ranking.binary_score) if ranking.binary_score else 0.0,
                    "average_response_time": float(ranking.average_response_time) if ranking.average_response_time else 0.0
                })
                logger.debug(f"Processed ranking for model {ranking.model}, score={avg_score}")
                
                test_results = db.query(TestCaseResult).filter(
                    TestCaseResult.model_ranking_id == ranking.id
                ).all()
                logger.info(f"Retrieved {len(test_results)} test results for model {ranking.model}")
                
                for test_result in test_results:
                    test_case = next((tc for tc in test_cases if tc.test_prompt == test_result.test), None)
                    results["detailed_results"].append({
                        "model_name": ranking.model,
                        "prompt": test_result.test,
                        "ground_truth": test_case.expected_answer if test_case else "N/A",
                        "response": test_result.response,
                        "is_correct": test_result.is_correct,
                        "accuracy_score": float(test_result.score) if test_result.score else 0.0,
                        "response_time": float(test_result.response_time) if test_result.response_time else 0.0,
                        "judge_explanation": test_result.judge_explanation,
                    })
                    logger.debug(f"Added test result for prompt: {test_result.test}")
            
            if scores:
                results["overall_results"]["overall_average_score"] = sum(scores) / len(scores)
                results["overall_results"]["worst_performing_model"] = worst_model or "N/A"
                if len(scores) > 1:
                    mean = sum(scores) / len(scores)
                    variance = sum((x - mean) ** 2 for x in scores) / len(scores)
                    results["overall_results"]["performance_variance"] = variance ** 0.5
                logger.info(f"Calculated statistics: average_score={results['overall_results']['overall_average_score']}, variance={results['overall_results']['performance_variance']}")
            
            use_case = db.query(GeneratedUseCase).filter(
                GeneratedUseCase.id == model_evaluation.usecase_id
            ).first()
            title = f"Model Evaluation Report - {use_case.title if use_case else 'Use Case ' + str(model_evaluation.usecase_id)}"
            logger.info(f"Generating PDF with title: {title}")
            
            pdf_content = pdf_generator.generate_pdf(results, title)
            logger.info(f"PDF content generated, size={len(pdf_content)} bytes")
            
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"model_evaluation_report_{model_evaluation_id}_{timestamp}.pdf"
            folder_prefix = f"model_evaluation/reports/{project.name}/report/{model_evaluation.usecase_id}"
            session_id = model_evaluation_id
            session_name = "evaluation"
            
            logger.info(f"Uploading PDF to S3: bucket={BUCKET_NAME}, folder_prefix={folder_prefix}, filename={filename}")
            try:
                s3_key, presigned_url, expires_at = upload_file(
                    bucket_name=BUCKET_NAME,
                    file_content=pdf_content,
                    session_id=session_id,
                    session_name=session_name,
                    filename=filename,
                    access_key=AWS_ACCESS_KEY_ID,
                    secret_key=AWS_SECRET_ACCESS_KEY,
                    region=AWS_REGION,
                    folder_prefix=folder_prefix,
                    expiration=604800
                )
                logger.info(f"Successfully uploaded PDF to S3: s3_key={s3_key}, presigned_url={presigned_url}, expires_at={expires_at}")
            except Exception as e:
                logger.error(f"Failed to upload PDF to S3: {str(e)}")
                return standard_response(
                    status_code=500,
                    success=False,
                    message="Failed to upload PDF to S3",
                    error=str(e)
                )
            
            pdf_report = AssessmentReport(
                usecase_id=model_evaluation.usecase_id,
                assessment_stage="model_evaluation",
                report_type="pdf",
                report_mimetype="application/pdf",
                report_filename=filename,
                report_path=s3_key
            )
            db.add(pdf_report)
            db.flush()
            logger.info(f"AssessmentReport created with id={pdf_report.id}, path={s3_key}")
            model_evaluation.generated_pdf_report_id = pdf_report.id
            
            db.commit()
            logger.info(f"Updated model_evaluation_id={model_evaluation_id} with generated_pdf_report_id={pdf_report.id}")
        
        response_data = {
            "presigned_url": presigned_url,
            "expires_at": expires_at.isoformat() if expires_at else None,
            "report_path": pdf_report.report_path if pdf_report else s3_key
        }
        logger.info(f"Returning response: presigned_url={presigned_url}, expires_at={expires_at}, report_path={response_data['report_path']}")
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="PDF report generated successfully",
            data=response_data
        )
        
    except Exception as e:
        logger.error(f"Error generating PDF: {str(e)}", exc_info=True)
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error generating PDF report",
            error=str(e)
        )

@router.get("/supported-models", response_model=StandardResponse)
async def get_supported_models(db: Session = Depends(get_db)):
    """Get list of supported models for evaluation"""
    try:
        evaluator = ModelEvaluator()
        
        db_models = db.query(LLMModel).all()
        
        available_providers = {}
        
        if os.getenv("GROQ_API_KEY"):
            available_providers["groq"] = {
                "name": "Groq",
                "models": evaluator.SUPPORTED_MODELS["groq"]
            }
        
        if os.getenv("AZURE_OPENAI_API_KEY"):
            available_providers["openai"] = {
                "name": "OpenAI",
                "models": evaluator.SUPPORTED_MODELS["openai"]
            }
        
        if os.getenv("ANTHROPIC_API_KEY"):
            available_providers["anthropic"] = {
                "name": "Anthropic",
                "models": evaluator.SUPPORTED_MODELS["anthropic"]
            }
        
        if os.getenv("GEMINI_API_KEY"):
            available_providers["gemini"] = {
                "name": "Gemini",
                "models": evaluator.SUPPORTED_MODELS["gemini"]
            }
        
        if os.getenv("AWS_ACCESS_KEY_ID") and os.getenv("AWS_SECRET_ACCESS_KEY"):
            available_providers["bedrock"] = {
                "name": "Bedrock",
                "models": evaluator.SUPPORTED_MODELS["bedrock"]
            }
        
        all_models = []
        for provider, info in available_providers.items():
            for model_id, model_name in info["models"].items():
                db_model = next((m for m in db_models if m.model_code == model_id and m.llm_provider == provider), None)
                
                all_models.append({
                    "id": model_id,
                    "name": model_name,
                    "provider": provider,
                    "is_in_database": db_model is not None,
                    "supports_llm_judge": db_model.is_support_llm_as_judge if db_model else True,
                    "is_default": db_model.is_default if db_model else False
                })
        
        response_data = {
            "providers": available_providers,
            "all_models": all_models,
            "total_models": len(all_models),
            "file_format_requirements": {
                "supported_formats": test_data_processor.supported_extensions,
                "required_columns": ["prompt", "ground_truth"],
                "optional_columns": ["test_category", "difficulty_level", "evaluation_criteria"],
                "example_structure": {
                    "prompt": "What is the capital of France?",
                    "ground_truth": "Paris",
                    "test_category": "Geography",
                    "difficulty_level": "Easy"
                }
            }
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Successfully retrieved supported models",
            data=response_data
        )
        
    except Exception as e:
        logger.error(f"Error retrieving supported models: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error retrieving supported models",
            error=str(e)
        )

@router.get("/sample-template/csv")
async def download_csv_template(
    include_predefined: bool = Query(True, description="Include predefined test cases from database"),
    limit: int = Query(10, description="Maximum number of predefined test cases to include"),
    db: Session = Depends(get_db)
):
    """Download a sample CSV template for model evaluation"""
    try:
        sample_data = []
        
        if include_predefined:
            predefined_cases = db.query(PredefinedTestCase).limit(limit).all()
            
            for case in predefined_cases:
                sample_data.append({
                    "prompt": case.test_prompt,
                    "ground_truth": case.expected_answer,
                    "test_category": case.test_category or "General",
                    "difficulty_level": case.difficulty_level or "Medium",
                    "evaluation_criteria": ",".join(case.evaluation_criteria) if case.evaluation_criteria else "accuracy,relevance"
                })
        
        if not sample_data:
            sample_data = [
                {
                    "prompt": "What is the capital of France?",
                    "ground_truth": "Paris",
                    "test_category": "Geography",
                    "difficulty_level": "Easy",
                    "evaluation_criteria": "accuracy"
                },
                {
                    "prompt": "Explain the concept of machine learning in simple terms.",
                    "ground_truth": "Machine learning is a subset of artificial intelligence that enables computers to learn and make decisions from data without being explicitly programmed for every task.",
                    "test_category": "Technology",
                    "difficulty_level": "Medium",
                    "evaluation_criteria": "accuracy,clarity,completeness"
                },
                {
                    "prompt": "What is 2 + 2?",
                    "ground_truth": "4",
                    "test_category": "Mathematics",
                    "difficulty_level": "Easy",
                    "evaluation_criteria": "accuracy"
                },
                {
                    "prompt": "Name three benefits of renewable energy.",
                    "ground_truth": "1. Environmentally friendly with reduced greenhouse gas emissions, 2. Sustainable and inexhaustible energy source, 3. Long-term cost savings and energy independence",
                    "test_category": "Environment",
                    "difficulty_level": "Medium",
                    "evaluation_criteria": "accuracy,completeness,relevance"
                },
                {
                    "prompt": "What programming language is known for data science?",
                    "ground_truth": "Python",
                    "test_category": "Technology",
                    "difficulty_level": "Easy",
                    "evaluation_criteria": "accuracy"
                }
            ]
        
        df = pd.DataFrame(sample_data)
        csv_buffer = io.StringIO()
        df.to_csv(csv_buffer, index=False)
        csv_content = csv_buffer.getvalue()
        
        return Response(
            content=csv_content,
            media_type="text/csv",
            headers={
                "Content-Disposition": "attachment; filename=model_evaluation_template.csv"
            }
        )
        
    except Exception as e:
        logger.error(f"Error generating CSV template: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error generating CSV template",
            error=str(e)
        )

@router.get("/sample-template/json", response_model=StandardResponse)
async def get_all_predefined_test_cases(
    db: Session = Depends(get_db)
):
    """Get all predefined test cases without any filtering"""
    try:
        test_cases = db.query(PredefinedTestCase).all()
        
        test_cases_data = []
        for case in test_cases:
            test_cases_data.append({
                "id": case.id,
                "test_prompt": case.test_prompt,
                "expected_answer": case.expected_answer,
                "test_category": case.test_category,
                "difficulty_level": case.difficulty_level,
                "evaluation_criteria": case.evaluation_criteria,
                "created_at": case.created_at.isoformat() if case.created_at else None,
                "updated_at": case.updated_at.isoformat() if case.updated_at else None
            })
        
        categories = {}
        difficulties = {}
        
        for case in test_cases:
            if case.test_category:
                categories[case.test_category] = categories.get(case.test_category, 0) + 1
            if case.difficulty_level:
                difficulties[case.difficulty_level] = difficulties.get(case.difficulty_level, 0) + 1
        
        response_data = {
            "test_cases": test_cases_data,
            "total_count": len(test_cases_data),
            "statistics": {
                "by_category": categories,
                "by_difficulty": difficulties,
                "unique_categories": list(categories.keys()),
                "unique_difficulty_levels": list(difficulties.keys())
            }
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message=f"Successfully retrieved all {len(test_cases_data)} predefined test cases",
            data=response_data
        )
        
    except Exception as e:
        logger.error(f"Error retrieving all predefined test cases: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error retrieving all predefined test cases",
            error=str(e)
        )
    
@router.get("/health", response_model=StandardResponse)
async def health_check():
    """Health check endpoint for model evaluation service"""
    try:
        api_status = {
            "groq": "available" if os.getenv("GROQ_API_KEY") else "not_configured",
            "openai": "available" if os.getenv("AZURE_OPENAI_API_KEY") else "not_configured",
            "gemini": "available" if os.getenv("GEMINI_API_KEY") else "not_configured",
            "bedrock": "available" if os.getenv("AWS_ACCESS_KEY_ID") and os.getenv("AWS_SECRET_ACCESS_KEY") else "not_configured",
        }
        
        total_available_models = 0
        for provider in api_status:
            if api_status.get(provider) == "available":
                total_available_models += len(ModelEvaluator.SUPPORTED_MODELS.get(provider, {}))
        
        health_data = {
            "status": "healthy",
            "api_services": api_status,
            "total_available_models": total_available_models,
            "supported_file_formats": test_data_processor.supported_extensions,
            "timestamp": datetime.utcnow()
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Model evaluation service is healthy",
            data=health_data
        )
        
    except Exception as e:
        logger.error(f"Error in health check: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Health check failed",
            error=str(e)
        )
    
price_calculator = PriceCalculator()

@router.post("/pricing")
async def calculate_model_pricing(
    request: PricingRequest,
):
    """
    Calculate pricing for AI model inference based on token usage
    """
    try:
        supported_models = price_calculator.get_supported_models()
        if request.model_id not in supported_models:
            return standard_response(
                status_code=status.HTTP_400_BAD_REQUEST,
                success=False,
                message=f"Model '{request.model_id}' not supported",
                error=f"Supported models: {', '.join(supported_models)}"
            )
        
        input_cost = price_calculator.calculate_input_price(request.input_tokens, request.model_id)
        output_cost = price_calculator.calculate_output_price(request.output_tokens, request.model_id)
        total_cost_per_invocation = price_calculator.calculate_total_price(
            request.input_tokens, 
            request.output_tokens, 
            request.model_id
        )       
        
        total_cost_all_invocations = total_cost_per_invocation * request.invocations
        
        model_provider = "unknown"
        for provider, models in ModelEvaluator.SUPPORTED_MODELS.items():
            if request.model_id in models:
                model_provider = provider
                break
        
        cost_breakdown = {
            "input_cost_per_1k_tokens": price_calculator.model_input_token_prices.get(request.model_id, 0),
            "output_cost_per_1k_tokens": price_calculator.model_output_token_prices.get(request.model_id, 0),
            "input_cost_calculation": f"({request.input_tokens} tokens / 1000) × ${price_calculator.model_input_token_prices.get(request.model_id, 0)}",
            "output_cost_calculation": f"({request.output_tokens} tokens / 1000) × ${price_calculator.model_output_token_prices.get(request.model_id, 0)}",
            "cost_per_invocation": {
                "input": input_cost,
                "output": output_cost,
                "total": total_cost_per_invocation
            },
            "cost_scaling": {
                "100_invocations": total_cost_per_invocation * 100,
                "1000_invocations": total_cost_per_invocation * 1000,
                "10000_invocations": total_cost_per_invocation * 10000
            }
        }
        
        pricing_data = {
            "model_id": request.model_id,
            "input_tokens": request.input_tokens,
            "output_tokens": request.output_tokens,
            "invocations": request.invocations,
            "input_cost": input_cost,
            "output_cost": output_cost,
            "total_cost_per_invocation": total_cost_per_invocation,
            "total_cost_all_invocations": total_cost_all_invocations,
            "cost_breakdown": cost_breakdown,
            "model_provider": model_provider,
            "timestamp": datetime.utcnow()
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Pricing calculated successfully",
            data=pricing_data
        )
        
    except Exception as e:
        logger.error(f"Error calculating pricing: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error calculating pricing",
            error=str(e)
        )

@router.get("/pricing/models")
async def get_pricing_models():
    """Get all models available for pricing calculation with their rates"""
    try:
        supported_models = price_calculator.get_supported_models()
        
        models_with_pricing = []
        for model_id in supported_models:
            input_price = price_calculator.model_input_token_prices.get(model_id, 0)
            output_price = price_calculator.model_output_token_prices.get(model_id, 0)
            
            provider = "unknown"
            model_name = model_id
            for prov, models in ModelEvaluator.SUPPORTED_MODELS.items():
                if model_id in models:
                    provider = prov
                    model_name = models[model_id]
                    break
            
            models_with_pricing.append({
                "model_id": model_id,
                "model_name": model_name,
                "provider": provider,
                "input_price_per_1k_tokens": input_price,
                "output_price_per_1k_tokens": output_price,
                "currency": "USD"
            })
        
        models_with_pricing.sort(key=lambda x: (x["provider"], x["input_price_per_1k_tokens"]))
        
        models_data = {
            "models": models_with_pricing,
            "total_models": len(models_with_pricing),
            "providers": list(set(model["provider"] for model in models_with_pricing)),
            "pricing_notes": {
                "currency": "USD",
                "unit": "per 1000 tokens",
                "calculation": "Actual cost = (tokens / 1000) × price_per_1k_tokens"
            }
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Pricing models retrieved successfully",
            data=models_data
        )
        
    except Exception as e:
        logger.error(f"Error getting pricing models: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error getting pricing models",
            error=str(e)
        )

@router.post("/pricing/compare")
async def compare_model_pricing(
    input_tokens: int = Form(..., description="Number of input tokens"),
    output_tokens: int = Form(..., description="Number of output tokens"),
    models: str = Form(..., description="Comma-separated list of models to compare"),
    invocations: int = Form(1, description="Number of invocations"),
):
    """
    Compare pricing across multiple models for the same token usage
    """
    try:
        model_list = [model.strip() for model in models.split(",") if model.strip()]
        
        if not model_list:
            return standard_response(
                status_code=status.HTTP_400_BAD_REQUEST,
                success=False,
                message="No models specified for comparison",
                error="Models parameter is required and cannot be empty"
            )
        
        pricing_results = []
        supported_models = price_calculator.get_supported_models()
        
        for model_id in model_list:
            if model_id not in supported_models:
                continue
                
            input_cost = price_calculator.calculate_input_price(input_tokens, model_id)
            output_cost = price_calculator.calculate_output_price(output_tokens, model_id)
            total_cost = price_calculator.calculate_total_price(input_tokens, output_tokens, model_id)
            total_cost_all = total_cost * invocations
            
            provider = "unknown"
            model_name = model_id
            for prov, models_dict in ModelEvaluator.SUPPORTED_MODELS.items():
                if model_id in models_dict:
                    provider = prov
                    model_name = models_dict[model_id]
                    break
            
            pricing_results.append({
                "model_id": model_id,
                "model_name": model_name,
                "provider": provider,
                "input_cost": input_cost,
                "output_cost": output_cost,
                "total_cost_per_invocation": total_cost,
                "total_cost_all_invocations": total_cost_all,
                "input_price_per_1k": price_calculator.model_input_token_prices.get(model_id, 0),
                "output_price_per_1k": price_calculator.model_output_token_prices.get(model_id, 0)
            })
        
        if not pricing_results:
            return standard_response(
                status_code=status.HTTP_400_BAD_REQUEST,
                success=False,
                message="No valid models found for comparison",
                error="None of the specified models are supported"
            )
        
        pricing_results.sort(key=lambda x: x["total_cost_all_invocations"])
        
        cheapest = pricing_results[0]
        most_expensive = pricing_results[-1]
        
        cost_savings = {
            "cheapest_model": cheapest["model_id"],
            "most_expensive_model": most_expensive["model_id"],
            "cost_difference": most_expensive["total_cost_all_invocations"] - cheapest["total_cost_all_invocations"],
            "savings_percentage": ((most_expensive["total_cost_all_invocations"] - cheapest["total_cost_all_invocations"]) / most_expensive["total_cost_all_invocations"] * 100) if most_expensive["total_cost_all_invocations"] > 0 else 0
        }
        
        comparison_data = {
            "comparison_results": pricing_results,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "invocations": invocations,
            "cost_savings": cost_savings,
            "recommendations": {
                "most_cost_effective": cheapest["model_id"],
                "provider_breakdown": {
                    provider: [r for r in pricing_results if r["provider"] == provider]
                    for provider in set(r["provider"] for r in pricing_results)
                }
            },
            "timestamp": datetime.utcnow()
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Model pricing comparison completed successfully",
            data=comparison_data
        )
        
    except Exception as e:
        logger.error(f"Error comparing model pricing: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error comparing model pricing",
            error=str(e)
        )

@router.get("/get_model_evaluation/{use_case_id}")
async def get_model_evaluation(
    use_case_id: int,
    db: Session = Depends(get_db)
):
    """
    Get model evaluation summary and details for given use_case_id
    """
    try:
        use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == use_case_id).first()
        if not use_case:
            raise HTTPException(status_code=404, detail=f"Use case {use_case_id} not found")

        model_evaluation = db.query(ModelEvaluation).filter(ModelEvaluation.usecase_id == use_case_id).first()
        if not model_evaluation:
            raise HTTPException(status_code=404, detail="Model evaluation not found for use case")

        selected_models = db.query(SelectedModel).filter(SelectedModel.model_evaluation_id == model_evaluation.id).all()

        models = []
        api_keys = {}
        use_llm_judge = None
        max_tokens = None
        temperature = None
        timeout = None
        max_retries = None

        for sm in selected_models:
            if sm.llm_model:
                models.append(sm.llm_model.model_code)
            api_keys[sm.llm_model.llm_provider] = sm.llm_key
            if use_llm_judge is None:
                use_llm_judge = sm.use_llm_as_judge
            if max_tokens is None:
                max_tokens = sm.max_tokens
            if temperature is None:
                temperature = float(sm.temperature) if sm.temperature is not None else None
            if timeout is None:
                timeout = sm.timeout
            if max_retries is None:
                max_retries = sm.max_retries

        test_cases_query = db.query(TestCase).filter(TestCase.model_evaluation_id == model_evaluation.id).all()
        test_cases = []
        for tc in test_cases_query:
            test_cases.append({
                "test_prompt": tc.test_prompt,
                "expected_answer": tc.expected_answer,
                "test_category": tc.test_category,
                "difficulty_level": tc.difficulty_level,
                "evaluation_criteria": tc.evaluation_criteria,
                "test_case_type": tc.test_case_type
            })

        pdf_report_path = None
        if model_evaluation.generated_pdf_report_id:
            pdf_report = db.query(AssessmentReport).filter(AssessmentReport.id == model_evaluation.generated_pdf_report_id).first()
            if pdf_report:
                pdf_report_path = pdf_report.report_path

        model_rankings = db.query(ModelRanking).filter(ModelRanking.model_evaluation_id == model_evaluation.id).order_by(ModelRanking.rank).all()

        overall_results = {
            "total_models": model_evaluation.model_tested_count,
            "total_test_cases": model_evaluation.test_cases_count,
            "best_performing_model": model_evaluation.best_model,
            "worst_performing_model": None,
            "overall_average_score": None,
            "overall_average_accuracy": float(model_evaluation.average_accuracy) if model_evaluation.average_accuracy else 0.0,
            "performance_variance": None,
            "model_rankings": []
        }

        scores = []
        worst_score = float('inf')
        worst_model = None
        for ranking in model_rankings:
            avg_score = float(ranking.average_score) if ranking.average_score else 0.0
            scores.append(avg_score)
            if avg_score < worst_score:
                worst_score = avg_score
                worst_model = ranking.model
            overall_results["model_rankings"].append({
                "rank": ranking.rank,
                "model_name": ranking.model,
                "average_score": avg_score,
                "accuracy_percentage": float(ranking.binary_score) if ranking.binary_score else 0.0,
                "average_response_time": float(ranking.average_response_time) if ranking.average_response_time else 0.0
            })

        overall_results["worst_performing_model"] = worst_model or "N/A"
        if scores and len(scores) > 1:
            mean = sum(scores) / len(scores)
            variance = sum((x - mean) ** 2 for x in scores) / len(scores)
            overall_results["overall_average_score"] = mean
            overall_results["performance_variance"] = variance ** 0.5
        elif scores:
            overall_results["overall_average_score"] = scores[0]
            overall_results["performance_variance"] = 0.0

        detailed_results = []
        test_case_results = db.query(TestCaseResult).join(ModelRanking).filter(
            ModelRanking.model_evaluation_id == model_evaluation.id
        ).all()

        prompt_to_answer = {tc.test_prompt: tc.expected_answer for tc in test_cases_query}

        for result in test_case_results:
            detailed_results.append({
                "model_name": result.model_ranking.model,
                "prompt": result.test,
                "ground_truth": prompt_to_answer.get(result.test, "N/A"),
                "response": result.response,
                "is_correct": result.is_correct,
                "accuracy_score": float(result.score) if result.score else 0.0,
                "response_time": float(result.response_time) if result.response_time else 0.0,
                "judge_explanation": result.judge_explanation
            })

        response_data = {
            "model_evaluation_id": model_evaluation.id,
            "total_test_cases": model_evaluation.test_cases_count,
            "models_evaluated": models,
            "api_keys": api_keys,
            "use_llm_judge": use_llm_judge,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "timeout": timeout,
            "max_retries": max_retries,
            "overall_results": overall_results,
            "detailed_results": detailed_results,
            "generated_pdf_report_path": pdf_report_path,
            "test_cases": test_cases,
            "evaluation_summary": model_evaluation.evaluation_summary_md
        }

        return JSONResponse(status_code=200, content={"success": True, "data": response_data})

    except Exception as e:
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"success": False, "error": str(e), "message": "Failed to get model evaluation"}
        )