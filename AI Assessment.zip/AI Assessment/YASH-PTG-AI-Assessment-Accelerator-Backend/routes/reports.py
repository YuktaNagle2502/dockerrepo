from fastapi import APIRouter, Depends, HTTPException, status, Response, UploadFile, File, Form, Request
from fastapi.responses import StreamingResponse, JSONResponse
from sqlalchemy.orm import Session
from typing import List, Optional, Any
from models.models import User, Project, AssessmentReport, GeneratedUseCase, PreWorkshopSession, DataCompliance
from database import get_db
from services.report_service import UniversalReportManager, ReportListItem, ReportResponse
from utils.report_utils import get_module_reports
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, ConfigDict
from datetime import datetime, timedelta
import os
from models.pydantic_models import StandardResponse,standard_response
from utils.s3_utils import generate_presigned_get_urls, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, BUCKET_NAME
import logging
import asyncio

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Store expiration timestamps in memory (key: report_id, value: expires_at)
url_expirations = {}

reports_router = APIRouter(prefix="/reports", tags=["Reports"])

async def get_current_user(keycloak_payload: dict, db: Session = Depends(get_db)) -> User:
    """Get the current user from the Keycloak token payload"""
   
    # Extract email from Keycloak token payload
    email = keycloak_payload.get("email") or keycloak_payload.get("preferred_username")
    if not email:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload: email not found")
    # Query the database for the user
    user = db.query(User).filter(User.email == email, User.is_active == True).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found or inactive")
    return user

def _refresh_report_presigned_url(report: AssessmentReport) -> tuple[str, datetime]:
    """Regenerate presigned URL if expired or about to expire"""
    report_id = report.id
    s3_key = report.report_path
    if not s3_key:
        return None, None
    
    # Check if URL is expired or about to expire (within 1 hour)
    current_time = datetime.utcnow()
    expires_at = url_expirations.get(report_id)
    logger.info(f"Checking expiration for report {report_id}: expires_at={expires_at}")
    if expires_at and expires_at > current_time + timedelta(hours=1):
        logger.info(f"URL for report {report_id} is still valid, returning existing")
        # Regenerate URL since we don't store it
        pass
    
    # Regenerate URL
    logger.info(f"Regenerating URL for report {report_id}")
    result = generate_presigned_get_urls(
        bucket_name=BUCKET_NAME,
        object_paths=[s3_key],
        access_key=AWS_ACCESS_KEY_ID,
        secret_key=AWS_SECRET_ACCESS_KEY,
        region=AWS_REGION,
        expiration=604800  # 7 days
    )[0]
    if result['status'] == 'success':
        url_expirations[report_id] = result['expires_at']
        logger.info(f"New URL for report {report_id} expires at {result['expires_at'].isoformat()}")
        return result['url'], result['expires_at']
    else:
        logger.error(f"Failed to regenerate URL for report {report_id}: {result['error']}")
        return None, None

@reports_router.get("/user")
async def get_user_all_reports(
    request: Request,
    db: Session = Depends(get_db)
):
    """Get all reports for the current user"""
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        manager = UniversalReportManager(db)
        reports = manager.get_user_reports(current_user.id)
        
        reports_data = [
            {
                "id": report.id,
                "report_uuid": report.report_uuid,
                "module_name": report.module_name,
                "module_entity_id": report.module_entity_id,
                "report_name": report.report_name,
                "report_type": report.report_type,
                "file_size": report.file_size,
                "created_at": report.created_at,
                "project_id": report.project_id
            }
            for report in reports
        ]
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="User reports retrieved successfully",
            data=reports_data
        )
    except HTTPException as e:
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Internal server error",
            error={"type": "Exception", "detail": str(e)}
        )

@reports_router.get("/project/{project_id}")
async def get_project_reports(
    project_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """Get all reports for a specific project"""
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        manager = UniversalReportManager(db)
        reports = manager.get_reports_by_project(current_user.id, project_id)
        
        reports_data = [
            {
                "id": report.id,
                "report_uuid": report.report_uuid,
                "module_name": report.module_name,
                "module_entity_id": report.module_entity_id,
                "report_name": report.report_name,
                "report_type": report.report_type,
                "file_size": report.file_size,
                "created_at": report.created_at
            }
            for report in reports
        ]
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message=f"Project reports retrieved successfully for project {project_id}",
            data=reports_data
        )
    except HTTPException as e:
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Internal server error",
            error={"type": "Exception", "detail": str(e)}
        )

@reports_router.get("/module/{module_name}")
async def get_module_all_reports(
    request: Request,
    module_name: str,
    module_entity_id: Optional[int] = None,
    project_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """Get reports for a specific module"""
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        module_reports = get_module_reports(
            db=db,
            user_id=current_user.id,
            module_name=module_name,
            module_entity_id=module_entity_id,
            project_id=project_id
        )
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message=f"Module reports retrieved successfully for module {module_name}",
            data=module_reports
        )
    except HTTPException as e:
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Internal server error",
            error={"type": "Exception", "detail": str(e)}
        )

@reports_router.get("/download/{report_uuid}")
async def download_report(
    report_uuid: str,
    request: Request,
    db: Session = Depends(get_db)
):
    """Download a report by its UUID"""
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        manager = UniversalReportManager(db)
        report = manager.get_report_by_uuid(report_uuid, current_user.id)
        
        if not report:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Report not found",
                error={"type": "NotFound", "detail": "Report not found"}
            )
        
        # Create filename
        extension = report.report_type
        filename = f"{report.report_name.replace(' ', '_')}.{extension}"
        
        # Return file as streaming response
        def iterfile():
            yield report.file_content
        
        return StreamingResponse(
            iterfile(),
            media_type=report.mime_type,
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
    except HTTPException as e:
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Internal server error",
            error={"type": "Exception", "detail": str(e)}
        )

@reports_router.delete("/{report_uuid}")
async def delete_report(
    report_uuid: str,
    request: Request,
    db: Session = Depends(get_db)
):
    """Delete a report"""
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        manager = UniversalReportManager(db)
        success = manager.delete_report(report_uuid, current_user.id)
        
        if not success:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Report not found",
                error={"type": "NotFound", "detail": "Report not found"}
            )
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Report deleted successfully",
            data={"report_uuid": report_uuid}
        )
    except HTTPException as e:
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Internal server error",
            error={"type": "Exception", "detail": str(e)}
        )

@reports_router.post("/save")
async def save_report_to_database(
    request: Request,
    file: UploadFile = File(...),
    user_id: int = Form(...),
    project_id: int = Form(...),
    module_name: str = Form(...),
    module_entity_id: int = Form(...),
    report_name: str = Form(...),
    report_type: str = Form(default="pdf"),
    db: Session = Depends(get_db)
):
    """
    Save a report file to the database
    
    Frontend usage:
    const formData = new FormData();
    formData.append('file', fileObject);
    formData.append('user_id', userId);
    formData.append('project_id', projectId);
    formData.append('module_name', 'pre_workshop');
    formData.append('module_entity_id', sessionId);
    formData.append('report_name', 'My Report');
    formData.append('report_type', 'pdf');
    
    fetch('/reports/save', {
        method: 'POST',
        body: formData
    })
    """
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        
        # Verify user owns the project
        project = db.query(Project).filter(
            Project.id == project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        
        if not project:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Project not found or access denied",
                error={"type": "NotFound", "detail": "Project not found or access denied"}
            )
        
        # Read file content
        file_content = await file.read()
        
        # Auto-detect report type from filename if not provided
        if report_type == "pdf" and file.filename:
            file_extension = file.filename.split('.')[-1].lower()
            if file_extension in ['json', 'xlsx', 'html', 'txt', 'csv', 'docx']:
                report_type = file_extension
        
        # Save report using the helper function
        manager = UniversalReportManager(db)
        report = manager.save_report(
            user_id=user_id,
            project_id=project_id,
            module_name=module_name,
            module_entity_id=module_entity_id,
            report_name=report_name,
            file_content=file_content,
            report_type=report_type
        )
        
        # Convert report to dict for response
        report_data = {
            "id": report.id,
            "report_uuid": report.report_uuid,
            "module_name": report.module_name,
            "module_entity_id": report.module_entity_id,
            "report_name": report.report_name,
            "report_type": report.report_type,
            "file_size": report.file_size,
            "created_at": report.created_at
        }
        
        return standard_response(
            status_code=status.HTTP_201_CREATED,
            success=True,
            message="Report saved successfully",
            data=report_data
        )
        
    except HTTPException as e:
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message=f"Error saving report: {str(e)}",
            error={"type": "Exception", "detail": str(e)}
        )

@reports_router.get("/usecase/{use_case_id}/presigned-urls")
async def get_usecase_presigned_urls(
    use_case_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """
    Get presigned URLs for all reports (data readiness, AI profiling, sprint planning, model evaluation, compliance)
    associated with a specific use case ID, with automatic URL refresh if expired.
    """
    try:
        # Authenticate user
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)

        # Validate use case exists and user has access
        use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == use_case_id).first()
        if not use_case:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error={"type": "NotFound", "detail": f"Use case with ID {use_case_id} not found"}
            )

        # Validate session exists
        session = db.query(PreWorkshopSession).filter(PreWorkshopSession.id == use_case.session_id).first()
        if not session:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error={"type": "NotFound", "detail": "Session not found"}
            )

        # Validate project ownership
        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        if not project:
            return standard_response(
                status_code=status.HTTP_403_FORBIDDEN,
                success=False,
                message="Access denied",
                error={"type": "AccessDenied", "detail": "User does not have permission to access this use case"}
            )

        # Check S3 configuration
        if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
            return standard_response(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                success=False,
                message="S3 credentials not configured",
                error={"type": "ConfigurationError", "detail": "S3 credentials not configured"}
            )

        # Initialize response data
        response_data = {
            "use_case_id": use_case_id,
            "reports": {
                "data_readiness": [],
                "ai_profiling": [],
                "sprint_planning": [],
                "model_evaluation": [],
                "compliance": []
            }
        }

        # Track processed report IDs to avoid duplicates
        processed_report_ids = set()

        # Get all AssessmentReport records for the use case (excluding compliance)
        assessment_reports = db.query(AssessmentReport).filter(
            AssessmentReport.usecase_id == use_case_id,
            AssessmentReport.report_type == "pdf"
        ).all()

        # Process AssessmentReport records
        for report in assessment_reports:
            if report.assessment_stage not in response_data["reports"]:
                continue  # Skip if stage is not one of the expected ones

            if report.id in processed_report_ids:
                logger.warning(f"Skipping duplicate report ID {report.id} for stage {report.assessment_stage}")
                continue

            presigned_url, expires_at = _refresh_report_presigned_url(report)
            if not presigned_url:
                logger.warning(f"Failed to generate presigned URL for report {report.id}")
                continue

            report_data = {
                "report_id": report.id,
                "report_filename": report.report_filename,
                "assessment_stage": report.assessment_stage,
                "report_type": report.report_type,
                "report_mimetype": report.report_mimetype,
                "presigned_url": presigned_url,
                "expires_at": expires_at.isoformat() if expires_at else None,
                "created_at": report.created_at.isoformat() if report.created_at else None
            }
            response_data["reports"][report.assessment_stage].append(report_data)
            processed_report_ids.add(report.id)

        # Get all DataCompliance records for the use case
        compliance_records = db.query(DataCompliance).filter(
            DataCompliance.usecase_id == use_case_id
        ).all()

        # Process compliance reports
        for compliance in compliance_records:
            if not compliance.generated_pdf_report_id:
                logger.info(f"No PDF report for compliance ID {compliance.id}")
                continue

            report = db.query(AssessmentReport).filter(
                AssessmentReport.id == compliance.generated_pdf_report_id,
                AssessmentReport.report_type == "pdf"
            ).first()

            if not report:
                logger.warning(f"No PDF report found for compliance ID {compliance.id}")
                continue

            if report.id in processed_report_ids:
                logger.warning(f"Skipping duplicate compliance report ID {report.id} for compliance ID {compliance.id}")
                continue

            presigned_url, expires_at = _refresh_report_presigned_url(report)
            if not presigned_url:
                logger.warning(f"Failed to generate presigned URL for compliance report {report.id}")
                continue

            report_data = {
                "report_id": report.id,
                "report_filename": report.report_filename,
                "assessment_stage": "compliance",
                "report_type": report.report_type,
                "report_mimetype": report.report_mimetype,
                "presigned_url": presigned_url,
                "expires_at": expires_at.isoformat() if expires_at else None,
                "created_at": report.created_at.isoformat() if report.created_at else None
            }
            response_data["reports"]["compliance"].append(report_data)
            processed_report_ids.add(report.id)

        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Presigned URLs for use case reports retrieved successfully",
            data=response_data
        )

    except HTTPException as e:
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        logger.error(f"Error retrieving presigned URLs: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error retrieving presigned URLs",
            error={"type": "Exception", "detail": str(e)}
        )