from typing import List
from fastapi import APIRouter, Depends, HTTPException, Query, status, UploadFile, File, Form, Response, Request
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from database import get_db
from models.models import User, Project, GeneratedUseCase, PreWorkshopSession, DataCompliance, DataComplianceDocument, AssessmentReport
from services.compliance_service import ComplianceAnalyzer
from utils.compliance_utils import FileProcessor, SimpleCompliancePDFGenerator
from models.pydantic_models import StandardResponse, standard_response
from utils.s3_utils import upload_file, generate_presigned_get_urls, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, BUCKET_NAME
import os
import json
import shutil
import tempfile
import asyncio
import boto3
import logging
from botocore.exceptions import ClientError

router = APIRouter(prefix="/compliance", tags=["Compliance & Integration"])

# Get API key from environment
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    print("Warning: GROQ_API_KEY not found in environment variables")

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Store expiration timestamps in memory (key: report_id, value: expires_at)
url_expirations = {}

file_processor = FileProcessor()
pdf_generator = SimpleCompliancePDFGenerator()

async def get_current_user(keycloak_payload: dict, db: Session = Depends(get_db)) -> User:
    """Get the current user from the Keycloak token payload"""
    email = keycloak_payload.get("email") or keycloak_payload.get("preferred_username")
    if not email:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload: email not found")
    user = db.query(User).filter(User.email == email, User.is_active == True).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found or inactive")
    return user

def _refresh_report_presigned_url(report: AssessmentReport) -> tuple[str, datetime]:
    """Regenerate presigned URL if expired or about to expire"""
    report_id = report.id
    s3_key = report.report_path
    if not s3_key:
        return None, None

    # Check if URL is expired or about to expire (within 1 hour)
    current_time = datetime.utcnow()
    expires_at = url_expirations.get(report_id)
    logger.info(f"Checking expiration for report {report_id}: expires_at={expires_at}")
    if expires_at and expires_at > current_time + timedelta(hours=1):
        logger.info(f"URL for report {report_id} is still valid, returning existing")
        # We need to regenerate the URL since we don't store it
        pass

    # Regenerate URL
    logger.info(f"Regenerating URL for report {report_id}")
    result = generate_presigned_get_urls(
        bucket_name=BUCKET_NAME,
        object_paths=[s3_key],
        access_key=AWS_ACCESS_KEY_ID,
        secret_key=AWS_SECRET_ACCESS_KEY,
        region=AWS_REGION,
        expiration=604800  # 7 days
    )[0]
    if result['status'] == 'success':
        url_expirations[report_id] = result['expires_at']
        logger.info(f"New URL for report {report_id} expires at {result['expires_at'].isoformat()}")
        return result['url'], result['expires_at']
    else:
        logger.error(f"Failed to regenerate URL for report {report_id}: {result['error']}")
        return None, None



async def save_analysis_document(file: UploadFile, analysis_id: int, analysis_type: str, db: Session = Depends(get_db)) -> str:
    """Save uploaded file to S3 and return the S3 key"""
    if analysis_type != 'compliance':
        raise ValueError("Only 'compliance' analysis type is supported for S3 upload")
    
    # Retrieve project name
    data_compliance = db.query(DataCompliance).filter(DataCompliance.id == analysis_id).first()
    if not data_compliance:
        raise HTTPException(status_code=404, detail="Data compliance record not found")
    use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == data_compliance.usecase_id).first()
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    session = db.query(PreWorkshopSession).filter(PreWorkshopSession.id == use_case.session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    project = db.query(Project).filter(Project.id == session.project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Read file content
    file.file.seek(0)
    file_content = await file.read()
    
    if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
        raise HTTPException(status_code=500, detail="S3 credentials not configured")
    
    # Set folder_prefix for compliance documents
    folder_prefix = 'data_compliance/documents'
    
    # Use analysis_id as session_id, and a fixed session_name
    session_id = analysis_id
    session_name = 'analysis'
    
    # Upload to S3
    loop = asyncio.get_event_loop()
    s3_key, presigned_url, expires_at = await loop.run_in_executor(
        None,
        lambda: upload_file(
            BUCKET_NAME,
            file_content,
            session_id,
            session_name,
            file.filename,
            AWS_ACCESS_KEY_ID,
            AWS_SECRET_ACCESS_KEY,
            AWS_REGION,
            folder_prefix=folder_prefix,
            expiration=604800,  # 7 days
            project_name=project.name  # Pass project name
        )
    )
    
    return s3_key

@router.post("/analyze")
async def analyze_compliance(
    request: Request,
    use_case_id: int = Form(...),
    files: List[UploadFile] = File(...),
    db: Session = Depends(get_db)
):
    """
    Generate compliance analysis report from data files and use case
    
    This endpoint:
    1. Processes the uploaded data files (multiple files supported)
    2. Retrieves use case information
    3. Generates comprehensive compliance analysis using AI
    4. Returns markdown-formatted report content
    
    Parameters:
    - use_case_id: Form field with the use case ID
    - files: Upload files (any supported format, multiple files allowed)
    """
    if not GROQ_API_KEY:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="AI service not configured",
            error={"type": "ServiceUnavailable", "detail": "AI service not configured"}
        )

    try:
        # Get current user and validate permissions
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        
        # Validate use case exists and user has access
        use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == use_case_id).first()
        if not use_case:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error={"type": "NotFound", "detail": "Use case not found"}
            )

        # Validate session exists
        session = db.query(PreWorkshopSession).filter(
            PreWorkshopSession.id == use_case.session_id
        ).first()

        if not files or len(files) == 0:
            return standard_response(
                status_code=status.HTTP_400_BAD_REQUEST,
                success=False,
                message="At least one file must be uploaded",
                error={"type": "NotFound", "detail": "At least one file must be uploaded"}
            )
        
        if not session:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error={"type": "NotFound", "detail": "Session not found"}
            )

        # Validate project ownership
        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        if not project:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Access denied",
                error={"type": "AccessDenied", "detail": "Access denied"}
            )

        # Process the uploaded files
        temp_dir = tempfile.mkdtemp()
        try:
            file_infos = []
            uploaded_docs = []
            for file in files:
                file_path = await file_processor.save_uploaded_file(file, temp_dir)
                file_info = await file_processor.process_file(file_path, file.filename)
                file_infos.append(file_info)

            # Prepare use case data for analysis
            use_case_data = {
                'id': use_case.id,
                'title': use_case.title,
                'description': use_case.description,
                'aws_services': use_case.aws_services,
                'primary_genai_capability': use_case.primary_genai_capability,
                'business_category': use_case.business_category,
                'customer_pain_points': use_case.customer_pain_points,
                'priority': use_case.priority,
                'complexity': use_case.complexity,
                'dependencies': use_case.dependencies,
                'risks': use_case.risks
            }

            # Run compliance analysis
            analyzer = ComplianceAnalyzer(GROQ_API_KEY)
            analysis_result = await analyzer.analyze_compliance(use_case_data, file_infos, "comprehensive")
            
            # Create Compliance record
            existing_compliance = db.query(DataCompliance).filter(
                DataCompliance.usecase_id == use_case_id
            ).first()
            
            if existing_compliance:
                # Update existing record
                existing_compliance.overall_score = analysis_result.get('compliance_score')
                existing_compliance.risk_level = analysis_result.get('risk_level')
                existing_compliance.analysis_type = "comprehensive"
                existing_compliance.analysis_report_text_md = analysis_result.get('generated_content')
                existing_compliance.recommendation_count = analysis_result.get('recommendations_count')
                existing_compliance.risk_assessment_text_md = analysis_result.get('risk_assessment')
                
                compliance_record = existing_compliance
            else:
                # Create new Compliance record
                compliance_record = DataCompliance(
                    usecase_id=use_case_id,
                    overall_score=analysis_result.get('compliance_score'),
                    risk_level=analysis_result.get('risk_level'),
                    analysis_type="comprehensive",
                    analysis_report_text_md=analysis_result.get('generated_content'),
                    recommendation_count=analysis_result.get('recommendations_count'),
                    risk_assessment_text_md=analysis_result.get('risk_assessment')
                )
                db.add(compliance_record)
            
            db.commit()
            db.refresh(compliance_record)

            for file in files:
                # Save the uploaded document
                document_path = await save_analysis_document(file, compliance_record.id, "compliance", db)
                
                # Check if document with same filename already exists for this compliance record
                existing_doc = db.query(DataComplianceDocument).filter(
                    DataComplianceDocument.data_compliance_id == compliance_record.id,
                    DataComplianceDocument.filename == file.filename
                ).first()
                
                if existing_doc:
                    # Update existing document record with new path
                    existing_doc.mimetype = file.content_type
                    existing_doc.path = document_path
                    
                    uploaded_docs.append({
                        "filename": existing_doc.filename,
                        "mimetype": existing_doc.mimetype,
                        "path": existing_doc.path,
                        "is_updated": True
                    })
                else:
                    # Create new document record
                    compliance_doc = DataComplianceDocument(
                        data_compliance_id=compliance_record.id,
                        filename=file.filename,
                        mimetype=file.content_type,
                        path=document_path
                    )
                    db.add(compliance_doc)
                    
                    uploaded_docs.append({
                        "filename": file.filename,
                        "mimetype": file.content_type,
                        "path": document_path,
                        "is_updated": False
                    })

            use_case.data_compliance_status = "Completed"
            if use_case.ai_profiling_status == "Pending":
                use_case.ai_profiling_status = "In Progress"
            db.commit()

            # Prepare response data
            response_data = {
                "compliance_id": compliance_record.id,
                "use_case_id": use_case_id,
                "overall_score": compliance_record.overall_score,
                "risk_level": compliance_record.risk_level,
                "analysis_type": compliance_record.analysis_type,
                "analysis_report": compliance_record.analysis_report_text_md,
                "risk_assessment": compliance_record.risk_assessment_text_md,
                "documents_uploaded": uploaded_docs,
                "reports_generated": {
                    "pdf_report_id": compliance_record.generated_pdf_report_id,
                    "json_report_id": compliance_record.generated_json_report_id,
                    "excel_report_id": compliance_record.generated_excel_report_id
                }
            }

            return standard_response(
                status_code=status.HTTP_200_OK,
                success=True,
                message="Data compliance analysis completed successfully",
                data=response_data
            )

        finally:
            # Clean up temporary directory
            shutil.rmtree(temp_dir, ignore_errors=True)

    except HTTPException as e:
        db.rollback()
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        db.rollback()
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message=f"Error analyzing data compliance: {str(e)}",
            error={"type": "Exception", "detail": str(e)}
        )

@router.post("/generate-pdf")
async def generate_compliance_pdf(
    request: Request,
    compliance_id: int = Query(..., description="The ID of the compliance analysis record"),
    use_case_id: int = Query(..., description="The ID of the use case"),
    db: Session = Depends(get_db)
):
    """
    Generate or fetch a PDF report for compliance analysis and return a presigned URL for download.
    
    Parameters:
    - compliance_id: The ID of the compliance analysis record
    - use_case_id: The ID of the use case (for validation and organization)
    """
    try:
        if not GROQ_API_KEY:
            return standard_response(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                success=False,
                message="AI service not configured",
                error={"type": "ServiceUnavailable", "detail": "AI service not configured"}
            )

        if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
            return standard_response(
                status_code=500,
                success=False,
                message="S3 credentials not configured",
                error={"type": "ConfigurationError", "detail": "S3 credentials not configured"}
            )

        # Get current user and validate permissions
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)

        # Get compliance record with relationships
        compliance_record = db.query(DataCompliance).filter(
            DataCompliance.id == compliance_id,
            DataCompliance.usecase_id == use_case_id
        ).first()
        
        if not compliance_record:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Compliance analysis not found or doesn't match the use case",
                error={"type": "NotFound", "detail": "Compliance analysis not found or doesn't match the use case"}
            )

        # Validate user has access to this compliance analysis through use case ownership
        use_case = db.query(GeneratedUseCase).filter(
            GeneratedUseCase.id == compliance_record.usecase_id
        ).first()
        
        if not use_case:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error={"type": "NotFound", "detail": "Use case not found"}
            )

        session = db.query(PreWorkshopSession).filter(
            PreWorkshopSession.id == use_case.session_id
        ).first()
        if not session:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error={"type": "NotFound", "detail": "Session not found"}
            )

        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        if not project:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Access denied",
                error={"type": "AccessDenied", "detail": "Access denied"}
            )

        # Check if PDF report already exists
        pdf_report = None
        presigned_url = None
        expires_at = None
        
        if compliance_record.generated_pdf_report_id:
            pdf_report = db.query(AssessmentReport).filter(
                AssessmentReport.id == compliance_record.generated_pdf_report_id
            ).first()
        
        if pdf_report:
            # For existing PDF, refresh presigned URL
            logger.info(f"Refreshing presigned URL for existing report {pdf_report.id}")
            presigned_url, expires_at = _refresh_report_presigned_url(pdf_report)
            if not presigned_url:
                return standard_response(
                    status_code=500,
                    success=False,
                    message="Failed to generate presigned URL for existing report",
                    error={"type": "S3Error", "detail": "Failed to generate presigned URL"}
                )
        else:
            # For new PDF, validate content and generate
            logger.info(f"Generating new PDF report for compliance {compliance_id}")
            if not compliance_record.analysis_report_text_md or compliance_record.analysis_report_text_md.strip() == "":
                return standard_response(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    success=False,
                    message="No analysis content available for PDF generation",
                    error={"type": "ValidationError", "detail": "No analysis content available for PDF generation"}
                )

            pdf_content = pdf_generator.generate_pdf(compliance_record.analysis_report_text_md, "Compliance & Integration Report")
            
            # Upload PDF to S3
            folder_prefix = 'data_compliance/reports'
            session_id = compliance_record.id
            session_name = 'report'
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"compliance_report_{use_case_id}_{compliance_id}_{timestamp}.pdf"
            
            s3_key, presigned_url, expires_at = upload_file(
                BUCKET_NAME,
                pdf_content,
                session_id,
                session_name,
                filename,
                AWS_ACCESS_KEY_ID,
                AWS_SECRET_ACCESS_KEY,
                AWS_REGION,
                folder_prefix=folder_prefix,
                expiration=604800,  # 7 days
                project_name=project.name  # Pass project name
            )
            
            # Create or update AssessmentReport record
            if compliance_record.generated_pdf_report_id:
                pdf_report = db.query(AssessmentReport).filter(
                    AssessmentReport.id == compliance_record.generated_pdf_report_id
                ).first()
                if pdf_report:
                    pdf_report.report_path = s3_key
                    pdf_report.report_filename = filename
                    pdf_report.updated_at = datetime.utcnow()
            else:
                pdf_report = AssessmentReport(
                    usecase_id=use_case_id,
                    assessment_stage="compliance",
                    report_type="pdf",
                    report_mimetype="application/pdf",
                    report_filename=filename,
                    report_path=s3_key
                )
                db.add(pdf_report)
                db.flush()
                compliance_record.generated_pdf_report_id = pdf_report.id
            
            # Store the expiration in memory
            url_expirations[pdf_report.id] = expires_at
            
            db.commit()
            logger.info(f"New PDF report created with ID {pdf_report.id}")
        
        # Return simplified JSON response with only presigned URL and expiration
        response_data = {
            "presigned_url": presigned_url,
            "expires_at": expires_at.isoformat() if expires_at else None
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="PDF report generated successfully",
            data=response_data
        )

    except HTTPException as e:
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message=f"Error generating PDF: {str(e)}",
            error={"type": "Exception", "detail": str(e)}
        )

@router.get("/supported-formats")
async def get_supported_formats():
    try:
        supported_data = {
            "supported_formats": list(FileProcessor.SUPPORTED_EXTENSIONS.keys()),
            "format_descriptions": {
                ".csv": "Comma-separated values",
                ".xlsx": "Excel spreadsheet (2007+)",
                ".xls": "Excel spreadsheet (legacy)",
                ".txt": "Plain text file",
                ".json": "JSON data file",
                ".docx": "Word document",
                ".pdf": "PDF document",
                ".zip": "ZIP archive"
            },
            "compliance_frameworks": {
                "comprehensive": "Full compliance analysis across all frameworks",
                "gdpr": "GDPR-focused privacy analysis",
                "security": "Security and cybersecurity compliance",
                "industry": "Industry-specific regulatory compliance"
            }
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Supported formats retrieved successfully",
            data=supported_data
        )
        
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error retrieving supported formats",
            error={"type": "Exception", "detail": str(e)}
        )

@router.get("/health")
async def health_check():
    try:
        health_data = {
            "status": "healthy",
            "ai_service": "available" if GROQ_API_KEY else "not_configured",
            "supported_formats": len(FileProcessor.SUPPORTED_EXTENSIONS),
            "timestamp": datetime.utcnow().isoformat()
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Service is healthy",
            data=health_data
        )
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Health check failed",
            error={"type": "Exception", "detail": str(e)}
        )

@router.get("/get_data_compliance/{use_case_id}")
async def get_data_compliance(
    request: Request,
    use_case_id: int,
    db: Session = Depends(get_db)
):
    """
    Retrieve existing data compliance analysis for a given use case.
    Returns:
    - Compliance metrics
    - Uploaded document paths
    - PDF report path
    - Assessment configuration
    """
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)

        # Validate use case
        use_case = db.query(GeneratedUseCase).filter(
            GeneratedUseCase.id == use_case_id
        ).first()
        if not use_case:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error={"type": "NotFound", "detail": "Use case not found"}
            )

        # Validate session
        session = db.query(PreWorkshopSession).filter(
            PreWorkshopSession.id == use_case.session_id
        ).first()
        if not session:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error={"type": "NotFound", "detail": "Session not found"}
            )

        # Validate project access
        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        if not project:
            return standard_response(
                status_code=status.HTTP_403_FORBIDDEN,
                success=False,
                message="Access denied",
                error={"type": "AccessDenied", "detail": "Access denied"}
            )

        # Fetch Data Compliance record
        data_compliance = db.query(DataCompliance).filter(
            DataCompliance.usecase_id == use_case_id
        ).first()
        if not data_compliance:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="No data compliance analysis found",
                error={"type": "NotFound", "detail": "No analysis found for use case"}
            )

        # Fetch uploaded documents
        documents = db.query(DataComplianceDocument).filter(
            DataComplianceDocument.data_compliance_id == data_compliance.id
        ).all()

        s3 = boto3.client(
            's3',
            region_name=AWS_REGION,
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY
        )

        object_paths = [doc.path for doc in documents]
        presigned_urls = generate_presigned_get_urls(
            bucket_name=BUCKET_NAME,
            object_paths=object_paths,
            access_key=AWS_ACCESS_KEY_ID,
            secret_key=AWS_SECRET_ACCESS_KEY,
            region=AWS_REGION,
            expiration=604800  # 7 days
        )

        uploaded_docs = []
        for doc, url_info in zip(documents, presigned_urls):
            file_size = 0
            try:
                response = s3.head_object(Bucket=BUCKET_NAME, Key=doc.path)
                file_size = response.get('ContentLength', 0)
            except Exception as e:
                logger.warning(f"Could not get file size for {doc.path}: {e}")

            uploaded_docs.append({
                "filename": doc.filename,
                "mimetype": doc.mimetype,
                "path": url_info['url'] if url_info['status'] == 'success' else None,
                "size": file_size
            })

        # Fetch report paths
        report = db.query(AssessmentReport).filter(
            AssessmentReport.id == data_compliance.generated_pdf_report_id
        ).first()
        pdf_path = report.report_path if report else None

        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Data compliance analysis fetched successfully",
            data={
                "uploaded_docs": uploaded_docs,
                "pdf_path": pdf_path,
                "compliance_id": data_compliance.id,
                "overall_score": data_compliance.overall_score,
                "risk_level": data_compliance.risk_level,
                "analysis_type": data_compliance.analysis_type,
                "analysis_report": data_compliance.analysis_report_text_md,
                "risk_assessment": data_compliance.risk_assessment_text_md,
            }
        )
    except Exception as e:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Internal server error",
            error={"type": "Exception", "detail": str(e)}
        )