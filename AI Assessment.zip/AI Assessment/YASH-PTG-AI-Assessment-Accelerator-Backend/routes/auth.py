from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status,Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from typing import List
from services.auth_service import AuthService
from models.pydantic_models import UserCreate, UserLogin, UserResponse, ProjectCreate, ProjectResponse, ProjectWithOwner, LoginResponse,StandardResponse,standard_response
from database import get_db
from sqlalchemy.exc import IntegrityError
from models.models import User, Project

import os

# Router
router = APIRouter(prefix="/auth", tags=["Authentication & Projects"])

# Security
SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-here")
ALGORITHM = "HS256"
security = HTTPBearer()

# Initialize service
auth_service = AuthService(SECRET_KEY, ALGORITHM)

async def get_current_user(keycloak_payload: dict,  db: Session = Depends(get_db)) -> User:
    """Get the current user from the Keycloak token payload"""
    # Extract email from Keycloak token payload
    email = keycloak_payload.get("email") or keycloak_payload.get("preferred_username")
    if not email:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload: email not found")
    # Query the database for the user
    user = db.query(User).filter(User.email == email, User.is_active == True).first()
    
    if user is None:
        try:
            user_name = keycloak_payload.get("name") or keycloak_payload.get("preferred_username", "")
            new_user = User(
                email=email,
                hashed_password="",  
                full_name=user_name or email.split('@')[0], 
                is_active=True,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            db.add(new_user)
            db.commit()
            db.refresh(new_user)
            
            print(f"Created new user: {email}")
            return new_user
            
        except IntegrityError as e:
            # Handle race condition where user might be created between check and insert
            db.rollback()
            print(f"User {email} already exists (race condition): {str(e)}")
            return db.query(User).filter(User.email == email).first()
        except Exception as e:
            db.rollback()
            print(f"Error ensuring user exists: {str(e)}")
            raise e
    return user

@router.get("/me", response_model=StandardResponse)
async def get_current_user_profile(request: Request,db: Session = Depends(get_db)):
    """
    Get current user profile
    """
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        user_response = UserResponse.model_validate(current_user)
        return standard_response(
            status_code=200,
            success=True,
            message="User profile retrieved successfully",
            data=user_response.model_dump()
        )
        
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to retrieve projects",
            error=str(e)
        )

@router.post("/projects", response_model=StandardResponse)
async def create_project(
    project: ProjectCreate,
    request: Request,
    db: Session = Depends(get_db),
):
    """
    Create a new project for the authenticated user
    """
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        projects_data= auth_service.create_project(project, current_user, db)
        return standard_response(
            status_code=200,
            success=True,
            message="Projects created successfully",
            data=projects_data
        )   
    except ValueError as ve:
        return standard_response(
            status_code=409,
            success=False,
            message="Project with this name already exists",
            error=str(ve)
        )
    except Exception as ex:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to create projects",
            error=str(ex)
        )

@router.get("/projects", response_model=StandardResponse)
async def get_user_projects(
    request: Request,
    db: Session = Depends(get_db)
):
    """
    Get all projects for the authenticated user
    """
    try:
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user,db)
        projects_data = auth_service.get_user_projects(current_user, db)
        
        return standard_response(
            status_code=200,
            success=True,
            message="Projects retrieved successfully",
            data=projects_data
    )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to retrieve projects",
            error=str(e)
        )

@router.get("/projects/{project_id}", response_model=StandardResponse)
async def get_project_by_id(
    project_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """
    Get a specific project by ID (only if owned by current user)
    """
    try:
        keycloak_user = request.state.user
        current_user =await get_current_user(keycloak_user,db)
        project = auth_service.get_project_by_id(project_id, current_user, db)
        if not project:
            return standard_response(
            status_code=status.HTTP_404_NOT_FOUND,
            success=False,
            message="Project not found",
            error=str(e)
            )
        return standard_response(
            status_code=200,
            success=True,
            message="Project retrieved successfully",
            data=project
        )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to retrieve projects",
            error=str(e)
        )

@router.put("/projects/{project_id}", response_model=StandardResponse)
async def update_project(
    project_id: int,
    project_update: ProjectCreate,
    request: Request,
    db: Session = Depends(get_db)
):
    """
    Update a project (only if owned by current user)
    """
    
    keycloak_user = request.state.user
    current_user = await get_current_user(keycloak_user,db)
    try:
        updated_project= auth_service.update_project(project_id, project_update, current_user, db)
        return standard_response(
            status_code=200,
            success=True,
            message="Project updated successfully",
            data=updated_project
    )
    except ValueError as ve:
        return standard_response(
            status_code=status.HTTP_400_BAD_REQUEST,
            success=False,
            message="Failed to update projects",
            error=str(ve)
        )
    except KeyError as ke:
        return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Project not found",
                error=str(ke)
            )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to update projects",
            error=str(e)
        )

@router.delete("/projects/{project_id}")
async def delete_project(
    project_id: int,
    request: Request,
    db: Session = Depends(get_db)
):
    """
    Delete a project (soft delete - only if owned by current user)
    """
    keycloak_user = request.state.user
    current_user = await get_current_user(keycloak_user,db)
    try:
        deleted_project= auth_service.delete_project(project_id, current_user, db)
        return standard_response(
            status_code=200,
            success=True,
            message="Project deleted successfully",
            data=deleted_project
        )
    except KeyError as ke:
        return standard_response(
            status_code=status.HTTP_404_NOT_FOUND,
            success=False,
            message="Project not found",
            error=str(ke)
        )
    except Exception as e:
        return standard_response(
            status_code=500,
            success=False,
            message="Failed to delete project",
            error=str(e)
        )
    