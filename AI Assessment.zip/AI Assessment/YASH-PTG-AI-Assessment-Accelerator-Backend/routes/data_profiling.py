from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request, status, UploadFile, File, Response
from services.auth_service import AuthService
from services.ai_profiling_service import DataProfilerAPI
from utils.data_profiling_utils import DataProfilingPDFGenerator, save_uploaded_file
from pydantic import BaseModel
from datetime import datetime, timedelta
from pathlib import Path
import tempfile
import shutil
import os
import asyncio
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import boto3
import logging
from botocore.exceptions import ClientError
from models.pydantic_models import standard_response
from sqlalchemy.orm import Session
from models.models import User, AIProfiling, AIProfilingDocument, AssessmentReport, GeneratedUseCase, PreWorkshopSession, Project
from database import get_db
from utils.s3_utils import upload_file, generate_presigned_get_urls, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, BUCKET_NAME

router = APIRouter(prefix="/data-profiling", tags=["Data Profiling"])
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    print("Warning: GROQ_API_KEY not found in environment variables")

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Store expiration timestamps in memory (key: report_id, value: expires_at)
url_expirations = {}

pdf_generator = DataProfilingPDFGenerator()
security = HTTPBearer()

class DataProfilingAnalysisResponse(BaseModel):
    analysis_type: str
    generated_content: str
    file_analyzed: str
    data_quality_score: float
    generated_at: datetime

class DataProfilingRequest(BaseModel):
    usecase_id: int
    include_analysis_metadata: bool = True
    include_full_analysis_content: bool = True

async def get_current_user(keycloak_payload: dict, db: Session = Depends(get_db)) -> User:
    """Get the current user from the Keycloak token payload"""
    email = keycloak_payload.get("email") or keycloak_payload.get("preferred_username")
    if not email:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token payload: email not found")
    user = db.query(User).filter(User.email == email, User.is_active == True).first()
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found or inactive")
    return user

async def save_analysis_document(file: UploadFile, analysis_id: int, analysis_type: str, db: Session) -> tuple[str, str, datetime]:
    """Save uploaded file to S3 and return the S3 key, presigned URL, and expiration"""
    if analysis_type != 'data_profiling':
        raise ValueError("Only 'data_profiling' analysis type is supported for S3 upload")
    
    # Retrieve project name
    ai_profiling = db.query(AIProfiling).filter(AIProfiling.id == analysis_id).first()
    if not ai_profiling:
        raise HTTPException(status_code=404, detail="AI profiling record not found")
    use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == ai_profiling.usecase_id).first()
    if not use_case:
        raise HTTPException(status_code=404, detail="Use case not found")
    session = db.query(PreWorkshopSession).filter(PreWorkshopSession.id == use_case.session_id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    project = db.query(Project).filter(Project.id == session.project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Read file content
    file.file.seek(0)
    file_content = await file.read()
    
    if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
        raise HTTPException(status_code=500, detail="S3 credentials not configured")
    
    # Set folder_prefix for data profiling documents
    folder_prefix = 'data_profiling/documents'
    
    # Use analysis_id as session_id, and a fixed session_name
    session_id = analysis_id
    session_name = 'analysis'
    
    # Upload to S3
    loop = asyncio.get_event_loop()
    s3_key, presigned_url, expires_at = await loop.run_in_executor(
        None,
        lambda: upload_file(
            BUCKET_NAME,
            file_content,
            session_id,
            session_name,
            file.filename,
            AWS_ACCESS_KEY_ID,
            AWS_SECRET_ACCESS_KEY,
            AWS_REGION,
            folder_prefix=folder_prefix,
            expiration=604800,
            project_name=project.name  # Pass project name
        )
    )
    
    return s3_key, presigned_url, expires_at

@router.post("/analyze")
async def analyze_data_file(
    request: Request,
    use_case_id: int = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    Analyze a data file and return profiling results
    
    Parameters:
    - use_case_id: Form field with the use case ID
    - file: Upload file (CSV, Excel, JSON, TXT, Parquet)
    """
    if not GROQ_API_KEY:
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="AI service not configured",
            error={"type": "ServiceUnavailable", "detail": "AI service not configured"}
        )

    temp_dir = None
    try:
        # Get current user and validate permissions
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        
        # Validate use case exists and user has access
        use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == use_case_id).first()
        if not use_case:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error={"type": "NotFound", "detail": "Use case not found"}
            )

        # Validate session exists
        session = db.query(PreWorkshopSession).filter(
            PreWorkshopSession.id == use_case.session_id
        ).first()
        if not session:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error={"type": "NotFound", "detail": "Session not found"}
            )

        # Validate project ownership
        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        if not project:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Access denied",
                error={"type": "AccessDenied", "detail": "Access denied"}
            )

        # Process the uploaded file
        temp_dir = tempfile.mkdtemp()
        file_path = await save_uploaded_file(file, temp_dir)
        
        # Analyze file
        profiler = DataProfilerAPI(GROQ_API_KEY)
        analysis_result = await profiler.analyze_file(file, file.filename)
        
        # Check if AIProfiling already exists for this use_case_id
        existing_profiling = db.query(AIProfiling).filter(
            AIProfiling.usecase_id == use_case_id
        ).first()

        if existing_profiling:
            existing_profiling.file_analyzed = file.filename
            existing_profiling.quality_score = analysis_result.get('data_quality_score', 0.0)
            existing_profiling.analysis_type = analysis_result.get('analysis_type', 'comprehensive')
            existing_profiling.status = 'completed'
            existing_profiling.analysis_report_text_md = analysis_result.get('generated_content', '')
            ai_profiling = existing_profiling
        else:
            ai_profiling = AIProfiling(
                usecase_id=use_case_id,
                file_analyzed=file.filename,
                quality_score=analysis_result.get('data_quality_score', 0.0),
                analysis_type=analysis_result.get('analysis_type', 'comprehensive'),
                status='completed',
                analysis_report_text_md=analysis_result.get('generated_content', ''),
            )
            db.add(ai_profiling)

        use_case.ai_profiling_status = "Completed"
        if use_case.model_evaluation_status == "Pending":
            use_case.model_evaluation_status = "In Progress"

        db.commit()
        db.refresh(ai_profiling)
        
        # Save the uploaded file as document
        document_path, document_url, expires_at = await save_analysis_document(file, ai_profiling.id, "data_profiling", db)
        
        # Create document record
        existing_doc = db.query(AIProfilingDocument).filter(
            AIProfilingDocument.ai_profiling_id == ai_profiling.id,
            AIProfilingDocument.filename == file.filename
        ).first()

        if existing_doc:
            existing_doc.mimetype = file.content_type or 'application/octet-stream'
            existing_doc.path = document_path
        else:
            ai_profiling_doc = AIProfilingDocument(
                ai_profiling_id=ai_profiling.id,
                filename=file.filename,
                mimetype=file.content_type or 'application/octet-stream',
                path=document_path
            )
            db.add(ai_profiling_doc)
        db.commit()
        
        # Get file size from S3
        s3 = boto3.client(
            's3',
            region_name=AWS_REGION,
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY
        )
        file_size = 0
        try:
            response = s3.head_object(Bucket=BUCKET_NAME, Key=document_path)
            file_size = response.get('ContentLength', 0)
        except Exception as e:
            logger.warning(f"Could not get file size for {document_path}: {e}")

        # Prepare response
        response_data = {
            "ai_profiling_id": ai_profiling.id,
            "use_case_id": use_case_id,
            "analysis_result": analysis_result,
            "document_uploaded": {
                "filename": file.filename,
                "mimetype": file.content_type,
                "path": document_url,
                "size": file_size
            }
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Data profiling analysis completed successfully",
            data=response_data
        )
        
    except HTTPException as e:
        db.rollback()
        logger.error(f"HTTP error analyzing file: {str(e)}")
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        db.rollback()
        logger.error(f"Error analyzing file: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message=f"Error analyzing file: {str(e)}",
            error={"type": "Exception", "detail": str(e)}
        )
    finally:
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)

@router.post("/generate-pdf")
async def generate_data_profiling_pdf(
    request: Request,
    ai_profiling_id: int = Query(..., description="The ID of the AI profiling analysis record"),
    db: Session = Depends(get_db)
):
    """
    Generate or fetch a PDF report for data profiling analysis and return a presigned URL for download.
    
    Parameters:
    - ai_profiling_id: The ID of the AI profiling analysis record
    """
    try:
        if not GROQ_API_KEY:
            return standard_response(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                success=False,
                message="AI service not configured",
                error={"type": "ServiceUnavailable", "detail": "AI service not configured"}
            )

        if not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, BUCKET_NAME]):
            return standard_response(
                status_code=500,
                success=False,
                message="S3 credentials not configured",
                error={"type": "ConfigurationError", "detail": "S3 credentials not configured"}
            )

        # Get current user and validate permissions
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)
        
        # Get AI profiling record
        ai_profiling = db.query(AIProfiling).filter(AIProfiling.id == ai_profiling_id).first()
        if not ai_profiling:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="AI profiling record not found",
                error={"type": "NotFound", "detail": "AI profiling record not found"}
            )
        
        # Get use_case_id from AIProfiling record
        use_case_id = ai_profiling.usecase_id
        
        # Validate user has access through use case ownership
        use_case = db.query(GeneratedUseCase).filter(
            GeneratedUseCase.id == use_case_id
        ).first()
        
        if not use_case:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error={"type": "NotFound", "detail": "Use case not found"}
            )
        
        # Verify access through session and project ownership
        session = db.query(PreWorkshopSession).filter(
            PreWorkshopSession.id == use_case.session_id
        ).first()
        
        if not session:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error={"type": "NotFound", "detail": "Session not found"}
            )
        
        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        
        if not project:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Access denied",
                error={"type": "AccessDenied", "detail": "Access denied"}
            )

        # Check if PDF report already exists
        pdf_report = None
        presigned_url = None
        expires_at = None
        
        if ai_profiling.generated_pdf_report_id:
            pdf_report = db.query(AssessmentReport).filter(
                AssessmentReport.id == ai_profiling.generated_pdf_report_id
            ).first()
        
        if pdf_report:
            # For existing PDF, refresh presigned URL
            logger.info(f"Refreshing presigned URL for existing report {pdf_report.id}")
            presigned_url, expires_at = _refresh_report_presigned_url(pdf_report)
            if not presigned_url:
                return standard_response(
                    status_code=500,
                    success=False,
                    message="Failed to generate presigned URL for existing report",
                    error={"type": "S3Error", "detail": "Failed to generate presigned URL"}
                )
        else:
            # For new PDF, generate and upload
            logger.info(f"Generating new PDF report for AI profiling {ai_profiling_id}")
            if not ai_profiling.analysis_report_text_md or ai_profiling.analysis_report_text_md.strip() == "":
                return standard_response(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    success=False,
                    message="No analysis content available for PDF generation",
                    error={"type": "ValidationError", "detail": "No analysis content available for PDF generation"}
                )

            report_title = f"AI Data Profiling Report - {ai_profiling.file_analyzed}"
            pdf_content = pdf_generator.generate_pdf(ai_profiling.analysis_report_text_md, report_title)
            
            # Upload PDF to S3
            folder_prefix = 'data_profiling/reports'
            session_id = ai_profiling.id
            session_name = 'report'
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"ai_profiling_report_{use_case_id}_{ai_profiling_id}_{timestamp}.pdf"
            
            s3_key, presigned_url, expires_at = upload_file(
                BUCKET_NAME,
                pdf_content,
                session_id,
                session_name,
                filename,
                AWS_ACCESS_KEY_ID,
                AWS_SECRET_ACCESS_KEY,
                AWS_REGION,
                folder_prefix=folder_prefix,
                expiration=604800,
                project_name=project.name  # Pass project name
            )
            
            # Create or update AssessmentReport record
            if ai_profiling.generated_pdf_report_id:
                pdf_report = db.query(AssessmentReport).filter(
                    AssessmentReport.id == ai_profiling.generated_pdf_report_id
                ).first()
                if pdf_report:
                    pdf_report.report_path = s3_key
                    pdf_report.report_filename = filename
                    pdf_report.updated_at = datetime.utcnow()
            else:
                pdf_report = AssessmentReport(
                    usecase_id=use_case_id,
                    assessment_stage="ai_profiling",
                    report_type="pdf",
                    report_mimetype="application/pdf",
                    report_filename=filename,
                    report_path=s3_key
                )
                db.add(pdf_report)
                db.flush()
                ai_profiling.generated_pdf_report_id = pdf_report.id
            
            # Store the expiration in memory
            url_expirations[pdf_report.id] = expires_at
            
            db.commit()
            logger.info(f"New PDF report created with ID {pdf_report.id}")
        
        # Return simplified JSON response with only presigned URL and expiration
        response_data = {
            "presigned_url": presigned_url,
            "expires_at": expires_at.isoformat() if expires_at else None
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="PDF report generated successfully",
            data=response_data
        )
        
    except HTTPException as e:
        logger.error(f"HTTP error generating PDF: {str(e)}")
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        logger.error(f"Error generating PDF: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message=f"Error generating PDF: {str(e)}",
            error={"type": "Exception", "detail": str(e)}
        )

@router.get("/get_data_profiling/{use_case_id}")
async def get_data_profiling_details(
    request: Request,
    use_case_id: int,
    db: Session = Depends(get_db)
):
    """
    Get data profiling result, uploaded document path, and PDF report path for a given use_case_id.
    """
    try:
        # Check AI Service Key
        if not GROQ_API_KEY:
            return standard_response(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                success=False,
                message="AI service not configured",
                error={"type": "ServiceUnavailable", "detail": "AI service not configured"}
            )

        # Auth and access check
        keycloak_user = request.state.user
        current_user = await get_current_user(keycloak_user, db)

        # Fetch Use Case
        use_case = db.query(GeneratedUseCase).filter(GeneratedUseCase.id == use_case_id).first()
        if not use_case:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Use case not found",
                error={"type": "NotFound", "detail": "Use case not found"}
            )

        session = db.query(PreWorkshopSession).filter(PreWorkshopSession.id == use_case.session_id).first()
        if not session:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="Session not found",
                error={"type": "NotFound", "detail": "Session not found"}
            )

        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()
        if not project:
            return standard_response(
                status_code=status.HTTP_403_FORBIDDEN,
                success=False,
                message="Access denied",
                error={"type": "AccessDenied", "detail": "Access denied"}
            )

        # Get AI profiling record
        ai_profiling = db.query(AIProfiling).filter(AIProfiling.usecase_id == use_case_id).first()
        if not ai_profiling:
            return standard_response(
                status_code=status.HTTP_404_NOT_FOUND,
                success=False,
                message="AI profiling not found for this use case",
                error={"type": "NotFound", "detail": "No AI profiling data found"}
            )

        # Fetch uploaded document
        doc = db.query(AIProfilingDocument).filter(
            AIProfilingDocument.ai_profiling_id == ai_profiling.id
        ).first()
        
        s3 = boto3.client(
            's3',
            region_name=AWS_REGION,
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY
        )

        document_path = doc.path if doc else None
        document_url = None
        file_size = 0
        
        if document_path:
            try:
                result = generate_presigned_get_urls(
                    bucket_name=BUCKET_NAME,
                    object_paths=[document_path],
                    access_key=AWS_ACCESS_KEY_ID,
                    secret_key=AWS_SECRET_ACCESS_KEY,
                    region=AWS_REGION,
                    expiration=604800
                )[0]
                if result['status'] == 'success':
                    document_url = result['url']
                
                # Get file size
                response = s3.head_object(Bucket=BUCKET_NAME, Key=document_path)
                file_size = response.get('ContentLength', 0)
            except Exception as e:
                logger.warning(f"Could not get file info for {document_path}: {e}")

        # Fetch PDF report if available
        pdf_path = None
        if ai_profiling.generated_pdf_report_id:
            pdf_report = db.query(AssessmentReport).filter(
                AssessmentReport.id == ai_profiling.generated_pdf_report_id
            ).first()
            pdf_path = pdf_report.report_path if pdf_report else None

        # Assemble response
        analysis_result = {
            "analysis_type": ai_profiling.analysis_type,
            "generated_content": ai_profiling.analysis_report_text_md,
            "file_analyzed": ai_profiling.file_analyzed,
            "data_quality_score": ai_profiling.quality_score,
            "generated_at": ai_profiling.updated_at or ai_profiling.created_at
        }

        response_data = {
            "ai_profiling_id": ai_profiling.id,
            "analysis_result": analysis_result,
            "usecase_id": use_case_id,
            "uploaded_doc_path": document_url,
            "generated_pdf_path": pdf_path,
            "document_uploaded": {
                "filename": doc.filename if doc else None,
                "mimetype": doc.mimetype if doc else None,
                "path": document_url,
                "size": file_size
            }
        }

        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Data profiling details fetched successfully",
            data=response_data
        )

    except HTTPException as e:
        logger.error(f"HTTP error fetching profiling details: {str(e)}")
        return standard_response(
            status_code=e.status_code,
            success=False,
            message=e.detail,
            error={"type": "HTTPException", "detail": e.detail}
        )
    except Exception as e:
        logger.error(f"Error fetching profiling details: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message=f"Error fetching profiling details: {str(e)}",
            error={"type": "Exception", "detail": str(e)}
        )

def _refresh_report_presigned_url(report: AssessmentReport) -> tuple[str, datetime]:
    """Regenerate presigned URL if expired or about to expire"""
    report_id = report.id
    s3_key = report.report_path
    if not s3_key:
        return None, None
    
    # Check if URL is expired or about to expire (within 1 hour)
    current_time = datetime.utcnow()
    expires_at = url_expirations.get(report_id)
    logger.info(f"Checking expiration for report {report_id}: expires_at={expires_at}")
    if expires_at and expires_at > current_time + timedelta(hours=1):
        logger.info(f"URL for report {report_id} is still valid, returning existing")
        pass
    
    # Regenerate URL
    logger.info(f"Regenerating URL for report {report_id}")
    result = generate_presigned_get_urls(
        bucket_name=BUCKET_NAME,
        object_paths=[s3_key],
        access_key=AWS_ACCESS_KEY_ID,
        secret_key=AWS_SECRET_ACCESS_KEY,
        region=AWS_REGION,
        expiration=604800
    )[0]
    if result['status'] == 'success':
        url_expirations[report_id] = result['expires_at']
        logger.info(f"New URL for report {report_id} expires at {result['expires_at'].isoformat()}")
        return result['url'], result['expires_at']
    else:
        logger.error(f"Failed to regenerate URL for report {report_id}: {result['error']}")
        return None, None

@router.get("/supported-formats")
async def get_supported_formats():
    """Get list of supported file formats for data profiling analysis"""
    try:
        supported_data = {
            "supported_formats": ['.csv', '.txt', '.parquet', '.xlsx', '.xls', '.json'],
            "format_descriptions": {
                ".csv": "Comma-separated values",
                ".xlsx": "Excel spreadsheet (2007+)",
                ".xls": "Excel spreadsheet (legacy)",
                ".txt": "Plain text file",
                ".json": "JSON data file",
                ".parquet": "Parquet columnar format"
            },
            "analysis_capabilities": [
                "Data quality assessment",
                "Column analysis",
                "Statistical profiling",
                "Pattern detection",
                "Missing value analysis"
            ]
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Supported formats retrieved successfully",
            data=supported_data
        )
        
    except Exception as e:
        logger.error(f"Error retrieving supported formats: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Error retrieving supported formats",
            error={"type": "Exception", "detail": str(e)}
        )

@router.get("/health")
async def health_check():
    """Health check endpoint for data profiling service"""
    try:
        health_data = {
            "status": "healthy",
            "ai_service": "available" if GROQ_API_KEY else "not_configured",
            "supported_formats": 6,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        return standard_response(
            status_code=status.HTTP_200_OK,
            success=True,
            message="Service is healthy",
            data=health_data
        )
        
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return standard_response(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            success=False,
            message="Health check failed",
            error={"type": "Exception", "detail": str(e)}
        )