# GenAI Assessment Platform

A comprehensive enterprise-grade platform for evaluating organizational AI readiness and generating actionable implementation roadmaps.

## 🚀 Overview

The GenAI Assessment Platform is a system designed to guide organizations through their AI transformation journey. It provides end-to-end assessment capabilities, from initial use case identification to detailed implementation planning, ensuring successful AI adoption with proper compliance and security considerations.

## 🏗️ Architecture

- **Backend**: FastAPI with async/await patterns
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Frontend**: Streamlit web application
- **AI Integration**: Multi-provider LLM support (Groq, OpenAI, Google Gemini)
- **Security**: JWT-based authentication with RBAC
- **Base URL**: `http://localhost:8000`

## ✨ Key Features

- **End-to-End AI Assessment Workflow** with dependency management
- **Multi-Format File Processing** with intelligent data type detection
- **Real-Time Progress Tracking** across assessment stages
- **Comprehensive Report Generation** with PDF export capabilities
- **Cross-Module Data Continuity** and validation
- **Enterprise-Grade Security** and data isolation

## 📦 Platform Modules

### 1. 📊 Project Management & Authentication
- User lifecycle management and authentication
- Project workspace creation and management
- JWT-based security with refresh token capability
- Role-based access control and audit trails

### 2. 🧠 Use Case Generation (Pre-Workshop Intelligence)
- AI-powered business requirement analysis
- Intelligent use case generation from questionnaires
- AWS service mapping and complexity scoring
- ROI estimation with business metrics

### 3. 📈 Data Readiness Assessment
- Comprehensive data quality evaluation
- Statistical profiling and distribution analysis
- AI-specific readiness metrics
- Data preparation roadmap generation

### 4. 🔒 Data Compliance & Security
- Multi-regulatory framework support (GDPR, HIPAA, SOX, PCI DSS)
- Automated PII and sensitive data detection
- Risk classification and remediation planning
- Security posture evaluation

### 5. 🤖 AI Profiling & Recommendation
- Statistical distribution analysis
- AI technique mapping and model recommendations
- AWS service integration matrix
- Performance and cost estimation

### 6. ⚡ Model Evaluation & Performance Analysis
- Multi-provider model comparison
- LLM-as-judge evaluation system
- Advanced statistical analysis
- Performance benchmarking and recommendations

### 7. 🏃‍♂️ Sprint Planning & Implementation
- Intelligent project planning with multiple methodologies
- Resource optimization and timeline estimation
- Risk-aware sprint breakdown
- Comprehensive monitoring frameworks

### 8. 📊 Universal Reports & Analytics Dashboard
- Cross-module analytics and insights
- Predictive analytics for implementation success
- Industry benchmarking and ROI modeling
- Comprehensive reporting with visualization

## 🛠️ Installation

### Prerequisites

- Python 3.8+
- PostgreSQL 12+
- Streamlit as Frontend

### Setup

1. **Clone the repository**
```bash
git clone https://github.com/your-org/genai-assessment-platform.git
cd genai-assessment-platform
```

2. **Create virtual environment**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Database setup**
```bash
# Create PostgreSQL database
createdb genai_assessment

# Run migrations
alembic upgrade head
```

5. **Environment configuration**
```bash
cp .env.example .env
# Edit .env with your configuration
```

6. **Start the application**
```bash
# Backend API
uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Frontend (in another terminal)
streamlit run frontend/app.py
```

## 🔧 Configuration

### Environment Variables

```env
# Database
DATABASE_URL=postgresql://user:password@localhost/genai_assessment

# Security
SECRET_KEY=your-secret-key-here
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24

# AI Providers
OPENAI_API_KEY=your-openai-key
GROQ_API_KEY=your-groq-key
GOOGLE_API_KEY=your-google-key

# Application
DEBUG=false
LOG_LEVEL=INFO
```

## 📚 API Documentation

### Authentication Endpoints

```http
POST /auth/register          # User registration
POST /auth/login             # User authentication
GET  /auth/me               # Current user profile
POST /auth/logout           # Session termination
```

### Project Management

```http
POST /auth/projects         # Create new project
GET  /auth/projects         # List user projects
GET  /auth/projects/{id}    # Get project details
PUT  /auth/projects/{id}    # Update project
DELETE /auth/projects/{id}  # Delete project
```

### Assessment Modules

```http
# Use Case Generation
POST /pre-workshop/sessions/{id}/generate-use-cases

# Data Readiness
POST /data-readiness/analyze

# Compliance Assessment
POST /compliance/analyze

# AI Profiling
POST /data-profiling/analyze

# Model Evaluation
POST /model-evaluation/analyze

# Sprint Planning
POST /sprint-planning/generate

# Reports
GET  /reports
POST /reports/save
GET  /reports/{uuid}
```

## 🔐 Security Features

- **JWT Authentication** with refresh token rotation
- **Rate Limiting** on sensitive endpoints
- **Input Validation** and sanitization
- **SQL Injection Protection** via SQLAlchemy ORM
- **CORS Configuration** for secure cross-origin requests
- **Audit Logging** for compliance and monitoring

## 📊 Usage Examples

### Creating a New Assessment

```python
import requests

# Login
response = requests.post('/auth/login', json={
    'email': 'user@example.com',
    'password': 'secure_password'
})
token = response.json()['access_token']

# Create project
headers = {'Authorization': f'Bearer {token}'}
project = requests.post('/auth/projects', 
    json={'name': 'AI Assessment Project'}, 
    headers=headers
)

# Generate use cases
requests.post('/pre-workshop/sessions/{session_id}/generate-use-cases',
    files={'questionnaire': open('questionnaire.xlsx', 'rb')},
    headers=headers
)
```

### Analyzing Data Readiness

```python
# Upload and analyze data
response = requests.post('/data-readiness/analyze',
    files={'file': open('dataset.csv', 'rb')},
    json={'use_case': 'Customer Churn Prediction'},
    headers=headers
)

assessment = response.json()
print(f"Data readiness score: {assessment['readiness_score']}")
```
