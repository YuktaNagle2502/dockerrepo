from fastapi import FastAPI, HTTPException
from typing import Optional
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import uvicorn
from middleware.auth_middleware import KeycloakAuthMiddleware
# Import database configuration
from database import create_tables, engine, Base

# Import routers
from routes.auth import router as auth_router
from routes.compliance import router as compliance_router
from routes.data_profiling import router as data_profiling_router
from routes.model_evaluation import router as model_eval_router
from routes.pre_workshop import router as pre_workshop_router
from routes.reports import reports_router as reports_router
from routes.data_readiness import router as data_readiness_router
from routes.sprint_planning import router as sprint_planning_router

# Lifespan context manager for startup/shutdown events
@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Starting up...")
    create_tables()
    print("Database tables created successfully")
    yield
    print("Shutting down...")

# Create FastAPI app with lifespan events
app = FastAPI(
    title="GenAI Assessment Platform",
    description="A comprehensive platform for GenAI assessment and implementation",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(KeycloakAuthMiddleware)

# Include routers
app.include_router(auth_router)
app.include_router(compliance_router)
app.include_router(data_profiling_router)
app.include_router(model_eval_router)
app.include_router(pre_workshop_router)
app.include_router(reports_router)
app.include_router(data_readiness_router)
app.include_router(sprint_planning_router)

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "GenAI Assessment Platform API",
        "version": "1.0.0",
        "status": "active"
    }

# Health check endpoint
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "database": "connected"
    }

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={
            "message": "Internal server error",
            "detail": str(exc)
        }
    )

# Run the application
if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )