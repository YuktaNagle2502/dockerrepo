import React from 'react';
import { Layout, Button, Row, Col, Typography, Card, Statistic, Collapse, Divider, Space, Steps } from 'antd';
import { RocketOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import { routes } from '../../util/constants';

const { Content } = Layout;
const { Title, Paragraph } = Typography;
const { Panel } = Collapse;
const { Step } = Steps;

const Home = () => {
    const navigate = useNavigate();

    const handleGoToProjectClick = () => {
        navigate(routes.PROJECT_MANAGEMENT.path);
    }
    const assessmentSteps = [
        {
            title: '📊 Create a Project - Start by creating a new project for your assessment.',
            color: '#8c8c8c'
        },
        {
            title: '🧠 Generate Use Cases - Upload your questionnaire and generate AI use cases.',
            color: '#8c8c8c'
        },
        {
            title: '📈 Check Data Readiness - Upload your data and assess its readiness.',
            color: '#8c8c8c'
        },
        {
            title: '🔒 Compliance Check - Verify data compliance and security requirements.',
            color: '#8c8c8c'
        },
        {
            title: '🤖 AI Profiling - Perform detailed AI model profiling.',
            color: '#8c8c8c'
        },
        {
            title: '⚡ Model Evaluation - Evaluate and compare different AI models.',
            color: '#8c8c8c'
        },
        {
            title: '🎯 Sprint Planning - Plan sprints and deliverables.',
            color: '#8c8c8c'
        },
        {
            title: '📋 Final Report - Generate comprehensive assessment reports.',
            color: '#8c8c8c'
        }
    ];

    const quickStats = [
        { title: 'Assessment Steps', value: 7, suffix: 'stages' },
        { title: 'Report Types', value: 5, suffix: 'formats' }
    ];

    return (
        <Content style={{ padding: '16px' }}>
            {/* Welcome Hero Section */}
            <Card 
                style={{ 
                    marginBottom: '16px',
                    borderRadius: '6px',
                    border: '1px solid #f0f0f0'
                }}
            >
                <Row align="middle" gutter={[16, 16]}>
                    <Col xs={24} md={16}>
                        <Space direction="vertical" size="small" style={{ width: '100%' }}>
                            <div>
                                <Title level={1} style={{ margin: 0, color: 'rgb(61, 61, 61)' }}>
                                    Welcome to GenAI Assessment
                                </Title>
                                <Title level={5} style={{ margin: '4px 0', color: 'rgb(61, 61, 61)', fontWeight: 'normal' }}>
                                    Your comprehensive AI readiness evaluation platform
                                </Title>
                            </div>
                            <Paragraph style={{ fontSize: '14px', color: '#8c8c8c', margin: 0 }}>
                                Streamline your AI adoption journey with our assessment platform. 
                                From data readiness to model evaluation, we guide you through every step.
                            </Paragraph>
                            <Space>
                                <Button 
                                    type="primary" 
                                    icon={<RocketOutlined />}
                                    style={{ 
                                        borderRadius: '4px'
                                    }}
                                    className='ant-btn-primary-custom'
                                    onClick={ handleGoToProjectClick}
                                >
                                    Go to Projects
                                </Button>
                                {/* <Button 
                                    style={{ 
                                        borderRadius: '4px'
                                    }}
                                    className='ant-btn-default-custom'
                                >
                                    View Guide
                                </Button> */}
                            </Space>
                        </Space>
                    </Col>
                    <Col xs={24} md={8}>
                        <Row gutter={[8, 8]}>
                            {quickStats.map((stat, index) => (
                                <Col span={24} key={index}>
                                    <Card 
                                        size="small" 
                                        style={{ 
                                            textAlign: 'center',
                                            background: '#f5f5f5',
                                            border: '1px solid #e8e8e8'
                                        }}
                                    >
                                        <Statistic 
                                            title={stat.title} 
                                            value={stat.value} 
                                            suffix={stat.suffix}
                                            valueStyle={{ color: '#595959', fontSize: '16px' }}
                                            titleStyle={{ color: '#8c8c8c', fontSize: '12px' }}
                                        />
                                    </Card>
                                </Col>
                            ))}
                        </Row>
                    </Col>
                </Row>
            </Card>

            {/* Getting Started Guide */}
            <Card 
    style={{ 
        borderRadius: '6px',
        border: '1px solid #f0f0f0'
    }}
>
    <div style={{ padding: '8px 0' }}>
        <Title level={4} style={{ marginBottom: '12px', color: '#595959' }}>
            Detailed Getting Started Guide
        </Title>
        <Steps direction="vertical" size="small">
            {assessmentSteps.map((step, index) => (
                <Step 
                    key={index}
                    title={step.title} // Use the emoji title directly
                    description=""
                    status="wait"
                />
            ))}
        </Steps>
        
        <Divider />
        
        <div style={{ 
            background: '#f9f9f9',
            padding: '12px',
            borderRadius: '4px',
            border: '1px solid #e8e8e8'
        }}>
            <Title level={5} style={{ color: '#595959', margin: '0 0 8px 0', fontSize: '14px' }}>
                💡 Tips for Success:
            </Title>
            <ul style={{ margin: 0, paddingLeft: '16px', fontSize: '12px', color: '#8c8c8c' }}>
                <li>Save your progress at each stage</li>
                <li>Prepare your data files beforehand</li>
                <li>Review compliance requirements</li>
                <li>Export reports in multiple formats</li>
            </ul>
        </div>
    </div>
</Card>
        </Content>
    );
};

export default Home;