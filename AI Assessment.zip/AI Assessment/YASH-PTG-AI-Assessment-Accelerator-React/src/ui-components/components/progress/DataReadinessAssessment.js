import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Card, Tabs, Button, Select, Upload, Table, Progress, Alert, Spin, Row, Col, Statistic, Typography, Space, Checkbox, message, Collapse, Tag, Descriptions, Divider } from 'antd';
import { InboxOutlined, FileTextOutlined, BarChartOutlined, CheckCircleOutlined, ExclamationCircleOutlined, DownloadOutlined, PlayCircleOutlined, EyeOutlined } from '@ant-design/icons';
import Papa from 'papaparse';
import { geteUseCase, processUploadedFiles, generateReport } from '../../../redux/features/dataReadiness/dataReadinessActions';
import { getSessionDetails } from '../../../redux/features/useCaseGeneration/useCaseAction';
import { getUseCaseProgressStatus } from "../../../redux/features/project/projectAction";
import { getDataReadiness } from '../../../redux/features/dataReadiness/dataReadinessActions';
import { setAssessmentResults } from '../../../redux/features/dataReadiness/dataReadinessSlice';
import Markdown from 'markdown-to-jsx';

// import Markdown from 'markdown-to-jsx';

const { TabPane } = Tabs;
const { Title, Text, Paragraph } = Typography;
const { Dragger } = Upload;
const { Panel } = Collapse;

const DataReadinessAssessment = () => {
  const dispatch = useDispatch();
  const { selectedUseCase, selectedUseCaseLoading, uploadedFiles, assessmentResults, isLoading, processedDataInfo, reportLoading } = useSelector(state => state.readiness);
  const selectedProjectName = useSelector(state => state.local?.projectName);
  const { selectedUseCaseDetail, selectedSessionDetail } = useSelector(state => state.local);
const [csvPreviews, setCsvPreviews] = useState({});
  const [activeTab, setActiveTab] = useState('1');
  const [fileList, setFileList] = useState([]);
  const [csvPreview, setCsvPreview] = useState(null);
  const { fetchedReadinessData, fetchedReadinessLoading } = useSelector(state => state.readiness);
  const [assessmentConfig, setAssessmentConfig] = useState({
    depth: 'detailed',
    includeAI: true,
    generateRecommendations: true,
    includeCompliance: false
  });


useEffect(() => {
  const checkAndPrefillData = () => {
    if (selectedUseCaseDetail?.id && selectedSessionDetail?.id) {
      // Fire both actions in parallel (geteUseCase and getUseCaseProgressStatus)
      dispatch(geteUseCase({ sessionId: selectedSessionDetail.id, useCaseId: selectedUseCaseDetail.id }));

      // Run getUseCaseProgressStatus in the background
      dispatch(getUseCaseProgressStatus(selectedUseCaseDetail.id))
        .unwrap()
        .then((statusRes) => {
          const readinessStatus = statusRes?.data?.data_readiness_status;
          console.log("readinessStatus:", readinessStatus);

          if (readinessStatus?.toLowerCase() === 'completed') {
            // Only fetch getDataReadiness if status is completed
            dispatch(getDataReadiness(selectedUseCaseDetail.id))
              .unwrap()
              .then((result) => {
                if (result.success && result.data) {
                  const data = result.data;

                  // Autofill form data
                  setAssessmentConfig({
                    depth: data.assessment_config?.depth || 'detailed',
                    includeAI: data.assessment_config?.includeAI ?? true,
                    generateRecommendations: data.assessment_config?.generateRecommendations ?? true,
                    includeCompliance: data.assessment_config?.includeCompliance ?? false
                  });

                  // Convert to AntD file format
                  const uploaded = data.documents_uploaded.map((file, index) => ({
                    uid: `${index}`,
                    name: file.filename,
                    status: 'done',
                    url: file.path,
                    type: file.mimetype,
                    size: file.size || 0 
                  }));

                  // Rebuild CSV previews from URLs if they are CSVs
                  uploaded.forEach((file) => {
                    if (file.name.toLowerCase().endsWith('.csv') && file.url) {
                      fetch(file.url)
                        .then(res => res.text())
                        .then(text => {
                          Papa.parse(text, {
                            header: true,
                            skipEmptyLines: true,
                            complete: (results) => {
                              setCsvPreviews(prev => ({
                                ...prev,
                                [file.uid]: {
                                  data: results.data.slice(0, 10),
                                  totalRows: results.data.length,
                                  columns: results.meta.fields || [],
                                  errors: results.errors
                                }
                              }));
                            },
                            error: (error) => {
                              message.error(`Error parsing CSV from server: ${error.message}`);
                            }
                          });
                        })
                        .catch(err => {
                          message.error(`Error fetching file ${file.name}: ${err.message}`);
                        });
                    }
                  });


                  setFileList(uploaded);

                  // Optionally store in Redux
                  dispatch(setAssessmentResults(data));
                  setActiveTab('4');
                  message.success("Loaded previous data readiness analysis.");
                }
              })
              .catch((err) => {
                console.error("Error fetching readiness data:", err);
              });
          }
        })
        .catch((err) => {
          console.error("Error fetching progress status:", err);
        });
    }
  };

  checkAndPrefillData();
}, [selectedUseCaseDetail, selectedSessionDetail]);


const handleFileUpload = (info) => {
  const { fileList } = info;
  setFileList(fileList);
  dispatch({ type: 'dataReadiness/setUploadedFiles', payload: fileList });

  const previews = {};
  fileList.forEach((file) => {
    if (file.name.toLowerCase().endsWith('.csv')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        Papa.parse(e.target.result, {
          header: true,
          skipEmptyLines: true,
          complete: (results) => {
            previews[file.uid] = {
              data: results.data.slice(0, 10),
              totalRows: results.data.length,
              columns: results.meta.fields || [],
              errors: results.errors
            };
            setCsvPreviews(prev => ({ ...prev, ...previews }));
          },
          error: (error) => {
            message.error(`Error parsing CSV: ${error.message}`);
          }
        });
      };
      if (file.originFileObj) {
        reader.readAsText(file.originFileObj);
      }
    }
  });
};
// const handleFileUpload = (info) => {
//     const newFiles = info.fileList;
//     setFileList(newFiles);

//     const previews = [];
//     newFiles.forEach(file => {
//       if (file.name.toLowerCase().endsWith('.csv')) {
//         const reader = new FileReader();
//         reader.onload = (e) => {
//           Papa.parse(e.target.result, {
//             header: true,
//             skipEmptyLines: true,
//             complete: (results) => {
//               previews.push({
//                 name: file.name,
//                 data: results.data.slice(0, 10),
//                 columns: results.meta.fields || [],
//               });
//               setCsvPreviews([...previews]);
//             },
//             error: (error) => {
//               message.error(`Error parsing ${file.name}: ${error.message}`);
//             },
//           });
//         };
//         reader.readAsText(file.originFileObj);
//       }
//     });
//   };

  const previewCSVFile = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const csvData = e.target.result;
      Papa.parse(csvData, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          const previewData = {
            data: results.data.slice(0, 10), // First 10 rows
            totalRows: results.data.length,
            columns: results.meta.fields || [],
            errors: results.errors
          };
          setCsvPreview(previewData);
        },
        error: (error) => {
          message.error(`Error parsing CSV: ${error.message}`);
          setCsvPreview(null);
        }
      });
    };
    
    if (file.originFileObj) {
      reader.readAsText(file.originFileObj);
    }
  };

  // Updated function to match Streamlit approach - single API call for upload + assessment
  const handleRunAssessment = async () => {
    setActiveTab('4');
    if (fileList.length === 0) {
      message.error('Please upload files first');
      return;
    }

    if (!selectedUseCaseDetail?.id) {
      message.error('No use case selected');
      return;
    }

    // Combine file upload and assessment config into single API call
    const assessmentPayload = {
      files: fileList,
      useCaseId: selectedUseCaseDetail?.id,
      projectId: selectedProjectName, // Add project context
      assessmentConfig: {
        depth: assessmentConfig.depth,
        includeAI: assessmentConfig.includeAI,
        generateRecommendations: assessmentConfig.generateRecommendations,
        includeCompliance: assessmentConfig.includeCompliance
      }
    };

    try {
      const response = await dispatch(processUploadedFiles(assessmentPayload));

      console.log("this is the response from processUploadedFiles", response.payload.data)
      if (processUploadedFiles.fulfilled.match(response)) {
        message.success('Data readiness assessment completed successfully!');
      } else if (processUploadedFiles.rejected.match(response)) {
        const errorMessage = response.payload?.message || response.payload?.detail || 'Assessment failed';
        message.error(errorMessage);
      }
    } catch (error) {
      message.error('Error running assessment: ' + error.message);
    }
  };

const handleDownloadReport = async (format) => {
    if (!assessmentResults) {
      message.error('No assessment results available');
      return;
    }
    try {
      const reportPayload = {
        data_readiness_id: assessmentResults.data_readiness_id,
        use_case_id: assessmentResults.use_case_id,
      };
      const response = await dispatch(generateReport(reportPayload)).unwrap();
      if (response.success && response.data && response.data.presigned_url) {
        const { presigned_url } = response.data;
        const link = document.createElement('a');
        link.href = presigned_url;
        link.download = `data_readiness_report_${reportPayload.use_case_id}_${reportPayload.data_readiness_id}.${format.toLowerCase()}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        message.success(`${format.toUpperCase()} report downloaded successfully!`);
      } else {
        message.error('No download link available for this report.');
      }
    } catch (error) {
      console.error('Error generating report:', error);
      message.error('Error generating report: ' + error.message);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ready': return 'success';
      case 'partially_ready': return 'warning';
      case 'not_ready': return 'error';
      default: return 'default';
    }
  };

  const getScoreColor = (score) => {
    if (score >= 80) return '#52c41a';
    if (score >= 60) return '#faad14';
    return '#ff4d4f';
  };

  const fileColumns = [
    { title: 'Filename', dataIndex: 'name', key: 'name' },
    { title: 'Size', dataIndex: 'size', key: 'size', render: (size) => `${(size / 1024 / 1024).toFixed(2)} MB` },
    { title: 'Type', dataIndex: 'type', key: 'type' },
    { title: 'Status', key: 'status', render: () => <Tag color="blue">Ready for Assessment</Tag> }
  ];

  const csvColumns = csvPreview?.columns?.map(col => ({ title: col, dataIndex: col, key: col })) || [];

  // Enhanced results display matching Streamlit structure
  const renderQualityMetrics = () => {
    if (!assessmentResults?.quality_metrics) return null;

    return (
      <Row gutter={16}>
        {Object.entries(assessmentResults.quality_metrics).map(([metric, score]) => (
          <Col span={8} key={metric} style={{ marginBottom: 16 }}>
            <Card>
              <Statistic 
                title={metric.charAt(0).toUpperCase() + metric.slice(1)} 
                value={score} 
                precision={1} 
                suffix="%" 
                valueStyle={{ color: getScoreColor(score) }} 
              />
              <Progress 
                percent={score} 
                showInfo={false} 
                strokeColor={getScoreColor(score)} 
                size="small" 
              />
            </Card>
          </Col>
        ))}
      </Row>
    );
  };

  return (
    <div style={{ padding: 0 }}>
      <Card>
        <Title level={4}><BarChartOutlined /> Data Readiness Assessment</Title>
        <Paragraph>Assess your data quality and readiness for AI implementation</Paragraph>

        {selectedUseCase && (
          <Alert message={`Working on: ${selectedProjectName}`} type="info" showIcon style={{ marginBottom: 24 }} />
        )}

        <Tabs activeKey={activeTab} onChange={setActiveTab}>
          <TabPane tab="Select Use Case" key="1" loading={selectedUseCaseLoading}>
            <Card title="📋 Selected Use Case for Assessment" loading={selectedUseCaseLoading}>
              {selectedUseCase && (
                <div>
                  <Alert message={`Selected: ${selectedUseCaseDetail?.title}`} type="success" showIcon style={{ marginBottom: 16 }} />
                  
                  <Collapse defaultActiveKey={['1']}>
                    <Panel header="Use Case Details" key="1">
                      <Descriptions bordered column={2}>
                        <Descriptions.Item label={<strong>Title</strong>}>{selectedUseCase.title}</Descriptions.Item>
                        <Descriptions.Item label={<strong>Business Category</strong>}>{selectedUseCase.business_category}</Descriptions.Item>
                        <Descriptions.Item label={<strong>Complexity</strong>}>
                          <Tag color={selectedUseCase.complexity === 'High' ? 'red' : 'orange'}>{selectedUseCase.complexity}</Tag>
                        </Descriptions.Item>
                        <Descriptions.Item label={<strong>Priority</strong>}>
                          <Tag color={selectedUseCase.priority === 'High' ? 'red' : 'blue'}>{selectedUseCase.priority}</Tag>
                        </Descriptions.Item>
                        <Descriptions.Item label={<strong>ROI Potential</strong>}>{selectedUseCase.roi_potential}</Descriptions.Item>
                        <Descriptions.Item label={<strong>Estimated Effort</strong>}>{selectedUseCase.estimated_effort}</Descriptions.Item>
                        <Descriptions.Item label={<strong>Cost Estimate</strong>}>{selectedUseCase.cost_estimate}</Descriptions.Item>
                        <Descriptions.Item label={<strong>AWS Services</strong>}>
                          {selectedUseCase.aws_services?.map(service => <Tag key={service} color="blue">{service}</Tag>)}
                        </Descriptions.Item>
                      </Descriptions>
                      <Divider />
                      <Paragraph><strong>Description:</strong> {selectedUseCase.description}</Paragraph>
                    </Panel>
                  </Collapse>
                </div>
              )}
            </Card>
          </TabPane>

          <TabPane tab="Upload Data" key="2">
            <Card title="📤 Upload Your Data Files" loading={selectedUseCaseLoading}>
              {selectedUseCase && (
                <Alert message={`Uploading data for: ${selectedUseCaseDetail?.title}`} type="info" showIcon style={{ marginBottom: 16 }} />
              )}

              <Dragger 
                multiple
                onChange={handleFileUpload} 
                beforeUpload={() => false} 
                style={{ marginBottom: 16 }}
                fileList={fileList}
                accept=".csv,.xlsx,.xls,.json,.txt,.pdf" // Specific file types
              >
                <p className="ant-upload-drag-icon"><InboxOutlined /></p>
                <p className="ant-upload-text">Click or drag file to this area to upload</p>
                <p className="ant-upload-hint">Support for CSV, Excel, JSON, TXT, PDF files (one file at a time)</p>
              </Dragger>
{fileList.length > 0 && (
  <div style={{ marginTop: 16 }}>
    <Title level={4}>📁 Uploaded Files</Title>
    <Table dataSource={fileList} columns={fileColumns} rowKey="uid" pagination={false} />

    {fileList.map(file => {
      const preview = csvPreviews[file.uid];
      if (!preview) return null;
      return (
        <div key={file.uid} style={{ marginTop: 24 }}>
          <Title level={5}>👁️ Preview: {file.name}</Title>
          <Space>
            <Text strong>Shape:</Text>
            <Text>{preview.totalRows} rows × {preview.columns.length} columns</Text>
          </Space>
          <Table 
            dataSource={preview.data} 
            columns={preview.columns.slice(0, 6).map(col => ({
              title: col,
              dataIndex: col,
              key: col
            }))}
            rowKey={(record, index) => index}
            pagination={false}
            scroll={{ x: true }}
            style={{ marginTop: 8 }}
            size="small"
          />
          {preview.errors.length > 0 && (
            <Alert 
              message="CSV Parsing Warnings" 
              description={preview.errors.map(err => err.message).join(', ')} 
              type="warning" 
              style={{ marginTop: 8 }} 
            />
          )}
        </div>
      );
    })}
  </div>
)}
            </Card>
          </TabPane>

          <TabPane tab="Assess Readiness" key="3">
            <Card title="🔍 Data Readiness Assessment" loading={isLoading}>
              {fileList.length === 0 ? (
                <Alert message="Please upload a data file first." type="warning" showIcon />
              ) : (
                <div>
                  <Alert message={`Assessing data readiness for: ${selectedUseCase?.title}`} type="info" showIcon style={{ marginBottom: 16 }} />

                  <Card title="⚙️ Assessment Configuration" style={{ marginBottom: 16 }}>
                    <Row gutter={16}>
                      <Col span={12}>
                        <Space direction="vertical" style={{ width: '100%' }}>
                          <div>
                            <Text strong>Assessment Depth:</Text>
                            <Select
                              value={assessmentConfig.depth}
                              style={{ width: '100%', marginTop: 8 }}
                              onChange={(value) => setAssessmentConfig(prev => ({ ...prev, depth: value }))}
                              options={[
                                { value: 'basic', label: 'Basic Analysis' },
                                { value: 'detailed', label: 'Detailed Analysis' },
                                { value: 'comprehensive', label: 'Comprehensive Analysis' }
                              ]}
                            />
                          </div>
                          <Checkbox 
                            checked={assessmentConfig.includeAI}
                            onChange={(e) => setAssessmentConfig(prev => ({ ...prev, includeAI: e.target.checked }))}
                          >
                            Include AI-powered analysis
                          </Checkbox>
                        </Space>
                      </Col>
                      <Col span={12}>
                        <Space direction="vertical">
                          <Checkbox 
                            checked={assessmentConfig.generateRecommendations}
                            onChange={(e) => setAssessmentConfig(prev => ({ ...prev, generateRecommendations: e.target.checked }))}
                          >
                            Generate improvement recommendations
                          </Checkbox>
                          <Checkbox 
                            checked={assessmentConfig.includeCompliance}
                            onChange={(e) => setAssessmentConfig(prev => ({ ...prev, includeCompliance: e.target.checked }))}
                          >
                            Include compliance assessment
                          </Checkbox>
                        </Space>
                      </Col>
                    </Row>
                    
                    {/* Assessment Info */}
                    <div style={{ marginTop: 16, padding: 12, backgroundColor: '#f6f8ff', borderRadius: 6 }}>
                      <Text type="secondary">
                        This assessment will analyze your uploaded data file against the selected use case requirements 
                        and provide detailed insights into data quality, completeness, and readiness for AI implementation.
                      </Text>
                    </div>
                  </Card>

                  <Button
                    type="primary"
                    size="large"
                    icon={<PlayCircleOutlined />}
                    onClick={handleRunAssessment}
                    loading={isLoading}
                    className='ant-btn-primary-custom'
                    block
                  >
                    {isLoading ? 'Running Assessment...' : 'Start Data Readiness Assessment'}
                  </Button>
                  
                  {isLoading && (
                    <div style={{ textAlign: 'center', marginTop: 16 }}>
                      <Spin size="large" />
                      <div style={{ marginTop: 8 }}>
                        <Text type="secondary">This may take a few minutes depending on your file size...</Text>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </Card>
          </TabPane>

          <TabPane tab="View Results" key="4">
            <Card title="📊 Assessment Results" loading={isLoading}>
              {!assessmentResults ? (
                <Alert message="No assessment results available. Please run the assessment first." type="info" showIcon />
              ) : (
                <div>
                  {/* Key Metrics Row */}
                  <Row gutter={16} style={{ marginBottom: 24 }}>
                    <Col span={6}>
                      <Card>
                        <Statistic 
                          title="Readiness Score" 
                          value={assessmentResults.readiness_score} 
                          precision={1} 
                          suffix="%" 
                          valueStyle={{ color: getScoreColor(assessmentResults.readiness_score) }} 
                        />
                      </Card>
                    </Col>
                    <Col span={6}>
                      <Card>
                        <Statistic 
                          title="Requirements Met" 
                          value={`${assessmentResults.requirements_analysis?.met_requirements || 0}/${assessmentResults.requirements_met_count|| 0}`} 
                          valueStyle={{ color: '#3f8600' }} 
                        />
                      </Card>
                    </Col>
                    <Col span={6}>
                      <Card>
                        <Statistic 
                          title="Data Quality Issues" 
                          value={assessmentResults.data_quality_issues_count || 0} 
                          valueStyle={{ color: '#cf1322' }} 
                        />
                      </Card>
                    </Col>
                    <Col span={6}>
                      <Card>
                        <Statistic 
                          title="Overall Status" 
                          value={assessmentResults.overall_status?.replace('_', ' ').toUpperCase() || 'UNKNOWN'} 
                          valueStyle={{ color: getScoreColor(assessmentResults.readiness_score) }} 
                        />
                      </Card>
                    </Col>
                  </Row>

                  {/* Issues and Recommendations */}
                  <Row gutter={16} style={{ marginBottom: 24 }}>
                    <Col span={12}>
                      <Card title="⚠️ Data Quality Issues">
                        {assessmentResults.data_quality_issues?.length > 0 ? (
                          <ul style={{ margin: 0, paddingLeft: 20 }}>
                            {assessmentResults.data_quality_issues.map((issue, index) => (
                              <li key={index} style={{ marginBottom: 8 }}>{issue}</li>
                            ))}
                          </ul>
                        ) : (
                          <Alert message="No significant data quality issues found!" type="success" />
                        )}
                      </Card>
                    </Col>
                    <Col span={12}>
                      <Card title="💡 Recommendations">
                        {assessmentResults.recommendations?.length > 0 ? (
                          <ol style={{ margin: 0, paddingLeft: 20 }}>
                            {assessmentResults.recommendations.map((rec, index) => (
                              <li key={index} style={{ marginBottom: 8 }}>{rec}</li>
                            ))}
                          </ol>
                        ) : (
                          <Alert message="No specific recommendations at this time." type="info" />
                        )}
                      </Card>
                    </Col>
                  </Row>

                  {/* Expandable Sections */}
                  <Collapse style={{ marginBottom: 24 }}>
                    <Panel header="📖 Detailed Analysis" key="1">
                      <Markdown style={{ whiteSpace: 'pre-line' }}>
                        {assessmentResults.generated_content || 'No detailed analysis available.'}
                      </Markdown>
                    </Panel>
                    {/* <Panel header="📊 Quality Metrics" key="2">
                      {renderQualityMetrics()}
                    </Panel> */}
                    {assessmentResults.requirements_analysis && (
                      <Panel header="📋 Requirements Analysis" key="3">
                        <Descriptions bordered column={2}>
                          <Descriptions.Item label="Total Requirements">
                            {assessmentResults.requirements_analysis.total_requirements}
                          </Descriptions.Item>
                          <Descriptions.Item label="Met Requirements">
                            {assessmentResults.requirements_analysis.met_requirements}
                          </Descriptions.Item>
                          <Descriptions.Item label="Partial Requirements">
                            {assessmentResults.requirements_analysis.partial_requirements || 0}
                          </Descriptions.Item>
                          <Descriptions.Item label="Missing Requirements">
                            {assessmentResults.requirements_analysis.missing_requirements || 0}
                          </Descriptions.Item>
                        </Descriptions>
                      </Panel>
                    )}
                  </Collapse>

                  {/* Action Buttons */}
                  <Row gutter={16}>
                    <Col span={8}>
                      <Button 
                        type="primary" 
                        icon={<DownloadOutlined />} 
                        onClick={() => handleDownloadReport('pdf')} 
                        block 
                        className='ant-btn-primary-custom'
                        loading={reportLoading}
                      >
                        Generate PDF Report
                      </Button>
                    </Col>
                    <Col span={8}>
                      <Button 
                        icon={<DownloadOutlined />} 
                        onClick={() => handleDownloadReport('json')} 
                        block 
                        className='ant-btn-default-custom'
                        loading={reportLoading}
                      >
                        Generate JSON Report
                      </Button>
                    </Col>
                    <Col span={8}>
                    </Col>
                  </Row>
                </div>
              )}
            </Card>
          </TabPane>
        </Tabs>
      </Card>
    </div>
  );
};

export default DataReadinessAssessment;