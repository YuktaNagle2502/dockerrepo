import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Card, Tabs, Button, Form, Input, Upload, Table, Checkbox, Collapse, Alert, Spin, Progress, Space, Typography, Row, Col, Tag, Divider, message, Modal, Descriptions, Empty, Tooltip, Radio ,Select, InputNumber} from 'antd';
import { UploadOutlined, FileTextOutlined, BulbOutlined, EyeOutlined, DownloadOutlined, PlusOutlined, ReloadOutlined, ProjectOutlined, CheckCircleOutlined, ExclamationCircleOutlined, SettingOutlined } from '@ant-design/icons';
import { addCustomUseCase, createPreWorkshopSession, generateReport, generateUseCases, getSessionDetails, loadPreWorkshopSessionsAndUsecases, uploadQuestionnaire } from '../../../redux/features/useCaseGeneration/useCaseAction';
import { clearGeneratedUseCases } from '../../../redux/features/useCaseGeneration/useCaseSlice';

const { Title, Text, Paragraph } = Typography;
const { Panel } = Collapse;
const { TabPane } = Tabs;
const { TextArea } = Input;
const { Option } = Select;

const UseCaseGeneration = () => {
  const dispatch = useDispatch();
  const selectedProjectId = useSelector(state => state.local?.selectedProjectId);
  const selectedProjectName = useSelector(state => state.local?.projectName);
  const { sessionAndUsecases, loading, questionnaireResponses, uploadLoading, generatedUseCases, selectedUseCaseIds, generateUseCasesLoading, sessionCreationLoading, sessionAndUsecasesLoading, sessionDetailsLoading } = useSelector(state => state.usecase);

  const [activeTab, setActiveTab] = useState('upload');
  const [useCaseForm] = Form.useForm();
  const [responseModal, setResponseModal] = useState(false);
  const [uploadFiles, setUploadFiles] = useState({});
  const [activeSessionId, setActiveSessionId] = useState(null);
  const [selectedUseCaseId, setSelectedUseCaseId] = useState(null);

  useEffect(() => {
    if (selectedProjectId) {
      dispatch(loadPreWorkshopSessionsAndUsecases(selectedProjectId));
    }
  }, [dispatch, selectedProjectId]);
 const [isModalVisible, setIsModalVisible] = useState(false);
  const [form] = Form.useForm();

  // AWS GenAI Services options
  const awsServices = [
    'Amazon Bedrock (Claude, Titan, Jurassic models)',
    'Amazon SageMaker (Custom ML models)',
    'Amazon Comprehend (NLP)',
    'Amazon Textract (Document analysis)',
    'Amazon Transcribe (Speech-to-text)',
    'Amazon Polly (Text-to-speech)',
    'Amazon Rekognition (Image/Video analysis)',
    'Amazon Lex (Conversational AI)',
    'Amazon Kendra (Intelligent search)',
    'Amazon CodeWhisperer (Code generation)',
    'Amazon Personalize (Recommendations)'
  ];

  // Dropdown options
  const priorityOptions = ['Low', 'Medium', 'High'];
  const complexityOptions = ['Low', 'Medium', 'High'];
  const roiOptions = ['Low', 'Medium', 'High'];
  const effortUnits = ['weeks', 'months'];

  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    useCaseForm.resetFields();
  };

  const handleSubmit = async () => {
    try {
      const values = await useCaseForm.validateFields();
      
      // Process the form data
      const formattedData = {
        ...values,
        cost_estimate:`$${values.cost_estimate_from} - $${values.cost_estimate_to}`,
        estimated_effort: `${values.effort_number} ${values.effort_unit}`,
        customer_pain_points: values.customer_pain_points || [],
        success_metrics: values.success_metrics || [],
        dependencies: values.dependencies || [],
        risks: values.risks || [],
        implementation_phases: values.implementation_phases || [],
        aws_architecture:values.aws_architecture || null,
      };
      
      let data={
        sessionId:activeSessionId,
        useCaseData:formattedData
      }
      dispatch(addCustomUseCase(data))
      .unwrap()
      .then(() => {
      message.success('Use case added successfully!');
      })
      .catch(err => {
        console.error('Failed to add custom use case:', err);
      });
      
      setIsModalVisible(false);
      useCaseForm.resetFields();
    } catch (error) {
      console.error('Form validation failed:', error);
      message.error('Please fill in all required fields');
    }
  };
  const handleCreateSession = async (values) => {
    try {
      const response = await dispatch(createPreWorkshopSession({
        project_id: selectedProjectId,
        session_name: values.sessionName,
        description: values.description
      }));

      if (response.payload.success) {
        message.success(response.payload.message);
        dispatch(loadPreWorkshopSessionsAndUsecases(selectedProjectId));
        form.resetFields();
      } else {
        message.error(response.payload.error);
      }
    } catch (error) {
      message.error('Failed to create session');
    }
  };

  const handleUploadQuestionnaire = async (sessionId, file) => {
    try {
      const response = await dispatch(uploadQuestionnaire({ sessionId, file }));
      if (response.payload.success) {
        message.success(response.payload.message);
        dispatch(loadPreWorkshopSessionsAndUsecases(selectedProjectId));
      } else {
        message.error(response.payload.error);
      }
    } catch (error) {
      message.error('Failed to upload questionnaire');
    }
  };

  const handleGenerateUseCases = async (sessionId) => {
    try {
      const response = await dispatch(generateUseCases(sessionId));
      if (response.payload.success) {
        message.success(response.payload.message);
        dispatch(getSessionDetails(sessionId));
      } else {
        message.error(response.payload.error);
      }
    } catch (error) {
      message.error('Failed to generate use cases');
    }
  };

  const handleSelectUseCase = (useCaseId) => {
    setSelectedUseCaseId(useCaseId === selectedUseCaseId ? null : useCaseId);
  };

  const handleGenerateReport = async (sessionId, reportType) => {
    try {
      const response = await dispatch(generateReport({ sessionId, reportType }));
      console.log('Generate report response:', response); // Debug full response
      console.log('Payload data:', response.payload?.data); // Debug payload data
      if (response.payload?.data?.success) {
        if (reportType === 'pdf') {
          // Handle PDF download via presigned URL
          const presignedUrl = response.payload.data?.data?.presigned_url;
          console.log('Presigned URL:', presignedUrl); // Debug presigned URL
          if (presignedUrl) {
            const link = document.createElement('a');
            link.href = presignedUrl;
            link.download = `use_cases_report_${sessionId}.pdf`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            message.success('PDF report downloaded successfully!');
          } else {
            console.error('No presigned URL in response:', response.payload.data);
            message.error('No presigned URL provided for PDF report');
          }
        } else if (reportType === 'json') {
          // Handle JSON download as blob
          const blob = new Blob([response.payload.data], { 
            type: 'application/json' 
          });
          const url = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = response.payload.filename;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          window.URL.revokeObjectURL(url);
          message.success('JSON report downloaded successfully!');
        }
      } else {
        console.error('Invalid response structure:', response.payload);
        message.error('Failed to generate report');
      }
    } catch (error) {
      console.error('Error generating report:', error);
      message.error('Failed to generate report');
    }
  };

  const showQuestionnaireResponses = (sessionId) => {
    dispatch(getSessionDetails(sessionId));
    setResponseModal(true);
  };

     const genExtra = () => (
    <Button 
      type="primary" 
      onClick={(event) => {
        event.stopPropagation();
        showModal();
      }} 
      className='ant-btn-primary-custom'
    >
      Add Use Case
    </Button>
  );
  const handleSessionExpand = async (key) => {
    const sessionId = key && key.length > 0 ? key[0] : null;
    if (sessionId && activeSessionId !== sessionId) {
      setActiveSessionId(sessionId);
      setSelectedUseCaseId(null); // Reset selected use case when switching sessions
      await dispatch(getSessionDetails(sessionId));
    } else if (!sessionId) {
      setActiveSessionId(null);
      setSelectedUseCaseId(null);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      'draft': 'processing',
      'questionnaire_uploaded': 'success',
      'use_cases_generated': 'purple',
      'completed': 'green'
    };
    return colors[status] || 'default';
  };

  const getStatusIcon = (status) => {
    const icons = {
      'draft': '🔄',
      'questionnaire_uploaded': '✅',
      'use_cases_generated': '🧠',
      'completed': '🎉'
    };
    return icons[status] || '📋';
  };

  const getPriorityColor = (priority) => {
    const colors = {
      'High': 'red',
      'Medium': 'orange',
      'Low': 'green'
    };
    return colors[priority] || 'default';
  };

  if (!selectedProjectId) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <Alert message="No Project Selected" description="Please select a project first from the Project Management page." type="warning" showIcon style={{ marginBottom: 20 }} />
        <Button type="primary" icon={<ProjectOutlined />} size="large">Go to Project Management</Button>
      </div>
    );
  }

  return (
    <div style={{ padding: '18px 24px 18px' }}>
      <div style={{ marginBottom: 24 }}>
        <Title level={4}><BulbOutlined style={{ marginRight: 8 }} />Session & Use Case Generation</Title>
        <Text type="secondary">Upload questionnaire responses and generate AI-powered use cases</Text>
      </div>

      <Alert message={`Working on: ${selectedProjectName}`} type="info" showIcon style={{ marginBottom: 24 }} />
      <Progress percent={33} format={() => 'Stage 1 of 3'} style={{ marginBottom: 24 }} />

      <Tabs activeKey={activeTab} onChange={setActiveTab}>
        <TabPane tab="📤 Session Management" key="upload">
          <Card loading={sessionAndUsecasesLoading}>
            <Collapse accordion>
              <Panel header="➕ Create New Assessment Session" key="create" extra={<PlusOutlined />}>
                <Form form={form} layout="vertical" onFinish={handleCreateSession}>
                  <Form.Item label="Session Name" name="sessionName" rules={[{ required: true, message: 'Session name is required!' }]}>
                    <Input placeholder="e.g., Q1 2024 Assessment" />
                  </Form.Item>
                  <Form.Item label="Description" name="description">
                    <TextArea rows={3} placeholder="Brief description of this assessment session" />
                  </Form.Item>
                  <Form.Item>
                    <Button type="primary" htmlType="submit" loading={sessionCreationLoading} icon={<PlusOutlined />} className='ant-btn-primary-custom'>Create Session</Button>
                  </Form.Item>
                </Form>
              </Panel>
            </Collapse>

            <Divider />
            <Title level={4}>📁 Existing Sessions</Title>
            {sessionAndUsecases.length === 0 ? (
              <Empty description="No assessment sessionAndUsecases found. Create your first session above." />
            ) : (
              <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                {sessionAndUsecases.map(session => (
                  <Card key={session.id} size="small" hoverable>
                    <Row gutter={24} align="middle">
                      <Col span={10}>
                        <div style={{ marginBottom: 12 }}>
                          <Title level={5} style={{ margin: 0, marginBottom: 4 }}>{session.session_name}</Title>
                          <Text type="secondary" style={{ fontSize: '13px' }}>
                            Created: {new Date(session.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                          </Text>
                        </div>
                        <Paragraph style={{ margin: 0, color: '#666', fontSize: '14px', lineHeight: '1.4' }} ellipsis={{ rows: 2, expandable: false }}>
                          {session.description || 'No description available'}
                        </Paragraph>
                      </Col>
                      <Col span={10} style={{ textAlign: 'center' }}>
                        <Tag color={getStatusColor(session.status)} style={{ fontSize: '12px', fontWeight: '500', padding: '4px 12px', borderRadius: '6px' }}>
                          {getStatusIcon(session.status)} {session.status}
                        </Tag>
                      </Col>
                      <Col span={4} style={{ textAlign: 'right' }}>
                        <Space direction='horizontal' size="small" style={{ width: '100%' }}>
                          {['draft', 'questionnaire_uploaded'].includes(session.status) && (
                            <Upload accept=".xlsx,.xls" beforeUpload={(file) => { handleUploadQuestionnaire(session.id, file); return false; }} showUploadList={false}>
                              <Tooltip title="Upload Questionnaire" placement="left">
                                <Button icon={<UploadOutlined />} type="primary" size="small" shape="circle" className='ant-btn-primary-custom' loading={uploadLoading} />
                              </Tooltip>
                            </Upload>
                          )}
                          {['questionnaire_uploaded', 'use_cases_generated', 'completed'].includes(session.status) && (
                            <Tooltip title="View Questionnaire Responses" placement="left">
                              <Button icon={<EyeOutlined />} type="default" size="small" shape="circle" onClick={() => showQuestionnaireResponses(session.id || [])} />
                            </Tooltip>
                          )}
                          {['questionnaire_uploaded', 'use_cases_generated', 'completed'].includes(session.status) && (
                            <Tooltip title="Download Questionnaire" placement="left">
                              <Button
                                icon={<DownloadOutlined />}
                                type="default"
                                size="small"
                                shape="circle"
                                loading={sessionDetailsLoading}
                                onClick={async () => {
                                  try {
                                    const result = await dispatch(getSessionDetails(session.id)).unwrap();
                                    if (result.data?.presigned_url) {
                                      window.open(result.data.presigned_url, '_blank');
                                    } else {
                                      message.error('No download link available for this session.');
                                    }
                                  } catch (error) {
                                    message.error('Failed to fetch the download link.');
                                  }
                                }}
                              />
                            </Tooltip>
                          )}
                        </Space>
                      </Col>
                    </Row>
                  </Card>
                ))}
              </Space>
            )}
          </Card>
        </TabPane>

        <TabPane tab="🧠 Generate Use Cases" key="generate">
          <Card loading={sessionAndUsecasesLoading}>
            <Title level={4}>🧠 Generate AI Use Cases</Title>
            {sessionAndUsecases.filter(s => ['questionnaire_uploaded', 'use_cases_generated'].includes(s.status)).length === 0 ? (
              <Alert message="No sessions with uploaded questionnaires found." description="Please upload a questionnaire first." type="warning" showIcon />
            ) : (
              <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                {sessionAndUsecases.filter(s => ['questionnaire_uploaded', 'use_cases_generated'].includes(s.status)).map(session => (
                  <Card key={session.id} size="small">
                    <Row gutter={16}>
                      <Col span={16}>
                        <Title level={5}>🧠 Generate Use Cases for {session.session_name}</Title>
                        <Text>
                          Status: {session.status === 'questionnaire_uploaded' 
                            ? '✅ Questionnaire responses are ready for use case generation'
                            : ' Use cases have been generated for this session'
                          }
                        </Text>
                      </Col>
                      <Col span={8} style={{ textAlign: 'center' }}>
                        {session.status === 'questionnaire_uploaded' ? (
                          <Button type="primary" icon={<BulbOutlined />} loading={generateUseCasesLoading} onClick={() => handleGenerateUseCases(session.id)} className='ant-btn-primary-custom'>
                            Generate Use Cases
                          </Button>
                        ) : (
                          <Button icon={<ReloadOutlined />} loading={generateUseCasesLoading} onClick={() => handleGenerateUseCases(session.id)} className='ant-btn-default-custom'>
                            Regenerate
                          </Button>
                        )}
                      </Col>
                    </Row>
                  </Card>
                ))}
              </Space>
            )}
          </Card>
        </TabPane>

        <TabPane tab="📋 View Results" key="results">
          <Card loading={sessionAndUsecasesLoading}>
            <Title level={4}>📋 Generated Use Cases</Title>
            {sessionAndUsecases.filter(s => ['use_cases_generated', 'completed'].includes(s.status)).length === 0 ? (
              <Alert message="No sessions with generated use cases found." description="Generate use cases first." type="info" showIcon />
            ) : (
              <Collapse accordion activeKey={activeSessionId} onChange={handleSessionExpand}>
                {sessionAndUsecases.filter(s => ['use_cases_generated', 'completed'].includes(s.status)).map(session => (
                  <Panel header={`📋 ${session.session_name} `} key={session.id} extra={genExtra()}>
                    <Spin spinning={sessionDetailsLoading}>
                      {/* <Radio.Group value={selectedUseCaseId} onChange={(e) => handleSelectUseCase(e.target.value)}> */}
                        <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                          {generatedUseCases.map(useCase => (
                            <Card key={useCase.id} size="small" style={{ marginBottom: 16 }}>
                              <Row gutter={16}>
                                <Col span={1}>
                                  {/* <Radio value={useCase.id} /> */}
                                </Col>
                                <Col span={18}>
                                  <Title level={5}>{useCase.title}</Title>
                                  <Paragraph ellipsis={{ rows: 2, expandable: true }}>{useCase.description}</Paragraph>
                                  <Collapse ghost>
                                    <Panel header="📖 View Details" key="details">
                                      <Row gutter={16}>
                                        <Col span={12}>
                                          <Descriptions column={1} size="small">
                                            <Descriptions.Item label="AWS Services">
                                              {Array.isArray(useCase.aws_services) ? useCase.aws_services.join(', ') : useCase.aws_services}
                                            </Descriptions.Item>
                                            <Descriptions.Item label="Priority">{useCase.priority}</Descriptions.Item>
                                            <Descriptions.Item label="Complexity">{useCase.complexity}</Descriptions.Item>
                                            <Descriptions.Item label="ROI Potential">{useCase.roi_potential}</Descriptions.Item>
                                          </Descriptions>
                                        </Col>
                                        <Col span={12}>
                                          <Descriptions column={1} size="small">
                                            <Descriptions.Item label="Business Category">{useCase.business_category}</Descriptions.Item>
                                            <Descriptions.Item label="Estimated Effort">{useCase.estimated_effort}</Descriptions.Item>
                                            <Descriptions.Item label="Cost Estimate">{useCase.cost_estimate}</Descriptions.Item>
                                          </Descriptions>
                                        </Col>
                                      </Row>
                                    </Panel>
                                  </Collapse>
                                </Col>
                                <Col span={5} style={{ textAlign: 'center' }}>
                                  <Tag color={getPriorityColor(useCase.priority)} style={{ fontSize: '14px' }}>{useCase.priority}</Tag>
                                </Col>
                              </Row>
                            </Card>
                          ))}
                        </Space>
                      {/* </Radio.Group> */}
                      
                      <Row gutter={16} style={{ marginTop: 16 }}>
                        <Col span={12}>
                          <Button type="primary" icon={<FileTextOutlined />} block onClick={() => handleGenerateReport(session.id, 'pdf')} loading={loading}  className='ant-btn-primary-custom'>
                            Generate PDF Report
                          </Button>
                        </Col>
                        <Col span={12}>
                          <Button icon={<DownloadOutlined />} block onClick={() => handleGenerateReport(session.id, 'json')} loading={loading} disabled={!selectedUseCaseId} className='ant-btn-default-custom'>
                            Generate JSON Report
                          </Button>
                        </Col>
                      </Row>
                    </Spin>
                  </Panel>
                ))}
              </Collapse>
            )}
          </Card>
        </TabPane>
      </Tabs>

      <Modal title="📋 Questionnaire Responses" open={responseModal} onCancel={() => setResponseModal(false)} footer={null} width={800} loading={sessionDetailsLoading}>
        <Space direction="vertical" size="middle" style={{ width: '100%' }}>
          {questionnaireResponses.map((response, index) => (
            <Card key={index} size="small">
              <Title level={5}>Q{index + 1}: {response.question}</Title>
              {response.description && <Text italic>{response.description}</Text>}
              <Paragraph><Text strong>Answer:</Text> {response.response}</Paragraph>
              {response.additional_notes && <Text type="secondary">Notes: {response.additional_notes}</Text>}
            </Card>
          ))}
        </Space>
      </Modal>
      <Modal
        title="Add Use Case"
        open={isModalVisible}
        onCancel={handleCancel}
        style={{ top: 20 }}
        width={900}
        footer={[
          <Button key="cancel" onClick={handleCancel}>
            Cancel
          </Button>,
          <Button key="submit" type="primary" onClick={handleSubmit} className='ant-btn-primary-custom' >
            Add Use Case
          </Button>
        ]}
      >
        <Form
          form={useCaseForm}
          layout="vertical"
          initialValues={{
            priority: 'Medium',
            complexity: 'Low',
            roi_potential: 'Medium',
            effort_unit: 'weeks'
          }}
        >
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="title"
                label="Title"
                rules={[{ required: true, message: 'Please enter title' }]}
              >
                <Input placeholder="Enter use case title" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="business_category"
                label="Business Category"
                rules={[{ required: true, message: 'Please enter business category' }]}
              >
                <Input placeholder="e.g., Customer Service, Operations, Analytics" />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            name="description"
            label="Description"
            rules={[{ required: true, message: 'Please enter description' }]}
          >
            <TextArea rows={3} placeholder="Describe the use case" />
          </Form.Item>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="aws_services"
                label="AWS Services"
                rules={[{ required: true, message: 'Please select AWS services' }]}
              >
                <Select
                  mode="multiple"
                  placeholder="Select AWS GenAI services"
                  showSearch
                  filterOption={(input, option) =>
                    option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {awsServices.map(service => (
                    <Option key={service} value={service}>{service}</Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="primary_genai_capability"
                label="Primary GenAI Capability"
                    rules={[{ required: true, message: 'Enter the primary GenAI capability ' }]}
              >
                <Input placeholder="e.g., LLM, NLP, Computer Vision" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={8}>
              <Form.Item name="priority" label="Priority">
                <Select>
                  {priorityOptions.map(option => (
                    <Option key={option} value={option}>{option}</Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="complexity" label="Complexity">
                <Select>
                  {complexityOptions.map(option => (
                    <Option key={option} value={option}>{option}</Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="roi_potential" label="ROI Potential">
                <Select>
                  {roiOptions.map(option => (
                    <Option key={option} value={option}>{option}</Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item label="Estimated Effort">
                <Input.Group compact>
                  <Form.Item
                    name="effort_number"
                    style={{ width: '70%' }}
                    rules={[{ required: true, message: 'Estimated effort required' }]}
                  >
                    <InputNumber
                      min={1}
                      placeholder="Enter number"
                      style={{ width: '100%' }}
                    />
                  </Form.Item>
                  <Form.Item
                    name="effort_unit"
                    style={{ width: '30%' }}
                  >
                    <Select>
                      {effortUnits.map(unit => (
                        <Option key={unit} value={unit}>{unit}</Option>
                      ))}
                    </Select>
                  </Form.Item>
                </Input.Group>
              </Form.Item>
            </Col>
            <Col span={12}>
  <Form.Item label="Cost Estimate" rules={[{ required: true, message: '' }]}>
    <Input.Group compact>
      <Form.Item
        name="cost_estimate_from"
        rules={[{ required: true, message: 'Please enter minimum cost estimate' }]}
        style={{ display: 'inline-block', width: 'calc(50% - 12px)' }}
      >
        <InputNumber
          placeholder="1,500"
          prefix="From $"
          style={{ width: '100%' }}
        />
      </Form.Item>
      <span
        style={{
          display: 'inline-block',
          width: '24px',
          lineHeight: '32px',
          textAlign: 'center',
        }}
      >
        -
      </span>
      <Form.Item
        name="cost_estimate_to"
        dependencies={['cost_estimate_from']}
        rules={[
          { required: true, message: 'Please enter maximum cost estimate' },
          ({ getFieldValue }) => ({
            validator(_, value) {
              const fromValue = getFieldValue('cost_estimate_from');
              if (!value || !fromValue || value >= fromValue) {
                return Promise.resolve();
              }
              return Promise.reject(new Error('To amount must be greater than or equal to From amount'));
            },
          }),
        ]}
        style={{ display: 'inline-block', width: 'calc(50% - 12px)' }}
      >
        <InputNumber
          placeholder="3,000"
          prefix="To $"
          style={{ width: '100%' }}
        />
      </Form.Item>
    </Input.Group>
  </Form.Item>
</Col>
          </Row>

          <Form.Item
            name="justification"
            label="Justification"
            rules={[{ required: true, message: 'Please provide justification' }]}
          >
            <TextArea 
              rows={3} 
              placeholder="Provide justification" 
            />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default UseCaseGeneration;