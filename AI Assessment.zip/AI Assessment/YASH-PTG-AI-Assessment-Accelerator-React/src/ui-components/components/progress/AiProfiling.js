import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  Card,
  Tabs,
  Upload,
  Button,
  Progress,
  Typography,
  Row,
  Col,
  Table,
  Alert,
  Spin,
  Statistic,
  Checkbox,
  Select,
  Modal,
  message,
  Descriptions,
  Tag,
  Space,
  Divider,
} from "antd";
import {
  InboxOutlined,
  FileTextOutlined,
  BarChartOutlined,
  DownloadOutlined,
  RocketOutlined,
  CheckCircleOutlined,
  WarningOutlined,
  InfoCircleOutlined,
} from "@ant-design/icons";
import {
  uploadProfilingData,
  setProfilingFile,
  clearProfilingResults,
  setProfilingResults,
} from "../../../redux/features/aiProfiling/aiProfilingSlice";
import {
  generateProfilingReport,
  getAIProfiling,
  runAIProfilingAnalysis,
} from "../../../redux/features/aiProfiling/aiProfilingActions";
import Papa from "papaparse";
import Markdown from "markdown-to-jsx";
import { geteUseCase } from "../../../redux/features/dataReadiness/dataReadinessActions";
import { getUseCaseProgressStatus } from "../../../redux/features/project/projectAction";

const { Title, Text, Paragraph } = Typography;
const { TabPane } = Tabs;
const { Dragger } = Upload;
const { Option } = Select;

const AIProfiling = () => {
  const dispatch = useDispatch();
  const {
    profilingFile,
    profilingResults,
    profilingCompleted,
    loading,
    error,
  } = useSelector((state) => state.aiProfiling);
  const { selectedUseCaseDetail, selectedSessionDetail } = useSelector(state => state.local);
  
  const [activeTab, setActiveTab] = useState("1");
  const [reportConfig, setReportConfig] = useState({
    includeMetadata: true,
    includeFullContent: true,
    format: "pdf",
  });
  const [fileList, setFileList] = useState([]);
  const [csvPreviews, setCsvPreviews] = useState({});

  useEffect(() => {
    if (!selectedUseCaseDetail) {
      console.log("Initializing with sample data...");
    }
  }, [selectedUseCaseDetail]);

  useEffect(() => {
    const checkAndPrefillData = () => {
      if (selectedUseCaseDetail?.id && selectedSessionDetail?.id) {
        // Fire both actions in parallel
        dispatch(geteUseCase({ sessionId: selectedSessionDetail.id, useCaseId: selectedUseCaseDetail.id }));

        dispatch(getUseCaseProgressStatus(selectedUseCaseDetail.id))
          .unwrap()
          .then((statusRes) => {
            const aiProfilingStatus = statusRes?.data?.ai_profiling_status;

            if (aiProfilingStatus?.toLowerCase() === 'completed') {
              dispatch(getAIProfiling(selectedUseCaseDetail.id))
                .unwrap()
                .then((result) => {
                  if (result.success && result.data) {
                    const data = result.data;

                    // Convert to AntD file format
                    const uploaded = [{
                      uid: '0',
                      name: data.analysis_result.file_analyzed,
                      status: 'done',
                      url: data.uploaded_doc_path,
                      type: data.document_uploaded?.mimetype || 'text/csv',
                      size: data.document_uploaded?.size || 0
                    }];

                    // Rebuild CSV previews from URLs if they are CSVs
                    uploaded.forEach((file) => {
                      if (file.name.toLowerCase().endsWith('.csv') && file.url) {
                        fetch(file.url)
                          .then(res => res.text())
                          .then(text => {
                            // Check for invalid HTML (expired URL or app fallback)
                            if (text.startsWith('<!DOCTYPE html>') || text.includes('<html')) {
                              message.error(`Preview failed: ${file.name} is not a valid CSV file.`);
                              return;
                            }

                            Papa.parse(text, {
                              header: true,
                              skipEmptyLines: true,
                              complete: (results) => {
                                setCsvPreviews(prev => ({
                                  ...prev,
                                  [file.uid]: {
                                    data: results.data.slice(0, 10),
                                    totalRows: results.data.length,
                                    columns: results.meta.fields || [],
                                    errors: results.errors
                                  }
                                }));
                              },
                              error: (error) => {
                                message.error(`Error parsing CSV from server: ${error.message}`);
                              }
                            });
                          })
                          .catch(err => {
                            message.error(`Error fetching file ${file.name}: ${err.message}`);
                          });
                      }
                    });

                    setFileList(uploaded);
                    dispatch(setProfilingResults(data));
                    message.success("Loaded previous AI profiling data.");
                  }
                })
                .catch((err) => {
                  console.error("Error fetching AI profiling data:", err);
                });
            }
          })
          .catch((err) => {
            console.error("Error fetching progress status:", err);
          });
      }
    };
    checkAndPrefillData();
  }, [selectedUseCaseDetail, selectedSessionDetail, dispatch]);

  const handleAnalyze = async () => {
    if (fileList.length === 0) {
      message.error("Please upload files first");
      return;
    }
    if (fileList.length > 1) {
      message.error("Please upload only one file at a time");
      return;
    }
    if (!selectedUseCaseDetail?.id) {
      message.error("Please select a use case first");
      return;
    }

    const profilingPayload = {
      files: [fileList[0]],
      useCaseId: selectedUseCaseDetail?.id,
      projectId: selectedUseCaseDetail?.project_id || selectedUseCaseDetail?.projectId,
      profilingConfig: {
        analysisDepth: "comprehensive",
        includeDataQuality: true,
        generateInsights: true,
        includeRecommendations: true,
      },
    };

    try {
      const response = await dispatch(runAIProfilingAnalysis(profilingPayload));
      if (runAIProfilingAnalysis.fulfilled.match(response)) {
        message.success("AI Profiling analysis completed successfully!");
        setActiveTab("2");
      } else if (runAIProfilingAnalysis.rejected.match(response)) {
        const errorMessage =
          response.payload?.message ||
          response.payload?.detail ||
          "AI Profiling analysis failed";
        message.error(errorMessage);
      }
    } catch (error) {
      message.error("AI Profiling analysis failed");
    }
  };

  const handleGenerateReport = async (format) => {
    if (!profilingResults?.analysis_result?.generated_content) {
      message.error("No profiling results to generate report");
      return;
    }

    try {
      const response = await dispatch(
        generateProfilingReport({
          use_case_id: selectedUseCaseDetail.id,
          ai_profiling_id: profilingResults.ai_profiling_id,
        })
      );

      if (generateProfilingReport.fulfilled.match(response)) {
        const reportData = response.payload;
        if (reportData?.data?.presigned_url) {
          const link = document.createElement("a");
          link.href = reportData.data.presigned_url;
          link.download = `ai_profiling_report_${selectedUseCaseDetail?.id}_${profilingResults.ai_profiling_id}.${format}`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          message.success(`${format.toUpperCase()} report downloaded successfully!`);
        } else {
          message.error("No download link available for this report. Please try again later.");
        }
      } else {
        message.error('Failed to generate report: ' + (response.payload?.message || 'Unknown error'));
      }
    } catch (error) {
      message.error("Error generating report: " + error.message);
    }
  };

  const handleFileUpload = (info) => {
    const { fileList } = info;
    setFileList(fileList);
    const previews = {};
    fileList.forEach((file) => {
      if (file.name.toLowerCase().endsWith('.csv')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          Papa.parse(e.target.result, {
            header: true,
            skipEmptyLines: true,
            complete: (results) => {
              previews[file.uid] = {
                data: results.data.slice(0, 10),
                totalRows: results.data.length,
                columns: results.meta.fields || [],
                errors: results.errors
              };
              setCsvPreviews(prev => ({ ...prev, ...previews }));
            },
            error: (error) => {
              message.error(`Error parsing CSV: ${error.message}`);
            }
          });
        };
        if (file.originFileObj) {
          reader.readAsText(file.originFileObj);
        }
      }
    });
  };

  const renderCSVPreview = () => {
    if (Object.keys(csvPreviews).length === 0) return null;

    return (
      <Card size="small" style={{ marginTop: 16 }}>
        {Object.entries(csvPreviews).map(([uid, preview], idx) => (
          <div key={uid} style={{ marginBottom: 16 }}>
            <Title level={5}>Preview: {fileList.find(f => f.uid === uid)?.name || `File ${idx + 1}`}</Title>
            <Row gutter={16} style={{ marginBottom: 16 }}>
              <Col span={6}>
                <Statistic title="Total Rows" value={preview.totalRows || 0} />
              </Col>
              <Col span={6}>
                <Statistic title="Columns" value={preview.columns?.length || 0} />
              </Col>
              <Col span={6}>
                <Statistic title="Preview Rows" value={Math.min(10, preview.data?.length || 0)} />
              </Col>
              <Col span={6}>
                <Statistic
                  title="File Size"
                  value={
                    fileList.find(f => f.uid === uid)?.size
                      ? `${(fileList.find(f => f.uid === uid).size / 1024 / 1024).toFixed(2)} MB`
                      : "N/A"
                  }
                />
              </Col>
            </Row>
            <Table
              dataSource={preview.data || []}
              columns={preview.columns.map((col) => ({
                title: col,
                dataIndex: col,
                key: col,
                ellipsis: true,
                width: 150,
              }))}
              pagination={false}
              scroll={{ x: true }}
              size="small"
              rowKey={(record, index) => index}
            />
            {preview.errors?.length > 0 && (
              <Alert
                message="CSV Parsing Warnings"
                description={preview.errors.map(err => err.message).join(', ')}
                type="warning"
                style={{ marginTop: 8 }}
              />
            )}
          </div>
        ))}
      </Card>
    );
  };

  const renderUploadTab = () => (
    <div>
      <Title level={4}>
        <InboxOutlined /> Upload Data for AI Profiling
      </Title>
      {selectedUseCaseDetail && (
        <Alert
          message={`Profiling data for Use Case: ${selectedUseCaseDetail?.title}`}
          type="info"
          showIcon
          style={{ marginBottom: 16 }}
        />
      )}
      <Card>
        <Dragger
          onChange={handleFileUpload}
          beforeUpload={() => false}
          style={{ marginBottom: 16 }}
          fileList={fileList}
          accept=".csv,.xlsx,.xls,.json,.txt,.pdf"
          maxCount={1}
        >
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">
            Click or drag file to this area to upload
          </p>
          <p className="ant-upload-hint">
            Support for CSV, Excel, JSON, TXT files. Maximum file size: 50MB
          </p>
        </Dragger>
        {fileList.length > 0 && fileList[0] && (
          <Card size="small" style={{ marginTop: 16 }}>
            <Descriptions column={3} bordered size="small">
              <Descriptions.Item label="Filename">
                {fileList[0].name || "Unknown"}
              </Descriptions.Item>
              <Descriptions.Item label="File Type">
                {fileList[0].type || "Unknown"}
              </Descriptions.Item>
              <Descriptions.Item label="Size">
                {fileList[0].size
                  ? `${(fileList[0].size / 1024 / 1024).toFixed(2)} MB`
                  : "Unknown"}
              </Descriptions.Item>
            </Descriptions>
          </Card>
        )}
        {renderCSVPreview()}
        {fileList.length > 0 && (
          <div style={{ marginTop: 16, textAlign: "center" }}>
            <Button
              type="primary"
              size="medium"
              icon={<RocketOutlined />}
              loading={loading}
              onClick={handleAnalyze}
              className="ant-btn-primary-custom"
            >
              Analyze File with AI Profiling
            </Button>
          </div>
        )}
      </Card>
    </div>
  );

  const renderProfilingTab = () => {
    if (!profilingResults) {
      return (
        <Alert
          message="Please upload and analyze a data file first."
          type="warning"
          showIcon
        />
      );
    }

    const {
      file_analyzed,
      data_quality_score,
      analysis_type,
      generated_at,
      generated_content,
    } = profilingResults.analysis_result;

    return (
      <div>
        <Title level={4}>
          <BarChartOutlined /> AI Profiling Analysis
        </Title>
        <Row gutter={16} style={{ marginBottom: 24 }}>
          <Col span={6}>
            <Card>
              <Statistic
                title="File Analyzed"
                value={file_analyzed || "Unknown"}
                valueStyle={{ color: "#3f8600" }}
              />
            </Card>
          </Col>
          <Col span={6}>
            <Card>
              <Statistic
                title="Quality Score"
                value={data_quality_score || 0}
                suffix="%"
                valueStyle={{
                  color:
                    data_quality_score >= 80
                      ? "#3f8600"
                      : data_quality_score >= 60
                      ? "#faad14"
                      : "#cf1322",
                }}
              />
            </Card>
          </Col>
          <Col span={6}>
            <Card>
              <Statistic
                title="Analysis Type"
                value={analysis_type || "Basic"}
                valueStyle={{ color: "#722ed1" }}
              />
            </Card>
          </Col>
          <Col span={6}>
            <Card>
              <Statistic
                title="Status"
                value="Complete"
                prefix={<CheckCircleOutlined />}
                valueStyle={{ color: "#3f8600" }}
              />
            </Card>
          </Col>
        </Row>
        <Card title="Analysis Report Preview">
          {generated_content ? (
            <div>
              <Markdown>
                {generated_content.length > 500
                  ? `${generated_content.substring(0, 500)}...`
                  : generated_content}
              </Markdown>
              {generated_content.length > 500 && (
                <Button
                  type="link"
                  onClick={() => setActiveTab("3")}
                  className="ant-btn-default-custom"
                >
                  View Full Report
                </Button>
              )}
            </div>
          ) : (
            <Alert
              message="No detailed analysis content available."
              type="info"
            />
          )}
        </Card>
        {generated_at && (
          <Alert
            message={`Analysis completed at: ${generated_at}`}
            type="success"
            style={{ marginTop: 16 }}
          />
        )}
      </div>
    );
  };

  const renderResultsTab = () => {
    if (!profilingResults) {
      return (
        <Alert
          message="No profiling results available. Please run the profiling analysis first."
          type="info"
          showIcon
        />
      );
    }

    const { generated_content, ...metadata } = profilingResults.analysis_result;

    return (
      <div>
        <Title level={4}>
          <FileTextOutlined /> Detailed Analysis Results
        </Title>
        {generated_content && (
          <Card title="Complete Analysis Report" style={{ marginBottom: 16 }}>
            <Markdown>{generated_content}</Markdown>
          </Card>
        )}
        <Card title="Analysis Metadata">
          <Descriptions bordered column={2}>
            {Object.entries(metadata).map(([key, value]) => (
              <Descriptions.Item
                label={key
                  .replace(/_/g, " ")
                  .replace(/\b\w/g, (l) => l.toUpperCase())}
                key={key}
              >
                {typeof value === "object"
                  ? JSON.stringify(value)
                  : String(value)}
              </Descriptions.Item>
            ))}
          </Descriptions>
        </Card>
      </div>
    );
  };

  const renderReportTab = () => {
    if (!profilingResults) {
      return (
        <Alert
          message="Please complete the profiling analysis first."
          type="info"
          showIcon
        />
      );
    }

    return (
      <div>
        <Title level={4}>
          <DownloadOutlined /> Generate AI Profiling Report
        </Title>
        <Card title="Report Configuration" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={12}>
              <Space direction="vertical">
                <Checkbox
                  checked={reportConfig.includeMetadata}
                  onChange={(e) =>
                    setReportConfig({
                      ...reportConfig,
                      includeMetadata: e.target.checked,
                    })
                  }
                >
                  Include analysis metadata
                </Checkbox>
                <Checkbox
                  checked={reportConfig.includeFullContent}
                  onChange={(e) =>
                    setReportConfig({
                      ...reportConfig,
                      includeFullContent: e.target.checked,
                    })
                  }
                >
                  Include full analysis content
                </Checkbox>
              </Space>
            </Col>
            <Col span={12}>
              <Space direction="vertical">
                <Text strong>Report format:</Text>
                <Select
                  value={reportConfig.format}
                  onChange={(value) =>
                    setReportConfig({ ...reportConfig, format: value })
                  }
                  style={{ width: "100%" }}
                >
                  <Option value="pdf">PDF</Option>
                  <Option value="json">JSON</Option>
                  <Option value="markdown">Markdown</Option>
                </Select>
              </Space>
            </Col>
          </Row>
        </Card>
        <Card title="Report Content Preview" style={{ marginBottom: 16 }}>
          {profilingResults?.analysis_result?.generated_content && (
            <Markdown>
              {profilingResults.analysis_result.generated_content
                .split("\n")
                .slice(0, 15)
                .join("\n")}
            </Markdown>
          )}
        </Card>
        <Card title="Generate Report">
          <Row gutter={16}>
            <Col span={8}>
              <Button
                type="primary"
                block
                loading={loading}
                onClick={() => handleGenerateReport("pdf")}
                className="ant-btn-primary-custom"
              >
                Generate PDF Report
              </Button>
            </Col>
            <Col span={8}>
              <Button
                block
                loading={loading}
                onClick={() => handleGenerateReport("json")}
                className="ant-btn-default-custom"
              >
                Export JSON Data
              </Button>
            </Col>
            <Col span={8}>
              <Button
                block
                loading={loading}
                onClick={() => handleGenerateReport("markdown")}
                className="ant-btn-default-custom"
              >
                Export Markdown
              </Button>
            </Col>
          </Row>
        </Card>
      </div>
    );
  };

  if (!selectedUseCaseDetail) {
    return (
      <Card>
        <Alert
          message="Please select a project first from the Project Management page."
          type="warning"
          showIcon
          action={
            <Button type="primary" className="ant-btn-primary-custom">
              Go to Project Management
            </Button>
          }
        />
      </Card>
    );
  }

  return (
    <div style={{ padding: 24 }}>
      <Card style={{ marginBottom: "16px" }}>
        <Title level={3} style={{ margin: "0 0 8px 0" }}>
          🤖 AI Profiling
        </Title>
        <Text>Perform detailed AI model profiling and data analysis</Text>
        <Alert
          message={`📊 Working on: ${selectedUseCaseDetail.title}`}
          type="info"
          style={{ margin: "12px 0 0 0" }}
        />
      </Card>
      <Spin spinning={loading}>
        <Tabs activeKey={activeTab} onChange={setActiveTab} size="large">
          <TabPane
            tab={
              <span>
                <InboxOutlined /> Upload Data
              </span>
            }
            key="1"
          >
            {renderUploadTab()}
          </TabPane>
          <TabPane
            tab={
              <span>
                <BarChartOutlined /> Profile Data
              </span>
            }
            key="2"
          >
            {renderProfilingTab()}
          </TabPane>
          <TabPane
            tab={
              <span>
                <FileTextOutlined /> Analysis Results
              </span>
            }
            key="3"
          >
            {renderResultsTab()}
          </TabPane>
          <TabPane
            tab={
              <span>
                <DownloadOutlined /> Generate Report
              </span>
            }
            key="4"
          >
            {renderReportTab()}
          </TabPane>
        </Tabs>
      </Spin>
      {error && (
        <Alert
          message="Error"
          description={error}
          type="error"
          closable
          style={{ marginTop: 16 }}
        />
      )}
    </div>
  );
};

export default AIProfiling;