import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  Card, Tabs, Form, Select, InputNumber, DatePicker, Button, 
  Checkbox, Row, Col, Statistic, Table, Collapse, message,
  Typography, Space, Divider, Tag,
  Alert, Skeleton
} from 'antd';
import {
  RocketOutlined, SettingOutlined,
  BarChartOutlined, TeamOutlined, CalendarOutlined,
  DollarOutlined, WarningOutlined
} from '@ant-design/icons';
import moment from 'moment';

import { setSprintConfig, setSprintPlan, setSprintPlanningCompleted } from '../../../redux/features/sprint/sprintSlice';
import { generateSprintPlan, exportSprintPlan, getSprintData, getOverallScore } from '../../../redux/features/sprint/sprintAction';
import { geteUseCase } from '../../../redux/features/dataReadiness/dataReadinessActions';
import { getUseCaseProgressStatus } from '../../../redux/features/project/projectAction';

const { Title, Text } = Typography;
const { TabPane } = Tabs;
const { Panel } = Collapse;

const SprintPlanning = () => {
  const dispatch = useDispatch();
  const [form] = Form.useForm();
  const [activeTab, setActiveTab] = useState('1');
  const [loading, setLoading] = useState(false);
  const [sprintPlanningStatus, setSprintPlanningStatus] = useState('pending'); // pending, inprogress, completed
  const [initialDataLoaded, setInitialDataLoaded] = useState(false);
  
  const { overallScore, overallLoading } = useSelector((state) => state.sprint);

  const {
    sprintConfig,
    sprintPlan,
    sprintPlanningCompleted,
    assessmentResults,
    complianceResults,
    profilingResults,
    evaluationResults
  } = useSelector(state => state.sprint);
  
  const selectedUseCase = useSelector(state => state.local.selectedUseCaseDetail);
  const { selectedUseCaseDetail, selectedSessionDetail } = useSelector(state => state.local);

  // Function to check sprint planning status
  const checkSprintPlanningStatus = async () => {
    if (!selectedUseCaseDetail?.id) return;

    try {
      const statusRes = await dispatch(getUseCaseProgressStatus(selectedUseCaseDetail.id)).unwrap();
      
      // Check if sprint planning is completed (you may need to adjust this based on your API response structure)
      const sprintStatus = statusRes?.data?.sprint_planning_status || 'pending';
      setSprintPlanningStatus(sprintStatus);

      if (sprintStatus.toLowerCase() === 'completed') {
        // Load existing sprint planning data
        await loadExistingSprintData();
      }
    } catch (error) {
      console.error("Error checking sprint planning status:", error);
      setSprintPlanningStatus('pending');
    }
  };

  // Function to load existing sprint data and prefill forms
  const loadExistingSprintData = async () => {
    if (!selectedUseCaseDetail?.id) return;

    try {
      const result = await dispatch(getSprintData(selectedUseCaseDetail.id)).unwrap();
      
      if (result.success && result.data) {
        const data = result.data;
        
        // Set sprint plan data
        dispatch(setSprintPlan(data));
        dispatch(setSprintPlanningCompleted(true));

        // Prefill configuration form with existing data
        const configData = {
          projectType: data.project_type || 'Web Application',
          methodology: data.methodology || 'Agile/Scrum',
          teamSize: data.team_size || 4,
          sprintDuration: data.sprint_duration_weeks ? `${data.sprint_duration_weeks} weeks` : '2 weeks',
          totalSprints: data.total_sprints || 4,
          startDate: data.start_date ? moment(data.start_date) : null,
          
          // Team composition from API data
          frontendDevs: data.team_composition?.['Frontend Developer'] || data.team_composition?.['Full-Stack Developer'] || 1,
          backendDevs: data.team_composition?.['Backend Developer'] || data.team_composition?.['Full-Stack Developer'] || 2,
          mlEngineers: data.team_composition?.['ML Engineer'] || 1,
          dataScientists: data.team_composition?.['Data Scientist'] || 1,
          devopsEngineers: data.team_composition?.['DevOps Engineer'] || 1,
          qaEngineers: data.team_composition?.['QA Engineer'] || 1,
          
          // Project priorities
          priorities: data.project_priorities || [],
          
          // Checkboxes
          includeTesting: data.include_comprehensive_testing_phases ? data.include_comprehensive_testing_phases: false,
          includeDeployment: data.include_deployment_and_monitoring_setup ? data.include_deployment_and_monitoring_setup: false,
          includeDocumentation:  data.include_documentation_tasks ? data.include_documentation_tasks: false
        };

        // Set form values
        form.setFieldsValue(configData);
        
        // Set sprint config in Redux
        dispatch(setSprintConfig({
          ...configData,
          useCase: selectedUseCase,
          startDate: configData.startDate ? configData.startDate.format('YYYY-MM-DD') : null
        }));

        // Auto-navigate to results tab if data is loaded
        setActiveTab('3');
        setInitialDataLoaded(true);
        
        message.success("Loaded existing sprint planning data successfully!");
      }
    } catch (error) {
      console.error("Error loading existing sprint data:", error);
      message.error("Failed to load existing sprint planning data");
    }
  };

  // Main useEffect for initialization
  useEffect(() => {
    const initializeComponent = async () => {
      if (selectedUseCaseDetail?.id && selectedSessionDetail?.id && !initialDataLoaded) {
        // Load overall score
        dispatch(getOverallScore(selectedUseCaseDetail.id));
        
        // Load use case data
        dispatch(geteUseCase({ 
          sessionId: selectedSessionDetail.id, 
          useCaseId: selectedUseCaseDetail.id 
        }));
        
        // Check sprint planning status and load data if completed
        await checkSprintPlanningStatus();
      }
    };

    initializeComponent();
  }, [selectedUseCaseDetail?.id, selectedSessionDetail?.id, dispatch, initialDataLoaded]);

  // Handle configuration save
  const handleConfigSave = (values) => {
    const configData = {
      ...values,
      useCase: selectedUseCase,
      startDate: values.startDate ? values.startDate.format('YYYY-MM-DD') : null
    };

    dispatch(setSprintConfig(configData));
    message.success('Sprint configuration saved successfully!');
    setActiveTab('2');
  };

  // Handle plan generation
  const handleGeneratePlan = async () => {
    setLoading(true);
    try {
      const response = await dispatch(generateSprintPlan(sprintConfig));
      dispatch(setSprintPlanningCompleted(true));
      setSprintPlanningStatus('completed');
      message.success('Sprint plan generated successfully!');
      setActiveTab('3');
    } catch (error) {
      message.error('Failed to generate sprint plan');
    }
    setLoading(false);
  };

  // Handle report generation
  const handleGenerateReport = async () => {
    try {
      const response = await dispatch(exportSprintPlan({ 
        sprint_planning_id: sprintPlan.sprint_planning_id 
      })).unwrap();
      
      const { presigned_url } = response;

      if (presigned_url) {
        const link = document.createElement('a');
        link.href = presigned_url;
        link.download = `sprint_plan_${sprintPlan.sprint_planning_id}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        message.success('PDF download started successfully!');
      } else {
        message.error('Failed to retrieve download URL');
      }
    } catch (error) {
      console.error('Error generating PDF:', error);
      message.error('Failed to generate PDF');
    }
  };

  // Status indicator component
  const StatusIndicator = () => {
    const getStatusColor = (status) => {
      switch (status.toLowerCase()) {
        case 'completed': return 'success';
        case 'inprogress': return 'processing';
        case 'pending': return 'default';
        default: return 'default';
      }
    };

    const getStatusText = (status) => {
      switch (status.toLowerCase()) {
        case 'completed': return 'Completed';
        case 'inprogress': return 'In Progress';
        case 'pending': return 'Pending';
        default: return 'Unknown';
      }
    };

    return (
      <Tag color={getStatusColor(sprintPlanningStatus)}>
        {getStatusText(sprintPlanningStatus)}
      </Tag>
    );
  };

  // Updated column mappings based on the API response structure
  const sprintColumns = [
    { 
      title: 'Sprint', 
      dataIndex: 'sprint_number', 
      key: 'sprint_number',
      render: (sprint_number) => `Sprint ${sprint_number}`
    },
    { 
      title: 'Goals', 
      dataIndex: 'goals', 
      key: 'goals', 
      render: (goals) => goals?.join(', ') || '' 
    },
    { 
      title: 'Duration', 
      dataIndex: 'duration', 
      key: 'duration' 
    },
    { 
      title: 'Tasks', 
      dataIndex: 'tasks', 
      key: 'tasks', 
      render: (tasks) => tasks?.length || 0 
    },
    { 
      title: 'Deliverables', 
      dataIndex: 'deliverables', 
      key: 'deliverables', 
      render: (deliverables) => deliverables?.length || 0 
    }
  ];

  const taskColumns = [
    { title: 'Task', dataIndex: 'task', key: 'task' },
    { title: 'Assignee', dataIndex: 'assignee', key: 'assignee' },
    { title: 'Effort', dataIndex: 'effort', key: 'effort' },
    { 
      title: 'Sprint', 
      dataIndex: 'sprint_number', 
      key: 'sprint_number',
      render: (_, record, index) => {
        if (sprintPlan?.generated_content?.sprint_plan?.sprints) {
          for (let sprint of sprintPlan.generated_content.sprint_plan.sprints) {
            if (sprint.tasks.some(task => task.task === record.task)) {
              return `Sprint ${sprint.sprint_number}`;
            }
          }
        }
        return 'N/A';
      }
    }
  ];

  // Function to extract all tasks from sprints for the task table
  const getAllTasks = () => {
    if (!sprintPlan?.generated_content?.sprint_plan?.sprints) return [];
    
    const allTasks = [];
    sprintPlan.generated_content.sprint_plan.sprints.forEach(sprint => {
      sprint.tasks.forEach(task => {
        allTasks.push({
          ...task,
          sprint_number: sprint.sprint_number,
          key: `${sprint.sprint_number}-${task.task}`
        });
      });
    });
    return allTasks;
  };

  return (
    <div className="sprint-planning-container" style={{ padding: '', background: '#f5f5f5', minHeight: '100vh' }}>
      <Card style={{ marginBottom: '16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <Title level={3} style={{ margin: '0 0 8px 0' }}>⚡ Sprint Planning</Title>
            <Text>Create comprehensive sprint plans for AI implementation</Text>
          </div>
          <StatusIndicator />
        </div>
        <Alert 
          message={`📊 Working on: ${selectedUseCase?.title || 'No use case selected'}`} 
          type="info" 
          style={{ margin: '12px 0 0 0' }} 
        />
      </Card>

      <Card 
        className="main-card"
        style={{ 
          maxWidth: '', 
          margin: '0 auto',
          borderRadius: '12px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
        }}
      >
        {/* Statistics Row */}
        <Row gutter={[24, 16]} style={{ marginBottom: '32px' }}>
          <Col xs={24} sm={12} lg={6}>
            <Card style={{ textAlign: 'center', borderRadius: '8px' }}>
              <Skeleton loading={overallLoading} active avatar>
                <Statistic
                  title={<span style={{fontWeight:'bold', color: 'rgb(77, 81, 72)'}}>Data Readiness</span>}
                  value={overallScore?.readinessScore || 0}
                  suffix="%"
                  valueStyle={{ color: '#3f8600', fontSize: '24px' }}
                />
              </Skeleton>
            </Card>
          </Col>
          <Col xs={24} sm={12} lg={6}>
            <Card style={{ textAlign: 'center', borderRadius: '8px' }}>
              <Skeleton loading={overallLoading} active avatar>
                <Statistic
                  title={<span style={{fontWeight:'bold', color: 'rgb(77, 81, 72)'}}>Compliance Score</span>}
                  value={overallScore?.complianceScore || 0}
                  suffix="%"
                  valueStyle={{ color: ' #3f8600', fontSize: '24px' }}
                />
              </Skeleton>
            </Card>
          </Col>
          <Col xs={24} sm={12} lg={6}>
            <Card style={{ textAlign: 'center', borderRadius: '8px' }}>
              <Skeleton loading={overallLoading} active avatar>
                <Statistic
                  title={<span style={{fontWeight:'bold', color: 'rgb(77, 81, 72)'}}>Data Quality</span>}
                  value={overallScore?.profilingScore || 0}
                  suffix="%"
                  valueStyle={{ color: '#3f8600', fontSize: '24px' }}
                />
              </Skeleton>
            </Card>
          </Col>
          <Col xs={24} sm={12} lg={6}>
            <Card style={{ textAlign: 'center', borderRadius: '8px' }}>
              <Skeleton loading={overallLoading} active avatar>
                <Statistic
                  title={<span style={{fontWeight:'bold', color: 'rgb(77, 81, 72)'}}>Model Performance</span>}
                  value={overallScore?.modelEvaluationScore || 0}
                  suffix="%"
                  valueStyle={{ color: '#3f8600', fontSize: '24px' }}
                />
              </Skeleton>
            </Card>
          </Col>
        </Row>

        {/* Tabs Section */}
        <Tabs 
          activeKey={activeTab} 
          onChange={setActiveTab}
          style={{ margin: '0 -24px' }}
          tabBarStyle={{ paddingLeft: '24px', paddingRight: '24px' }}
        >
          <TabPane tab={<><SettingOutlined /> Configure Sprint</>} key="1">
            <div style={{ padding: '0 24px 24px' }}>
              <Card style={{ borderRadius: '8px' }}>
                <Form form={form} layout="vertical" onFinish={handleConfigSave} initialValues={{
    priorities: [], // default to empty array
    includeTesting: false,
    includeDeployment: false,
    includeDocumentation: false
  }}> 
                  <Title level={4} style={{ marginBottom: '24px', color: '#1890ff' }}>
                    Project Configuration
                  </Title>
                  
                  <Row gutter={[24, 16]} style={{ marginBottom: '24px' }}>
                    <Col xs={24} md={8}>
                      <Form.Item name="projectType" label="Project Type" initialValue="Web Application">
                        <Select size="large">
                          <Select.Option value="Web Application">Web Application</Select.Option>
                          <Select.Option value="Mobile Application">Mobile Application</Select.Option>
                          <Select.Option value="API Service">API Service</Select.Option>
                          <Select.Option value="Data Pipeline">Data Pipeline</Select.Option>
                          <Select.Option value="Machine Learning Model">Machine Learning Model</Select.Option>
                          <Select.Option value="Chatbot">Chatbot</Select.Option>
                        </Select>
                      </Form.Item>
                    </Col>
                    <Col xs={24} md={8}>
                      <Form.Item name="methodology" label="Development Methodology" initialValue="Agile/Scrum">
                        <Select size="large">
                          <Select.Option value="Agile/Scrum">Agile/Scrum</Select.Option>
                          <Select.Option value="Kanban">Kanban</Select.Option>
                          <Select.Option value="Hybrid">Hybrid</Select.Option>
                          <Select.Option value="Waterfall">Waterfall</Select.Option>
                        </Select>
                      </Form.Item>
                    </Col>
                    <Col xs={24} md={8}>
                      <Form.Item name="teamSize" label="Team Size" initialValue={5}>
                        <InputNumber min={1} max={20} size="large" style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                  </Row>

                  <Row gutter={[24, 16]} style={{ marginBottom: '24px' }}>
                    <Col xs={24} md={8}>
                      <Form.Item name="sprintDuration" label="Sprint Duration" initialValue="2">
                        <Select size="large">
                          <Select.Option value="1">1 week</Select.Option>
                          <Select.Option value="2">2 weeks</Select.Option>
                          <Select.Option value="3">3 weeks</Select.Option>
                          <Select.Option value="4">4 weeks</Select.Option>
                        </Select>
                      </Form.Item>
                    </Col>
                    <Col xs={24} md={8}>
                      <Form.Item name="totalSprints" label="Total Sprints" initialValue={6}>
                        <InputNumber min={1} max={20} size="large" style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                    <Col xs={24} md={8}>
                      <Form.Item name="startDate" label="Start Date">
                        <DatePicker size="large" style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                  </Row>

                  <Divider style={{ margin: '32px 0' }} />
                  
                  <Title level={5} style={{ marginBottom: '24px', color: '#52c41a' }}>
                    Team Composition
                  </Title>
                  <Row gutter={[24, 16]} style={{ marginBottom: '24px' }}>
                    <Col xs={24} md={8}>
                      <Form.Item name="frontendDevs" label="Frontend Developers" initialValue={1}>
                        <InputNumber min={0} max={10} size="large" style={{ width: '100%' }} />
                      </Form.Item>
                      <Form.Item name="backendDevs" label="Backend Developers" initialValue={2}>
                        <InputNumber min={0} max={10} size="large" style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                    <Col xs={24} md={8}>
                      <Form.Item name="mlEngineers" label="ML Engineers" initialValue={1}>
                        <InputNumber min={0} max={10} size="large" style={{ width: '100%' }} />
                      </Form.Item>
                      <Form.Item name="dataScientists" label="Data Scientists" initialValue={1}>
                        <InputNumber min={0} max={10} size="large" style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                    <Col xs={24} md={8}>
                      <Form.Item name="devopsEngineers" label="DevOps Engineers" initialValue={1}>
                        <InputNumber min={0} max={10} size="large" style={{ width: '100%' }} />
                      </Form.Item>
                      <Form.Item name="qaEngineers" label="QA Engineers" initialValue={1}>
                        <InputNumber min={0} max={10} size="large" style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                  </Row>

                  <Divider style={{ margin: '32px 0' }} />

                  <Form.Item name="priorities" label="Project Priorities" style={{ marginBottom: '32px' }}>
                    <Checkbox.Group>
                      <Row gutter={[16, 16]}>
                        <Col xs={24} sm={12} md={8}>
                          <Checkbox value="Time to Market">Time to Market</Checkbox>
                        </Col>
                        <Col xs={24} sm={12} md={8}>
                          <Checkbox value="Cost Optimization">Cost Optimization</Checkbox>
                        </Col>
                        <Col xs={24} sm={12} md={8}>
                          <Checkbox value="Performance">Performance</Checkbox>
                        </Col>
                        <Col xs={24} sm={12} md={8}>
                          <Checkbox value="Scalability">Scalability</Checkbox>
                        </Col>
                        <Col xs={24} sm={12} md={8}>
                          <Checkbox value="Security">Security</Checkbox>
                        </Col>
                        <Col xs={24} sm={12} md={8}>
                          <Checkbox value="User Experience">User Experience</Checkbox>
                        </Col>
                      </Row>
                    </Checkbox.Group>
                  </Form.Item>

                  <Row gutter={[24, 16]} style={{ marginBottom: '32px' }}>
                    <Col xs={24} md={8}>
                      <Form.Item name="includeTesting" valuePropName="checked" >
                        <Checkbox>Include comprehensive testing phases</Checkbox>
                      </Form.Item>
                    </Col>
                    <Col xs={24} md={8}>
                      <Form.Item name="includeDeployment" valuePropName="checked" >
                        <Checkbox>Include deployment and monitoring setup</Checkbox>
                      </Form.Item>
                    </Col>
                    <Col xs={24} md={8}>
                      <Form.Item name="includeDocumentation" valuePropName="checked" >
                        <Checkbox>Include documentation tasks</Checkbox>
                      </Form.Item>
                    </Col>
                  </Row>

                  <Form.Item style={{ textAlign: 'center', marginTop: '32px' }}>
                    <Button 
                      type="primary" 
                      htmlType="submit" 
                      icon={<SettingOutlined />} 
                      size="large"
                      style={{ 
                        minWidth: '200px',
                        height: '50px',
                        borderRadius: '8px',
                        fontSize: '16px'
                      }}
                      className='ant-btn-primary-custom'
                    >
                      Save Configuration
                    </Button>
                  </Form.Item>
                </Form>
              </Card>
            </div>
          </TabPane>

          <TabPane tab={<><RocketOutlined /> Generate Plan</>} key="2">
            <div style={{ padding: '0 24px 24px' }}>
              <Card style={{ borderRadius: '8px', textAlign: 'center' }}>
                <Title level={4} style={{ marginBottom: '24px' }}>Generate Sprint Plan</Title>
                {sprintConfig ? (
                  <div>
                    <Title level={5} style={{ marginBottom: '24px', textAlign: 'left' }}>
                      Configuration Summary
                    </Title>
                    <Row gutter={[24, 16]} style={{ marginBottom: '32px' }}>
                      <Col xs={24} md={8}>
                        <Card size="small" style={{ background: '#fafafa', border: 'none' }}>
                          <Text strong>Project Type: </Text><Text>{sprintConfig.projectType}</Text><br/>
                          <Text strong>Team Size: </Text><Text>{sprintConfig.teamSize} members</Text><br/>
                          <Text strong>Methodology: </Text><Text>{sprintConfig.methodology}</Text>
                        </Card>
                      </Col>
                      <Col xs={24} md={8}>
                        <Card size="small" style={{ background: '#fafafa', border: 'none' }}>
                          <Text strong>Sprint Duration: </Text><Text>{sprintConfig.sprintDuration}</Text><br/>
                          <Text strong>Total Sprints: </Text><Text>{sprintConfig.totalSprints}</Text><br/>
                          <Text strong>Start Date: </Text><Text>{sprintConfig.startDate}</Text>
                        </Card>
                      </Col>
                      <Col xs={24} md={8}>
                        <Card size="small" style={{ background: '#fafafa', border: 'none' }}>
                          <Text strong>Priorities: </Text><Text>{sprintConfig.priorities?.join(', ') || 'None'}</Text><br/>
                          <Text strong>Include Testing: </Text><Text>{sprintConfig.includeTesting ? 'Yes' : 'No'}</Text><br/>
                          <Text strong>Include Deployment: </Text><Text>{sprintConfig.includeDeployment ? 'Yes' : 'No'}</Text>
                        </Card>
                      </Col>
                    </Row>
                    <Button 
                      type="primary" 
                      size="large" 
                      loading={loading}
                      onClick={handleGeneratePlan}
                      icon={<RocketOutlined />}
                      // disabled={sprintPlanningStatus === 'completed'}
                      style={{ 
                        minWidth: '300px',
                        height: '60px',
                        borderRadius: '12px',
                        fontSize: '20px',
                        fontWeight: 'bold',
                        padding: '4px'
                      }}
                      className='ant-btn-primary-custom'
                    >
                      {sprintPlanningStatus === 'completed' ? 'Generated again sprint plan' : 'Generate Sprint Plan'}
                    </Button>
                  </div>
                ) : (
                  <div style={{ padding: '40px' }}>
                    <Text type="warning" style={{ fontSize: '16px' }}>
                      Please configure sprint parameters first.
                    </Text>
                  </div>
                )}
              </Card>
            </div>
          </TabPane>

          <TabPane tab={<><BarChartOutlined /> View Plan</>} key="3">
            <div style={{ padding: '0 24px 24px' }}>
              <Card style={{ borderRadius: '8px' }}>
                {sprintPlan ? (
                  <div>
                    <Title level={4} style={{ marginBottom: '32px' }}>Sprint Plan Overview</Title>
                    
                    <Row gutter={[24, 16]} style={{ marginBottom: '32px' }}>
                      <Col xs={24} sm={12} lg={6}>
                        <Card style={{ textAlign: 'center', background: '#e6f7ff', border: '1px solid #91d5ff' }}>
                          <Statistic
                            title="Total Sprints"
                            value={sprintPlan.total_sprints || sprintPlan.generated_content?.sprint_plan?.total_sprints}
                            prefix={<CalendarOutlined />}
                            valueStyle={{ color: '#1890ff' }}
                          />
                        </Card>
                      </Col>
                      <Col xs={24} sm={12} lg={6}>
                        <Card style={{ textAlign: 'center', background: '#f6ffed', border: '1px solid #b7eb8f' }}>
                          <Statistic
                            title="Total Duration"
                            value={sprintPlan.estimated_duration || sprintPlan.generated_content?.sprint_plan?.duration}
                            prefix={<CalendarOutlined />}
                            valueStyle={{ color: '#52c41a' }}
                          />
                        </Card>
                      </Col>
                      <Col xs={24} sm={12} lg={6}>
                        <Card style={{ textAlign: 'center', background: '#fff2e8', border: '1px solid #ffbb96' }}>
                          <Statistic
                            title="Estimated Cost"
                            value={sprintPlan.estimated_cost || sprintPlan.generated_content?.budget_estimation?.total_poc_cost}
                            prefix={<DollarOutlined />}
                            valueStyle={{ color: '#fa8c16' }}
                          />
                        </Card>
                      </Col>
                      <Col xs={24} sm={12} lg={6}>
                        <Card style={{ textAlign: 'center', background: '#f9f0ff', border: '1px solid #d3adf7' }}>
                          <Statistic
                            title="Team Size"
                            value={sprintPlan.generated_content?.team_structure?.total_developers || sprintConfig?.teamSize}
                            suffix="members"
                            prefix={<TeamOutlined />}
                            valueStyle={{ color: '#722ed1' }}
                          />
                        </Card>
                      </Col>
                    </Row>

                    <div style={{ marginBottom: '32px' }}>
                      <Title level={5} style={{ marginBottom: '16px' }}>Sprint Breakdown</Title>
                      <Table 
                        dataSource={sprintPlan.generated_content?.sprint_plan?.sprints || sprintPlan.sprints} 
                        columns={sprintColumns}
                        pagination={false}
                        size="middle"
                        style={{ borderRadius: '8px' }}
                        rowKey="sprint_number"
                      />
                    </div>

                    <div style={{ marginBottom: '32px' }}>
                      <Title level={5} style={{ marginBottom: '16px' }}>All Tasks</Title>
                      <Table 
                        dataSource={getAllTasks()} 
                        columns={taskColumns}
                        pagination={{ pageSize: 10 }}
                        size="middle"
                        style={{ borderRadius: '8px' }}
                        rowKey="key"
                      />
                    </div>

                    {(sprintPlan.generated_content?.risks_and_mitigation || sprintPlan.risks) && (
                      <div style={{ marginBottom: '32px' }}>
                        <Title level={5} style={{ marginBottom: '16px' }}>Risk Assessment</Title>
                        <Collapse style={{ borderRadius: '8px' }}>
                          {(sprintPlan.generated_content?.risks_and_mitigation || sprintPlan.risks).map((risk, index) => (
                            <Panel 
                              header={
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                  <WarningOutlined style={{ color: '#ff4d4f', marginRight: '8px' }} />
                                  <Text strong>{risk.risk}</Text>
                                </div>
                              } 
                              key={index}
                            >
                              <div style={{ padding: '16px 0' }}>
                                <div style={{ marginBottom: '12px' }}>
                                  <Text strong>Impact: </Text><Text>{risk.impact}</Text>
                                </div>
                                <div>
                                  <Text strong>Mitigation: </Text><Text>{risk.mitigation}</Text>
                                </div>
                              </div>
                            </Panel>
                          ))}
                        </Collapse>
                      </div>
                    )}

                    <Divider style={{ margin: '32px 0' }} />
                    
                    <div style={{ textAlign: 'center' }}>
                      <Space size="large">
                        <Button 
                          type="primary" 
                          size="large"
                          style={{ borderRadius: '8px', minWidth: '120px' }}
                          className='ant-btn-primary-custom'
                          onClick={handleGenerateReport}
                        >
                          Generate PDF
                        </Button>
                        <Button 
                          size="large"
                          style={{ borderRadius: '8px', minWidth: '120px' }}
                          className='ant-btn-default-custom'
                        >
                          Export Excel
                        </Button>
                        <Button 
                          size="large"
                          style={{ borderRadius: '8px', minWidth: '120px' }}
                          className='ant-btn-default-custom'
                        >
                          Export JSON
                        </Button>
                      </Space>
                    </div>
                  </div>
                ) : (
                  <div style={{ textAlign: 'center', padding: '60px 20px' }}>
                    <Text type="secondary" style={{ fontSize: '16px' }}>
                      No sprint plan generated yet. Please generate a plan first.
                    </Text>
                  </div>
                )}
              </Card>
            </div>
          </TabPane>
        </Tabs>
      </Card>
    </div>
  );
};

export default SprintPlanning;