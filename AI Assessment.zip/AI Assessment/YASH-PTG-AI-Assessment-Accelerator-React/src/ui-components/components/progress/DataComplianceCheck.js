
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  Card,
  Tabs,
  Upload,
  Button,
  Alert,
  Typography,
  Row,
  Col,
  Statistic,
  Divider,
  List,
  Tag,
  Collapse,
  message,
  Progress,
  Table,
} from 'antd';
import Papa from 'papaparse';
import {
  InboxOutlined,
  ScanOutlined,
  FileTextOutlined,
  DownloadOutlined,
  ExclamationCircleOutlined,
  CheckCircleOutlined,
  WarningOutlined,
  SecurityScanOutlined,
} from '@ant-design/icons';
import {
  fetchSupportedFormats,
  runComplianceScan,
  generateComplianceReport,
  resetScanResults,
  getDataCompliance,
} from '../../../redux/features/dataComplianceCheck/dataComplieanceCheckAction';
import { clearError, setComplianceResults } from '../../../redux/features/dataComplianceCheck/dataComplieanceCheckSlice';
import Markdown from 'markdown-to-jsx';
import { getUseCaseProgressStatus } from '../../../redux/features/project/projectAction';
import { geteUseCase } from '../../../redux/features/dataReadiness/dataReadinessActions';
const { Title, Text, Paragraph } = Typography;
const { TabPane } = Tabs;
const { Dragger } = Upload;
const { Panel } = Collapse;

const DataComplianceCheck = () => {
  const dispatch = useDispatch();
  const [activeTab, setActiveTab] = useState('scan');
  const [fileList, setFileList] = useState([]);
  const [csvPreviews, setCsvPreviews] = useState({});

  const {
    supportedFormats,
    complianceResults,
    isScanning,
    isGeneratingReport,
    error,
    scanCompleted,
  } = useSelector((state) => state.compliance);
  const { selectedUseCaseDetail, selectedSessionDetail } = useSelector(state => state.local);
  const selectedUseCase = useSelector((state) => state.local.selectedUseCaseDetail) || {};
  

  useEffect(() => {
    if (error) {
      message.error(error);
      dispatch(clearError());
    }
  }, [error, dispatch]);

// useEffect(() => {
//   const checkAndPrefillData = async () => {
//     if (selectedUseCaseDetail?.id && selectedSessionDetail?.id) {
//       try {
//         const statusRes = await dispatch(getUseCaseProgressStatus(selectedUseCaseDetail.id)).unwrap();
//         const complianceStatus = statusRes?.data?.data_compliance_status;
//         console.log("complianceStatus:", complianceStatus);

//         if (complianceStatus?.toLowerCase() === 'completed') {
//           const res = await dispatch(getDataCompliance(selectedUseCaseDetail.id)).unwrap();
//           const complianceData = res?.data;
// const uploaded = complianceData.documents_uploaded.map((file, index) => ({
//                 uid: `${index}`,
//                 name: file.filename,
//                 status: 'done',
//                 url: file.path,
//                 type: file.mimetype
//               }));

//               setFileList(uploaded);

//               // Optionally store in Redux if needed later
//               dispatch(setComplianceResults(complianceData));
//               message.success("Loaded previous data readiness analysis.");
//           // // dispatch(resetScanResults());

//           // // Prefill file list from uploaded_docs
//           // const csvFiles = complianceData?.uploaded_docs?.filter(doc => doc.mimetype === 'text/csv') || [];

//           // const newFileList = csvFiles.map((file, index) => ({
//           //   uid: `${index}`,
//           //   name: file.filename,
//           //   status: 'done',
//           //   url: file.path,
//           //   originFileObj: null,
//           // }));

//           // setFileList(newFileList);

//           // // Fetch and parse each CSV file for preview
//           // const previews = await Promise.all(
//           //   csvFiles.map(async (file) => {
//           //     try {
//           //       const response = await fetch(`${process.env.REACT_APP_BASE_URL}/${file.path}`);
//           //       const text = await response.text();
//           //       const parsed = Papa.parse(text, {
//           //         header: true,
//           //         skipEmptyLines: true,
//           //       });

//           //       return {
//           //         name: file.filename,
//           //         data: parsed.data.slice(0, 10),
//           //         columns: parsed.meta.fields || [],
//           //       };
//           //     } catch (err) {
//           //       console.warn(`Failed to preview ${file.filename}`);
//           //       return null;
//           //     }
//           //   })
//           // );

//           // setCsvPreviews(previews.filter(Boolean));
//           // setActiveTab('report');
//         }
//       } catch (error) {
//         console.error('Prefill data failed:', error);
//       }
//     }
//   };
// if(selectedSessionDetail && selectedUseCaseDetail) {
//         dispatch(geteUseCase({ sessionId: selectedSessionDetail?.id, useCaseId: selectedUseCaseDetail?.id }));
//       }
//     checkAndPrefillData();
// }, [selectedUseCaseDetail, selectedSessionDetail, dispatch]);

useEffect(() => {
  const checkAndPrefillData = () => {
    if (selectedUseCaseDetail?.id && selectedSessionDetail?.id) {
      // Fire both actions in parallel (geteUseCase and getUseCaseProgressStatus)
      dispatch(geteUseCase({ sessionId: selectedSessionDetail.id, useCaseId: selectedUseCaseDetail.id }));

      // Run getUseCaseProgressStatus in the background
      dispatch(getUseCaseProgressStatus(selectedUseCaseDetail.id))
        .unwrap()
        .then((statusRes) => {
          const complianceStatus = statusRes?.data?.data_compliance_status;
          if (complianceStatus?.toLowerCase() === 'completed') {
            // Only fetch getDataCompliance if status is completed
            dispatch(getDataCompliance(selectedUseCaseDetail.id))
              .unwrap()
              .then((result) => {
                if (result.success && result.data) {
                  const data = result.data;

                  // Convert to AntD file format
                  const uploaded = data.uploaded_docs.map((file, index) => ({
                    uid: `${index}`,
                    name: file.filename,
                    status: 'done',
                    url: file.path,
                    type: file.mimetype
                  }));

                  uploaded.forEach((file) => {
                    if (file.name.toLowerCase().endsWith('.csv') && file.url) {
                      fetch(file.url)
                        .then(res => res.text())
                        .then(text => {
                          // Detect if it's invalid HTML (expired URL or app fallback)
                          if (text.startsWith('<!DOCTYPE html>') || text.includes('<html')) {
                            message.error(`Preview failed: ${file.name} is not a valid CSV file.`);
                            return;
                          }

                          Papa.parse(text, {
                            header: true,
                            skipEmptyLines: true,
                            complete: (results) => {
                              setCsvPreviews(prev => ({
                                ...prev,
                                [file.uid]: {
                                  data: results.data.slice(0, 10),
                                  totalRows: results.data.length,
                                  columns: results.meta.fields || [],
                                  errors: results.errors
                                }
                              }));
                            },
                            error: (error) => {
                              message.error(`CSV parsing error: ${error.message}`);
                            }
                          });
                        })
                        .catch(err => {
                          message.error(`Failed to fetch file ${file.name}: ${err.message}`);
                        });
                    }
                  });


                  setFileList(uploaded);

                  // Optionally store in Redux
                  dispatch(setComplianceResults(data));
                  setActiveTab('report');
                  message.success("Loaded previous data compliance analysis.");
                }
              })
              .catch((err) => {
                console.error("Error fetching compliance data:", err);
              });
          }
        })
        .catch((err) => {
          console.error("Error fetching progress status:", err);
        });
    }
  };
  checkAndPrefillData();
}, [selectedUseCaseDetail, selectedSessionDetail]);


  const allowedTypes = supportedFormats?.supported_formats?.map(ext =>
    ext.startsWith('.') ? ext.substring(1) : ext
  ) || ['csv', 'xlsx', 'xls', 'json', 'txt', 'pdf'];

  const handleFileUpload = (info) => {
    const newFiles = info.fileList;
    setFileList(newFiles);

    const previews = [];
    newFiles.forEach(file => {
      if (file.name.toLowerCase().endsWith('.csv')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          Papa.parse(e.target.result, {
            header: true,
            skipEmptyLines: true,
            complete: (results) => {
              previews.push({
                name: file.name,
                data: results.data.slice(0, 10),
                columns: results.meta.fields || [],
              });
              setCsvPreviews([...previews]);
            },
            error: (error) => {
              message.error(`Error parsing ${file.name}: ${error.message}`);
            },
          });
        };
        reader.readAsText(file.originFileObj);
      }
    });
  };

  const handleComplianceScan = async () => {

    if (fileList.length === 0) {
          message.error('Please upload files first');
          return;
        }

    if (!selectedUseCase?.id) {
      message.error('Please select a use case first');
      return;
    }
    const assessmentPayload = {
      files: fileList,
      useCaseId: selectedUseCase?.id,
    };

    try {
      const response = await dispatch(runComplianceScan(assessmentPayload));


      if (runComplianceScan.fulfilled.match(response)) {
              message.success('Compliance scan completed successfully!');
              setActiveTab('report'); // Switch to results tab
            } else if (runComplianceScan.rejected.match(response)) {
              const errorMessage = response.payload?.message || response.payload?.detail || 'Assessment failed';
              message.error(errorMessage);
            }
    } catch (error) {
      message.error('Compliance scan failed');
    }
  };


  const renderComplianceScan = () => (
    <Card >
      <Title level={4}><ScanOutlined /> Data Compliance Scan</Title>
      <Dragger
        multiple
        name="file"
        accept={allowedTypes.map(type => `.${type}`).join(',')}
        beforeUpload={() => false}
        onChange={handleFileUpload}
        fileList={fileList}
      >
        <p className="ant-upload-drag-icon"><InboxOutlined /></p>
        <p className="ant-upload-text">Click or drag files to this area to upload</p>
        <p className="ant-upload-hint">Supported formats: {allowedTypes.join(', ')}</p>
      </Dragger>

      {/* {csvPreviews.length > 0 && (
        <Collapse accordion style={{ marginTop: 16 }}>
          {csvPreviews.map((preview, idx) => (
            <Panel header={`Preview: ${preview.name}`} key={idx}>
              <Table
                dataSource={preview.data.map((row, i) => ({ key: i, ...row }))}
                columns={preview.columns.map(col => ({ title: col, dataIndex: col, key: col }))}
                pagination={false}
                scroll={{ x: true }}
              />
            </Panel>
          ))}
        </Collapse>
      )} */}

      {Object.keys(csvPreviews).length > 0 && (
        <Collapse accordion style={{ marginTop: 16 }}>
          {Object.entries(csvPreviews).map(([uid, preview], idx) => (
            <Panel header={`Preview: ${fileList[idx]?.name || preview.name || `File ${idx + 1}`}`} key={uid}>
              <Table
                dataSource={preview.data.map((row, i) => ({ key: i, ...row }))}
                columns={preview.columns.map(col => ({
                  title: col,
                  dataIndex: col,
                  key: col
                }))}
                pagination={false}
                scroll={{ x: true }}
              />
              {preview.errors?.length > 0 && (
                <Text type="danger" style={{ marginTop: 8, display: 'block' }}>
                  CSV Parsing Warnings: {preview.errors.map(e => e.message).join(', ')}
                </Text>
              )}
            </Panel>
          ))}
        </Collapse>
      )}

      {Object.keys(csvPreviews).length === 0 && (
      <Text type="secondary" style={{ marginTop: 12, display: 'block' }}>
        No CSV preview available.
      </Text>
      )}
      
      <Button
        type="primary"
        icon={<SecurityScanOutlined />}
        onClick={handleComplianceScan}
        loading={isScanning}
        disabled={!fileList.length || !selectedUseCase?.id || isScanning}
        style={{ marginTop: 16 }}
        size="large"
        block
        className=' ant-btn-primary-custom'
      >
        {isScanning ? 'Running Compliance Scan...' : 'Start Compliance Scan'}
      </Button>
    </Card>
  );
  const handleGenerateReport = async () => {
    if (!complianceResults?.compliance_id) {
      message.error('No compliance results to generate report');
      return;
    }

    try {
      const response = await dispatch(
        generateComplianceReport({
          use_case_id: selectedUseCase?.id,
          compliance_id: complianceResults.compliance_id,
        })
      );

      if (generateComplianceReport.fulfilled.match(response)) {
        const reportData = response.payload;
        console.log('Generate PDF Response:', reportData); // Debug logging
        if (reportData?.data?.presigned_url) {
          const link = document.createElement('a');
          link.href = reportData.data.presigned_url;
          link.download = `compliance_report_${selectedUseCase?.id}_${complianceResults.compliance_id}.pdf`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          message.success('PDF report downloaded successfully!');
        } else {
          console.error('Presigned URL missing in response:', reportData);
          message.error('No download link available for this report. Please try again later.');
        }
      } else {
        console.error('Report generation failed:', response.payload);
        message.error('Failed to generate report: ' + (response.payload?.message || 'Unknown error'));
      }
    } catch (error) {
      console.error('Error generating report:', error);
      message.error('Error generating report: ' + error.message);
    }
  };

  const extractRecommendations= (content) => {
    const lines = content.split('\n');
    const recommendations = [];
    let inRecommendations = false;

    for (const line of lines) {
      const trimmedLine = line.trim();
      if (trimmedLine.toLowerCase().includes('recommendation') && 
          (trimmedLine.includes('##') || trimmedLine.includes('###'))) {
        inRecommendations = true;
        continue;
      }
      
      if (inRecommendations && (trimmedLine.includes('##') || trimmedLine.includes('###')) && 
          !trimmedLine.toLowerCase().includes('recommendation')) {
        break;
      }
      
      if (inRecommendations && trimmedLine) {
        if (trimmedLine.match(/^\d+\./)) {
          const rec = trimmedLine.split('.', 2)[1]?.trim();
          if (rec) recommendations.push(rec.replace(/\*\*/g, ''));
        } else if (trimmedLine.startsWith('*') || trimmedLine.startsWith('-')) {
          const rec = trimmedLine.substring(1).trim();
          if (rec) recommendations.push(rec.replace(/\*\*/g, ''));
        }
      }
    }
    
    return recommendations;
  };

  const extractIssues = (content) => {
    const lines = content.split('\n');
    const issues = [];
    const issueKeywords = ['critical', 'high priority', 'medium priority', 'issue'];
    
    for (const line of lines) {
      const trimmedLine = line.trim();
      if (issueKeywords.some(keyword => trimmedLine.toLowerCase().includes(keyword))) {
        if (trimmedLine.startsWith('*') || trimmedLine.startsWith('-') || trimmedLine.startsWith('•')) {
          const issue = trimmedLine.substring(1).trim();
          if (issue.length > 20) {
            issues.push({
              text: issue,
              severity: determineSeverity(issue),
            });
          }
        }
      }
    }
    
    return issues.slice(0, 10);
  };

  const determineSeverity = (issue) => {
    const lowerIssue = issue.toLowerCase();
    if (lowerIssue.includes('critical')) return 'critical';
    if (lowerIssue.includes('high')) return 'high';
    if (lowerIssue.includes('medium')) return 'medium';
    return 'low';
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'red';
      case 'high': return 'orange';
      case 'medium': return 'yellow';
      default: return 'green';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'critical': return <ExclamationCircleOutlined style={{ color: 'red' }} />;
      case 'high': return <WarningOutlined style={{ color: 'orange' }} />;
      case 'medium': return <WarningOutlined style={{ color: 'gold' }} />;
      default: return <CheckCircleOutlined style={{ color: 'green' }} />;
    }
  };
  const renderComplianceReport = () => {
    if (!complianceResults) {
      return (
        <Card loading={isScanning}>
          <Alert
            message="Please run the compliance scan first to generate a report."
            type="info"
            showIcon
          />
        </Card>
      );
    }

    const recommendations = extractRecommendations(complianceResults.analysis_report);
    const issues = extractIssues(complianceResults.analysis_report);
//     const reportData = complianceResults || fetchedComplinceData;
// if (!reportData) {
//   return <Card><Alert message="Please run the compliance scan first to generate a report." type="info" showIcon /></Card>;
// }

// const recommendations = extractRecommendations(reportData.analysis_report);
// const issues = extractIssues(reportData.analysis_report);

    return (
      <div>
        <Card title="📊 Compliance Report" style={{ marginBottom: 16 }} loading={isScanning}>
          <Title level={4}>📈 Compliance Dashboard</Title>
          <Row gutter={16} style={{ marginBottom: 24 }}>
            <Col span={8}>
              <Statistic
                title="Overall Score"
                value={complianceResults.overall_score}
                precision={1}
                suffix="%"
                valueStyle={{ color: complianceResults.compliance_score > 80 ? '#3f8600' : '#cf1322' }}
              />
            </Col>
            <Col span={8}>
              <Statistic
                title="Risk Level"
                value={complianceResults.risk_level}
                valueStyle={{ 
                  color: complianceResults.risk_level === 'Low' ? '#3f8600' : 
                         complianceResults.risk_level === 'Medium' ? '#d48806' : '#cf1322'
                }}
              />
            </Col>
            <Col span={8}>
              <Statistic
                title="Analysis Type"
                value={complianceResults.analysis_type?.charAt(0).toUpperCase() + 
                       complianceResults.analysis_type?.slice(1) || 'N/A'}
              />
            </Col>
          </Row>

          <Progress
            percent={complianceResults.compliance_score}
            strokeColor={{
              '0%': '#ff4d4f',
              '50%': '#faad14',
              '100%': '#52c41a',
            }}
            style={{ marginBottom: 24 }}
          />
          
        </Card>
        <Card title="📋 Compliance Analysis Report" style={{ marginBottom: 16 }}>
        <Markdown style={{ whiteSpace: 'pre-line' }}>
                        {complianceResults.analysis_report || 'No detailed analysis available.'}
                      </Markdown>

        </Card>
        <Card title="💡 Key Recommendations" style={{ marginBottom: 16 }}>
          {recommendations.length > 0 ? (
            <List
              dataSource={recommendations}
              renderItem={(item, index) => (
                <List.Item>
                  <Text>
                    <strong>{index + 1}.</strong> {item}
                  </Text>
                </List.Item>
              )}
            />
          ) : (
            <Text type="secondary">No specific recommendations found in the analysis.</Text>
          )}
        </Card>

        <Card title="⚠️ Compliance Issues" style={{ marginBottom: 16 }}>
          {issues.length > 0 ? (
            <List
              dataSource={issues}
              renderItem={(item) => (
                <List.Item>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    {getSeverityIcon(item.severity)}
                    <Text>{item.text}</Text>
                    <Tag color={getSeverityColor(item.severity)}>
                      {item.severity.toUpperCase()}
                    </Tag>
                  </div>
                </List.Item>
              )}
            />
          ) : (
            <Alert
              message="No major compliance issues identified."
              type="success"
              showIcon
            />
          )}
        </Card>

        <Card title="🎯 Risk Assessment">
          <Collapse>
            <Panel header="Risk Details" key="1">
              <Row gutter={16}>
                <Col span={12}>
                  <Text strong>Overall Risk Level: </Text>
                  <Tag color={complianceResults.risk_level === 'Low' ? 'green' : 
                             complianceResults.risk_level === 'Medium' ? 'orange' : 'red'}>
                    {complianceResults.risk_level}
                  </Tag>
                </Col>
                <Col span={12}>
                  <Text strong>Compliance Score: </Text>
                  <Text>{complianceResults.compliance_score}%</Text>
                </Col>
                
              </Row>
              
              {complianceResults.risk_assessment!=="null" && <>
              <Divider />
              <Paragraph>
                <Text strong>Risk Assessment</Text>
              </Paragraph>
              <Paragraph>
              {JSON.parse(complianceResults.risk_assessment).map((risk_data)=>{
                return <>• <Markdown style={{ whiteSpace: 'pre-line' }}>
                                     {risk_data || 'No detailed analysis available.'}
                                   </Markdown>
                                   <br/></>
              })
                                   
                                   }
                                 
              </Paragraph>
              </>}
            </Panel>
          </Collapse>
        </Card>

        <Divider />
        
        <Button
          type="primary"
          size="large"
          icon={<DownloadOutlined />}
          onClick={handleGenerateReport}
          loading={isGeneratingReport}
          className='ant-btn-primary-custom'
        >
          {isGeneratingReport ? 'Generating PDF Report...' : 'Generate PDF Report'}
        </Button>
      </div>
    );
  };

  return (
    <div style={{ padding: 24 }}>
      <Tabs activeKey={activeTab} onChange={setActiveTab}>
        <TabPane tab="Compliance Scan" key="scan">{renderComplianceScan()}</TabPane>
        <TabPane tab="Compliance Report" key="report">{renderComplianceReport()}</TabPane>
      </Tabs>
    </div>
  );
};

export default DataComplianceCheck;
