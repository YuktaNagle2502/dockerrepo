import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Tabs, Card, Form, Input, Select, Button, Upload, Table, Checkbox, Radio, Row, Col, Statistic, Progress, Alert, Modal, Space, Typography, Divider, Tag, message, Descriptions } from 'antd';
import { UploadOutlined, PlayCircleOutlined, DownloadOutlined, DeleteOutlined, PlusOutlined, FileTextOutlined, CloseOutlined, InboxOutlined } from '@ant-design/icons';
import { runModelEvaluation, generateEvaluationReport, importTestCasesFromCSV, getEvaluationData } from '../../../redux/features/evaluation/evaluationAction';
import { setEvaluationConfig, setTestCases, addTestCase, removeTestCase, setSelectedModels, setApiKeys, clearError, setEvaluationResults } from '../../../redux/features/evaluation/evaluationSlice';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { geteUseCase } from '../../../redux/features/dataReadiness/dataReadinessActions';
import { getUseCaseProgressStatus } from '../../../redux/features/project/projectAction';
import Papa from 'papaparse';
const { TabPane } = Tabs;
const { TextArea } = Input;
const { Option } = Select;
const { Title, Text } = Typography;
const { Dragger } = Upload;

const ModelEvaluation = () => {
  const dispatch = useDispatch();
  const { evaluationConfig, testCases, evaluationResults, evaluationCompleted, loading, error, selectedModels, apiKeys } = useSelector(state => state.evaluation);
  const selectedUseCase = useSelector(state => state.local.selectedUseCaseDetail);
  const { selectedUseCaseDetail, selectedSessionDetail } = useSelector(state => state.local);
  const [activeTabMode, setActiveTabMode] = useState('manual');
  const [form] = Form.useForm();
  const [testCaseForm] = Form.useForm();
  const [activeTab, setActiveTab] = useState('1');
  const [uploadedFile, setUploadedFile] = useState(null);
  const [selectedTestIndices, setSelectedTestIndices] = useState([]);
  const [selectedEvaluationModels, setSelectedEvaluationModels] = useState({
    openai: [],
    gemini: [],
    bedrock: []
  });
  const [jsonOutput, setJsonOutput] = useState('');
  const [csvError,setCsvError]=useState("")
  const [isProcessing, setIsProcessing] = useState(false);
  const [csvTestFile, setCsvTestFile] = useState(null);

  const [addedTemplates, setAddedTemplates] = useState(new Set());

  useEffect(() => {
    if (error) {
      Modal.error({ title: 'Error', content: error });
      dispatch(clearError());
    }
  }, [error, dispatch]);

  useEffect(() => {
    const checkAndPrefillData = () => {
      if (selectedUseCaseDetail?.id && selectedSessionDetail?.id) {
        // Fire both actions in parallel (geteUseCase and getUseCaseProgressStatus)
        dispatch(geteUseCase({ sessionId: selectedSessionDetail.id, useCaseId: selectedUseCaseDetail.id }));

        dispatch(getUseCaseProgressStatus(selectedUseCaseDetail.id))
          .unwrap()
          .then((statusRes) => {
            const aiProfilingStatus = statusRes?.data?.model_evaluation_status;
            if (aiProfilingStatus?.toLowerCase() === 'completed') {
              // Only fetch getEvaluationData if status is completed
              dispatch(getEvaluationData(selectedUseCaseDetail.id))
                .unwrap()
                .then((result) => {
                  if (result.success && result.data) {
                    const data = result.data;
                    
                    // Set evaluation results for the results tab
                    dispatch(setEvaluationResults(data));
                    
                    // Prefill all data
                    prefillDataFromResponse(data);
                    
                    message.success("Loaded previous model evaluation data.");
                  }
                })
                .catch((err) => {
                  console.error("Error fetching model evaluation data:", err);
                });
            }
          })
          .catch((err) => {
            console.error("Error fetching progress status:", err);
          });
      }
    };
    checkAndPrefillData();
  }, [selectedUseCaseDetail, selectedSessionDetail]);

  // Enhanced prefill function to handle all data types
  const prefillDataFromResponse = (data) => {
    try {
      // 1. Prefill API Configuration (Tab 1)
      const config = createConfigFromResponse(data);
      dispatch(setEvaluationConfig(config));
      
      // Set form values for the configuration form
      const formValues = {
        // OpenAI configuration
        openai_api_key: data.api_keys?.openai ? '*********************' : '',
        openai_endpoint: config.openai?.endpoint || '',
        openai_models: config.openai?.models || [],
        
        // Gemini configuration
        gemini_api_key: data.api_keys?.gemini ? '*********************' : '',
        gemini_models: config.gemini?.models || [],
        
        // Bedrock configuration
        bedrock_models: config.bedrock?.models || [],
        
        // Evaluation configuration
        use_llm_judge: data.use_llm_judge || true,
        judge_model: data.overall_results?.best_performing_model || 'gpt-4',
        timeout: data.timeout || 60,
        max_retries: data.max_retries || 3,
        temperature: data.temperature || 0.7,
        max_tokens: data.max_tokens || 1000
      };
      
      // Set form fields
      form.setFieldsValue(formValues);
      
      // Update Redux state for API keys and selected models
      dispatch(setApiKeys({
        openai: data.api_keys?.openai || '',
        gemini: data.api_keys?.gemini || ''
      }));
      
      dispatch(setSelectedModels({
        openai: config.openai?.models || [],
        gemini: config.gemini?.models || [],
        bedrock: config.bedrock?.models || []
      }));

      // 2. Prefill Test Cases (Tab 2)
      if (data.test_cases && data.test_cases.length > 0) {
        const transformedTestCases = data.test_cases.map((tc, index) => ({
          id: index + 1,
          prompt: tc.test_prompt || tc.prompt,
          ground_truth: tc.expected_answer || tc.ground_truth,
          category: tc.test_category || tc.category || 'General',
          difficulty: tc.difficulty_level || tc.difficulty || 'Medium',
          criteria: tc.evaluation_criteria || ['Accuracy', 'Completeness']
        }));
        
        dispatch(setTestCases(transformedTestCases));
      }

      // 3. Prefill Model Selection for Evaluation (Tab 3)
      if (data.models_evaluated && data.models_evaluated.length > 0) {
        const modelsByProvider = {
          openai: data.models_evaluated.filter(model => 
            model === "gpt-35-turbo" || model === "gpt-4o-mini"
            // model.startsWith('gpt') || model.includes('openai')
          ),
          gemini: data.models_evaluated.filter(model => 
            model === "gemini-1.5-flash" 
            // model.startsWith('gemini')
          ),
          bedrock: data.models_evaluated.filter(model => 
            model.startsWith('anthropic') || 
            model.startsWith('amazon') || 
            model.startsWith('ai21')
          )
        };
        
        setSelectedEvaluationModels(modelsByProvider);
      }

      // 4. Auto-select all test cases if they exist
      if (data.test_cases && data.test_cases.length > 0) {
        const testIndices = data.test_cases.map((_, index) => index);
        setSelectedTestIndices(testIndices);
      }

      console.log('Successfully prefilled all data from previous evaluation');
      
    } catch (error) {
      console.error('Error prefilling data:', error);
      message.error('Error loading previous evaluation data');
    }
  };

  function createConfigFromResponse(response) {
    const modelsEvaluated = response.models_evaluated || [];

    const openaiModels = modelsEvaluated.filter(model => 
      model === "gpt-35-turbo" || model === "gpt-4o-mini"
      // model.startsWith("gpt") || model.includes("openai")
    );
    const geminiModels = modelsEvaluated.filter(model => 
      model === "gemini-1.5-flash"
      // model.startsWith("gemini")
    );
    const bedrockModels = modelsEvaluated.filter(model => 
      model.startsWith("anthropic") || 
      model.startsWith("amazon") || 
      model.startsWith("ai21")
    );

    const config = {
      openai: {
        api_key: response.api_keys?.openai || null,
        endpoint: null,
        models: openaiModels
      },
      gemini: {
        api_key: response.api_keys?.gemini || null,
        models: geminiModels
      },
      bedrock: {
        models: bedrockModels
      },
      evaluation: {
        use_llm_judge: response.use_llm_judge || false,
        judge_model: response.overall_results?.best_performing_model || null,
        timeout: response.timeout || null,
        max_retries: response.max_retries || null,
        temperature: response.temperature || null,
        max_tokens: response.max_tokens || null
      }
    };

    return config;
  }

  const renderMarkdown = (text) => {
    if (!text) return null;
    
    // Simple markdown renderer for basic formatting
    const lines = text.split('\n');
    return (
      <div>
        {lines.map((line, index) => {
          if (line.startsWith('# ')) {
            return <Title key={index} level={2} style={{ margin: '16px 0 8px 0' }}>{line.substring(2)}</Title>;
          } else if (line.startsWith('## ')) {
            return <Title key={index} level={3} style={{ margin: '12px 0 6px 0' }}>{line.substring(3)}</Title>;
          } else if (line.startsWith('### ')) {
            return <Title key={index} level={4} style={{ margin: '8px 0 4px 0' }}>{line.substring(4)}</Title>;
          } else if (line.startsWith('**') && line.endsWith('**')) {
            return <Text key={index} strong style={{ display: 'block', margin: '4px 0' }}>{line.slice(2, -2)}</Text>;
          } else if (line.startsWith('===') || line.startsWith('---')) {
            return <Divider key={index} style={{ margin: '8px 0' }} />;
          } else if (line.trim()) {
            return <Text key={index} style={{ display: 'block', margin: '2px 0' }}>{line}</Text>;
          }
          return <br key={index} />;
        })}
      </div>
    );
  };

  const getPerformanceColor = (score) => {
    if (score >= 80) return '#52c41a'; // Green
    if (score >= 60) return '#faad14'; // Orange
    if (score >= 40) return '#fa8c16'; // Light red
    return '#f5222d'; // Red
  };

  const predefinedTemplates = {
    "General Knowledge": [
      { prompt: "What is the capital of France?", ground_truth: "Paris" },
      { prompt: "Who wrote Romeo and Juliet?", ground_truth: "William Shakespeare" },
      { prompt: "What is the largest planet in our solar system?", ground_truth: "Jupiter" }
    ],
    "Mathematics": [
      { prompt: "What is 15% of 240?", ground_truth: "36" },
      { prompt: "If log₂(x) = 5, what is the value of x?", ground_truth: "x = 32" },
      { prompt: "What is the derivative of x³ - 4x² + 6x - 3?", ground_truth: "3x² - 8x + 6" }
    ],
    "Science": [
      { prompt: "What is the molecular formula for glucose?", ground_truth: "C₆H₁₂O₆" },
      { prompt: "In which layer of the atmosphere do commercial airplanes fly?", ground_truth: "Stratosphere" },
      { prompt: "What is photosynthesis?", ground_truth: "The process by which plants convert light energy into chemical energy" }
    ],
    "Reasoning": [
      { prompt: "If all roses are flowers and some flowers are red, can we conclude that some roses are red?", ground_truth: "No, we cannot conclude that some roses are red based on the given information" },
      { prompt: "A train travels 80 km/h to a destination and returns at 120 km/h. If total time is 5 hours, what's the distance?", ground_truth: "240 km" },
      { prompt: "What logical fallacy involves attacking the person rather than their argument?", ground_truth: "Ad hominem" }
    ]
  };

  const availableModels = {
    openai: [
      { label: 'GPT-3.5 Turbo', value: 'gpt-35-turbo' },
      { label: 'GPT-4o Mini', value: 'gpt-4o-mini' },
      // { label: 'GPT-4', value: 'gpt-4' },
      // { label: 'GPT-4 Turbo', value: 'gpt-4-turbo' },
      // { label: 'GPT-4o', value: 'gpt-4o' },
      // { label: 'GPT-3516K', value: 'gpt3516k' },
    ],
    gemini: [
      { label: 'Gemini 1.5 Flash', value: 'gemini-1.5-flash' },
      // { label: 'Gemini 1.5 Pro', value: 'gemini-1.5-pro' },
      // { label: 'Gemini Pro', value: 'gemini-pro' }
    ],
    bedrock: [
      { label: 'AI21 Jamba 1.5 Large', value: 'ai21.jamba-1-5-large-v1:0' },
      { label: 'Amazon Nova Canvas', value: 'amazon.nova-canvas-v1:0' },
      { label: 'Claude 3 Sonnet', value: 'anthropic.claude-3-sonnet-20240229-v1:0' }
    ]
  };

  const handleConfigSave = (values) => {
    
    const config = {
      openai: { api_key: values.openai_api_key, endpoint: values.openai_endpoint, models: values.openai_models || [] },
      gemini: { api_key: values.gemini_api_key, models: values.gemini_models || [] },
      bedrock: { models: values.bedrock_models || [] },
      evaluation: { use_llm_judge: values.use_llm_judge, judge_model: values.judge_model, timeout: values.timeout, max_retries: values.max_retries, temperature: values.temperature, max_tokens: values.max_tokens }
    };
    let openai=values.openai_models
    let gemini=values.gemini_models
    let bedrock=values.bedrock_models
    
    setSelectedEvaluationModels({
      openai:openai || [],
      gemini:gemini || [],
      bedrock:bedrock || [],
    })
    dispatch(setEvaluationConfig(config));
    dispatch(setApiKeys({ openai: values.openai_api_key, gemini: values.gemini_api_key }));
    dispatch(setSelectedModels({ openai: values.openai_models || [], gemini: values.gemini_models || [], bedrock: values.bedrock_models || [] }));
    Modal.success({ title: 'Success', content: 'Configuration saved successfully!' });
    setActiveTab("2")
  };

  const handleAddTestCase = (values) => {
    const newTestCase = { id: testCases.length + 1, ...values, criteria: values.criteria || ['Accuracy', 'Completeness'] };
    dispatch(addTestCase(newTestCase));
    testCaseForm.resetFields();
    Modal.success({ title: 'Success', content: 'Test case added successfully!' });
  };

  const handleDeleteTestCase = (id) => {
    dispatch(removeTestCase(id));
  };

  const handleTemplateImport = (templateName) => {
    if (addedTemplates.has(templateName)) {
      Modal.warning({ title: 'Warning', content: `${templateName} template has already been added!` });
      return;
    }
    
    const templateCases = predefinedTemplates[templateName].map((tc, idx) => ({  
      id: testCases.length + idx + 1, 
      ...tc, 
      category: templateName, 
      difficulty: 'Medium' 
    }));
    let idsImportedCase=templateCases.map(testCase => testCase.id-1)
    

    setSelectedTestIndices([...selectedTestIndices,...idsImportedCase]);
    dispatch(setTestCases([...testCases, ...templateCases]));
    setAddedTemplates(prev => new Set([...prev, templateName]));
    Modal.success({ title: 'Success', content: `Imported ${templateCases.length} test cases from ${templateName} template!` });
  };

  const handleFileUpload = (file) => {
    if (!file.name.toLowerCase().endsWith('.csv')) {
      message.error('Please upload a CSV file');
      return false;
    }

    setIsProcessing(true);
    setCsvError('');
    setJsonOutput('');

    const reader = new FileReader();
    reader.onload = (e) => {
      const csvText = e.target.result;
      parseCsvToJson(csvText);
    };
    reader.readAsText(file);
    return false;
    
  };

   const draggerProps = {
    name: 'file',
    multiple: false,
    accept: '.csv',
    beforeUpload: handleFileUpload,
    showUploadList: false,
    onChange: (info) => {
      const { status } = info.file;
      if (status === 'done') {
        message.success(`${info.file.name} file uploaded successfully.`);
      } else if (status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
  };

  const parseCsvToJson = (csvText) => {
    Papa.parse(csvText, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: false,
      delimitersToGuess: [',', '\t', '|', ';'],
      complete: (results) => {
        try {
          if (results.errors.length > 0) {
            setCsvError('CSV parsing errors: ' + results.errors.map(e => e.message).join(', '));
            setIsProcessing(false);
            return;
          }

          const testCases = results.data.map((row, index) => {
            // Clean whitespace from headers and values
            const cleanRow = {};
            Object.keys(row).forEach(key => {
              const cleanKey = key.trim();
              cleanRow[cleanKey] = row[key] ? row[key].toString().trim() : '';
            });

            // Map CSV columns to JSON structure
            const testCase = {
              id:index+1,
              prompt: cleanRow['prompt'] || cleanRow['Prompt'] || '',
              ground_truth: cleanRow['ground_truth'] || cleanRow['Ground_truth'] || cleanRow['ground truth'] || '',
              category: cleanRow['category'] || cleanRow['Category'] || '',
              difficulty: cleanRow['difficulty'] || cleanRow['Difficulty'] || '',
            };
            return testCase;
          }) // Filter out empty rows

          const jsonStructure = {
            test_cases: testCases
          };
          
          // console.log("jsonStructure:",jsonStructure.test_cases)
          dispatch(setTestCases(jsonStructure.test_cases))
          const idArray = jsonStructure.test_cases.map(testCase => testCase.id-1);
          setSelectedTestIndices([...selectedTestIndices,...idArray])
          setJsonOutput(JSON.stringify(jsonStructure, null, 2));
          setIsProcessing(false);
        } catch (err) {
          setCsvError('Error processing CSV: ' + err.message);
          setIsProcessing(false);
        }
      },
      error: (error) => {
        setCsvError('Failed to parse CSV: ' + error.message);
        setIsProcessing(false);
      }
    });
  };

  const handleModelSelect = (modelType, modelId) => {
    setSelectedEvaluationModels(prev => ({
      ...prev,
      [modelType]: prev[modelType].includes(modelId) 
        ? prev[modelType].filter(id => id !== modelId)
        : [...prev[modelType], modelId]
    }));
  };

  const handleRemoveModel = (modelType, modelId) => {
    setSelectedEvaluationModels(prev => ({
      ...prev,
      [modelType]: prev[modelType].filter(id => id !== modelId)
    }));
  };

  const getSelectedTestCasesCSV = () => {
    const selectedTests = selectedTestIndices.map(i => testCases[i]);
    
    // Helper function to properly escape CSV fields
    const escapeCSVField = (field) => {
      if (field == null) return '';
      const str = String(field);
      // If field contains quotes, newlines, or commas, wrap in quotes and escape internal quotes
      if (str.includes('"') || str.includes('\n') || str.includes(',')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };
    
    const header = 'prompt,ground_truth,category,difficulty\n';
    const rows = selectedTests.map(tc => 
      `${escapeCSVField(tc.prompt)},${escapeCSVField(tc.ground_truth)},${escapeCSVField(tc.category || 'General')},${escapeCSVField(tc.difficulty || 'Medium')}`
    ).join('\n');
    
    // Create proper CSV file with correct MIME type
    const csvContent = header + rows;
    const csvFile = new File([csvContent], `test_cases_${new Date().toISOString().split('T')[0]}.csv`, {
      type: 'text/csv'
    });
    
    return csvFile;
  };

  const handleRunEvaluation = () => {
    setActiveTab("4")
    const totalSelectedModels = selectedEvaluationModels.openai.length + 
                              selectedEvaluationModels.gemini.length + 
                              selectedEvaluationModels.bedrock.length;
    
    if (totalSelectedModels === 0) {
      Modal.error({ title: 'Error', content: 'Please select at least one model to evaluate!' });
      return;
    }
    
    if (selectedTestIndices.length === 0) {
      Modal.error({ title: 'Error', content: 'Please select at least one test case!' });
      return;
    }

    const modelsString = [
      ...selectedEvaluationModels.openai,
      ...selectedEvaluationModels.gemini,
      ...selectedEvaluationModels.bedrock
    ].join(',');

    console.log('Running evaluation with models:', modelsString);

    const apiKeysString = JSON.stringify({
      openai: apiKeys.openai,
      gemini: apiKeys.gemini
    });

    const evaluationParams = {
      usecase_id: selectedUseCase.id,
      models: modelsString,
      api_keys: apiKeysString,
      file: getSelectedTestCasesCSV(),
      use_llm_judge: evaluationConfig.evaluation?.use_llm_judge || true,
      max_tokens: evaluationConfig.evaluation?.max_tokens || 1000,
      temperature: evaluationConfig.evaluation?.temperature || 0.7
    };

    dispatch(runModelEvaluation(evaluationParams));
  };

  const handleGenerateReport = async (format) => {
    if (!evaluationResults?.model_evaluation_id) {
      Modal.error({ title: 'Error', content: 'No evaluation results available to generate report' });
      return;
    }

    try {
      const response = await dispatch(generateEvaluationReport({
        model_evaluation_id: evaluationResults.model_evaluation_id,
        use_case_id: selectedUseCase.id,
        format
      }));

      if (generateEvaluationReport.fulfilled.match(response)) {
        const reportData = response.payload;
        console.log('Generate Report Response:', reportData);
        if (format === 'pdf' && reportData?.data?.presigned_url) {
          const link = document.createElement('a');
          link.href = reportData.data.presigned_url;
          link.download = `model_evaluation_report_${selectedUseCase.id}_${evaluationResults.model_evaluation_id}.pdf`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          Modal.success({ title: 'Success', content: 'PDF report downloaded successfully!' });
        } else {
          console.error('Presigned URL missing or invalid format:', reportData);
          Modal.error({ title: 'Error', content: 'No download link available for this report. Please try again later.' });
        }
      } else {
        console.error('Report generation failed:', response.payload);
        Modal.error({ title: 'Error', content: `Failed to generate report: ${response.payload?.message || 'Unknown error'}` });
      }
    } catch (error) {
      console.error('Error generating report:', error);
      Modal.error({ title: 'Error', content: `Error generating report: ${error.message}` });
    }
  };
  
  const testCaseColumns = [
    { title: 'ID', dataIndex: 'id', key: 'id', width: 50 },
    { title: 'Category', dataIndex: 'category', key: 'category', width: 120 },
    { title: 'Prompt', dataIndex: 'prompt', key: 'prompt', ellipsis: true },
    { title: 'Expected Answer', dataIndex: 'ground_truth', key: 'ground_truth', ellipsis: true },
    { title: 'Difficulty', dataIndex: 'difficulty', key: 'difficulty', width: 100 },
    { title: 'Action', key: 'action', width: 80, render: (_, record) => <Button icon={<DeleteOutlined />} danger onClick={() => handleDeleteTestCase(record.id)} /> }
  ];

  const resultColumns = [
    { title: 'Model', dataIndex: 'model_name', key: 'model_name' },
    { title: 'Accuracy (%)', dataIndex: 'accuracy_percentage', key: 'accuracy_percentage', render: val => `${val?.toFixed(1)}%` },
    { title: 'Avg Score (%)', dataIndex: 'average_accuracy_score', key: 'average_accuracy_score', render: val => `${val?.toFixed(1)}%` },
    { title: 'Response Time (s)', dataIndex: 'average_response_time', key: 'average_response_time', render: val => `${val?.toFixed(2)}s` }
  ];

  if (!selectedUseCase) {
    return <Alert message="Please select a project first from the Project Management page." type="warning" showIcon />;
  }

  const totalSelectedModels = selectedEvaluationModels?.openai?.length + 
                             selectedEvaluationModels?.gemini?.length + 
                             selectedEvaluationModels?.bedrock?.length;

  return (
    <div style={{ padding: '' }}>
      <Card style={{ marginBottom: '16px' }}>
        <Title level={3} style={{ margin: '0 0 8px 0' }}>⚡ Model Evaluation</Title>
        <Text>Evaluate and compare different AI model performances</Text>
        <Alert message={`📊 Working on: ${selectedUseCase.title}`} type="info" style={{ margin: '12px 0 0 0' }} />
      </Card>

      <Tabs activeKey={activeTab} onChange={setActiveTab}>
        <TabPane tab="⚙️ Setup Evaluation" key="1">
          <Card title="🔧 API Configuration" style={{ marginBottom: '16px' }}>
            <Form form={form} layout="vertical" onFinish={handleConfigSave}>
              <Row gutter={16}>
                <Col span={8}>
                  <Title level={4} style={{ margin: '0 0 16px 0' }}>OpenAI/Azure OpenAI Configuration</Title>
                  <Form.Item name="openai_api_key" label="OpenAI API Key" style={{ marginBottom: '12px' }}>
                    <Input.Password placeholder="Your OpenAI API key" />
                  </Form.Item>
                  <Form.Item name="openai_endpoint" label="API Endpoint (Azure only)" style={{ marginBottom: '12px' }}>
                    <Input placeholder="https://your-resource.openai.azure.com/" />
                  </Form.Item>
                  <Form.Item name="openai_models" label="OpenAI Models" style={{ marginBottom: '12px' }}>
                    <Select mode="multiple" placeholder="Select models" options={availableModels.openai} />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Title level={4} style={{ margin: '0 0 16px 0' }}>Google Gemini Configuration</Title>
                  <Form.Item name="gemini_api_key" label="Gemini API Key" style={{ marginBottom: '12px' }}>
                    <Input.Password placeholder="Your Gemini API key" />
                  </Form.Item>
                  <Form.Item name="gemini_models" label="Gemini Models" style={{ marginBottom: '12px' }}>
                    <Select mode="multiple" placeholder="Select models" options={availableModels.gemini} />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Title level={4} style={{ margin: '0 0 16px 0' }}>Bedrock Configuration</Title>
                  <Form.Item name="bedrock_models" label="Bedrock Models" style={{ marginBottom: '12px' }}>
                    <Select mode="multiple" placeholder="Select models" options={availableModels.bedrock} />
                  </Form.Item>
                </Col>
              </Row>
              <Divider style={{ margin: '20px 0' }} />
              <Title level={4} style={{ margin: '0 0 16px 0' }}>📊 Evaluation Configuration</Title>
              <Row gutter={16}>
                <Col span={6}>
                  <Form.Item name="use_llm_judge" label="Use LLM as Judge" valuePropName="checked" initialValue={true} style={{ marginBottom: '12px' }}>
                    <Checkbox />
                  </Form.Item>
                  <Form.Item name="judge_model" label="Judge Model" initialValue="gpt-4" style={{ marginBottom: '12px' }}>
                    <Select options={[{label:'gpt-4',value:'gpt-4'},{label:'gpt-3.5-turbo',value:'gpt-3.5-turbo'}]} />
                  </Form.Item>
                </Col>
                <Col span={6}>
                  <Form.Item name="timeout" label="Timeout (seconds)" initialValue={60} style={{ marginBottom: '12px' }}>
                    <Input type="number" min={10} max={300} />
                  </Form.Item>
                  <Form.Item name="max_retries" label="Max Retries" initialValue={3} style={{ marginBottom: '12px' }}>
                    <Input type="number" min={1} max={5} />
                  </Form.Item>
                </Col>
                <Col span={6}>
                  <Form.Item name="temperature" label="Temperature" initialValue={0.7} style={{ marginBottom: '12px' }}>
                    <Input type="number" min={0} max={1} step={0.1} />
                  </Form.Item>
                  <Form.Item name="max_tokens" label="Max Tokens" initialValue={1000} style={{ marginBottom: '12px' }}>
                    <Input type="number" min={100} max={4000} />
                  </Form.Item>
                </Col>
              </Row>
              <Button type="primary" htmlType="submit" className=' ant-btn-primary-custom'>💾 Save Configuration</Button>
            </Form>
          </Card>
        </TabPane>

        <TabPane tab="📝 Create Test Cases" key="2">
          <Card title="📝 Create Evaluation Test Cases" style={{ marginBottom: '16px' }}>
            <Radio.Group 
              value={activeTabMode} 
              style={{ marginBottom: 16 }}
              onChange={(e) => setActiveTabMode(e.target.value)}
            >
              <Radio.Button value="manual">✏️ Manual Entry</Radio.Button>
              <Radio.Button value="csv">📤 Upload CSV</Radio.Button>
              <Radio.Button value="template">📋 Predefined Templates</Radio.Button>
            </Radio.Group>

            {activeTabMode === 'manual' && (
              <Card title="✏️ Manual Test Case Entry" style={{ marginBottom: 16 }}>
                <Form form={testCaseForm} layout="vertical" onFinish={handleAddTestCase}>
                  <Row gutter={16}>
                    <Col span={12}>
                      <Form.Item name="prompt" label="Test Prompt" rules={[{required:true}]} style={{ marginBottom: '12px' }}>
                        <TextArea rows={3} placeholder="Enter the prompt/question to test..." />
                      </Form.Item>
                      <Form.Item name="ground_truth" label="Expected Answer" rules={[{required:true}]} style={{ marginBottom: '12px' }}>
                        <TextArea rows={3} placeholder="Enter the expected correct answer..." />
                      </Form.Item>
                    </Col>
                    <Col span={12}>
                      <Form.Item name="category" label="Test Category" style={{ marginBottom: '12px' }}>
                        <Select placeholder="Select category" options={[{label:'General Knowledge',value:'General Knowledge'},{label:'Math',value:'Math'},{label:'Reasoning',value:'Reasoning'},{label:'Creative Writing',value:'Creative Writing'}]} />
                      </Form.Item>
                      <Form.Item name="difficulty" label="Difficulty Level" style={{ marginBottom: '12px' }}>
                        <Select placeholder="Select difficulty" options={[{label:'Easy',value:'Easy'},{label:'Medium',value:'Medium'},{label:'Hard',value:'Hard'}]} />
                      </Form.Item>
                      <Form.Item name="criteria" label="Evaluation Criteria" style={{ marginBottom: '12px' }}>
                        <Select mode="multiple" placeholder="Select criteria" options={[{label:'Accuracy',value:'Accuracy'},{label:'Completeness',value:'Completeness'},{label:'Clarity',value:'Clarity'}]} />
                      </Form.Item>
                    </Col>
                  </Row>
                  <Button type="primary" htmlType="submit" icon={<PlusOutlined />}>➕ Add Test Case</Button>
                </Form>
              </Card>
            )}

            {activeTabMode === 'csv' && (
              <Card title="📤 Upload CSV File" style={{ marginBottom: 16 }}>
                <div style={{ textAlign: 'center', padding: '20px' }}>
                  <Dragger {...draggerProps}>
          <p className="ant-upload-drag-icon">
            <InboxOutlined style={{ fontSize: '48px', color: '#1890ff' }} />
          </p>
          <p className="ant-upload-text text-lg font-medium">
            Click or drag CSV file to this area to upload
          </p>
          <p className="ant-upload-hint text-gray-500">
            Support for CSV files with columns: prompt, ground_truth, category, difficulty
          </p>
        </Dragger>
                </div>
              </Card>
            )}

            {activeTabMode === 'template' && (
              <Card title="📋 Use Predefined Templates" style={{ marginBottom: 16 }}>
                <Row gutter={[16, 16]}>
                  {Object.keys(predefinedTemplates).map(templateName => (
                    <Col span={6} key={templateName}>
                      <Card 
                        size="small" 
                        hoverable 
                        style={{ 
                          cursor: 'pointer',
                          opacity: addedTemplates.has(templateName) ? 0.5 : 1
                        }}
                        onClick={() => handleTemplateImport(templateName)}
                      >
                        <div style={{ textAlign: 'center' }}>
                          <Title level={5} style={{ margin: '0 0 8px 0' }}>{templateName}</Title>
                          <Text type="secondary">{predefinedTemplates[templateName].length} test cases</Text>
                          {addedTemplates.has(templateName) && (
                            <div style={{ marginTop: '8px' }}>
                              <Tag color="green">✓ Added</Tag>
                            </div>
                          )}
                        </div>
                      </Card>
                    </Col>
                  ))}
                </Row>
              </Card>
            )}

            {testCases.length > 0 && (
              <Card title={`📋 Current Test Cases (${testCases.length})`}>
                <Table columns={testCaseColumns} dataSource={testCases} rowKey="id" scroll={{x:true}} size="small" />
              </Card>
            )}
          </Card>
        </TabPane>

        <TabPane tab="🚀 Run Evaluation" key="3">
          <Row gutter={16}>
            <Col span={16}>
              <Card title="🎯 Select Models to Evaluate" style={{ marginBottom: '16px' }}>
                <Row gutter={16}>
                  <Col span={8}>
                    <Card size="small" title="🔵 OpenAI Models" style={{ height: '280px' }}>
                      <div style={{ marginBottom: '12px' }}>
                        {availableModels.openai.map(model => (
                          <Button 
                            key={model.value}
                            size="small"
                            type={selectedEvaluationModels.openai.includes(model.value) ? "primary" : "default"}
                            onClick={() => handleModelSelect('openai', model.value)}
                            style={{ margin: '2px', fontSize: '11px' }}
                          >
                            {model.label}
                          </Button>
                        ))}
                      </div>
                      <div>
                        {selectedEvaluationModels.openai.map(modelId => {
                          const model = availableModels.openai.find(m => m.value === modelId);
                          return (
                            <Tag key={modelId} closable onClose={() => handleRemoveModel('openai', modelId)} color="blue" style={{ margin: '2px' }}>
                              {model?.label}
                            </Tag>
                          );
                        })}
                      </div>
                    </Card>
                  </Col>
                  <Col span={8}>
                    <Card size="small" title="🟢 Gemini Models" style={{ height: '280px' }}>
                      <div style={{ marginBottom: '12px' }}>
                        {availableModels.gemini.map(model => (
                          <Button 
                            key={model.value}
                            size="small"
                            type={selectedEvaluationModels.gemini.includes(model.value) ? "primary" : "default"}
                            onClick={() => handleModelSelect('gemini', model.value)}
                            style={{ margin: '2px', fontSize: '11px' }}
                          >
                            {model.label}
                          </Button>
                        ))}
                      </div>
                      <div>
                        {selectedEvaluationModels.gemini.map(modelId => {
                          const model = availableModels.gemini.find(m => m.value === modelId);
                          return (
                            <Tag key={modelId} closable onClose={() => handleRemoveModel('gemini', modelId)} color="green" style={{ margin: '2px' }}>
                              {model?.label}
                            </Tag>
                          );
                        })}
                      </div>
                    </Card>
                  </Col>
                  <Col span={8}>
                    <Card size="small" title="🟠 Bedrock Models" style={{ height: '280px' }}>
                      <div style={{ marginBottom: '12px' }}>
                        {availableModels.bedrock.map(model => (
                          <Button 
                            key={model.value}
                            size="small"
                            type={selectedEvaluationModels.bedrock.includes(model.value) ? "primary" : "default"}
                            onClick={() => handleModelSelect('bedrock', model.value)}
                            style={{ margin: '2px', fontSize: '11px' }}
                          >
                            {model.label}
                          </Button>
                        ))}
                      </div>
                      <div>
                        {selectedEvaluationModels.bedrock.map(modelId => {
                          const model = availableModels.bedrock.find(m => m.value === modelId);
                          return (
                            <Tag key={modelId} closable onClose={() => handleRemoveModel('bedrock', modelId)} color="orange" style={{ margin: '2px' }}>
                              {model?.label}
                            </Tag>
                          );
                        })}
                      </div>
                    </Card>
                  </Col>
                </Row>
              </Card>

              <Card title="📝 Select Test Case" style={{ marginBottom: '16px' }}>
                <div style={{ maxHeight: '200px', overflowY: 'auto' }}>
                  <Checkbox.Group value={selectedTestIndices} onChange={setSelectedTestIndices} style={{width:'100%'}}>
                    <Row>
                      {testCases.map((tc, idx) => (
                        <Col span={24} key={idx} style={{marginBottom:4}}>
                          <Checkbox value={idx} style={{ fontSize: '12px' }}>
                            {`Test ${tc.id}: ${tc.category} - ${tc.prompt.substring(0, 60)}...`}
                          </Checkbox>
                        </Col>
                      ))}
                    </Row>
                  </Checkbox.Group>
                </div>
              </Card>

              <Button 
                type="primary" 
                size="large" 
                icon={<PlayCircleOutlined />} 
                loading={loading} 
                onClick={handleRunEvaluation} 
                style={{width:'100%'}}
                disabled={totalSelectedModels === 0 || selectedTestIndices.length === 0}
                className=' ant-btn-primary-custom'
              >
                🚀 Start Evaluation
              </Button>
            </Col>

            <Col span={8}>
              <Card title="📊 Evaluation Summary">
                <Row gutter={[8, 16]}>
                  <Col span={12}>
                    <Statistic title="Selected Models" value={totalSelectedModels} />
                  </Col>
                  <Col span={12}>
                    <Statistic title="Test Cases" value={testCases.length} />
                  </Col>
                  <Col span={12}>
                    <Statistic title="Selected Tests" value={selectedTestIndices.length} />
                  </Col>
                  <Col span={12}>
                    <Statistic title="Est. Time" value={`${((selectedTestIndices.length * totalSelectedModels * 3) / 60).toFixed(1)} min`} />
                  </Col>
                </Row>
                
                <Divider style={{ margin: '16px 0' }} />
                
                <Title level={5} style={{ margin: '0 0 8px 0' }}>Selected Models:</Title>
                <div style={{ marginBottom: '8px' }}>
                  <Text strong>OpenAI: </Text>
                  <Text>{selectedEvaluationModels.openai.length}</Text>
                </div>
                <div style={{ marginBottom: '8px' }}>
                  <Text strong>Gemini: </Text>
                  <Text>{selectedEvaluationModels.gemini.length}</Text>
                </div>
                <div>
                  <Text strong>Bedrock: </Text>
                  <Text>{selectedEvaluationModels.bedrock.length}</Text>
                </div>
              </Card>
            </Col>
          </Row>
        </TabPane>

<TabPane tab="📊 View Results" key="4">
  <Card title="📊 Evaluation Results" loading={loading}>
    {!evaluationCompleted || !evaluationResults?.overall_results ? (
      <Alert message="No evaluation results available. Please run the evaluation first." type="info" />
    ) : (
      <>
        {/* Overall Statistics */}
        <Card title="📈 Overall Performance" style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={4}>
              <Statistic 
                title="Models Tested" 
                value={evaluationResults.overall_results?.total_models || 0}
                prefix="🤖"
              />
            </Col>
            <Col span={4}>
              <Statistic 
                title="Test Cases" 
                value={evaluationResults.overall_results?.total_test_cases || 0}
                prefix="📝"
              />
            </Col>
            <Col span={4}>
              <Statistic 
                title="Overall Avg Score" 
                value={evaluationResults.overall_results?.overall_average_score?.toFixed(1) || 0}
                suffix="%"
                prefix="📊"
                valueStyle={{ color: getPerformanceColor(evaluationResults.overall_results?.overall_average_score || 0) }}
              />
            </Col>
            <Col span={4}>
              <Statistic 
                title="Overall Accuracy" 
                value={evaluationResults.overall_results?.overall_average_accuracy?.toFixed(1) || 0}
                suffix="%"
                prefix="🎯"
                valueStyle={{ color: getPerformanceColor(evaluationResults.overall_results?.overall_average_accuracy || 0) }}
              />
            </Col>
            <Col span={4}>
              <Statistic 
                title="Best Model" 
                value={evaluationResults.overall_results?.best_performing_model || 'N/A'}
                prefix="🏆"
                valueStyle={{ fontSize: '16px' }}
              />
            </Col>
            <Col span={4}>
              <Statistic 
                title="Worst Model" 
                value={evaluationResults.overall_results?.worst_performing_model || 'N/A'}
                prefix="📉"
                valueStyle={{ fontSize: '16px' }}
              />
            </Col>
          </Row>
        </Card>

        {/* Performance Visualizations */}
        <Row gutter={16} style={{ marginBottom: 16 }}>
          <Col span={12}>
            <Card title="📊 Model Performance Comparison" size="small">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={evaluationResults.overall_results?.model_rankings || []}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="model_name" 
                    angle={-45} 
                    textAnchor="end" 
                    height={80}
                    fontSize={10}
                  />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    dataKey="accuracy_percentage" 
                    fill="#1890ff" 
                    name="Accuracy (%)"
                    radius={[4, 4, 0, 0]}
                  />
                  <Bar 
                    dataKey="average_score" 
                    fill="#52c41a" 
                    name="Avg Score (%)"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </Col>
          <Col span={12}>
            <Card title="⏱️ Response Times" size="small">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={evaluationResults.overall_results?.model_rankings || []}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="model_name" 
                    angle={-45} 
                    textAnchor="end" 
                    height={80}
                    fontSize={10}
                  />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value?.toFixed(2)}s`, 'Response Time']} />
                  <Bar 
                    dataKey="average_response_time" 
                    fill="#fa8c16" 
                    name="Avg Response Time (s)"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </Col>
        </Row>

        {/* Model Rankings Table */}
        <Card title="🏆 Detailed Model Rankings" style={{ marginBottom: 16 }}>
          <Table 
            columns={[
              { 
                title: 'Rank', 
                dataIndex: 'rank', 
                key: 'rank', 
                width: 60,
                render: (rank) => (
                  <Tag color={rank === 1 ? 'gold' : rank === 2 ? 'silver' : rank === 3 ? '#cd7f32' : 'default'}>
                    #{rank}
                  </Tag>
                )
              },
              { 
                title: 'Model', 
                dataIndex: 'model_name', 
                key: 'model_name',
                render: (name) => <Text strong>{name}</Text>
              },
              { 
                title: 'Accuracy (%)', 
                dataIndex: 'accuracy_percentage', 
                key: 'accuracy_percentage', 
                render: (val) => (
                  <span style={{ color: getPerformanceColor(val) }}>
                    <strong>{val?.toFixed(1)}%</strong>
                  </span>
                ),
                sorter: (a, b) => a.accuracy_percentage - b.accuracy_percentage
              },
              { 
                title: 'Avg Score (%)', 
                dataIndex: 'average_score', 
                key: 'average_score', 
                render: (val) => (
                  <span style={{ color: getPerformanceColor(val) }}>
                    <strong>{val?.toFixed(1)}%</strong>
                  </span>
                ),
                sorter: (a, b) => a.average_score - b.average_score
              },
              { 
                title: 'Response Time (s)', 
                dataIndex: 'average_response_time', 
                key: 'average_response_time', 
                render: (val) => (
                  <Tag color={val < 1 ? 'green' : val < 2 ? 'orange' : 'red'}>
                    {val?.toFixed(2)}s
                  </Tag>
                ),
                sorter: (a, b) => a.average_response_time - b.average_response_time
              },
              {
                title: 'Performance',
                key: 'performance',
                render: (_, record) => (
                  <Progress 
                    percent={record.accuracy_percentage} 
                    size="small" 
                    strokeColor={getPerformanceColor(record.accuracy_percentage)}
                    showInfo={false}
                  />
                )
              }
            ]} 
            dataSource={evaluationResults.overall_results?.model_rankings || []} 
            rowKey="model_name" 
            size="small" 
            pagination={false}
          />
        </Card>

        {/* Individual Model Performance */}
        {evaluationResults.overall_results?.model_rankings?.map((model, index) => (
          <Card 
            key={model.model_name}
            title={`🤖 ${model.model_name} - Rank #${model.rank}`}
            size="small"
            style={{ 
              marginBottom: 12,
              border: model.rank === 1 ? '2px solid #fadb14' : '1px solid #d9d9d9'
            }}
          >
            <Row gutter={16}>
              <Col span={6}>
                <Statistic 
                  title="Accuracy" 
                  value={model.accuracy_percentage?.toFixed(1)} 
                  suffix="%" 
                  valueStyle={{ color: getPerformanceColor(model.accuracy_percentage) }}
                />
              </Col>
              <Col span={6}>
                <Statistic 
                  title="Average Score" 
                  value={model.average_score?.toFixed(1)} 
                  suffix="%" 
                  valueStyle={{ color: getPerformanceColor(model.average_score) }}
                />
              </Col>
              <Col span={6}>
                <Statistic 
                  title="Response Time" 
                  value={model.average_response_time?.toFixed(2)} 
                  suffix="s" 
                  valueStyle={{ 
                    color: model.average_response_time < 1 ? '#52c41a' : 
                           model.average_response_time < 2 ? '#faad14' : '#f5222d' 
                  }}
                />
              </Col>
              <Col span={6}>
                <div style={{ textAlign: 'center' }}>
                  <Progress 
                    type="circle" 
                    percent={model.accuracy_percentage} 
                    size={60}
                    strokeColor={getPerformanceColor(model.accuracy_percentage)}
                  />
                  <div style={{ marginTop: 4, fontSize: '12px' }}>Overall Performance</div>
                </div>
              </Col>
            </Row>
          </Card>
        ))}

        {/* Detailed Results Table */}
        {evaluationResults.detailed_results && evaluationResults.detailed_results.length > 0 && (
          <Card title="🔍 Detailed Test Results" style={{ marginBottom: 16 }}>
            <Table 
              columns={[
                { title: 'Model', dataIndex: 'model_name', key: 'model_name', width: 150 },
                { title: 'Prompt', dataIndex: 'prompt', key: 'prompt', ellipsis: true },
                { 
                  title: 'Response', 
                  dataIndex: 'response', 
                  key: 'response', 
                  ellipsis: true,
                  render: (text) => (
                    <Text style={{ color: text?.startsWith('ERROR:') ? '#f5222d' : 'inherit' }}>
                      {text}
                    </Text>
                  )
                },
                { title: 'Expected', dataIndex: 'ground_truth', key: 'ground_truth', ellipsis: true },
                { 
                  title: 'Correct', 
                  dataIndex: 'is_correct', 
                  key: 'is_correct',
                  render: (correct) => (
                    <Tag color={correct ? 'success' : 'error'}>
                      {correct ? '✅ Yes' : '❌ No'}
                    </Tag>
                  )
                },
                { 
                  title: 'Score', 
                  dataIndex: 'accuracy_score', 
                  key: 'accuracy_score',
                  render: (score) => (
                    <Tag color={getPerformanceColor(score * 100)}>
                      {(score * 100).toFixed(0)}%
                    </Tag>
                  )
                },
                { 
                  title: 'Time (s)', 
                  dataIndex: 'response_time', 
                  key: 'response_time',
                  render: (time) => `${time?.toFixed(2)}s`
                }
              ]} 
              dataSource={evaluationResults.detailed_results} 
              rowKey={(record, index) => `${record.model_name}-${index}`}
              size="small"
              scroll={{ x: true }}
              expandable={{
                expandedRowRender: (record) => (
                  <div style={{ padding: '8px 16px', backgroundColor: '#fafafa' }}>
                    <Text strong>Judge Explanation:</Text>
                    <div style={{ marginTop: 4, padding: '8px', backgroundColor: 'white', border: '1px solid #d9d9d9', borderRadius: '4px' }}>
                      {record.judge_explanation || 'No explanation available'}
                    </div>
                  </div>
                ),
                rowExpandable: (record) => !!record.judge_explanation,
              }}
            />
          </Card>
        )}

        {/* Evaluation Summary */}
        {evaluationResults.evaluation_summary && (
          <Card title="📋 AI-Generated Summary" style={{ marginBottom: 16 }}>
            <div style={{ 
              padding: '16px', 
              backgroundColor: '#fafafa', 
              border: '1px solid #d9d9d9', 
              borderRadius: '6px',
              fontFamily: 'monospace'
            }}>
              {renderMarkdown(evaluationResults.evaluation_summary)}
            </div>
          </Card>
        )}

        {/* Action Buttons */}
        <Card title="📤 Export Results">
          <Space size="large">
            <Button 
              type="primary" 
              icon={<FileTextOutlined />} 
              onClick={() => handleGenerateReport('pdf')} 
              className="ant-btn-primary-custom"
              size="large"
            >
              📄 Generate PDF Report
            </Button>
            <Button 
              icon={<DownloadOutlined />} 
              onClick={() => handleGenerateReport('excel')}
              className="ant-btn-default-custom"
              size="large"
            >
              📊 Export Excel
            </Button>
            <Button 
              icon={<DownloadOutlined />} 
              onClick={() => handleGenerateReport('json')} 
              className="ant-btn-default-custom"
              size="large"
            >
              📋 Export JSON
            </Button>
          </Space>
          
          <Divider style={{ margin: '16px 0' }} />
          
          <Row gutter={16}>
            <Col span={8}>
              <Text type="secondary">📅 Generated: {new Date(evaluationResults.generated_at).toLocaleString()}</Text>
            </Col>
            <Col span={8}>
              <Text type="secondary">📊 Performance Variance: {evaluationResults.overall_results?.performance_variance?.toFixed(2)}</Text>
            </Col>
          </Row>
        </Card>
      </>
    )}
  </Card>
</TabPane>
      </Tabs>
    </div>
  );
};

export default ModelEvaluation;