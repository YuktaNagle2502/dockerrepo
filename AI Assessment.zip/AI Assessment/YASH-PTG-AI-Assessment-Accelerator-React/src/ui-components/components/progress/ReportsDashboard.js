import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Card, Table, Button, Space, Modal, Tag, Spin, message } from 'antd';
import { DownloadOutlined, EyeOutlined, DeleteOutlined, SettingOutlined } from '@ant-design/icons';
import { fetchReports, downloadReport, deleteReport, generateSummaryReport } from '../../../redux/features/reports/reportsAction';
import moment from 'moment';

const ReportsDashboard = () => {
  const dispatch = useDispatch();
  const { loading= false,reportsLoading  } = useSelector(state => state.reports);
  const reportsData = useSelector(state => state.reports?.reports);
  const selectedUseCaseDetail = useSelector(state => state.local.selectedUseCaseDetail);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);
  const [downloadingReports, setDownloadingReports] = useState(new Set());

  useEffect(() => {
    if (selectedUseCaseDetail) {
      dispatch(fetchReports(selectedUseCaseDetail.id));
    }
  }, [dispatch, selectedUseCaseDetail]);

  // Transform the nested reports structure into a flat array
  const transformReportsData = (reportsData) => {
    if (!reportsData?.reports) return [];
    
    const flatReports = [];
    
    Object.entries(reportsData.reports).forEach(([assessmentStage, reports]) => {
      reports.forEach(report => {
        flatReports.push({
          id: report.report_id,
          report_title: report.report_filename,
          report_type: report.assessment_stage,
          module_name: report.assessment_stage,
          created_at: report.created_at,
          expires_at: report.expires_at,
          presigned_url: report.presigned_url,
          report_mimetype: report.report_mimetype,
          project_id: reportsData.use_case_id,
          assessment_stage: assessmentStage
        });
      });
    });
    
    // Sort by creation date (newest first)
    return flatReports.sort((a, b) => moment(b.created_at).diff(moment(a.created_at)));
  };

  const reports = transformReportsData(reportsData);

  // Enhanced download function with better error handling and loading states
  const handleDownload = async (report) => {
    if (!report.presigned_url) {
      message.error('Download URL not available for this report');
      return;
    }

    // Check if URL is expired
    const now = moment();
    const expiry = moment(report.expires_at);
    if (now.isAfter(expiry)) {
      message.error('This download link has expired. Please regenerate the report.');
      return;
    }

    setDownloadingReports(prev => new Set([...prev, report.id]));

    try {
      // Method 1: Direct download using anchor element (works for most cases)
      const link = document.createElement('a');
      link.href = report.presigned_url;
      link.download = report.report_title || `report_${report.id}.pdf`;
      link.target = '_blank'; // Open in new tab as fallback
      link.rel = 'noopener noreferrer';
      
      // Add the link to DOM temporarily
      document.body.appendChild(link);
      
      // Trigger the download
      link.click();
      
      // Clean up
      document.body.removeChild(link);
      
      message.success(`Downloading ${report.report_title}`);
      
    } catch (error) {
      console.error('Download failed with direct method, trying fetch method:', error);
      
      try {
        // Method 2: Fetch and download (for CORS issues)
        const response = await fetch(report.presigned_url, {
          method: 'GET',
          headers: {
            'Accept': 'application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.openxmlformats-officedocument.wordprocessingml.document,*/*'
          }
        });
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = report.report_title || `report_${report.id}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Clean up the blob URL
        window.URL.revokeObjectURL(url);
        
        message.success(`Downloaded ${report.report_title}`);
        
      } catch (fetchError) {
        console.error('Fetch download also failed:', fetchError);
        
        // Method 3: Fallback to opening in new window
        try {
          window.open(report.presigned_url, '_blank');
          message.info('Download started in new window');
        } catch (windowError) {
          console.error('All download methods failed:', windowError);
          message.error('Download failed. Please try again or contact support.');
          
          // Fallback to Redux action if available
          if (typeof downloadReport === 'function') {
            dispatch(downloadReport(report.id));
          }
        }
      }
    } finally {
      setDownloadingReports(prev => {
        const newSet = new Set(prev);
        newSet.delete(report.id);
        return newSet;
      });
    }
  };

  const handleDelete = (reportId) => {
    Modal.confirm({
      title: 'Are you sure?',
      content: 'This action cannot be undone.',
      onOk: () => dispatch(deleteReport(reportId)),
    });
  };

  const handleViewDetails = (report) => {
    setSelectedReport(report);
    setModalVisible(true);
  };

  const getStatusColor = (expiresAt) => {
    const now = moment();
    const expiry = moment(expiresAt);
    const daysUntilExpiry = expiry.diff(now, 'days');
    
    if (daysUntilExpiry > 7) return 'green';
    if (daysUntilExpiry > 3) return 'orange';
    return 'red';
  };

  const isExpired = (expiresAt) => {
    return moment().isAfter(moment(expiresAt));
  };

  const columns = [
    { 
      title: 'ID', 
      dataIndex: 'id', 
      key: 'id', 
      width: 80 
    },
    { 
      title: 'Filename', 
      dataIndex: 'report_title', 
      key: 'title', 
      ellipsis: true,
      render: (text) => (
        <span title={text}>
          {text?.replace(/\.(pdf|xlsx|docx)$/i, '')}
        </span>
      )
    },
    { 
      title: 'Assessment Stage', 
      dataIndex: 'report_type', 
      key: 'type', 
      render: (text) => (
        <Tag color="blue">
          {text?.replace(/_/g, ' ').toUpperCase()}
        </Tag>
      )
    },
    { 
      title: 'File Type', 
      dataIndex: 'report_mimetype', 
      key: 'mimetype', 
      render: (text) => (
        <Tag color="purple">
          {text === 'application/pdf' ? 'PDF' : 
           text === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ? 'XLSX' :
           text === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ? 'DOCX' :
           text?.split('/')[1]?.toUpperCase()}
        </Tag>
      )
    },
    { 
      title: 'Created', 
      dataIndex: 'created_at', 
      key: 'created', 
      render: (text) => moment(text).format('YYYY-MM-DD HH:mm'),
      sorter: (a, b) => moment(a.created_at).unix() - moment(b.created_at).unix()
    },
    {
      title: 'Actions',
      key: 'actions',
      fixed: 'right',
      width: 120,
      render: (_, record) => (
<Space>
  <Button 
    icon={<EyeOutlined />} 
    size="small" 
    onClick={() => handleViewDetails(record)}
    title="View Details"
    type="default"
    style={{ color: '#1890ff' }} // Blue color for View
  />

  <Button 
    icon={<DownloadOutlined />} 
    size="small" 
    onClick={() => handleDownload(record)}
    title="Download Report"
    loading={downloadingReports.has(record.id)}
    disabled={isExpired(record.expires_at)}
    type="default"
    style={{ color: '#52c41a' }} // Green for Download
  />

  {/* <Button 
    icon={<DeleteOutlined />} 
    size="small" 
    danger 
    onClick={() => handleDelete(record.id)}
    title="Delete Report"
  /> */}
</Space>
      ),
    },
  ];

  const ReportDetailsModal = () => (
    <Modal 
      title={`Report Details`}
      open={modalVisible} 
      onCancel={() => setModalVisible(false)} 
      width={800}
      footer={[
        <Button key="close" onClick={() => setModalVisible(false)} className=' ant-btn-default-custom'>
          Close
        </Button>,
        <Button 
          key="download" 
          type="primary"
          icon={<DownloadOutlined />} 
          onClick={() => handleDownload(selectedReport)}
          loading={selectedReport && downloadingReports.has(selectedReport.id)}
          disabled={selectedReport && isExpired(selectedReport.expires_at)}
          className=' ant-btn-primary-custom'
        >
          Download
        </Button>,
        // <Button 
        //   key="delete" 
        //   danger 
        //   icon={<DeleteOutlined />} 
        //   onClick={() => handleDelete(selectedReport?.id)}
        // >
        //   Delete
        // </Button>,
      ]}
    >
      {selectedReport && (
        <div>
          <div style={{ marginBottom: 16 }}>
            <h4>📄 {selectedReport.report_title}</h4>
            {isExpired(selectedReport.expires_at) && (
              <Tag color="red" style={{ marginTop: 8 }}>
                ⚠️ Download Link Expired
              </Tag>
            )}
          </div>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
            <div>
              <p><strong>Report ID:</strong> {selectedReport.id}</p>
              <p><strong>Assessment Stage:</strong> 
                <Tag color="blue" style={{ marginLeft: 8 }}>
                  {selectedReport.assessment_stage?.replace(/_/g, ' ').toUpperCase()}
                </Tag>
              </p>
              <p><strong>File Type:</strong> 
                <Tag color="purple" style={{ marginLeft: 8 }}>
                  {selectedReport.report_mimetype === 'application/pdf' ? 'PDF' : 
                   selectedReport.report_mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ? 'XLSX' :
                   selectedReport.report_mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ? 'DOCX' :
                   selectedReport.report_mimetype?.split('/')[1]?.toUpperCase()}
                </Tag>
              </p>
            </div>
            <div>
              <p><strong>Created:</strong> {moment(selectedReport.created_at).format('YYYY-MM-DD HH:mm:ss')}</p>
              <p><strong>Expires:</strong> 
                <Tag color={getStatusColor(selectedReport.expires_at)} style={{ marginLeft: 8 }}>
                  {moment(selectedReport.expires_at).format('YYYY-MM-DD HH:mm:ss')}
                </Tag>
              </p>
              <p><strong>Use Case ID:</strong> {selectedReport.project_id}</p>
            </div>
          </div>

          <div style={{ 
            padding: 12, 
            backgroundColor: '#f5f5f5', 
            borderRadius: 6,
            border: '1px solid #d9d9d9'
          }}>
            <p><strong>Download URL:</strong></p>
            <div style={{ 
              fontSize: '12px', 
              wordBreak: 'break-all',
              fontFamily: 'monospace',
              backgroundColor: 'white',
              padding: 8,
              borderRadius: 4,
              maxHeight: 100,
              overflowY: 'auto'
            }}>
              {selectedReport.presigned_url}
            </div>
          </div>

          <div style={{ marginTop: 16, fontSize: '12px', color: '#666' }}>
            <p>💡 <strong>Note:</strong> Presigned URLs expire on the date shown above. Download the report before expiration.</p>
            {isExpired(selectedReport.expires_at) && (
              <p style={{ color: '#ff4d4f' }}>⚠️ <strong>Warning:</strong> This download link has expired. Please regenerate the report.</p>
            )}
          </div>
        </div>
      )}
    </Modal>
  );

  return (
    <div style={{ padding: 24 }}>
      <Card 
      loading={ reportsLoading}
        title={`📊 Reports Dashboard${selectedUseCaseDetail ? ` - ${selectedUseCaseDetail.title}` : ''}`}
        extra={
          selectedUseCaseDetail && (''
            // <Button 
            //   icon={<SettingOutlined />} 
            //   onClick={() => dispatch(generateSummaryReport(selectedUseCaseDetail.id))}
            // >
            //   Generate Summary
            // </Button>
          )
        }
      >
        <Spin spinning={loading}>
          <div style={{ marginBottom: 16 }}>
            <Tag color="blue">Total Reports: {reports.length}</Tag>
            <Tag color="green">
              Assessment Stages: {[...new Set(reports.map(r => r.assessment_stage))].length}
            </Tag>
            {/* <Tag color="orange">
              Expired: {reports.filter(r => isExpired(r.expires_at)).length}
            </Tag> */}
          </div>
          
          <Table 
            dataSource={reports} 
            columns={columns} 
            rowKey="id"
            scroll={{ x: 1000 }}
            pagination={{
              showSizeChanger: true,
              showQuickJumper: true,
              showTotal: (total, range) => 
                `${range[0]}-${range[1]} of ${total} reports`
            }}
          />
        </Spin>
      </Card>
      <ReportDetailsModal />
    </div>
  );
};

export default ReportsDashboard;