import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Select, Card, Typography, Alert, Row, Col, Spin } from "antd";
import { loadPreWorkshopSessionsAndUsecases } from "../../../redux/features/useCaseGeneration/useCaseAction";
import { getUseCaseProgressStatus } from "../../../redux/features/project/projectAction";
import {
  setSelectedSessionDetails,
  setSelectedUsecaseDetail,
} from "../../../redux/features/local/localSlice";
import { clearAssessmentResults } from "../../../redux/features/dataReadiness/dataReadinessActions";
import { clearProfilingResults } from "../../../redux/features/aiProfiling/aiProfilingSlice";
import { resetScanResults } from "../../../redux/features/dataComplianceCheck/dataComplieanceCheckSlice";
import { clearEvaluationData, resetEvaluation, resetReportGeneration, resetTestCasesImport } from "../../../redux/features/evaluation/evaluationSlice";

const { Title, Text, Paragraph } = Typography;
const { Option } = Select;

// Sample data structure for Redux store
const sampleAssessmentState = {
  assessment: {
    completedStages: [2],
    currentStage: 2,
    workflowStages: {
      2: {
        name: "Session & Use Case Generation",
        description: "Identify and document AI use cases",
        icon: "🧠",
        route: "use-case-generation",
      },
      3: {
        name: "Data Readiness",
        description: "Assess data quality and availability",
        icon: "📊",
        route: "data-readiness",
      },
      4: {
        name: "Compliance Check",
        description: "Verify regulatory and ethical compliance",
        icon: "🔒",
        route: "compliance-check",
      },
      5: {
        name: "AI Profiling",
        description: "Profile AI models and capabilities",
        icon: "🤖",
        route: "ai-profiling",
      },
      6: {
        name: "Model Evaluation",
        description: "Evaluate model performance and metrics",
        icon: "⚡",
        route: "model-evaluation",
      },
      7: {
        name: "Sprint Planning",
        description: "Plan sprints and deliverables",
        icon: "🎯",
        route: "sprint-planning",
      },
      8: {
        name: "Final Report",
        description: "Generate comprehensive assessment report",
        icon: "📋",
        route: "final-report",
      },
    },
  },
};

const AssessmentProgress = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  // Redux selectors
  const completedStages = useSelector(
    (state) =>
      state.assessment?.completedStages ||
      sampleAssessmentState.assessment.completedStages
  );
  const currentStage = useSelector(
    (state) =>
      state.assessment?.currentStage ||
      sampleAssessmentState.assessment.currentStage
  );
  const workflowStages = useSelector(
    (state) =>
      state.assessment?.workflowStages ||
      sampleAssessmentState.assessment.workflowStages
  );
  const { sessionAndUsecases, sessionAndUsecasesLoading } = useSelector(
    (state) => state.usecase
  );
  const {
    useCaseProgressStatus,
    usecaseProgressError,
    usecaseProgressLoading,
  } = useSelector((state) => state.projects);
  const selectedProjectId = useSelector(
    (state) => state.local?.selectedProjectId
  );
  const { selectedSessionDetail, selectedUseCaseDetail } = useSelector(
    (state) => state.local
  );
  const selectedSessionId = selectedSessionDetail?.id || null;
  const selectedUseCaseId = selectedUseCaseDetail?.id || null;

  // Debug useEffect to log state changes
  useEffect(() => {
    console.log("Redux State Update:", {
      selectedUseCaseId,
      useCaseProgressStatus,
      usecaseProgressLoading,
      usecaseProgressError,
    });
  }, [
    selectedUseCaseId,
    useCaseProgressStatus,
    usecaseProgressLoading,
    usecaseProgressError,
  ]);

  useEffect(() => {
    if (selectedProjectId) {
      dispatch(loadPreWorkshopSessionsAndUsecases(selectedProjectId));
    }
  }, [dispatch, selectedProjectId]);

  // Fetch use case progress when selectedUseCaseId changes
  useEffect(() => {
    if (selectedUseCaseId) {
      console.log("Fetching progress for use case:", selectedUseCaseId);
      dispatch(getUseCaseProgressStatus(selectedUseCaseId));
    }
  }, [dispatch, selectedUseCaseId]);

  // Separate stages into two sections
  const useCaseGenerationStage = { 2: workflowStages[2] };
  const otherStages = Object.fromEntries(
    Object.entries(workflowStages).filter(([key]) => key !== "2")
  );

  const getStageStatus = (stageNum, isUseCaseDependent = false) => {
    const stageNumber = parseInt(stageNum);

    // Phase 1 (Stage 2): Status-less, use assessment-level completedStages and currentStage
    if (!isUseCaseDependent && stageNumber === 2) {
      if (completedStages.includes(stageNumber)) {
        return {
          status: "Completed",
          text: "Completed ✅",
          className: "status-completed",
          isClickable: true,
        };
      } else if (stageNumber === currentStage) {
        return {
          status: "In Progress",
          text: "In Progress 🔄",
          className: "status-in-progress",
          isClickable: true,
        };
      } else {
        return {
          status: "Pending",
          text: "Pending ⏳",
          className: "status-pending",
          isClickable: false,
        };
      }
    }

    // Phase 2 (Stages 3-8): Use useCaseProgressStatus if available
    if (isUseCaseDependent && selectedUseCaseId) {
      // If loading, show loading state
      if (usecaseProgressLoading) {
        return {
          status: "Loading",
          text: "Loading...",
          className: "status-pending",
          isClickable: false,
        };
      }

      // If we have progress status data
      if (
        useCaseProgressStatus &&
        useCaseProgressStatus.use_case_id === selectedUseCaseId
      ) {
        const statusMap = {
          3: useCaseProgressStatus.data_readiness_status,
          4: useCaseProgressStatus.data_compliance_status,
          5: useCaseProgressStatus.ai_profiling_status,
          6: useCaseProgressStatus.model_evaluation_status,
          7: useCaseProgressStatus.sprint_planning_status,
          8: useCaseProgressStatus.final_report_status || "Pending",
        };

        const status = statusMap[stageNumber] || "Pending";
        console.log(`Stage ${stageNumber} status:`, status);

        if (status === "Completed") {
          return {
            status: "Completed",
            text: "Completed ✅",
            className: "status-completed",
            isClickable: true,
          };
        } else if (
          status === "In Progress" ||
          status === "InProgress" ||
          status === "In progress"
        ) {
          return {
            status: "In Progress",
            text: "In Progress 🔄",
            className: "status-in-progress",
            isClickable: true,
          };
        } else {
          return {
            status: "Pending",
            text: "Pending ⏳",
            className: "status-pending",
            isClickable: false,
          };
        }
      }
    }

    // Fallback for use case-dependent stages
    return {
      status: "Pending",
      text: "Pending ⏳",
      className: "status-pending",
      isClickable: selectedUseCaseId !== null,
    };
  };

  const handleCardClick = (stageNum, stageInfo, isClickable) => {
    if (!isClickable) return;
    dispatch(clearAssessmentResults())
    dispatch(clearProfilingResults())
    dispatch(resetScanResults())
    dispatch(resetEvaluation())
    dispatch(resetTestCasesImport())
    dispatch(resetReportGeneration())
    const route = stageInfo.route;
    navigate(`/project-management/${selectedProjectId}/${route}`);
  };

  const handleSessionChange = (selectedId) => {
    if (selectedId) {
      const selectedSession = sessionAndUsecases.find(
        (session) => session.id === selectedId
      );

      if (selectedSession) {
        const sessionData = {
          id: selectedSession.id,
          session_name: selectedSession.session_name,
          description: selectedSession.description,
        };
        dispatch(setSelectedSessionDetails(sessionData));
      }
    } else {
      dispatch(setSelectedSessionDetails(null));
    }

    // Reset use case selection when session changes
    dispatch(
      setSelectedUsecaseDetail({ id: null, title: "", description: "" })
    );
  };

  const handleUseCaseChange = (selectedId) => {
    console.log("handleUseCaseChange triggered:", { selectedId });
    if (selectedId) {
      const selectedUseCase = filteredUseCases.find(
        (useCase) => useCase.id === selectedId
      );
      if (selectedUseCase) {
        const useCaseData = {
          id: selectedUseCase.id,
          title: selectedUseCase.title,
          description: selectedUseCase.description,
        };
        dispatch(setSelectedUsecaseDetail(useCaseData));
        // The useEffect will handle fetching progress status
      }
    } else {
      dispatch(setSelectedUsecaseDetail(null));
    }
  };

  const filteredUseCases = selectedSessionId
    ? sessionAndUsecases.find((session) => session.id === selectedSessionId)
        ?.generated_use_cases || []
    : [];

  const renderStageCard = (stageNum, stageInfo, isUseCaseDependent = false) => {
    const stageNumber = parseInt(stageNum);
    if(stageNumber==2 ){
     return (
      <Card
        key={stageNumber}
        className={`stage-card clickable`}
        onClick={() =>
          handleCardClick(
            stageNumber,
            stageInfo,
            true
          )
        }
        
        hoverable
      >
        <div className="stage-card-content">
          <div className="stage-icon">{stageInfo.icon}</div>
          <div className="stage-content">
            <Title level={4} className="stage-title">
              {stageInfo.name}
            </Title>
            <Text className="stage-description">{stageInfo.description}</Text>
          </div>
        </div>
      </Card>
    );
    }
    
    const stageStatus = getStageStatus(stageNumber, isUseCaseDependent);
    console.log("stageStatus:",stageStatus)
    // Disable card if it's use case dependent and no use case is selected
    const isDisabled = isUseCaseDependent && !selectedUseCaseId;
    if(stageNumber==8){
     return (
      <Card
        key={stageNumber}
        className={`stage-card ${
        !isDisabled ? "clickable" : "disabled"
        }`}
        onClick={() =>
          handleCardClick(
            stageNumber,
            stageInfo,
            true
          )
        }
        hoverable
      >
        <div className="stage-card-content">
          <div className="stage-icon">{stageInfo.icon}</div>
          <div className="stage-content">
            <Title level={4} className="stage-title">
              {stageInfo.name}
            </Title>
            <Text className="stage-description">{stageInfo.description}</Text>
          </div>
        </div>
      </Card>
    );
    }
    return (
      <Card
        key={stageNumber}
        className={`stage-card ${
          stageStatus.isClickable  ? "clickable" : "disabled"
        }`}
        onClick={() =>
          handleCardClick(
            stageNumber,
            stageInfo,
            stageStatus.isClickable && !isDisabled
          )
        }
        hoverable={stageStatus.isClickable}
      >
        <div className="stage-card-content">
          <div className="stage-icon">{stageInfo.icon}</div>
          <div className="stage-content">
            <Title level={4} className="stage-title">
              {stageInfo.name}
            </Title>
            <Text className="stage-description">{stageInfo.description}</Text>
          </div>
          <div className={`stage-status ${stageStatus.className}`}>
            {usecaseProgressLoading &&
            isUseCaseDependent &&
            selectedUseCaseId ? (
              <Spin size="small" />
            ) : (
              stageStatus.text
            )}
          </div>
        </div>
      </Card>
    );
  };

  return (
    <div className="assessment-progress">
      <Title level={2} className="progress-title">
        🎯 Assessment Progress
      </Title>

      {/* Section 1: Use Case Generation */}
      <div className="section">
        <Title level={3} className="section-title">
          Phase 1: Use Case Generation
        </Title>
        <div className="stages-container">
          {Object.entries(useCaseGenerationStage).map(([stageNum, stageInfo]) =>
            renderStageCard(stageNum, stageInfo, false)
          )}
        </div>
      </div>

      {/* Section 2: Use Case Dependent Stages */}
      <div className="section">
        <Title level={3} className="section-title">
          Phase 2: Use Case Assessment
        </Title>

        {/* Session and Use Case Selector */}
        <Card className="use-case-selector">
          <Row gutter={[24, 16]}>
            <Col xs={24} md={12}>
              <div className="selector-column">
                <Text strong className="selector-label">
                  Select Session:
                </Text>
                <Select
                  loading={sessionAndUsecasesLoading}
                  value={selectedSessionId}
                  onChange={handleSessionChange}
                  placeholder="-- Select a Session --"
                  className="dropdown"
                  style={{ width: "100%" }}
                  
                >
                  {sessionAndUsecases.map((session) => (
                    <Option key={session.id} value={session.id}>
                      {session.session_name}
                    </Option>
                  ))}
                </Select>
              </div>
            </Col>

            <Col xs={24} md={12}>
              <div className="selector-column">
                <Text strong className="selector-label">
                  Select Use Case for Assessment:
                </Text>
                <Select
                  loading={sessionAndUsecasesLoading || usecaseProgressLoading}
                  value={selectedUseCaseId}
                  onChange={handleUseCaseChange}
                  placeholder="-- Select a Use Case --"
                  className="dropdown"
                  style={{ width: "100%" }}
                  disabled={!selectedSessionId}
                  
                >
                  {filteredUseCases.map((useCase) => (
                    <Option key={useCase.id} value={useCase.id}>
                      {useCase.title}
                    </Option>
                  ))}
                </Select>
              </div>
            </Col>
          </Row>

          {/* Selected Session Info */}
          {selectedSessionDetail?.id && (
            <div className="selected-info">
              <div className="info-item">
                <Text strong>Session:</Text>{" "}
                <Text>{selectedSessionDetail.session_name}</Text>
                <Paragraph className="info-description">
                  {selectedSessionDetail.description}
                </Paragraph>
              </div>
            </div>
          )}

          {/* Selected Use Case Info */}
          {selectedUseCaseDetail?.id && (
            <div className="selected-info">
              <div className="info-item">
                <Text strong>Use Case:</Text>{" "}
                <Text>{selectedUseCaseDetail.title}</Text>
                <Paragraph className="info-description">
                  {selectedUseCaseDetail.description}
                </Paragraph>
              </div>
            </div>
          )}
        </Card>

        {/* Warning messages */}
        {sessionAndUsecasesLoading ? (
          <Alert
            message="Loading sessions..."
            type="info"
            className="warning-message"
          />
        ) : (
          <>
            {usecaseProgressError && (
              <Alert
                message={`Error fetching use case progress: ${usecaseProgressError}`}
                type="error"
                showIcon
                className="warning-message"
              />
            )}
            {!selectedSessionId && sessionAndUsecases.length > 0 && (
              <Alert
                message="⚠️ Please select a session first to view available use cases."
                type="warning"
                showIcon
                className="warning-message"
              />
            )}
            {!selectedUseCaseDetail &&
              selectedSessionId &&
              filteredUseCases.length === 0 && (
                <Alert
                  message="⚠️ No use cases found for the selected session. Please complete the Session & Use Case Generation phase first."
                  type="warning"
                  showIcon
                  className="warning-message"
                />
              )}
            {selectedSessionId &&
              filteredUseCases.length > 0 &&
              !selectedUseCaseId && (
                <Alert
                  message="⚠️ Please select a use case to view and access the assessment stages below."
                  type="warning"
                  showIcon
                  className="warning-message"
                />
              )}
            {sessionAndUsecases.length === 0 && (
              <Alert
                message="❌ No sessions found. Please complete the Session & Use Case Generation phase first."
                type="error"
                showIcon
                className="warning-message"
              />
            )}
          </>
        )}

        {/* Use Case Dependent Stages */}
        <div className="stages-container">
          {Object.entries(otherStages).map(([stageNum, stageInfo]) =>
            renderStageCard(stageNum, stageInfo, true)
          )}
        </div>
      </div>
    </div>
  );
};

export default AssessmentProgress;
