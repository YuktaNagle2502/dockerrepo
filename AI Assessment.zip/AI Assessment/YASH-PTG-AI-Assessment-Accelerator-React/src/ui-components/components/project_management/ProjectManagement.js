import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    Card,
    Button,
    Modal,
    Form,
    Input,
    Row,
    Col,
    Typography,
    Space,
    Statistic,
    Select,
    Empty,
    message,
    Popconfirm,
    Tag
} from 'antd';
import {
    PlusOutlined,
    ReloadOutlined,
    ProjectOutlined,
    DeleteOutlined,
    EditOutlined,
    SearchOutlined,
    BarChartOutlined,
    PieChartOutlined,
    CheckOutlined,
    CheckCircleOutlined
} from '@ant-design/icons';
import { clearPersistData, setProjectData, setSelectedProjectId, setSelectedSessionDetails, setSelectedUsecaseDetail } from '../../../redux/features/local/localSlice';
import { useNavigate } from 'react-router-dom';
import { generateProjectPath} from '../../../util/constants';
import { createProject, deleteProject, loadProjects, updateProject } from '../../../redux/features/project/projectAction';
import { clearWorkflowState } from '../../../redux/features/project/projectSlice';

const { Title, Text, Paragraph } = Typography;
const { Search } = Input;
const { TextArea } = Input;

const ProjectManagement = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const {
        projects,
        loading,
        error,
        createLoading,
        updateLoading,
        deleteLoading
    } = useSelector(state => state.projects);

    const [createModalVisible, setCreateModalVisible] = useState(false);
    const [editModalVisible, setEditModalVisible] = useState(false);
    const [selectedProject, setSelectedProject] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [sortBy, setSortBy] = useState('recent');
    const [createForm] = Form.useForm();
    const [editForm] = Form.useForm();

    useEffect(() => {
        dispatch(loadProjects());
        dispatch(clearPersistData());
        setSelectedProjectId(null)
    }, [dispatch]);

    const handleCreateProject = async (values) => {
        try {
            const response = await dispatch(createProject(values));
            if (response.payload.success) {
                message.success(response.payload.message);
                setCreateModalVisible(false);
                createForm.resetFields();
            } else {
                message.error(response.payload.error);
            }
        } catch (error) {
            message.error('Failed to create project');
        }
    };

    const handleUpdateProject = async (values) => {
        try {
            const response = await dispatch(updateProject({ id: selectedProject.id, ...values }));
            if (response.payload.success) {
                message.success(response.payload.message);
                setEditModalVisible(false);
                setSelectedProject(null);
            } else {
                message.error(response.payload.error);
            }
        } catch (error) {
            // message.error('Failed to update project');
        }
    };

    const handleDeleteProject = async (projectId) => {
        try {
            const response = await dispatch(deleteProject(projectId));
            if (response.payload.success) {
                message.success(response.payload.message);
            } else {
                message.error(response.payload.error);
            }
        } catch (error) {
            message.error('Failed to delete project');
        }
    };

    const handleOpenProject = async (project) => {
        dispatch(setProjectData({
            id: project.id,
            projectName: project.name,
            projectDescription: project.description,
        }))
        dispatch(setSelectedProjectId(project.id));
        await dispatch(setSelectedSessionDetails({id: null, session_name: '', description: ''}));
        await dispatch(setSelectedUsecaseDetail({ id: null, title: '', description: ''}));
        navigate(generateProjectPath(project.name).path);
        setSelectedProject(project);
        dispatch(clearWorkflowState());
    };

    const handleRefresh = () => {
        dispatch(loadProjects());
    };

    const handleEditProject = (project) => {
        setSelectedProject(project);
        editForm.setFieldsValue({
            name: project.name,
            description: project.description
        });
        setEditModalVisible(true);
    };

    // Filter and sort projects
    const filteredProjects = projects?.filter(project =>
        project.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.description?.toLowerCase().includes(searchTerm.toLowerCase())
    ) || [];

    const sortedProjects = [...filteredProjects].sort((a, b) => {
        switch (sortBy) {
            case 'recent':
                return new Date(b.updated_at || b.created_at) - new Date(a.updated_at || a.created_at);
            case 'name':
                return a.name?.localeCompare(b.name);
            case 'status':
                return (b.is_active ? 1 : 0) - (a.is_active ? 1 : 0);
            default:
                return 0;
        }
    });

    // Calculate metrics
    const totalProjects = projects?.length || 0;
    const activeProjects = projects?.filter(p => p.is_active)?.length || 0;
    const completedProjects = 0; // To be implemented based on your assessment status logic
    const completionRate = totalProjects > 0 ? (completedProjects / totalProjects * 100) : 0;

    return (
        <div style={{ padding: '18x 24px 18px' }}>
            {/* Header */}
            <div style={{ marginBottom: '24px' }}>
                <Title level={4}>
                    <ProjectOutlined /> Project Management
                </Title>
                <Text type="secondary">Create and manage your GenAI assessment projects</Text>
            </div>

            {/* Action Buttons */}
            <Row gutter={16} style={{ marginBottom: '24px' }}>
                <Col>
                    <Button
                        type="primary"
                        icon={<PlusOutlined />}
                        onClick={() => setCreateModalVisible(true)}
                        size="small"
                        className='ant-btn-primary-custom'
                    >
                        New Project
                    </Button>
                </Col>
                <Col>
                    <Button
                        icon={<ReloadOutlined />}
                        onClick={handleRefresh}
                        loading={loading}
                        size="small"
                        className='ant-btn-default-custom'
                    >
                        Refresh
                    </Button>
                </Col>
            </Row>

            {/* Overview Metrics */}
            {projects?.length > 0 && (
                <div style={{ marginBottom: '32px' }}>
                    <Title level={4} style={{ textAlign: 'left' }}>
                        <BarChartOutlined /> Overview
                    </Title>
                    <Row gutter={16}>
                        <Col span={6}>
                            <Card loading={loading}>
                                <Statistic
                                    title={
                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '16px', fontWeight: 600 }}>
                                            <span>Total Projects</span>
                                            <ProjectOutlined style={{ fontSize: '24px', color: '#3182ce' }} />
                                        </div>
                                    }
                                    value={totalProjects}
                                    valueStyle={{ color: '#3182ce' }}
                                />
                            </Card>
                        </Col>
                        <Col span={6}>
                            <Card loading={loading}>
                                <Statistic
                                    title={
                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '16px', fontWeight: 600 }}>
                                            <span>Active Projects</span>
                                            <CheckCircleOutlined style={{ fontSize: '24px', color: '#38a169' }} />
                                        </div>
                                    }
                                    value={activeProjects}
                                    valueStyle={{ color: '#38a169' }}
                                />
                            </Card>
                        </Col>
                        <Col span={6}>
                            <Card loading={loading}>
                                <Statistic
                                    title={
                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '16px', fontWeight: 600 }}>
                                            <span>Completed</span>
                                            <CheckOutlined style={{ fontSize: '24px', color: '#d69e2e' }} />
                                        </div>
                                    }
                                    value={completedProjects}
                                    valueStyle={{ color: '#d69e2e' }}
                                />
                            </Card>
                        </Col>
                        <Col span={6}>
                            <Card loading={loading}>
                                <Statistic
                                    title={
                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '16px', fontWeight: 600 }}>
                                            <span>Completion Rate</span>
                                            <PieChartOutlined style={{ fontSize: '24px', color: '#9f7aea' }} />
                                        </div>
                                    }
                                    value={completionRate}
                                    precision={1}
                                    suffix="%"
                                    valueStyle={{ color: '#9f7aea' }}
                                />
                            </Card>
                        </Col>

                    </Row>
                </div>
            )}

            {/* Search and Filter */}
            {projects?.length > 0 && (
                <div style={{ marginBottom: '12px' }}>
                    <Row align="middle" style={{ marginBottom: '6px' }}>
                        <Col flex="auto">
                            <Title level={4} style={{ margin: 0 }}>Your Projects</Title>
                        </Col>
                        <Col>
                            <Input
                                placeholder="Search projects..."
                                prefix={<SearchOutlined />}
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                size="medium" // Set to medium size
                                style={{ width: '200px', marginRight: '12px' }} // Adjust width as needed
                            />
                        </Col>
                        <Col>
                            <Select
                                value={sortBy}
                                onChange={setSortBy}
                                style={{ width: 120 }} // Keep width for dropdown
                                size="medium" // Set to medium size
                            >
                                <Select.Option value="recent">Recent</Select.Option>
                                <Select.Option value="name">Name</Select.Option>
                                <Select.Option value="status">Status</Select.Option>
                            </Select>
                        </Col>
                    </Row>
                </div>
            )}

            {/* Projects List */}
            {/* <Spin spinning={loading || false}> */}
            {sortedProjects.length > 0 ? (
                <Row gutter={[0, 20]} justify="center" loading={loading}>
                    {sortedProjects.map(project => (
                        <Card
                            loading={loading}
                            size="small"
                            title={
                                <Space size="small" style={{ width: '100%', justifyContent: 'space-between', alignItems: 'center' }} >
                                    <Space size="small">
                                        <Text strong style={{ fontSize: '14px' }}>{project.name}</Text>
                                        <Tag color={project.is_active ? "green" : "red"}>
                                            {project.is_active ? "Active" : "Inactive"}
                                        </Tag>
                                    </Space>
                                    <Space>
                                        <Button
                                            type="text"
                                            icon={<EditOutlined />}
                                            onClick={() => handleEditProject(project)}
                                            size="small"
                                        />
                                        <Popconfirm
                                            title="Are you sure you want to delete this project?"
                                            onConfirm={() => handleDeleteProject(project.id)}
                                            okText="Yes"
                                            cancelText="No"
                                            okButtonProps={{ className: 'ant-btn-primary-custom',loading: deleteLoading }} 
                                            cancelButtonProps={{ className: 'ant-btn-default-custom' }}
                                        >
                                            <Button
                                                type="text"
                                                icon={<DeleteOutlined />}
                                                danger
                                                size="small"
                                            />
                                        </Popconfirm>
                                        <Button
                                            type="primary"
                                            onClick={() => handleOpenProject(project)}
                                            size="small"
                                            style={{ padding: '0 8px' }}
                                            className='ant-btn-primary-custom'
                                        >
                                            <ProjectOutlined /> Open
                                        </Button>
                                    </Space>
                                </Space>
                            }
                            style={{
                                width: '100%', // Set width to 80%
                                transition: 'all 0.3s ease',
                                borderRadius: '8px',
                                boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                                maxWidth: '100%',
                                margin: '0 auto',
                            }}
                            // onMouseEnter={e => {
                            //     e.currentTarget.style.transform = 'translateY(-4px) scale(1.02)';
                            //     e.currentTarget.style.boxShadow = '0 8px 18px rgba(0,0,0,0.5)';
                            // }}
                            // onMouseLeave={e => {
                            //     e.currentTarget.style.transform = 'translateY(0) scale(1)';
                            //     e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
                            // }}
                            className='project-card'
                        >
                            <Paragraph
                                ellipsis={{ rows: 1, expandable: false }}
                                style={{
                                    marginBottom: '8px',
                                    fontSize: '13px',
                                    lineHeight: '1.4'
                                }}
                            >
                                {project.description || 'No description provided'}
                            </Paragraph>
                            <Text
                                type="secondary"
                                style={{
                                    fontSize: '12px',
                                    display: 'block'
                                }}
                            >
                                Updated: {new Date(project.updated_at || project.created_at).toLocaleDateString()}
                            </Text>
                        </Card>
                    ))}
                </Row>
            ) : projects?.length === 0 && !loading ? (
                <Empty
                    image={Empty.PRESENTED_IMAGE_SIMPLE}
                    description={
                        <span>
                            <Title level={4}>Ready to Start Your First Project?</Title>
                            <Text type="secondary">
                                Create your first GenAI assessment project to begin the evaluation process.
                            </Text>
                        </span>
                    }
                >
                    <Button
                        type="primary"
                        icon={<PlusOutlined />}
                        onClick={() => setCreateModalVisible(true)}
                        size="medium"
                        className='ant-btn-primary-custom'
                    >
                        Create Your First Project
                    </Button>
                </Empty>
            ) : searchTerm && sortedProjects.length === 0 ? (
                <Empty description="No projects found matching your search criteria." />
            ) : null}
            {/* </Spin> */}

            {/* Create Project Modal */}
            <Modal
                title="Create New Project"
                open={createModalVisible}
                onCancel={() => {
                    setCreateModalVisible(false);
                    createForm.resetFields();
                }}
                footer={null}
                width={600}
            >
                <Form
                    form={createForm}
                    layout="vertical"
                    onFinish={handleCreateProject}
                >
                    <Form.Item
                        label="Project Name"
                        name="name"
                        rules={[{ required: true, message: 'Please enter project name' }]}
                    >
                        <Input placeholder="Enter a descriptive project name" />
                    </Form.Item>

                    <Form.Item
                        label="Description"
                        name="description"
                    >
                        <TextArea
                            rows={4}
                            placeholder="Describe your project goals and objectives"
                        />
                    </Form.Item>

                    <Form.Item style={{ marginBottom: 0, textAlign: 'right' }}>
                        <Space>
                            <Button onClick={() => setCreateModalVisible(false)} className=' ant-btn-default-custom'>
                                Cancel
                            </Button>
                            <Button
                                type="primary"
                                htmlType="submit"
                                loading={createLoading}
                                className=' ant-btn-primary-custom'
                            >
                                Create Project
                            </Button>
                        </Space>
                    </Form.Item>
                </Form>
            </Modal>

            {/* Edit Project Modal */}
            <Modal
                title="Edit Project"
                open={editModalVisible}
                onCancel={() => {
                    setEditModalVisible(false);
                    setSelectedProject(null);
                    editForm.resetFields();
                }}
                footer={null}
                width={600}
            >
                <Form
                    form={editForm}
                    layout="vertical"
                    onFinish={handleUpdateProject}
                >
                    <Form.Item
                        label="Project Name"
                        name="name"
                        rules={[{ required: true, message: 'Please enter project name' }]}
                    >
                        <Input placeholder="Enter a descriptive project name" />
                    </Form.Item>

                    <Form.Item
                        label="Description"
                        name="description"
                    >
                        <TextArea
                            rows={4}
                            placeholder="Describe your project goals and objectives"
                        />
                    </Form.Item>

                    <Form.Item style={{ marginBottom: 0, textAlign: 'right' }}>
                        <Space>
                            <Button onClick={() => setEditModalVisible(false)}
                                className=' ant-btn-default-custom'>
                                Cancel
                            </Button>
                            <Button
                                type="primary"
                                htmlType="submit"
                                loading={updateLoading}
                                className=' ant-btn-primary-custom'
                            >
                                Update Project
                            </Button>
                        </Space>
                    </Form.Item>
                </Form>
            </Modal>
        </div>
    );
};

export default ProjectManagement;