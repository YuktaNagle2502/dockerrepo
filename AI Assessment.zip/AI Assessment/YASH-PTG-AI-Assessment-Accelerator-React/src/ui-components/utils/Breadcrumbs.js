import React from 'react';
import { Breadcrumb } from 'antd';
import { Link, useLocation } from 'react-router-dom';
import { routes } from '../../util/constants';

// Create a mapping of paths to labels from routes
const pathToLabelMap = Object.values(routes).reduce((acc, route) => {
  if (route.path && route.label) {
    acc[route.path] = route.label;
  }
  return acc;
}, {});

// Function to get label for a path
const getPathLabel = (path, pathSegment) => {
  // First check if exact path exists in routes
  if (pathToLabelMap[path]) {
    return pathToLabelMap[path];
  }
  
  // Check for dynamic route patterns
  for (const [routePath, label] of Object.entries(pathToLabelMap)) {
    if (routePath.includes(':')) {
      // Convert route pattern to regex
      const regexPattern = routePath.replace(/:[^/]+/g, '[^/]+');
      const regex = new RegExp(`^${regexPattern}$`);
      
      if (regex.test(path)) {
        // For dynamic routes, you might want to customize labels based on context
        // For now, return the base label
        return label;
      }
    }
  }
  
  // If no route match found, try to make the path segment more readable
  return pathSegment
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

const Breadcrumbs = () => {
  const location = useLocation();
  const pathnames = location.pathname.split('/').filter(Boolean);

  const breadcrumbItems = pathnames.map((pathSegment, index) => {
    const path = '/' + pathnames.slice(0, index + 1).join('/');
    const label = getPathLabel(path, pathSegment);
    
    return {
      title: <Link to={path}>{label}</Link>,
    };
  });

  // Only add "Home" if not already at /home
  if (location.pathname !== routes.HOME.path) {
    breadcrumbItems.unshift({
      title: <Link to={routes.HOME.path}>{routes.HOME.label}</Link>,
    });
  }

  return <Breadcrumb items={breadcrumbItems} />;
};

export default Breadcrumbs;