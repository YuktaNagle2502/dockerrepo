import React from 'react'
import { routes } from '../../util/constants'
import { Route, Routes, useLocation, Navigate } from 'react-router-dom'
import LAYOUT from './LAYOUT'
import PageNotFound from '../pages/PageNotFound'
import UserLogoutPage from '../pages/UserLogoutPage'
import ProjectManagement from '../components/project_management/ProjectManagement'
import UseCaseGeneration from '../components/progress/UseCaseGeneration'
import DataReadinessAssessment from '../components/progress/DataReadinessAssessment'
import DataComplianceCheck from '../components/progress/DataComplianceCheck'
import AIProfiling from '../components/progress/AiProfiling'
import ModelEvaluation from '../components/progress/ModelEvaluation'
import ReportsDashboard from '../components/progress/ReportsDashboard'
import AssessmentProgress from '../components/project_management/AssessmentProgress'
import SprintPlanning from '../components/progress/SprintPlanning'


export default function NavRoutes() {
  const location = useLocation();

  return (
    <Routes location={location}>
      {/* Default route redirect */}
      <Route path="/" element={<Navigate to={routes.HOME.path} replace />} />

      {/* Layout wrapped routes */}
      <Route path={routes.HOME.path} element={<LAYOUT location={location} />} />
      <Route path={routes.VIEW_LIST.path} element={<LAYOUT location={location} />} />
      <Route path={routes.LOADING.path} element={<LAYOUT location={location} />} />
      
      {/* Project Management Routes */}
      <Route path={routes.PROJECT_MANAGEMENT.path} element={<LAYOUT location={location} />}>
        {/* This will render the main project management page */}
        <Route index element={<ProjectManagement />} />
        
        {/* Dynamic project routes */}
        <Route path=":projectName" element={<AssessmentProgress />} />
        
        {/* Assessment Stage Routes */}
        {/* <Route path=":projectId/project-setup" element={<ProjectSetup />} /> */}
        <Route path=":projectName/use-case-generation" element={<UseCaseGeneration />} />
        <Route path=":projectName/data-readiness" element={<DataReadinessAssessment />} />
        <Route path=":projectName/compliance-check" element={<DataComplianceCheck />} />
        <Route path=":projectName/ai-profiling" element={<AIProfiling />} />
        <Route path=":projectName/model-evaluation" element={<ModelEvaluation />} />
        <Route path=":projectName/sprint-planning" element={<SprintPlanning />} />
        <Route path=":projectName/final-report" element={<ReportsDashboard />} />
        
      </Route>

      {/* Logout route (no layout) */}
      <Route path={routes.LOGOUT.path} element={<UserLogoutPage/>} />

      {/* 404 fallback */}
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
}