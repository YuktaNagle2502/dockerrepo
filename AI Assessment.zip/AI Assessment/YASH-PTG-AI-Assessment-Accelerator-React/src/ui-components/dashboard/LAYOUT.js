import React, { useState, useMemo, useCallback } from "react";
import {
  Avatar,
  Button,
  Dropdown,
  Layout,
  Menu,
  Space,
  Switch,
  Typography,
  Divider,
  Card,
  Badge,
  Tooltip,
} from "antd";
import {
  UserOutlined,
  BellOutlined,
  DownOutlined,
  HomeOutlined,
  ProjectOutlined,
  BulbOutlined,
  BarChartOutlined,
  ShieldCheckOutlined,
  RobotOutlined,
  ThunderboltOutlined,
  FileTextOutlined,
  DashboardOutlined,
  TeamOutlined,
  SettingOutlined,
  LogoutOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  MailOutlined,
} from "@ant-design/icons";
import logoAI from "../../assests/assessment.png";
import { routes } from "../../util/constants";
import { useLocation, useNavigate } from "react-router-dom";
import NotAuthorized from "../pages/NotAuthorized";
import LoadingPage from "../pages/LoadingPage";
import Home from "../components/Home";
import ProjectManagement from "../components/project_management/ProjectManagement";
import Breadcrumbs from "../utils/Breadcrumbs";
import UseCaseGeneration from "../components/progress/UseCaseGeneration";
import DataReadinessAssessment from "../components/progress/DataReadinessAssessment";
import DataComplianceCheck from "../components/progress/DataComplianceCheck";
import AIProfiling from "../components/progress/AiProfiling";
import ModelEvaluation from "../components/progress/ModelEvaluation";
import ReportsDashboard from "../components/progress/ReportsDashboard";
import AssessmentProgress from "../components/project_management/AssessmentProgress";
import SprintPlanning from "../components/progress/SprintPlanning";

const { Content, Footer, Sider, Header } = Layout;
const { Text } = Typography;

const LAYOUT = () => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const user_name = localStorage.getItem("user_name");
  const user_email = localStorage.getItem("user_email");
  const user_profile = localStorage.getItem("user_profile");

  const toggle = useCallback(() => {
    setCollapsed((prev) => !prev);
  }, []);

  // Enhanced navigation items with icons and descriptions
  const navigationItems = [
    {
      key: routes.HOME.path,
      icon: <HomeOutlined />,
      label: "Home",
      // description: "Main dashboard",
      path: routes.HOME.path,
    },
    {
      key: routes.PROJECT_MANAGEMENT.path,
      icon: <ProjectOutlined />,
      label: "Project Management",
      // description: "Project management",
      path: routes.PROJECT_MANAGEMENT.path,
    },
    // {
    //   key: routes.USE_CASE_GENERATION.path,
    //   icon: <BulbOutlined />,
    //   label: "Use Cases Generation",
    //   // description: "Use case generation",
    //   path: routes.USE_CASE_GENERATION.path ,
    // },
    // {
    //   key: routes.DATA_READINESS || "/data-readiness",
    //   icon: <BarChartOutlined />,
    //   label: "Data Readiness",
    //   // description: "Data preparation status",
    //   path: routes.DATA_READINESS || "/data-readiness",
    // },
    // {
    //   key: routes.AI_PROFILING || "/ai-profiling",
    //   icon: <RobotOutlined />,
    //   label: "AI Profiling",
    //   // description: "AI model profiling",
    //   path: routes.AI_PROFILING || "/ai-profiling",
    // },
    // {
    //   key: routes.MODEL_EVALUATION || "/model-evaluation",
    //   icon: <ThunderboltOutlined />,
    //   label: "Model Evaluation",
    //   // description: "Model performance",
    //   path: routes.MODEL_EVALUATION || "/model-evaluation",
    // },
    // {
    //   key: routes.REPORTS || "/reports",
    //   icon: <FileTextOutlined />,
    //   label: "Reports",
    //   // description: "Reports dashboard",
    //   path: routes.REPORTS || "/reports",
    // },
  ];

  const handleProfileChange = () => {
    // Handle the switch change event here
  };

  const signOut = () => {
    // Clear localStorage items
    localStorage.removeItem("user_id");
    localStorage.removeItem("accessToken");
    localStorage.removeItem("user_name");
    localStorage.removeItem("user_email");
    localStorage.removeItem("user_roles");
    localStorage.removeItem("user_profile");

    // Clear session storage as well
    sessionStorage.clear();

    // Clear browser cache for specific domain
    if (window.caches) {
      caches.keys().then((names) => {
        names.forEach((name) => {
          caches.delete(name);
        });
      });
    }

    // Redirect to logout page
    navigate(routes.LOGOUT);
  };

const renderPathName = useMemo(() => {
  const pathname = location.pathname;
  
  switch (pathname) {
    case routes.HOME.path:
      return <Home />;
    case routes.PROJECT_MANAGEMENT.path:
      return <ProjectManagement />;
    case routes.LOADING.path:
      return <LoadingPage />;
    default:
      // Check if it's a project management dynamic route
      if (pathname.startsWith('/project-management/')) {
        // Extract the path segments
        const pathSegments = pathname.split('/');
        const projectId = pathSegments[2];
        
        // If it's just /project-management/:projectId (assessment progress)
        if (pathSegments.length === 3) {
          return <AssessmentProgress />;
        }
        
        // If it's a stage route /project-management/:projectId/stage-name
        if (pathSegments.length === 4) {
          const stageName = pathSegments[3];
          
          switch (stageName) {
            case 'use-case-generation':
              return <UseCaseGeneration />;
            case 'data-readiness':
              return <DataReadinessAssessment />;
            case 'compliance-check':
              return <DataComplianceCheck />;
            case 'ai-profiling':
              return <AIProfiling />;
            case 'model-evaluation':
              return <ModelEvaluation />;
            case 'sprint-planning':
              return <SprintPlanning/>;
            case 'final-report':
              return <ReportsDashboard />;
            default:
              return <NotAuthorized />;
          }
        }       
        // Default fallback for project management routes
        return <AssessmentProgress />;
      }
      return <NotAuthorized />;
  }
}, [location.pathname]);

  const RenderLayout = useMemo(
    () => (
      <Layout style={{ minHeight: "100vh" }}>
        <Header
          style={{
            padding: "0 24px",
            background: " #31304D", // Header Background color for the header
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            position: "fixed",
            width: "100%",
            zIndex: 1000,
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)",
            borderBottom: "1px solid rgba(255, 255, 255, 0.1)",
            maxHeight: 48
          }}
        >
          <div style={{ display: "flex", alignItems: "center" }}>
            <Button
              type="text"
              icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
              onClick={toggle}
              style={{
                fontSize: "16px",
                width: 40,
                height: 48,
                marginRight: "16px",
                color: "#ffffff",
                borderRadius: "8px",
                transition: "all 0.3s ease",
              }}
              onMouseEnter={(e) => {
                e.target.style.transform = "scale(1.05)";
              }}
              onMouseLeave={(e) => {
                e.target.style.transform = "scale(1)";
              }}
            />
            <div style={{
              display: "flex",
              alignItems: "center",
              padding: "0 16px",
              borderRadius: "12px",
              backdropFilter: "blur(10px)",
            }}>
              <img
                src={logoAI}
                alt="AiAss"
                style={{
                  height: "32px",
                  width: "32px",
                  marginRight: "12px",
                  filter: "drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1))"
                }}
              />
              <h1 style={{
                margin: 0,
                fontWeight: 700,
                fontSize: "22px",
                color: "#ffffff",
                textShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                letterSpacing: "0.5px"
              }}>
                AI Assessment
              </h1>
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "center" }}>
            <Space size="middle">
              <Badge count={3} size="small" style={{fontSize:'6px'}}>
                <Button
                  icon={<BellOutlined />}
                  style={{
                    color: "#ffffff",
                    background: "rgba(255, 255, 255, 0.1)",
                    border: "1px solid rgba(255, 255, 255, 0.2)",
                    borderRadius: "8px",
                    height: "24px",
                    width: "24px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    transition: "all 0.3s ease",
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.transform = "translateY(-2px)";
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.transform = "translateY(0)";
                  }}
                />
              </Badge>

              <Dropdown
                menu={{
                  items: [
                    // {
                    //   key: "divider1",
                    //   type: "divider",
                    // },
                    // {
                    //   key: "4",
                    //   label: (
                    //     <div className="flex items-center justify-between px-4">
                    //       <Switch
                    //         checkedChildren="User"
                    //         onChange={handleProfileChange}
                    //         className="ml-2"
                    //       />
                    //     </div>
                    //   ),
                    // },
                    // {
                    //   key: "divider2",
                    //   type: "divider",
                    // },
                    {
                      key: "1",
                      label: "Logout",
                      icon: <LogoutOutlined />,
                      onClick: signOut,
                    },
                  ],
                }}
              >
                <Button
                  type="text"
                  style={{
                    display: "flex",
                    alignItems: "center",
                    padding: "8px 16px",
                    height: "48px",
                    borderRadius: "25px",
                    color: "#ffffff",
                    transition: "all 0.3s ease",
                  }}
                >
                  <Avatar
                    icon={<UserOutlined />}
                    style={{
                      background: "rgba(255, 255, 255, 0.2)",
                      border: "2px solid rgba(255, 255, 255, 0.3)"
                    }}
                  />
                  <div style={{
                    marginLeft: "8px",
                    display: "flex",
                    alignItems: "center" // Ensure items are centered vertically
                  }}>
                    <span style={{
                      fontWeight: 600,
                      fontSize: "14px",
                      color: "#ffffff",
                      textShadow: "0 1px 2px rgba(0, 0, 0, 0.1)"
                    }}>
                      {user_name || "User"}
                    </span>
                    <DownOutlined style={{
                      marginLeft: "4px",
                      color: "#ffffff",
                      fontSize: "12px"
                    }} />
                  </div>
                </Button>
              </Dropdown>
            </Space>
          </div>
        </Header>
        <Layout className="site-layout" style={{ marginTop: "48px" }}>
          <div style={{ position: "relative" }}>
            <Sider
              trigger={null}
              collapsible
              collapsed={collapsed}
              width={220}
              style={{
                overflow: "hidden",
                height: "calc(100vh - 48px)",
                position: "fixed",
                left: 0,
                top: 48,
                bottom: 0,
                zIndex: 10,
                boxShadow: "2px 0 8px rgba(221, 217, 217, 0.15)",
                background: "rgb(223, 222, 221)",
              }}
            >
              <div style={{ padding: "16px 0" }}>

                {/* Navigation Section */}
                <div style={{ padding: "0 16px" }}>
                  {!collapsed && (
                    <Text
                      style={{
                        color: "rgb(94, 94, 94)",
                        fontSize: "14px",
                        fontWeight: "700",
                        textTransform: "uppercase",
                        letterSpacing: "1px",
                        marginBottom: "8px",
                        display: "block",
                      }}
                    >
                      🧭 Navigation
                    </Text>
                  )}
                </div>

                <Menu
                  mode="inline"
                  selectedKeys={[location.pathname]}
                  style={{
                    height: "auto",
                    borderRight: 0,
                    background: "transparent",
                  }}
                >
                  {navigationItems.map((item) => (
                    <Menu.Item
                      key={item.key}
                      icon={item.icon}
                      onClick={() => navigate(item.path)}
                      style={{
                        color: "rgb(87, 87, 87)",
                        fontSize: "14px",
                        marginBottom: "4px",
                        borderRadius: "6px",
                        height: "auto",
                        lineHeight: "normal",
                        padding: "8px 0px 8px 12px",
                      }}
                    >
                      <span style={{ display: "block" }}>
                        <span style={{ display: "block", lineHeight: "1.2" }}>
                          {item.label}
                        </span>
                        {!collapsed && (
                          <span
                            style={{
                              fontSize: "11px",
                              color: "#8c8c8c",
                              marginTop: "2px",
                              display: "block",
                              lineHeight: "1.1",
                              whiteSpace: "nowrap",
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                            }}
                          >
                            {item.description}
                          </span>
                        )}
                      </span>
                    </Menu.Item>
                  ))}

                  {/* <Divider style={{ margin: "16px 0", borderColor: "#434343" }} /> */}
                </Menu>
              </div>
            </Sider>
          </div>
          <Layout
            className="site-layout"
            style={{
              marginLeft: collapsed ? "80px" : "220px",
              transition: "all 0.2s ease",
            }}
          >
            <Content style={{ padding: "16px", minHeight: "calc(100vh - 64px - 70px)", background: "#f0f2f5" }}>
  <Breadcrumbs />
  <div style={{ marginTop: '16px' }}>
    {renderPathName}
  </div>
</Content>
 
            <Footer
              style={{
                textAlign: "center",
                background: " rgb(240, 242, 245)",
                padding: "12px",
                color: "#666",
              }}
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
              >
                <Text
                  type="secondary"
                  style={{ fontSize: "12px", color: "black" }}
                >
                  <strong>Yash Technologies</strong>{" "}
                  <strong>| RRT Team | </strong>
                  <strong>© {new Date().getFullYear()}</strong>
                </Text>
                <Text
                  type="secondary"
                  style={{ marginTop: "2px", fontSize: "12px" }}
                >
                  Disclaimer: AI can make mistakes too. Please verify important information.
                </Text>
              </div>
            </Footer>
          </Layout>
        </Layout>
      </Layout>
    ),
    [collapsed, renderPathName, toggle, location.pathname, user_name, user_email]
  );

  return RenderLayout;
};

export default React.memo(LAYOUT);