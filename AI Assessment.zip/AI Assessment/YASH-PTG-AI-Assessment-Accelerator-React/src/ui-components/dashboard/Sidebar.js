import React from 'react';
import { Layout, Menu, Button } from 'antd';
import { useNavigate, useLocation } from 'react-router-dom';
import {
    CreditCardTwoTone,
    FundViewOutlined,
    AppstoreOutlined,
    DatabaseOutlined,
    UserOutlined,
    MonitorOutlined
} from '@ant-design/icons';
import { routes } from '../../util/constants';
import AppSessions from '../components/User/AppSessions'; // Import the AppSessions component
import { useSelector } from 'react-redux';

const { Sider } = Layout;

const Sidebar = ({ collapsed, toggle }) => {
    const navigate = useNavigate();
    const location = useLocation();
    const isAdmin = useSelector(state => state.local.isAdmin);
    const isManager = useSelector(state => state.local.isManager);
    const isUser = useSelector(state => state.local.isUser);

    const allRoutes = [
        {
            key: routes.MONITORING_DASHBOARD,
            label: 'Monitoring',
            icon: <MonitorOutlined />,
            onClick: () => navigate(routes.MONITORING_DASHBOARD)
        },
        {
            key: routes.VIEW_LIST,
            label: 'Applications',
            icon: <AppstoreOutlined />,
            onClick: () => navigate(routes.VIEW_LIST)
        },

        {
            key: routes.VIEW_MODEL,
            label: 'Models',
            icon: <DatabaseOutlined />,
            onClick: () => navigate(routes.VIEW_MODEL)
        },
        {
            key: routes.USER_MANAGEMENT,
            label: 'User Management',
            icon: <UserOutlined />,
            onClick: () => navigate(routes.USER_MANAGEMENT)
        },
    ];

    const menuItemsManager = [
        {
            key: routes.VIEW_LIST,
            label: 'Applications',
            icon: <AppstoreOutlined />,
            onClick: () => navigate(routes.VIEW_LIST)
        },
    ];


    return (
        <Sider
            collapsedWidth="80"
            theme="light"
            trigger={null}
            collapsible
            collapsed={collapsed}
            width={250}
            style={{
                background: '#f0f0f0',
                overflowY: isAdmin ? 'auto' : 'hidden',
                height: '100vh',
                position: 'fixed',
                left: 0,
                top: 60,
                bottom: 0,
            }}
        >

            {/* render the toggle button for admin users */}
            {true && (
                <Menu mode="inline" style={{ height: '100%', paddingTop: '25px' }}>
                    {allRoutes.map(item => (
    <Menu.Item
        key={item.key}
        icon={item.icon}
        onClick={item.onClick}
        style={{
            fontSize: '18px',
            backgroundColor: location.pathname === item.key ? '#d9d9d9' : 'transparent',
            marginBottom: '10px'
        }}
    >
        {item.label}
    </Menu.Item>
))}
                </Menu>
            )}

        </Sider>
    );
};

export default Sidebar;