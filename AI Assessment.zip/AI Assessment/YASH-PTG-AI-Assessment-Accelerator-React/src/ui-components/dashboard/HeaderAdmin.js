// src/ui-components/dashboard/HeaderAdmin.js
import React from 'react';
import { Layout, Button } from 'antd';
import logo from '../../assests/GENERATIVE_AI.jpg';
import { routes } from '../../util/constants';
import { useNavigate } from 'react-router-dom';
const { Header } = Layout;

const HeaderAdmin = ({ toggle, collapsed, user, onToggleSidebar }) => {

  const navigate = useNavigate();


  const signOut = () => {
    // Clear localStorage items
    localStorage.removeItem('user_id');
    localStorage.removeItem('accessToken');
    localStorage.removeItem('user_name');
    localStorage.removeItem('user_email');
    localStorage.removeItem('user_roles');
    localStorage.removeItem('user_profile');
    
    // Clear session storage as well
    sessionStorage.clear();
    
    // Clear browser cache for specific domain (more complete logout)
    // Note: This requires the user to reload the page
    if (window.caches) {
      caches.keys().then(names => {
        names.forEach(name => {
          caches.delete(name);
        });
      });
    }
    
    // Redirect to logout page
    navigate(routes.LOGOUT);
  }


  return (
    <Header
      style={{
        padding: '0 24px',
        background: '#ffffff',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        position: 'fixed',
        width: '100%',
        zIndex: 1000,
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <img src={logo} alt="AI Factory Logo" style={{ height: '60px', marginLeft: '25px' , width: '130px'}} />
      </div>
      {/* <Button
        type="text"
        onClick={toggle}
        style={{ fontSize: '18px' }}
      >
        {collapsed ? '☰' : '✕'}
      </Button> */}
      <div>
        <span>Welcome, {'User'}</span>
        <Button
          type="link"
          onClick={signOut}
          style={{ marginLeft: '16px' }}
        >
          Sign Out
        </Button>
      </div>
    </Header>
  );
};

export default HeaderAdmin;