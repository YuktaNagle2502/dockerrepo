import React, { useState, useEffect } from 'react';
import { Spin } from 'antd';

const LoadingPage = () => {
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Set a timer to change to "Not Authorized" after 3 seconds
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000);
    
    // Clear the timer when component unmounts
    return () => clearTimeout(timer);
  }, []);
  
  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100vh',
    backgroundColor: '#f0f2f5',
  };
  
  const textStyle = {
    marginTop: '16px',
    fontSize: '16px',
    color: '#555',
  };
  
  const errorStyle = {
    fontSize: '20px',
    color: '#ff4d4f',
    fontWeight: 'bold',
  };

  return (
    <div style={containerStyle}>
      {isLoading ? (
        <>
          <Spin size="large" />
          <p style={textStyle}>Loading, please hold on a moment.</p>
        </>
      ) : (
        <>
          <p style={errorStyle}>Not Authorized</p>
          <p style={textStyle}>You don't have permission to access this page.</p>
        </>
      )}
    </div>
  );
};

export default LoadingPage;