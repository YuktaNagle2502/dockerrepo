import React from 'react';
import { Button, Typography } from 'antd';
import { FrownOutlined } from '@ant-design/icons';

const { Title, Paragraph } = Typography;

function PageNotFound() {
  const handleGoBack = () => {
    window.history.back(); // Go back to the previous page
  };

  const handleGoHome = () => {
    window.location.href = '/'; // Navigate to the home page
  };

  return (
    <div style={{ textAlign: 'center', margin: '50px' }}>
      <FrownOutlined style={{ fontSize: '48px', color: '#ff4d4f' }} />
      <Title level={4}>Page Not Found</Title>
      <Paragraph>
        The page you are looking for does not exist.
      </Paragraph>
      <Paragraph>
        Please check the URL or return to the homepage.
      </Paragraph>
      <Button type="primary" onClick={handleGoBack} style={{ marginRight: '10px' }}>
        Go Back
      </Button>
      <Button onClick={handleGoHome}>
        Go Home
      </Button>
    </div>
  );
}

export default PageNotFound;