import React from 'react';
import { Button, Typography } from 'antd';
import { ExclamationCircleOutlined } from '@ant-design/icons';

const { Title, Paragraph } = Typography;

const NotAuthorized = () => {
  const handleContactAdmin = () => {
    // Logic to handle contacting the admin (e.g., navigating to a contact page or displaying a modal)
    alert("Please contact your admin for access.");
  };

  const handleGoBack = () => {
    // Logic to go back to the previous page
    window.history.back();
  };

  return (
    <div style={{ textAlign: 'center', margin: '50px' }}>
      <ExclamationCircleOutlined style={{ fontSize: '48px', color: '#ff4d4f' }} />
      <Title level={4}>You are not authorized</Title>
      <Paragraph>
        It seems you do not have the necessary permissions to access this page.
      </Paragraph>
      <Paragraph>
        Please contact your admin to get access.
      </Paragraph>
      <Button type="primary" onClick={handleContactAdmin} style={{ marginRight: '10px' }}>
        Contact Admin
      </Button>
      <Button onClick={handleGoBack}>
        Go Back
      </Button>
    </div>
  );
}

export default NotAuthorized;