import { Spin, Button } from 'antd';
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const UserLogoutPage = () => {
  const [isLoggingOut, setIsLoggingOut] = useState(true);
  const navigate = useNavigate();
  
  useEffect(() => {
    // Simulate logout process
    const logoutUser = async () => {
      try {
        // Here you would typically call your logout API
        // Example: await authService.logout();
        
        // Simulate API call with timeout
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        setIsLoggingOut(false);
        
        // Redirect to login page after showing success message
        setTimeout(() => {
          // navigate('/login');
        }, 2000);
        
      } catch (error) {
        console.error('Logout failed:', error);
        setIsLoggingOut(false);
      }
    };
    
    logoutUser();
    
    // No cleanup needed for this effect
  }, [navigate]);
  
  const handleLogin = () => {
    window.location.href = 'https://rrt.genai.yashtech.link';
  };
  
  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100vh',
    backgroundColor: '#f0f2f5',
  };
  
  const textStyle = {
    marginTop: '16px',
    fontSize: '16px',
    color: '#555',
  };
  
  const successStyle = {
    fontSize: '20px',
    color: '#52c41a',
    fontWeight: 'bold',
  };

  const buttonStyle = {
    marginTop: '24px',
  };

  return (
    <div style={containerStyle}>
      {isLoggingOut ? (
        <>
          <Spin size="large" />
          <p style={textStyle}>Logging out, please wait...</p>
        </>
      ) : (
        <>
          <p style={successStyle}>Successfully Logged Out</p>
          {/* <p style={textStyle}>You will be redirected to the login page shortly.</p> */}
          <Button 
            type="primary" 
            size="large" 
            onClick={handleLogin}
            style={buttonStyle}
          >
            Go to Login
          </Button>
        </>
      )}
    </div>
  );
};

export default UserLogoutPage;