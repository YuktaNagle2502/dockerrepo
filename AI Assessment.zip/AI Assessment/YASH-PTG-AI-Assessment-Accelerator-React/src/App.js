// App.js
 
import React, { useEffect } from "react";
import "./App.css";
import { BrowserRouter } from "react-router-dom";
import NavRoutes from "./ui-components/dashboard/NavRoutes";
import { brand } from "./util/constants";
import "bootstrap/dist/css/bootstrap.min.css";
 
import { Provider, useDispatch } from "react-redux";
import store, { persistor } from "./redux/store";
 
// PersistGate delays rendering until rehydration is complete
import { PersistGate } from "redux-persist/integration/react";
 
function App() {
  useEffect(() => {
    document.title = brand.NAME;
  }, []);
 
  return (
    <Provider store={store}>
      {/* PersistGate ensures app waits until persisted state is loaded */}
      <PersistGate loading={null} persistor={persistor}>
        <BrowserRouter>
          <AuthCheck />
          <NavRoutes />
        </BrowserRouter>
      </PersistGate>
    </Provider>
  );
}
 
// Separate component to handle authentication check
function AuthCheck() { 
  return null; // This component doesn't render anything
}
 
export default App;
 