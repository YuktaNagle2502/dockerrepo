import Keycloak from 'keycloak-js';
import { keyCloak_ClientId, keyCloak_Realm, keyCloak_URL_Auth } from './constants';

const keycloak = new Keycloak({
url: keyCloak_URL_Auth,
realm: keyCloak_Realm,
clientId: keyCloak_ClientId,
});
export default keycloak;