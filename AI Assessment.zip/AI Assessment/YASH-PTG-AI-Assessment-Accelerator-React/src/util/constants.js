// export const routes = {
//   HOME: "/",
//   HOME: "/home",
//   VIEW_LIST: "/agent",
//   LOGOUT: "/redirect",
//   LOADING : "/loading",
//   PROJECT_MANAGEMENT: "/project-management",
// };
export const routes = {   
  HOME: { path: '/home', label: 'Home' },   
  VIEW_LIST: { path: '/agent', label: 'Agent List' },   
  LOGOUT: { path: '/redirect', label: 'Logout' },   
  LOADING: { path: '/loading', label: 'Loading' },   
  PROJECT_MANAGEMENT: { path: '/project-management', label: 'Project Management' },   
  ASSESSMENT_PROGRESS: { path: '/project-management/:projectName', label: 'Project Details' },   
  USE_CASE_DETAILS: { path: '/project-management/:projectName/usecase/:useCaseId', label: 'Use Case Details' },   
  USE_CASE_EDIT: { path: '/project-management/:projectName/usecase/:useCaseId/edit', label: 'Edit Use Case' },
  
  // Assessment Stage Routes
  PROJECT_SETUP: { path: '/project-management/:projectName/project-setup', label: 'Project Setup' },
  USE_CASE_GENERATION: { path: '/project-management/:projectName/use-case-generation', label: 'Use Case Generation' },
  DATA_READINESS: { path: '/project-management/:projectName/data-readiness', label: 'Data Readiness' },
  COMPLIANCE_CHECK: { path: '/project-management/:projectName/compliance-check', label: 'Compliance Check' },
  AI_PROFILING: { path: '/project-management/:projectName/ai-profiling', label: 'AI Profiling' },
  SPRINT_PLANNING: { path: '/project-management/:projectName/sprint-planning', label: 'Sprint Planning' },  // Added new route for sprint planning
  MODEL_EVALUATION: { path: '/project-management/:projectName/model-evaluation', label: 'Model Evaluation' },
  FINAL_REPORT: { path: '/project-management/:projectName/final-report', label: 'Final Report' },
};  

// Helper functions to generate dynamic paths with labels
export const generateProjectPath = (projectName) => ({   
  path: `/project-management/${projectName}`,   
  label: "Project Details"  
});

// Helper functions to generate stage paths
export const generateStagePath = (projectName, stage) => {
  const stageRoutes = {
    'project-setup': `/project-management/${projectName}/project-setup`,
    'use-case-generation': `/project-management/${projectName}/use-case-generation`,
    'data-readiness': `/project-management/${projectName}/data-readiness`,
    'compliance-check': `/project-management/${projectName}/compliance-check`,
    'ai-profiling': `/project-management/${projectName}/ai-profiling`,
    'sprint-planning': `/project-management/${projectName}/sprint-planning`,
    'model-evaluation': `/project-management/${projectName}/model-evaluation`,
    'final-report': `/project-management/${projectName}/final-report`,
  };
  
  return {
    path: stageRoutes[stage] || `/project-management/${projectName}`,
    label: routes[stage.toUpperCase().replace('-', '_')]?.label || 'Assessment Stage'
  };
};
export const generateUseCasePath = (projectName, useCaseId, useCaseName = 'Use Case Details') => ({
  path: `/project-management/${projectName}/usecase/${useCaseId}`,
  label: useCaseName
});

export const generateUseCaseEditPath = (projectName, useCaseId, useCaseName = 'Edit Use Case') => ({
  path: `/project-management/${projectName}/usecase/${useCaseId}/edit`,
  label: `Edit ${useCaseName}`
});
// Define route permissions by role
export const routePermissions = {
  [routes.ADMIN]: ['*'],
  [routes.HOME]: ['*'],
  [routes.USERS]: ['*'],
};


export const brand = {
  NAME: "AI Assessment",
};


export const URL = "https://api.aiassessment.yashtech.link"
// export const URL = "http://localhost:8000"
export const keyCloak_URL = "https://sso.yashtech.link"
export const keyCloak_URL_Auth = "https://sso.yashtech.link/"
// export const keyCloak_URL = "https://keycloak.rrt.genai.yashtech.link"
// export const keyCloak_URL_Auth = "https://keycloak.rrt.genai.yashtech.link/"
export const keyCloak_Realm = "yashtech_ai"
export const keyCloak_ClientId = "ai_assessment"


