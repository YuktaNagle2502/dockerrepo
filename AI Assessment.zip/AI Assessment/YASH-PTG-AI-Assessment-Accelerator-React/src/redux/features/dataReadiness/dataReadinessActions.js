import { createAsyncThunk } from '@reduxjs/toolkit'; // Adjust import path as needed
import axios from 'axios';
import { getService, postService } from '../../../Services';
import { URL } from '../../../util/constants';


// Get use case for a session (keeping the same as requested)
// get use case for a session
export const geteUseCase = createAsyncThunk(
  'dataReadiness/geteUseCase',
  async ({sessionId,useCaseId}, { rejectWithValue }) => {
    console.log('asdasdasdasdsad')
    try {
      // /pre-workshop/sessions/15/use-cases/90
      const url = `${URL}/pre-workshop/sessions/${sessionId}/use-cases/${useCaseId}`;
      const response = await getService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);
// Process uploaded files and run assessment (combined action)
export const processUploadedFiles = createAsyncThunk(
  'dataReadiness/processUploadedFiles',
  async (assessmentPayload, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      if (assessmentPayload.files && assessmentPayload.files.length > 0) {
        assessmentPayload.files.forEach((fileItem) => {
          formData.append('files', fileItem.originFileObj || fileItem); // support both AntD and raw File
        });
      }
      // Add file to form data
      // if (assessmentPayload.files && assessmentPayload.files.length > 0) {
      //   formData.append('files', assessmentPayload.files[0].originFileObj);
      // }
      
      // Add other assessment parameters
      formData.append('use_case_id', assessmentPayload.useCaseId);
      formData.append('projectId', assessmentPayload.projectId);
      formData.append('assessmentConfig', JSON.stringify(assessmentPayload.assessmentConfig));
      
      const url = `${URL}/data-readiness/analyze`;
        const accessToken=localStorage.getItem('accessToken');
      const response = await axios.post(url, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'authorization': `Bearer ${accessToken}`
        },
      });
      
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Generate report action
export const generateReport = createAsyncThunk(
  'dataReadiness/generateReport',
  async (reportPayload, { rejectWithValue }) => {
    try {
      const url = `${URL}/data-readiness/generate-pdf?data_readiness_id=${reportPayload.data_readiness_id}&use_case_id=${reportPayload.use_case_id}`;
      console.log('Requesting URL:', url);

      
const response = await axios.post(url, null, {
  headers: {
    'Authorization': `Bearer ${localStorage.getItem('accessToken')}`
  }
});
      console.log('Response:', response.data);
      console.log('Presigned URL:', response.data.data.presigned_url);
      return response.data;
    } catch (error) {
      console.error('Generate report error:', error);
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);


// Upload files action (if needed separately)
export const uploadFiles = createAsyncThunk(
  'dataReadiness/uploadFiles',
  async (files, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      files.forEach((file, index) => {
        formData.append(`file${index}`, file.originFileObj);
      });
      
      const url = `${URL}/data-readiness/upload`;
      const response = await postService(url, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Get assessment history
export const getAssessmentHistory = createAsyncThunk(
  'dataReadiness/getAssessmentHistory',
  async ({ useCaseId, projectId }, { rejectWithValue }) => {
    try {
      const url = `${URL}/data-readiness/history?useCaseId=${useCaseId}&projectId=${projectId}`;
      const response = await getService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Clear assessment results
export const clearAssessmentResults = createAsyncThunk(
  'dataReadiness/clearAssessmentResults',
  async (_, { rejectWithValue }) => {
    try {
      // This is a client-side action to clear results
      return null;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);
export const getDataReadiness = createAsyncThunk(
  'dataReadiness/getDataReadiness',
  async (useCaseId, { rejectWithValue }) => {
    try {
      const url = `${URL}/data-readiness/get_data_readiness/${useCaseId}`;
      const response = await getService(url); // This is your custom GET wrapper
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);