import { createSlice } from '@reduxjs/toolkit';
import {
  geteUseCase,
  processUploadedFiles,
  generateReport,
  uploadFiles,
  getAssessmentHistory,
  clearAssessmentResults,
  getDataReadiness
} from './dataReadinessActions';

const initialState = {
  // Use Case related state
  selectedUseCase: null,
  selectedUseCaseLoading: false,
  selectedUseCaseError: null,
  
  // File upload related state
  uploadedFiles: [],
  uploadLoading: false,
  uploadError: null,
  
  // Assessment related state
  assessmentResults: null,
  isLoading: false,
  assessmentError: null,
  
  // Processed data info
  processedDataInfo: null,
  
  // Report generation state
  reportLoading: false,
  reportError: null,
  generatedReport: null,
  
  // Assessment history
  assessmentHistory: [],
  historyLoading: false,
  historyError: null,

  fetchedReadinessData: null,
  fetchedReadinessLoading: false,
  fetchedReadinessError: null,
  
  // General UI state
  activeTab: '1',
  assessmentConfig: {
    depth: 'detailed',
    includeAI: true,
    generateRecommendations: true,
    includeCompliance: false
  }
};

const dataReadinessSlice = createSlice({
  name: 'dataReadiness',
  initialState,
  reducers: {
    // Set uploaded files
    setUploadedFiles: (state, action) => {
      state.uploadedFiles = action.payload;
    },
    
    // Clear uploaded files
    clearUploadedFiles: (state) => {
      state.uploadedFiles = [];
    },
    
    // Set active tab
    setActiveTab: (state, action) => {
      state.activeTab = action.payload;
    },
    
    // Update assessment config
    updateAssessmentConfig: (state, action) => {
      state.assessmentConfig = { ...state.assessmentConfig, ...action.payload };
    },
    
    // Clear assessment results
    clearResults: (state) => {
      state.assessmentResults = null;
      state.processedDataInfo = null;
      state.assessmentError = null;
    },
    
    // Clear all errors
    clearErrors: (state) => {
      state.selectedUseCaseError = null;
      state.uploadError = null;
      state.assessmentError = null;
      state.reportError = null;
      state.historyError = null;
    },
    
    // Reset state
    resetDataReadinessState: (state) => {
      return initialState;
    },
    setAssessmentResults(state, action) {
      state.assessmentResults = action.payload;
    },
    
  },
  extraReducers: (builder) => {
    builder
      // Get Use Case
      .addCase(geteUseCase.pending, (state) => {
        state.selectedUseCaseLoading = true;
        state.selectedUseCaseError = null;
      })
      .addCase(geteUseCase.fulfilled, (state, action) => {
        state.selectedUseCaseLoading = false;
        state.selectedUseCase = action.payload.data;
      })
      .addCase(geteUseCase.rejected, (state, action) => {
        state.selectedUseCaseLoading = false;
        state.selectedUseCaseError = action.payload;
      })
      
      // Process Uploaded Files and Run Assessment
      .addCase(processUploadedFiles.pending, (state) => {
        state.isLoading = true;
        state.assessmentError = null;
        state.assessmentResults = null;
      })
      .addCase(processUploadedFiles.fulfilled, (state, action) => {
        state.isLoading = false;
        state.assessmentResults = action.payload.data || action.payload;
        state.processedDataInfo = action.payload.processedDataInfo || null;
      })
      .addCase(processUploadedFiles.rejected, (state, action) => {
        state.isLoading = false;
        state.assessmentError = action.payload;
      })
      
      // Upload Files
      .addCase(uploadFiles.pending, (state) => {
        state.uploadLoading = true;
        state.uploadError = null;
      })
      .addCase(uploadFiles.fulfilled, (state, action) => {
        state.uploadLoading = false;
        state.processedDataInfo = action.payload.data || action.payload;
      })
      .addCase(uploadFiles.rejected, (state, action) => {
        state.uploadLoading = false;
        state.uploadError = action.payload;
      })
      
      // Generate Report
      .addCase(generateReport.pending, (state) => {
        state.reportLoading = true;
        state.reportError = null;
      })
      .addCase(generateReport.fulfilled, (state, action) => {
        state.reportLoading = false;
        // state.generatedReport = action.payload.data || action.payload;
        state.generatedReport = {
          presigned_url: action.payload.data.presigned_url,
          expires_at: action.payload.data.expires_at,
          data_readiness_id: action.meta.arg.data_readiness_id,
          use_case_id: action.meta.arg.use_case_id
        };
      })
      .addCase(generateReport.rejected, (state, action) => {
        state.reportLoading = false;
        state.reportError = action.payload;
      })
      
      // Get Assessment History
      .addCase(getAssessmentHistory.pending, (state) => {
        state.historyLoading = true;
        state.historyError = null;
      })
      .addCase(getAssessmentHistory.fulfilled, (state, action) => {
        state.historyLoading = false;
        state.assessmentHistory = action.payload.data || action.payload || [];
      })
      .addCase(getAssessmentHistory.rejected, (state, action) => {
        state.historyLoading = false;
        state.historyError = action.payload;
      })
      
      // Clear Assessment Results
      .addCase(clearAssessmentResults.fulfilled, (state) => {
        state.assessmentResults = null;
        state.processedDataInfo = null;
        state.assessmentError = null;
      })

      //  Get Data Readiness by use case ID
    .addCase(getDataReadiness.pending, (state) => {
      state.fetchedReadinessLoading = true;
      state.fetchedReadinessError = null;
    })
    .addCase(getDataReadiness.fulfilled, (state, action) => {
      state.fetchedReadinessLoading = false;
      state.fetchedReadinessData = action.payload.data || action.payload;
    })
    .addCase(getDataReadiness.rejected, (state, action) => {
      state.fetchedReadinessLoading = false;
      state.fetchedReadinessError = action.payload;
    });

  }
});

// Export actions
export const {
  setUploadedFiles,
  clearUploadedFiles,
  setActiveTab,
  updateAssessmentConfig,
  clearResults,
  clearErrors,
  resetDataReadinessState
} = dataReadinessSlice.actions;

// Export selectors
export const selectDataReadinessState = (state) => state.dataReadiness || state.readiness;
export const selectSelectedUseCase = (state) => selectDataReadinessState(state).selectedUseCase;
export const selectUploadedFiles = (state) => selectDataReadinessState(state).uploadedFiles;
export const selectAssessmentResults = (state) => selectDataReadinessState(state).assessmentResults;
export const selectIsLoading = (state) => selectDataReadinessState(state).isLoading;
export const selectAssessmentConfig = (state) => selectDataReadinessState(state).assessmentConfig;
export const selectFetchedReadinessData = (state) =>selectDataReadinessState(state).fetchedReadinessData;
export const { setAssessmentResults } = dataReadinessSlice.actions;
// Export reducer
export default dataReadinessSlice.reducer;