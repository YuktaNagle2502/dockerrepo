import { createSlice } from "@reduxjs/toolkit";
import {
  loadProjects,
  createProject,
  updateProject,
  deleteProject,
  refreshProjects,
  getProjectDetails,
  toggleProjectStatus,
  getUseCaseProgressStatus,
} from "./projectAction";

// Initial state
const initialState = {
  projects: [],
  selectedProject: null,
  currentProjectData: {
    id: null,
    projectName: "",
    projectDescription: "",
  },
  // Loading states
  loading: false,
  createLoading: false,
  updateLoading: false,
  deleteLoading: false,
  refreshLoading: false,
  detailsLoading: false,
  statusLoading: false,
  // Error states
  error: null,
  createError: null,
  updateError: null,
  deleteError: null,
  refreshError: null,
  detailsError: null,
  statusError: null,
  // UI states
  showCreateModal: false,
  showEditModal: false,
  searchTerm: "",
  sortBy: "recent",
  // Statistics
  totalProjects: 0,
  activeProjects: 0,
  completedProjects: 0,
  completionRate: 0,
  useCaseProgressStatus: null,
  usecaseProgressError: null,
  usecaseProgressLoading: false,
  // Workflow state management
  workflowState: {
    active_use_case_session: null,
    active_use_case_session_id: null,
    generated_use_cases: [],
    selected_use_case_for_data: null,
    selected_use_case_id: null,
    uploaded_data_files: [],
    processed_data_info: null,
    assessment_results: null,
    compliance_results: null,
    profiling_results: null,
  },
};

// Helper function to calculate statistics
const calculateStatistics = (projects) => {
  const totalProjects = projects.length;
  const activeProjects = projects.filter((p) => p.is_active).length;
  const completedProjects = projects.filter(
    (p) => p.status === "completed"
  ).length; // Adjust based on your data structure
  const completionRate =
    totalProjects > 0 ? (completedProjects / totalProjects) * 100 : 0;

  return {
    totalProjects,
    activeProjects,
    completedProjects,
    completionRate,
  };
};

const projectSlice = createSlice({
  name: "projects",
  initialState,
  reducers: {
    // UI state management
    setShowCreateModal: (state, action) => {
      state.showCreateModal = action.payload;
    },
    setShowEditModal: (state, action) => {
      state.showEditModal = action.payload;
    },
    setSearchTerm: (state, action) => {
      state.searchTerm = action.payload;
    },
    setSortBy: (state, action) => {
      state.sortBy = action.payload;
    },
    setSelectedProject: (state, action) => {
      state.selectedProject = action.payload;
    },
    // Project data management
    setProjectData: (state, action) => {
      state.currentProjectData = {
        ...state.currentProjectData,
        ...action.payload,
      };
    },
    // Clear all errors
    clearErrors: (state) => {
      state.error = null;
      state.createError = null;
      state.updateError = null;
      state.deleteError = null;
      state.refreshError = null;
      state.detailsError = null;
      state.statusError = null;
    },
    // Clear specific error
    clearError: (state, action) => {
      const errorType = action.payload;
      if (state.hasOwnProperty(errorType)) {
        state[errorType] = null;
      }
    },
    // Workflow state management
    setWorkflowState: (state, action) => {
      state.workflowState = {
        ...state.workflowState,
        ...action.payload,
      };
    },
    clearWorkflowState: (state) => {
      state.workflowState = {
        active_use_case_session: null,
        active_use_case_session_id: null,
        generated_use_cases: [],
        selected_use_case_for_data: null,
        selected_use_case_id: null,
        uploaded_data_files: [],
        processed_data_info: null,
        assessment_results: null,
        compliance_results: null,
        profiling_results: null,
      };
    },
    // Reset project state
    resetProjectState: (state) => {
      return {
        ...initialState,
        projects: state.projects, // Keep projects data
        ...calculateStatistics(state.projects),
      };
    },
    // Update project in list (for optimistic updates)
    updateProjectInList: (state, action) => {
      const { id, updates } = action.payload;
      const projectIndex = state.projects.findIndex((p) => p.id === id);
      if (projectIndex !== -1) {
        state.projects[projectIndex] = {
          ...state.projects[projectIndex],
          ...updates,
          updated_at: new Date().toISOString(),
        };
        // Recalculate statistics
        const stats = calculateStatistics(state.projects);
        Object.assign(state, stats);
      }
    },
  },
  extraReducers: (builder) => {
    // Load Projects
    builder
      .addCase(loadProjects.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(loadProjects.fulfilled, (state, action) => {
        state.loading = false;
        state.projects = action.payload.data;
        state.error = null;
        // Calculate and update statistics
        const stats = calculateStatistics(action.payload.data);
        Object.assign(state, stats);
      })
      .addCase(loadProjects.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
        state.projects = [];
      });

    // Create Project
    builder
      .addCase(createProject.pending, (state) => {
        state.createLoading = true;
        state.createError = null;
      })
      .addCase(createProject.fulfilled, (state, action) => {
        state.createLoading = false;
        state.projects.push(action.payload.data);
        state.createError = null;
        state.showCreateModal = false;
        // Recalculate statistics
        const stats = calculateStatistics(state.projects);
        Object.assign(state, stats);
      })
      .addCase(createProject.rejected, (state, action) => {
        state.createLoading = false;
        state.createError = action.payload;
      });

    // Update Project
    builder
      .addCase(updateProject.pending, (state) => {
        state.updateLoading = true;
        state.updateError = null;
      })
      .addCase(updateProject.fulfilled, (state, action) => {
        state.updateLoading = false;
        const projectIndex = state.projects.findIndex(
          (p) => p.id === action.payload.data.id
        );
        if (projectIndex !== -1) {
          state.projects[projectIndex] = {
            ...state.projects[projectIndex],
            ...action.payload.data,
            updated_at: new Date().toISOString(),
          };
        }
        state.updateError = null;
        state.showEditModal = false;
        state.selectedProject = null;
        // Recalculate statistics
        const stats = calculateStatistics(state.projects);
        Object.assign(state, stats);
      })
      .addCase(updateProject.rejected, (state, action) => {
        state.updateLoading = false;
        state.updateError = action.payload.data;
      });

    // Delete Project
    builder
      .addCase(deleteProject.pending, (state) => {
        state.deleteLoading = true;
        state.deleteError = null;
      })
      .addCase(deleteProject.fulfilled, (state, action) => {
        state.deleteLoading = false;
        console.log("in_slice", action.payload.data);
        state.projects = state.projects.filter(
          (p) => p.id !== action.payload.data.id
        );
        state.deleteError = null;
        // Reset selected project if it was deleted
        if (
          state.selectedProject &&
          state.selectedProject.id === action.payload.data.id
        ) {
          state.selectedProject = null;
        }
        // Recalculate statistics
        const stats = calculateStatistics(state.projects);
        Object.assign(state, stats);
      })
      .addCase(deleteProject.rejected, (state, action) => {
        state.deleteLoading = false;
        state.deleteError = action.payload.data;
      });

    // Refresh Projects
    builder
      .addCase(refreshProjects.pending, (state) => {
        state.refreshLoading = true;
        state.refreshError = null;
      })
      .addCase(refreshProjects.fulfilled, (state, action) => {
        state.refreshLoading = false;
        state.projects = action.payload.data;
        state.refreshError = null;
        // Recalculate statistics
        const stats = calculateStatistics(action.payload.data);
        Object.assign(state, stats);
      })
      .addCase(refreshProjects.rejected, (state, action) => {
        state.refreshLoading = false;
        state.refreshError = action.payload.data;
      });

    // Get Project Details
    builder
      .addCase(getProjectDetails.pending, (state) => {
        state.detailsLoading = true;
        state.detailsError = null;
      })
      .addCase(getProjectDetails.fulfilled, (state, action) => {
        state.detailsLoading = false;
        state.selectedProject = action.payload.data;
        state.detailsError = null;
        // Update project in list if it exists
        const projectIndex = state.projects.findIndex(
          (p) => p.id === action.payload.data.id
        );
        if (projectIndex !== -1) {
          state.projects[projectIndex] = action.payload.data;
        }
      })
      .addCase(getProjectDetails.rejected, (state, action) => {
        state.detailsLoading = false;
        state.detailsError = action.payload.data;
      });

    // Toggle Project Status
    builder
      .addCase(toggleProjectStatus.pending, (state) => {
        state.statusLoading = true;
        state.statusError = null;
      })
      .addCase(toggleProjectStatus.fulfilled, (state, action) => {
        state.statusLoading = false;
        const projectIndex = state.projects.findIndex(
          (p) => p.id === action.payload.data.id
        );
        if (projectIndex !== -1) {
          state.projects[projectIndex] = {
            ...state.projects[projectIndex],
            ...action.payload.data,
            updated_at: new Date().toISOString(),
          };
        }
        state.statusError = null;
        // Recalculate statistics
        const stats = calculateStatistics(state.projects);
        Object.assign(state, stats);
      })
      .addCase(toggleProjectStatus.rejected, (state, action) => {
        state.statusLoading = false;
        state.statusError = action.payload.data;
      });

    //get usecase progress
    builder
      .addCase(getUseCaseProgressStatus.pending, (state) => {
        state.usecaseProgressLoading = true;
        state.usecaseProgressError = null;
      })
      .addCase(getUseCaseProgressStatus.fulfilled, (state, action) => {
        state.usecaseProgressLoading = false;
        state.useCaseProgressStatus = action.payload.data;
        state.usecaseProgressError = null;
      })
      .addCase(getUseCaseProgressStatus.rejected, (state, action) => {
        state.usecaseProgressLoading = false;
        state.usecaseProgressError = action.payload.data;
      });
  },
});

// Export actions
export const {
  setShowCreateModal,
  setShowEditModal,
  setSearchTerm,
  setSortBy,
  setSelectedProject,
  setProjectData,
  clearErrors,
  clearError,
  setWorkflowState,
  clearWorkflowState,
  resetProjectState,
  updateProjectInList,
} = projectSlice.actions;

// Selectors
export const selectProjects = (state) => state.projects.projects;
export const selectProjectsLoading = (state) => state.projects.loading;
export const selectProjectsError = (state) => state.projects.error;
export const selectSelectedProject = (state) => state.projects.selectedProject;
export const selectCurrentProjectData = (state) =>
  state.projects.currentProjectData;
export const selectProjectStatistics = (state) => ({
  totalProjects: state.projects.totalProjects,
  activeProjects: state.projects.activeProjects,
  completedProjects: state.projects.completedProjects,
  completionRate: state.projects.completionRate,
});
export const selectWorkflowState = (state) => state.projects.workflowState;
export const selectUIState = (state) => ({
  showCreateModal: state.projects.showCreateModal,
  showEditModal: state.projects.showEditModal,
  searchTerm: state.projects.searchTerm,
  sortBy: state.projects.sortBy,
});

// Filtered and sorted projects selector
export const selectFilteredAndSortedProjects = (state) => {
  const { projects, searchTerm, sortBy } = state.projects;

  // Filter projects
  let filteredProjects = projects;
  if (searchTerm) {
    filteredProjects = projects.filter(
      (project) =>
        project.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.description?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  // Sort projects
  const sortedProjects = [...filteredProjects].sort((a, b) => {
    switch (sortBy) {
      case "recent":
        return (
          new Date(b.updated_at || b.created_at) -
          new Date(a.updated_at || a.created_at)
        );
      case "name":
        return a.name?.localeCompare(b.name);
      case "status":
        return (b.is_active ? 1 : 0) - (a.is_active ? 1 : 0);
      default:
        return 0;
    }
  });

  return sortedProjects;
};

// Export reducer
export default projectSlice.reducer;
