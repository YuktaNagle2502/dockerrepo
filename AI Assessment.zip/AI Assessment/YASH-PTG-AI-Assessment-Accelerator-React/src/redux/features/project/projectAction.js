import { createAsyncThunk } from "@reduxjs/toolkit";
import {
  getService,
  postService,
  putService,
  deleteService,
} from "../../../Services/index";
import { URL } from "../../../util/constants";

// Async thunk for loading projects
export const loadProjects = createAsyncThunk(
  "projects/loadProjects",
  async (_, { rejectWithValue }) => {
    try {
      const url = `${URL}/auth/projects`;
      const response = await getService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);
export const getUseCaseProgressStatus = createAsyncThunk(
  "projects/getUseCaseProgressStatus",
  async (useCaseId, { rejectWithValue }) => {
    try {
      const url = `${URL}/pre-workshop/use_case/${useCaseId}/statuses`;
      const response = await getService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Async thunk for creating a project
export const createProject = createAsyncThunk(
  "projects/createProject",
  async ({ name, description }, { rejectWithValue }) => {
    try {
      const url = `${URL}/auth/projects`;
      const requestBody = {
        name: name.trim(),
        description: description?.trim() || "",
      };
      const response = await postService(url, requestBody);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Async thunk for updating a project
export const updateProject = createAsyncThunk(
  "projects/updateProject",
  async ({ id, name, description }, { rejectWithValue }) => {
    try {
      const url = `${URL}/auth/projects/${id}`;
      const requestBody = {
        name: name.trim(),
        description: description?.trim() || "",
      };
      const response = await putService(url, requestBody);
      return { id, ...response.data };
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Async thunk for deleting a project
export const deleteProject = createAsyncThunk(
  "projects/deleteProject",
  async (projectId, { rejectWithValue }) => {
    try {
      const url = `${URL}/auth/projects/${projectId}`;
      const response = await deleteService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Async thunk for refreshing projects
export const refreshProjects = createAsyncThunk(
  "projects/refreshProjects",
  async (_, { rejectWithValue }) => {
    try {
      const url = `${URL}/auth/projects`;
      const response = await getService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Async thunk for getting project details
export const getProjectDetails = createAsyncThunk(
  "projects/getProjectDetails",
  async (projectId, { rejectWithValue }) => {
    try {
      const url = `${URL}/auth/projects/${projectId}`;
      const response = await getService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Async thunk for toggling project active status
export const toggleProjectStatus = createAsyncThunk(
  "projects/toggleProjectStatus",
  async ({ id, is_active }, { rejectWithValue }) => {
    try {
      const url = `${URL}/auth/projects/${id}`;
      const requestBody = { is_active };
      const response = await putService(url, requestBody);
      return { id, ...response.data };
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);
