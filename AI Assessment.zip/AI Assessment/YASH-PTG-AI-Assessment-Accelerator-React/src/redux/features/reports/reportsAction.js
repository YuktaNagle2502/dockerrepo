import { createAsyncThunk } from '@reduxjs/toolkit';
import { getService, postService, deleteService } from '../../../Services/index';
import { URL } from '../../../util/constants';
import { message } from 'antd';

// Async thunk for fetching reports
export const fetchReports = createAsyncThunk(
  'reports/fetchReports',
  async (use_case_id, { rejectWithValue }) => {
    try {
      const url = `${URL}/reports/usecase/${use_case_id}/presigned-urls`;
      const response = await getService(url);
      return response.data;
    } catch (error) {
      message.error('Failed to load reports');
      return rejectWithValue(error.response.data);
    }
  }
);

// Async thunk for downloading a report
export const downloadReport = createAsyncThunk(
  'reports/downloadReport',
  async (reportId, { rejectWithValue, getState }) => {
    try {
      // Find report by ID to get UUID
      const { reports } = getState().reports;
      const report = reports.find(r => r.id === reportId);
      
      if (!report) {
        throw new Error('Report not found');
      }
      
      // Use a custom service for blob response
      const url = `${URL}/reports/${report.report_uuid}/download`;
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to download report');
      }
      
      // Create download link
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = `report_${reportId}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(downloadUrl);
      
      message.success('Report downloaded successfully');
      return { reportId };
    } catch (error) {
      message.error('Failed to download report');
      return rejectWithValue(error.message);
    }
  }
);

// Async thunk for deleting a report
export const deleteReport = createAsyncThunk(
  'reports/deleteReport',
  async (reportId, { rejectWithValue, getState }) => {
    try {
      // Find report by ID to get UUID
      const { reports } = getState().reports;
      const report = reports.find(r => r.id === reportId);
      
      if (!report) {
        throw new Error('Report not found');
      }
      
      const url = `${URL}/reports/${report.report_uuid}`;
      await deleteService(url);
      
      message.success('Report deleted successfully');
      return reportId;
    } catch (error) {
      message.error('Failed to delete report');
      return rejectWithValue(error.response.data);
    }
  }
);

// Async thunk for generating summary report
export const generateSummaryReport = createAsyncThunk(
  'reports/generateSummaryReport',
  async (projectId, { rejectWithValue }) => {
    try {
      // Use a custom service for blob response
      const url = `${URL}/projects/${projectId}/reports/summary`;
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate summary report');
      }
      
      // Create download link
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = `summary_report_${projectId}_${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(downloadUrl);
      
      message.success('Summary report generated successfully');
      return { projectId };
    } catch (error) {
      message.error('Failed to generate summary report');
      return rejectWithValue(error.message);
    }
  }
);