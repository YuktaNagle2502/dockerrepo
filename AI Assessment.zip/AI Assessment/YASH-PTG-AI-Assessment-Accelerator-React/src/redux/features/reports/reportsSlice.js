import { createSlice } from '@reduxjs/toolkit';
import { 
  fetchReports, 
  downloadReport, 
  deleteReport, 
  generateSummaryReport 
} from './reportsAction';

const initialState = {
  reports: [],
  
  // Fetch reports states
  reportsLoading: false,
  reportsError: null,
  
  // Download report states
  downloadLoading: false,
  downloadError: null,
  
  // Delete report states
  deleteLoading: false,
  deleteError: null,
  
  // Generate summary states
  generateSummaryLoading: false,
  generateSummaryError: null,
  
};

const reportsSlice = createSlice({
  name: 'reports',
  initialState,
  reducers: {
    setSelectedProject: (state, action) => {
      state.selectedProject = action.payload;
    },
    clearReportsError: (state) => {
      state.reportsError = null;
    },
    clearDownloadError: (state) => {
      state.downloadError = null;
    },
    clearDeleteError: (state) => {
      state.deleteError = null;
    },
    clearGenerateSummaryError: (state) => {
      state.generateSummaryError = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Fetch Reports
      .addCase(fetchReports.pending, (state) => {
        state.reportsLoading = true;
        state.reportsError = null;
      })
      .addCase(fetchReports.fulfilled, (state, action) => {
        state.reportsLoading = false;
        console.log("action.payload.data", action.payload.data.reports)
        state.reports = action.payload.data;
      })
      .addCase(fetchReports.rejected, (state, action) => {
        state.reportsLoading = false;
        state.reportsError = action.payload;
      })
      
      // Download Report
      .addCase(downloadReport.pending, (state) => {
        state.downloadLoading = true;
        state.downloadError = null;
      })
      .addCase(downloadReport.fulfilled, (state, action) => {
        state.downloadLoading = false;
        // No state update needed as file is downloaded directly
      })
      .addCase(downloadReport.rejected, (state, action) => {
        state.downloadLoading = false;
        state.downloadError = action.payload;
      })
      
      // Delete Report
      .addCase(deleteReport.pending, (state) => {
        state.deleteLoading = true;
        state.deleteError = null;
      })
      .addCase(deleteReport.fulfilled, (state, action) => {
        state.deleteLoading = false;
        state.reports = state.reports.filter(report => report.id !== action.payload);
      })
      .addCase(deleteReport.rejected, (state, action) => {
        state.deleteLoading = false;
        state.deleteError = action.payload;
      })
      
      // Generate Summary Report
      .addCase(generateSummaryReport.pending, (state) => {
        state.generateSummaryLoading = true;
        state.generateSummaryError = null;
      })
      .addCase(generateSummaryReport.fulfilled, (state, action) => {
        state.generateSummaryLoading = false;
        // No state update needed as file is downloaded directly
      })
      .addCase(generateSummaryReport.rejected, (state, action) => {
        state.generateSummaryLoading = false;
        state.generateSummaryError = action.payload;
      });
  }
});

export const {
  setSelectedProject,
  clearReportsError,
  clearDownloadError,
  clearDeleteError,
  clearGenerateSummaryError
} = reportsSlice.actions;

export default reportsSlice.reducer;