import { createSlice } from '@reduxjs/toolkit';
import { generateSprintPlan,getSprintData ,getOverallScore} from './sprintAction';

const initialState = {
  // This is for testing purposes only
  selectedUseCase: null,
  
  // Sample assessment data for testing
  assessmentResults: {
    readinessScore: 85
  },
  
  complianceResults: {
    complianceScore: 92
  },
  
  profilingResults: {
    qualityScore: 88
  },
  
  evaluationResults: {
    averageAccuracy: 89
  },
  sprintData:null,
  overallScore:null,
   overallLoading: false,
    overallError: null,
  sprintConfig: null,
  
  sprintPlan: null,
  sprintPlanningCompleted: false,
  loading: false,
  error: null
};

const sprintPlanningSlice = createSlice({
  name: 'sprintPlanning',
  initialState,
  reducers: {
    setSprintConfig: (state, action) => {
      state.sprintConfig = action.payload;
    },
    
    setSprintPlan: (state, action) => {
      state.sprintPlan = action.payload;
    },
    
    setSprintPlanningCompleted: (state, action) => {
      state.sprintPlanningCompleted = action.payload;
    },
    
    setSelectedUseCase: (state, action) => {
      state.selectedUseCase = action.payload;
    },
    
    setAssessmentResults: (state, action) => {
      state.assessmentResults = action.payload;
    },
    
    setComplianceResults: (state, action) => {
      state.complianceResults = action.payload;
    },
    
    setProfilingResults: (state, action) => {
      state.profilingResults = action.payload;
    },
    
    setEvaluationResults: (state, action) => {
      state.evaluationResults = action.payload;
    },
    
    clearSprintData: (state) => {
      state.sprintConfig = null;
      state.sprintPlan = null;
      state.sprintPlanningCompleted = false;
    },
    
    setError: (state, action) => {
      state.error = action.payload;
      state.loading = false;
    }
  },
  
  extraReducers: (builder) => {
    builder
      .addCase(generateSprintPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(generateSprintPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.sprintPlan = action.payload.data;
        state.sprintPlanningCompleted = true;
      })
      .addCase(generateSprintPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload.error;
      })
      .addCase(getOverallScore.pending, (state) => {
        state.overallLoading = true;
        state.overallError = null;
      })
      .addCase(getOverallScore.fulfilled, (state, action) => {
        console.log("action.payload.data:",action.payload.data)
        state.overallLoading = false;
        state.overallScore = action.payload.data;
      })
      .addCase(getOverallScore.rejected, (state, action) => {
        state.overallLoading = false;
        state.overallError = action.payload.error;
      })
      .addCase(getSprintData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getSprintData.fulfilled, (state, action) => {
        state.loading = false;
        state.sprintData = action.payload.data;
      })
      .addCase(getSprintData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload.error;
      })
      ;
  }
});

export const {
  setSprintConfig,
  setSprintPlan,
  setSprintPlanningCompleted,
  setSelectedUseCase,
  setAssessmentResults,
  setComplianceResults,
  setProfilingResults,
  setEvaluationResults,
  clearSprintData,
  setError
} = sprintPlanningSlice.actions;

export default sprintPlanningSlice.reducer;