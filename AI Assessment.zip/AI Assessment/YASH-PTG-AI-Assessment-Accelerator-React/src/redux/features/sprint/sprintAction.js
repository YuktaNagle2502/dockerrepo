import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { URL } from "../../../util/constants";
import { getService } from "../../../Services";

// Helper function to get content type based on format
const getContentType = (format) => {
  switch (format) {
    case "pdf":
      return "application/pdf";
    case "excel":
      return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    case "json":
      return "application/json";
    default:
      return "application/octet-stream";
  }
};

export const generateSprintPlan = createAsyncThunk(
  "sprint/generatePlan",
  async (sprintConfig, { rejectWithValue }) => {
    try {
      const url = `${URL}/sprint-planning/generate`;
      console.log("sprintConfig.priorities:",sprintConfig.priorities)
      const formData = new FormData();
      formData.append("use_case_id", sprintConfig.useCase?.id);
      formData.append("project_type",sprintConfig.projectType);
      formData.append("sprint_duration_weeks", sprintConfig.sprintDuration.split(" ")[0] );
      formData.append("development_methodology", sprintConfig.methodology);
      formData.append("team_size", sprintConfig.teamSize); 
      formData.append("project_start_date", sprintConfig.startDate);
      formData.append("include_comprehensive_testing_phases", sprintConfig.includeTesting);
      formData.append("include_deployment_and_monitoring_setup", sprintConfig.includeDeployment);
      formData.append("include_documentation_tasks", sprintConfig.includeDocumentation);
      // formData.append("project_priorities", sprintConfig.priorities);
      sprintConfig.priorities.forEach(priority => {
  formData.append("project_priorities", priority); // ✅ Correct
});
      const teamComposition = {
      "Frontend Developer": (sprintConfig.frontendDevs || 0),
      "Backend Developer":(sprintConfig.backendDevs || 0),
      "ML Engineer":(sprintConfig.mlEngineers || 0),
      "DevOps Engineer": (sprintConfig.devopsEngineers || 0),
      "QA Engineer": (sprintConfig.dataScientists || 0),
      "Data Scientist": (sprintConfig.qaEngineers || 0),
      };
      console.log(JSON.stringify(teamComposition))
      formData.append("team_composition", JSON.stringify(teamComposition));
      const accessToken = localStorage.getItem("accessToken");
      const response = await axios.post(url, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${accessToken}`,
        },
      });

      return response.data; // Extract data from standardized response
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

export const saveSprintConfig = createAsyncThunk(
  "sprint/saveConfig",
  async (configData, { rejectWithValue }) => {
    try {
      const url = `${URL}/sprint-planning/save-config`;
      const accessToken = localStorage.getItem("accessToken");

      const response = await axios.post(url, configData, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

export const exportSprintPlan = createAsyncThunk(
  "sprint/exportPlan",
  async (
    { sprint_planning_id },
    { rejectWithValue }
  ) => {
    try {
      const accessToken = localStorage.getItem("accessToken");
      const url = `${URL}/sprint-planning/generate-pdf?sprint_planning_id=${sprint_planning_id}`;

      const response = await axios.post(url, null, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      });

      console.log('Export Sprint Plan API Response:', response.data); // Debug log

      if (!response.data.success || !response.data.data?.presigned_url) {
        throw new Error(response.data.message || 'No presigned URL in response');
      }

      return {
        success: response.data.success,
        presigned_url: response.data.data.presigned_url,
        report_path: response.data.data.report_path,
        expires_at: response.data.data.expires_at,
        format: "pdf"
      };
    } catch (error) {
      console.error('Export Sprint Plan Error:', error);
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

export const fetchSprintPlan = createAsyncThunk(
  "sprint/fetchPlan",
  async (sprint_plan_id, { rejectWithValue }) => {
    try {
      const url = `${URL}/sprint-planning/plan/${sprint_plan_id}`;
      const accessToken = localStorage.getItem("accessToken");

      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

export const updateSprintPlan = createAsyncThunk(
  "sprint/updatePlan",
  async ({ sprint_plan_id, updateData }, { rejectWithValue }) => {
    try {
      const url = `${URL}/sprint-planning/plan/${sprint_plan_id}`;
      const accessToken = localStorage.getItem("accessToken");

      const response = await axios.put(url, updateData, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

export const deleteSprintPlan = createAsyncThunk(
  "sprint/deletePlan",
  async (sprint_plan_id, { rejectWithValue }) => {
    try {
      const url = `${URL}/sprint-planning/plan/${sprint_plan_id}`;
      const accessToken = localStorage.getItem("accessToken");

      const response = await axios.delete(url, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      return { sprint_plan_id, success: true };
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

export const fetchUseCaseData = createAsyncThunk(
  "sprint/fetchUseCaseData",
  async (useCaseId, { rejectWithValue }) => {
    try {
      const url = `${URL}/use-cases/${useCaseId}`;
      const accessToken = localStorage.getItem("accessToken");

      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

export const fetchAssessmentData = createAsyncThunk(
  "sprint/fetchAssessmentData",
  async (use_case_id, { rejectWithValue }) => {
    try {
      const url = `${URL}/assessment/data/${use_case_id}`;
      const accessToken = localStorage.getItem("accessToken");

      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

export const fetchAllSprintPlans = createAsyncThunk(
  "sprint/fetchAllPlans",
  async (_, { rejectWithValue }) => {
    try {
      const url = `${URL}/sprint-planning/plans`;
      const accessToken = localStorage.getItem("accessToken");

      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

export const validateSprintConfig = createAsyncThunk(
  "sprint/validateConfig",
  async (configData, { rejectWithValue }) => {
    try {
      const url = `${URL}/sprint-planning/validate-config`;
      const accessToken = localStorage.getItem("accessToken");

      const response = await axios.post(url, configData, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

export const duplicateSprintPlan = createAsyncThunk(
  "sprint/duplicatePlan",
  async (sprint_plan_id, { rejectWithValue }) => {
    try {
      const url = `${URL}/sprint-planning/duplicate/${sprint_plan_id}`;
      const accessToken = localStorage.getItem("accessToken");

      const response = await axios.post(url, null, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

export const getSprintData = createAsyncThunk(
  'sprint/getSprintData',
  async (useCaseId, { rejectWithValue }) => {
    try {
      const url = `${URL}/sprint-planning/get_sprint_planning/${useCaseId}`;
      const response = await getService(url); // This is your custom GET wrapper
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

export const getOverallScore = createAsyncThunk(
  'sprint/getOverallScore',
  async (useCaseId, { rejectWithValue }) => {
    try {
      const url = `${URL}/sprint-planning/overall_scores/${useCaseId}`;
      const response = await getService(url); // This is your custom GET wrapper
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);