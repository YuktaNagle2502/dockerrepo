import { createSlice } from '@reduxjs/toolkit';
import { 
  fetchSupportedFormats, 
  runComplianceScan, 
  generateComplianceReport ,
  getDataCompliance
} from './dataComplieanceCheckAction';

const dataComplianceSlice = createSlice({
  name: 'dataCompliance',
  initialState: {
    supportedFormats: null,
    complianceResults: null,
    isScanning: false,
    isGeneratingReport: false,
    error: null,
    scanCompleted: false,
    reportGenerated: false,
    fetchedComplinceData: null,
    fetchedComplinceLoading: false,
    fetchedComplinceError: null,
  },
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    resetScanResults: (state) => {
      state.complianceResults = null;
      state.scanCompleted = false;
      state.reportGenerated = false;
      state.error = null;
      state.fetchedComplinceData= null;
    state.fetchedComplinceLoading= false;
    state.fetchedComplinceError= null;
    },
    setScanCompleted: (state, action) => {
      state.scanCompleted = action.payload;
    },
    setComplianceResults(state, action) {
          state.complianceResults = action.payload;
        },

  },
  extraReducers: (builder) => {
    builder
      // Fetch supported formats
      .addCase(fetchSupportedFormats.pending, (state) => {
        state.error = null;
      })
      .addCase(fetchSupportedFormats.fulfilled, (state, action) => {
        state.supportedFormats = action.payload.data;
      })
      .addCase(fetchSupportedFormats.rejected, (state, action) => {
        state.error = action.payload;
      })
      // Run compliance scan
      .addCase(runComplianceScan.pending, (state) => {
        state.isScanning = true;
        state.error = null;
        state.scanCompleted = false;
      })
      .addCase(runComplianceScan.fulfilled, (state, action) => {
        state.isScanning = false;
        state.complianceResults = action.payload.data;
        state.scanCompleted = true;
      })
      .addCase(runComplianceScan.rejected, (state, action) => {
        state.isScanning = false;
        state.error = action.payload;
        state.scanCompleted = false;
      })
      // Generate compliance report
      .addCase(generateComplianceReport.pending, (state) => {
        state.isGeneratingReport = true;
        state.error = null;
        state.reportGenerated = false;
      })
      .addCase(generateComplianceReport.fulfilled, (state, action) => {
        state.isGeneratingReport = false;
        state.reportGenerated = true;
      })
      .addCase(generateComplianceReport.rejected, (state, action) => {
        state.isGeneratingReport = false;
        state.error = action.payload;
        state.reportGenerated = false;
      })

      .addCase(getDataCompliance.pending, (state) => {
        state.fetchedComplinceLoading = true;
        state.fetchedComplinceError = null;
      })
      .addCase(getDataCompliance.fulfilled, (state, action) => {
        state.fetchedComplinceLoading = false;
        state.fetchedComplinceData = action.payload.data || action.payload;
      })
      .addCase(getDataCompliance.rejected, (state, action) => {
        state.fetchedComplinceLoading = false;
        state.fetchedComplinceError = action.payload;
      });
  },
});

export const { clearError, resetScanResults, setScanCompleted } = dataComplianceSlice.actions;
export const { setComplianceResults } = dataComplianceSlice.actions;
export default dataComplianceSlice.reducer;