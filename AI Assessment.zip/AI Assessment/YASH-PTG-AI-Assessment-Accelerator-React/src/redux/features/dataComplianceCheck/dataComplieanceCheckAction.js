import { createAsyncThunk } from '@reduxjs/toolkit';
import { getService, postService, deleteService } from '../../../Services/index';
import { URL } from '../../../util/constants';
import axios from 'axios';

// Async thunk for fetching supported formats
export const fetchSupportedFormats = createAsyncThunk(
  'dataCompliance/fetchSupportedFormats',
  async (_, { rejectWithValue }) => {
    try {
      const url = `${URL}/compliance/supported-formats`;
      const response = await getService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Run compliance scan (modified to match processUploadedFiles format)
export const runComplianceScan = createAsyncThunk(
  'dataCompliance/runComplianceScan',
  async (compliancePayload, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      
      if (compliancePayload.files && compliancePayload.files.length > 0) {
        compliancePayload.files.forEach((fileItem) => {
          formData.append('files', fileItem.originFileObj || fileItem); // support both AntD and raw File
        });
      }
      
      // Add other compliance parameters
      formData.append('use_case_id', compliancePayload.useCaseId);
      
      const url = `${URL}/compliance/analyze`;
      const accessToken = localStorage.getItem('accessToken');
      
      const response = await axios.post(url, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'authorization': `Bearer ${accessToken}`
        },
        timeout: 300000, // 5 minutes
      });
      
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Generate compliance report (modified to match generateReport format)
export const generateComplianceReport = createAsyncThunk(
  'dataCompliance/generateComplianceReport',
  async ({use_case_id, compliance_id} , { rejectWithValue }) => {
    try {
      const url = `${URL}/compliance/generate-pdf?use_case_id=${use_case_id}&compliance_id=${compliance_id}`;

      const response = await axios.post(url, null, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('accessToken')}`
        },
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);
export const getDataCompliance = createAsyncThunk(
  'dataCompliance/getDataCompliance',
  async (useCaseId, { rejectWithValue }) => {
    try {
      const url = `${URL}/compliance/get_data_compliance/${useCaseId}`;
      const response = await getService(url); // This is your custom GET wrapper
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);