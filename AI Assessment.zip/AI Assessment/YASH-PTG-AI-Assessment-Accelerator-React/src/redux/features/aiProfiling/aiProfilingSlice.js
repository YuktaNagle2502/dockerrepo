import { createSlice } from '@reduxjs/toolkit';
import { 
  fetchSupportedFormats,
  runAIProfilingAnalysis, 
  generateProfilingReport ,
  getAIProfiling
} from './aiProfilingActions';

// Initial state without static data
const initialState = {
  // Supported formats
  supportedFormats: null,
  
  // Selected use case
  selectedUseCase: null,
  
  // Profiling state
  profilingFile: null,
  profilingResults: null,
  profilingCompleted: false,
  savedProfilingReportId: null,
  fetchedProfilingData: null,
    fetchedProfilingLoading: false,
    fetchedProfilingError: null,
  // UI state
  loading: false,
  isGeneratingReport: false,
  error: null,
  reportGenerated: false,
};

// Create slice
const aiProfilingSlice = createSlice({
  name: 'aiProfiling',
  initialState,
  reducers: {
    setProfilingFile: (state, action) => {
      state.profilingFile = action.payload;
      state.error = null;
    },
    clearProfilingFile: (state) => {
      state.profilingFile = null;
    },
    clearProfilingResults: (state) => {
      state.profilingResults = null;
      state.profilingCompleted = false;
      state.savedProfilingReportId = null;
      state.reportGenerated = false;
      state.error = null;
      state.fetchedProfilingData= null;
    state.fetchedProfilingLoading= false;
    state.fetchedProfilingError= null;
    },
    setSelectedUseCase: (state, action) => {
      state.selectedUseCase = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    },
    setProfilingCompleted: (state, action) => {
      state.profilingCompleted = action.payload;
    },
    setProfilingResults(state, action) {
          state.profilingResults = action.payload;
        },
  },
  extraReducers: (builder) => {
    builder
      // Fetch supported formats
      .addCase(fetchSupportedFormats.pending, (state) => {
        state.error = null;
      })
      .addCase(fetchSupportedFormats.fulfilled, (state, action) => {
        state.supportedFormats = action.payload.data;
      })
      .addCase(fetchSupportedFormats.rejected, (state, action) => {
        state.error = action.payload;
      })
      
      // Run AI Profiling Analysis
      .addCase(runAIProfilingAnalysis.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.profilingCompleted = false;
      })
      .addCase(runAIProfilingAnalysis.fulfilled, (state, action) => {
        state.loading = false;
        state.profilingResults = action.payload.data;
        state.profilingCompleted = true;
        state.error = null;
      })
      .addCase(runAIProfilingAnalysis.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
        state.profilingCompleted = false;
      })
      
      // Generate Profiling Report
      .addCase(generateProfilingReport.pending, (state) => {
        state.isGeneratingReport = true;
        state.error = null;
        state.reportGenerated = false;
      })
      .addCase(generateProfilingReport.fulfilled, (state, action) => {
        state.isGeneratingReport = false;
        state.reportGenerated = true;
        state.error = null;
        // Note: For PDF blob response, we don't need to store the data in state
        // The blob will be handled directly in the component for download
      })
      .addCase(generateProfilingReport.rejected, (state, action) => {
        state.isGeneratingReport = false;
        state.error = action.payload;
        state.reportGenerated = false;
      })
      .addCase(getAIProfiling.pending, (state) => {
              state.fetchedProfilingLoading = true;
              state.fetchedProfilingError = null;
            })
            .addCase(getAIProfiling.fulfilled, (state, action) => {
              state.fetchedProfilingLoading = false;
              state.fetchedProfilingData = action.payload.data || action.payload;
            })
            .addCase(getAIProfiling.rejected, (state, action) => {
              state.fetchedProfilingLoading = false;
              state.fetchedProfilingError = action.payload;
            });
  }
});

// Export actions
export const {
  setProfilingFile,
  clearProfilingFile,
  clearProfilingResults,
  setSelectedUseCase,
  clearError,
  setProfilingCompleted
} = aiProfilingSlice.actions;
export const { setProfilingResults } = aiProfilingSlice.actions;

export default aiProfilingSlice.reducer;