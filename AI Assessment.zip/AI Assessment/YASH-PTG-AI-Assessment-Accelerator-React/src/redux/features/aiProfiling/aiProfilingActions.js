import { createAsyncThunk } from '@reduxjs/toolkit';
import { getService, postService, deleteService } from '../../../Services/index';
import { URL } from '../../../util/constants';
import axios from 'axios';

// Async thunk for fetching supported formats
export const fetchSupportedFormats = createAsyncThunk(
  'aiProfiling/fetchSupportedFormats',
  async (_, { rejectWithValue }) => {
    try {
      const url = `${URL}/data-profiling/supported-formats`;
      const response = await getService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Run AI profiling analysis (modified to match compliance format)
export const runAIProfilingAnalysis = createAsyncThunk(
  'aiProfiling/runAnalysis',
  async (profilingPayload, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      
      // Add file to form data
      if (profilingPayload.files && profilingPayload.files.length > 0) {
      }
      
      // Add other profiling parameters
      formData.append('use_case_id', profilingPayload.useCaseId);
      formData.append('file', profilingPayload.files[0].originFileObj);
      
      const url = `${URL}/data-profiling/analyze`;
      const accessToken = localStorage.getItem('accessToken');
      
      const response = await axios.post(url, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'authorization': `Bearer ${accessToken}`
        },
        timeout: 300000, // 5 minutes
      });
      
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Generate AI profiling report (modified to match compliance format)
export const generateProfilingReport = createAsyncThunk(
  'aiProfiling/generateReport',
  async ({use_case_id, ai_profiling_id}, { rejectWithValue }) => {
    try {
      const url = `${URL}/data-profiling/generate-pdf?use_case_id=${use_case_id}&ai_profiling_id=${ai_profiling_id}`;

      const response = await axios.post(url, null, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('accessToken')}`
        },
        timeout: 60000,
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);
export const getAIProfiling = createAsyncThunk(
  'aiProfiling/getAIProfiling',
  async (useCaseId, { rejectWithValue }) => {
    try {
      const url = `${URL}/data-profiling/get_data_profiling/${useCaseId}`;
      const response = await getService(url); // This is your custom GET wrapper
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);