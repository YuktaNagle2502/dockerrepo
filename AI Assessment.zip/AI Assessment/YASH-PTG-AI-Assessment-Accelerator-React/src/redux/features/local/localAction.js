// redux/actions/localActions.js
 
import { setProjectData, clearProjectData, updateProjectName } from "../slices/localSlice";
 
/**
 * Action to set all project data at once
 */
export const saveProjectData = (projectInfo) => (dispatch) => {
  dispatch(setProjectData(projectInfo));
};
 
/**
 * Action to clear project data (useful during logout or reset)
 */
export const removeProjectData = () => (dispatch) => {
  dispatch(clearProjectData());
};
 
/**
 * Action to update just the project name
 */
export const changeProjectName = (name) => (dispatch) => {
  dispatch(updateProjectName(name));
};
 