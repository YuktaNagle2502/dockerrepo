// redux/slices/localSlice.js
 
import { createSlice } from "@reduxjs/toolkit";
 
/**
 * Initial state to manage project-specific local data
 */
const initialState = {
  id: null,
  projectName: "",
  projectDescription: "",
  selectedProjectId: null,
  selectedSessionDetail: {
        id: null,
        session_name: '',
        description: ''
    },
    selectedUseCaseDetail: {
        id: null,
        title: '',
        description: ''
    },
};
 
const localSlice = createSlice({
  name: "local",
  initialState,
  reducers: {
    setProjectData: (state, action) => {
      const { id, projectName, projectDescription } = action.payload;
      state.id = id;
      state.projectName = projectName;
      state.projectDescription = projectDescription;
    },
    setSelectedProjectId: (state, action) => {
      state.selectedProjectId = action.payload
    },
    setSelectedSessionDetails: (state, action) => {
            const { id, session_name, description } = action.payload;
            state.selectedSessionDetail = { id, session_name, description };
        },
        setSelectedUsecaseDetail: (state, action) => {
            const { id, title, description } = action.payload;
            state.selectedUseCaseDetail = { id, title, description };
        },
 
    clearPersistData: () => initialState
,

    updateProjectName: (state, action) => {
      state.projectName = action.payload;
    },
  },
});
 
export const { setProjectData, clearPersistData, updateProjectName, setSelectedProjectId, setSelectedUsecaseDetail, setSelectedSessionDetails } = localSlice.actions;
export default localSlice.reducer;
 