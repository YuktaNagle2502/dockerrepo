import { createAsyncThunk } from '@reduxjs/toolkit';
import { getService, postService, putService, deleteService } from '../../../Services/index';
import { URL } from '../../../util/constants';
import axios from 'axios';

// Async thunk for running model evaluation
export const runModelEvaluation = createAsyncThunk(
  'evaluation/runModelEvaluation',
  async ({ models, api_keys, file, use_llm_judge,max_tokens,temperature, usecase_id }, { rejectWithValue }) => {
    try {
      console.log("aaa")
      const url = `${URL}/model-evaluation/analyze`;
      
      const formData = new FormData();
      console.log("bbb")
      // const allModels = [
      //   ...selectedModels.openai,
      //   ...selectedModels.gemini,
      //   ...selectedModels.bedrock
      // ];
      
      formData.append('models', models);
      formData.append('api_keys', api_keys);
      formData.append('file', file);
      formData.append('usecase_id', usecase_id);
     
      if (use_llm_judge !== undefined) {
        formData.append('use_llm_judge', use_llm_judge);
      }
      if (max_tokens) {
        formData.append('max_tokens', max_tokens);
      }
      if (temperature !== undefined) {
        formData.append('temperature', temperature);
      }
      const accessToken=localStorage.getItem('accessToken');

      const response = await axios.post(url, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${accessToken}`
        },
      });

      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

// Async thunk for generating reports
export const generateEvaluationReport = createAsyncThunk(
  'evaluation/generateReport',
  async ({ model_evaluation_id, use_case_id,format }, { rejectWithValue }) => {
    try {
      const accessToken=localStorage.getItem('accessToken');
      const url = `${URL}/model-evaluation/generate-pdf?model_evaluation_id=${model_evaluation_id}`;
      // const requestBody = { evaluation_results: results };
      const response = await await axios.post(url,null, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Accept': 'application/json'
        }
      });
     
      // Handle blob response for file download
      // const blob = new Blob([response.data], { type: getContentType(format) });
      // const downloadUrl = window.URL.createObjectURL(blob);
      // const link = document.createElement('a');
      // link.href = downloadUrl;
      // link.download = `evaluation_report.${format}`;
      // document.body.appendChild(link);
      // link.click();
      // document.body.removeChild(link);
      // window.URL.revokeObjectURL(downloadUrl);
     
      // return { success: true, format };
      return {
        success: response.data.success,
        data: response.data.data,
        format
      };
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

// Async thunk for importing test cases from CSV
export const importTestCasesFromCSV = createAsyncThunk(
  'evaluation/importTestCases',
  async (file, { rejectWithValue }) => {
    try {
      const url = `${URL}/test-cases/import`;
      const formData = new FormData();
      formData.append('file', file);
     
      const response = await postService(url, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
     
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data || { message: error.message }
      );
    }
  }
);

// Helper function to get content type for different formats
const getContentType = (format) => {
  switch (format) {
    case 'pdf':
      return 'application/pdf';
    case 'csv':
      return 'text/csv';
    case 'json':
      return 'application/json';
    case 'xlsx':
      return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    default:
      return 'application/octet-stream';
  }
};

export const getEvaluationData = createAsyncThunk(
  'evaluation/getEvaluationData',
  async (useCaseId, { rejectWithValue }) => {
    try {
      const url = `${URL}/model-evaluation/get_model_evaluation/${useCaseId}`;
      const response = await getService(url); // This is your custom GET wrapper
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);