import { createSlice } from '@reduxjs/toolkit';
import { 
  runModelEvaluation, 
  generateEvaluationReport, 
  importTestCasesFromCSV ,
  getEvaluationData
} from './evaluationAction';

const initialState = {
  selectedUseCase: {
    id: 2,
    session_id: 1,
    title: "Predictive Analytics Platform",
    description: "Build a comprehensive predictive analytics platform using machine learning to forecast business trends, customer behavior, and operational metrics. This will enable proactive decision-making and resource optimization.",
    aws_services: ["Amazon SageMaker", "Amazon Redshift", "AWS Glue", "Amazon QuickSight", "Amazon S3"],
    priority: "High",
    complexity: "High",
    roi_potential: "Very High",
    business_category: "Data Analytics",
    estimated_effort: "6-8 months",
    cost_estimate: "$40,000 - $60,000",
    is_selected: true,
    fetchedEvaluationData: null,
    fetchedEvaluationLoading: false,
    fetchedEvaluationError: null,
  },
  evaluationConfig: {
    use_llm_judge: true,
    max_tokens: 1000,
    temperature: 0.7
  },
  testCases: [],
  evaluationResults: {},
  evaluationCompleted: false,
  loading: false,
  error: null,
  selectedModels: {
    openai: [],
    gemini: [],
    bedrock: []
  },
  apiKeys: {},
  uploadedFile: null,
  reportGeneration: {
    loading: false,
    error: null,
    success: false
  },
  testCasesImport: {
    loading: false,
    error: null,
    success: false,
    importedCount: 0
  }
};

const evaluationSlice = createSlice({
  name: 'evaluation',
  initialState,
  reducers: {
    setSelectedUseCase: (state, action) => {
      state.selectedUseCase = action.payload;
    },
    setEvaluationConfig: (state, action) => {
      state.evaluationConfig = { ...state.evaluationConfig, ...action.payload };
    },
    setTestCases: (state, action) => {
      state.testCases = action.payload;
    },
    addTestCase: (state, action) => {
      state.testCases.push(action.payload);
    },
    removeTestCase: (state, action) => {
      state.testCases = state.testCases.filter(tc => tc.id !== action.payload);
    },
    setEvaluationResults: (state, action) => {
      state.evaluationResults = action.payload;
    },
    setEvaluationCompleted: (state, action) => {
      state.evaluationCompleted = action.payload;
    },
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
    setSelectedModels: (state, action) => {
      state.selectedModels = { ...state.selectedModels, ...action.payload };
    },
    setApiKeys: (state, action) => {
      state.apiKeys = { ...state.apiKeys, ...action.payload };
    },
    setUploadedFile: (state, action) => {
      state.uploadedFile = action.payload;
    },
    resetEvaluation: (state) => {
      state.evaluationConfig = {
        use_llm_judge: true,
        max_tokens: 1000,
        temperature: 0.7
      };
      state.testCases = [];
      state.evaluationResults = {};
      state.evaluationCompleted = false;
      state.error = null;
      state.loading = false;
    },
    clearError: (state) => {
      state.error = null;
    },
    clearReportError: (state) => {
      state.reportGeneration.error = null;
    },
    clearImportError: (state) => {
      state.testCasesImport.error = null;
    },
    resetReportGeneration: (state) => {
      state.reportGeneration = {
        loading: false,
        error: null,
        success: false
      };
    },
  
    resetTestCasesImport: (state) => {
      state.testCasesImport = {
        loading: false,
        error: null,
        success: false,
        importedCount: 0
      }
    }
  },
  extraReducers: (builder) => {
    builder
      // Handle runModelEvaluation
      .addCase(runModelEvaluation.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.evaluationCompleted = false;
      })
      .addCase(runModelEvaluation.fulfilled, (state, action) => {
        state.loading = false;
        state.error = null;
        state.evaluationResults = action.payload.data || action.payload;
        state.evaluationCompleted = true;
      })
      .addCase(runModelEvaluation.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload?.message || 'An error occurred during evaluation';
        state.evaluationCompleted = false;
      })
      
      // Handle generateEvaluationReport
      .addCase(generateEvaluationReport.pending, (state) => {
        state.reportGeneration.loading = true;
        state.reportGeneration.error = null;
        state.reportGeneration.success = false;
      })
      .addCase(generateEvaluationReport.fulfilled, (state, action) => {
        state.reportGeneration.loading = false;
        state.reportGeneration.error = null;
        state.reportGeneration.success = true;
      })
      .addCase(generateEvaluationReport.rejected, (state, action) => {
        state.reportGeneration.loading = false;
        state.reportGeneration.error = action.payload?.message || 'An error occurred during report generation';
        state.reportGeneration.success = false;
      })
      
      // Handle importTestCasesFromCSV
      .addCase(importTestCasesFromCSV.pending, (state) => {
        state.testCasesImport.loading = true;
        state.testCasesImport.error = null;
        state.testCasesImport.success = false;
      })
      .addCase(importTestCasesFromCSV.fulfilled, (state, action) => {
        state.testCasesImport.loading = false;
        state.testCasesImport.error = null;
        state.testCasesImport.success = true;
        state.testCasesImport.importedCount = action.payload?.count || 0;
        
        // Add imported test cases to existing test cases
        if (action.payload?.testCases) {
          state.testCases = [...state.testCases, ...action.payload.testCases];
        }
      })
      .addCase(importTestCasesFromCSV.rejected, (state, action) => {
        state.testCasesImport.loading = false;
        state.testCasesImport.error = action.payload?.message || 'An error occurred during test cases import';
        state.testCasesImport.success = false;
        state.testCasesImport.importedCount = 0;
      })
      .addCase(getEvaluationData.pending, (state) => {
              state.fetchedEvaluationLoading = true;
              state.fetchedEvaluationError = null;
        state.evaluationCompleted = false;

            })
            .addCase(getEvaluationData.fulfilled, (state, action) => {
              state.fetchedEvaluationLoading = false;
              state.fetchedEvaluationData = action.payload.data || action.payload;
        state.evaluationCompleted = true;

            })
            .addCase(getEvaluationData.rejected, (state, action) => {
              state.fetchedEvaluationLoading = false;
              state.fetchedEvaluationError = action.payload;
        state.evaluationCompleted = false;

            });
      ;
  }
});

export const {
  setSelectedUseCase,
  setEvaluationConfig,
  setTestCases,
  addTestCase,
  removeTestCase,
  setEvaluationResults,
  setEvaluationCompleted,
  setLoading,
  setError,
  setSelectedModels,
  setApiKeys,
  setUploadedFile,
  resetEvaluation,
  clearError,
  clearReportError,
  clearImportError,
  resetReportGeneration,
  resetTestCasesImport,
  clearEvaluationData
} = evaluationSlice.actions;

export default evaluationSlice.reducer;