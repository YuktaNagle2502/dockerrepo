import { createSlice } from '@reduxjs/toolkit';
import {
  loadPreWorkshopSessionsAndUsecases,
  createPreWorkshopSession,
  uploadQuestionnaire,
  getSessionDetails,
  generateUseCases,
  selectUseCases,
  generateReport,
  saveReportToDatabase,
  addCustomUseCase
} from './useCaseAction';

const initialState = {
  // Session management
  sessionAndUsecases: [],
  activeSession: null,
  
  // Project information
  selectedProjectId: null,
  selectedProjectName: '',
  
  // Use case data
  generatedUseCases: [],
  selectedUseCaseIds: [],
  
  // Questionnaire responses
  questionnaireResponses: [],
  
  // Reports
  generatedReports: [],
  lastGeneratedReport: null,
  
  
  // Upload state
  uploadFiles: {},
  
  // Loading states for each operation
  sessionAndUsecasesLoading: false,
  sessionCreationLoading: false,
  uploadLoading: false,
  sessionDetailsLoading: false,
  generateUseCasesLoading: false,
  selectUseCasesLoading: false,
  generateReportLoading: false,
  saveReportLoading: false,
  
addCustomUseCaseLoading: false,
addCustomUseCaseError: null,

  // Error states for each operation
  sessionAndUsecasesError: null,
  sessionCreationError: null,
  uploadError: null,
  sessionDetailsError: null,
  generateUseCasesError: null,
  selectUseCasesError: null,
  generateReportError: null,
  saveReportError: null
};

const useCaseSlice = createSlice({
  name: 'useCase',
  initialState,
  reducers: {
    // Project selection
    setSelectedProject: (state, action) => {
      state.selectedProjectId = action.payload.id;
      state.selectedProjectName = action.payload.name;
    },
    
    clearSelectedProject: (state) => {
      state.selectedProjectId = null;
      state.selectedProjectName = '';
      state.sessionAndUsecases = [];
      state.generatedUseCases = [];
      state.selectedUseCaseIds = [];
    },

    clearGeneratedUseCases: (state) => { state.generatedUseCases = []; },
    
    // setSelectedUseCases: (state, action) => {
    //   state.selectedUseCaseIds = action.payload;
    // },
    
    // Modal management
    // setResponseModal: (state, action) => {
    //   state.responseModal = action.payload;
    // },
    
    // Upload files management
    setUploadFiles: (state, action) => {
      state.uploadFiles = {
        ...state.uploadFiles,
        ...action.payload
      };
    },
    
    clearUploadFiles: (state) => {
      state.uploadFiles = {};
    },
  },
  
  extraReducers: (builder) => {
    builder
      // Load Pre-Workshop Sessions
      .addCase(loadPreWorkshopSessionsAndUsecases.pending, (state) => {
        state.sessionAndUsecasesLoading = true;
        state.sessionAndUsecasesError = null;
      })
      .addCase(loadPreWorkshopSessionsAndUsecases.fulfilled, (state, action) => {
        state.sessionAndUsecasesLoading = false;
        state.sessionAndUsecases = action.payload.data;
      })
      .addCase(loadPreWorkshopSessionsAndUsecases.rejected, (state, action) => {
        state.sessionAndUsecasesLoading = false;
        state.sessionAndUsecasesError = action.payload;
      })
      
      // Create Pre-Workshop Session
      .addCase(createPreWorkshopSession.pending, (state) => {
        state.sessionCreationLoading = true;
        state.sessionCreationError = null;
      })
      .addCase(createPreWorkshopSession.fulfilled, (state, action) => {
        state.sessionCreationLoading = false;
        const newSessionArray = action.payload.data;
        // Extract the first object from the array since API returns an array
        const newSession = newSessionArray[0];
        if (newSession) {
          state.sessionAndUsecases = [...state.sessionAndUsecases, newSession];
        }
      })
      .addCase(createPreWorkshopSession.rejected, (state, action) => {
        state.sessionCreationLoading = false;
        state.sessionCreationError = action.payload.data;
      })
      
      // Upload Questionnaire
      .addCase(uploadQuestionnaire.pending, (state) => {
        state.uploadLoading = true;
        state.uploadError = null;
      })
      .addCase(uploadQuestionnaire.fulfilled, (state, action) => {
        state.uploadLoading = false;
        
        // Update session status
        const sessionIndex = state.sessionAndUsecases.findIndex(s => s.id === action.payload.data.session_id);
        if (sessionIndex !== -1) {
          state.sessionAndUsecases[sessionIndex].status = 'questionnaire_uploaded';
          state.sessionAndUsecases[sessionIndex].questionnaire_responses = action.payload.data.responses || [];
        }
      })
      .addCase(uploadQuestionnaire.rejected, (state, action) => {
        state.uploadLoading = false;
        state.uploadError = action.payload.data;
      })
      
      // Get Session Details
      .addCase(getSessionDetails.pending, (state) => {
        state.sessionDetailsLoading = true;
        state.sessionDetailsError = null;
      })
      .addCase(getSessionDetails.fulfilled, (state, action) => {
        state.sessionDetailsLoading = false;
        state.activeSession = action.payload.data;
        state.questionnaireResponses = action.payload.data.questionnaire_responses || [];
        state.generatedUseCases = action.payload.data.generated_use_cases || [];
        
        // Extract selected use case IDs
        const selectedIds = (action.payload.data.generated_use_cases || [])
          .filter(uc => uc.is_selected)
          .map(uc => uc.id);
        state.selectedUseCaseIds = selectedIds;

        // Update sessionAndUsecases with the fetched session data
        const sessionIndex = state.sessionAndUsecases.findIndex(s => s.id === action.payload.data.id);
        if (sessionIndex !== -1) {
          state.sessionAndUsecases[sessionIndex] = action.payload.data;
        } else {
          state.sessionAndUsecases.push(action.payload.data);
        }
      })
      .addCase(getSessionDetails.rejected, (state, action) => {
        state.sessionDetailsLoading = false;
        state.sessionDetailsError = action.payload;
      })
      
      // Generate Use Cases
      .addCase(generateUseCases.pending, (state) => {
        state.generateUseCasesLoading = true;
        state.generateUseCasesError = null;
      })
      .addCase(generateUseCases.fulfilled, (state, action) => {
        state.generateUseCasesLoading = false;
        state.generatedUseCases = action.payload.use_cases || [];
        
        // Update session status
        const sessionIndex = state.sessionAndUsecases.findIndex(s => s.id === action.payload.session_id);
        if (sessionIndex !== -1) {
          state.sessionAndUsecases[sessionIndex].status = 'use_cases_generated';
        }
        
        // Reset selected use cases
        state.selectedUseCaseIds = [];
      })
      .addCase(generateUseCases.rejected, (state, action) => {
        state.generateUseCasesLoading = false;
        state.generateUseCasesError = action.payload;
      })
      
      // Select Use Cases
      .addCase(selectUseCases.pending, (state) => {
        state.selectUseCasesLoading = true;
        state.selectUseCasesError = null;
      })
      .addCase(selectUseCases.fulfilled, (state, action) => {
        state.selectUseCasesLoading = false;
        
        // Update use case selection status
        const { use_case_ids, is_selected } = action.payload;
        state.generatedUseCases.forEach(useCase => {
          if (use_case_ids.includes(useCase.id)) {
            useCase.is_selected = is_selected;
          }
        });
        
        // Update selected use case IDs
        if (is_selected) {
          use_case_ids.forEach(id => {
            if (!state.selectedUseCaseIds.includes(id)) {
              state.selectedUseCaseIds.push(id);
            }
          });
        } else {
          state.selectedUseCaseIds = state.selectedUseCaseIds.filter(
            id => !use_case_ids.includes(id)
          );
        }
      })
      .addCase(selectUseCases.rejected, (state, action) => {
        state.selectUseCasesLoading = false;
        state.selectUseCasesError = action.payload;
      })
      
      // Generate Report
      .addCase(generateReport.pending, (state) => {
        state.generateReportLoading = true;
        state.generateReportError = null;
      })
      .addCase(generateReport.fulfilled, (state, action) => {
        state.generateReportLoading = false;
        state.lastGeneratedReport = action.payload;
        console.log( " Report generated successfully!", action.payload.data)
        state.generatedReports.push({
          id: Date.now(),
          ...action.payload,
          timestamp: new Date().toISOString()
        });
      })
      .addCase(generateReport.rejected, (state, action) => {
        state.generateReportLoading = false;
        state.generateReportError = action.payload;
      })
      
      // Save Report to Database
      .addCase(saveReportToDatabase.pending, (state) => {
        state.saveReportLoading = true;
        state.saveReportError = null;
      })
      .addCase(saveReportToDatabase.fulfilled, (state, action) => {
        state.saveReportLoading = false;
        
        // Update the last generated report with saved information
        if (state.lastGeneratedReport) {
          state.lastGeneratedReport.saved = true;
          state.lastGeneratedReport.savedData = action.payload;
        }
      })
      .addCase(saveReportToDatabase.rejected, (state, action) => {
        state.saveReportLoading = false;
        state.saveReportError = action.payload;
      })

      // Add Custom Use Case
    .addCase(addCustomUseCase.pending, (state) => {
      state.addCustomUseCaseLoading = true;
      state.addCustomUseCaseError = null;
    })
    .addCase(addCustomUseCase.fulfilled, (state, action) => {
      state.addCustomUseCaseLoading = false;
      
      // Push the new use case into generatedUseCases
      state.generatedUseCases.push(action.payload.data);

      // If it belongs to a specific session, update that too
      if (state.activeSession && state.activeSession.id === action.payload.session_id) {
        state.activeSession.generated_use_cases = [
          ...(state.activeSession.generated_use_cases || []),
          action.payload
        ];
      }
    })
    .addCase(addCustomUseCase.rejected, (state, action) => {
      state.addCustomUseCaseLoading = false;
      state.addCustomUseCaseError = action.payload;
    });
  }
});

// Export actions
export const {
  setSelectedProject,
  clearSelectedProject,
  // setActiveSession,
  clearActiveSession,
  toggleUseCaseSelection,
  setSelectedUseCases,
  setResponseModal,
  setUploadFiles,
  resetUseCaseState,
  clearGeneratedUseCases
} = useCaseSlice.actions;

// Selectors
export const selectUseCaseState = (state) => state.useCase;
export const selectSessions = (state) => state.useCase.sessionAndUsecases;
export const selectActiveSession = (state) => state.useCase.activeSession;
export const selectGeneratedUseCases = (state) => state.useCase.generatedUseCases;
export const selectSelectedUseCaseIds = (state) => state.useCase.selectedUseCaseIds;
export const selectSelectedProject = (state) => ({
  id: state.useCase.selectedProjectId,
  name: state.useCase.selectedProjectName
});

// Loading selectors
export const selectSessionsLoading = (state) => state.useCase.sessionAndUsecasesLoading;
export const selectSessionCreationLoading = (state) => state.useCase.sessionCreationLoading;
export const selectUploadLoading = (state) => state.useCase.uploadLoading;
export const selectSessionDetailsLoading = (state) => state.useCase.sessionDetailsLoading;
export const selectGenerateUseCasesLoading = (state) => state.useCase.generateUseCasesLoading;
export const selectSelectUseCasesLoading = (state) => state.useCase.selectUseCasesLoading;
export const selectGenerateReportLoading = (state) => state.useCase.generateReportLoading;
export const selectSaveReportLoading = (state) => state.useCase.saveReportLoading;


// Computed selectors
export const selectSessionsWithQuestionnaire = (state) => 
  state.useCase.sessionAndUsecases.filter(s => 
    ['questionnaire_uploaded', 'use_cases_generated'].includes(s.status)
  );

export const selectSessionsWithUseCases = (state) => 
  state.useCase.sessionAndUsecases.filter(s => 
    ['use_cases_generated', 'completed'].includes(s.status)
  );

export const selectSelectedUseCases = (state) => 
  state.useCase.generatedUseCases.filter(uc => 
    state.useCase.selectedUseCaseIds.includes(uc.id)
  );

export const selectUseCaseStats = (state) => {
  const useCases = state.useCase.generatedUseCases;
  return {
    total: useCases.length,
    selected: state.useCase.selectedUseCaseIds.length,
    byPriority: {
      high: useCases.filter(uc => uc.priority === 'High').length,
      medium: useCases.filter(uc => uc.priority === 'Medium').length,
      low: useCases.filter(uc => uc.priority === 'Low').length
    },
    byComplexity: {
      high: useCases.filter(uc => uc.complexity === 'High').length,
      medium: useCases.filter(uc => uc.complexity === 'Medium').length,
      low: useCases.filter(uc => uc.complexity === 'Low').length
    }
  };
};

export const selectAddCustomUseCaseLoading = (state) => state.useCase.addCustomUseCaseLoading;
export const selectAddCustomUseCaseError = (state) => state.useCase.addCustomUseCaseError;


export default useCaseSlice.reducer;