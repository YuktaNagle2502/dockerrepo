import { createAsyncThunk } from '@reduxjs/toolkit';
import { getService, postService, putService } from '../../../Services/index';
import { URL } from '../../../util/constants';
import axios from 'axios';

// Load pre-workshop sessions for a project
export const loadPreWorkshopSessionsAndUsecases = createAsyncThunk(
  'preWorkshop/loadPreWorkshopSessionsAndUsecases',
  async (projectId, { rejectWithValue }) => {
    try {
      const url = `${URL}/pre-workshop/sessions?project_id=${projectId}`;
      const response = await getService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Create a new pre-workshop session
export const createPreWorkshopSession = createAsyncThunk(
  'preWorkshop/createPreWorkshopSession',
  async (sessionData, { rejectWithValue }) => {
    try {
      const url = `${URL}/pre-workshop/sessions`;
      const response = await postService(url, sessionData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Upload questionnaire file to session
export const uploadQuestionnaire = createAsyncThunk(
  'preWorkshop/uploadQuestionnaire',
  async ({ sessionId, file }, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      formData.append('file', file);

      const url = `${URL}/pre-workshop/sessions/${sessionId}/upload-questionnaire`;
      const accessToken=localStorage.getItem('accessToken');
      const response = await axios.post(url, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'authorization': `Bearer ${accessToken}`
        }
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Get session details with questionnaire responses
export const getSessionDetails = createAsyncThunk(
  'preWorkshop/getSessionDetails',
  async (sessionId, { rejectWithValue }) => {
    try {
      const url = `${URL}/pre-workshop/sessions/${sessionId}`;
      const response = await getService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Generate use cases for a session
export const generateUseCases = createAsyncThunk(
  'preWorkshop/generateUseCases',
  async (sessionId, { rejectWithValue }) => {
    try {
      const url = `${URL}/pre-workshop/sessions/${sessionId}/generate-use-cases`;
      const response = await postService(url);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Select or deselect use cases
export const selectUseCases = createAsyncThunk(
  'preWorkshop/selectUseCases',
  async ({ sessionId, useCaseIds, isSelected }, { rejectWithValue }) => {
    try {
      const url = `${URL}/pre-workshop/sessions/${sessionId}/use-cases/select`;
      const payload = {
        use_case_ids: useCaseIds,
        is_selected: isSelected
      };
      const response = await putService(url, payload);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Generate report for session
export const generateReport = createAsyncThunk(
  'preWorkshop/generateReport',
  async ({ sessionId, reportType }, { rejectWithValue }) => {
    try {
      const url = `${URL}/pre-workshop/sessions/${sessionId}/generate-report`;
      const payload = {
        session_id: sessionId,
        report_type: reportType
      };
      const accessToken=localStorage.getItem('accessToken');
      const response = await axios.post(url,  payload, {
         responseType: reportType === 'json' ? 'blob' : 'json', // Use 'blob' for JSON, 'json' for PDF
         headers: {
           "Content-Type": "application/json",
          'authorization': `Bearer ${accessToken}`
        }
      });
      console.log("res from generate report", response.data);
      return {
        data: response.data,
        filename: `use_cases_report_${sessionId}.${reportType}`
      };
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

// Save report to database
export const saveReportToDatabase = createAsyncThunk(
  'preWorkshop/saveReportToDatabase',
  async ({ formData }, { rejectWithValue }) => {
    try {
      const url = `${URL}/reports/save`;
      const response = await postService(url, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);

export const addCustomUseCase = createAsyncThunk(
  'preWorkshop/addCustomUseCase',
  async (data, { rejectWithValue }) => {
    try {
      const url = `${URL}/pre-workshop/sessions/${data.sessionId}/use-cases`;
      const response = await postService(url, data.useCaseData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response.data);
    }
  }
);