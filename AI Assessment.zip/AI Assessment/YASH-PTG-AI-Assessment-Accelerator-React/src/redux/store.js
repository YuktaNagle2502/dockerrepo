// redux/store.js
 
import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage"; 
import thunk from "redux-thunk";
import localReducer from "./features/local/localSlice"; 
import projectReducer from "./features/project/projectSlice"; 
import datareadinessReducer from "./features/dataReadiness/dataReadinessSlice"; 
import dataComplianceCheckReducer from "./features/dataComplianceCheck/dataComplieanceCheckSlice"; 
import aiProfilingReducer from "./features/aiProfiling/aiProfilingSlice"; 
import evaluationReducer from "./features/evaluation/evaluationSlice"; 
import reportsReducer from "./features/reports/reportsSlice"; 
import usecaseReducer from "./features/useCaseGeneration/useCaseSlice";
import sprintReducer from "./features/sprint/sprintSlice";

const rootReducer = combineReducers({
  local: localReducer,
  usecase : usecaseReducer,  // ✅ add your usecase reducer here
  projects: projectReducer, 
  readiness: datareadinessReducer,
  compliance: dataComplianceCheckReducer,
  aiProfiling: aiProfilingReducer,
  evaluation : evaluationReducer,
  reports: reportsReducer,
  sprint: sprintReducer,
});
 
const persistConfig = {
  key: "root",
  storage,
  whitelist: ["local"], // ✅ persist only the local slice
};
 
const persistedReducer = persistReducer(persistConfig, rootReducer);
 
const store = configureStore({
  reducer: persistedReducer,
  middleware: [thunk],
});
 
export const persistor = persistStore(store);
export default store;
 