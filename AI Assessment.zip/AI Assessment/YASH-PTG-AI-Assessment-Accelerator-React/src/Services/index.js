import axios from "axios";
const accessToken=localStorage.getItem('accessToken');

export const getService = async (url, params) => {
  try {
    const user_id = localStorage.getItem('userId'); 
    const accessToken=localStorage.getItem('accessToken');
    const res = await axios.get(url, {
      params,
      headers: {
        'authorization': `Bearer ${accessToken}`
      }
    });
    return res;
  } catch (error) {
    console.log("error", error);
  }
};

export const postService = async (url, body) => {
  try {
    console.log("called post api", url, body);
    const user_id = localStorage.getItem('userId'); 
    const accessToken=localStorage.getItem('accessToken');
    // const accessToken=localStorage.getItem('accessToken');
    const res = await axios.post(url, body, {
      headers: {
        "Content-Type": "application/json" ,
        'authorization': `Bearer ${accessToken}`
      }
    });
    
    console.log("res from post", res);
    return res;
  } catch (error) {
    console.log("error from post api", error);
  }
};


export const deleteService = async (url, body) => {
  try {
    const accessToken=localStorage.getItem('accessToken');
    console.log("called delete api", url, body);
    const user_id = localStorage.getItem('userId'); 
    // const accessToken=localStorage.getItem('accessToken');
    const res = await axios.delete(url, {
      data: body,
      headers: {
        'authorization': `Bearer ${accessToken}`
      }
    });
    console.log("res from delete", res);
    return res;
  } catch (error) {
    console.log("error from delete api", error);
  }
};

export const putService = async (url, body) => {
  try {
    console.log("called put api", url, body);
    const user_id = localStorage.getItem('userId'); 
    const accessToken=localStorage.getItem('accessToken');
    // const accessToken=localStorage.getItem('accessToken');
    const res = await axios.put(url, body, {
      headers: {
        'authorization': `Bearer ${accessToken}`
      }
    });
    console.log("res from put", res);
    return res;
  } catch (error) {
    console.log("error from put api", error);
  }
};
