
import ReactDOM from "react-dom/client";
import "./index.css";
import "./App.css";
import App from "./App";
import reportWebVitals from "./reportWebVitals";
import keycloak from "./util/keycloak";

keycloak.init({ onLoad: "login-required" })
  .then((authenticated) => {

    console.log("Is authenticated:", authenticated);
    if (authenticated) {
      // Access the access token from the keycloak object
      const accessToken = keycloak.token;
      localStorage.setItem("accessToken", accessToken);
      
      // Get user information
      keycloak.loadUserProfile()
        .then(profile => {
          console.log("User profile:", profile);
          localStorage.setItem("user_id", profile.id);
          localStorage.setItem("user_profile", profile);
          localStorage.setItem("user_email", profile.email);
          localStorage.setItem("user_name", profile.firstName);

          
          // Get user roles from the token
          const tokenParts = keycloak.token.split('.');
          if (tokenParts.length === 3) {
            try {
              const payload = JSON.parse(atob(tokenParts[1]));
              console.log("Token payload:", payload);
              
              // Extract roles from token - approach depends on your Keycloak setup
              // Common patterns include:
              const realmRoles = payload.realm_access?.roles || [];
              const clientRoles = payload.resource_access?.['your-client-id']?.roles || [];
              
              console.log("Realm roles:", realmRoles);
              console.log("Client roles:", clientRoles);
              
              // Store roles in localStorage for later use
              localStorage.setItem("user_roles",realmRoles);
              

            } catch (e) {
              console.error("Error parsing token for roles:", e);
            }
          }
          
          const root = ReactDOM.createRoot(document.getElementById("root"));
          root.render(<App />);
        })
        .catch(err => {
          console.error("Failed to load user profile:", err);
          
          // Try to get email and roles from token if profile loading fails
          const tokenParts = keycloak.token.split('.');
          if (tokenParts.length === 3) {
            try {
              const payload = JSON.parse(atob(tokenParts[1]));
              console.log("Parsed token:", payload);
              
              // Get email
              const email = payload.email || payload.preferred_username;
              if (email) localStorage.setItem("user_email", email);
              
              // Get roles
              const realmRoles = payload.realm_access?.roles || [];
              const clientRoles = payload.resource_access?.['your-client-id']?.roles || [];
              
              localStorage.setItem("user_roles", JSON.stringify({
                realmRoles,
                clientRoles
              }));
            } catch (e) {
              console.error("Error parsing token:", e);
            }
          }
          
          const root = ReactDOM.createRoot(document.getElementById("root"));
          root.render(<App />);
        });
      
      // Set token refresh
      // setInterval(() => {
      //   keycloak.updateToken(70)
      //     .then((refreshed) => {
      //       if (refreshed) {
      //         console.log("Token refreshed");
      //         localStorage.setItem("accessToken", keycloak.token);
              
      //         // Update roles on token refresh
      //         try {
      //           const tokenParts = keycloak.token.split('.');
      //           const payload = JSON.parse(atob(tokenParts[1]));
                
      //           const realmRoles = payload.realm_access?.roles || [];
      //           const clientRoles = payload.resource_access?.['your-client-id']?.roles || [];
                
      //           localStorage.setItem("user_roles", realmRoles);
      //         } catch (e) {
      //           console.error("Error updating roles on refresh:", e);
      //         }
      //       }
      //     })
      //     .catch(() => {
      //       console.error("Failed to refresh token");
      //       keycloak.login();
      //     });
      // }, 60000); // Check for token refresh every minute
      
    } else {
      console.log("User is not authenticated.");
      keycloak.login();
    }
  })
  .catch((error) => {
    console.error("Keycloak initialization error:", error);
  });

// If you want to start measuring performance in your app, pass a function
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
