import streamlit as st
import requests
import pandas as pd
import json
from datetime import datetime, timedelta
from typing import List, Dict, Any
from utils.auth import validate_session, get_auth_headers
from utils.config import API_ENDPOINTS, APP_CONFIG
from utils.ui_components import (
    apply_custom_css, show_success_message, show_error_message,
    show_loading_spinner, show_sidebar_navigation, show_workflow_progress,
    create_metric_card
)
from utils.report_manager import StreamlitReportManager
# Configure page
st.set_page_config(
    page_title="Sprint Planning - GenAI Assessment",
    page_icon="🏃‍♂️",
    layout="wide"
)

# Apply custom styling
apply_custom_css()

# Validate authentication
validate_session()

# Show sidebar navigation
show_sidebar_navigation()

def main():
    """Main sprint planning page"""
    
    # Header
    st.markdown(""" 
    <div class="dashboard-header">
        <h1>🏃‍♂️ Sprint Planning</h1>
        <p>Create comprehensive sprint plans for AI implementation</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Check if project is selected
    if 'selected_project_id' not in st.session_state:
        show_project_selection()
        return
    
    # Show workflow progress - Sprint Planning comes after Model Evaluation
    show_workflow_progress([1, 2, 3, 4, 5], current_stage=6)
    
    # Check previous stage completion
    if not check_previous_stage_completion():
        return
    
    # Main content
    show_sprint_planning_workflow()

def show_project_selection():
    """Show project selection if no project is selected"""
    
    st.warning("Please select a project first from the Project Management page.")
    
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        if st.button("📊 Go to Project Management", type="primary", use_container_width=True):
            st.switch_page("pages/1_📊_Project_Management.py")

def check_previous_stage_completion():
    """Check if Model Evaluation is completed"""
    
    if not st.session_state.get('evaluation_completed', False):
        st.warning("Please complete the Model Evaluation step first.")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("⚡ Go to Model Evaluation"):
                st.switch_page("pages/6_⚡_Model_Evaluation.py")
        with col2:
            # Allow skipping if evaluation results exist
            if st.session_state.get('evaluation_results'):
                if st.button("⏭️ Continue Anyway"):
                    st.session_state.evaluation_completed = True
                    st.rerun()
        return False
    return True

def show_sprint_planning_workflow():
    """Show the main sprint planning workflow"""
    
    project_id = st.session_state.selected_project_id
    project_name = st.session_state.get('selected_project_name', 'Selected Project')
    
    # Project info
    st.info(f"📊 Working on: **{project_name}**")
    
    # Tabs for different sprint planning activities
    tab1, tab2, tab3, tab4 = st.tabs(["📋 Select Use Case", "⚙️ Configure Sprint", "🚀 Generate Plan", "📊 View Plan"])
    
    with tab1:
        show_use_case_selection_tab()
    
    with tab2:
        show_sprint_configuration_tab()
    
    with tab3:
        show_generate_plan_tab()
    
    with tab4:
        show_view_plan_tab()

def show_use_case_selection_tab():
    """Show use case selection for sprint planning"""
    
    st.markdown("### 📋 Select Use Case for Sprint Planning")
    
    # Get use case from previous steps with better fallback handling
    use_case = st.session_state.get("selected_use_case_for_data")
    use_case_id = st.session_state.get('selected_use_case_id')
    
    if not use_case_id or not use_case:
        st.warning("Please complete previous steps to select a use case.")
        if st.button("📈 Go to Data Readiness Assessment"):
            st.switch_page("pages/3_📈_Data_Readiness.py")
        return
    
    st.success(f"✅ Selected Use Case: **{use_case.get('title', 'Selected Use Case') if isinstance(use_case, dict) else 'Use Case'}**")
    
    # Display use case details for sprint planning context
    if isinstance(use_case, dict):
        with st.expander("📖 Use Case Details for Sprint Planning", expanded=True):
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown(f"**Title:** {use_case.get('title', 'N/A')}")
                st.markdown(f"**Description:** {use_case.get('description', 'N/A')}")
                st.markdown(f"**Business Category:** {use_case.get('business_category', 'N/A')}")
                st.markdown(f"**Complexity:** {use_case.get('complexity', 'N/A')}")
            
            with col2:
                aws_services = use_case.get('aws_services')
                if isinstance(aws_services, list):
                    aws_services_str = ', '.join(aws_services)
                else:
                    aws_services_str = str(aws_services) if aws_services else 'N/A'
                
                st.markdown(f"**AWS Services:** {aws_services_str}")
                st.markdown(f"**Estimated Effort:** {use_case.get('estimated_effort', 'N/A')}")
                st.markdown(f"**ROI Potential:** {use_case.get('roi_potential', 'N/A')}")
                st.markdown(f"**Primary GenAI Capability:** {use_case.get('primary_genai_capability', 'N/A')}")
    
    # Show assessment summary
    st.markdown("#### 📊 Assessment Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    # Data from previous assessments
    data_readiness = st.session_state.get('assessment_results', {})
    compliance_results = st.session_state.get('compliance_results', {})
    profiling_results = st.session_state.get('profiling_results', {})
    evaluation_results = st.session_state.get('evaluation_results', {})
    
    with col1:
        readiness_score = data_readiness.get('readiness_score', 0)
        st.markdown(
            create_metric_card(
                "Data Readiness",
                f"{readiness_score:.1f}%",
                None,
                "#38a169" if readiness_score >= 80 else "#d69e2e"
            ),
            unsafe_allow_html=True
        )
    
    with col2:
        compliance_score = compliance_results.get('compliance_score', 0)
        st.markdown(
            create_metric_card(
                "Compliance Score",
                f"{compliance_score:.1f}%",
                None,
                "#38a169" if compliance_score >= 80 else "#d69e2e"
            ),
            unsafe_allow_html=True
        )
    
    with col3:
        quality_score = profiling_results.get('data_quality', {}).get('overall_quality_score', 0)
        st.markdown(
            create_metric_card(
                "Data Quality",
                f"{quality_score:.1f}%",
                None,
                "#38a169" if quality_score >= 80 else "#d69e2e"
            ),
            unsafe_allow_html=True
        )
    
    with col4:
        avg_accuracy = evaluation_results.get('collective_results', {}).get('overall_average_accuracy', 0)
        st.markdown(
            create_metric_card(
                "Model Performance",
                f"{avg_accuracy:.1f}%",
                None,
                "#38a169" if avg_accuracy >= 80 else "#d69e2e"
            ),
            unsafe_allow_html=True
        )
        
# def show_sprint_configuration_tab():
#     """Show sprint configuration tab"""
    
#     st.markdown("### ⚙️ Configure Sprint Parameters")
    
#     use_case_id = st.session_state.get('selected_use_case_id')
#     if not use_case_id:
#         st.warning("Please select a use case first.")
#         return
    
#     # Sprint configuration form
#     with st.form("sprint_config"):
#         st.markdown("#### 🏗️ Project Configuration")
        
#         col1, col2 = st.columns(2)
        
#         with col1:
#             project_type = st.selectbox(
#                 "Project Type",
#                 ["Web Application", "Mobile Application", "API Service", "Data Pipeline", "Machine Learning Model", "Chatbot", "Other"],
#                 index=0,
#                 help="Type of project being developed"
#             )
            
#             development_methodology = st.selectbox(
#                 "Development Methodology",
#                 ["Agile/Scrum", "Kanban", "Hybrid", "Waterfall"],
#                 index=0,
#                 help="Development methodology to follow"
#             )
            
#             team_size = st.number_input(
#                 "Team Size",
#                 min_value=1,
#                 max_value=20,
#                 value=5,
#                 help="Number of team members"
#             )
        
#         with col2:
#             sprint_duration = st.selectbox(
#                 "Sprint Duration",
#                 ["1 week", "2 weeks", "3 weeks", "4 weeks"],
#                 index=1,
#                 help="Duration of each sprint"
#             )
            
#             total_sprints = st.number_input(
#                 "Total Sprints",
#                 min_value=1,
#                 max_value=20,
#                 value=6,
#                 help="Total number of sprints planned"
#             )
            
#             start_date = st.date_input(
#                 "Project Start Date",
#                 value=datetime.now().date(),
#                 help="When the project will start"
#             )
        
#         st.markdown("#### 👥 Team Composition")
        
#         col1, col2, col3 = st.columns(3)
        
#         with col1:
#             frontend_devs = st.number_input("Frontend Developers", min_value=0, max_value=10, value=1)
#             backend_devs = st.number_input("Backend Developers", min_value=0, max_value=10, value=2)
            
#         with col2:
#             ml_engineers = st.number_input("ML Engineers", min_value=0, max_value=10, value=1)
#             data_scientists = st.number_input("Data Scientists", min_value=0, max_value=10, value=1)
        
#         with col3:
#             devops_engineers = st.number_input("DevOps Engineers", min_value=0, max_value=10, value=1)
#             qa_engineers = st.number_input("QA Engineers", min_value=0, max_value=10, value=1)
        
#         st.markdown("#### 🎯 Project Priorities")
        
#         priorities = st.multiselect(
#             "Select project priorities:",
#             ["Time to Market", "Cost Optimization", "Performance", "Scalability", "Security", "User Experience", "Compliance"],
#             default=["Time to Market", "Performance", "Security"]
#         )
        
#         include_testing = st.checkbox("Include comprehensive testing phases", value=True)
#         include_deployment = st.checkbox("Include deployment and monitoring setup", value=True)
#         include_documentation = st.checkbox("Include documentation tasks", value=True)
        
#         if st.form_submit_button("💾 Save Configuration", type="primary"):
#             sprint_config = {
#                 'use_case_id': use_case_id,
#                 'project_type': project_type,
#                 'development_methodology': development_methodology,
#                 'team_size': team_size,
#                 'sprint_duration': sprint_duration,
#                 'total_sprints': total_sprints,
#                 'start_date': start_date.isoformat(),
#                 'team_composition': {
#                     'frontend_developers': frontend_devs,
#                     'backend_developers': backend_devs,
#                     'ml_engineers': ml_engineers,
#                     'data_scientists': data_scientists,
#                     'devops_engineers': devops_engineers,
#                     'qa_engineers': qa_engineers
#                 },
#                 'priorities': priorities,
#                 'include_testing': include_testing,
#                 'include_deployment': include_deployment,
#                 'include_documentation': include_documentation
#             }
#             if 'sprint_config' not in st.session_state:
#                 st.session_state.sprint_config = sprint_config
#             show_success_message("Sprint configuration saved successfully!")

def show_sprint_configuration_tab():
    """Show sprint configuration tab"""
    
    st.markdown("### ⚙️ Configure Sprint Parameters")
    
    use_case_id = st.session_state.get('selected_use_case_id')
    if not use_case_id:
        st.warning("Please select a use case first.")
        return
    
    # Initialize sprint_config if it doesn't exist - BEFORE any widgets
    if 'sprint_config' not in st.session_state:
        st.session_state.sprint_config = {}
    
    # Get existing config for default values
    existing_config = st.session_state.get('sprint_config', {})
    
    # Sprint configuration form
    with st.form("sprint_config_form"):  # Changed form key to avoid conflicts
        st.markdown("#### 🏗️ Project Configuration")
        
        col1, col2 = st.columns(2)
        
        with col1:
            project_type = st.selectbox(
                "Project Type",
                ["Web Application", "Mobile Application", "API Service", "Data Pipeline", "Machine Learning Model", "Chatbot", "Other"],
                index=["Web Application", "Mobile Application", "API Service", "Data Pipeline", "Machine Learning Model", "Chatbot", "Other"].index(existing_config.get('project_type', 'Web Application')) if existing_config.get('project_type') in ["Web Application", "Mobile Application", "API Service", "Data Pipeline", "Machine Learning Model", "Chatbot", "Other"] else 0,
                help="Type of project being developed"
            )
            
            development_methodology = st.selectbox(
                "Development Methodology",
                ["Agile/Scrum", "Kanban", "Hybrid", "Waterfall"],
                index=["Agile/Scrum", "Kanban", "Hybrid", "Waterfall"].index(existing_config.get('development_methodology', 'Agile/Scrum')) if existing_config.get('development_methodology') in ["Agile/Scrum", "Kanban", "Hybrid", "Waterfall"] else 0,
                help="Development methodology to follow"
            )
            
            team_size = st.number_input(
                "Team Size",
                min_value=1,
                max_value=20,
                value=existing_config.get('team_size', 5),
                help="Number of team members"
            )
        
        with col2:
            sprint_duration = st.selectbox(
                "Sprint Duration",
                ["1 week", "2 weeks", "3 weeks", "4 weeks"],
                index=["1 week", "2 weeks", "3 weeks", "4 weeks"].index(existing_config.get('sprint_duration', '2 weeks')) if existing_config.get('sprint_duration') in ["1 week", "2 weeks", "3 weeks", "4 weeks"] else 1,
                help="Duration of each sprint"
            )
            
            total_sprints = st.number_input(
                "Total Sprints",
                min_value=1,
                max_value=20,
                value=existing_config.get('total_sprints', 6),
                help="Total number of sprints planned"
            )
            
            # Handle start_date conversion
            default_start_date = datetime.now().date()
            if existing_config.get('start_date'):
                try:
                    if isinstance(existing_config['start_date'], str):
                        default_start_date = datetime.fromisoformat(existing_config['start_date']).date()
                    else:
                        default_start_date = existing_config['start_date']
                except:
                    default_start_date = datetime.now().date()
            
            start_date = st.date_input(
                "Project Start Date",
                value=default_start_date,
                help="When the project will start"
            )
        
        st.markdown("#### 👥 Team Composition")
        
        col1, col2, col3 = st.columns(3)
        
        # Get existing team composition
        existing_team = existing_config.get('team_composition', {})
        
        with col1:
            frontend_devs = st.number_input("Frontend Developers", min_value=0, max_value=10, value=existing_team.get('frontend_developers', 1))
            backend_devs = st.number_input("Backend Developers", min_value=0, max_value=10, value=existing_team.get('backend_developers', 2))
            
        with col2:
            ml_engineers = st.number_input("ML Engineers", min_value=0, max_value=10, value=existing_team.get('ml_engineers', 1))
            data_scientists = st.number_input("Data Scientists", min_value=0, max_value=10, value=existing_team.get('data_scientists', 1))
        
        with col3:
            devops_engineers = st.number_input("DevOps Engineers", min_value=0, max_value=10, value=existing_team.get('devops_engineers', 1))
            qa_engineers = st.number_input("QA Engineers", min_value=0, max_value=10, value=existing_team.get('qa_engineers', 1))
        
        st.markdown("#### 🎯 Project Priorities")
        
        priorities = st.multiselect(
            "Select project priorities:",
            ["Time to Market", "Cost Optimization", "Performance", "Scalability", "Security", "User Experience", "Compliance"],
            default=existing_config.get('priorities', ["Time to Market", "Performance", "Security"])
        )
        
        include_testing = st.checkbox("Include comprehensive testing phases", value=existing_config.get('include_testing', True))
        include_deployment = st.checkbox("Include deployment and monitoring setup", value=existing_config.get('include_deployment', True))
        include_documentation = st.checkbox("Include documentation tasks", value=existing_config.get('include_documentation', True))
        
        if st.form_submit_button("💾 Save Configuration", type="primary"):
            sprint_config = {
                'use_case_id': use_case_id,
                'project_type': project_type,
                'development_methodology': development_methodology,
                'team_size': team_size,
                'sprint_duration': sprint_duration,
                'total_sprints': total_sprints,
                'start_date': start_date.isoformat(),
                'team_composition': {
                    'frontend_developers': frontend_devs,
                    'backend_developers': backend_devs,
                    'ml_engineers': ml_engineers,
                    'data_scientists': data_scientists,
                    'devops_engineers': devops_engineers,
                    'qa_engineers': qa_engineers
                },
                'priorities': priorities,
                'include_testing': include_testing,
                'include_deployment': include_deployment,
                'include_documentation': include_documentation
            }
            
            # FIXED: Direct assignment instead of conditional
            st.session_state.sprint_config = sprint_config
            show_success_message("Sprint configuration saved successfully!")
            st.rerun()

def show_generate_plan_tab():
    """Show sprint plan generation tab"""
    
    st.markdown("### 🚀 Generate Sprint Plan")
    
    if 'sprint_config' not in st.session_state:
        st.warning("Please configure sprint parameters first.")
        return
    
    config = st.session_state.sprint_config
    use_case = st.session_state.get("selected_use_case_for_data")
    
    # Show configuration summary
    st.markdown("#### 📋 Configuration Summary")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown(f"**Project Type:** {config.get('project_type', 'Not specified')}")
        st.markdown(f"**Team Size:** {config.get('team_size', 0)} members")
        st.markdown(f"**Methodology:** {config.get('development_methodology', 'Not specified')}")

    with col2:
        st.markdown(f"**Sprint Duration:** {config.get('sprint_duration', 'Not specified')}")
        st.markdown(f"**Total Sprints:** {config.get('total_sprints', 0)}")
        st.markdown(f"**Start Date:** {config.get('start_date', 'Not specified')}")

    with col3:
        priorities = config.get('priorities', [])
        st.markdown(f"**Priorities:** {', '.join(priorities) if priorities else 'None selected'}")
        st.markdown(f"**Include Testing:** {'Yes' if config.get('include_testing', False) else 'No'}")
        st.markdown(f"**Include Deployment:** {'Yes' if config.get('include_deployment', False) else 'No'}")
    
    # Advanced options
    with st.expander("🔧 Advanced Generation Options"):
        col1, col2 = st.columns(2)
        
        with col1:
            include_risk_assessment = st.checkbox("Include risk assessment", value=True)
            include_budget_estimation = st.checkbox("Include budget estimation", value=True)
            include_resource_allocation = st.checkbox("Include detailed resource allocation", value=True)
        
        with col2:
            include_dependencies = st.checkbox("Include dependency mapping", value=True)
            include_milestones = st.checkbox("Include milestone tracking", value=True)
            detailed_tasks = st.checkbox("Generate detailed task breakdown", value=True)
    
    # Generate sprint plan
    if st.button("🚀 Generate Sprint Plan", type="primary", use_container_width=True):
        generation_options = {
            'include_risk_assessment': include_risk_assessment,
            'include_budget_estimation': include_budget_estimation,
            'include_resource_allocation': include_resource_allocation,
            'include_dependencies': include_dependencies,
            'include_milestones': include_milestones,
            'detailed_tasks': detailed_tasks
        }
        
        generate_sprint_plan(config, generation_options)

def generate_sprint_plan(config: Dict, options: Dict):
    """Generate sprint plan using backend API"""
    
    try:
        with show_loading_spinner("Generating comprehensive sprint plan... This may take a few minutes."):
            
            headers = get_auth_headers()
            headers['Content-Type'] = 'application/json'
            
            # Prepare request data
            request_data = {
                **config,
                'generation_options': options,
                'assessment_context': {
                    'data_readiness': st.session_state.get('assessment_results', {}),
                    'compliance_results': st.session_state.get('compliance_results', {}),
                    'profiling_results': st.session_state.get('profiling_results', {}),
                    'evaluation_results': st.session_state.get('evaluation_results', {})
                }
            }
            
            if 'Content-Type' in headers:
                del headers['Content-Type']

            # Prepare form data
            form_data = {
                'use_case_id': str(config['use_case_id']),
                'project_type': config['project_type'],
                'sprint_duration': config['sprint_duration'],
                'total_sprints': str(config['total_sprints']),
                'team_size': str(config['team_size'])
            }

            response = requests.post(
                f"{API_ENDPOINTS['reports']['save'].replace('/reports/save', '')}/sprint-planning/generate",
                data=form_data,  # ✅ Use form data instead of JSON
                headers=headers,
                timeout=300
            )
            
            if response.status_code == 200:
                sprint_plan = response.json()
                st.session_state.sprint_plan = sprint_plan
                
                # Save the sprint plan report
                save_sprint_plan_report(sprint_plan, config['use_case_id'])
                
                show_success_message("Sprint plan generated successfully!")
            else:
                show_error_message(f"Failed to generate sprint plan: {response.text}")
        
    except requests.exceptions.Timeout:
        show_error_message("Sprint plan generation timed out. Please try again.")
    except Exception as e:
        show_error_message(f"Error generating sprint plan: {str(e)}")

def save_sprint_plan_report(sprint_plan, use_case_id):
    """Save sprint plan report to database"""
    try:
        import json
        
        # Convert sprint plan to JSON bytes for database storage
        report_content = json.dumps(sprint_plan, indent=2, default=str).encode('utf-8')
        
        # Get use case details for report name
        use_case = st.session_state.get('selected_use_case_for_data', {})
        use_case_title = use_case.get('title', 'Sprint Planning') if isinstance(use_case, dict) else 'Sprint Planning'
        
        # Save using StreamlitReportManager
        report_data = StreamlitReportManager.save_report_to_database(
            file_content=report_content,
            module_name="sprint_planning",
            module_entity_id=use_case_id,
            report_name=f"Sprint Planning Report - {use_case_title}",
            report_type="json",
            filename=f"sprint_plan_{use_case_id}.json"
        )
        
        if report_data:
            st.session_state.saved_sprint_plan_report_id = report_data.get('id')
            # FIXED: Mark sprint planning as completed
            st.session_state.sprint_planning_completed = True
        
    except Exception as e:
        st.warning(f"Report saved locally but failed to save to database: {str(e)}")

def show_view_plan_tab():
    """Show generated sprint plan"""
    
    st.markdown("### 📊 Sprint Plan Overview")
    
    if 'sprint_plan' not in st.session_state:
        st.info("No sprint plan generated yet. Please generate a plan first.")
        return
    
    plan = st.session_state.sprint_plan
    
    # Plan overview
    st.markdown("#### 📈 Plan Overview")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(
            create_metric_card(
                "Total Sprints",
                str(plan.get('total_sprints', 0)),
                None,
                "#3182ce"
            ),
            unsafe_allow_html=True
        )
    
    with col2:
        # FIXED: Use estimated_duration instead of total_duration_weeks
        duration = plan.get('estimated_duration', '0 weeks')
        st.markdown(
            create_metric_card(
                "Total Duration",
                duration,
                None,
                "#38a169"
            ),
            unsafe_allow_html=True
        )
    
    with col3:
        # FIXED: Use estimated_cost and handle string format
        estimated_cost = plan.get('estimated_cost', '$0')
        st.markdown(
            create_metric_card(
                "Estimated Cost",
                estimated_cost,
                None,
                "#d69e2e"
            ),
            unsafe_allow_html=True
        )
    
    with col4:
        # FIXED: Get team_size from generated_content.team_structure
        team_size = plan.get('generated_content', {}).get('team_structure', {}).get('total_developers', 0)
        st.markdown(
            create_metric_card(
                "Team Size",
                f"{team_size} members",
                None,
                "#9f7aea"
            ),
            unsafe_allow_html=True
        )
    
    # Sprint breakdown
    st.markdown("#### 🏃‍♂️ Sprint Breakdown")
    
    # FIXED: Correct path to sprints
    sprints = plan.get('generated_content', {}).get('sprint_plan', {}).get('sprints', [])
    
    if sprints:
        # Sprint overview table
        sprint_overview = []
        for sprint in sprints:
            # FIXED: Handle missing fields gracefully
            sprint_overview.append({
                'Sprint': sprint.get('sprint_number', ''),
                'Goals': ', '.join(sprint.get('goals', [])),  # Show goals instead of name
                'Duration': sprint.get('duration', ''),
                'Tasks': len(sprint.get('tasks', [])),
                'Deliverables': len(sprint.get('deliverables', []))
            })
        
        sprint_df = pd.DataFrame(sprint_overview)
        st.dataframe(sprint_df, use_container_width=True)
        
        # Detailed sprint view
        st.markdown("#### 🔍 Detailed Sprint View")
        
        selected_sprint_idx = st.selectbox(
            "Select sprint to view details:",
            range(len(sprints)),
            format_func=lambda i: f"Sprint {sprints[i].get('sprint_number', i+1)}"
        )
        
        if selected_sprint_idx is not None:
            selected_sprint = sprints[selected_sprint_idx]
            
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.markdown(f"**Sprint {selected_sprint.get('sprint_number', '')}**")
                
                # FIXED: Display goals instead of single goal
                goals = selected_sprint.get('goals', [])
                if goals:
                    st.markdown("**Goals:**")
                    for goal in goals:
                        st.markdown(f"• {goal}")
                
                # Sprint tasks
                st.markdown("**Tasks:**")
                tasks = selected_sprint.get('tasks', [])
                for task in tasks:
                    # FIXED: Use correct field names from JSON
                    task_name = task.get('task', '')  # Not 'name'
                    assignee = task.get('assignee', '')
                    effort = task.get('effort', '')  # String format like "8 hours"
                    st.markdown(f"• **{task_name}** ({assignee}) - {effort}")
            
            with col2:
                st.markdown("**Sprint Metrics:**")
                st.metric("Duration", selected_sprint.get('duration', ''))
                st.metric("Total Tasks", len(tasks))
                
                # FIXED: Calculate total effort from string format
                total_effort = 0
                for task in tasks:
                    effort_str = task.get('effort', '0 hours')
                    try:
                        # Extract number from "X hours" format
                        effort_num = int(effort_str.split()[0]) if effort_str.split() else 0
                        total_effort += effort_num
                    except (ValueError, IndexError):
                        pass
                
                st.metric("Total Effort", f"{total_effort}h")
                
                # Sprint deliverables
                deliverables = selected_sprint.get('deliverables', [])
                if deliverables:
                    st.markdown("**Deliverables:**")
                    for deliverable in deliverables:
                        st.markdown(f"• {deliverable}")
    
    # Budget breakdown
    # FIXED: Correct path to budget
    budget = plan.get('generated_content', {}).get('budget_estimation', {})
    if budget:
        st.markdown("#### 💰 Budget Breakdown")
        
        budget_items = []
        for category, amount in budget.items():
            # FIXED: Handle string amounts and skip non-cost items
            if isinstance(amount, str) and ('$' in amount or 'cost' in category.lower()):
                budget_items.append({
                    'Category': category.replace('_', ' ').title(),
                    'Amount': amount
                })
        
        if budget_items:
            budget_df = pd.DataFrame(budget_items)
            st.dataframe(budget_df, use_container_width=True)
    
    # Risk assessment
    # FIXED: Correct path to risks
    risks = plan.get('generated_content', {}).get('risks_and_mitigation', [])
    if risks:
        st.markdown("#### ⚠️ Risk Assessment")
        
        for risk in risks:
            with st.expander(f"🔴 {risk.get('risk', 'Risk')} - {risk.get('impact', 'Unknown')} Impact"):
                st.markdown(f"**Impact:** {risk.get('impact', 'Unknown')}")
                st.markdown(f"**Mitigation:** {risk.get('mitigation', 'No mitigation strategy')}")
    
    # Remove milestones section since it's not in the JSON structure
    
    # Export options (keep unchanged)
    st.markdown("---")
    st.markdown("#### 📤 Export Sprint Plan")
    
    col1, col2, col3 = st.columns([1, 1, 1])
    
    with col1:
        if st.button("📄 Generate PDF Plan", type="primary", use_container_width=True):
            generate_sprint_plan_report('pdf')
    
    with col2:
        if st.button("📊 Export Excel Plan", use_container_width=True):
            generate_sprint_plan_report('excel')
    
    with col3:
        if st.button("📋 Export JSON Data", use_container_width=True):
            generate_sprint_plan_report('json')

def generate_sprint_plan_report(format_type: str):
    """Generate sprint plan report"""
    
    try:
        plan = st.session_state.sprint_plan
        use_case_id = st.session_state.get('selected_use_case_id')
        use_case = st.session_state.get('selected_use_case_for_data', {})
        
        with show_loading_spinner(f"Generating {format_type.upper()} sprint plan report..."):
            
            if format_type == 'pdf':
                headers = get_auth_headers()
                if 'Content-Type' in headers:
                    del headers['Content-Type']
                
                # FIXED: Send as form data, not JSON
                form_data = {
                    'content': json.dumps(plan.get('generated_content', {})),  # Convert plan to JSON string
                    'title': 'Sprint Planning Document',
                    'include_charts': 'true'
                }
                
                response = requests.post(
                    f"{API_ENDPOINTS['reports']['save'].replace('/reports/save', '')}/sprint-planning/generate-pdf",
                    data=form_data,  # ✅ Use data instead of json
                    headers=headers
                )
                
                if response.status_code == 200:
                    report_content = response.content
                    filename = f"sprint_plan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                    
                    # FIXED: Save to database using StreamlitReportManager
                    if use_case_id:
                        use_case_title = use_case.get('title', 'Sprint Planning') if isinstance(use_case, dict) else 'Sprint Planning'
                        StreamlitReportManager.save_report_to_database(
                            file_content=report_content,
                            module_name="sprint_planning",
                            module_entity_id=use_case_id,
                            report_name=f"Sprint Planning PDF Report - {use_case_title}",
                            report_type="pdf",
                            filename=filename
                        )
                    
                    st.download_button(
                        label="📥 Download PDF Plan",
                        data=report_content,
                        file_name=filename,
                        mime="application/pdf",
                        use_container_width=True
                    )
                    show_success_message("PDF sprint plan generated and saved successfully!")
                else:
                    show_error_message(f"Failed to generate PDF: {response.text}")
            
            elif format_type == 'excel':
                # Generate Excel report locally
                import io
                output = io.BytesIO()
                
                with pd.ExcelWriter(output, engine='openpyxl') as writer:
                    # Sprint overview
                    sprints = plan.get('sprint_plan', {}).get('sprints', [])
                    if sprints:
                        sprint_overview = []
                        for sprint in sprints:
                            sprint_overview.append({
                                'Sprint': sprint.get('sprint_number', ''),
                                'Name': sprint.get('name', ''),
                                'Duration': sprint.get('duration', ''),
                                'Start Date': sprint.get('start_date', ''),
                                'End Date': sprint.get('end_date', ''),
                                'Tasks': len(sprint.get('tasks', [])),
                                'Focus': sprint.get('focus_area', '')
                            })
                        
                        sprint_df = pd.DataFrame(sprint_overview)
                        sprint_df.to_excel(writer, sheet_name='Sprint Overview', index=False)
                    
                    # Detailed tasks
                    all_tasks = []
                    for sprint in sprints:
                        sprint_num = sprint.get('sprint_number', '')
                        for task in sprint.get('tasks', []):
                            all_tasks.append({
                                'Sprint': sprint_num,
                                'Task': task.get('name', ''),
                                'Assignee': task.get('assignee', ''),
                                'Effort (hours)': task.get('effort_hours', 0),
                                'Description': task.get('description', '')
                            })
                    
                    if all_tasks:
                        tasks_df = pd.DataFrame(all_tasks)
                        tasks_df.to_excel(writer, sheet_name='Detailed Tasks', index=False)
                    
                    # Budget
                    budget = plan.get('budget_estimation', {})
                    if budget:
                        budget_items = []
                        for category, amount in budget.items():
                            if category != 'total_cost' and isinstance(amount, (int, float)):
                                budget_items.append({
                                    'Category': category.replace('_', ' ').title(),
                                    'Amount': amount
                                })
                        
                        if budget_items:
                            budget_df = pd.DataFrame(budget_items)
                            budget_df.to_excel(writer, sheet_name='Budget', index=False)
                
                report_content = output.getvalue()
                filename = f"sprint_plan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
                
                # FIXED: Save to database using StreamlitReportManager
                if use_case_id:
                    use_case_title = use_case.get('title', 'Sprint Planning') if isinstance(use_case, dict) else 'Sprint Planning'
                    StreamlitReportManager.save_report_to_database(
                        file_content=report_content,
                        module_name="sprint_planning",
                        module_entity_id=use_case_id,
                        report_name=f"Sprint Planning Excel Report - {use_case_title}",
                        report_type="xlsx",
                        filename=filename
                    )
                
                st.download_button(
                    label="📥 Download Excel Plan",
                    data=report_content,
                    file_name=filename,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True
                )
                show_success_message("Excel sprint plan generated and saved successfully!")
            
            else:  # json
                report_content = json.dumps(plan, indent=2, default=str).encode()
                filename = f"sprint_plan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                
                # FIXED: Save to database using StreamlitReportManager
                if use_case_id:
                    use_case_title = use_case.get('title', 'Sprint Planning') if isinstance(use_case, dict) else 'Sprint Planning'
                    StreamlitReportManager.save_report_to_database(
                        file_content=report_content,
                        module_name="sprint_planning",
                        module_entity_id=use_case_id,
                        report_name=f"Sprint Planning JSON Data - {use_case_title}",
                        report_type="json",
                        filename=filename
                    )
                
                st.download_button(
                    label="📥 Download JSON Data",
                    data=report_content,
                    file_name=filename,
                    mime="application/json",
                    use_container_width=True
                )
                show_success_message("JSON sprint plan data exported and saved successfully!")
        
    except Exception as e:
        show_error_message(f"Error generating report: {str(e)}")

if __name__ == "__main__":
    main()