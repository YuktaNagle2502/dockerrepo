import streamlit as st
import requests
import pandas as pd
import json
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from utils.auth import validate_session, get_auth_headers
from utils.config import API_ENDPOINTS, APP_CONFIG
from utils.ui_components import (
    apply_custom_css, show_success_message, show_error_message,
    show_loading_spinner, show_sidebar_navigation, create_metric_card
)

# Configure page
st.set_page_config(
    page_title="Reports Dashboard - GenAI Assessment",
    page_icon="📊",
    layout="wide"
)

# Apply custom styling
apply_custom_css()

# Validate authentication
validate_session()

# Show sidebar navigation
show_sidebar_navigation()

def main():
    """Main reports dashboard page"""
    
    # Header
    st.markdown("""
    <div class="dashboard-header">
        <h1>📊 Reports Dashboard</h1>
        <p>View, manage, and download all generated reports</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Check if project is selected
    if 'selected_project_id' not in st.session_state:
        show_project_selection()
        return
    
    # Main content
    show_reports_dashboard()

def show_project_selection():
    """Show project selection if no project is selected"""
    
    st.warning("Please select a project first from the Project Management page.")
    
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        if st.button("📊 Go to Project Management", type="primary", use_container_width=True):
            st.switch_page("pages/1_📊_Project_Management.py")

def show_reports_dashboard():
    """Show the main reports dashboard"""
    
    project_id = st.session_state.selected_project_id
    project_name = st.session_state.get('selected_project_name', 'Selected Project')
    
    # Project info
    st.info(f"📊 Reports for: **{project_name}**")
    
    # Load reports for the project
    reports = load_project_reports(project_id)
    
    # Dashboard tabs
    tab1, tab2, tab3, tab4 = st.tabs(["📈 Overview", "📋 All Reports", "🔍 Search & Filter", "📊 Analytics"])
    
    with tab1:
        show_overview_tab(reports)
    
    with tab2:
        show_all_reports_tab(reports)
    
    with tab3:
        show_search_filter_tab(reports)
    
    with tab4:
        show_analytics_tab(reports)

@st.cache_data(ttl=300)
def load_project_reports(project_id: int) -> List[Dict[str, Any]]:
    """Load all reports for a project"""
    try:
        headers = get_auth_headers()
        response = requests.get(
            API_ENDPOINTS['reports']['project'].format(project_id=project_id),
            headers=headers
        )
        print(response.json())
        if response.status_code == 200:
            return response.json()
        else:
            st.error("Failed to load reports from database")
            return []
    except Exception as e:
        st.error(f"Error loading reports: {str(e)}")
        return []

def show_download_button(report_id: str, key_suffix: str = ""):
    """Show download button that actually works"""
    
    if st.button("📥", key=f"download_{report_id}_{key_suffix}", help="Download Report"):
        try:
            # Get the report details
            headers = get_auth_headers()
            project_id = st.session_state.selected_project_id
            reports = load_project_reports(project_id)
            
            target_report = None
            for report in reports:
                if str(report.get('id')) == str(report_id):
                    target_report = report
                    break
            
            if not target_report:
                show_error_message("Report not found")
                return
            
            report_uuid = target_report.get('report_uuid')
            if not report_uuid:
                show_error_message("Report UUID not found")
                return
            
            # Download the file
            with st.spinner("Downloading report..."):
                response = requests.get(
                    API_ENDPOINTS['reports']['download'].format(report_uuid=report_uuid),
                    headers=headers
                )
                
                if response.status_code == 200:
                    # Get filename
                    filename = f"report_{report_id}.{target_report.get('report_type', 'pdf')}"
                    content_disposition = response.headers.get('Content-Disposition')
                    
                    if content_disposition:
                        import re
                        filename_match = re.search(r'filename="([^"]*)"', content_disposition)
                        if filename_match:
                            filename = filename_match.group(1)
                    
                    # Get MIME type
                    content_type = response.headers.get('Content-Type', 'application/octet-stream')
                    
                    # Create download button that actually downloads
                    st.download_button(
                        label=f"📥 Download {filename}",
                        data=response.content,
                        file_name=filename,
                        mime=content_type,
                        key=f"actual_download_{report_id}_{key_suffix}",
                        use_container_width=True
                    )
                    
                else:
                    show_error_message(f"Failed to download report: {response.text}")
        
        except Exception as e:
            show_error_message(f"Error downloading report: {str(e)}")

def show_overview_tab(reports: List[Dict[str, Any]]):
    """Show overview of reports"""
    
    st.markdown("#### 📈 Reports Overview")
    
    if not reports:
        st.info("No reports found for this project. Complete the assessment workflow to generate reports.")
        return
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    total_reports = len(reports)
    report_types = set(report.get('report_type', 'unknown') for report in reports)
    
    # Calculate recent reports (last 7 days)
    recent_reports = 0
    for report in reports:
        created_at = report.get('created_at', '')
        if created_at:
            try:
                report_date = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                if report_date >= datetime.now() - timedelta(days=7):
                    recent_reports += 1
            except:
                pass
    
    with col1:
        st.markdown(
            create_metric_card(
                "Total Reports",
                str(total_reports),
                None,
                "#3182ce"
            ),
            unsafe_allow_html=True
        )
    
    with col2:
        st.markdown(
            create_metric_card(
                "Report Types",
                str(len(report_types)),
                None,
                "#38a169"
            ),
            unsafe_allow_html=True
        )
    
    with col3:
        st.markdown(
            create_metric_card(
                "Recent Reports",
                str(recent_reports),
                None,
                "#d69e2e"
            ),
            unsafe_allow_html=True
        )
    
    with col4:
        # Find latest report
        latest_report = None
        if reports:
            latest_report = max(reports, key=lambda r: r.get('created_at', ''))
        
        latest_date = "None"
        if latest_report and latest_report.get('created_at'):
            try:
                latest_date = datetime.fromisoformat(latest_report['created_at'].replace('Z', '+00:00')).strftime('%m/%d')
            except:
                pass
        
        st.markdown(
            create_metric_card(
                "Latest Report",
                latest_date,
                None,
                "#9f7aea"
            ),
            unsafe_allow_html=True
        )
    
    # Report type breakdown
    st.markdown("#### 📊 Report Type Breakdown")
    
    type_counts = {}
    for report in reports:
        report_type = report.get('report_type', 'unknown')
        type_counts[report_type] = type_counts.get(report_type, 0) + 1
    
    if type_counts:
        # Create a nice visualization
        type_df = pd.DataFrame([
            {'Report Type': rtype.replace('_', ' ').title(), 'Count': count}
            for rtype, count in type_counts.items()
        ])
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.bar_chart(type_df.set_index('Report Type'))
        
        with col2:
            st.dataframe(type_df, use_container_width=True)
    
    # Recent reports
    st.markdown("#### 🕒 Recent Reports")
    
    # Sort reports by creation date (most recent first)
    sorted_reports = sorted(reports, key=lambda r: r.get('created_at', ''), reverse=True)
    recent_reports_list = sorted_reports[:5]  # Show top 5 recent reports
    
    if recent_reports_list:
        for report in recent_reports_list:
            with st.expander(f"📄 {report.get('report_title', 'Untitled Report')}"):
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.markdown(f"**Type:** {report.get('report_type', 'Unknown').replace('_', ' ').title()}")
                    st.markdown(f"**Module:** {report.get('module_name', 'Unknown').replace('_', ' ').title()}")
                    
                    created_at = report.get('created_at', '')
                    if created_at:
                        try:
                            formatted_date = datetime.fromisoformat(created_at.replace('Z', '+00:00')).strftime('%Y-%m-%d %H:%M')
                            st.markdown(f"**Created:** {formatted_date}")
                        except:
                            st.markdown(f"**Created:** {created_at}")
                
                with col2:
                    show_download_button(report.get('id'), "overview")
                    
                    if st.button("👁️ View", key=f"view_{report.get('id')}_overview"):
                        view_report_details(report)

def show_all_reports_tab(reports: List[Dict[str, Any]]):
    """Show all reports in a table format"""
    
    st.markdown("#### 📋 All Reports")
    
    if not reports:
        st.info("No reports found for this project.")
        return
    
    # Create reports dataframe
    reports_data = []
    for report in reports:
        created_at = report.get('created_at', '')
        formatted_date = created_at
        if created_at:
            try:
                formatted_date = datetime.fromisoformat(created_at.replace('Z', '+00:00')).strftime('%Y-%m-%d %H:%M')
            except:
                pass
        
        reports_data.append({
            'ID': report.get('id', ''),
            'Title': report.get('report_title', 'Untitled'),
            'Type': report.get('report_type', 'unknown').replace('_', ' ').title(),
            'Module': report.get('module_name', 'unknown').replace('_', ' ').title(),
            'Created': formatted_date,
            'report_obj': report  # Keep original object for actions
        })
    
    # Sort by creation date (most recent first)
    reports_data.sort(key=lambda x: x['Created'], reverse=True)
    
    # Display table
    for i, report_data in enumerate(reports_data):
        with st.container():
            col1, col2, col3, col4, col5, col6 = st.columns([1, 3, 2, 2, 2, 2])
            
            with col1:
                st.write(f"**{report_data['ID']}**")
            
            with col2:
                st.write(report_data['Title'])
            
            with col3:
                st.write(report_data['Type'])
            
            with col4:
                st.write(report_data['Module'])
            
            with col5:
                st.write(report_data['Created'])
            
            with col6:
                col_a, col_b, col_c = st.columns(3)
                
                with col_a:
                    if st.button("👁️", key=f"view_all_{i}", help="View Details"):
                        view_report_details(report_data['report_obj'])
                
                with col_b:
                    show_download_button(report_data['ID'], f"all_{i}")
                
                with col_c:
                    if st.button("🗑️", key=f"delete_all_{i}", help="Delete"):
                        delete_report(report_data['ID'])
            
            st.divider()

def show_search_filter_tab(reports: List[Dict[str, Any]]):
    """Show search and filter functionality"""
    
    st.markdown("#### 🔍 Search & Filter Reports")
    
    if not reports:
        st.info("No reports found for this project.")
        return
    
    # Search and filter controls
    col1, col2, col3 = st.columns(3)
    
    with col1:
        search_term = st.text_input(
            "🔍 Search reports",
            placeholder="Search by title, type, or module..."
        )
    
    with col2:
        # Get unique report types
        report_types = sorted(set(report.get('report_type', 'unknown') for report in reports))
        selected_types = st.multiselect(
            "📊 Filter by Type",
            report_types,
            format_func=lambda x: x.replace('_', ' ').title()
        )
    
    with col3:
        # Get unique modules
        modules = sorted(set(report.get('module_name', 'unknown') for report in reports))
        selected_modules = st.multiselect(
            "🔧 Filter by Module",
            modules,
            format_func=lambda x: x.replace('_', ' ').title()
        )
    
    # Date range filter
    col1, col2 = st.columns(2)
    
    with col1:
        start_date = st.date_input(
            "📅 From Date",
            value=datetime.now().date() - timedelta(days=30)
        )
    
    with col2:
        end_date = st.date_input(
            "📅 To Date",
            value=datetime.now().date()
        )
    
    # Apply filters
    filtered_reports = filter_reports(reports, search_term, selected_types, selected_modules, start_date, end_date)
    
    st.markdown(f"#### 📋 Filtered Results ({len(filtered_reports)} reports)")
    
    if filtered_reports:
        # Display filtered results
        for i, report in enumerate(filtered_reports):
            with st.expander(f"📄 {report.get('report_title', 'Untitled Report')}"):
                col1, col2, col3 = st.columns([2, 2, 1])
                
                with col1:
                    st.markdown(f"**Type:** {report.get('report_type', 'Unknown').replace('_', ' ').title()}")
                    st.markdown(f"**Module:** {report.get('module_name', 'Unknown').replace('_', ' ').title()}")
                
                with col2:
                    created_at = report.get('created_at', '')
                    if created_at:
                        try:
                            formatted_date = datetime.fromisoformat(created_at.replace('Z', '+00:00')).strftime('%Y-%m-%d %H:%M')
                            st.markdown(f"**Created:** {formatted_date}")
                        except:
                            st.markdown(f"**Created:** {created_at}")
                    
                    st.markdown(f"**ID:** {report.get('id', 'N/A')}")
                
                with col3:
                    show_download_button(report.get('id'), f"filter_{i}")
                    
                    if st.button("👁️ View Details", key=f"filter_view_{i}"):
                        view_report_details(report)
    else:
        st.info("No reports match the current filters.")

def filter_reports(reports: List[Dict], search_term: str, types: List[str], modules: List[str], 
                  start_date: datetime.date, end_date: datetime.date) -> List[Dict]:
    """Filter reports based on criteria"""
    
    filtered = reports.copy()
    
    # Search term filter
    if search_term:
        search_lower = search_term.lower()
        filtered = [r for r in filtered if 
                   search_lower in r.get('report_title', '').lower() or
                   search_lower in r.get('report_type', '').lower() or
                   search_lower in r.get('module_name', '').lower()]
    
    # Type filter
    if types:
        filtered = [r for r in filtered if r.get('report_type') in types]
    
    # Module filter
    if modules:
        filtered = [r for r in filtered if r.get('module_name') in modules]
    
    # Date filter
    date_filtered = []
    for report in filtered:
        created_at = report.get('created_at', '')
        if created_at:
            try:
                report_date = datetime.fromisoformat(created_at.replace('Z', '+00:00')).date()
                if start_date <= report_date <= end_date:
                    date_filtered.append(report)
            except:
                # Include reports with invalid dates
                date_filtered.append(report)
        else:
            # Include reports without creation date
            date_filtered.append(report)
    
    return date_filtered

def show_analytics_tab(reports: List[Dict[str, Any]]):
    """Show analytics and insights about reports"""
    
    st.markdown("#### 📊 Reports Analytics")
    
    if not reports:
        st.info("No reports found for analytics.")
        return
    
    # Time-based analytics
    st.markdown("##### 📈 Report Generation Timeline")
    
    # Create timeline data
    timeline_data = []
    for report in reports:
        created_at = report.get('created_at', '')
        if created_at:
            try:
                report_date = datetime.fromisoformat(created_at.replace('Z', '+00:00')).date()
                timeline_data.append({
                    'Date': report_date,
                    'Report Type': report.get('report_type', 'unknown').replace('_', ' ').title(),
                    'Count': 1
                })
            except:
                pass
    
    if timeline_data:
        timeline_df = pd.DataFrame(timeline_data)
        
        # Group by date and count
        daily_counts = timeline_df.groupby('Date')['Count'].sum().reset_index()
        daily_counts = daily_counts.sort_values('Date')
        
        if len(daily_counts) > 1:
            st.line_chart(daily_counts.set_index('Date'))
        else:
            st.info("Not enough data points for timeline visualization.")
    
    # Module completion analysis
    st.markdown("##### 🔧 Module Completion Analysis")
    
    module_counts = {}
    for report in reports:
        module = report.get('module_name', 'unknown')
        module_counts[module] = module_counts.get(module, 0) + 1
    
    if module_counts:
        module_df = pd.DataFrame([
            {'Module': module.replace('_', ' ').title(), 'Reports': count}
            for module, count in module_counts.items()
        ])
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.bar_chart(module_df.set_index('Module'))
        
        with col2:
            st.dataframe(module_df, use_container_width=True)
    
    # Assessment progress
    st.markdown("##### 🎯 Assessment Progress")
    
    expected_modules = [
        'use_case_generation',
        'data_readiness', 
        'data_compliance',
        'ai_profiling',
        'model_evaluation',
        'sprint_planning'
    ]
    
    completed_modules = set(report.get('module_name') for report in reports)
    
    progress_data = []
    for module in expected_modules:
        status = "Completed" if module in completed_modules else "Pending"
        progress_data.append({
            'Module': module.replace('_', ' ').title(),
            'Status': status
        })
    
    progress_df = pd.DataFrame(progress_data)
    
    # Calculate completion percentage
    completion_percentage = (len(completed_modules) / len(expected_modules)) * 100
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown(
            create_metric_card(
                "Assessment Progress",
                f"{completion_percentage:.1f}%",
                None,
                "#38a169" if completion_percentage == 100 else "#d69e2e"
            ),
            unsafe_allow_html=True
        )
    
    with col2:
        st.dataframe(progress_df, use_container_width=True)
    
    # Report size analytics
    st.markdown("##### 📏 Report Analytics")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        # Average reports per day
        if timeline_data:
            date_range = (datetime.now().date() - min(r['Date'] for r in timeline_data)).days + 1
            avg_per_day = len(reports) / max(date_range, 1)
            st.metric("Avg Reports/Day", f"{avg_per_day:.1f}")
    
    with col2:
        # Most active module
        if module_counts:
            most_active = max(module_counts.items(), key=lambda x: x[1])
            st.metric("Most Active Module", most_active[0].replace('_', ' ').title())
    
    with col3:
        # Latest activity
        if reports:
            latest_report = max(reports, key=lambda r: r.get('created_at', ''))
            latest_date = latest_report.get('created_at', '')
            if latest_date:
                try:
                    days_ago = (datetime.now() - datetime.fromisoformat(latest_date.replace('Z', '+00:00'))).days
                    st.metric("Days Since Last Report", days_ago)
                except:
                    st.metric("Days Since Last Report", "Unknown")

def view_report_details(report: Dict[str, Any]):
    """Show detailed view of a report"""
    
    st.session_state.selected_report_for_view = report
    
    # Create a modal-like experience using expander
    with st.expander(f"📄 Report Details: {report.get('report_title', 'Untitled')}", expanded=True):
        
        # Basic info
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown(f"**Report ID:** {report.get('id', 'N/A')}")
            st.markdown(f"**Title:** {report.get('report_title', 'N/A')}")
            st.markdown(f"**Type:** {report.get('report_type', 'N/A').replace('_', ' ').title()}")
            st.markdown(f"**Module:** {report.get('module_name', 'N/A').replace('_', ' ').title()}")
        
        with col2:
            created_at = report.get('created_at', '')
            if created_at:
                try:
                    formatted_date = datetime.fromisoformat(created_at.replace('Z', '+00:00')).strftime('%Y-%m-%d %H:%M:%S')
                    st.markdown(f"**Created:** {formatted_date}")
                except:
                    st.markdown(f"**Created:** {created_at}")
            
            st.markdown(f"**Project ID:** {report.get('project_id', 'N/A')}")
            st.markdown(f"**Module Entity ID:** {report.get('module_entity_id', 'N/A')}")
        
        # Report data preview
        report_data = report.get('report_data', {})
        if report_data:
            st.markdown("**Report Data Preview:**")
            
            # Show key metrics if available
            if isinstance(report_data, dict):
                # Try to extract key information based on report type
                report_type = report.get('report_type', '')
                
                if report_type == 'data_readiness':
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Readiness Score", f"{report_data.get('readiness_score', 0):.1f}%")
                    with col2:
                        st.metric("Overall Status", report_data.get('overall_status', 'Unknown').replace('_', ' ').title())
                    with col3:
                        issues_count = len(report_data.get('data_quality_issues', []))
                        st.metric("Quality Issues", issues_count)
                
                elif report_type == 'data_compliance':
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Compliance Score", f"{report_data.get('compliance_score', 0):.1f}%")
                    with col2:
                        st.metric("Risk Level", report_data.get('risk_level', 'Unknown'))
                    with col3:
                        recommendations_count = len(report_data.get('recommendations', []))
                        st.metric("Recommendations", recommendations_count)
                
                elif report_type == 'ai_profiling':
                    data_quality = report_data.get('data_quality', {})
                    ml_insights = report_data.get('ml_insights', {})
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Quality Score", f"{data_quality.get('overall_quality_score', 0):.1f}%")
                    with col2:
                        st.metric("ML Ready", "Yes" if ml_insights.get('suitable_for_ml', False) else "No")
                    with col3:
                        basic_info = report_data.get('basic_info', {})
                        st.metric("Files Processed", basic_info.get('total_files', 0))
                
                elif report_type == 'model_evaluation':
                    collective = report_data.get('collective_results', {})
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Models Tested", collective.get('total_models', 0))
                    with col2:
                        st.metric("Test Cases", collective.get('total_test_cases', 0))
                    with col3:
                        st.metric("Avg Accuracy", f"{collective.get('overall_average_accuracy', 0):.1f}%")
                
                elif report_type == 'sprint_planning':
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Sprints", report_data.get('total_sprints', 0))
                    with col2:
                        st.metric("Duration", f"{report_data.get('total_duration_weeks', 0)} weeks")
                    with col3:
                        budget = report_data.get('budget_estimation', {})
                        st.metric("Est. Cost", f"${budget.get('total_cost', 0):,.0f}")
            
            # Raw data viewer
            with st.expander("🔍 View Raw Report Data"):
                st.json(report_data)
        
        # Action buttons
        col1, col2, col3 = st.columns(3)
        
        with col1:
            show_download_button(report.get('id'), "modal")
        
        with col2:
            if st.button("📋 Copy Report ID", key="modal_copy"):
                st.code(f"{report.get('id')}")  # This displays the ID for copying
                st.success("Report ID displayed above!")
        
        with col3:
            if st.button("🗑️ Delete Report", key="modal_delete", type="secondary"):
                if st.button("⚠️ Confirm Delete", key="modal_confirm_delete"):
                    delete_report(report.get('id'))

def delete_report(report_id: str):
    """Delete a report"""
    
    try:
        # Get the report UUID from the report ID
        headers = get_auth_headers()
        
        # Find the report by ID to get its UUID
        project_id = st.session_state.selected_project_id
        reports = load_project_reports(project_id)
        
        target_report = None
        for report in reports:
            if str(report.get('id')) == str(report_id):
                target_report = report
                break
        
        if not target_report:
            show_error_message("Report not found")
            return
        
        report_uuid = target_report.get('report_uuid')
        if not report_uuid:
            show_error_message("Report UUID not found")
            return
        
        # Use report_uuid in the delete URL
        response = requests.delete(
            API_ENDPOINTS['reports']['delete'].format(report_uuid=report_uuid),
            headers=headers
        )
        
        if response.status_code == 200:
            show_success_message("Report deleted successfully!")
            # Clear cache to refresh the reports list
            st.cache_data.clear()
            st.rerun()
        else:
            show_error_message(f"Failed to delete report: {response.text}")
    
    except Exception as e:
        show_error_message(f"Error deleting report: {str(e)}")

# Bulk operations
def show_bulk_operations():
    """Show bulk operations for reports"""
    
    st.markdown("#### 🔧 Bulk Operations")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📥 Download All Reports", use_container_width=True):
            download_all_reports()
    
    with col2:
        if st.button("📊 Generate Summary Report", use_container_width=True):
            generate_summary_report()
    
    with col3:
        if st.button("🗑️ Clear Old Reports", use_container_width=True):
            clear_old_reports()

def download_all_reports():
    """Download all reports as a ZIP file"""
    
    project_id = st.session_state.selected_project_id
    
    try:
        with show_loading_spinner("Preparing all reports for download..."):
            headers = get_auth_headers()
            response = requests.get(
                f"{API_ENDPOINTS['reports']['project_reports'].format(project_id=project_id)}/download-all",
                headers=headers
            )
            
            if response.status_code == 200:
                filename = f"all_reports_project_{project_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
                
                st.download_button(
                    label="📥 Download All Reports (ZIP)",
                    data=response.content,
                    file_name=filename,
                    mime="application/zip",
                    use_container_width=True
                )
                
                show_success_message("All reports ZIP file ready for download!")
            else:
                show_error_message(f"Failed to create reports archive: {response.text}")
    
    except Exception as e:
        show_error_message(f"Error creating reports archive: {str(e)}")

def generate_summary_report():
    """Generate a summary report of all assessments"""
    
    project_id = st.session_state.selected_project_id
    
    try:
        with show_loading_spinner("Generating summary report..."):
            headers = get_auth_headers()
            response = requests.post(
                f"{API_ENDPOINTS['reports']['project_reports'].format(project_id=project_id)}/summary",
                headers=headers
            )
            
            if response.status_code == 200:
                filename = f"summary_report_project_{project_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                
                st.download_button(
                    label="📥 Download Summary Report",
                    data=response.content,
                    file_name=filename,
                    mime="application/pdf",
                    use_container_width=True
                )
                
                show_success_message("Summary report generated successfully!")
            else:
                show_error_message(f"Failed to generate summary report: {response.text}")
    
    except Exception as e:
        show_error_message(f"Error generating summary report: {str(e)}")

def clear_old_reports():
    """Clear reports older than specified days"""
    
    days = st.number_input(
        "Delete reports older than (days):",
        min_value=1,
        max_value=365,
        value=30
    )
    
    if st.button("⚠️ Confirm Deletion"):
        project_id = st.session_state.selected_project_id
        
        try:
            headers = get_auth_headers()
            response = requests.delete(
                f"{API_ENDPOINTS['reports']['project_reports'].format(project_id=project_id)}/cleanup",
                json={'days_old': days},
                headers=headers
            )
            
            if response.status_code == 200:
                deleted_count = response.json().get('deleted_count', 0)
                show_success_message(f"Deleted {deleted_count} old reports successfully!")
                st.cache_data.clear()
                st.rerun()
            else:
                show_error_message(f"Failed to delete old reports: {response.text}")
        
        except Exception as e:
            show_error_message(f"Error deleting old reports: {str(e)}")

if __name__ == "__main__":
    main()