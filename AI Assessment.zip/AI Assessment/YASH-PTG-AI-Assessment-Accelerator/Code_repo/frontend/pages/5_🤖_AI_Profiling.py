import streamlit as st
import requests
import pandas as pd
import io
import json
from typing import List, Dict, Any
from utils.auth import validate_session, get_auth_headers
from utils.config import API_ENDPOINTS, APP_CONFIG
from utils.ui_components import (
    apply_custom_css, show_success_message, show_error_message,
    create_file_uploader, show_loading_spinner, show_sidebar_navigation,
    show_workflow_progress, create_metric_card
)
from utils.report_manager import StreamlitReportManager

# Configure page
st.set_page_config(
    page_title="AI Profiling - GenAI Assessment",
    page_icon="🤖",
    layout="wide"
)

# Apply custom styling
apply_custom_css()

# Validate authentication
validate_session()

# Show sidebar navigation
show_sidebar_navigation()

def main():
    """Main AI profiling page"""
    
    # Header
    st.markdown("""
    <div class="dashboard-header">
        <h1>🤖 AI Profiling</h1>
        <p>Perform detailed AI model profiling and data analysis</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Check if project is selected
    if 'selected_project_id' not in st.session_state:
        show_project_selection()
        return
    
    # Show workflow progress
    show_workflow_progress([1, 2, 3], current_stage=4)
    
    # Check previous stage completion
    if not check_previous_stage_completion():
        return
    
    # Main content
    show_ai_profiling_workflow()

def show_project_selection():
    """Show project selection if no project is selected"""
    
    st.warning("Please select a project first from the Project Management page.")
    
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        if st.button("📊 Go to Project Management", type="primary", use_container_width=True):
            st.switch_page("pages/1_📊_Project_Management.py")

def check_previous_stage_completion():
    """Check if previous stages are completed"""
    
    # Check if compliance is completed
    if not st.session_state.get('compliance_completed', False):
        st.warning("Please complete the Data Compliance Check step first.")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🔒 Go to Data Compliance"):
                st.switch_page("pages/4_🔒_Data_Compliance.py")
        with col2:
            # Allow skipping if compliance results exist
            if st.session_state.get('compliance_results'):
                if st.button("⏭️ Continue Anyway"):
                    st.session_state.compliance_completed = True
                    st.rerun()
        return False
    return True

def show_ai_profiling_workflow():
    """Show the main AI profiling workflow"""
    
    project_id = st.session_state.selected_project_id
    project_name = st.session_state.get('selected_project_name', 'Selected Project')
    
    # Project info
    st.info(f"📊 Working on: **{project_name}**")
    
    # Tabs for different profiling activities
    tab1, tab2, tab3, tab4 = st.tabs(["📤 Upload Data", "🔍 Profile Data", "📊 Analysis Results", "📋 Generate Report"])
    
    with tab1:
        show_data_upload_tab()
    
    with tab2:
        show_profiling_tab()
    
    with tab3:
        show_analysis_results_tab()
    
    with tab4:
        show_report_generation_tab()

def show_data_upload_tab():
    """Show data upload tab for profiling"""
    
    st.markdown("### 📤 Upload Data for AI Profiling")
    
    # Get use case information
    use_case = st.session_state.get("selected_use_case_for_data")
    use_case_id = st.session_state.get('selected_use_case_id')
    
    if not use_case_id:
        st.warning("Please complete previous steps to select a use case.")
        if st.button("📈 Go to Data Readiness Assessment"):
            st.switch_page("pages/3_📈_Data_Readiness.py")
        return
    
    st.info(f"Profiling data for Use Case: **{use_case.get('title', 'Selected Use Case') if isinstance(use_case, dict) else 'Use Case'}**")
    
    # Data upload section
    st.markdown("#### 📁 Select Data Files")
    
    uploaded_file = st.file_uploader(
        "Upload your data file for AI profiling analysis",
        type=['csv', 'txt', 'xlsx', 'xls', 'json', 'parquet'],
        help="Supported formats: CSV, TXT, Excel, JSON, Parquet",
        key="profiling_data_file"
    )
    
    if uploaded_file:
        st.markdown("#### 📋 File Information")
        
        file_size_mb = len(uploaded_file.getvalue()) / (1024 * 1024)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Filename", uploaded_file.name)
        with col2:
            st.metric("File Type", uploaded_file.type)
        with col3:
            st.metric("Size", f"{file_size_mb:.2f} MB")
        
        # Show file preview for CSV files
        if uploaded_file.name.endswith('.csv'):
            show_csv_preview(uploaded_file)
        
        # Store file in session state
        st.session_state.profiling_file = uploaded_file
        st.session_state.profiling_file_ready = True
        
        # Process file
        if st.button("🚀 Analyze File with AI Profiling", type="primary", use_container_width=True):
            run_ai_profiling_analysis(uploaded_file, use_case_id)
    else:
        # Clear file state if no file uploaded
        if 'profiling_file' in st.session_state:
            del st.session_state.profiling_file
        if 'profiling_file_ready' in st.session_state:
            del st.session_state.profiling_file_ready

def show_csv_preview(csv_file):
    """Show preview of CSV file with enhanced information"""
    try:
        # Reset file pointer
        csv_file.seek(0)
        df = pd.read_csv(csv_file)
        
        # Basic info
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Rows", f"{df.shape[0]:,}")
        with col2:
            st.metric("Total Columns", df.shape[1])
        with col3:
            memory_usage = df.memory_usage(deep=True).sum() / 1024
            st.metric("Memory Usage", f"{memory_usage:.1f} KB")
        with col4:
            missing_pct = (df.isnull().sum().sum() / (df.shape[0] * df.shape[1]) * 100)
            st.metric("Missing Data", f"{missing_pct:.1f}%")
        
        # Data preview
        st.markdown("**First 10 rows:**")
        st.dataframe(df.head(10), use_container_width=True)
        
        # Column information
        with st.expander("📊 Column Information"):
            col_info = []
            for col in df.columns:
                col_info.append({
                    'Column': col,
                    'Data Type': str(df[col].dtype),
                    'Non-Null Count': f"{df[col].count():,}",
                    'Null Count': f"{df[col].isnull().sum():,}",
                    'Unique Values': f"{df[col].nunique():,}",
                })
            
            col_df = pd.DataFrame(col_info)
            st.dataframe(col_df, use_container_width=True)
                    
    except Exception as e:
        st.error(f"Error previewing CSV: {str(e)}")

def run_ai_profiling_analysis(uploaded_file, use_case_id):
    """Run AI profiling analysis using backend API"""
    
    try:
        with show_loading_spinner("Running AI profiling analysis... This may take several minutes."):
            
            # Reset file pointer
            uploaded_file.seek(0)
            
            # Prepare multipart form data
            files = {
                "file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type or "application/octet-stream")
            }
            
            headers = get_auth_headers()
            # Remove Content-Type to let requests handle multipart
            if 'Content-Type' in headers:
                del headers['Content-Type']
            
            # Call the AI profiling API
            endpoint = f"{API_ENDPOINTS['ai_profiling']['analyze']}"
            
            response = requests.post(
                endpoint,
                files=files,
                headers=headers,
                timeout=300  # 5 minute timeout
            )
            
            if response.status_code == 200:
                profiling_results = response.json()
                st.session_state.profiling_results = profiling_results
                
                # Save the profiling report to database
                save_profiling_report(profiling_results, use_case_id)
                
                # Mark profiling as completed
                st.session_state.profiling_completed = True
                
                show_success_message("AI profiling analysis completed successfully!")
                st.rerun()  # Refresh to show results
            else:
                error_detail = "Unknown error"
                try:
                    error_data = response.json()
                    error_detail = error_data.get('detail', response.text)
                except:
                    error_detail = response.text
                
                show_error_message(f"Profiling analysis failed: {error_detail}")
        
    except requests.exceptions.Timeout:
        show_error_message("Analysis timed out. Please try with a smaller file.")
    except Exception as e:
        show_error_message(f"Error running profiling analysis: {str(e)}")

def save_profiling_report(results, use_case_id):
    """Save profiling report to database"""
    try:
        # Convert results to JSON for database storage
        report_content = json.dumps(results, indent=2, default=str).encode('utf-8')
        
        # Get use case details for report name
        use_case = st.session_state.get('selected_use_case_for_data', {})
        use_case_title = use_case.get('title', 'AI Profiling') if isinstance(use_case, dict) else 'AI Profiling'
        
        # Save using StreamlitReportManager
        report_data = StreamlitReportManager.save_report_to_database(
            file_content=report_content,
            module_name="ai_profiling",
            module_entity_id=use_case_id,
            report_name=f"AI Profiling Report - {use_case_title}",
            report_type="json",
            filename=f"ai_profiling_{use_case_id}.json"
        )
        
        if report_data:
            st.session_state.saved_profiling_report_id = report_data.get('id')
        
    except Exception as e:
        st.warning(f"Report saved locally but failed to save to database: {str(e)}")

def show_profiling_tab():
    """Show profiling analysis tab"""
    
    st.markdown("### 🔍 AI Profiling Analysis")
    
    if 'profiling_results' not in st.session_state:
        st.warning("Please upload and analyze a data file first.")
        return
    
    results = st.session_state.profiling_results
    
    # Extract data from API response
    file_analyzed = results.get('file_analyzed', 'Unknown')
    data_quality_score = results.get('data_quality_score', 0)
    analysis_type = results.get('analysis_type', 'basic')
    generated_at = results.get('generated_at', '')
    
    # Quick statistics
    st.markdown("#### 📊 Analysis Overview")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(
            create_metric_card(
                "File Analyzed", 
                file_analyzed, 
                None, 
                "#3182ce"
            ),
            unsafe_allow_html=True
        )
    
    with col2:
        st.markdown(
            create_metric_card(
                "Quality Score", 
                f"{data_quality_score:.1f}%", 
                None, 
                "#38a169" if data_quality_score >= 80 else "#d69e2e" if data_quality_score >= 60 else "#e53e3e"
            ),
            unsafe_allow_html=True
        )
    
    with col3:
        st.markdown(
            create_metric_card(
                "Analysis Type", 
                analysis_type.title(), 
                None, 
                "#9f7aea"
            ),
            unsafe_allow_html=True
        )
    
    with col4:
        analysis_status = "✅ Complete"
        st.markdown(
            create_metric_card(
                "Status", 
                analysis_status, 
                None, 
                "#38a169"
            ),
            unsafe_allow_html=True
        )
    
    # Show generated content preview
    st.markdown("#### 📄 Analysis Report Preview")
    
    generated_content = results.get('generated_content', '')
    if generated_content:
        # Show first 500 characters as preview
        preview_content = generated_content[:500] + "..." if len(generated_content) > 500 else generated_content
        st.markdown(preview_content)
        
        if len(generated_content) > 500:
            with st.expander("📖 View Full Report"):
                st.markdown(generated_content)
    else:
        st.info("No detailed analysis content available.")
    
    # Analysis timestamp
    if generated_at:
        st.info(f"Analysis completed at: {generated_at}")

def show_analysis_results_tab():
    """Show analysis results"""
    
    st.markdown("### 📊 Detailed Analysis Results")
    
    if 'profiling_results' not in st.session_state:
        st.info("No profiling results available. Please run the profiling analysis first.")
        return
    
    results = st.session_state.profiling_results
    
    # Show full analysis content
    generated_content = results.get('generated_content', '')
    if generated_content:
        st.markdown("#### 📄 Complete Analysis Report")
        st.markdown(generated_content)
    else:
        st.warning("No analysis content available.")
    
    # Show analysis metadata
    st.markdown("#### 📋 Analysis Metadata")
    
    metadata = {
        "File Analyzed": results.get('file_analyzed', 'N/A'),
        "Analysis Type": results.get('analysis_type', 'N/A'),
        "Data Quality Score": f"{results.get('data_quality_score', 0):.2f}%",
        "Generated At": results.get('generated_at', 'N/A')
    }
    
    metadata_df = pd.DataFrame(list(metadata.items()), columns=['Property', 'Value'])
    st.dataframe(metadata_df, use_container_width=True, hide_index=True)

def show_report_generation_tab():
    """Show report generation tab"""
    
    st.markdown("### 📋 Generate AI Profiling Report")
    
    if 'profiling_results' not in st.session_state:
        st.info("Please complete the profiling analysis first.")
        return
    
    results = st.session_state.profiling_results
    
    # Report configuration
    st.markdown("#### ⚙️ Report Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        include_metadata = st.checkbox("Include analysis metadata", value=True)
        include_full_content = st.checkbox("Include full analysis content", value=True)
    
    with col2:
        report_format = st.selectbox(
            "Report format:",
            ["PDF", "JSON", "Markdown"]
        )
    
    # Show content preview
    st.markdown("#### 👁️ Report Content Preview")
    
    generated_content = results.get('generated_content', '')
    if generated_content:
        # Show truncated preview
        preview_lines = generated_content.split('\n')[:10]
        preview_content = '\n'.join(preview_lines)
        if len(preview_lines) == 10:
            preview_content += "\n\n... (content truncated for preview)"
        
        st.markdown(preview_content)
    
    # Generate report
    st.markdown("#### 📤 Generate Report")
    
    col1, col2, col3 = st.columns([1, 1, 1])
    
    with col1:
        if st.button("📄 Generate PDF Report", type="primary", use_container_width=True):
            generate_profiling_report('pdf', include_metadata, include_full_content)
    
    with col2:
        if st.button("📊 Export JSON Data", use_container_width=True):
            generate_profiling_report('json', include_metadata, include_full_content)
    
    with col3:
        if st.button("📝 Export Markdown", use_container_width=True):
            generate_profiling_report('markdown', include_metadata, include_full_content)

# FIXED: Update generate_profiling_report function for PDF generation
def generate_profiling_report(format_type: str, include_metadata: bool, include_full_content: bool):
    """Generate AI profiling report"""
    
    try:
        results = st.session_state.profiling_results
        use_case_id = st.session_state.get('selected_use_case_id')
        use_case = st.session_state.get('selected_use_case_for_data', {})
        
        with show_loading_spinner(f"Generating {format_type.upper()} profiling report..."):
            
            if format_type == 'pdf':
                # Generate PDF using backend API
                headers = get_auth_headers()
                
                # Prepare content for PDF generation
                content_to_pdf = results.get('generated_content', '')
                
                # Add metadata if requested
                if include_metadata:
                    metadata_section = f"""# AI Profiling Report

## Analysis Metadata

- **File Analyzed:** {results.get('file_analyzed', 'N/A')}
- **Analysis Type:** {results.get('analysis_type', 'N/A')}
- **Data Quality Score:** {results.get('data_quality_score', 0):.2f}%
- **Generated At:** {results.get('generated_at', 'N/A')}

---

"""
                    content_to_pdf = metadata_section + content_to_pdf
                
                try:
                    # FIXED: Use query parameters instead of JSON body
                    params = {"content": content_to_pdf}
                    
                    response = requests.post(
                        API_ENDPOINTS['ai_profiling']['generate_pdf'],
                        params=params,
                        headers=headers,
                        timeout=120
                    )
                    
                    if response.status_code == 200:
                        report_content = response.content
                        filename = f"ai_profiling_report_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                        
                        # Save to database using StreamlitReportManager
                        if use_case_id:
                            use_case_title = use_case.get('title', 'AI Profiling') if isinstance(use_case, dict) else 'AI Profiling'
                            StreamlitReportManager.save_report_to_database(
                                file_content=report_content,
                                module_name="ai_profiling",
                                module_entity_id=use_case_id,
                                report_name=f"AI Profiling PDF Report - {use_case_title}",
                                report_type="pdf",
                                filename=filename
                            )
                        
                        st.download_button(
                            label="📥 Download PDF Report",
                            data=report_content,
                            file_name=filename,
                            mime="application/pdf",
                            use_container_width=True
                        )
                        show_success_message("PDF profiling report generated and saved successfully!")
                    else:
                        # FIXED: Better error handling for validation errors
                        try:
                            error_data = response.json()
                            error_detail = error_data.get('detail', response.text)
                            show_error_message(f"Failed to generate PDF: {error_detail}")
                        except:
                            show_error_message(f"Failed to generate PDF: {response.text}")
                
                except requests.exceptions.RequestException as e:
                    show_error_message(f"Error generating PDF report: {str(e)}")
                    
            elif format_type == 'json':
                # Generate JSON report
                report_data = {
                    'profiling_results': results,
                    'report_config': {
                        'include_metadata': include_metadata,
                        'include_full_content': include_full_content
                    },
                    'timestamp': pd.Timestamp.now().isoformat()
                }
                
                if not include_full_content:
                    # Remove large content if not requested
                    report_data['profiling_results'] = {
                        k: v for k, v in results.items() 
                        if k != 'generated_content'
                    }
                
                report_content = json.dumps(report_data, indent=2, default=str).encode()
                filename = f"ai_profiling_data_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.json"
                
                # Save to database using StreamlitReportManager
                if use_case_id:
                    use_case_title = use_case.get('title', 'AI Profiling') if isinstance(use_case, dict) else 'AI Profiling'
                    StreamlitReportManager.save_report_to_database(
                        file_content=report_content,
                        module_name="ai_profiling",
                        module_entity_id=use_case_id,
                        report_name=f"AI Profiling JSON Data - {use_case_title}",
                        report_type="json",
                        filename=filename
                    )
                
                st.download_button(
                    label="📥 Download JSON Report",
                    data=report_content,
                    file_name=filename,
                    mime="application/json",
                    use_container_width=True
                )
                show_success_message("JSON profiling data exported and saved successfully!")
                
            else:  # markdown
                # Generate markdown report
                content = results.get('generated_content', '')
                
                if include_metadata:
                    metadata_section = f"""# AI Profiling Report

## Analysis Metadata

- **File Analyzed:** {results.get('file_analyzed', 'N/A')}
- **Analysis Type:** {results.get('analysis_type', 'N/A')}
- **Data Quality Score:** {results.get('data_quality_score', 0):.2f}%
- **Generated At:** {results.get('generated_at', 'N/A')}

---

"""
                    content = metadata_section + content
                
                report_content = content.encode('utf-8')
                filename = f"ai_profiling_report_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.md"
                
                # Save to database using StreamlitReportManager
                if use_case_id:
                    use_case_title = use_case.get('title', 'AI Profiling') if isinstance(use_case, dict) else 'AI Profiling'
                    StreamlitReportManager.save_report_to_database(
                        file_content=report_content,
                        module_name="ai_profiling",
                        module_entity_id=use_case_id,
                        report_name=f"AI Profiling Markdown Report - {use_case_title}",
                        report_type="md",
                        filename=filename
                    )
                
                st.download_button(
                    label="📥 Download Markdown Report",
                    data=report_content,
                    file_name=filename,
                    mime="text/markdown",
                    use_container_width=True
                )
                show_success_message("Markdown profiling report exported and saved successfully!")
        
    except Exception as e:
        show_error_message(f"Error generating report: {str(e)}")
if __name__ == "__main__":
    main()