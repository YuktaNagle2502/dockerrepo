import streamlit as st
import requests
import json
from datetime import datetime
from typing import List, Dict, Any

# Assuming these are in their respective files and correctly implemented
from utils.auth import validate_session, get_auth_headers
from utils.config import API_ENDPOINTS, APP_CONFIG
from utils.ui_components import (
    apply_custom_css, show_success_message, show_error_message,
    create_project_card, create_metric_card, show_sidebar_navigation
)


# Configure page
st.set_page_config(
    page_title="Project Management - GenAI Assessment",
    page_icon="📊",
    layout="wide"
)

# Initialize session state for showing the create project form
if "show_create_project_form" not in st.session_state:
    st.session_state.show_create_project_form = False

# Apply custom styling
apply_custom_css()

# Validate authentication (this will redirect if not authenticated)
validate_session()

# Show sidebar navigation
show_sidebar_navigation()

def main():
    """Main project management page"""

    # Header
    st.markdown("""
    <div class="dashboard-header">
        <h1>📊 Project Management</h1>
        <p>Create and manage your GenAI assessment projects</p>
    </div>
    """, unsafe_allow_html=True)

    # Action buttons
    # Use st.container() for buttons to ensure they don't shift when form appears
    with st.container():
        col1, col2, col3, col4 = st.columns([1, 1, 1, 2])

        with col1:
            # When "➕ New Project" is clicked, set the state variable
            if st.button("➕ New Project", type="primary", use_container_width=True, key="new_project_btn"):
                st.session_state.show_create_project_form = True
                # No rerun here, let the page re-render naturally to show the form below

        with col2:
            if st.button("🔄 Refresh", use_container_width=True, key="refresh_btn"):
                st.cache_data.clear() # Clear cache to fetch fresh data
                st.rerun() # Rerun to reflect changes immediately

    # Conditional display of the create project form
    # This needs to be below the buttons but before displaying projects,
    # so that the form appears immediately upon button click.
    if st.session_state.show_create_project_form:
        show_create_project_form()

    # Load and display projects
    # We load projects *after* checking for the form, so new projects
    # appear correctly after a successful submission which triggers a rerun.
    projects = load_projects()

    if projects:
        show_projects_overview(projects)
        show_projects_list(projects)
    else:
        # Only show empty state if create form is NOT currently active
        # This prevents showing "empty state" and the "create form" simultaneously
        if not st.session_state.show_create_project_form:
            show_empty_state()


@st.cache_data(ttl=300)
def load_projects() -> List[Dict[str, Any]]:
    """Load projects from API"""
    try:
        headers = get_auth_headers()
        # Ensure the correct API endpoint is used from config
        # Use API_ENDPOINTS["projects"]["list"] for consistency if available, otherwise keep direct URL
        response = requests.get(
            API_ENDPOINTS["projects"]["list"], # Use the configured endpoint
            headers=headers,
            timeout=30
        )

        if response.status_code == 200:
            return response.json()
        else:
            # Improved error message for debugging
            error_detail = response.json().get("detail", response.text)
            st.error(f"Failed to load projects: {response.status_code} - {error_detail}")
            return []

    except requests.exceptions.ConnectionError:
        st.error("Network error: Could not connect to the API. Please ensure the backend is running.")
        return []
    except requests.exceptions.Timeout:
        st.error("API request timed out. Please try again.")
        return []
    except Exception as e:
        st.error(f"An unexpected error occurred while loading projects: {str(e)}")
        return []


def show_projects_overview(projects: List[Dict[str, Any]]):
    """Show projects overview with metrics"""

    st.markdown("### 📈 Overview")

    # Calculate metrics
    total_projects = len(projects)
    # Assuming 'is_active' is reliable from your Project model
    active_projects = len([p for p in projects if p.get('is_active', True)])
    # 'completed_projects' needs actual assessment status logic from your backend
    # For now, it remains 0 as per original, but note this limitation
    completed_projects = 0

    # Display metrics
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.markdown(
            create_metric_card("Total Projects", str(total_projects), None, "#3182ce"),
            unsafe_allow_html=True
        )

    with col2:
        st.markdown(
            create_metric_card("Active Projects", str(active_projects), None, "#38a169"),
            unsafe_allow_html=True
        )

    with col3:
        st.markdown(
            create_metric_card("Completed", str(completed_projects), None, "#d69e2e"),
            unsafe_allow_html=True
        )

    with col4:
        completion_rate = (completed_projects / total_projects * 100) if total_projects > 0 else 0
        st.markdown(
            create_metric_card("Completion Rate", f"{completion_rate:.1f}%", None, "#9f7aea"),
            unsafe_allow_html=True
        )


def show_projects_list(projects: List[Dict[str, Any]]):
    """Display list of projects"""

    st.markdown("### 📋 Your Projects")

    # Search and filter
    col1, col2 = st.columns([3, 1])

    with col1:
        search_term = st.text_input(
            "🔍 Search projects",
            placeholder="Enter project name or description...",
            key="project_search_term" # Add a key to prevent issues with other text inputs
        )

    with col2:
        sort_by = st.selectbox(
            "Sort by",
            ["Recent", "Name", "Status"],
            index=0,
            key="project_sort_by" # Add a key
        )

    # Filter projects
    filtered_projects = projects
    if search_term:
        filtered_projects = [
            p for p in projects
            if search_term.lower() in p.get('name', '').lower()
            or search_term.lower() in p.get('description', '').lower()
        ]

    # Sort projects
    if sort_by == "Recent":
        # Ensure 'updated_at' exists for sorting, provide a default if not
        filtered_projects.sort(key=lambda x: x.get('updated_at', '1970-01-01T00:00:00Z'), reverse=True)
    elif sort_by == "Name":
        filtered_projects.sort(key=lambda x: x.get('name', '').lower()) # Sort by lowercase name

    # Display projects
    if filtered_projects:
        for project in filtered_projects:
            show_project_item(project)
    else:
        st.info("No projects found matching your criteria.")

def clear_workflow_state():
    """Clear workflow-related session state when switching projects"""
    workflow_keys = [
        'active_use_case_session',
        'active_use_case_session_id', 
        'generated_use_cases',
        'selected_use_case_for_data',
        'selected_use_case_id',
        'uploaded_data_files',
        'processed_data_info',
        'assessment_results',
        'compliance_results',
        'profiling_results'
    ]
    
    for key in workflow_keys:
        if key in st.session_state:
            del st.session_state[key]
            
def show_project_item(project: Dict[str, Any]):
    """Display individual project item"""
    
    # FIXED: Use simple columns layout instead of custom HTML
    project_col, open_btn_col, settings_btn_col = st.columns([3, 1, 1])

    with project_col:
        # FIXED: Use create_project_card without custom HTML wrapper
        st.markdown(create_project_card(project), unsafe_allow_html=True)

    with open_btn_col:
        # Use unique keys for each button to avoid WidgetNotFound errors on refresh
        if st.button("📊 Open", key=f"open_{project['id']}", use_container_width=True):
            # FIXED: Ensure proper session state management for project selection
            st.session_state.selected_project_id = project['id']
            st.session_state.selected_project_name = project['name']
            # Clear any previous workflow state
            clear_workflow_state()
            st.switch_page("pages/2_🧠_Use_Case_Generation.py")

    with settings_btn_col:
        if st.button("⚙️ Settings", key=f"settings_{project['id']}", use_container_width=True):
            # Toggle settings visibility for this project
            settings_key = f"show_settings_{project['id']}"
            st.session_state[settings_key] = not st.session_state.get(settings_key, False)
            # Rerun to show/hide the expander immediately
            st.rerun()

    # Display settings expander if its state is True
    settings_key = f"show_settings_{project['id']}"
    if st.session_state.get(settings_key, False):
        show_project_settings(project)


def show_project_settings(project: Dict[str, Any]):
    """Show project settings modal (using expander for simplicity)"""

    # Ensure the expander has a unique key, and its expanded state is tied to session_state
    with st.expander(
        f"⚙️ Settings for {project['name']}",
        expanded=st.session_state.get(f"show_settings_{project['id']}", False)
    ):

        # Edit project form
        with st.form(f"edit_project_{project['id']}"):
            st.markdown("#### Edit Project")

            # Ensure keys are unique across all instances if this form can appear multiple times
            new_name = st.text_input(
                "Project Name",
                value=project.get('name', ''),
                key=f"edit_name_{project['id']}"
            )

            new_description = st.text_area(
                "Description",
                value=project.get('description', ''),
                key=f"edit_desc_{project['id']}"
            )

            col1, col2 = st.columns(2)

            with col1:
                if st.form_submit_button("💾 Save Changes", type="primary", use_container_width=True, key=f"save_edit_{project['id']}"):
                    update_project(project['id'], new_name, new_description)

            with col2:
                # Use a specific key for the delete confirmation button
                confirm_delete_key = f"confirm_delete_btn_{project['id']}"
                if st.form_submit_button("🗑️ Delete Project", use_container_width=True, key=f"delete_btn_{project['id']}"):
                    # Implement a two-step confirmation for deletion
                    if st.session_state.get(confirm_delete_key, False):
                        delete_project(project['id'])
                        # Reset confirmation state after deletion
                        st.session_state[confirm_delete_key] = False
                    else:
                        st.session_state[confirm_delete_key] = True
                        st.warning("Click again to confirm deletion")
                        # FIXED: Use st.rerun() instead of experimental_rerun
                        st.rerun()


def show_create_project_form():
    """Show create project form"""

    # The expander allows closing the form without submitting
    with st.expander("➕ Create New Project", expanded=True):
        with st.form("create_project_form", clear_on_submit=True):
            st.markdown("#### Project Details")

            name = st.text_input(
                "Project Name *",
                placeholder="Enter a descriptive project name",
                key="new_project_name_input"
            )

            description = st.text_area(
                "Description",
                placeholder="Describe your project goals and objectives",
                key="new_project_description_input"
            )

            col1, col2, col3 = st.columns([1, 1, 1])

            with col2:
                # Use a unique key for the submit button as well
                submitted = st.form_submit_button("🚀 Create Project", type="primary", use_container_width=True)

                if submitted:
                    if name.strip():
                        # Call the function to create the project
                        create_project(name.strip(), description.strip())
                        # FIXED: Close form after successful creation
                        st.session_state.show_create_project_form = False
                    else:
                        show_error_message("Project name is required!")

# FIXED: Update create_project function to handle success properly
def create_project(name: str, description: str):
    """Create a new project"""
    try:
        headers = get_auth_headers()
        payload = {
            "name": name,
            "description": description
        }

        response = requests.post(
            API_ENDPOINTS["projects"]["create"],
            headers=headers,
            json=payload,
            timeout=30
        )

        if response.status_code == 200:
            show_success_message("Project created successfully!")
            st.session_state.show_create_project_form = False  # Hide the form
            st.cache_data.clear()  # Invalidate cache so new project appears
            st.rerun()  # Rerun to refresh the project list
        else:
            error_data = response.json() if response.content else {}
            show_error_message(f"Failed to create project: {response.status_code} - {error_data.get('detail', 'Unknown error')}")

    except requests.exceptions.ConnectionError:
        show_error_message("Network error: Could not connect to the API. Please ensure the backend is running.")
    except requests.exceptions.Timeout:
        show_error_message("API request timed out while creating project. Please try again.")
    except Exception as e:
        show_error_message(f"An unexpected error occurred creating project: {str(e)}")


def update_project(project_id: int, name: str, description: str):
    """Update an existing project"""
    try:
        headers = get_auth_headers()
        payload = {
            "name": name,
            "description": description
        }

        response = requests.put(
            API_ENDPOINTS["projects"]["update"].format(project_id=project_id),
            headers=headers,
            json=payload,
            timeout=30
        )

        if response.status_code == 200:
            show_success_message("Project updated successfully!")
            st.cache_data.clear() # Clear cache to show updated data
            # Optionally, close the settings expander after update
            st.session_state[f"show_settings_{project_id}"] = False
            st.rerun()
        else:
            error_data = response.json() if response.content else {}
            show_error_message(f"Failed to update project: {response.status_code} - {error_data.get('detail', 'Unknown error')}")

    except requests.exceptions.ConnectionError:
        show_error_message("Network error: Could not connect to the API. Please ensure the backend is running.")
    except requests.exceptions.Timeout:
        show_error_message("API request timed out while updating project. Please try again.")
    except Exception as e:
        show_error_message(f"An unexpected error occurred updating project: {str(e)}")


def delete_project(project_id: int):
    """Delete a project"""
    try:
        headers = get_auth_headers()

        response = requests.delete(
            API_ENDPOINTS["projects"]["delete"].format(project_id=project_id),
            headers=headers,
            timeout=30
        )

        if response.status_code == 200:
            show_success_message("Project deleted successfully!")
            st.cache_data.clear() # Clear cache to remove deleted project
            # Also hide the settings expander for the deleted project
            st.session_state[f"show_settings_{project_id}"] = False
            st.rerun()
        else:
            error_data = response.json() if response.content else {}
            show_error_message(f"Failed to delete project: {response.status_code} - {error_data.get('detail', 'Unknown error')}")

    except requests.exceptions.ConnectionError:
        show_error_message("Network error: Could not connect to the API. Please ensure the backend is running.")
    except requests.exceptions.Timeout:
        show_error_message("API request timed out while deleting project. Please try again.")
    except Exception as e:
        show_error_message(f"An unexpected error occurred deleting project: {str(e)}")


def show_empty_state():
    """Show empty state when no projects exist"""

    st.markdown("""
    <div style="text-align: center; padding: 3rem; background: white; border-radius: 15px; margin: 2rem 0;">
        <h2>🚀 Ready to Start Your First Project?</h2>
        <p style="font-size: 1.1rem; color: #718096; margin-bottom: 2rem;">
            Create your first GenAI assessment project to begin the evaluation process.
        </p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        # Use a unique key for this button
        if st.button("➕ Create Your First Project", type="primary", use_container_width=True, key="create_first_project_btn"):
            st.session_state.show_create_project_form = True
            st.rerun() # Rerun to show the form


if __name__ == "__main__":
    main()
