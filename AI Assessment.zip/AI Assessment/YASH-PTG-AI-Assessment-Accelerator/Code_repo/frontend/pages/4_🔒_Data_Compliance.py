import streamlit as st
import requests
import pandas as pd
from datetime import datetime
from utils.auth import validate_session, get_auth_headers
from utils.config import API_ENDPOINTS
from utils.ui_components import (
    apply_custom_css, show_success_message, show_error_message,
    show_loading_spinner, show_sidebar_navigation, show_workflow_progress
)
from utils.report_manager import StreamlitReportManager
# --- PAGE CONFIG & AUTH ---
st.set_page_config(
    page_title="Data Compliance Check - GenAI Assessment",
    page_icon="🔒",
    layout="wide"
)
apply_custom_css()
validate_session()
show_sidebar_navigation()

def get_supported_formats():
    """Fetch supported formats from backend"""
    try:
        endpoint = f"{API_ENDPOINTS['reports']['list'].replace('/reports', '')}/compliance/supported-formats"
        headers = get_auth_headers()
        resp = requests.get(endpoint, headers=headers)
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return {}

def show_compliance_scan_tab():
    st.markdown("### 🔍 Data Compliance Scan")

    # Supported formats from backend
    formats = get_supported_formats()
    allowed_types = formats.get("supported_formats", [".csv", ".xlsx", ".xls", ".json", ".txt", ".pdf"])

    # File upload
    st.markdown("#### 📁 Upload Data File for Compliance Analysis")
    uploaded_file = st.file_uploader(
        "Choose a file",
        type=[ext.lstrip(".") for ext in allowed_types],
        help="Upload a data file for compliance analysis"
    )

    # FIXED: Improved use case selection with session state management
    use_case = st.session_state.get("selected_use_case_for_data")
    use_case_id = None
    
    if isinstance(use_case, dict):
        use_case_id = use_case.get("id")
    elif use_case:
        use_case_id = use_case  # fallback if only id is stored
    else:
        # Try to get from other session state variables
        use_case_id = st.session_state.get('selected_use_case_id')
    
    if not use_case_id:
        st.warning("Please select a use case from the Data Readiness Assessment step first.")
        if st.button("📈 Go to Data Readiness Assessment"):
            st.switch_page("pages/3_📈_Data_Readiness.py")
        return

    st.info(f"Running compliance scan for Use Case ID: {use_case_id}")

    if st.button("🔍 Start Compliance Scan", type="primary", use_container_width=True):
        if not uploaded_file:
            st.error("Please upload a data file.")
            return

        with show_loading_spinner("Running compliance scan..."):
            try:
                # Reset file pointer to beginning
                uploaded_file.seek(0)
                
                # Prepare the multipart form data correctly
                files = {
                    "file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type or "application/octet-stream")
                }
                
                # Send use_case_id as form data
                data = {
                    "use_case_id": str(use_case_id)  # Convert to string for form data
                }
                
                # Get headers but remove Content-Type to let requests set it automatically for multipart
                headers = get_auth_headers()
                if 'Content-Type' in headers:
                    del headers['Content-Type']
                
                endpoint = f"{API_ENDPOINTS['reports']['list'].replace('/reports', '')}/compliance/analyze"
                
                response = requests.post(
                    endpoint, 
                    files=files, 
                    data=data,
                    headers=headers,
                    timeout=300  # 5 minute timeout for large files
                )
                
                if response.status_code == 200:
                    result = response.json()
                    st.session_state.compliance_results = result
                    # FIXED: Store compliance state for next steps
                    st.session_state.compliance_completed = True
                    show_success_message("Compliance scan completed successfully!")
                elif response.status_code == 422:
                    error_detail = response.json()
                    show_error_message(f"Validation error: {error_detail}")
                else:
                    show_error_message(f"Scan failed: {response.text}")
                    
            except requests.exceptions.Timeout:
                show_error_message("Request timed out. Please try with a smaller file.")
            except requests.exceptions.RequestException as e:
                show_error_message(f"Network error: {str(e)}")
            except Exception as e:
                show_error_message(f"Error: {str(e)}")

def show_compliance_report_tab():
    st.markdown("### 📊 Compliance Report")
    if 'compliance_results' not in st.session_state:
        st.info("Please run the compliance scan first to generate a report.")
        return

    results = st.session_state.compliance_results

    # Overall compliance dashboard
    st.markdown("#### 📈 Compliance Dashboard")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown(f"**Overall Score:** {results.get('compliance_score', 0):.1f}%")
    with col2:
        st.markdown(f"**Risk Level:** {results.get('risk_level', 'N/A')}")
    with col3:
        st.markdown(f"**Analysis Type:** {results.get('analysis_type', 'N/A').title()}")

    # Display the main compliance content
    st.markdown("#### 📋 Compliance Analysis Report")
    
    # Parse and display the generated content
    generated_content = results.get('generated_content', '')
    if generated_content:
        st.markdown(generated_content)
    else:
        st.warning("No compliance content generated.")

    # Extract recommendations from the generated content
    st.markdown("#### 💡 Key Recommendations")
    recommendations = extract_recommendations_from_content(generated_content)
    if recommendations:
        for i, rec in enumerate(recommendations, 1):
            st.markdown(f"{i}. {rec}")
    else:
        st.info("No specific recommendations found in the analysis.")

    # Extract compliance issues from content
    st.markdown("#### ⚠️ Compliance Issues")
    issues = extract_issues_from_content(generated_content)
    if issues:
        for issue in issues:
            severity_color = {"critical": "🔴", "high": "🟡", "medium": "🟡", "low": "🟢"}
            issue_level = determine_issue_severity(issue)
            st.markdown(f"{severity_color.get(issue_level, '⚪')} {issue}")
    else:
        st.success("No major compliance issues identified.")

    # Risk Assessment
    with st.expander("🎯 Risk Assessment", expanded=False):
        st.markdown(f"**Overall Risk Level:** {results.get('risk_level', 'N/A')}")
        st.markdown(f"**Compliance Score:** {results.get('compliance_score', 0):.1f}%")
        
        # Extract risk information from content
        risk_info = extract_risk_info_from_content(generated_content)
        if risk_info:
            st.markdown("**Key Risk Areas:**")
            for risk in risk_info:
                st.markdown(f"• {risk}")

    # Generate compliance report
    st.markdown("---")
    if st.button("📄 Generate PDF Report", type="primary", use_container_width=True):
        generate_compliance_report_pdf()

def extract_recommendations_from_content(content: str) -> list:
    """Extract recommendations from the generated compliance content"""
    recommendations = []
    
    # Look for the recommendations section
    lines = content.split('\n')
    in_recommendations = False
    
    for line in lines:
        line = line.strip()
        
        # Check if we're entering recommendations section
        if 'recommendation' in line.lower() and ('###' in line or '##' in line):
            in_recommendations = True
            continue
        
        # Check if we're leaving recommendations section
        if in_recommendations and ('###' in line or '##' in line) and 'recommendation' not in line.lower():
            break
        
        # Extract numbered recommendations
        if in_recommendations and line:
            if line.startswith(('1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.', '9.')):
                # Remove the number and clean up
                rec = line.split('.', 1)[1].strip()
                if rec.startswith('**') and rec.endswith('**'):
                    rec = rec[2:-2]
                recommendations.append(rec)
            elif line.startswith('*') or line.startswith('-'):
                # Handle bullet points
                rec = line[1:].strip()
                if rec.startswith('**') and rec.endswith('**'):
                    rec = rec[2:-2]
                recommendations.append(rec)
    
    return recommendations

def extract_issues_from_content(content: str) -> list:
    """Extract compliance issues from the generated content"""
    issues = []
    
    # Look for common issue indicators
    issue_keywords = ['must', 'required', 'compliance', 'regulation', 'violation', 'non-compliant']
    
    lines = content.split('\n')
    for line in lines:
        line = line.strip()
        
        # Look for lines that indicate compliance requirements or issues
        if any(keyword in line.lower() for keyword in issue_keywords):
            if line.startswith(('*', '-', '•')):
                issue = line[1:].strip()
                if len(issue) > 20:  # Filter out very short lines
                    issues.append(issue)
    
    return issues[:10]  # Limit to top 10 issues

def determine_issue_severity(issue: str) -> str:
    """Determine the severity level of a compliance issue"""
    issue_lower = issue.lower()
    
    if any(word in issue_lower for word in ['critical', 'severe', 'violation', 'breach']):
        return 'critical'
    elif any(word in issue_lower for word in ['high', 'important', 'significant']):
        return 'high'
    elif any(word in issue_lower for word in ['medium', 'moderate', 'consider']):
        return 'medium'
    else:
        return 'low'

def extract_risk_info_from_content(content: str) -> list:
    """Extract risk information from the generated content"""
    risks = []
    
    # Look for risk assessment section
    lines = content.split('\n')
    in_risk_section = False
    
    for line in lines:
        line = line.strip()
        
        # Check if we're entering risk section
        if 'risk' in line.lower() and ('###' in line or '##' in line):
            in_risk_section = True
            continue
        
        # Check if we're leaving risk section
        if in_risk_section and ('###' in line or '##' in line) and 'risk' not in line.lower():
            break
        
        # Extract risk items
        if in_risk_section and line:
            if line.startswith(('*', '-', '•')):
                risk = line[1:].strip()
                if len(risk) > 15:  # Filter out very short lines
                    risks.append(risk)
    
    return risks[:8]  # Limit to top 8 risks

def generate_compliance_report_pdf():
    try:
        with show_loading_spinner("Generating PDF compliance report..."):
            results = st.session_state.get("compliance_results")
            if not results:
                show_error_message("No compliance results to generate report.")
                return
            
            content = results.get("generated_content") or ""
            if not content:
                show_error_message("No content available to generate PDF report.")
                return
            
            endpoint = f"{API_ENDPOINTS['reports']['list'].replace('/reports', '')}/compliance/generate-pdf"
            headers = get_auth_headers()
            
            # Try different approaches based on what the backend expects
            try:
                params = {"content": content}
                resp = requests.post(
                    endpoint, 
                    params=params,
                    headers=headers,
                    timeout=60
                )
            except requests.exceptions.RequestException:
                # Fallback to JSON body
                headers['Content-Type'] = 'application/json'
                resp = requests.post(
                    endpoint,
                    json={"content": content},
                    headers=headers,
                    timeout=60
                )
            
            if resp.status_code == 200:
                report_content = resp.content
                filename = f"compliance_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                
                # FIXED: Save to database using StreamlitReportManager
                use_case_id = st.session_state.get('selected_use_case_id')
                use_case = st.session_state.get("selected_use_case_for_data", {})
                use_case_title = use_case.get('title', 'Compliance Assessment') if isinstance(use_case, dict) else 'Compliance Assessment'
                
                if use_case_id:
                    StreamlitReportManager.save_report_to_database(
                        file_content=report_content,
                        module_name="data_compliance",
                        module_entity_id=use_case_id,
                        report_name=f"Compliance Report - {use_case_title}",
                        report_type="pdf",
                        filename=filename
                    )
                
                st.download_button(
                    label="📥 Download PDF Report",
                    data=report_content,
                    file_name=filename,
                    mime="application/pdf",
                    use_container_width=True
                )
                show_success_message("PDF compliance report generated and saved successfully!")
            elif resp.status_code == 422:
                error_detail = resp.json()
                show_error_message(f"Validation error: {error_detail}")
            else:
                show_error_message(f"Failed to generate PDF: {resp.text}")
                
    except requests.exceptions.Timeout:
        show_error_message("PDF generation timed out. Please try again.")
    except requests.exceptions.RequestException as e:
        show_error_message(f"Network error: {str(e)}")
    except Exception as e:
        show_error_message(f"Error generating report: {str(e)}")

# FIXED: Add workflow progress and project check to main function
def main():
    st.markdown("""
    <div class="dashboard-header">
        <h1>🔒 Data Compliance Check</h1>
        <p>Verify data compliance and security requirements for AI implementation</p>
    </div>
    """, unsafe_allow_html=True)

    # FIXED: Add project selection check
    if 'selected_project_id' not in st.session_state:
        st.warning("Please select a project first from the Project Management page.")
        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            if st.button("📊 Go to Project Management", type="primary", use_container_width=True):
                st.switch_page("pages/1_📊_Project_Management.py")
        return

    # FIXED: Add workflow progress
    show_workflow_progress([1, 2], current_stage=3)

    # FIXED: Check if previous steps are completed
    if not st.session_state.get('assessment_results'):
        st.warning("Please complete the Data Readiness Assessment first.")
        if st.button("📈 Go to Data Readiness Assessment"):
            st.switch_page("pages/3_📈_Data_Readiness.py")
        return

    tab1, tab2 = st.tabs(["🔍 Compliance Scan", "📊 Compliance Report"])
    with tab1:
        show_compliance_scan_tab()
    with tab2:
        show_compliance_report_tab()

if __name__ == "__main__":
    main()