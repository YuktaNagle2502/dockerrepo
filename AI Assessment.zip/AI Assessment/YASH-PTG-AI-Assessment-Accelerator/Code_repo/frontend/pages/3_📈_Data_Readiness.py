import streamlit as st
import requests
import pandas as pd
import io
from typing import List, Dict, Any
from utils.auth import validate_session, get_auth_headers
from utils.config import API_ENDPOINTS, APP_CONFIG
from utils.ui_components import (
    apply_custom_css, show_success_message, show_error_message,
    create_file_uploader, show_loading_spinner, show_sidebar_navigation,
    show_workflow_progress, create_metric_card
)
from utils.report_manager import StreamlitReportManager
# Configure page
st.set_page_config(
    page_title="Data Readiness Assessment - GenAI Assessment",
    page_icon="📈",
    layout="wide"
)

# Apply custom styling
apply_custom_css()

# Validate authentication
validate_session()

# Show sidebar navigation
show_sidebar_navigation()

def main():
    """Main data readiness assessment page"""
    
    # Header
    st.markdown("""
    <div class="dashboard-header">
        <h1>📈 Data Readiness Assessment</h1>
        <p>Assess your data quality and readiness for AI implementation</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Check if project is selected
    if 'selected_project_id' not in st.session_state:
        show_project_selection()
        return
    
    # Show workflow progress
    show_workflow_progress([1], current_stage=2)
    
    # Main content
    show_data_readiness_workflow()

def show_project_selection():
    """Show project selection if no project is selected"""
    
    st.warning("Please select a project first from the Project Management page.")
    
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        if st.button("📊 Go to Project Management", type="primary", use_container_width=True):
            st.switch_page("pages/1_📊_Project_Management.py")

def show_data_readiness_workflow():
    """Show the main data readiness assessment workflow"""
    
    project_id = st.session_state.selected_project_id
    project_name = st.session_state.get('selected_project_name', 'Selected Project')
    
    # Project info
    st.info(f"📊 Working on: **{project_name}**")
    
    # Check previous stage completion
    if not check_previous_stage_completion():
        return
    
    # Store data readiness state
    if 'data_readiness_stage' not in st.session_state:
        st.session_state.data_readiness_stage = 'select_use_case'
    
    # Tabs for different actions
    tab1, tab2, tab3, tab4 = st.tabs(["📋 Select Use Case", "📤 Upload Data", "🔍 Assess Readiness", "📊 View Results"])
    
    with tab1:
        show_use_case_selection_tab()
    
    with tab2:
        show_data_upload_tab()
    
    with tab3:
        show_assessment_tab()
    
    with tab4:
        show_results_tab()
        
def check_previous_stage_completion():
    """Check if Use Case Generation is completed"""
    
    # Check if we have generated use cases from previous step
    has_use_cases = (
        'generated_use_cases' in st.session_state and 
        st.session_state.generated_use_cases and 
        len(st.session_state.generated_use_cases) > 0
    )
    
    if not has_use_cases:
        st.warning("Please complete the Use Case Generation step first and select at least one use case.")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🧠 Go to Use Case Generation"):
                st.switch_page("pages/2_🧠_Use_Case_Generation.py")
        with col2:
            # Allow manual loading if session exists
            if st.button("🔄 Try to Load Use Cases"):
                session_id = st.session_state.get('active_use_case_session_id')
                if session_id:
                    use_cases = get_generated_use_cases(session_id)
                    if use_cases:
                        st.success("Use cases loaded successfully!")
                        st.rerun()
                    else:
                        st.error("No use cases found in session")
                else:
                    st.error("No active session found")
        return False
    return True

def show_use_case_selection_tab():
    """Show use case selection for data readiness assessment"""
    
    st.markdown("### 📋 Select Use Case for Assessment")
    
    # Get use cases from session state
    use_cases = st.session_state.get('generated_use_cases', [])
    session_id = st.session_state.get('active_use_case_session_id')
    
    if not use_cases and session_id:
        # Try to load from backend
        use_cases = get_generated_use_cases(session_id)
    
    if not use_cases:
        st.warning("No use cases found from the previous step.")
        if st.button("🧠 Go to Use Case Generation"):
            st.switch_page("pages/2_🧠_Use_Case_Generation.py")
        return
    
    # Use case selection
    selected_use_case = st.selectbox(
        "Choose a use case to assess data readiness for:",
        options=use_cases,
        format_func=lambda x: x.get('title', 'Untitled Use Case'),
        key="selected_use_case_dropdown"
    )
    
    if selected_use_case:
        # Display use case details
        with st.expander("📖 Use Case Details", expanded=True):
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown(f"**Title:** {selected_use_case.get('title', 'N/A')}")
                st.markdown(f"**Description:** {selected_use_case.get('description', 'N/A')}")
                st.markdown(f"**Business Category:** {selected_use_case.get('business_category', 'N/A')}")
                st.markdown(f"**Complexity:** {selected_use_case.get('complexity', 'N/A')}")
            
            with col2:
                aws_services = selected_use_case.get('aws_services')
                if isinstance(aws_services, list):
                    aws_services_str = ', '.join(aws_services)
                else:
                    aws_services_str = str(aws_services) if aws_services else 'N/A'
                
                st.markdown(f"**AWS Services:** {aws_services_str}")
                st.markdown(f"**Estimated Effort:** {selected_use_case.get('estimated_effort', 'N/A')}")
                st.markdown(f"**ROI Potential:** {selected_use_case.get('roi_potential', 'N/A')}")
        
        # FIXED: Store selected use case in session state with proper structure
        st.session_state.selected_use_case_for_data = selected_use_case
        st.session_state.selected_use_case_id = selected_use_case.get('id')

@st.cache_data(ttl=300)
def get_generated_use_cases(session_id: int) -> List[Dict[str, Any]]:
    """Load generated use cases from the backend or session state"""
    # First try to get from session state
    if 'generated_use_cases' in st.session_state:
        return st.session_state.generated_use_cases
    
    # Fallback to API call
    try:
        headers = get_auth_headers()
        response = requests.get(
            f"{API_ENDPOINTS['pre_workshop']['sessions']}/{session_id}",
            headers=headers
        )
        if response.status_code == 200:
            session_data = response.json()
            use_cases = session_data.get('generated_use_cases', [])
            # Store in session state for future use
            st.session_state.generated_use_cases = use_cases
            return use_cases
        else:
            st.error("Failed to load use cases from backend")
            return []
    except Exception as e:
        st.error(f"Error loading use cases: {str(e)}")
        return []

def show_data_upload_tab():
    """Show data upload tab"""
    
    st.markdown("### 📤 Upload Your Data Files")
    
    if 'selected_use_case_for_data' not in st.session_state:
        st.warning("Please select a use case first.")
        return
    
    use_case = st.session_state.selected_use_case_for_data
    st.info(f"Uploading data for: **{use_case.get('title', 'Selected Use Case')}**")
    
    # File upload section
    uploaded_files = create_file_uploader(
        "Upload your data files for assessment",
        accept_multiple=True,
        key="data_files_upload"
    )
    
    if uploaded_files:
        st.markdown("#### 📁 Uploaded Files")
        
        file_info = []
        for file in uploaded_files:
            file_size_mb = len(file.getvalue()) / (1024 * 1024)
            file_info.append({
                'Filename': file.name,
                'Type': file.type,
                'Size (MB)': f"{file_size_mb:.2f}"
            })
        
        df = pd.DataFrame(file_info)
        st.dataframe(df, use_container_width=True)
        
        # File preview for CSV files
        if len(uploaded_files) == 1 and uploaded_files[0].name.endswith('.csv'):
            show_csv_preview(uploaded_files[0])
        
        # FIXED: Store files in session state with proper handling
        st.session_state.uploaded_data_files = uploaded_files
        st.session_state.data_files_ready = True
        
        # Process files button
        if st.button("📊 Process Files for Assessment", type="primary", use_container_width=True):
            process_data_files()
    else:
        # Clear file state if no files uploaded
        if 'uploaded_data_files' in st.session_state:
            del st.session_state.uploaded_data_files
        if 'data_files_ready' in st.session_state:
            del st.session_state.data_files_ready

def show_csv_preview(csv_file):
    """Show preview of CSV file"""
    try:
        # Reset file pointer
        csv_file.seek(0)
        df = pd.read_csv(csv_file)
        
        st.markdown("#### 👁️ Data Preview")
        st.markdown(f"**Shape:** {df.shape[0]} rows × {df.shape[1]} columns")
        
        # Show first few rows
        st.dataframe(df.head(10), use_container_width=True)
        
        # Basic statistics
        with st.expander("📊 Basic Statistics"):
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Numerical Columns:**")
                numeric_cols = df.select_dtypes(include=['number']).columns
                if len(numeric_cols) > 0:
                    st.dataframe(df[numeric_cols].describe())
                else:
                    st.info("No numerical columns found")
            
            with col2:
                st.markdown("**Missing Values:**")
                missing_data = df.isnull().sum()
                if missing_data.sum() > 0:
                    missing_df = pd.DataFrame({
                        'Column': missing_data.index,
                        'Missing Count': missing_data.values,
                        'Missing %': (missing_data.values / len(df) * 100).round(2)
                    })
                    st.dataframe(missing_df[missing_df['Missing Count'] > 0])
                else:
                    st.success("No missing values found!")
                    
    except Exception as e:
        st.error(f"Error previewing CSV: {str(e)}")

def process_data_files():
    """Process uploaded data files"""
    
    if not st.session_state.get('data_files_ready', False) or 'uploaded_data_files' not in st.session_state:
        show_error_message("No files uploaded!")
        return
    
    use_case = st.session_state.selected_use_case_for_data
    files = st.session_state.uploaded_data_files
    
    try:
        with show_loading_spinner("Processing data files..."):
            # Store processed data info
            st.session_state.processed_data_info = {
                'files_count': len(files),
                'total_size_mb': sum(len(f.getvalue()) for f in files) / (1024 * 1024),
                'use_case': use_case,
                'status': 'processed',
                'processed_at': pd.Timestamp.now().isoformat()
            }
            
            # Mark data as ready for assessment
            st.session_state.data_ready_for_assessment = True
        
        show_success_message("Data files processed successfully!")
        
    except Exception as e:
        show_error_message(f"Error processing files: {str(e)}")

def show_assessment_tab():
    """Show data readiness assessment tab"""
    
    st.markdown("### 🔍 Data Readiness Assessment")
    
    if not st.session_state.get('data_ready_for_assessment', False):
        st.warning("Please upload and process data files first.")
        return
    
    data_info = st.session_state.processed_data_info
    use_case = data_info['use_case']
    use_case_id = st.session_state.get('selected_use_case_id')
    
    if not use_case_id:
        st.error("Use case ID not found. Please select a use case again.")
        return
    
    st.info(f"Assessing data readiness for: **{use_case.get('title', 'Selected Use Case')}**")
    
    # Assessment configuration
    with st.expander("⚙️ Assessment Configuration", expanded=True):
        col1, col2 = st.columns(2)
        
        with col1:
            assessment_depth = st.selectbox(
                "Assessment Depth",
                ["basic", "detailed", "comprehensive"],
                index=1,
                key="assessment_depth_select"
            )
            
            include_ai_analysis = st.checkbox(
                "Include AI-powered analysis",
                value=True,
                help="Use AI to provide detailed insights",
                key="ai_analysis_check"
            )
        
        with col2:
            generate_recommendations = st.checkbox(
                "Generate improvement recommendations",
                value=True,
                key="recommendations_check"
            )
            
            include_compliance_check = st.checkbox(
                "Include compliance assessment",
                value=False,
                help="Check data compliance and privacy requirements",
                key="compliance_check"
            )
    
    # Start assessment
    if st.button("🚀 Start Data Readiness Assessment", type="primary", use_container_width=True):
        run_data_readiness_assessment(
            use_case_id,
            assessment_depth,
            include_ai_analysis,
            generate_recommendations,
            include_compliance_check
        )

# FIXED: Add missing create_file_uploader function if not in ui_components
def create_file_uploader(label: str, accept_multiple: bool = False, key: str = None):
    """Create a file uploader with consistent styling"""
    return st.file_uploader(
        label,
        accept_multiple_files=accept_multiple,
        key=key,
        help="Supported formats: CSV, Excel, JSON, TXT, PDF"
    )

def run_data_readiness_assessment(use_case_id, depth, ai_analysis, recommendations, compliance):
    """Run the data readiness assessment using backend API"""
    
    try:
        with show_loading_spinner("Running data readiness assessment... This may take a few minutes."):
            files = st.session_state.uploaded_data_files
            
            if not files or len(files) == 0:
                show_error_message("No files uploaded for assessment")
                return
            
            # Take the first file for assessment
            file = files[0]
            file.seek(0)  # Reset file pointer
            
            # Prepare multipart form data for the API
            files_data = {
                'file': (file.name, file.getvalue(), file.type)
            }
            
            form_data = {
                'use_case_id': str(use_case_id),
                'project_id': str(st.session_state.selected_project_id),
                'assessment_depth': depth,
                'include_ai_analysis': str(ai_analysis).lower(),
                'generate_recommendations': str(recommendations).lower(),
                'include_compliance_check': str(compliance).lower()
            }
            
            headers = get_auth_headers()
            # Remove Content-Type to let requests handle multipart
            if 'Content-Type' in headers:
                del headers['Content-Type']
            
            # FIXED: Use proper endpoint construction
            base_url = API_ENDPOINTS['reports']['list'].replace('/reports', '')
            endpoint = f"{base_url}/data-readiness/analyze"
            
            response = requests.post(
                endpoint,
                files=files_data,
                data=form_data,
                headers=headers,
                timeout=300  # 5 minute timeout
            )
            
            if response.status_code == 200:
                assessment_results = response.json()
                st.session_state.assessment_results = assessment_results
                
                # Save the report to database
                save_assessment_report(assessment_results, use_case_id)
                
                show_success_message("Data readiness assessment completed successfully!")
                st.rerun()  # Refresh to show results
            else:
                error_detail = "Unknown error"
                try:
                    error_data = response.json()
                    error_detail = error_data.get('detail', response.text)
                except:
                    error_detail = response.text
                
                show_error_message(f"Assessment failed: {error_detail}")
        
    except requests.exceptions.Timeout:
        show_error_message("Assessment timed out. Please try with smaller files.")
    except Exception as e:
        show_error_message(f"Error running assessment: {str(e)}")

def save_assessment_report(results, use_case_id):
    """Save assessment report to database"""
    try:
        import json
        
        # Convert results to JSON bytes
        report_content = json.dumps(results, indent=2).encode('utf-8')
        
        # Get use case details for report name
        use_case = st.session_state.get('selected_use_case_for_data', {})
        use_case_title = use_case.get('title', 'Unknown Use Case')
        
        # Save using StreamlitReportManager
        report_data = StreamlitReportManager.save_report_to_database(
            file_content=report_content,
            module_name="data_readiness",
            module_entity_id=use_case_id,
            report_name=f"Data Readiness Assessment - {use_case_title}",
            report_type="json",
            filename=f"data_readiness_assessment_{use_case_id}.json"
        )
        
        # Store report ID in session state
        if report_data:
            st.session_state.saved_report_id = report_data.get('id')
        
    except Exception as e:
        st.warning(f"Assessment completed but failed to save to database: {str(e)}")
def show_results_tab():
    """Show assessment results"""
    
    st.markdown("### 📊 Assessment Results")
    
    if 'assessment_results' not in st.session_state:
        st.info("No assessment results available. Please run the assessment first.")
        return
    
    results = st.session_state.assessment_results
    
    # Overall score
    col1, col2, col3, col4 = st.columns(4)
    
    readiness_score = results.get('readiness_score', 0)
    overall_status = results.get('overall_status', 'unknown')
    
    with col1:
        score_color = "#38a169" if readiness_score >= 80 else "#d69e2e" if readiness_score >= 60 else "#e53e3e"
        st.markdown(
            create_metric_card(
                "Readiness Score", 
                f"{readiness_score:.1f}%", 
                None, 
                score_color
            ),
            unsafe_allow_html=True
        )
    
    with col2:
        req_analysis = results.get('requirements_analysis', {})
        met_reqs = req_analysis.get('met_requirements', 0)
        total_reqs = req_analysis.get('total_requirements', 1)
        st.markdown(
            create_metric_card(
                "Requirements Met", 
                f"{met_reqs}/{total_reqs}", 
                None, 
                "#3182ce"
            ),
            unsafe_allow_html=True
        )
    
    with col3:
        issues_count = len(results.get('data_quality_issues', []))
        st.markdown(
            create_metric_card(
                "Data Quality Issues", 
                str(issues_count), 
                None, 
                "#e53e3e"
            ),
            unsafe_allow_html=True
        )
    
    with col4:
        status_colors = {
            'ready': '#38a169',
            'partially_ready': '#d69e2e',
            'not_ready': '#e53e3e'
        }
        st.markdown(
            create_metric_card(
                "Overall Status", 
                overall_status.replace('_', ' ').title(), 
                None, 
                status_colors.get(overall_status, '#3182ce')
            ),
            unsafe_allow_html=True
        )
    
    # Detailed results
    col1, col2 = st.columns([1, 1])
    
    with col1:
        # Data quality issues
        st.markdown("#### ⚠️ Data Quality Issues")
        issues = results.get('data_quality_issues', [])
        if issues:
            for issue in issues:
                st.markdown(f"• {issue}")
        else:
            st.success("No significant data quality issues found!")
    
    with col2:
        # Recommendations
        st.markdown("#### 💡 Recommendations")
        recommendations = results.get('recommendations', [])
        if recommendations:
            for i, rec in enumerate(recommendations, 1):
                st.markdown(f"{i}. {rec}")
        else:
            st.info("No specific recommendations at this time.")
    
    # Detailed analysis
    with st.expander("📖 Detailed Analysis", expanded=True):
        detailed_analysis = results.get('detailed_analysis', 'No detailed analysis available.')
        st.markdown(detailed_analysis)
    
    # Generate report
    st.markdown("---")
    col1, col2, col3 = st.columns([1, 1, 1])
    
    with col1:
        if st.button("📄 Generate PDF Report", type="primary", use_container_width=True):
            generate_readiness_report('pdf')
    
    with col2:
        if st.button("📊 Generate JSON Report", use_container_width=True):
            generate_readiness_report('json')
    
    with col3:
        if st.button("📈 View Detailed Metrics", use_container_width=True):
            show_detailed_metrics()

def generate_readiness_report(format_type: str):
    """Generate data readiness report using backend API"""
    
    results = st.session_state.assessment_results
    use_case_id = st.session_state.get('selected_use_case_id')
    use_case = st.session_state.get('selected_use_case_for_data', {})
    
    if not use_case_id:
        show_error_message("Use case ID not found")
        return
    
    try:
        with show_loading_spinner(f"Generating {format_type.upper()} report..."):
            headers = get_auth_headers()
            
            if format_type == 'pdf':
                # FIXED: Generate content for PDF and pass as query parameter
                detailed_analysis = results.get('detailed_analysis', '')
                readiness_score = results.get('readiness_score', 0)
                overall_status = results.get('overall_status', 'unknown')
                
                # Create markdown content for PDF
                pdf_content = f"""# Data Readiness Assessment Report

## Executive Summary
- **Use Case:** {use_case.get('title', 'Assessment')}
- **Readiness Score:** {readiness_score:.1f}%
- **Overall Status:** {overall_status.replace('_', ' ').title()}

## Detailed Analysis
{detailed_analysis}

## Data Quality Issues
"""
                
                issues = results.get('data_quality_issues', [])
                if issues:
                    for issue in issues:
                        pdf_content += f"- {issue}\n"
                else:
                    pdf_content += "- No significant data quality issues found!\n"
                
                pdf_content += "\n## Recommendations\n"
                recommendations = results.get('recommendations', [])
                if recommendations:
                    for i, rec in enumerate(recommendations, 1):
                        pdf_content += f"{i}. {rec}\n"
                else:
                    pdf_content += "- No specific recommendations at this time.\n"
                
                # FIXED: Use query parameters instead of JSON body
                params = {"content": pdf_content}
                
                response = requests.post(
                    API_ENDPOINTS["data_readiness"]["generate_pdf"],
                    params=params,
                    headers=headers,
                    timeout=120
                )
                
                if response.status_code == 200:
                    report_content = response.content
                    filename = f"data_readiness_report_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                    
                    # Save to database using StreamlitReportManager
                    report_data = StreamlitReportManager.save_report_to_database(
                        file_content=report_content,
                        module_name="data_readiness",
                        module_entity_id=use_case_id,
                        report_name=f"Data Readiness Report - {use_case.get('title', 'Assessment')}",
                        report_type="pdf",
                        filename=filename
                    )
                    
                    st.download_button(
                        label="📥 Download PDF Report",
                        data=report_content,
                        file_name=filename,
                        mime="application/pdf",
                        use_container_width=True
                    )
                    
                    if report_data:
                        show_success_message("PDF report generated and saved successfully!")
                    else:
                        show_success_message("PDF report generated (local copy only)")
                else:
                    # FIXED: Better error handling for validation errors
                    try:
                        error_data = response.json()
                        error_detail = error_data.get('detail', response.text)
                        show_error_message(f"Failed to generate PDF: {error_detail}")
                    except:
                        show_error_message(f"Failed to generate PDF: {response.text}")
            
            else:  # json
                import json
                report_content = json.dumps(results, indent=2).encode()
                filename = f"data_readiness_report_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.json"
                
                # Save to database using StreamlitReportManager
                report_data = StreamlitReportManager.save_report_to_database(
                    file_content=report_content,
                    module_name="data_readiness",
                    module_entity_id=use_case_id,
                    report_name=f"Data Readiness Report - {use_case.get('title', 'Assessment')}",
                    report_type="json",
                    filename=filename
                )
                
                st.download_button(
                    label="📥 Download JSON Report",
                    data=report_content,
                    file_name=filename,
                    mime="application/json",
                    use_container_width=True
                )
                
                if report_data:
                    show_success_message("JSON report generated and saved successfully!")
                else:
                    show_success_message("JSON report generated (local copy only)")
        
    except Exception as e:
        show_error_message(f"Error generating report: {str(e)}")


def show_detailed_metrics():
    """Show detailed metrics in expandable section"""
    
    results = st.session_state.assessment_results
    
    with st.expander("📊 Detailed Metrics", expanded=True):
        
        # Requirements breakdown
        st.markdown("#### 📋 Requirements Analysis")
        req_analysis = results.get('requirements_analysis', {})
        
        # Create a simple visualization
        req_data = {
            'Status': ['Met', 'Partial', 'Missing'],
            'Count': [
                req_analysis.get('met_requirements', 0),
                req_analysis.get('partial_requirements', 0), 
                req_analysis.get('missing_requirements', 0)
            ]
        }
        
        req_df = pd.DataFrame(req_data)
        st.bar_chart(req_df.set_index('Status'))
        
        # Data quality metrics
        st.markdown("#### 🔍 Data Quality Metrics")
        
        quality_metrics = results.get('quality_metrics', {
            'Completeness': 85.0,
            'Consistency': 78.5,
            'Accuracy': 92.3,
            'Timeliness': 88.7,
            'Validity': 91.2
        })
        
        for metric, score in quality_metrics.items():
            delta = f"{score - 80:.1f}%" if score != 80 else None
            st.metric(metric, f"{score}%", delta)

if __name__ == "__main__":
    main()