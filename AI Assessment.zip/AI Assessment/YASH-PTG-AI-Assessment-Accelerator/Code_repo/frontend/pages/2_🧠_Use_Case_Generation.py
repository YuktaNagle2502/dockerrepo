import streamlit as st
import requests
import pandas as pd
from typing import List, Dict, Any
from utils.auth import validate_session, get_auth_headers
from utils.config import API_ENDPOINTS, APP_CONFIG
from utils.ui_components import (
    apply_custom_css, show_success_message, show_error_message,
    create_file_uploader, show_loading_spinner, show_sidebar_navigation,
    show_workflow_progress
)

# Configure page
st.set_page_config(
    page_title="Use Case Generation - GenAI Assessment",
    page_icon="🧠",
    layout="wide"
)

# Apply custom styling
apply_custom_css()

# Validate authentication
validate_session()

# Show sidebar navigation
show_sidebar_navigation()

def main():
    """Main use case generation page"""
    
    # Header
    st.markdown("""
    <div class="dashboard-header">
        <h1>🧠 Use Case Generation</h1>
        <p>Upload questionnaire responses and generate AI-powered use cases</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Check if project is selected
    if 'selected_project_id' not in st.session_state:
        show_project_selection()
        return
    
    # Show workflow progress
    show_workflow_progress([1], current_stage=1)
    
    # Main content
    show_use_case_workflow()

def show_project_selection():
    """Show project selection if no project is selected"""
    
    st.warning("Please select a project first from the Project Management page.")
    
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        if st.button("📊 Go to Project Management", type="primary", use_container_width=True):
            st.switch_page("pages/1_📊_Project_Management.py")

def show_use_case_workflow():
    """Show the main use case generation workflow"""
    
    project_id = st.session_state.selected_project_id
    project_name = st.session_state.get('selected_project_name', 'Selected Project')
    
    # Project info
    st.info(f"📊 Working on: **{project_name}**")
    
    # Load existing sessions
    sessions = load_pre_workshop_sessions(project_id)
    
    # Tabs for different actions
    tab1, tab2, tab3 = st.tabs(["📤 Upload Questionnaire", "🧠 Generate Use Cases", "📋 View Results"])
    
    with tab1:
        show_questionnaire_upload_tab(project_id, sessions)
    
    with tab2:
        show_use_case_generation_tab(sessions)
    
    with tab3:
        show_results_tab(sessions)

@st.cache_data(ttl=300)
def load_pre_workshop_sessions(project_id: int) -> List[Dict[str, Any]]:
    """Load pre-workshop sessions for the project"""
    try:
        headers = get_auth_headers()
        response = requests.get(
            f"{API_ENDPOINTS['pre_workshop']['sessions']}?project_id={project_id}",
            headers=headers,
            timeout=30
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            return []
            
    except Exception as e:
        st.error(f"Error loading sessions: {str(e)}")
        return []

def show_questionnaire_upload_tab(project_id: int, sessions: List[Dict[str, Any]]):
    """Show questionnaire upload tab"""
    
    st.markdown("### 📤 Upload Questionnaire Responses")
    
    # Create new session form
    with st.expander("➕ Create New Assessment Session", expanded=True):
        with st.form("create_session_form"):
            session_name = st.text_input(
                "Session Name *",
                placeholder="e.g., Q1 2024 Assessment"
            )
            
            session_description = st.text_area(
                "Description",
                placeholder="Brief description of this assessment session"
            )
            
            if st.form_submit_button("🚀 Create Session", type="primary"):
                if session_name.strip():
                    create_session(project_id, session_name.strip(), session_description.strip())
                else:
                    show_error_message("Session name is required!")
    
    # Show existing sessions
    if sessions:
        st.markdown("### 📁 Existing Sessions")
        
        for session in sessions:
            show_session_card(session)
    else:
        st.info("No assessment sessions found. Create your first session above.")

def show_session_card(session: Dict[str, Any]):
    """Display session card with upload functionality"""
    
    with st.expander(f"📁 {session['session_name']}", expanded=False):
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.markdown(f"**Description:** {session.get('description', 'No description')}")
            st.markdown(f"**Status:** {session['status']}")
            st.markdown(f"**Created:** {session['created_at'][:19]}")
        
        with col2:
            status_color = {
                'draft': '🔄',
                'questionnaire_uploaded': '✅',
                'use_cases_generated': '🧠',
                'completed': '🎉'
            }
            st.markdown(f"## {status_color.get(session['status'], '📋')} {session['status'].replace('_', ' ').title()}")
        
        # File upload for this session
        if session['status'] in ['draft', 'questionnaire_uploaded']:
            st.markdown("#### 📤 Upload Excel Questionnaire")
            
            uploaded_file = create_file_uploader(
                "Choose Excel file with questionnaire responses",
                key=f"upload_{session['id']}"
            )
            
            if uploaded_file:
                if st.button(f"📤 Upload to {session['session_name']}", key=f"upload_btn_{session['id']}"):
                    upload_questionnaire(session['id'], uploaded_file)
        
        # View questionnaire responses
        if session['status'] in ['questionnaire_uploaded', 'use_cases_generated', 'completed']:
            if st.button(f"👁️ View Responses", key=f"view_{session['id']}"):
                show_questionnaire_responses(session['id'])

def create_session(project_id: int, name: str, description: str):
    """Create a new pre-workshop session"""
    try:
        headers = get_auth_headers()
        payload = {
            "project_id": project_id,
            "session_name": name,
            "description": description
        }
        
        response = requests.post(
            API_ENDPOINTS["pre_workshop"]["sessions"],
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            show_success_message("Session created successfully!")
            st.cache_data.clear()
            st.rerun()
        else:
            error_data = response.json() if response.content else {}
            show_error_message(error_data.get("detail", "Failed to create session"))
            
    except Exception as e:
        show_error_message(f"Error creating session: {str(e)}")

def upload_questionnaire(session_id: int, uploaded_file):
    """Upload questionnaire file to session"""
    try:
        headers = {
            "Authorization": f"Bearer {st.session_state.access_token}"
        }
        
        files = {
            "file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type)
        }
        
        with show_loading_spinner("Uploading and processing questionnaire..."):
            response = requests.post(
                API_ENDPOINTS["pre_workshop"]["upload"].format(session_id=session_id),
                headers=headers,
                files=files,
                timeout=120
            )
        
        if response.status_code == 200:
            result = response.json()
            show_success_message(f"Questionnaire uploaded successfully! {result['total_responses']} responses processed.")
            st.cache_data.clear()
            st.rerun()
        else:
            error_data = response.json() if response.content else {}
            show_error_message(error_data.get("detail", "Failed to upload questionnaire"))
            
    except Exception as e:
        show_error_message(f"Error uploading questionnaire: {str(e)}")

def show_questionnaire_responses(session_id: int):
    """Show questionnaire responses for a session"""
    try:
        headers = get_auth_headers()
        response = requests.get(
            f"{API_ENDPOINTS['pre_workshop']['sessions']}/{session_id}",
            headers=headers,
            timeout=30
        )
        
        if response.status_code == 200:
            session_data = response.json()
            responses = session_data.get('questionnaire_responses', [])
            
            if responses:
                st.markdown("#### 📋 Questionnaire Responses")
                
                # Convert to DataFrame for better display
                df_data = []
                for resp in responses:
                    df_data.append({
                        'Category': resp.get('category', 'General'),
                        'Question': resp['question'][:100] + "..." if len(resp['question']) > 100 else resp['question'],
                        'Response': resp['response'][:150] + "..." if len(resp['response']) > 150 else resp['response']
                    })
                
                df = pd.DataFrame(df_data)
                st.dataframe(df, use_container_width=True)
                
                # Show full responses in expandable sections
                with st.expander("📖 View Full Responses"):
                    for i, resp in enumerate(responses, 1):
                        st.markdown(f"**Q{i}: {resp['question']}**")
                        if resp.get('description'):
                            st.markdown(f"*{resp['description']}*")
                        st.markdown(f"**Answer:** {resp['response']}")
                        if resp.get('additional_notes'):
                            st.markdown(f"*Notes: {resp['additional_notes']}*")
                        st.markdown("---")
            else:
                st.info("No questionnaire responses found.")
                
    except Exception as e:
        show_error_message(f"Error loading responses: {str(e)}")

def show_use_case_generation_tab(sessions: List[Dict[str, Any]]):
    """Show use case generation tab"""
    
    st.markdown("### 🧠 Generate AI Use Cases")
    
    # Filter sessions that have questionnaire uploaded
    eligible_sessions = [s for s in sessions if s['status'] in ['questionnaire_uploaded', 'use_cases_generated']]
    
    if not eligible_sessions:
        st.warning("No sessions with uploaded questionnaires found. Please upload a questionnaire first.")
        return
    
    for session in eligible_sessions:
        with st.expander(f"🧠 Generate Use Cases for {session['session_name']}", expanded=True):
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.markdown(f"**Status:** {session['status'].replace('_', ' ').title()}")
                if session['status'] == 'questionnaire_uploaded':
                    st.markdown("✅ Questionnaire responses are ready for use case generation")
                elif session['status'] == 'use_cases_generated':
                    st.markdown("🧠 Use cases have been generated for this session")
            
            with col2:
                if session['status'] == 'questionnaire_uploaded':
                    if st.button(f"🚀 Generate Use Cases", key=f"generate_{session['id']}", type="primary"):
                        generate_use_cases(session['id'])
                elif session['status'] == 'use_cases_generated':
                    if st.button(f"🔄 Regenerate", key=f"regenerate_{session['id']}"):
                        generate_use_cases(session['id'])

def generate_use_cases(session_id: int):
    """Generate use cases for a session"""
    try:
        headers = get_auth_headers()
        
        with show_loading_spinner("Generating AI use cases... This may take a few minutes."):
            response = requests.post(
                API_ENDPOINTS["pre_workshop"]["generate_use_cases"].format(session_id=session_id),
                headers=headers,
                timeout=300  # 5 minutes timeout
            )
        
        if response.status_code == 200:
            result = response.json()
            show_success_message(f"Generated {result['total_use_cases']} use cases successfully!")
            st.cache_data.clear()
            st.rerun()
        else:
            error_data = response.json() if response.content else {}
            show_error_message(error_data.get("detail", "Failed to generate use cases"))
            
    except Exception as e:
        show_error_message(f"Error generating use cases: {str(e)}")

def show_results_tab(sessions: List[Dict[str, Any]]):
    """Show results tab with generated use cases"""
    
    st.markdown("### 📋 Generated Use Cases")
    
    # Filter sessions with generated use cases
    completed_sessions = [s for s in sessions if s['status'] in ['use_cases_generated', 'completed']]
    
    if not completed_sessions:
        st.info("No sessions with generated use cases found. Generate use cases first.")
        return
    
    for session in completed_sessions:
        if 'use_case_session_id' not in st.session_state:
            st.session_state.use_case_session_id = session['id']
        show_session_results(session)

def show_session_results(session: Dict[str, Any]):
    """Show results for a specific session"""
    try:
        headers = get_auth_headers()
        response = requests.get(
            f"{API_ENDPOINTS['pre_workshop']['sessions']}/{session['id']}",
            headers=headers,
            timeout=30
        )
        
        if response.status_code == 200:
            session_data = response.json()
            use_cases = session_data.get('generated_use_cases', [])
            
            with st.expander(f"📋 Results for {session['session_name']}", expanded=True):
                if use_cases:
                    st.markdown(f"**Generated {len(use_cases)} use cases:**")
                    
                    # FIXED: Store session data in session state for next pages
                    if 'active_use_case_session' not in st.session_state:
                        st.session_state.active_use_case_session = session
                        st.session_state.active_use_case_session_id = session['id']
                        st.session_state.generated_use_cases = use_cases
                    
                    # Use case selection
                    selected_ids = []
                    for i, use_case in enumerate(use_cases):
                        col1, col2, col3 = st.columns([0.5, 4, 1])
                        
                        with col1:
                            is_selected = st.checkbox(
                                "",
                                value=use_case.get('is_selected', False),
                                key=f"select_{use_case['id']}"
                            )
                            if is_selected:
                                selected_ids.append(use_case['id'])
                        
                        with col2:
                            st.markdown(f"**{use_case['title']}**")
                            st.markdown(f"{use_case['description'][:200]}...")
                            
                            # Show details in expandable section
                            with st.expander("📖 View Details"):
                                col_a, col_b = st.columns(2)
                                with col_a:
                                    # FIXED: Handle list properly
                                    aws_services = use_case.get('aws_services', [])
                                    if isinstance(aws_services, list):
                                        aws_services_str = ', '.join(aws_services)
                                    else:
                                        aws_services_str = str(aws_services)
                                    
                                    st.markdown(f"**AWS Services:** {aws_services_str}")
                                    st.markdown(f"**Priority:** {use_case.get('priority', 'N/A')}")
                                    st.markdown(f"**Complexity:** {use_case.get('complexity', 'N/A')}")
                                    st.markdown(f"**ROI Potential:** {use_case.get('roi_potential', 'N/A')}")
                                
                                with col_b:
                                    st.markdown(f"**Business Category:** {use_case.get('business_category', 'N/A')}")
                                    st.markdown(f"**Estimated Effort:** {use_case.get('estimated_effort', 'N/A')}")
                                    st.markdown(f"**Cost Estimate:** {use_case.get('cost_estimate', 'N/A')}")
                        with col3:
                            priority_color = {
                                'High': '🔴',
                                'Medium': '🟡',
                                'Low': '🟢'
                            }
                            st.markdown(f"{priority_color.get(use_case.get('priority'), '⚪')} {use_case.get('priority', 'N/A')}")
                    
                    # FIXED: Store selected use cases in session state
                    st.session_state.selected_use_case_ids = selected_ids
                    
                    # Generate report with proper data structure
                    st.markdown("---")
                    col1, col2 = st.columns([1, 1])
                    
                    with col1:
                        if st.button(f"📄 Generate PDF Report", key=f"pdf_{session['id']}", type="primary"):
                            generate_report(session['id'], 'pdf', session)
                    
                    with col2:
                        if st.button(f"📊 Generate JSON Report", key=f"json_{session['id']}"):
                            generate_report(session['id'], 'json', session)
    except Exception as e:
        show_error_message(f"Error: {str(e)}")

def select_use_cases(session_id: int, use_case_ids: List[int], is_selected: bool):
    """Select or deselect use cases"""
    try:
        headers = get_auth_headers()
        payload = {
            "use_case_ids": use_case_ids,
            "is_selected": is_selected
        }
        
        response = requests.put(
            f"{API_ENDPOINTS['pre_workshop']['sessions']}/{session_id}/use-cases/select",
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            action = "selected" if is_selected else "deselected"
            show_success_message(f"Use cases {action} successfully!")
            st.rerun()
        else:
            show_error_message("Failed to update use case selection")
            
    except Exception as e:
        show_error_message(f"Error updating selection: {str(e)}")

def generate_report(session_id: int, report_type: str, session_data: Dict[str, Any]):
    """Generate and save report to database"""
    try:
        headers = get_auth_headers()
        payload = {
            "session_id": session_id,
            "report_type": report_type
        }
        
        with show_loading_spinner(f"Generating {report_type.upper()} report..."):
            response = requests.post(
                API_ENDPOINTS["pre_workshop"]["reports"].format(session_id=session_id),
                headers=headers,
                json=payload,
                timeout=120
            )
        
        if response.status_code == 200:
            report_content = response.content
            filename = f"use_cases_report_{session_id}.{report_type}"
            
            # FIXED: Save report to database using universal reports API
            save_report_to_database(
                file_content=report_content,
                module_name="pre_workshop", 
                module_entity_id=session_id,
                report_name=f"Use Cases Report - {session_data.get('session_name', 'Session')}",
                report_type=report_type,
                filename=filename
            )
            
            # Provide download
            st.download_button(
                label=f"📥 Download {report_type.upper()} Report",
                data=report_content,
                file_name=filename,
                mime=f"application/{report_type}",
                use_container_width=True
            )
            
            show_success_message(f"{report_type.upper()} report generated and saved successfully!")
        else:
            show_error_message("Failed to generate report")
            
    except Exception as e:
        show_error_message(f"Error generating report: {str(e)}")

def save_report_to_database(file_content: bytes, module_name: str, module_entity_id: int, 
                          report_name: str, report_type: str, filename: str):
    """Save report to database using universal reports API"""
    try:
        import io
        
        # Create form data for multipart upload
        files = {
            'file': (filename, io.BytesIO(file_content), f'application/{report_type}')
        }
        
        form_data = {
            'user_id': str(st.session_state.user_data['id']),
            'project_id': str(st.session_state.selected_project_id),
            'module_name': module_name,
            'module_entity_id': str(module_entity_id),
            'report_name': report_name,
            'report_type': report_type
        }
        
        headers = get_auth_headers()
        # Remove Content-Type to let requests handle multipart
        if 'Content-Type' in headers:
            del headers['Content-Type']
        
        response = requests.post(
            API_ENDPOINTS["reports"]["save"],
            files=files,
            data=form_data,
            headers=headers,
            timeout=60
        )
        
        if response.status_code == 200:
            report_data = response.json()
            st.session_state.last_saved_report = report_data
        else:
            st.warning(f"Report generated but failed to save to database: {response.text}")
            
    except Exception as e:
        st.warning(f"Report generated but failed to save to database: {str(e)}")

if __name__ == "__main__":
    main()
