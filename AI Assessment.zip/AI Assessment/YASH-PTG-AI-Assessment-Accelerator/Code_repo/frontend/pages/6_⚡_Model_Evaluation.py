import streamlit as st
import requests
import pandas as pd
import json
from typing import List, Dict, Any
from utils.auth import validate_session, get_auth_headers
from utils.config import API_ENDPOINTS, APP_CONFIG
from utils.ui_components import (
    apply_custom_css, show_success_message, show_error_message,
    show_loading_spinner, show_sidebar_navigation, show_workflow_progress,
    create_metric_card
)
from utils.report_manager import StreamlitReportManager

# Configure page
st.set_page_config(
    page_title="Model Evaluation - GenAI Assessment",
    page_icon="⚡",
    layout="wide"
)

# Apply custom styling
apply_custom_css()

# Validate authentication
validate_session()

# Show sidebar navigation
show_sidebar_navigation()

def main():
    """Main model evaluation page"""
    
    # Header
    st.markdown("""
    <div class="dashboard-header">
        <h1>⚡ Model Evaluation</h1>
        <p>Evaluate and compare different AI model performances</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Check if project is selected
    if 'selected_project_id' not in st.session_state:
        show_project_selection()
        return
    
    # Show workflow progress
    show_workflow_progress([1, 2, 3, 4], current_stage=5)
    
    # Check previous stage completion
    if not check_previous_stage_completion():
        return
    
    # Main content
    show_model_evaluation_workflow()

def show_project_selection():
    """Show project selection if no project is selected"""
    
    st.warning("Please select a project first from the Project Management page.")
    
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        if st.button("📊 Go to Project Management", type="primary", use_container_width=True):
            st.switch_page("pages/1_📊_Project_Management.py")

def check_previous_stage_completion():
    """Check if previous stages are completed"""
    
    # Check if compliance is completed
    if not st.session_state.get('compliance_completed', False):
        st.warning("Please complete the Data Compliance Check step first.")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🔒 Go to Data Compliance"):
                st.switch_page("pages/4_🔒_Data_Compliance.py")
        with col2:
            # Allow skipping if compliance results exist
            if st.session_state.get('compliance_results'):
                if st.button("⏭️ Continue Anyway"):
                    st.session_state.compliance_completed = True
                    st.rerun()
        return False
    return True

def show_model_evaluation_workflow():
    """Show the main model evaluation workflow"""
    
    project_id = st.session_state.selected_project_id
    project_name = st.session_state.get('selected_project_name', 'Selected Project')
    
    # Project info
    st.info(f"📊 Working on: **{project_name}**")
    
    # Tabs for different evaluation activities
    tab1, tab2, tab3, tab4 = st.tabs(["⚙️ Setup Evaluation", "📝 Create Test Cases", "🚀 Run Evaluation", "📊 View Results"])
    
    with tab1:
        show_evaluation_setup_tab()
    
    with tab2:
        show_test_cases_tab()
    
    with tab3:
        show_run_evaluation_tab()
    
    with tab4:
        show_results_tab()

def show_evaluation_setup_tab():
    """Show evaluation setup tab"""
    
    st.markdown("### ⚙️ Model Evaluation Setup")
    
    # Get use case information
    use_case = st.session_state.get("selected_use_case_for_data")
    use_case_id = st.session_state.get('selected_use_case_id')
    
    if not use_case_id:
        st.warning("Please complete previous steps to select a use case.")
        return
    
    st.info(f"Setting up evaluation for: **{use_case.get('title', 'Selected Use Case') if use_case else 'Use Case'}**")
    
    # API Configuration
    st.markdown("#### 🔧 API Configuration")
    
    col1, col2 ,col3= st.columns(3)
    
    with col1:
        st.markdown("**OpenAI/Azure OpenAI Configuration**")
        
        openai_api_key = st.text_input(
            "OpenAI API Key",
            type="password",
            help="Your OpenAI or Azure OpenAI API key"
        )
        
        openai_endpoint = st.text_input(
            "API Endpoint (Azure only)",
            placeholder="https://your-resource.openai.azure.com/",
            help="Leave empty for standard OpenAI API"
        )
        
        openai_models = st.multiselect(
            "OpenAI Models to Evaluate",
            ["gpt-3.5-turbo", "gpt-4", "gpt-4-turbo", "gpt-35-turbo", "gpt3516k"],
            default=["gpt-3.5-turbo"]
        )
    
    with col2:
        st.markdown("**Google Gemini Configuration**")
        
        gemini_api_key = st.text_input(
            "Gemini API Key",
            type="password",
            help="Your Google Gemini API key"
        )
        
        gemini_models = st.multiselect(
            "Gemini Models to Evaluate",
            ["gemini-1.5-pro", "gemini-1.5-flash", "gemini-2.0-flash-exp", "gemini-2.0-flash-thinking-exp"],
            default=["gemini-1.5-pro"]
        )
    
    with col3:
        st.markdown("**Bedrock Configuration**")
        
        
        bedrock_model_ids = st.multiselect(
            "Bedrock Models to Evaluate",
            ["ai21.jamba-1-5-large-v1:0", "amazon.nova-canvas-v1:0", "amazon.nova-micro-v1:0"],
            default=["amazon.nova-canvas-v1:0"]
        )
    
    # Evaluation Configuration
    st.markdown("#### 📊 Evaluation Configuration")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        use_llm_judge = st.checkbox(
            "Use LLM as Judge",
            value=True,
            help="Use an LLM to evaluate response quality (more accurate)"
        )
        
        judge_model = st.selectbox(
            "Judge Model",
            ["gpt-4", "gpt-3.5-turbo", "gpt3516k"],
            help="Model to use for judging responses"
        )
    
    with col2:
        evaluation_timeout = st.number_input(
            "Timeout (seconds)",
            min_value=10,
            max_value=300,
            value=60,
            help="Timeout for each model evaluation"
        )
        
        max_retries = st.number_input(
            "Max Retries",
            min_value=1,
            max_value=5,
            value=3,
            help="Maximum retries for failed requests"
        )
    
    with col3:
        temperature = st.slider(
            "Temperature",
            min_value=0.0,
            max_value=1.0,
            value=0.7,
            step=0.1,
            help="Randomness in model responses"
        )
        
        max_tokens = st.number_input(
            "Max Tokens",
            min_value=100,
            max_value=4000,
            value=1000,
            help="Maximum tokens in response"
        )
    
    # Save configuration
    if st.button("💾 Save Configuration", type="primary", use_container_width=True):
        evaluation_config = {
            'use_case_id': use_case_id,
            'openai': {
                'api_key': openai_api_key,
                'endpoint': openai_endpoint,
                'models': openai_models
            },
            'gemini': {
                'api_key': gemini_api_key,
                'models': gemini_models
            },
            'bedrock': {
                'api_key': "gemini_api_key",
                'models': bedrock_model_ids
            },
            'evaluation': {
                'use_llm_judge': use_llm_judge,
                'judge_model': judge_model,
                'timeout': evaluation_timeout,
                'max_retries': max_retries,
                'temperature': temperature,
                'max_tokens': max_tokens
            }
        }
        
        st.session_state.evaluation_config = evaluation_config
        show_success_message("Configuration saved successfully!")

def show_test_cases_tab():
    """Show test cases creation tab"""
    
    st.markdown("### 📝 Create Evaluation Test Cases")
    
    # Check if configuration is set
    if 'evaluation_config' not in st.session_state:
        st.warning("Please configure the evaluation setup first.")
        return
    
    # Test case input methods
    input_method = st.radio(
        "Choose input method:",
        ["Manual Entry", "Upload CSV", "Use Predefined Templates"],
        horizontal=True
    )
    
    if input_method == "Manual Entry":
        show_manual_test_entry()
    elif input_method == "Upload CSV":
        show_csv_upload()
    else:
        show_predefined_templates()

def show_manual_test_entry():
    """Show manual test case entry"""
    
    st.markdown("#### ✏️ Manual Test Case Entry")
    
    # Initialize test cases in session state
    if 'test_cases' not in st.session_state:
        st.session_state.test_cases = []
    
    # Add new test case form
    with st.expander("➕ Add New Test Case", expanded=True):
        with st.form("add_test_case"):
            col1, col2 = st.columns(2)
            
            with col1:
                test_prompt = st.text_area(
                    "Test Prompt",
                    placeholder="Enter the prompt/question to test...",
                    height=100
                )
                
                ground_truth = st.text_area(
                    "Expected Answer (Ground Truth)",
                    placeholder="Enter the expected correct answer...",
                    height=100
                )
            
            with col2:
                test_category = st.selectbox(
                    "Test Category",
                    ["General Knowledge", "Math", "Reasoning", "Creative Writing", "Code Generation", "Analysis", "Other"],
                    index=0
                )
                
                difficulty_level = st.selectbox(
                    "Difficulty Level",
                    ["Easy", "Medium", "Hard"],
                    index=1
                )
                
                evaluation_criteria = st.multiselect(
                    "Evaluation Criteria",
                    ["Accuracy", "Completeness", "Clarity", "Relevance", "Creativity"],
                    default=["Accuracy", "Completeness"]
                )
            
            if st.form_submit_button("➕ Add Test Case", type="primary"):
                if test_prompt and ground_truth:
                    new_test_case = {
                        'id': len(st.session_state.test_cases) + 1,
                        'prompt': test_prompt,
                        'ground_truth': ground_truth,
                        'category': test_category,
                        'difficulty': difficulty_level,
                        'criteria': evaluation_criteria
                    }
                    st.session_state.test_cases.append(new_test_case)
                    show_success_message("Test case added successfully!")
                    st.rerun()
                else:
                    show_error_message("Please fill in both prompt and ground truth!")
    
    # Display existing test cases
    if st.session_state.test_cases:
        st.markdown("#### 📋 Current Test Cases")
        
        for i, test_case in enumerate(st.session_state.test_cases):
            with st.expander(f"Test Case {test_case['id']}: {test_case['category']} - {test_case['difficulty']}"):
                col1, col2, col3 = st.columns([3, 3, 1])
                
                with col1:
                    st.markdown("**Prompt:**")
                    st.markdown(test_case['prompt'])
                
                with col2:
                    st.markdown("**Expected Answer:**")
                    st.markdown(test_case['ground_truth'])
                
                with col3:
                    if st.button("🗑️ Delete", key=f"delete_{test_case['id']}"):
                        st.session_state.test_cases.pop(i)
                        st.rerun()
        
        # Export test cases
        if st.button("📤 Export Test Cases as JSON"):
            export_test_cases()

def show_csv_upload():
    """Show CSV upload for test cases"""
    
    st.markdown("#### 📤 Upload Test Cases from CSV")
    
    # Show expected format
    with st.expander("📋 Expected CSV Format", expanded=True):
        sample_data = {
            'prompt': [
                'What is the capital of France?',
                'Calculate 15% of 240',
                'Explain the concept of photosynthesis'
            ],
            'ground_truth': [
                'Paris',
                '36',
                'Photosynthesis is the process by which plants convert light energy into chemical energy'
            ],
            'category': [
                'General Knowledge',
                'Math',
                'Science'
            ],
            'difficulty': [
                'Easy',
                'Easy',
                'Medium'
            ]
        }
        
        sample_df = pd.DataFrame(sample_data)
        st.dataframe(sample_df, use_container_width=True)
        
        # Download sample CSV
        csv_content = sample_df.to_csv(index=False)
        st.download_button(
            "📥 Download Sample CSV",
            csv_content,
            "sample_test_cases.csv",
            "text/csv"
        )
    
    # File upload
    uploaded_file = st.file_uploader(
        "Choose CSV file",
        type=['csv'],
        help="Upload a CSV file with test cases"
    )
    
    if uploaded_file:
        try:
            df = pd.read_csv(uploaded_file)
            
            # Validate required columns
            required_columns = ['prompt', 'ground_truth']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                show_error_message(f"Missing required columns: {', '.join(missing_columns)}")
                return
            
            # Preview uploaded data
            st.markdown("#### 👁️ Preview Uploaded Test Cases")
            st.dataframe(df.head(10), use_container_width=True)
            
            # Import test cases
            if st.button("📥 Import Test Cases", type="primary"):
                imported_cases = []
                for _, row in df.iterrows():
                    test_case = {
                        'id': len(imported_cases) + 1,
                        'prompt': row['prompt'],
                        'ground_truth': row['ground_truth'],
                        'category': row.get('category', 'General'),
                        'difficulty': row.get('difficulty', 'Medium'),
                        'criteria': ['Accuracy', 'Completeness']
                    }
                    imported_cases.append(test_case)
                
                st.session_state.test_cases = imported_cases
                show_success_message(f"Imported {len(imported_cases)} test cases successfully!")
                
        except Exception as e:
            show_error_message(f"Error reading CSV file: {str(e)}")

def show_predefined_templates():
    """Show predefined test case templates"""
    
    st.markdown("#### 🎯 Predefined Test Templates")
    
    templates = {
        "General Knowledge": [
            {"prompt": "What is the capital of France?", "ground_truth": "Paris"},
            {"prompt": "Who wrote Romeo and Juliet?", "ground_truth": "William Shakespeare"},
            {"prompt": "What is the largest planet in our solar system?", "ground_truth": "Jupiter"}
        ],
        "Mathematics": [
            {"prompt": "What is 15% of 240?", "ground_truth": "36"},
            {"prompt": "If log₂(x) = 5, what is the value of x?", "ground_truth": "x = 32"},
            {"prompt": "What is the derivative of x³ - 4x² + 6x - 3?", "ground_truth": "3x² - 8x + 6"}
        ],
        "Science": [
            {"prompt": "What is the molecular formula for glucose?", "ground_truth": "C₆H₁₂O₆"},
            {"prompt": "In which layer of the atmosphere do commercial airplanes fly?", "ground_truth": "Stratosphere"},
            {"prompt": "What is photosynthesis?", "ground_truth": "The process by which plants convert light energy into chemical energy"}
        ],
        "Reasoning": [
            {"prompt": "If all roses are flowers and some flowers are red, can we conclude that some roses are red?", "ground_truth": "No, we cannot conclude that some roses are red based on the given information"},
            {"prompt": "A train travels 80 km/h to a destination and returns at 120 km/h. If total time is 5 hours, what's the distance?", "ground_truth": "240 km"},
            {"prompt": "What logical fallacy involves attacking the person rather than their argument?", "ground_truth": "Ad hominem"}
        ]
    }
    
    selected_template = st.selectbox(
        "Choose a template:",
        list(templates.keys())
    )
    
    if selected_template:
        template_cases = templates[selected_template]
        
        st.markdown(f"#### 📋 {selected_template} Test Cases")
        
        for i, case in enumerate(template_cases):
            with st.expander(f"Test Case {i+1}"):
                st.markdown(f"**Prompt:** {case['prompt']}")
                st.markdown(f"**Expected Answer:** {case['ground_truth']}")
        
        if st.button(f"📥 Import {selected_template} Template", type="primary"):
            imported_cases = []
            for i, case in enumerate(template_cases):
                test_case = {
                    'id': i + 1,
                    'prompt': case['prompt'],
                    'ground_truth': case['ground_truth'],
                    'category': selected_template,
                    'difficulty': 'Medium',
                    'criteria': ['Accuracy', 'Completeness']
                }
                imported_cases.append(test_case)
            
            st.session_state.test_cases = imported_cases
            show_success_message(f"Imported {len(imported_cases)} test cases from {selected_template} template!")

def export_test_cases():
    """Export test cases as JSON"""
    
    test_cases_json = json.dumps(st.session_state.test_cases, indent=2)
    
    st.download_button(
        "📥 Download Test Cases JSON",
        test_cases_json,
        f"test_cases_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.json",
        "application/json"
    )

def show_run_evaluation_tab():
    """Show evaluation execution tab"""
    
    st.markdown("### 🚀 Run Model Evaluation")
    
    # Check prerequisites
    if 'evaluation_config' not in st.session_state:
        st.warning("Please configure the evaluation setup first.")
        return
    
    if 'test_cases' not in st.session_state or not st.session_state.test_cases:
        st.warning("Please create test cases first.")
        return
    
    config = st.session_state.evaluation_config
    test_cases = st.session_state.test_cases
    
    # Show evaluation summary
    st.markdown("#### 📊 Evaluation Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        total_models = len(config['openai']['models']) + len(config['gemini']['models'])+len(config['bedrock']['models'])
        st.metric("Models to Evaluate", total_models)
    
    with col2:
        st.metric("Test Cases", len(test_cases))
    
    with col3:
        total_evaluations = total_models * len(test_cases)
        st.metric("Total Evaluations", total_evaluations)
    
    with col4:
        estimated_time = (total_evaluations * 3) / 60  # Assuming 3 seconds per evaluation
        st.metric("Est. Time", f"{estimated_time:.1f} min")
    
    # Model selection for evaluation
    st.markdown("#### 🤖 Select Models to Evaluate")
    
    col1, col2,col3 = st.columns(3)
    
    with col1:
        st.markdown("**OpenAI Models:**")
        selected_openai = []
        for model in config['openai']['models']:
            if st.checkbox(f"OpenAI: {model}", value=True, key=f"openai_{model}"):
                selected_openai.append(model)
    
    with col2:
        st.markdown("**Gemini Models:**")
        selected_gemini = []
        for model in config['gemini']['models']:
            if st.checkbox(f"Gemini: {model}", value=True, key=f"gemini_{model}"):
                selected_gemini.append(model)

    with col3:
        st.markdown("**Bedrock Models:**")
        selected_bedrock_models = []
        for model in config['bedrock']['models']:
            if st.checkbox(f"Bedrock: {model}", value=True, key=f"Bedrock{model}"):
                selected_bedrock_models.append(model)
    
    # Test case selection
    st.markdown("#### 📝 Select Test Cases")
    
    test_case_options = [f"Test {tc['id']}: {tc['category']} - {tc['prompt'][:50]}..." for tc in test_cases]
    selected_test_indices = st.multiselect(
        "Choose test cases to run:",
        range(len(test_cases)),
        default=list(range(len(test_cases))),
        format_func=lambda i: test_case_options[i]
    )
    
    # Run evaluation
    if st.button("🚀 Start Evaluation", type="primary", use_container_width=True):
        if selected_openai or selected_gemini:
            if selected_test_indices:
                run_model_evaluation(selected_openai, selected_gemini,selected_bedrock_models, selected_test_indices)
            else:
                show_error_message("Please select at least one test case!")
        else:
            show_error_message("Please select at least one model!")

def run_model_evaluation(openai_models: List[str], gemini_models: List[str], bedrock_models: List[str] ,test_indices: List[int]):
    """Run the model evaluation using backend API"""
    
    try:
        config = st.session_state.evaluation_config
        test_cases = st.session_state.test_cases
        selected_tests = [test_cases[i] for i in test_indices]
        use_case_id = config.get('use_case_id')
        
        with show_loading_spinner("Running model evaluation... This may take several minutes."):
            
            # FIXED: Create CSV file from test cases for upload
            import io
            import csv
            
            # Create CSV content from test cases
            csv_buffer = io.StringIO()
            csv_writer = csv.writer(csv_buffer)
            csv_writer.writerow(['prompt', 'ground_truth', 'category', 'difficulty'])
            
            for test_case in selected_tests:
                csv_writer.writerow([
                    test_case['prompt'],
                    test_case['ground_truth'],
                    test_case.get('category', 'General'),
                    test_case.get('difficulty', 'Medium')
                ])
            
            csv_content = csv_buffer.getvalue().encode('utf-8')
            
            # FIXED: Prepare form data instead of JSON
            # Combine all selected models
            all_models = openai_models + gemini_models+bedrock_models
            models_str = ','.join(all_models)
            
            # Prepare API keys dictionary
            api_keys_dict = {}
            if openai_models and config['openai']['api_key']:
                api_keys_dict['openai'] = config['openai']['api_key']
            if gemini_models and config['gemini']['api_key']:
                api_keys_dict['gemini'] = config['gemini']['api_key']
            
            if bedrock_models and config['bedrock']['api_key']:
                api_keys_dict['bedrock'] = config['bedrock']['api_key']
            
            # FIXED: Use multipart form data as expected by backend
            files = {
                'file': ('test_cases.csv', io.BytesIO(csv_content), 'text/csv')
            }
            
            form_data = {
                'models': models_str,
                'api_keys': json.dumps(api_keys_dict),
                'use_llm_judge': str(config['evaluation']['use_llm_judge']).lower(),
                'max_tokens': str(config['evaluation']['max_tokens']),
                'temperature': str(config['evaluation']['temperature'])
            }
            
            headers = get_auth_headers()
            # Remove Content-Type to let requests handle multipart
            if 'Content-Type' in headers:
                del headers['Content-Type']
            

            # FIXED: Use the correct endpoint
            endpoint = f"{API_ENDPOINTS['reports']['save'].replace('/reports/save', '')}/model-evaluation/analyze"
            
            response = requests.post(
                endpoint,
                files=files,
                data=form_data,
                headers=headers,
                timeout=1800  # 30 minute timeout for evaluation
            )
            
            if response.status_code == 200:
                evaluation_results = response.json()
                st.session_state.evaluation_results = evaluation_results
                print("*******Evaluation results:", evaluation_results)
                # Save the eprivaluation report
                save_evaluation_report(evaluation_results, use_case_id)
                
                show_success_message("Model evaluation completed successfully!")
                st.rerun()  # Refresh to show results
            else:
                error_detail = "Unknown error"
                try:
                    error_data = response.json()
                    error_detail = error_data.get('detail', response.text)
                except:
                    error_detail = response.text
                
                show_error_message(f"Evaluation failed: {error_detail}")
        
    except requests.exceptions.Timeout:
        show_error_message("Evaluation timed out. Please try with fewer test cases or models.")
    except Exception as e:
        show_error_message(f"Error running evaluation: {str(e)}")

def save_evaluation_report(results, use_case_id):
    """Save evaluation report to database"""
    try:
        import json
        print("*******Saving evaluation report results value:", results)
        # FIXED: Update the response structure to match backend
        report_results = {
            "collective_results": results.get("overall_results", {}),
            "model_summaries": results.get("evaluation_summary", {}),
            "individual_results": results.get("detailed_results", [])
        }
        
        
        # Convert results to JSON bytes for database storage
        report_content = json.dumps(report_results, indent=2, default=str).encode('utf-8')
        print("*******Report results structure:", report_results)
        # Get use case details for report name
        use_case = st.session_state.get('selected_use_case_for_data', {})
        use_case_title = use_case.get('title', 'Model Evaluation') if isinstance(use_case, dict) else 'Model Evaluation'
        
        # Save using StreamlitReportManager
        report_data = StreamlitReportManager.save_report_to_database(
            file_content=report_content,
            module_name="model_evaluation",
            module_entity_id=use_case_id,
            report_name=f"Model Evaluation Report - {use_case_title}",
            report_type="json",
            filename=f"model_evaluation_{use_case_id}.json"
        )
        
        if report_data:
            st.session_state.saved_evaluation_report_id = report_data.get('id')
            # Mark evaluation as completed for next steps
            st.session_state.evaluation_completed = True
            # FIXED: Store the corrected results structure
            st.session_state.evaluation_results = report_results
        
    except Exception as e:
        st.warning(f"Report saved locally but failed to save to database: {str(e)}")

def show_results_tab():
    """Show evaluation results"""
    
    st.markdown("### 📊 Evaluation Results")
    
    if 'evaluation_results' not in st.session_state:
        st.info("No evaluation results available. Please run the evaluation first.")
        return
    
    results = st.session_state.evaluation_results
    collective = results.get('collective_results', {})
    model_summaries_text = results.get('model_summaries', '')  # This is a string, not dict
    individual_results = results.get('individual_results', [])
    
    # Overall results summary
    st.markdown("#### 📈 Overall Results Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(
            create_metric_card(
                "Models Tested",
                str(collective.get('total_models', 0)),
                None,
                "#3182ce"
            ),
            unsafe_allow_html=True
        )
    
    with col2:
        st.markdown(
            create_metric_card(
                "Test Cases",
                str(collective.get('total_test_cases', 0)),
                None,
                "#38a169"
            ),
            unsafe_allow_html=True
        )
    
    with col3:
        st.markdown(
            create_metric_card(
                "Avg Accuracy",
                f"{collective.get('overall_average_accuracy', 0):.1f}%",
                None,
                "#d69e2e"
            ),
            unsafe_allow_html=True
        )
    
    with col4:
        st.markdown(
            create_metric_card(
                "Best Model",
                collective.get('best_performing_model', 'N/A'),
                None,
                "#9f7aea"
            ),
            unsafe_allow_html=True
        )
    
    # Model rankings
    st.markdown("#### 🏆 Model Rankings")
    
    rankings = collective.get('model_rankings', [])
    if rankings:
        rankings_df = pd.DataFrame(rankings)
        rankings_df['Rank'] = range(1, len(rankings_df) + 1)
        rankings_df = rankings_df[['Rank', 'model_name', 'average_accuracy_score', 'accuracy_percentage', 'average_response_time']]
        rankings_df.columns = ['Rank', 'Model', 'Avg Score (%)', 'Binary Accuracy (%)', 'Avg Response Time (s)']
        
        st.dataframe(rankings_df, use_container_width=True)
    
    # Show evaluation summary text
    if model_summaries_text:
        st.markdown("#### 📝 Evaluation Summary")
        st.markdown(model_summaries_text)
    
    # Process individual results to create model summaries
    if individual_results:
        st.markdown("#### 🔍 Detailed Model Results")
        
        # Group individual results by model
        model_data = {}
        for result in individual_results:
            model_name = result.get('model_name', 'Unknown')
            if model_name not in model_data:
                model_data[model_name] = []
            model_data[model_name].append(result)
        
        # Calculate model summaries from individual results
        model_summaries = {}
        for model_name, results in model_data.items():
            # Filter out error results for calculations
            valid_results = [r for r in results if not r.get('response', '').startswith('ERROR:')]
            
            if valid_results:
                avg_accuracy = sum(r.get('accuracy_score', 0) for r in valid_results) / len(valid_results)
                avg_response_time = sum(r.get('response_time', 0) for r in valid_results) / len(valid_results)
                accuracy_percentage = (sum(1 for r in valid_results if r.get('is_correct', False)) / len(valid_results)) * 100
            else:
                avg_accuracy = 0
                avg_response_time = 0
                accuracy_percentage = 0
            
            model_summaries[model_name] = {
                'accuracy_percentage': accuracy_percentage,
                'average_accuracy_score': avg_accuracy,
                'average_response_time': avg_response_time,
                'detailed_results': results
            }
        
        # Model selection dropdown
        selected_model = st.selectbox(
            "Select model for detailed view:",
            list(model_summaries.keys()) if model_summaries else []
        )
        
        if selected_model and selected_model in model_summaries:
            model_data = model_summaries[selected_model]
            
            # Model performance metrics
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Binary Accuracy", f"{model_data.get('accuracy_percentage', 0):.1f}%")
            with col2:
                st.metric("LLM Judge Score", f"{model_data.get('average_accuracy_score', 0):.1f}%")
            with col3:
                st.metric("Avg Response Time", f"{model_data.get('average_response_time', 0):.2f}s")
            
            # Individual test results
            st.markdown("**Individual Test Results:**")
            
            detailed_results = model_data.get('detailed_results', [])
            if detailed_results:
                results_df = pd.DataFrame([
                    {
                        'Test': r['prompt'][:50] + "..." if len(r['prompt']) > 50 else r['prompt'],
                        'Correct': "✅" if r.get('is_correct', False) else "❌",
                        'Score': f"{r.get('accuracy_score', 0):.1f}%",
                        'Response Time': f"{r.get('response_time', 0):.2f}s",
                        'Status': "Error" if r.get('response', '').startswith('ERROR:') else "Success"
                    }
                    for r in detailed_results
                ])
                
                st.dataframe(results_df, use_container_width=True)
                
                # Show individual responses
                with st.expander("👁️ View Individual Responses"):
                    for i, result in enumerate(detailed_results):
                        st.markdown(f"**Test {i+1}:** {result.get('prompt', '')}")
                        
                        if result.get('response', '').startswith('ERROR:'):
                            st.error(f"**Error:** {result.get('response', '')}")
                        else:
                            st.markdown(f"**Model Response:** {result.get('response', '')}")
                            st.markdown(f"**Expected Answer:** {result.get('ground_truth', '')}")
                            st.markdown(f"**Score:** {result.get('accuracy_score', 0):.1f}% - {result.get('judge_explanation', '')}")
                        
                        st.markdown("---")
    
    # Comparison chart
    st.markdown("#### 📊 Model Comparison")
    
    if individual_results:
        # Create comparison DataFrame from individual results
        comparison_data = []
        model_stats = {}
        
        for result in individual_results:
            model_name = result.get('model_name', 'Unknown')
            if model_name not in model_stats:
                model_stats[model_name] = {
                    'scores': [],
                    'times': []
                }
            
            # Only include valid results (not errors)
            if not result.get('response', '').startswith('ERROR:'):
                model_stats[model_name]['scores'].append(result.get('accuracy_score', 0))
                model_stats[model_name]['times'].append(result.get('response_time', 0))
        
        for model_name, stats in model_stats.items():
            avg_score = sum(stats['scores']) / len(stats['scores']) if stats['scores'] else 0
            avg_time = sum(stats['times']) / len(stats['times']) if stats['times'] else 0
            
            comparison_data.append({
                'Model': model_name,
                'Accuracy Score': avg_score,
                'Response Time': avg_time
            })
        
        if comparison_data:
            comparison_df = pd.DataFrame(comparison_data)
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Accuracy Scores**")
                st.bar_chart(comparison_df.set_index('Model')['Accuracy Score'])
            
            with col2:
                st.markdown("**Response Times**")
                st.bar_chart(comparison_df.set_index('Model')['Response Time'])
    
    # Export results
    st.markdown("---")
    col1, col2, col3 = st.columns([1, 1, 1])
    
    with col1:
        if st.button("📄 Generate PDF Report", type="primary", use_container_width=True):
            generate_evaluation_report('pdf')
    
    with col2:
        if st.button("📊 Export Excel Report", use_container_width=True):
            generate_evaluation_report('excel')
    
    with col3:
        if st.button("📋 Export JSON Data", use_container_width=True):
            generate_evaluation_report('json')


def generate_evaluation_report(format_type: str):
    """Generate evaluation report using backend API"""
    
    try:
        results = st.session_state.evaluation_results
        use_case_id = st.session_state.get('selected_use_case_id')
        use_case = st.session_state.get('selected_use_case_for_data', {})
        
        with show_loading_spinner(f"Generating {format_type.upper()} evaluation report..."):
            headers = get_auth_headers()
            
            if format_type == 'pdf':
                # Transform data structure to match what PDF generator expects
                title = f"Model Evaluation Report - {use_case.get('title', 'Assessment') if isinstance(use_case, dict) else 'Assessment'}"
                
                # Get the data
                collective = results.get("collective_results", {})
                individual = results.get("individual_results", [])
                
                # Get evaluation summary (this is a string, not dict)
                evaluation_summary = results.get("model_summaries", "")
                
                # Ensure we have a meaningful summary
                if not evaluation_summary or evaluation_summary.strip() == "":
                    # Generate a basic summary from the available data
                    total_models = collective.get("total_models", 0)
                    best_model = collective.get("best_performing_model", "N/A")
                    avg_score = collective.get("overall_average_score", 0)
                    
                    evaluation_summary = f"""
## Model Evaluation Summary

This evaluation assessed {total_models} model(s) with an overall average score of {avg_score:.2f}%.

**Key Findings:**
- Best performing model: {best_model}
- Average accuracy: {collective.get('overall_average_accuracy', 0):.2f}%
- Total test cases evaluated: {collective.get('total_test_cases', 0)}

**Performance Analysis:**
The evaluation shows {'consistent' if collective.get('performance_variance', 0) < 10 else 'varying'} performance across the tested models.
"""
                
                transformed_results = {
                    "evaluation_id": results.get("evaluation_id", "N/A"),
                    "total_test_cases": collective.get("total_test_cases", 0),
                    "models_evaluated": list(set([item.get("model_name", "") for item in individual])) if individual else [],
                    "overall_results": collective,
                    "detailed_results": individual,
                    "best_performing_model": collective.get("best_performing_model", "N/A"),
                    "worst_performing_model": collective.get("worst_performing_model", "N/A"),
                    "evaluation_summary": evaluation_summary,
                    "generated_at": results.get("generated_at", pd.Timestamp.now().isoformat())
                }
                
                # Convert to JSON string
                evaluation_results_json = json.dumps(transformed_results, default=str)
                
                # Use form data (application/x-www-form-urlencoded)
                form_data = {
                    'evaluation_results': evaluation_results_json,
                    'title': title
                }
                
                # Set headers
                headers = get_auth_headers()
                headers['Content-Type'] = 'application/x-www-form-urlencoded'
                
                response = requests.post(
                    f"{API_ENDPOINTS['reports']['save'].replace('/reports/save', '')}/model-evaluation/generate-pdf",
                    data=form_data,
                    headers=headers,
                    timeout=120
                )
                
                if response.status_code == 200:
                    report_content = response.content
                    filename = f"model_evaluation_report_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                    
                    # Save to database using StreamlitReportManager
                    if use_case_id:
                        use_case_title = use_case.get('title', 'Model Evaluation') if isinstance(use_case, dict) else 'Model Evaluation'
                        StreamlitReportManager.save_report_to_database(
                            file_content=report_content,
                            module_name="model_evaluation",
                            module_entity_id=use_case_id,
                            report_name=f"Model Evaluation PDF Report - {use_case_title}",
                            report_type="pdf",
                            filename=filename
                        )
                    
                    st.download_button(
                        label="📥 Download PDF Report",
                        data=report_content,
                        file_name=filename,
                        mime="application/pdf",
                        use_container_width=True
                    )
                    show_success_message("PDF evaluation report generated and saved successfully!")
                else:
                    error_detail = "Unknown error"
                    try:
                        error_data = response.json()
                        error_detail = error_data.get('detail', response.text)
                    except:
                        error_detail = response.text
                    show_error_message(f"Failed to generate PDF: {error_detail}")
                
            elif format_type == 'excel':
                # Create Excel report locally
                import io
                output = io.BytesIO()
                
                with pd.ExcelWriter(output, engine='openpyxl') as writer:
                    # Model rankings
                    rankings = results.get('collective_results', {}).get('model_rankings', [])
                    if rankings:
                        rankings_df = pd.DataFrame(rankings)
                        rankings_df.to_excel(writer, sheet_name='Model Rankings', index=False)
                    
                    # Individual results
                    individual_results = results.get('individual_results', [])
                    if individual_results:
                        individual_df = pd.DataFrame(individual_results)
                        individual_df.to_excel(writer, sheet_name='Individual Results', index=False)
                
                report_content = output.getvalue()
                filename = f"model_evaluation_report_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
                
                # Save to database using StreamlitReportManager
                if use_case_id:
                    use_case_title = use_case.get('title', 'Model Evaluation') if isinstance(use_case, dict) else 'Model Evaluation'
                    StreamlitReportManager.save_report_to_database(
                        file_content=report_content,
                        module_name="model_evaluation",
                        module_entity_id=use_case_id,
                        report_name=f"Model Evaluation Excel Report - {use_case_title}",
                        report_type="xlsx",
                        filename=filename
                    )
                
                st.download_button(
                    label="📥 Download Excel Report",
                    data=report_content,
                    file_name=filename,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True
                )
                show_success_message("Excel evaluation report generated and saved successfully!")
                
            else:  # json
                report_content = json.dumps(results, indent=2, default=str).encode()
                filename = f"model_evaluation_data_{pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')}.json"
                
                # Save to database using StreamlitReportManager
                if use_case_id:
                    use_case_title = use_case.get('title', 'Model Evaluation') if isinstance(use_case, dict) else 'Model Evaluation'
                    StreamlitReportManager.save_report_to_database(
                        file_content=report_content,
                        module_name="model_evaluation",
                        module_entity_id=use_case_id,
                        report_name=f"Model Evaluation JSON Data - {use_case_title}",
                        report_type="json",
                        filename=filename
                    )
                
                st.download_button(
                    label="📥 Download JSON Data",
                    data=report_content,
                    file_name=filename,
                    mime="application/json",
                    use_container_width=True
                )
                show_success_message("JSON evaluation data exported and saved successfully!")
        
    except Exception as e:
        show_error_message(f"Error generating report: {str(e)}")

if __name__ == "__main__":
    main()