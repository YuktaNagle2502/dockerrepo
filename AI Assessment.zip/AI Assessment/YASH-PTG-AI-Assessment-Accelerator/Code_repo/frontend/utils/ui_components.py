"""
UI Components and styling utilities for the GenAI Assessment Platform
"""
import streamlit as st
import time
from typing import List, Dict, Any, Optional
from utils.config import UI_CONFIG, WORKFLOW_STAGES

def apply_custom_css():
    """Apply custom CSS styling to the Streamlit app"""
    
    css = f"""
    <style>
    /* Import Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    /* Global Styles */
    .stApp {{
        font-family: 'Inter', sans-serif;
        background: linear-gradient(135deg, {UI_CONFIG['theme']['background_color']} 0%, #ffffff 100%);
    }}
    
    /* Header Styles */
    .main-header {{
        text-align: center;
        padding: 2rem 0;
        background: linear-gradient(135deg, {UI_CONFIG['theme']['primary_color']} 0%, {UI_CONFIG['theme']['secondary_color']} 100%);
        color: white;
        border-radius: 15px;
        margin-bottom: 2rem;
        box-shadow: 0 10px 30px rgba(31, 78, 121, 0.3);
    }}
    
    .main-header h1 {{
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }}
    
    .main-header p {{
        font-size: 1.2rem;
        opacity: 0.9;
        font-weight: 300;
    }}
    
    .dashboard-header {{
        padding: 1rem 0;
        border-bottom: 2px solid {UI_CONFIG['theme']['primary_color']};
        margin-bottom: 1rem;
    }}
    
    .dashboard-header h1 {{
        color: {UI_CONFIG['theme']['primary_color']};
        font-size: 2rem;
        font-weight: 600;
        margin-bottom: 0.5rem;
    }}
    
    /* Card Styles */
    .metric-card {{
        background: white;
        padding: 1.5rem;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border: 1px solid #e2e8f0;
        transition: transform {UI_CONFIG['animations']['transition_duration']}, box-shadow {UI_CONFIG['animations']['transition_duration']};
        margin-bottom: 1rem;
    }}
    
    .metric-card:hover {{
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }}
    
    .project-card {{
        background: white;
        padding: 1.5rem;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border-left: 4px solid {UI_CONFIG['theme']['primary_color']};
        margin-bottom: 1rem;
        transition: transform {UI_CONFIG['animations']['transition_duration']};
    }}
    
    .project-card:hover {{
        transform: scale({UI_CONFIG['animations']['hover_scale']});
    }}
    
    /* Button Styles */
    .stButton > button {{
        border-radius: 8px;
        border: none;
        transition: all {UI_CONFIG['animations']['transition_duration']};
        font-weight: 500;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }}
    
    .stButton > button:hover {{
        transform: translateY(-1px);
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    }}
    
    /* Stage Progress Styles */
    .stage-container {{
        display: flex;
        align-items: center;
        padding: 1rem;
        margin: 0.5rem 0;
        border-radius: 10px;
        background: white;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        transition: all {UI_CONFIG['animations']['transition_duration']};
    }}
    
    .stage-container:hover {{
        box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        transform: translateX(5px);
    }}
    
    .stage-icon {{
        font-size: 2rem;
        margin-right: 1rem;
        opacity: 0.7;
    }}
    
    .stage-content {{
        flex: 1;
    }}
    
    .stage-title {{
        font-weight: 600;
        color: {UI_CONFIG['theme']['text_color']};
        margin-bottom: 0.25rem;
    }}
    
    .stage-description {{
        color: #718096;
        font-size: 0.9rem;
    }}
    
    .stage-status {{
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
        margin-left: 1rem;
    }}
    
    .status-completed {{
        background: {UI_CONFIG['theme']['success_color']};
        color: white;
    }}
    
    .status-in-progress {{
        background: {UI_CONFIG['theme']['warning_color']};
        color: white;
    }}
    
    .status-pending {{
        background: #e2e8f0;
        color: #4a5568;
    }}
    
    /* Form Styles */
    .stTextInput > div > div > input {{
        border-radius: 8px;
        border: 2px solid #e2e8f0;
        transition: border-color {UI_CONFIG['animations']['transition_duration']};
    }}
    
    .stTextInput > div > div > input:focus {{
        border-color: {UI_CONFIG['theme']['primary_color']};
        box-shadow: 0 0 0 3px rgba(49, 130, 206, 0.1);
    }}
    
    /* File Upload Styles */
    .uploadedFile {{
        border-radius: 8px;
        border: 2px dashed {UI_CONFIG['theme']['primary_color']};
        padding: 2rem;
        text-align: center;
        background: #f8f9ff;
    }}
    
    /* Progress Bar Styles */
    .stProgress > div > div > div > div {{
        background: linear-gradient(90deg, {UI_CONFIG['theme']['primary_color']} 0%, {UI_CONFIG['theme']['success_color']} 100%);
        border-radius: 10px;
    }}
    
    /* Success/Error Message Styles */
    .success-message {{
        background: {UI_CONFIG['theme']['success_color']};
        color: white;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
        font-weight: 500;
        box-shadow: 0 4px 15px rgba(56, 161, 105, 0.3);
    }}
    
    .error-message {{
        background: {UI_CONFIG['theme']['error_color']};
        color: white;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
        font-weight: 500;
        box-shadow: 0 4px 15px rgba(229, 62, 62, 0.3);
    }}
    
    .warning-message {{
        background: {UI_CONFIG['theme']['warning_color']};
        color: white;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
        font-weight: 500;
        box-shadow: 0 4px 15px rgba(214, 158, 46, 0.3);
    }}
    
    /* Sidebar Styles */
    .css-1d391kg {{
        background: linear-gradient(180deg, {UI_CONFIG['theme']['primary_color']} 0%, {UI_CONFIG['theme']['secondary_color']} 100%);
    }}
    
    /* Hide Streamlit branding */

    
    /* Animation for loading */
    @keyframes pulse {{
        0% {{ opacity: 1; }}
        50% {{ opacity: 0.5; }}
        100% {{ opacity: 1; }}
    }}
    
    .loading {{
        animation: pulse 2s infinite;
    }}
    </style>
    """
    
    st.markdown(css, unsafe_allow_html=True)

def show_success_message(message: str, duration: int = 3):
    """Display a success message with custom styling"""
    placeholder = st.empty()
    placeholder.markdown(f'''
    <div class="success-message">
        ✅ {message}
    </div>
    ''', unsafe_allow_html=True)
    
    if duration > 0:
        time.sleep(duration)
        placeholder.empty()

def show_error_message(message: str, duration: int = 0):
    """Display an error message with custom styling"""
    st.markdown(f'''
    <div class="error-message">
        ❌ {message}
    </div>
    ''', unsafe_allow_html=True)

def show_warning_message(message: str, duration: int = 0):
    """Display a warning message with custom styling"""
    st.markdown(f'''
    <div class="warning-message">
        ⚠️ {message}
    </div>
    ''', unsafe_allow_html=True)

def create_metric_card(title: str, value: str, delta: Optional[str] = None, color: str = "#3182ce"):
    """Create a custom metric card"""
    delta_html = f"<p style='color: {color}; font-size: 0.9rem; margin: 0;'>{delta}</p>" if delta else ""
    
    return f'''
    <div class="metric-card">
        <h3 style="color: {color}; margin: 0 0 0.5rem 0; font-size: 1.1rem;">{title}</h3>
        <p style="font-size: 2rem; font-weight: 700; margin: 0; color: #2d3748;">{value}</p>
        {delta_html}
    </div>
    '''

def create_project_card(project: Dict[str, Any]):
    """Create a project card with information"""
    return f'''
    <div class="project-card">
        <h3 style="color: {UI_CONFIG['theme']['primary_color']}; margin: 0 0 0.5rem 0;">{project.get('name', 'Unnamed Project')}</h3>
        <p style="color: #718096; margin: 0 0 1rem 0;">{project.get('description', 'No description available')}</p>
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="color: #4a5568; font-size: 0.9rem;">Created: {project.get('created_at', 'Unknown')}</span>
            <span style="background: {UI_CONFIG['theme']['success_color']}; color: white; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem;">
                {"Active" if project.get('is_active', True) else "Inactive"}
            </span>
        </div>
    </div>
    '''

def show_workflow_progress(completed_stages: List[int], current_stage: int = 1):
    """Display workflow progress with stage indicators"""
    st.markdown("### 🎯 Assessment Progress")
    
    for stage_num, stage_info in WORKFLOW_STAGES.items():
        if stage_num in completed_stages:
            status = "completed"
            status_text = "Completed ✅"
            status_class = "status-completed"
        elif stage_num == current_stage:
            status = "in-progress"
            status_text = "In Progress 🔄"
            status_class = "status-in-progress"
        else:
            status = "pending"
            status_text = "Pending ⏳"
            status_class = "status-pending"
        
        st.markdown(f'''
        <div class="stage-container">
            <div class="stage-icon">{stage_info['icon']}</div>
            <div class="stage-content">
                <div class="stage-title">{stage_info['name']}</div>
                <div class="stage-description">{stage_info['description']}</div>
            </div>
            <div class="stage-status {status_class}">{status_text}</div>
        </div>
        ''', unsafe_allow_html=True)

def create_file_uploader(label: str, accept_multiple: bool = False, key: str = None):
    """Create a styled file uploader"""
    accepted_types = ['.csv', '.xlsx', '.xls', '.json', '.txt', '.pdf']
    
    return st.file_uploader(
        label,
        accept_multiple_files=accept_multiple,
        type=[t.replace('.', '') for t in accepted_types],
        key=key,
        help=f"Supported formats: {', '.join(accepted_types)}"
    )

def show_loading_spinner(message: str = "Processing..."):
    """Show a loading spinner with message"""
    return st.spinner(message)

def create_data_table(data: List[Dict], title: str = "Data Preview"):
    """Create a styled data table"""
    if not data:
        st.info("No data available")
        return
    
    st.markdown(f"### {title}")
    st.dataframe(
        data,
        use_container_width=True,
        hide_index=True
    )

def create_download_button(data, filename: str, label: str = "Download", mime_type: str = "text/csv"):
    """Create a styled download button"""
    return st.download_button(
        label=label,
        data=data,
        file_name=filename,
        mime=mime_type,
        use_container_width=True,
        type="primary"
    )

def show_sidebar_navigation():
    """Show sidebar navigation"""
    with st.sidebar:
        st.markdown("### 🧭 Navigation")
        
        pages = [
            ("🏠", "Home", "Home.py"),
            ("📊", "Projects", "pages/1_📊_Project_Management.py"),
            ("🧠", "Use Cases", "pages/2_🧠_Use_Case_Generation.py"),
            ("📈", "Data Readiness", "pages/3_📈_Data_Readiness.py"),
            ("🔒", "Compliance", "pages/4_🔒_Data_Compliance.py"),
            ("🤖", "AI Profiling", "pages/5_🤖_AI_Profiling.py"),
            ("⚡", "Model Evaluation", "pages/6_⚡_Model_Evaluation.py"),
            ("📋", "Reports", "pages/7_📋_Reports_Dashboard.py")
        ]
        
        for icon, name, page in pages:
            if st.button(f"{icon} {name}", use_container_width=True):
                st.switch_page(page)
        
        st.markdown("---")
        
        # User info
        if st.session_state.get('authenticated'):
            user_data = st.session_state.get('user_data', {})
            st.markdown(f"**Logged in as:**")
            st.markdown(f"👤 {user_data.get('full_name', 'User')}")
            st.markdown(f"📧 {user_data.get('email', 'email@example.com')}")
