"""
Configuration settings for the GenAI Assessment Platform
"""
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# API Configuration
API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")

# Database Configuration
DATABASE_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": os.getenv("DB_PORT", "5432"),
    "database": os.getenv("DB_NAME", "genai_assessment"),
    "user": os.getenv("DB_USER", "postgres"),
    "password": os.getenv("DB_PASSWORD", "")
}

# App Configuration
APP_CONFIG = {
    "app_name": "GenAI Assessment Platform",
    "version": "1.0.0",
    "description": "Comprehensive AI-powered assessment and evaluation platform",
    "author": "GenAI Team",
    "max_file_size": 100 * 1024 * 1024,  # 100MB
    "allowed_file_types": ['.csv', '.xlsx', '.xls', '.json', '.txt', '.pdf'],
    "session_timeout": 3600,  # 1 hour in seconds
}

# UI Configuration
UI_CONFIG = {
    "theme": {
        "primary_color": "#1f4e79",
        "secondary_color": "#2c5282",
        "success_color": "#38a169",
        "warning_color": "#d69e2e",
        "error_color": "#e53e3e",
        "background_color": "#f7fafc",
        "text_color": "#2d3748"
    },
    "animations": {
        "transition_duration": "0.3s",
        "hover_scale": "1.02",
        "loading_color": "#3182ce"
    }
}

# File Storage Configuration
STORAGE_CONFIG = {
    "upload_folder": "data/uploads",
    "reports_folder": "data/reports",
    "temp_folder": "data/temp",
    "max_storage_size": 1024 * 1024 * 1024,  # 1GB
}

# API Endpoints
API_ENDPOINTS = {
    "auth": {
        "login": f"{API_BASE_URL}/auth/login",
        "register": f"{API_BASE_URL}/auth/register",
        "me": f"{API_BASE_URL}/auth/me",
        "logout": f"{API_BASE_URL}/auth/logout"
    },
    "projects": {
        "create": f"{API_BASE_URL}/auth/projects",
        "list": f"{API_BASE_URL}/auth/projects",
        "get": f"{API_BASE_URL}/auth/projects/{{project_id}}",
        "update": f"{API_BASE_URL}/auth/projects/{{project_id}}",
        "delete": f"{API_BASE_URL}/auth/projects/{{project_id}}"
    },
    "pre_workshop": {
        "sessions": f"{API_BASE_URL}/pre-workshop/sessions",
        "upload": f"{API_BASE_URL}/pre-workshop/sessions/{{session_id}}/upload-questionnaire",
        "generate_use_cases": f"{API_BASE_URL}/pre-workshop/sessions/{{session_id}}/generate-use-cases",
        "reports": f"{API_BASE_URL}/pre-workshop/sessions/{{session_id}}/generate-report"
    },
    "reports": {
        "save": f"{API_BASE_URL}/reports/save",
        "list": f"{API_BASE_URL}/reports",
        "get": f"{API_BASE_URL}/reports/{{report_uuid}}",
        "download": f"{API_BASE_URL}/reports/download/{{report_uuid}}",
        "delete": f"{API_BASE_URL}/reports/{{report_uuid}}",
        "user": f"{API_BASE_URL}/reports/user",
        "project": f"{API_BASE_URL}/reports/project/{{project_id}}",
        "module": f"{API_BASE_URL}/reports/module/{{module_name}}"
    },
    "data_readiness": {
        "analyze": f"{API_BASE_URL}/data-readiness/analyze",
        "generate_pdf": f"{API_BASE_URL}/data-readiness/generate-pdf"
    },
    "compliance": {
        "analyze": f"{API_BASE_URL}/compliance/analyze",
        "supported_formats": f"{API_BASE_URL}/compliance/supported-formats"
    },
    "ai_profiling": {
        "analyze": f"{API_BASE_URL}/data-profiling/analyze",
       "generate_pdf": f"{API_BASE_URL}/data-profiling/generate-pdf"
    }
}



# Workflow Stages Configuration
WORKFLOW_STAGES = {
    1: {
        "name": "Use Case Generation",
        "description": "Generate AI use cases from questionnaire responses",
        "icon": "🧠",
        "color": "#3182ce"
    },
    2: {
        "name": "Data Readiness Assessment",
        "description": "Assess data quality and readiness for AI implementation",
        "icon": "📈",
        "color": "#38a169"
    },
    3: {
        "name": "Data Compliance Check",
        "description": "Verify data compliance and security requirements",
        "icon": "🔒",
        "color": "#d69e2e"
    },
    4: {
        "name": "AI Profiling",
        "description": "Perform detailed AI model profiling and analysis",
        "icon": "🤖",
        "color": "#9f7aea"
    },
    5: {
        "name": "Model Evaluation",
        "description": "Evaluate and compare different AI model performances",
        "icon": "⚡",
        "color": "#e53e3e"
    },
    6: {
        "name": "Final Report",
        "description": "Generate comprehensive assessment report",
        "icon": "📋",
        "color": "#2d3748"
    }
}

# Error Messages
ERROR_MESSAGES = {
    "auth_failed": "Authentication failed. Please check your credentials.",
    "session_expired": "Your session has expired. Please login again.",
    "file_too_large": f"File size exceeds maximum limit of {APP_CONFIG['max_file_size'] // (1024*1024)}MB",
    "invalid_file_type": f"Invalid file type. Allowed types: {', '.join(APP_CONFIG['allowed_file_types'])}",
    "network_error": "Network error. Please check your connection and try again.",
    "server_error": "Server error. Please try again later.",
    "invalid_input": "Please provide valid input for all required fields."
}

# Success Messages
SUCCESS_MESSAGES = {
    "login_success": "Login successful! Welcome back.",
    "register_success": "Account created successfully! Please login.",
    "project_created": "Project created successfully!",
    "file_uploaded": "File uploaded successfully!",
    "report_generated": "Report generated successfully!",
    "data_saved": "Data saved successfully!"
}
