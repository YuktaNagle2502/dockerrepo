"""
Utility functions for data processing and file handling
"""
import os
import pandas as pd
import json
from pathlib import Path
from typing import List, Dict, Any, Optional
import tempfile
import shutil


def ensure_directory_exists(directory_path: str) -> None:
    """Ensure that a directory exists, create if it doesn't"""
    Path(directory_path).mkdir(parents=True, exist_ok=True)


def save_uploaded_file(uploaded_file, upload_dir: str, filename: str = None) -> str:
    """
    Save an uploaded file to the specified directory
    
    Args:
        uploaded_file: Streamlit uploaded file object
        upload_dir: Directory to save the file
        filename: Optional custom filename
    
    Returns:
        str: Path to the saved file
    """
    ensure_directory_exists(upload_dir)
    
    if filename is None:
        filename = uploaded_file.name
    
    file_path = os.path.join(upload_dir, filename)
    
    with open(file_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    return file_path


def load_csv_file(file_path: str, **kwargs) -> pd.DataFrame:
    """
    Load CSV file with error handling and encoding detection
    
    Args:
        file_path: Path to the CSV file
        **kwargs: Additional arguments for pd.read_csv
    
    Returns:
        pd.DataFrame: Loaded dataframe
    """
    encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
    
    for encoding in encodings:
        try:
            df = pd.read_csv(file_path, encoding=encoding, **kwargs)
            return df
        except UnicodeDecodeError:
            continue
    
    # Fallback to default encoding
    return pd.read_csv(file_path, **kwargs)


def validate_file_type(filename: str, allowed_types: List[str]) -> bool:
    """
    Validate if file type is allowed
    
    Args:
        filename: Name of the file
        allowed_types: List of allowed file extensions
    
    Returns:
        bool: True if file type is allowed
    """
    file_extension = Path(filename).suffix.lower()
    return file_extension in allowed_types


def get_file_size_mb(file_path: str) -> float:
    """Get file size in MB"""
    size_bytes = os.path.getsize(file_path)
    return size_bytes / (1024 * 1024)


def clean_filename(filename: str) -> str:
    """Clean filename for safe storage"""
    # Remove or replace unsafe characters
    unsafe_chars = ['<', '>', ':', '"', '/', '\\', '|', '?', '*']
    clean_name = filename
    
    for char in unsafe_chars:
        clean_name = clean_name.replace(char, '_')
    
    return clean_name


def create_temp_file(suffix: str = '.tmp') -> str:
    """Create a temporary file and return its path"""
    temp_file = tempfile.NamedTemporaryFile(suffix=suffix, delete=False)
    temp_file.close()
    return temp_file.name


def cleanup_temp_files(temp_paths: List[str]) -> None:
    """Clean up temporary files"""
    for path in temp_paths:
        try:
            if os.path.exists(path):
                os.unlink(path)
        except Exception:
            pass  # Ignore cleanup errors


def format_file_size(size_bytes: int) -> str:
    """Format file size in human readable format"""
    if size_bytes == 0:
        return "0B"
    
    size_names = ["B", "KB", "MB", "GB", "TB"]
    import math
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_names[i]}"


def extract_file_metadata(file_path: str) -> Dict[str, Any]:
    """Extract metadata from a file"""
    path = Path(file_path)
    
    metadata = {
        'filename': path.name,
        'extension': path.suffix.lower(),
        'size_bytes': path.stat().st_size,
        'size_formatted': format_file_size(path.stat().st_size),
        'created_time': path.stat().st_ctime,
        'modified_time': path.stat().st_mtime
    }
    
    return metadata


def json_serializable(obj):
    """Make object JSON serializable"""
    if isinstance(obj, pd.Timestamp):
        return obj.isoformat()
    elif isinstance(obj, pd.Series):
        return obj.tolist()
    elif isinstance(obj, pd.DataFrame):
        return obj.to_dict('records')
    elif hasattr(obj, 'isoformat'):
        return obj.isoformat()
    else:
        return str(obj)


def safe_json_dump(data: Any, file_path: str, **kwargs) -> None:
    """Safely dump data to JSON file"""
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, default=json_serializable, ensure_ascii=False, **kwargs)


def safe_json_load(file_path: str) -> Any:
    """Safely load data from JSON file"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def batch_process_files(file_paths: List[str], process_func, batch_size: int = 10):
    """Process files in batches"""
    results = []
    
    for i in range(0, len(file_paths), batch_size):
        batch = file_paths[i:i + batch_size]
        batch_results = []
        
        for file_path in batch:
            try:
                result = process_func(file_path)
                batch_results.append(result)
            except Exception as e:
                batch_results.append({'error': str(e), 'file_path': file_path})
        
        results.extend(batch_results)
    
    return results


def merge_dictionaries(*dicts) -> Dict[str, Any]:
    """Merge multiple dictionaries"""
    result = {}
    for d in dicts:
        if isinstance(d, dict):
            result.update(d)
    return result


def flatten_dict(d: Dict[str, Any], parent_key: str = '', sep: str = '_') -> Dict[str, Any]:
    """Flatten a nested dictionary"""
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def calculate_similarity(text1: str, text2: str) -> float:
    """Calculate similarity between two texts"""
    from difflib import SequenceMatcher
    return SequenceMatcher(None, text1.lower(), text2.lower()).ratio()


def chunk_list(lst: List[Any], chunk_size: int) -> List[List[Any]]:
    """Split a list into chunks of specified size"""
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]


def retry_operation(operation, max_retries: int = 3, delay: float = 1.0):
    """Retry an operation with exponential backoff"""
    import time
    
    for attempt in range(max_retries):
        try:
            return operation()
        except Exception as e:
            if attempt == max_retries - 1:
                raise e
            time.sleep(delay * (2 ** attempt))
