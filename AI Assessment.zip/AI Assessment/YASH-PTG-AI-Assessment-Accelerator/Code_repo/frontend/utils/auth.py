"""
Authentication utilities for the GenAI Assessment Platform
"""
import streamlit as st
import requests
import json
from typing import Dict, Any
from utils.config import API_ENDPOINTS, ERROR_MESSAGES, SUCCESS_MESSAGES

def authenticate_user(email: str, password: str) -> Dict[str, Any]:
    """
    Authenticate user with email and password
    
    Args:
        email: User email
        password: User password
    
    Returns:
        Dict containing success status, user data, and access token
    """
    try:
        payload = {
            "email": email,
            "password": password
        }
        
        response = requests.post(
            API_ENDPOINTS["auth"]["login"],
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            return {
                "success": True,
                "user_data": data["user"],
                "access_token": data["access_token"],
                "message": SUCCESS_MESSAGES["login_success"]
            }
        else:
            error_data = response.json() if response.content else {}
            return {
                "success": False,
                "message": error_data.get("detail", ERROR_MESSAGES["auth_failed"])
            }
            
    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "message": ERROR_MESSAGES["network_error"]
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"Unexpected error: {str(e)}"
        }

def register_user(full_name: str, email: str, password: str) -> Dict[str, Any]:
    """
    Register new user
    
    Args:
        full_name: User's full name
        email: User email
        password: User password
    
    Returns:
        Dict containing success status and message
    """
    try:
        payload = {
            "full_name": full_name,
            "email": email,
            "password": password
        }
        
        response = requests.post(
            API_ENDPOINTS["auth"]["register"],
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            return {
                "success": True,
                "message": SUCCESS_MESSAGES["register_success"]
            }
        else:
            error_data = response.json() if response.content else {}
            return {
                "success": False,
                "message": error_data.get("detail", "Registration failed")
            }
            
    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "message": ERROR_MESSAGES["network_error"]
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"Registration error: {str(e)}"
        }

def check_auth_status() -> bool:
    """
    Check if user is authenticated and token is valid
    
    Returns:
        Boolean indicating authentication status
    """
    if not st.session_state.get('authenticated'):
        return False
    
    if not st.session_state.get('access_token'):
        return False
    
    try:
        headers = {
            "Authorization": f"Bearer {st.session_state.access_token}"
        }
        
        response = requests.get(
            API_ENDPOINTS["auth"]["me"],
            headers=headers,
            timeout=10
        )
        
        return response.status_code == 200
        
    except:
        return False

def get_auth_headers() -> Dict[str, str]:
    """
    Get authentication headers for API requests
    
    Returns:
        Dict containing authorization headers
    """
    if st.session_state.get('access_token'):
        return {
            "Authorization": f"Bearer {st.session_state.access_token}",
            "Content-Type": "application/json"
        }
    return {}

def require_auth(func):
    """
    Decorator to require authentication for functions
    """
    def wrapper(*args, **kwargs):
        if not check_auth_status():
            st.error("Please login to access this feature.")
            st.switch_page("Home.py")
            return None
        return func(*args, **kwargs)
    return wrapper

@st.cache_data(ttl=3000)  # Cache for 5 minutes
def get_user_profile() -> Dict[str, Any]:
    """
    Get current user profile data
    
    Returns:
        Dict containing user profile information
    """
    try:
        headers = get_auth_headers()
        
        response = requests.get(
            API_ENDPOINTS["auth"]["me"],
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            return {}
            
    except Exception as e:
        st.error(f"Error fetching user profile: {str(e)}")
        return {}

def logout_user():
    """
    Logout current user and clear session
    """
    try:
        # Call logout endpoint if needed
        headers = get_auth_headers()
        if headers:
            requests.post(
                API_ENDPOINTS["auth"]["logout"],
                headers=headers,
                timeout=10
            )
    except:
        pass  # Ignore logout API errors
    
    # Clear session state
    for key in list(st.session_state.keys()):
        del st.session_state[key]
    
    # Clear cache
    st.cache_data.clear()
    st.cache_resource.clear()

def validate_session():
    """
    Validate current session and redirect if invalid
    """
    if not st.session_state.get('authenticated'):
        st.warning("Please login to continue.")
        st.switch_page("Home.py")
        st.stop()
    
    if not check_auth_status():
        st.error("Your session has expired. Please login again.")
        logout_user()
        st.switch_page("Home.py")
        st.stop()
