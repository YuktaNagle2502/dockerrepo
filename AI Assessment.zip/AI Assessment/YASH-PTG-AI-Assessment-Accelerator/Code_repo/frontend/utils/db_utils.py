"""
Database utilities and helper functions
"""
import streamlit as st
from sqlalchemy.orm import Session
from typing import List, Dict, Any, Optional
from datetime import datetime
import json


def create_report_record(
    session: Session,
    project_id: int,
    user_id: int,
    report_type: str,
    report_title: str,
    report_description: str,
    file_path: str,
    file_name: str,
    file_type: str,
    file_size: int,
    report_data: Dict[str, Any],
    session_id: Optional[int] = None,
    stage_order: Optional[int] = None
) -> Dict[str, Any]:
    """
    Create a new report record in the database
    
    Args:
        session: Database session
        project_id: ID of the project
        user_id: ID of the user
        report_type: Type of report (use_cases, data_readiness, etc.)
        report_title: Title of the report
        report_description: Description of the report
        file_path: Path to the report file
        file_name: Name of the report file
        file_type: Type of file (pdf, json, excel)
        file_size: Size of the file in bytes
        report_data: Metadata and summary data
        session_id: Optional session ID
        stage_order: Order of the stage in workflow
    
    Returns:
        Dict containing the created report information
    """
    # This would interact with your Reports table
    # Placeholder implementation
    
    report_record = {
        'id': generate_report_id(),
        'project_id': project_id,
        'session_id': session_id,
        'user_id': user_id,
        'report_type': report_type,
        'report_title': report_title,
        'report_description': report_description,
        'file_path': file_path,
        'file_name': file_name,
        'file_type': file_type,
        'file_size': file_size,
        'report_data': report_data,
        'status': 'generated',
        'stage_order': stage_order,
        'created_at': datetime.now(),
        'updated_at': datetime.now()
    }
    
    # Store in session state for demo purposes
    if 'stored_reports' not in st.session_state:
        st.session_state.stored_reports = []
    
    st.session_state.stored_reports.append(report_record)
    
    return report_record


def get_project_reports(
    session: Session,
    project_id: int,
    user_id: int,
    report_type: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Get all reports for a project
    
    Args:
        session: Database session
        project_id: ID of the project
        user_id: ID of the user
        report_type: Optional filter by report type
    
    Returns:
        List of report records
    """
    # This would query your Reports table
    # Placeholder implementation
    
    stored_reports = st.session_state.get('stored_reports', [])
    
    # Filter by project and user
    project_reports = [
        report for report in stored_reports
        if report['project_id'] == project_id and report['user_id'] == user_id
    ]
    
    # Filter by report type if specified
    if report_type:
        project_reports = [
            report for report in project_reports
            if report['report_type'] == report_type
        ]
    
    return project_reports


def get_report_by_id(
    session: Session,
    report_id: int,
    user_id: int
) -> Optional[Dict[str, Any]]:
    """
    Get a specific report by ID
    
    Args:
        session: Database session
        report_id: ID of the report
        user_id: ID of the user
    
    Returns:
        Report record or None if not found
    """
    stored_reports = st.session_state.get('stored_reports', [])
    
    for report in stored_reports:
        if report['id'] == report_id and report['user_id'] == user_id:
            return report
    
    return None


def update_report_status(
    session: Session,
    report_id: int,
    user_id: int,
    status: str
) -> bool:
    """
    Update report status
    
    Args:
        session: Database session
        report_id: ID of the report
        user_id: ID of the user
        status: New status
    
    Returns:
        True if updated successfully
    """
    stored_reports = st.session_state.get('stored_reports', [])
    
    for report in stored_reports:
        if report['id'] == report_id and report['user_id'] == user_id:
            report['status'] = status
            report['updated_at'] = datetime.now()
            return True
    
    return False


def delete_report(
    session: Session,
    report_id: int,
    user_id: int
) -> bool:
    """
    Delete a report
    
    Args:
        session: Database session
        report_id: ID of the report
        user_id: ID of the user
    
    Returns:
        True if deleted successfully
    """
    stored_reports = st.session_state.get('stored_reports', [])
    
    for i, report in enumerate(stored_reports):
        if report['id'] == report_id and report['user_id'] == user_id:
            stored_reports.pop(i)
            return True
    
    return False


def get_user_statistics(
    session: Session,
    user_id: int
) -> Dict[str, Any]:
    """
    Get user statistics
    
    Args:
        session: Database session
        user_id: ID of the user
    
    Returns:
        Dictionary with user statistics
    """
    stored_reports = st.session_state.get('stored_reports', [])
    user_reports = [r for r in stored_reports if r['user_id'] == user_id]
    
    stats = {
        'total_reports': len(user_reports),
        'reports_by_type': {},
        'total_file_size': 0,
        'recent_reports': 0  # Last 7 days
    }
    
    # Calculate statistics
    for report in user_reports:
        report_type = report['report_type']
        stats['reports_by_type'][report_type] = stats['reports_by_type'].get(report_type, 0) + 1
        stats['total_file_size'] += report.get('file_size', 0)
        
        # Check if report is recent (last 7 days)
        created_at = report['created_at']
        if isinstance(created_at, datetime):
            days_ago = (datetime.now() - created_at).days
            if days_ago <= 7:
                stats['recent_reports'] += 1
    
    return stats


def get_project_statistics(
    session: Session,
    project_id: int,
    user_id: int
) -> Dict[str, Any]:
    """
    Get project statistics
    
    Args:
        session: Database session
        project_id: ID of the project
        user_id: ID of the user
    
    Returns:
        Dictionary with project statistics
    """
    project_reports = get_project_reports(session, project_id, user_id)
    
    stats = {
        'total_reports': len(project_reports),
        'completed_stages': len(set(r.get('stage_order') for r in project_reports if r.get('stage_order'))),
        'latest_report': None,
        'workflow_progress': calculate_workflow_progress(project_reports)
    }
    
    # Find latest report
    if project_reports:
        latest = max(project_reports, key=lambda x: x['created_at'])
        stats['latest_report'] = {
            'title': latest['report_title'],
            'type': latest['report_type'],
            'created_at': latest['created_at']
        }
    
    return stats


def calculate_workflow_progress(reports: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Calculate workflow progress based on generated reports"""
    
    stage_mapping = {
        'use_cases': 1,
        'data_readiness': 2,
        'data_compliance': 3,
        'ai_profiling': 4,
        'model_evaluation': 5,
        'final_report': 6
    }
    
    completed_stages = set()
    for report in reports:
        report_type = report.get('report_type')
        if report_type in stage_mapping:
            completed_stages.add(stage_mapping[report_type])
    
    total_stages = 6
    progress_percentage = (len(completed_stages) / total_stages) * 100
    
    return {
        'completed_stages': sorted(list(completed_stages)),
        'total_stages': total_stages,
        'progress_percentage': progress_percentage,
        'next_stage': get_next_stage(completed_stages)
    }


def get_next_stage(completed_stages: set) -> Optional[int]:
    """Get the next stage to complete"""
    for stage in range(1, 7):
        if stage not in completed_stages:
            return stage
    return None


def generate_report_id() -> int:
    """Generate a unique report ID"""
    import random
    return random.randint(1000, 9999)


def backup_report_data(
    session: Session,
    user_id: int,
    backup_path: str
) -> bool:
    """
    Backup user's report data
    
    Args:
        session: Database session
        user_id: ID of the user
        backup_path: Path to save backup
    
    Returns:
        True if backup successful
    """
    try:
        stored_reports = st.session_state.get('stored_reports', [])
        user_reports = [r for r in stored_reports if r['user_id'] == user_id]
        
        # Serialize datetime objects for JSON
        for report in user_reports:
            if isinstance(report.get('created_at'), datetime):
                report['created_at'] = report['created_at'].isoformat()
            if isinstance(report.get('updated_at'), datetime):
                report['updated_at'] = report['updated_at'].isoformat()
        
        backup_data = {
            'user_id': user_id,
            'backup_date': datetime.now().isoformat(),
            'reports': user_reports
        }
        
        with open(backup_path, 'w') as f:
            json.dump(backup_data, f, indent=2, default=str)
        
        return True
    
    except Exception:
        return False


def restore_report_data(
    session: Session,
    user_id: int,
    backup_path: str
) -> bool:
    """
    Restore user's report data from backup
    
    Args:
        session: Database session
        user_id: ID of the user
        backup_path: Path to backup file
    
    Returns:
        True if restore successful
    """
    try:
        with open(backup_path, 'r') as f:
            backup_data = json.load(f)
        
        if backup_data.get('user_id') != user_id:
            return False
        
        # Restore reports to session state
        if 'stored_reports' not in st.session_state:
            st.session_state.stored_reports = []
        
        # Remove existing reports for this user
        st.session_state.stored_reports = [
            r for r in st.session_state.stored_reports 
            if r['user_id'] != user_id
        ]
        
        # Add restored reports
        restored_reports = backup_data.get('reports', [])
        for report in restored_reports:
            # Convert datetime strings back to datetime objects
            if isinstance(report.get('created_at'), str):
                report['created_at'] = datetime.fromisoformat(report['created_at'])
            if isinstance(report.get('updated_at'), str):
                report['updated_at'] = datetime.fromisoformat(report['updated_at'])
        
        st.session_state.stored_reports.extend(restored_reports)
        
        return True
    
    except Exception:
        return False
