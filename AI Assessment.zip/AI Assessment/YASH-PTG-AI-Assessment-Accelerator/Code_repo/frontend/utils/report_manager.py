import streamlit as st
import requests
import io
from typing import Dict, Any, Optional
from utils.auth import get_auth_headers
from utils.config import API_ENDPOINTS
from utils.ui_components import show_success_message, show_error_message

class StreamlitReportManager:
    """Frontend report manager for Streamlit integration"""
    
    @staticmethod
    def save_report_to_database(
        file_content: bytes,
        module_name: str,
        module_entity_id: int,
        report_name: str,
        report_type: str,
        filename: str
    ) -> Optional[Dict[str, Any]]:
        """
        Save report to database using universal reports API
        
        Args:
            file_content: Report content as bytes
            module_name: Name of the module (e.g., "pre_workshop", "data_readiness")
            module_entity_id: ID of the entity within the module
            report_name: Human readable name for the report
            report_type: Type of report (pdf, json, xlsx, html)
            filename: Original filename
            
        Returns:
            Report data if successful, None if failed
        """
        try:
            # Validate required session state
            if 'user_data' not in st.session_state:
                show_error_message("User data not found in session")
                return None
                
            if 'selected_project_id' not in st.session_state:
                show_error_message("No project selected")
                return None
            
            # Create form data for multipart upload
            files = {
                'file': (filename, io.BytesIO(file_content), f'application/{report_type}')
            }
            
            form_data = {
                'user_id': str(st.session_state.user_data['id']),
                'project_id': str(st.session_state.selected_project_id),
                'module_name': module_name,
                'module_entity_id': str(module_entity_id),
                'report_name': report_name,
                'report_type': report_type
            }
            
            headers = get_auth_headers()
            # Remove Content-Type to let requests handle multipart
            if 'Content-Type' in headers:
                del headers['Content-Type']
            
            response = requests.post(
                API_ENDPOINTS["reports"]["save"],
                files=files,
                data=form_data,
                headers=headers,
                timeout=60
            )
            
            if response.status_code == 200:
                report_data = response.json()
                st.session_state.last_saved_report = report_data
                return report_data
            else:
                error_detail = "Unknown error"
                try:
                    error_data = response.json()
                    error_detail = error_data.get('detail', response.text)
                except:
                    error_detail = response.text
                
                show_error_message(f"Failed to save report to database: {error_detail}")
                return None
                
        except Exception as e:
            show_error_message(f"Error saving report to database: {str(e)}")
            return None
    
    @staticmethod
    def get_user_reports() -> list:
        """Get all reports for the current user"""
        try:
            headers = get_auth_headers()
            response = requests.get(
                API_ENDPOINTS["reports"]["user"],
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return []
                
        except Exception as e:
            st.error(f"Error loading user reports: {str(e)}")
            return []
    
    @staticmethod
    def get_project_reports(project_id: int) -> list:
        """Get all reports for a specific project"""
        try:
            headers = get_auth_headers()
            response = requests.get(
                API_ENDPOINTS["reports"]["project"].format(project_id=project_id),
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return []
                
        except Exception as e:
            st.error(f"Error loading project reports: {str(e)}")
            return []
    
    @staticmethod
    def get_module_reports(module_name: str, module_entity_id: Optional[int] = None, 
                          project_id: Optional[int] = None) -> list:
        """Get reports for a specific module"""
        try:
            headers = get_auth_headers()
            params = {}
            
            if module_entity_id is not None:
                params['module_entity_id'] = module_entity_id
            if project_id is not None:
                params['project_id'] = project_id
            
            response = requests.get(
                API_ENDPOINTS["reports"]["module"].format(module_name=module_name),
                headers=headers,
                params=params,
                timeout=30
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return []
                
        except Exception as e:
            st.error(f"Error loading module reports: {str(e)}")
            return []
    
    @staticmethod
    def download_report(report_uuid: str) -> Optional[bytes]:
        """Download a report by UUID"""
        try:
            headers = get_auth_headers()
            response = requests.get(
                API_ENDPOINTS["reports"]["download"].format(report_uuid=report_uuid),
                headers=headers,
                timeout=60
            )
            
            if response.status_code == 200:
                return response.content
            else:
                show_error_message("Failed to download report")
                return None
                
        except Exception as e:
            show_error_message(f"Error downloading report: {str(e)}")
            return None