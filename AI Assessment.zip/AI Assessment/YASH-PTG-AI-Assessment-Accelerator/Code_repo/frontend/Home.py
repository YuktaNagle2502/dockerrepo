import streamlit as st
import requests
import json
from datetime import datetime
import time
from utils.auth import authenticate_user, register_user, check_auth_status
from utils.config import API_BASE_URL, APP_CONFIG
from utils.ui_components import apply_custom_css, show_success_message, show_error_message

# Configure page
st.set_page_config(
    page_title="GenAI Assessment Platform",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Apply custom CSS
apply_custom_css()

# Initialize session state
if 'authenticated' not in st.session_state:
    st.session_state.authenticated = False
if 'user_data' not in st.session_state:
    st.session_state.user_data = None
if 'access_token' not in st.session_state:
    st.session_state.access_token = None

def main():
    """Main application entry point"""
    
    # Check if user is already authenticated
    if st.session_state.authenticated and st.session_state.user_data:
        show_dashboard()
    else:
        show_login_page()

def show_login_page():
    """Display login/registration page"""
    
    # Header
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown("""
        <div class="main-header">
            <h1>🤖 GenAI Assessment Platform</h1>
            <p>Comprehensive AI-powered assessment and evaluation platform</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Login/Register tabs
    tab1, tab2 = st.tabs(["🔐 Login", "📝 Register"])
    
    with tab1:
        show_login_form()
    
    with tab2:
        show_register_form()

def show_login_form():
    """Display login form"""
    
    with st.form("login_form"):
        st.markdown("### Welcome Back!")
        
        email = st.text_input(
            "Email Address",
            placeholder="Enter your email",
            help="Use the email address you registered with"
        )
        
        password = st.text_input(
            "Password",
            type="password",
            placeholder="Enter your password"
        )
        
        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            submitted = st.form_submit_button(
                "🔑 Login",
                use_container_width=True,
                type="primary"
            )
        
        if submitted:
            if email and password:
                with st.spinner("Authenticating..."):
                    result = authenticate_user(email, password)
                    
                if result['success']:
                    st.session_state.authenticated = True
                    st.session_state.user_data = result['user_data']
                    st.session_state.access_token = result['access_token']
                    
                    show_success_message("Login successful! Redirecting...")
                    time.sleep(1)
                    st.rerun()
                else:
                    show_error_message(result['message'])
            else:
                show_error_message("Please fill in all fields")

def show_register_form():
    """Display registration form"""
    
    with st.form("register_form"):
        st.markdown("### Create New Account")
        
        full_name = st.text_input(
            "Full Name",
            placeholder="Enter your full name"
        )
        
        email = st.text_input(
            "Email Address",
            placeholder="Enter your email address"
        )
        
        password = st.text_input(
            "Password",
            type="password",
            placeholder="Create a strong password",
            help="Password should be at least 8 characters long"
        )
        
        confirm_password = st.text_input(
            "Confirm Password",
            type="password",
            placeholder="Confirm your password"
        )
        
        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            submitted = st.form_submit_button(
                "📝 Register",
                use_container_width=True,
                type="primary"
            )
        
        if submitted:
            if full_name and email and password and confirm_password:
                if password != confirm_password:
                    show_error_message("Passwords do not match!")
                elif len(password) < 8:
                    show_error_message("Password must be at least 8 characters long!")
                else:
                    with st.spinner("Creating account..."):
                        result = register_user(full_name, email, password)
                    
                    if result['success']:
                        show_success_message("Account created successfully! Please login.")
                        time.sleep(2)
                        st.rerun()
                    else:
                        show_error_message(result['message'])
            else:
                show_error_message("Please fill in all fields")

def show_dashboard():
    """Display main dashboard after login"""
    
    # Header with user info
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        st.markdown(f"""
        <div class="dashboard-header">
            <h1>Welcome, {st.session_state.user_data['full_name']}! 👋</h1>
            <p>Ready to start your GenAI assessment journey?</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        if st.button("🚪 Logout", type="secondary"):
            logout_user()
    
    st.markdown("---")
    
    # Quick stats and navigation
    show_dashboard_content()

def show_dashboard_content():
    """Display dashboard content with project overview and quick actions"""
    
    # Quick Actions
    st.markdown("### 🚀 Quick Actions")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("📊 View Projects", use_container_width=True):
            st.switch_page("pages/1_📊_Project_Management.py")
    
    with col2:
        if st.button("🧠 Use Cases", use_container_width=True):
            st.switch_page("pages/2_🧠_Use_Case_Generation.py")
    
    with col3:
        if st.button("📈 Data Readiness", use_container_width=True):
            st.switch_page("pages/3_📈_Data_Readiness.py")
    
    with col4:
        if st.button("📋 Reports", use_container_width=True):
            st.switch_page("pages/7_📋_Reports_Dashboard.py")
    
    st.markdown("---")
    
    # Recent Activity
    st.markdown("### 📈 Recent Activity")
    
    # This will be populated with actual data from the backend
    with st.container():
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.info("🎯 No recent activity. Start by creating a new project!")
        
        with col2:
            st.metric("Total Projects", "0")
            st.metric("Completed Assessments", "0")
    
    # Getting Started Guide
    with st.expander("🎯 Getting Started Guide", expanded=True):
        st.markdown("""
        ### Welcome to the GenAI Assessment Platform!
        
        Follow these steps to complete your assessment:
        
        1. **📊 Create a Project** - Start by creating a new project for your assessment
        2. **🧠 Generate Use Cases** - Upload your questionnaire and generate AI use cases
        3. **📈 Check Data Readiness** - Upload your data and assess its readiness
        4. **🔒 Compliance Check** - Verify data compliance and security requirements
        5. **🤖 AI Profiling** - Perform detailed AI model profiling
        6. **⚡ Model Evaluation** - Evaluate and compare different AI models
        7. **📋 Final Report** - Generate comprehensive assessment reports
        
        💡 **Tip**: You can save and access all reports at any stage of the process!
        """)

def logout_user():
    """Handle user logout"""
    # Clear session state
    for key in st.session_state.keys():
        del st.session_state[key]
    
    st.success("Logged out successfully!")
    time.sleep(1)
    st.rerun()

if __name__ == "__main__":
    main()
