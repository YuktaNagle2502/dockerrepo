from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Response, Form
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
import json
import os
import tempfile
import shutil
from pathlib import Path
import pandas as pd
import logging
from enum import Enum
from dataclasses import dataclass
from groq import Groq
import re
import io
import asyncio

# ReportLab imports for PDF generation
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.colors import HexColor, black, white, red, green, orange
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from reportlab.lib import colors

# Import database configuration and auth dependencies
from database import get_db
from login_project import get_current_user, User, Project
from pre_workshop import GeneratedUseCase, PreWorkshopSession

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Data Classes and Enums
class DataReadinessStatus(Enum):
    READY = "ready"
    PARTIALLY_READY = "partially_ready"
    NOT_READY = "not_ready"

@dataclass
class DataRequirement:
    """Represents a specific data requirement for a use case"""
    name: str
    description: str
    required_columns: List[str]
    data_type: str
    minimum_rows: int
    criticality: str  # 'critical', 'important', 'nice_to_have'
    weight: float  # Weight for scoring (0-1)

@dataclass
class DataFile:
    """Represents an uploaded data file"""
    filename: str
    file_type: str
    size_mb: float
    columns: Optional[List[str]] = None
    row_count: Optional[int] = None
    sample_data: Optional[Dict] = None
    data_quality_score: float = 0.0
    matches_requirements: List[str] = None

@dataclass
class DataReadinessReport:
    """Represents the final data readiness assessment report"""
    use_case_title: str
    overall_status: DataReadinessStatus
    readiness_score: float  # 0-100
    requirements_analysis: Dict[str, Any]
    data_quality_issues: List[str]
    recommendations: List[str]
    detailed_analysis: str
    files_analyzed: List[DataFile]
    timestamp: str

# Pydantic Models for API
class DataReadinessAnalysisResponse(BaseModel):
    use_case_id: int
    analysis_type: str
    generated_content: str
    readiness_score: float
    status: str
    files_count: int
    generated_at: datetime

class DataFileInfo(BaseModel):
    filename: str
    file_type: str
    size_mb: float
    row_count: Optional[int] = None
    columns_count: Optional[int] = None
    data_quality_score: float
    matches_requirements: List[str]

# File Processing Class
class FileProcessor:
    """Process various file types for data readiness analysis"""
    
    SUPPORTED_EXTENSIONS = {
        '.csv': 'text/csv',
        '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        '.xls': 'application/vnd.ms-excel',
        '.txt': 'text/plain',
        '.json': 'application/json',
        '.parquet': 'application/parquet'
    }
    
    def __init__(self):
        self.temp_dir = None
    
    async def process_file(self, file_path: str, filename: str) -> DataFile:
        """Process uploaded file and extract metadata with quality assessment"""
        try:
            file_path = Path(file_path)
            file_size_mb = file_path.stat().st_size / (1024 * 1024)
            file_type = file_path.suffix.lower()
            
            if file_type not in self.SUPPORTED_EXTENSIONS:
                raise ValueError(f"Unsupported file type: {file_type}")
            
            data_file = DataFile(
                filename=filename,
                file_type=file_type,
                size_mb=round(file_size_mb, 2),
                matches_requirements=[]
            )
            
            # Process based on file type
            if file_type == '.csv':
                await self._process_csv(file_path, data_file)
            elif file_type in ['.xlsx', '.xls']:
                await self._process_excel(file_path, data_file)
            elif file_type == '.txt':
                await self._process_text(file_path, data_file)
            elif file_type == '.json':
                await self._process_json(file_path, data_file)
            elif file_type == '.parquet':
                await self._process_parquet(file_path, data_file)
            
            return data_file
            
        except Exception as e:
            raise ValueError(f"Error processing file: {str(e)}")
    
    async def _process_csv(self, file_path: str, data_file: DataFile):
        """Process CSV files"""
        try:
            df = pd.read_csv(file_path, nrows=1000)  # Sample first 1000 rows
            data_file.columns = df.columns.tolist()
            data_file.row_count = len(df)
            data_file.sample_data = df.head(3).to_dict('records')
            data_file.data_quality_score = self._calculate_data_quality_score(df)
        except Exception as e:
            # Try different encodings
            encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252']
            for encoding in encodings:
                try:
                    df = pd.read_csv(file_path, encoding=encoding, nrows=1000)
                    data_file.columns = df.columns.tolist()
                    data_file.row_count = len(df)
                    data_file.sample_data = df.head(3).to_dict('records')
                    data_file.data_quality_score = self._calculate_data_quality_score(df)
                    break
                except:
                    continue
    
    async def _process_excel(self, file_path: str, data_file: DataFile):
        """Process Excel files"""
        try:
            df = pd.read_excel(file_path, nrows=1000)
            data_file.columns = df.columns.tolist()
            data_file.row_count = len(df)
            data_file.sample_data = df.head(3).to_dict('records')
            data_file.data_quality_score = self._calculate_data_quality_score(df)
        except Exception as e:
            raise ValueError(f"Error processing Excel file: {str(e)}")
    
    async def _process_text(self, file_path: str, data_file: DataFile):
        """Process text files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            data_file.row_count = len(content.splitlines())
            data_file.sample_data = {"preview": content[:500] + "..." if len(content) > 500 else content}
            data_file.data_quality_score = 0.7 if len(content) > 100 else 0.3
        except UnicodeDecodeError:
            # Try different encodings
            encodings = ['latin-1', 'iso-8859-1', 'cp1252']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    data_file.row_count = len(content.splitlines())
                    data_file.sample_data = {"preview": content[:500] + "..." if len(content) > 500 else content}
                    data_file.data_quality_score = 0.7 if len(content) > 100 else 0.3
                    break
                except:
                    continue
    
    async def _process_json(self, file_path: str, data_file: DataFile):
        """Process JSON files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if isinstance(data, list):
                data_file.row_count = len(data)
                data_file.columns = list(data[0].keys()) if data and isinstance(data[0], dict) else None
                df = pd.DataFrame(data)
                data_file.data_quality_score = self._calculate_data_quality_score(df)
            elif isinstance(data, dict):
                data_file.row_count = 1
                data_file.columns = list(data.keys())
                data_file.data_quality_score = 0.5
            
            data_file.sample_data = data[:3] if isinstance(data, list) else data
        except Exception as e:
            raise ValueError(f"Error processing JSON file: {str(e)}")
    
    async def _process_parquet(self, file_path: str, data_file: DataFile):
        """Process Parquet files"""
        try:
            df = pd.read_parquet(file_path)
            data_file.columns = df.columns.tolist()
            data_file.row_count = len(df)
            data_file.sample_data = df.head(3).to_dict('records')
            data_file.data_quality_score = self._calculate_data_quality_score(df)
        except Exception as e:
            raise ValueError(f"Error processing Parquet file: {str(e)}")
    
    def _calculate_data_quality_score(self, df: pd.DataFrame) -> float:
        """Calculate data quality score based on completeness, consistency, etc."""
        if df.empty:
            return 0.0
        
        # Completeness score (percentage of non-null values)
        completeness = df.count().sum() / (df.shape[0] * df.shape[1])
        
        # Consistency score (check for obvious data issues)
        consistency = 1.0
        for col in df.columns:
            if df[col].dtype == 'object':
                # Check for mixed data types in text columns
                unique_vals = df[col].dropna().unique()
                if len(unique_vals) > 0:
                    text_ratio = sum(1 for val in unique_vals if isinstance(val, str)) / len(unique_vals)
                    consistency *= text_ratio
        
        # Volume score (penalize very small datasets)
        volume_score = min(1.0, df.shape[0] / 100)  # Assume 100 rows is minimum good volume
        
        # Overall quality score
        quality_score = (completeness * 0.5 + consistency * 0.3 + volume_score * 0.2)
        return round(quality_score, 2)

# Data Readiness Analyzer
class DataReadinessAnalyzer:
    """Enhanced data readiness analysis engine"""
    
    def __init__(self, api_key: str, model: str = "deepseek-r1-distill-llama-70b"):
        self.client = Groq(api_key=api_key)
        self.model = model
    
    def extract_data_requirements(self, use_case: Dict[str, Any]) -> List[DataRequirement]:
        """Extract specific data requirements from use case using rule-based and LLM analysis"""
        
        requirements = []
        
        # Get primary capability and services
        primary_capability = use_case.get('primary_genai_capability', '').lower()
        aws_services = [service.lower() for service in use_case.get('aws_services', [])]
        title = use_case.get('title', '').lower()
        
        # Rule-based requirements extraction
        if 'customer' in title and 'support' in title:
            requirements.append(DataRequirement(
                name="customer_support_data",
                description="Customer support tickets and interactions",
                required_columns=["customer_message", "response", "ticket_id", "timestamp"],
                data_type="structured",
                minimum_rows=100,
                criticality="critical",
                weight=0.4
            ))
            
        if 'chatbot' in title or 'lex' in ' '.join(aws_services):
            requirements.append(DataRequirement(
                name="conversation_data",
                description="Conversation logs or chat transcripts",
                required_columns=["user_input", "bot_response", "intent", "confidence"],
                data_type="structured",
                minimum_rows=500,
                criticality="critical",
                weight=0.4
            ))
            
        if 'comprehend' in ' '.join(aws_services) or primary_capability == 'nlp':
            requirements.append(DataRequirement(
                name="text_data",
                description="Text data for NLP analysis",
                required_columns=["text", "label", "category"],
                data_type="text",
                minimum_rows=200,
                criticality="important",
                weight=0.3
            ))
            
        if 'fraud' in title:
            requirements.append(DataRequirement(
                name="transaction_data",
                description="Transaction records with fraud labels",
                required_columns=["transaction_id", "amount", "user_id", "is_fraud", "timestamp"],
                data_type="structured",
                minimum_rows=1000,
                criticality="critical",
                weight=0.5
            ))
            
        if 'recommendation' in title:
            requirements.append(DataRequirement(
                name="user_interaction_data",
                description="User behavior and interaction data",
                required_columns=["user_id", "item_id", "rating", "timestamp"],
                data_type="structured",
                minimum_rows=1000,
                criticality="critical",
                weight=0.4
            ))
        
        # Add LLM-based requirements extraction
        try:
            llm_requirements = self._get_llm_requirements(use_case)
            requirements.extend(llm_requirements)
        except Exception as e:
            logger.warning(f"LLM requirements extraction failed: {str(e)}")
        
        return requirements
    
    def _get_llm_requirements(self, use_case: Dict[str, Any]) -> List[DataRequirement]:
        """Use LLM to extract additional requirements"""
        prompt = f"""
        Analyze this AI use case and identify the top 3 most critical data requirements:
        
        Use Case: {json.dumps(use_case, indent=2)}
        
        For each requirement, provide:
        1. Name (snake_case)
        2. Description
        3. Required columns (list)
        4. Minimum rows needed
        5. Criticality (critical/important/nice_to_have)
        
        Return as JSON array:
        [
            {{
                "name": "requirement_name",
                "description": "What this data is for",
                "required_columns": ["col1", "col2", "col3"],
                "minimum_rows": 100,
                "criticality": "critical"
            }}
        ]
        """
        
        try:
            response = self.client.chat.completions.create(
                messages=[
                    {"role": "system", "content": "You are a data requirements analyst. Provide specific, technical data requirements in JSON format."},
                    {"role": "user", "content": prompt}
                ],
                model=self.model,
                temperature=0.1,
                max_tokens=1000
            )
            
            content = response.choices[0].message.content
            # Extract JSON from response
            start_idx = content.find('[')
            end_idx = content.rfind(']') + 1
            json_str = content[start_idx:end_idx]
            
            requirements_data = json.loads(json_str)
            
            requirements = []
            for req_data in requirements_data:
                weight = 0.5 if req_data['criticality'] == 'critical' else 0.3 if req_data['criticality'] == 'important' else 0.1
                requirements.append(DataRequirement(
                    name=req_data['name'],
                    description=req_data['description'],
                    required_columns=req_data['required_columns'],
                    data_type="structured",
                    minimum_rows=req_data['minimum_rows'],
                    criticality=req_data['criticality'],
                    weight=weight
                ))
            
            return requirements
            
        except Exception as e:
            logger.error(f"Error extracting LLM requirements: {str(e)}")
            return []
    
    def match_data_to_requirements(self, data_files: List[DataFile], requirements: List[DataRequirement]) -> Dict[str, Any]:
        """Match uploaded data files to requirements and calculate scores"""
        
        analysis = {
            "total_requirements": len(requirements),
            "met_requirements": 0,
            "partial_requirements": 0,
            "missing_requirements": 0,
            "requirement_details": [],
            "overall_score": 0.0
        }
        
        total_weight = sum(req.weight for req in requirements)
        weighted_score = 0.0
        
        for requirement in requirements:
            req_analysis = {
                "name": requirement.name,
                "description": requirement.description,
                "status": "missing",
                "matched_files": [],
                "score": 0.0,
                "issues": []
            }
            
            best_match_score = 0.0
            
            for data_file in data_files:
                if data_file.columns:
                    # Check column matching
                    matched_columns = []
                    for req_col in requirement.required_columns:
                        # Flexible matching (case-insensitive, partial matches)
                        for file_col in data_file.columns:
                            if (req_col.lower() in file_col.lower() or 
                                file_col.lower() in req_col.lower() or
                                self._calculate_similarity(req_col.lower(), file_col.lower()) > 0.7):
                                matched_columns.append(file_col)
                                break
                    
                    column_match_ratio = len(matched_columns) / len(requirement.required_columns)
                    
                    # Check row count
                    row_score = 1.0 if data_file.row_count >= requirement.minimum_rows else (data_file.row_count / requirement.minimum_rows)
                    
                    # Overall match score for this file
                    file_score = (column_match_ratio * 0.6 + row_score * 0.2 + data_file.data_quality_score * 0.2)
                    
                    if file_score > best_match_score:
                        best_match_score = file_score
                        req_analysis["matched_files"] = [data_file.filename]
                        req_analysis["score"] = file_score
                        
                        # Update file's matches
                        if requirement.name not in data_file.matches_requirements:
                            data_file.matches_requirements.append(requirement.name)
                        
                        # Add issues
                        if column_match_ratio < 1.0:
                            missing_cols = set(requirement.required_columns) - set(matched_columns)
                            req_analysis["issues"].append(f"Missing columns: {list(missing_cols)}")
                        
                        if row_score < 1.0:
                            req_analysis["issues"].append(f"Insufficient data volume: {data_file.row_count} rows (need {requirement.minimum_rows})")
            
            # Determine status
            if best_match_score >= 0.8:
                req_analysis["status"] = "met"
                analysis["met_requirements"] += 1
            elif best_match_score >= 0.4:
                req_analysis["status"] = "partial"
                analysis["partial_requirements"] += 1
            else:
                req_analysis["status"] = "missing"
                analysis["missing_requirements"] += 1
            
            analysis["requirement_details"].append(req_analysis)
            
            # Add to weighted score
            weighted_score += best_match_score * requirement.weight
        
        # Calculate overall score
        if total_weight > 0:
            analysis["overall_score"] = round((weighted_score / total_weight) * 100, 1)
        
        return analysis
    
    def _calculate_similarity(self, str1: str, str2: str) -> float:
        """Calculate similarity between two strings"""
        # Simple similarity based on common characters
        set1, set2 = set(str1), set(str2)
        intersection = set1.intersection(set2)
        union = set1.union(set2)
        return len(intersection) / len(union) if union else 0.0
    
    async def analyze_data_readiness(self, use_case_data: Dict, data_files: List[DataFile]) -> Dict[str, Any]:
        """Analyze data readiness and generate markdown report"""
        
        # Extract requirements
        requirements = self.extract_data_requirements(use_case_data)
        
        # Match data to requirements
        analysis = self.match_data_to_requirements(data_files, requirements)
        
        # Determine overall status
        score = analysis["overall_score"]
        if score >= 80:
            status = "Ready"
        elif score >= 50:
            status = "Partially Ready"
        else:
            status = "Not Ready"
        
        # Prepare context for AI analysis
        context = self._prepare_analysis_context(use_case_data, data_files, analysis, requirements)
        
        # Generate comprehensive markdown analysis
        markdown_content = await self._generate_ai_analysis(context, score, status)
        
        return {
            'use_case_id': use_case_data.get('id'),
            'analysis_type': "comprehensive",
            'generated_content': markdown_content,
            'readiness_score': score,
            'status': status,
            'files_count': len(data_files),
            'generated_at': datetime.utcnow()
        }
    
    def _prepare_analysis_context(self, use_case_data: Dict, data_files: List[DataFile], analysis: Dict, requirements: List[DataRequirement]) -> str:
        """Prepare context for AI analysis"""
        
        # Files summary
        files_summary = []
        for file in data_files:
            files_summary.append({
                "filename": file.filename,
                "type": file.file_type,
                "size_mb": file.size_mb,
                "rows": file.row_count,
                "columns": len(file.columns) if file.columns else 0,
                "quality_score": file.data_quality_score,
                "matches": file.matches_requirements
            })
        
        # Requirements summary
        requirements_summary = []
        for req in requirements:
            req_analysis = next((r for r in analysis["requirement_details"] if r["name"] == req.name), {})
            requirements_summary.append({
                "name": req.name,
                "description": req.description,
                "required_columns": req.required_columns,
                "minimum_rows": req.minimum_rows,
                "criticality": req.criticality,
                "status": req_analysis.get("status", "unknown"),
                "score": req_analysis.get("score", 0.0),
                "issues": req_analysis.get("issues", [])
            })
        
        context = f"""
        # Use Case Information
        - **Title**: {use_case_data.get('title', 'N/A')}
        - **Description**: {use_case_data.get('description', 'N/A')}
        - **AWS Services**: {', '.join(use_case_data.get('aws_services', []))}
        - **Primary GenAI Capability**: {use_case_data.get('primary_genai_capability', 'N/A')}
        - **Business Category**: {use_case_data.get('business_category', 'N/A')}
        - **Priority**: {use_case_data.get('priority', 'N/A')}
        - **Complexity**: {use_case_data.get('complexity', 'N/A')}
        
        # Uploaded Files Analysis
        {json.dumps(files_summary, indent=2)}
        
        # Data Requirements Assessment
        {json.dumps(requirements_summary, indent=2)}
        
        # Overall Analysis Results
        - **Overall Score**: {analysis['overall_score']}%
        - **Total Requirements**: {analysis['total_requirements']}
        - **Met Requirements**: {analysis['met_requirements']}
        - **Partial Requirements**: {analysis['partial_requirements']}
        - **Missing Requirements**: {analysis['missing_requirements']}
        """
        return context
    
    async def _generate_ai_analysis(self, context: str, score: float, status: str) -> str:
        """Generate AI-powered comprehensive markdown analysis"""
        
        system_prompt = f"""
        You are a senior data scientist and AI consultant specializing in data readiness assessment for GenAI implementations.
        Your task is to analyze the provided data and generate a comprehensive data readiness report.
        
        Focus on the following areas:
        1. Executive Summary with clear recommendations
        2. Data Quality Assessment
        3. Requirements Coverage Analysis
        4. Identified Gaps and Issues
        5. Data Preparation Recommendations
        6. Implementation Readiness Assessment
        7. Next Steps and Action Items
        
        Generate a detailed report in markdown format with clear sections and actionable insights.
        Be specific about data quality issues and provide practical recommendations.
        """
        
        user_request = f"""
        Please analyze the following data readiness assessment and generate a comprehensive report:
        
        **Overall Readiness Score**: {score}%
        **Status**: {status}
        
        {context}
        
        Generate a comprehensive data readiness assessment report in markdown format.
        Provide specific, actionable recommendations and highlight critical issues that need attention.
        Structure the report with clear headings and bullet points for easy reading.
        """
        
        try:
            response = await asyncio.get_event_loop().run_in_executor(
                None, 
                lambda: self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_request}
                    ],
                    temperature=0.7,
                    max_tokens=4000
                )
            )
            content=response.choices[0].message.content.strip()
            return content.replace("<think>","")
            
        except Exception as e:
            return f"""
            # Data Readiness Assessment Report
            
            ## Executive Summary
            
            **Overall Readiness Score**: {score}%  
            **Status**: {status}
            
            An error occurred while generating the detailed analysis: {str(e)}
            
            ## Manual Review Required
            
            Please review the following items manually:
            - Data quality and completeness assessment
            - Requirements coverage validation
            - Column mapping and data type verification
            - Volume and sampling adequacy
            - Data preparation and cleaning needs
            
            ## Files Processed
            
            The system successfully processed the uploaded files but requires manual analysis for detailed assessment.
            
            ## Recommendations
            
            1. Verify data quality manually
            2. Ensure all required columns are present
            3. Check data volume adequacy
            4. Validate data formats and types
            5. Plan data preprocessing steps
            """
    
    def _generate_recommendations(self, analysis: Dict[str, Any], requirements: List[DataRequirement]) -> List[str]:
        """Generate specific recommendations based on analysis"""
        recommendations = []
        
        for req_detail in analysis["requirement_details"]:
            if req_detail["status"] == "missing":
                req_obj = next((req for req in requirements if req.name == req_detail['name']), None)
                if req_obj:
                    recommendations.append(f"Collect {req_detail['name']} data with columns: {', '.join(req_obj.required_columns)}")
            elif req_detail["status"] == "partial":
                for issue in req_detail["issues"]:
                    recommendations.append(f"Address {req_detail['name']}: {issue}")
        
        # Add general recommendations
        if analysis["overall_score"] < 50:
            recommendations.append("Consider starting with a smaller pilot project to validate data collection processes")
        
        return recommendations
    
    def _generate_detailed_analysis(self, analysis: Dict[str, Any], requirements: List[DataRequirement], data_files: List[DataFile]) -> str:
        """Generate detailed analysis text"""
        
        analysis_text = f"""
        DATA READINESS ANALYSIS
        
        Requirements Assessment:
        - Total requirements identified: {analysis['total_requirements']}
        - Fully met requirements: {analysis['met_requirements']}
        - Partially met requirements: {analysis['partial_requirements']}
        - Missing requirements: {analysis['missing_requirements']}
        
        Data Quality Summary:
        """
        
        for data_file in data_files:
            analysis_text += f"\n- {data_file.filename}: Quality score {data_file.data_quality_score:.2f}, {data_file.row_count} rows"
        
        analysis_text += f"\n\nOverall Assessment:\nThe data readiness score of {analysis['overall_score']:.1f}% indicates that "
        
        if analysis['overall_score'] >= 80:
            analysis_text += "the project is ready to proceed with the available data."
        elif analysis['overall_score'] >= 50:
            analysis_text += "the project can proceed with some data gaps that need to be addressed."
        else:
            analysis_text += "significant data collection is needed before the project can proceed."
        
        return analysis_text
    
    def _identify_quality_issues(self, data_files: List[DataFile], analysis: Dict[str, Any]) -> List[str]:
        """Identify data quality issues"""
        issues = []
        
        for data_file in data_files:
            if data_file.data_quality_score < 0.7:
                issues.append(f"{data_file.filename}: Low data quality score ({data_file.data_quality_score:.2f})")
            
            if data_file.row_count and data_file.row_count < 100:
                issues.append(f"{data_file.filename}: Insufficient data volume ({data_file.row_count} rows)")
        
        return issues

# PDF Report Generator
import io
import re
from datetime import datetime
from typing import List, Tuple
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.lib.colors import HexColor
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.units import inch
from reportlab.lib import colors

class DataReadinessPDFGenerator:
    """Generate PDF reports for data readiness analysis from markdown content"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        # Title style
        self.title_style = ParagraphStyle(
            'DataReadinessTitle',
            parent=self.styles['Title'],
            fontSize=24,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=HexColor('#1a365d'),
            fontName='Helvetica-Bold'
        )
        
        # Subtitle style
        self.subtitle_style = ParagraphStyle(
            'DataReadinessSubtitle',
            parent=self.styles['Normal'],
            fontSize=16,
            spaceAfter=20,
            alignment=TA_CENTER,
            textColor=HexColor('#2d3748'),
            fontName='Helvetica-Oblique'
        )
        
        # Heading styles
        self.h1_style = ParagraphStyle(
            'DataReadinessH1',
            parent=self.styles['Heading1'],
            fontSize=18,
            spaceAfter=15,
            spaceBefore=25,
            textColor=HexColor('#2b6cb0'),
            fontName='Helvetica-Bold',
            backColor=HexColor('#ebf8ff'),
            borderWidth=1,
            borderColor=HexColor('#3182ce'),
            borderPadding=8,
            leftIndent=10
        )
        
        self.h2_style = ParagraphStyle(
            'DataReadinessH2',
            parent=self.styles['Heading2'],
            fontSize=16,
            spaceAfter=12,
            spaceBefore=18,
            textColor=HexColor('#2c5282'),
            fontName='Helvetica-Bold',
            leftIndent=5
        )
        
        self.h3_style = ParagraphStyle(
            'DataReadinessH3',
            parent=self.styles['Heading3'],
            fontSize=14,
            spaceAfter=10,
            spaceBefore=15,
            textColor=HexColor('#3182ce'),
            fontName='Helvetica-Bold',
            leftIndent=10
        )
        
        # Body styles
        self.body_style = ParagraphStyle(
            'DataReadinessBody',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=8,
            textColor=HexColor('#2d3748'),
            alignment=TA_JUSTIFY,
            leftIndent=20,
            rightIndent=20
        )
        
        # List styles
        self.bullet_style = ParagraphStyle(
            'DataReadinessBullet',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=6,
            textColor=HexColor('#4a5568'),
            leftIndent=30,
            bulletIndent=20
        )
        
        # Table styles
        self.table_header_style = ParagraphStyle(
            'TableHeader',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=HexColor('#1a365d'),
            fontName='Helvetica-Bold',
            alignment=TA_CENTER
        )
        
        self.table_cell_style = ParagraphStyle(
            'TableCell',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=HexColor('#2d3748'),
            alignment=TA_LEFT
        )
        
        # Alert styles
        self.alert_critical_style = ParagraphStyle(
            'AlertCritical',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=HexColor('#fed7d7'),
            borderColor=HexColor('#e53e3e'),
            borderWidth=1,
            borderPadding=5,
            spaceAfter=12,
            spaceBefore=6,
            textColor=HexColor('#742a2a')
        )
        
        self.alert_warning_style = ParagraphStyle(
            'AlertWarning',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=HexColor('#fef5e7'),
            borderColor=HexColor('#ed8936'),
            borderWidth=1,
            borderPadding=5,
            spaceAfter=12,
            spaceBefore=6,
            textColor=HexColor('#744210')
        )
        
        self.alert_info_style = ParagraphStyle(
            'AlertInfo',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=HexColor('#ebf8ff'),
            borderColor=HexColor('#4299e1'),
            borderWidth=1,
            borderPadding=5,
            spaceAfter=12,
            spaceBefore=6,
            textColor=HexColor('#2c5282')
        )
        
        self.alert_success_style = ParagraphStyle(
            'AlertSuccess',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=HexColor('#f0fff4'),
            borderColor=HexColor('#48bb78'),
            borderWidth=1,
            borderPadding=5,
            spaceAfter=12,
            spaceBefore=6,
            textColor=HexColor('#22543d')
        )
    
    def generate_pdf(self, markdown_content: str, title: str = "Data Readiness Assessment Report") -> bytes:
        """Generate PDF from markdown content"""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=50,
            leftMargin=50,
            topMargin=60,
            bottomMargin=60
        )
        
        # Parse markdown and build content
        content = self._parse_markdown_to_reportlab(markdown_content, title)
        
        # Build PDF
        doc.build(content)
        buffer.seek(0)
        return buffer.read()
    
    def _clean_text(self, text: str) -> str:
        """Clean and escape text for ReportLab"""
        # Remove problematic characters and fix common issues
        text = text.replace('\\n', '\n')
        text = text.replace('\\\\', '\\')
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        text = text.replace('<think>', '')
        
        # Fix common markdown to HTML issues
        text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
        text = re.sub(r'\*(.*?)\*', r'<i>\1</i>', text)
        text = re.sub(r'`(.*?)`', r'<font name="Courier">\1</font>', text)
        
        return text
    
    def _parse_table(self, table_lines: List[str]) -> Table:
        """Parse markdown table and return ReportLab Table"""
        if len(table_lines) < 2:
            return None
            
        # Parse header
        header_line = table_lines[0]
        headers = [cell.strip() for cell in header_line.split('|')[1:-1]]  # Remove empty first/last elements
        
        # Skip separator line (table_lines[1])
        
        # Parse data rows
        rows = [headers]
        for line in table_lines[2:]:
            if line.strip():
                row_data = [cell.strip() for cell in line.split('|')[1:-1]]
                # Ensure row has same number of columns as header
                while len(row_data) < len(headers):
                    row_data.append('')
                rows.append(row_data[:len(headers)])  # Trim excess columns
        
        # Create table data with proper formatting
        table_data = []
        for i, row in enumerate(rows):
            formatted_row = []
            for cell in row:
                if i == 0:  # Header row
                    formatted_row.append(Paragraph(self._clean_text(cell), self.table_header_style))
                else:  # Data row
                    formatted_row.append(Paragraph(self._clean_text(cell), self.table_cell_style))
            table_data.append(formatted_row)
        
        # Create table
        table = Table(table_data)
        
        # Style the table
        table_style = TableStyle([
            # Header row styling
            ('BACKGROUND', (0, 0), (-1, 0), HexColor('#e2e8f0')),
            ('TEXTCOLOR', (0, 0), (-1, 0), HexColor('#1a365d')),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            
            # Data rows styling
            ('BACKGROUND', (0, 1), (-1, -1), colors.white),
            ('TEXTCOLOR', (0, 1), (-1, -1), HexColor('#2d3748')),
            ('ALIGN', (0, 1), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            
            # Grid styling
            ('GRID', (0, 0), (-1, -1), 1, HexColor('#cbd5e0')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, HexColor('#f7fafc')]),
            
            # Padding
            ('LEFTPADDING', (0, 0), (-1, -1), 6),
            ('RIGHTPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ])
        
        table.setStyle(table_style)
        return table
    
    def _extract_json_content(self, content: str) -> str:
        """Extract markdown content from JSON if present"""
        try:
            # Check if content is wrapped in JSON
            if content.strip().startswith('{') and '"generated_content"' in content:
                import json
                data = json.loads(content)
                return data.get('generated_content', content)
        except:
            pass
        return content
    
    def _parse_markdown_to_reportlab(self, markdown_content: str, title: str) -> List:
        """Parse markdown content to ReportLab elements"""
        content = []
        
        # Extract actual markdown content from JSON wrapper if present
        markdown_content = self._extract_json_content(markdown_content)
        
        # Remove markdown code block wrapper if present
        if markdown_content.strip().startswith('```markdown'):
            markdown_content = markdown_content.strip()[11:]  # Remove ```markdown
        if markdown_content.strip().endswith('```'):
            markdown_content = markdown_content.strip()[:-3]  # Remove trailing ```
        
        # Add cover page
        content.append(Paragraph(title, self.title_style))
        content.append(Spacer(1, 20))
        
        # Add generation info
        timestamp = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        content.append(Paragraph(f"Generated on {timestamp}", self.subtitle_style))
        content.append(Spacer(1, 30))
        
        # Clean the markdown content
        cleaned_content = self._clean_text(markdown_content)
        
        # Split content into lines
        lines = cleaned_content.split('\n')
        
        in_code_block = False
        code_block_content = []
        in_list = False
        list_counter = 0
        in_table = False
        table_lines = []
        
        i = 0
        while i < len(lines):
            line = lines[i]
            original_line = line
            line = line.strip()
            
            if not line:
                if not in_code_block and not in_table:
                    content.append(Spacer(1, 8))
                    in_list = False
                    list_counter = 0
                i += 1
                continue
            
            # Handle code blocks
            if line.startswith('```'):
                if in_code_block:
                    # End code block
                    if code_block_content:
                        code_text = '\n'.join(code_block_content)
                        content.append(Paragraph(f'<font name="Courier" size="9">{code_text}</font>', self.styles['Normal']))
                        content.append(Spacer(1, 10))
                    code_block_content = []
                    in_code_block = False
                else:
                    # Start code block
                    in_code_block = True
                i += 1
                continue
            
            if in_code_block:
                code_block_content.append(line)
                i += 1
                continue
            
            # Handle tables
            if '|' in line and not in_table:
                # Start of table
                in_table = True
                table_lines = [line]
                i += 1
                continue
            elif in_table:
                if '|' in line:
                    table_lines.append(line)
                    i += 1
                    continue
                else:
                    # End of table
                    table = self._parse_table(table_lines)
                    if table:
                        content.append(table)
                        content.append(Spacer(1, 15))
                    in_table = False
                    table_lines = []
                    # Process current line normally
            
            # Handle headings
            if line.startswith('# '):
                text = line[2:].strip()
                # Remove any remaining markdown formatting
                text = re.sub(r'^#+\s*', '', text)
                content.append(Paragraph(text, self.h1_style))
                in_list = False
                list_counter = 0
                
            elif line.startswith('## '):
                text = line[3:].strip()
                text = re.sub(r'^#+\s*', '', text)
                content.append(Paragraph(text, self.h2_style))
                in_list = False
                list_counter = 0
                
            elif line.startswith('### '):
                text = line[4:].strip()
                text = re.sub(r'^#+\s*', '', text)
                content.append(Paragraph(text, self.h3_style))
                in_list = False
                list_counter = 0
            
            # Handle special content blocks
            elif line.startswith('**') and ('recommendation' in line.lower() or 'action' in line.lower()):
                text = line.replace('**', '').replace('*', '').strip()
                content.append(Paragraph(f"💡 {text}", self.alert_info_style))
                in_list = False
                
            elif 'not ready' in line.lower() or 'critical' in line.lower():
                text = line.replace('**', '').replace('*', '').strip()
                content.append(Paragraph(f"⚠️ {text}", self.alert_critical_style))
                in_list = False
                
            elif 'warning' in line.lower() or 'gap' in line.lower():
                text = line.replace('**', '').replace('*', '').strip()
                content.append(Paragraph(f"⚠️ {text}", self.alert_warning_style))
                in_list = False
                
            elif 'ready' in line.lower() or 'complete' in line.lower():
                text = line.replace('**', '').replace('*', '').strip()
                content.append(Paragraph(f"✅ {text}", self.alert_success_style))
                in_list = False
            
            # Handle lists
            elif line.startswith('- ') or line.startswith('* '):
                text = line[2:].strip()
                content.append(Paragraph(f"• {text}", self.bullet_style))
                in_list = True
                
            elif re.match(r'^\d+\.', line):
                if not in_list:
                    list_counter = 0
                    in_list = True
                match = re.match(r'^(\d+)\.\s*(.*)', line)
                if match:
                    list_counter = int(match.group(1))
                    text = match.group(2)
                    content.append(Paragraph(f"{list_counter}. {text}", self.bullet_style))
            
            # Handle regular paragraphs
            else:
                if line.strip() and not line.startswith('---'):  # Skip horizontal rules
                    content.append(Paragraph(line, self.body_style))
                    in_list = False
            
            i += 1
        
        # Handle any remaining table
        if in_table and table_lines:
            table = self._parse_table(table_lines)
            if table:
                content.append(table)
                content.append(Spacer(1, 15))
        
        # Handle any remaining code block
        if in_code_block and code_block_content:
            code_text = '\n'.join(code_block_content)
            content.append(Paragraph(f'<font name="Courier" size="9">{code_text}</font>', self.styles['Normal']))
        
        return content

# Utility functions
async def save_uploaded_file(upload_file: UploadFile, temp_dir: str = None) -> str:
    """Save uploaded file to temporary location"""
    if temp_dir is None:
        temp_dir = tempfile.mkdtemp()
    
    file_path = os.path.join(temp_dir, upload_file.filename)
    
    try:
        content = await upload_file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        return file_path
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving file: {str(e)}"
        )

# Router
router = APIRouter(prefix="/data-readiness", tags=["Data Readiness"])

# Get API key from environment
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    print("Warning: GROQ_API_KEY not found in environment variables")

# Initialize processors
file_processor = FileProcessor()
pdf_generator = DataReadinessPDFGenerator()

@router.post("/analyze", response_model=DataReadinessAnalysisResponse)
async def analyze_data_readiness(
    use_case_id: int = Form(...),
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Analyze data readiness for a specific use case with uploaded data file
    
    This endpoint:
    1. Processes the uploaded data file
    2. Retrieves use case information from the database
    3. Analyzes data readiness using AI
    4. Returns comprehensive markdown analysis
    
    Parameters:
    - use_case_id: Form field with the use case ID
    - file: Upload file (CSV, Excel, JSON, TXT, Parquet)
    """
    
    if not GROQ_API_KEY:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="AI service not configured"
        )
    
    # Get use case data
    use_case = db.query(GeneratedUseCase).filter(
        GeneratedUseCase.id == use_case_id
    ).first()
    
    if not use_case:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Use case not found"
        )
    
    # Verify access to use case through session and project ownership
    session = db.query(PreWorkshopSession).filter(
        PreWorkshopSession.id == use_case.session_id
    ).first()
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    project = db.query(Project).filter(
        Project.id == session.project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Access denied"
        )
    
    # Process uploaded file
    temp_dir = tempfile.mkdtemp()
    try:
        file_path = await save_uploaded_file(file, temp_dir)
        data_file = await file_processor.process_file(file_path, file.filename)
        
        # Prepare use case data
        use_case_data = {
            'id': use_case.id,
            'title': use_case.title,
            'description': use_case.description,
            'aws_services': use_case.aws_services,
            'primary_genai_capability': use_case.primary_genai_capability,
            'business_category': use_case.business_category,
            'customer_pain_points': use_case.customer_pain_points,
            'priority': use_case.priority,
            'complexity': use_case.complexity,
            'dependencies': use_case.dependencies,
            'risks': use_case.risks
        }
        
        # Analyze data readiness
        analyzer = DataReadinessAnalyzer(GROQ_API_KEY)
        analysis_result = await analyzer.analyze_data_readiness(use_case_data, [data_file])
        
        return DataReadinessAnalysisResponse(**analysis_result)
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error analyzing data readiness: {str(e)}"
        )
    
    finally:
        # Clean up temporary files
        shutil.rmtree(temp_dir, ignore_errors=True)

@router.post("/generate-pdf")
async def generate_data_readiness_pdf(
    content: str,
    current_user: User = Depends(get_current_user)
):
    """
    Generate PDF report from data readiness analysis markdown content
    
    This endpoint:
    1. Takes markdown-formatted data readiness content
    2. Generates a beautifully formatted PDF report
    3. Returns the PDF as downloadable file
    
    Parameters:
    - content: The markdown content to convert to PDF
    """
    
    try:
        # Generate PDF from markdown content
        pdf_content = pdf_generator.generate_pdf(
            content, 
            "Data Readiness Assessment Report"
        )
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"data_readiness_report_{timestamp}.pdf"
        
        return Response(
            content=pdf_content,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename={filename}"
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generating PDF: {str(e)}"
        )

@router.get("/supported-formats")
async def get_supported_formats():
    """Get list of supported file formats for data readiness analysis"""
    return {
        "supported_formats": list(FileProcessor.SUPPORTED_EXTENSIONS.keys()),
        "format_descriptions": {
            ".csv": "Comma-separated values",
            ".xlsx": "Excel spreadsheet (2007+)",
            ".xls": "Excel spreadsheet (legacy)",
            ".txt": "Plain text file",
            ".json": "JSON data file",
            ".parquet": "Parquet columnar format"
        },
        "analysis_capabilities": [
            "Data quality assessment",
            "Requirements matching",
            "Column analysis",
            "Volume validation",
            "Completeness checking"
        ]
    }

@router.get("/health")
async def health_check():
    """Health check endpoint for data readiness service"""
    return {
        "status": "healthy",
        "ai_service": "available" if GROQ_API_KEY else "not_configured",
        "supported_formats": len(FileProcessor.SUPPORTED_EXTENSIONS),
        "timestamp": datetime.utcnow().isoformat()
    }