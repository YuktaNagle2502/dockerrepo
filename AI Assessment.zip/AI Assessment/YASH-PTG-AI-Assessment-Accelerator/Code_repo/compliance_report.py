from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Response, Form
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
import json
import os
import uuid
from pathlib import Path
import pandas as pd
import asyncio
from groq import Groq
import time
import tempfile
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
import io
import openpyxl
from openpyxl import load_workbook
import csv
import docx
from docx import Document
import PyPDF2
import re
import markdown
from markdown.extensions import codehilite
import zipfile
import mimetypes

# Import database configuration and auth dependencies
from database import get_db
from login_project import get_current_user, User, Project

# Import pre-workshop models to get use case data
from pre_workshop import GeneratedUseCase, PreWorkshopSession

# Pydantic Models
class ComplianceAnalysisRequest(BaseModel):
    use_case_id: int
    analysis_type: str = Field(default="comprehensive", description="Type of analysis: comprehensive, gdpr, security, industry")
    include_recommendations: bool = Field(default=True, description="Include compliance recommendations")
    include_risk_assessment: bool = Field(default=True, description="Include risk assessment")

class ComplianceAnalysisResponse(BaseModel):
    use_case_id: int
    analysis_type: str
    generated_content: str
    compliance_score: float
    risk_level: str
    recommendations_count: int
    generated_at: datetime

class PDFGenerationRequest(BaseModel):
    content: str
    title: str = Field(default="Compliance & Integration Report")
    include_toc: bool = Field(default=True, description="Include table of contents")
    include_executive_summary: bool = Field(default=True, description="Include executive summary")

class DataFileInfo(BaseModel):
    filename: str
    file_type: str
    size_bytes: int
    records_count: Optional[int] = None
    columns_count: Optional[int] = None
    has_pii: bool = False
    has_sensitive_data: bool = False
    content: Optional[str] = None  # Content preview for small files

class ComplianceIssue(BaseModel):
    severity: str  # Critical, High, Medium, Low
    category: str  # Privacy, Security, Regulatory, Integration
    title: str
    description: str
    recommendation: str
    aws_service_impact: Optional[str] = None

# File Processing Classes
class FileProcessor:
    """Process various file types and extract relevant data for compliance analysis"""
    
    SUPPORTED_EXTENSIONS = {
        '.csv': 'text/csv',
        '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        '.xls': 'application/vnd.ms-excel',
        '.txt': 'text/plain',
        '.json': 'application/json',
        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        '.pdf': 'application/pdf',
        '.zip': 'application/zip'
    }
    
    PII_PATTERNS = {
        'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        'phone': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        'ssn': r'\b\d{3}-\d{2}-\d{4}\b',
        'credit_card': r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',
        'ip_address': r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
        'passport': r'\b[A-Z]{1,2}\d{6,9}\b'
    }
    
    SENSITIVE_KEYWORDS = [
        'password', 'secret', 'token', 'api_key', 'private_key', 'confidential',
        'salary', 'income', 'medical', 'health', 'diagnosis', 'treatment',
        'financial', 'banking', 'account', 'transaction', 'payment'
    ]
    
    def __init__(self):
        self.temp_dir = None
    
    async def process_file(self, file_path: str, filename: str) -> DataFileInfo:
        """Process uploaded file and extract metadata"""
        try:
            file_size = os.path.getsize(file_path)
            file_ext = Path(filename).suffix.lower()
            
            if file_ext not in self.SUPPORTED_EXTENSIONS:
                raise ValueError(f"Unsupported file type: {file_ext}")
            
            file_info = DataFileInfo(
                filename=filename,
                file_type=self.SUPPORTED_EXTENSIONS[file_ext],
                size_bytes=file_size
            )
            
            # Process based on file type
            if file_ext == '.csv':
                await self._process_csv(file_path, file_info)
            elif file_ext in ['.xlsx', '.xls']:
                await self._process_excel(file_path, file_info)
            elif file_ext == '.txt':
                await self._process_text(file_path, file_info)
            elif file_ext == '.json':
                await self._process_json(file_path, file_info)
            elif file_ext == '.docx':
                await self._process_docx(file_path, file_info)
            elif file_ext == '.pdf':
                await self._process_pdf(file_path, file_info)
            elif file_ext == '.zip':
                await self._process_zip(file_path, file_info)
            
            return file_info
            
        except Exception as e:
            raise ValueError(f"Error processing file: {str(e)}")
    
    async def _process_csv(self, file_path: str, file_info: DataFileInfo):
        """Process CSV files"""
        try:
            df = pd.read_csv(file_path, nrows=50)  # Sample first 1000 rows
            file_info.records_count = len(df)
            file_info.columns_count = len(df.columns)
            
            # Check for PII and sensitive data
            content = df.to_string()
            file_info.content=content
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
            
        except Exception as e:
            # Try different encodings
            encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252']
            for encoding in encodings:
                try:
                    df = pd.read_csv(file_path, encoding=encoding, nrows=1000)
                    file_info.records_count = len(df)
                    file_info.columns_count = len(df.columns)
                    content = df.to_string()
                    file_info.has_pii = self._detect_pii(content)
                    file_info.has_sensitive_data = self._detect_sensitive_data(content)
                    break
                except:
                    continue
    
    async def _process_excel(self, file_path: str, file_info: DataFileInfo):
        """Process Excel files"""
        try:
            df = pd.read_excel(file_path, nrows=50)  # Sample first 1000 rows
            file_info.records_count = len(df)
            file_info.columns_count = len(df.columns)
            
            content = df.to_string()
            file_info.content = content
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
            
        except Exception:
            # Try with openpyxl
            try:
                workbook = load_workbook(file_path, read_only=True)
                sheet = workbook.active
                rows = list(sheet.iter_rows(max_row=1000, values_only=True))
                file_info.records_count = len(rows)
                file_info.columns_count = len(rows[0]) if rows else 0
                
                content = str(rows)
                file_info.has_pii = self._detect_pii(content)
                file_info.has_sensitive_data = self._detect_sensitive_data(content)
                
            except Exception as e:
                raise ValueError(f"Error processing Excel file: {str(e)}")
    
    async def _process_text(self, file_path: str, file_info: DataFileInfo):
        """Process text files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            file_info.content = content
            file_info.records_count = len(content.splitlines())
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
            
        except UnicodeDecodeError:
            # Try different encodings
            encodings = ['latin-1', 'iso-8859-1', 'cp1252']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    file_info.records_count = len(content.splitlines())
                    file_info.has_pii = self._detect_pii(content)
                    file_info.has_sensitive_data = self._detect_sensitive_data(content)
                    break
                except:
                    continue
    
    async def _process_json(self, file_path: str, file_info: DataFileInfo):
        """Process JSON files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if isinstance(data, list):
                file_info.records_count = len(data)
                file_info.columns_count = len(data[0].keys()) if data and isinstance(data[0], dict) else 0
            elif isinstance(data, dict):
                file_info.records_count = 1
                file_info.columns_count = len(data.keys())
            
            content = json.dumps(data, default=str)
            file_info.content = content
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
            
        except Exception as e:
            raise ValueError(f"Error processing JSON file: {str(e)}")
    
    async def _process_docx(self, file_path: str, file_info: DataFileInfo):
        """Process Word documents"""
        try:
            doc = Document(file_path)
            content = "\n".join([paragraph.text for paragraph in doc.paragraphs])
            file_info.content = content
            file_info.records_count = len(doc.paragraphs)
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
            
        except Exception as e:
            raise ValueError(f"Error processing Word document: {str(e)}")
    
    async def _process_pdf(self, file_path: str, file_info: DataFileInfo):
        """Process PDF files"""
        try:
            with open(file_path, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                content = ""
                for page in pdf_reader.pages:
                    content += page.extract_text()
            file_info.content = content
            file_info.records_count = len(pdf_reader.pages)
            file_info.has_pii = self._detect_pii(content)
            file_info.has_sensitive_data = self._detect_sensitive_data(content)
            
        except Exception as e:
            raise ValueError(f"Error processing PDF file: {str(e)}")
    
    async def _process_zip(self, file_path: str, file_info: DataFileInfo):
        """Process ZIP files"""
        try:
            with zipfile.ZipFile(file_path, 'r') as zip_ref:
                file_list = zip_ref.namelist()
                file_info.records_count = len(file_list)
                
                # Extract and analyze small files
                content = ""
                for file_name in file_list[:10]:  # Limit to first 10 files
                    if zip_ref.getinfo(file_name).file_size < 1024 * 1024:  # Files smaller than 1MB
                        try:
                            with zip_ref.open(file_name) as f:
                                content += f.read().decode('utf-8', errors='ignore')
                        except:
                            continue
                
                file_info.has_pii = self._detect_pii(content)
                file_info.content = content
                file_info.has_sensitive_data = self._detect_sensitive_data(content)
                
        except Exception as e:
            raise ValueError(f"Error processing ZIP file: {str(e)}")
    
    def _detect_pii(self, content: str) -> bool:
        """Detect PII patterns in content"""
        content_lower = content.lower()
        
        # Check regex patterns
        for pattern_name, pattern in self.PII_PATTERNS.items():
            if re.search(pattern, content, re.IGNORECASE):
                return True
        
        # Check for common PII keywords
        pii_keywords = ['email', 'phone', 'address', 'ssn', 'social security', 'passport', 'license']
        for keyword in pii_keywords:
            if keyword in content_lower:
                return True
        
        return False
    
    def _detect_sensitive_data(self, content: str) -> bool:
        """Detect sensitive data patterns"""
        content_lower = content.lower()
        
        for keyword in self.SENSITIVE_KEYWORDS:
            if keyword in content_lower:
                return True
        
        return False

# Compliance Analysis Engine
class ComplianceAnalyzer:
    """AI-powered compliance analysis engine"""
    
    def __init__(self, api_key: str, model: str = "deepseek-r1-distill-llama-70b"):
        self.client = Groq(api_key=api_key)
        self.model = model
        self.compliance_frameworks = {
            'gdpr': 'General Data Protection Regulation',
            'ccpa': 'California Consumer Privacy Act',
            'hipaa': 'Health Insurance Portability and Accountability Act',
            'sox': 'Sarbanes-Oxley Act',
            'pci_dss': 'Payment Card Industry Data Security Standard',
            'iso_27001': 'ISO/IEC 27001 Information Security Management',
            'aws_security': 'AWS Security Best Practices',
            'nist': 'NIST Cybersecurity Framework'
        }
    
    async def analyze_compliance(self, use_case_data: Dict, file_info: DataFileInfo, analysis_type: str = "comprehensive") -> Dict:
        """Generate comprehensive compliance analysis"""
        
        # Prepare context for AI analysis
        context = self._prepare_analysis_context(use_case_data, file_info, analysis_type)
        
        # Generate analysis using AI
        analysis_result = await self._generate_ai_analysis(context, analysis_type,file_info.content)
        
        # Calculate compliance score
        compliance_score = self._calculate_compliance_score(analysis_result)
        
        # Determine risk level
        risk_level = self._determine_risk_level(compliance_score, file_info)
        
        return {
            'use_case_id': use_case_data.get('id'),
            'analysis_type': analysis_type,
            'generated_content': analysis_result,
            'compliance_score': compliance_score,
            'risk_level': risk_level,
            'recommendations_count': len(re.findall(r'## Recommendation', analysis_result)),
            'generated_at': datetime.utcnow()
        }
    
    def _prepare_analysis_context(self, use_case_data: Dict, file_info: DataFileInfo, analysis_type: str) -> str:
        """Prepare context for AI analysis"""
        context = f"""
        # Use Case Information
        - **Title**: {use_case_data.get('title', 'N/A')}
        - **Description**: {use_case_data.get('description', 'N/A')}
        - **AWS Services**: {', '.join(use_case_data.get('aws_services', []))}
        - **Primary GenAI Capability**: {use_case_data.get('primary_genai_capability', 'N/A')}
        - **Business Category**: {use_case_data.get('business_category', 'N/A')}
        - **Priority**: {use_case_data.get('priority', 'N/A')}
        - **Complexity**: {use_case_data.get('complexity', 'N/A')}
        - **Customer Pain Points**: {', '.join(use_case_data.get('customer_pain_points', []))}
        
        # Data File Information
        - **Filename**: {file_info.filename}
        - **File Type**: {file_info.file_type}
        - **Size**: {file_info.size_bytes} bytes
        - **Records Count**: {file_info.records_count or 'N/A'}
        - **Columns Count**: {file_info.columns_count or 'N/A'}
        - **Contains PII**: {file_info.has_pii}
        - **Contains Sensitive Data**: {file_info.has_sensitive_data}
        
        # Analysis Type
        Analysis Focus: {analysis_type}
        
        # Compliance Frameworks to Consider
        {', '.join(self.compliance_frameworks.values())}
        """
        return context
    
    async def _generate_ai_analysis(self, context: str, analysis_type: str,sample_data:str) -> str:
        """Generate AI-powered compliance analysis"""
        
        system_prompt = f"""
        You are an expert compliance analyst specializing in GenAI implementations, data privacy, and AWS security.
        Your task is to analyze the provided use case and data information to generate a comprehensive compliance report.
        
        Focus on the following areas:
        1. Data Privacy & Protection (GDPR, CCPA, etc.) and what specific Data privacy we should follow
        like Is it for Medical (Healthcare providers are subject to various laws and regulations, such as HIPAA in the US and GDPR in Europe)
        and other different different data privacy laws. You have to provide the specific data privacy laws that we should follow for this data.
        2. Security Compliance (ISO 27001, NIST, AWS Security)
        3. Industry-specific Regulations (HIPAA, SOX, PCI-DSS)
        4. AWS GenAI Service Compliance
        5. Data Governance & Integration
        6. Risk Assessment & Mitigation
        
        Generate a detailed compliance report in markdown format with the following structure:
        - Executive Summary
        - Compliance Status Overview
        - Detailed Analysis by Framework
        - Risk Assessment
        - Recommendations
        - Implementation Roadmap
        - AWS Service Specific Considerations
        
        Be specific about compliance requirements and provide actionable recommendations.
        """
        
        user_request = f"""
        Please analyze the following use case and data information for compliance:
        And provide what specific data privacy laws we should follow for this data.
        {context}
        This is the sample data for which you need to check what are the different 
        GDPR compliance we should follow {sample_data}
        Analyze the data and then decide what is this data is representing and what 
        are the different data privacy laws we should follow.
        Generate a comprehensive compliance and integration report in markdown format.
        Focus on {analysis_type} analysis and provide specific, actionable recommendations.
        ****Instruction to follow****
        - Use markdown format for the report
        - Do write as I need to provide the specific data privacy laws that we should follow for this data.
        - Make it like it is a compliance report
        """
        
        try:
            response = await asyncio.get_event_loop().run_in_executor(
                None, 
                lambda: self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_request}
                    ],
                    temperature=0.7
                )
            )
            
            return response.choices[0].message.content.strip().replace("<think>", "")
            
        except Exception as e:
            return f"""
            # Compliance Analysis Error
            
            An error occurred while generating the compliance analysis: {str(e)}
            
            ## Manual Review Required
            
            Please review the following items manually:
            - Data privacy compliance for PII handling
            - Security requirements for GenAI implementation
            - Industry-specific regulatory requirements
            - AWS service compliance configurations
            """
    
    def _calculate_compliance_score(self, analysis_content: str) -> float:
        """Calculate compliance score based on analysis content"""
        # Simple scoring based on content analysis
        score = 100.0
        
        # Reduce score for identified issues
        critical_issues = len(re.findall(r'critical|severe|high risk', analysis_content.lower()))
        high_issues = len(re.findall(r'high priority|important|significant', analysis_content.lower()))
        medium_issues = len(re.findall(r'medium|moderate|consider', analysis_content.lower()))
        
        score -= critical_issues * 20
        score -= high_issues * 10
        score -= medium_issues * 5
        
        # Ensure score is between 0 and 100
        return max(0.0, min(100.0, score))
    
    def _determine_risk_level(self, compliance_score: float, file_info: DataFileInfo) -> str:
        """Determine overall risk level"""
        # Adjust risk based on compliance score
        if compliance_score >= 90:
            base_risk = "Low"
        elif compliance_score >= 70:
            base_risk = "Medium"
        elif compliance_score >= 50:
            base_risk = "High"
        else:
            base_risk = "Critical"
        
        # Increase risk if PII or sensitive data is detected
        if file_info.has_pii or file_info.has_sensitive_data:
            risk_levels = ["Low", "Medium", "High", "Critical"]
            current_index = risk_levels.index(base_risk)
            if current_index < len(risk_levels) - 1:
                base_risk = risk_levels[current_index + 1]
        
        return base_risk

# PDF Report Generator
class CompliancePDFGenerator:
    """Generate beautiful PDF reports from markdown content"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        # Title style
        self.title_style = ParagraphStyle(
            'ComplianceTitle',
            parent=self.styles['Title'],
            fontSize=24,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=colors.HexColor('#1a365d'),
            fontName='Helvetica-Bold'
        )
        
        # Subtitle style
        self.subtitle_style = ParagraphStyle(
            'ComplianceSubtitle',
            parent=self.styles['Normal'],
            fontSize=16,
            spaceAfter=20,
            alignment=TA_CENTER,
            textColor=colors.HexColor('#2d3748'),
            fontName='Helvetica-Oblique'
        )
        
        # Heading styles
        self.h1_style = ParagraphStyle(
            'ComplianceH1',
            parent=self.styles['Heading1'],
            fontSize=18,
            spaceAfter=20,
            spaceBefore=30,
            textColor=colors.HexColor('#2b6cb0'),
            fontName='Helvetica-Bold',
            backColor=colors.HexColor('#ebf8ff'),
            borderWidth=1,
            borderColor=colors.HexColor('#3182ce'),
            borderPadding=5,
            leftIndent=10
        )
        
        self.h2_style = ParagraphStyle(
            'ComplianceH2',
            parent=self.styles['Heading2'],
            fontSize=16,
            spaceAfter=20,
            spaceBefore=18,
            textColor=colors.HexColor('#2c5282'),
            fontName='Helvetica-Bold',
            leftIndent=5
        )
        
        self.h3_style = ParagraphStyle(
            'ComplianceH3',
            parent=self.styles['Heading3'],
            fontSize=14,
            spaceAfter=10,
            spaceBefore=15,
            textColor=colors.HexColor('#3182ce'),
            fontName='Helvetica-Bold',
            leftIndent=10
        )
        
        self.h4_style = ParagraphStyle(
            'ComplianceH4',
            parent=self.styles['Heading4'],
            fontSize=12,
            spaceAfter=8,
            spaceBefore=12,
            textColor=colors.HexColor('#4299e1'),
            fontName='Helvetica-Bold',
            leftIndent=15
        )
        
        # Body styles
        self.body_style = ParagraphStyle(
            'ComplianceBody',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=8,
            textColor=colors.HexColor('#2d3748'),
            alignment=TA_JUSTIFY,
            leftIndent=20,
            rightIndent=20
        )
        
        # List styles
        self.bullet_style = ParagraphStyle(
            'ComplianceBullet',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=6,
            textColor=colors.HexColor('#4a5568'),
            leftIndent=30,
            bulletIndent=20
        )
        
        self.numbered_style = ParagraphStyle(
            'ComplianceNumbered',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=6,
            textColor=colors.HexColor('#4a5568'),
            leftIndent=30,
            bulletIndent=20
        )
        
        # Alert styles
        self.alert_critical_style = ParagraphStyle(
            'AlertCritical',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=colors.HexColor('#fed7d7'),
            borderColor=colors.HexColor('#e53e3e'),
            borderWidth=2,
            borderPadding=5,
            spaceAfter=20,
            spaceBefore=15,
            textColor=colors.HexColor('#742a2a')
        )
        
        self.alert_warning_style = ParagraphStyle(
            'AlertWarning',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=colors.HexColor('#fef5e7'),
            borderColor=colors.HexColor('#ed8936'),
            borderWidth=2,
            borderPadding=5,
            spaceAfter=20,
            spaceBefore=15,
            textColor=colors.HexColor('#744210')
        )
        
        self.alert_info_style = ParagraphStyle(
            'AlertInfo',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=colors.HexColor('#ebf8ff'),
            borderColor=colors.HexColor('#4299e1'),
            borderWidth=2,
            borderPadding=5,
            spaceAfter=20,
            spaceBefore=15,
            textColor=colors.HexColor('#2c5282')
        )
        
        self.alert_success_style = ParagraphStyle(
            'AlertSuccess',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=colors.HexColor('#f0fff4'),
            borderColor=colors.HexColor('#48bb78'),
            borderWidth=2,
            borderPadding=5,
            spaceAfter=20,
            spaceBefore=15,
            textColor=colors.HexColor('#22543d')
        )
        
        # Code style
        self.code_style = ParagraphStyle(
            'ComplianceCode',
            parent=self.styles['Code'],
            fontSize=9,
            backColor=colors.HexColor('#f7fafc'),
            borderColor=colors.HexColor('#e2e8f0'),
            borderWidth=1,
            borderPadding=8,
            spaceAfter=10,
            spaceBefore=5,
            fontName='Courier'
        )
        
        # Quote style
        self.quote_style = ParagraphStyle(
            'ComplianceQuote',
            parent=self.styles['Normal'],
            fontSize=11,
            backColor=colors.HexColor('#f7fafc'),
            borderColor=colors.HexColor('#cbd5e0'),
            borderWidth=0,
            leftIndent=30,
            rightIndent=30,
            spaceAfter=10,
            spaceBefore=5,
            textColor=colors.HexColor('#4a5568'),
            fontName='Helvetica-Oblique'
        )
    
    def generate_pdf(self, markdown_content: str, title: str = "Compliance & Integration Report") -> bytes:
        """Generate PDF from markdown content"""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=50,
            leftMargin=50,
            topMargin=60,
            bottomMargin=60
        )
        
        # Parse markdown and build content
        content = self._parse_markdown_to_reportlab(markdown_content, title)
        
        # Build PDF
        doc.build(content)
        buffer.seek(0)
        return buffer.read()
    
    def _clean_text(self, text: str) -> str:
        """Clean and escape text for ReportLab"""
        # Remove problematic characters and fix common issues
        text = text.replace('\\n', '\n')
        text = text.replace('\\\\', '\\')
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        
        # Fix common markdown to HTML issues
        text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
        text = re.sub(r'\*(.*?)\*', r'<i>\1</i>', text)
        text = re.sub(r'`(.*?)`', r'<font name="Courier">\1</font>', text)
        
        return text
    
    def _parse_markdown_to_reportlab(self, markdown_content: str, title: str) -> List:
        """Parse markdown content to ReportLab elements"""
        content = []
        
        # Add cover page
        content.append(Paragraph(title, self.title_style))
        content.append(Spacer(1, 20))
        
        # Add generation info
        timestamp = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        content.append(Paragraph(f"Generated on {timestamp}", self.subtitle_style))
        content.append(Spacer(1, 30))
        
        # Add decorative line
        content.append(Spacer(1, 20))
        
        # Clean the markdown content
        cleaned_content = self._clean_text(markdown_content)
        
        # Split content into lines
        lines = cleaned_content.split('\n')
        
        in_code_block = False
        code_block_content = []
        in_list = False
        list_counter = 0
        
        for line in lines:
            original_line = line
            line = line.strip()
            
            if not line:
                if not in_code_block:
                    content.append(Spacer(1, 8))
                    in_list = False
                    list_counter = 0
                continue
            
            # Handle code blocks
            if line.startswith('```'):
                if in_code_block:
                    # End code block
                    if code_block_content:
                        code_text = '\n'.join(code_block_content)
                        content.append(Paragraph(code_text, self.code_style))
                        content.append(Spacer(1, 10))
                    code_block_content = []
                    in_code_block = False
                else:
                    # Start code block
                    in_code_block = True
                continue
            
            if in_code_block:
                code_block_content.append(line)
                continue
            
            # Handle headings
            if line.startswith('# '):
                text = line[2:].strip()
                content.append(Paragraph(text, self.h1_style))
                in_list = False
                list_counter = 0
                
            elif line.startswith('## '):
                text = line[3:].strip()
                content.append(Paragraph(text, self.h2_style))
                in_list = False
                list_counter = 0
                
            elif line.startswith('### '):
                text = line[4:].strip()
                content.append(Paragraph(text, self.h3_style))
                in_list = False
                list_counter = 0
                
            elif line.startswith('#### '):
                text = line[5:].strip()
                content.append(Paragraph(text, self.h4_style))
                in_list = False
                list_counter = 0
            
            # Handle alerts/callouts
            elif 'critical' in line.lower() or 'severe' in line.lower():
                text = line.replace('**', '').replace('*', '')
                content.append(Paragraph(f"⚠️ {text}", self.alert_critical_style))
                content.append(Spacer(1, 12))
                in_list = False
                
            elif 'warning' in line.lower() or 'caution' in line.lower():
                text = line.replace('**', '').replace('*', '')
                content.append(Paragraph(f"⚠️ {text}", self.alert_warning_style))
                content.append(Spacer(1, 12))
                in_list = False
                
            elif 'recommendation' in line.lower() or 'best practice' in line.lower():
                text = line.replace('**', '').replace('*', '')
                content.append(Paragraph(f"💡 {text}", self.alert_info_style))
                in_list = False
                
            elif 'compliant' in line.lower() or 'approved' in line.lower():
                text = line.replace('**', '').replace('*', '')
                content.append(Paragraph(f"✅ {text}", self.alert_success_style))
                in_list = False
            
            # Handle lists
            elif line.startswith('- ') or line.startswith('* '):
                text = line[2:].strip()
                content.append(Paragraph(f"• {text}", self.bullet_style))
                in_list = True
                
            elif re.match(r'^\d+\.', line):
                if not in_list:
                    list_counter = 0
                    in_list = True
                list_counter += 1
                text = re.sub(r'^\d+\.\s*', '', line)
                content.append(Paragraph(f"{list_counter}. {text}", self.numbered_style))
            
            # Handle quotes
            elif line.startswith('>'):
                text = line[1:].strip()
                content.append(Paragraph(text, self.quote_style))
                in_list = False
            
            # Handle regular paragraphs
            else:
                if line.strip():
                    content.append(Paragraph(line, self.body_style))
                    in_list = False
        
        # Handle any remaining code block
        if in_code_block and code_block_content:
            code_text = '\n'.join(code_block_content)
            content.append(Paragraph(code_text, self.code_style))
        
        return content

# Utility functions
async def save_uploaded_file(upload_file: UploadFile, temp_dir: str = None) -> str:
    """Save uploaded file to temporary location"""
    if temp_dir is None:
        temp_dir = tempfile.mkdtemp()
    
    file_path = os.path.join(temp_dir, upload_file.filename)
    
    try:
        content = await upload_file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        return file_path
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving file: {str(e)}"
        )

# Router
router = APIRouter(prefix="/compliance", tags=["Compliance & Integration"])

# Get API key from environment
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    print("Warning: GROQ_API_KEY not found in environment variables")

# Initialize processors
file_processor = FileProcessor()
pdf_generator = CompliancePDFGenerator()

@router.post("/analyze", response_model=ComplianceAnalysisResponse)
async def analyze_compliance(
    use_case_id: int = Form(...),
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Generate compliance analysis report from data file and use case
    
    This endpoint:
    1. Processes the uploaded data file
    2. Retrieves use case information
    3. Generates comprehensive compliance analysis using AI
    4. Returns markdown-formatted report content
    
    Parameters:
    - use_case_id: Form field with the use case ID
    - file: Upload file (any supported format)
    """
    
    if not GROQ_API_KEY:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="AI service not configured"
        )
    
    # Get use case data
    use_case = db.query(GeneratedUseCase).filter(
        GeneratedUseCase.id == use_case_id
    ).first()
    
    if not use_case:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Use case not found"
        )
    
    # Verify access to use case through session and project ownership
    session = db.query(PreWorkshopSession).filter(
        PreWorkshopSession.id == use_case.session_id
    ).first()
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    project = db.query(Project).filter(
        Project.id == session.project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Access denied"
        )
    
    # Process uploaded file
    temp_dir = tempfile.mkdtemp()
    try:
        file_path = await save_uploaded_file(file, temp_dir)
        file_info = await file_processor.process_file(file_path, file.filename)
        
        # Prepare use case data
        use_case_data = {
            'id': use_case.id,
            'title': use_case.title,
            'description': use_case.description,
            'aws_services': use_case.aws_services,
            'primary_genai_capability': use_case.primary_genai_capability,
            'business_category': use_case.business_category,
            'customer_pain_points': use_case.customer_pain_points,
            'priority': use_case.priority,
            'complexity': use_case.complexity,
            'dependencies': use_case.dependencies,
            'risks': use_case.risks
        }
        
        # Generate compliance analysis
        analyzer = ComplianceAnalyzer(GROQ_API_KEY)
        analysis_result = await analyzer.analyze_compliance(
            use_case_data, 
            file_info, 
            "comprehensive"  # Default to comprehensive analysis
        )
        
        return ComplianceAnalysisResponse(**analysis_result)
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error analyzing compliance: {str(e)}"
        )
    
    finally:
        # Clean up temporary files
        import shutil
        shutil.rmtree(temp_dir, ignore_errors=True)

@router.post("/generate-pdf")
async def generate_compliance_pdf(
    content: str,
    current_user: User = Depends(get_current_user)
):
    """
    Generate PDF report from compliance analysis content
    
    This endpoint:
    1. Takes markdown-formatted compliance content
    2. Generates a beautifully formatted PDF report
    3. Returns the PDF as downloadable file
    
    Parameters:
    - content: The markdown content to convert to PDF
    """
    
    try:
        # Generate PDF from markdown content
        pdf_content = pdf_generator.generate_pdf(
            content, 
            "Compliance & Integration Report"
        )
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"compliance_report_{timestamp}.pdf"
        
        return Response(
            content=pdf_content,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename={filename}"
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generating PDF: {str(e)}"
        )

@router.get("/supported-formats")
async def get_supported_formats():
    """Get list of supported file formats for compliance analysis"""
    return {
        "supported_formats": list(FileProcessor.SUPPORTED_EXTENSIONS.keys()),
        "format_descriptions": {
            ".csv": "Comma-separated values",
            ".xlsx": "Excel spreadsheet (2007+)",
            ".xls": "Excel spreadsheet (legacy)",
            ".txt": "Plain text file",
            ".json": "JSON data file",
            ".docx": "Word document",
            ".pdf": "PDF document",
            ".zip": "ZIP archive"
        },
        "compliance_frameworks": {
            "comprehensive": "Full compliance analysis across all frameworks",
            "gdpr": "GDPR-focused privacy analysis",
            "security": "Security and cybersecurity compliance",
            "industry": "Industry-specific regulatory compliance"
        }
    }

@router.get("/health")
async def health_check():
    """Health check endpoint for compliance service"""
    return {
        "status": "healthy",
        "ai_service": "available" if GROQ_API_KEY else "not_configured",
        "supported_formats": len(FileProcessor.SUPPORTED_EXTENSIONS),
        "timestamp": datetime.utcnow().isoformat()
    }