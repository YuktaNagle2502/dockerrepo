from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from contextlib import asynccontextmanager

# Import database configuration
from database import create_tables, engine, Base

# Import routers
from login_project import router as login_project_router
# Add more routers as you create them:
from pre_workshop import router as pre_workshop_router
# from use_case_discovery import router as use_case_discovery_router
from data_readiness_report import router as data_readiness_router
from compliance_report import router as compliance_integration_router
from ai_profiling_data import router as ai_profiling_router
from model_evaluation import router as model_eval_router
from spirint_plan_generation import router as sprint_planning_router
from report_data import reports_router as report_data_router
# from roadmap import router as roadmap_router
# from roi_biz_case import router as roi_biz_case_router
# from final_readout import router as final_readout_router

# Lifespan context manager for startup/shutdown events
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    print("Starting up...")
    create_tables()
    print("Database tables created successfully")
    yield
    # Shutdown
    print("Shutting down...")

# Create FastAPI app with lifespan events
app = FastAPI(
    title="GenAI Assessment Platform",
    description="A comprehensive platform for GenAI assessment and implementation",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure this properly for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(login_project_router)
app.include_router(pre_workshop_router)
# app.include_router(use_case_discovery_router)
app.include_router(data_readiness_router)
app.include_router(compliance_integration_router)
app.include_router(ai_profiling_router)
app.include_router(model_eval_router)
app.include_router(report_data_router)
app.include_router(sprint_planning_router)
# app.include_router(roadmap_router)
# app.include_router(roi_biz_case_router)
# app.include_router(final_readout_router)

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "GenAI Assessment Platform API",
        "version": "1.0.0",
        "status": "active"
    }

# Health check endpoint
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "database": "connected"
    }

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={
            "message": "Internal server error",
            "detail": str(exc)
        }
    )

# Run the application
if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )
