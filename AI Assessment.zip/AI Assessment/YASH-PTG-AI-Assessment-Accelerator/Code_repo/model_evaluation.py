import boto3
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Response, Form
from openai import AzureOpenAI
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
import json
import os
import uuid
from pathlib import Path
import asyncio
from groq import Groq
import time
import tempfile
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
import io
import openpyxl
from openpyxl import load_workbook
import csv
import re
from difflib import SequenceMatcher
import logging
import aiohttp
import pandas as pd
from pricing import PriceCalculator
from reportlab.platypus.flowables import KeepTogether

# Import database configuration and auth dependencies
from database import get_db
from login_project import get_current_user, User, Project

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Pydantic Models
class ModelEvaluationRequest(BaseModel):
    models: List[str] = Field(..., description="List of models to evaluate")
    evaluation_type: str = Field(default="accuracy", description="Type of evaluation: accuracy, performance, comprehensive")
    use_llm_judge: bool = Field(default=True, description="Use LLM as judge for scoring")
    max_tokens: int = Field(default=1000, description="Maximum tokens for model responses")
    temperature: float = Field(default=0.7, description="Temperature for model responses")

class ModelEvaluationResponse(BaseModel):
    evaluation_id: str
    total_test_cases: int
    models_evaluated: List[str]
    overall_results: Dict[str, Any]
    detailed_results: List[Dict[str, Any]]
    best_performing_model: str
    worst_performing_model: str
    evaluation_summary: str
    generated_at: datetime

class ModelResult(BaseModel):
    model_name: str
    prompt: str
    response: str
    ground_truth: str
    is_correct: bool
    accuracy_score: float
    response_time: float
    judge_explanation: Optional[str] = None

class TestCase(BaseModel):
    prompt: str
    ground_truth: str

class PricingRequest(BaseModel):
    model_id: str = Field(..., description="Model ID for pricing calculation")
    input_tokens: int = Field(..., description="Number of input tokens")
    output_tokens: int = Field(..., description="Number of output tokens")
    invocations: int = Field(default=1, description="Number of invocations")

class PricingResponse(BaseModel):
    model_id: str
    input_tokens: int
    output_tokens: int
    invocations: int
    input_cost: float
    output_cost: float
    total_cost_per_invocation: float
    total_cost_all_invocations: float
    cost_breakdown: Dict[str, Any]
    model_provider: str
    timestamp: datetime

# Supported Models Configuration
SUPPORTED_MODELS = {
    "groq": {
        "llama-3.3-70b-versatile": "Llama 3.3 70B",
        "llama3-8b-8192": "Llama 3 8B",
        "llama3-70b-8192": "Llama 3 70B",
        "mixtral-8x7b-32768": "Mixtral 8x7B",
        "gemma-7b-it": "Gemma 7B",
        "gemma2-9b-it": "Gemma 2 9B"
    },
    "openai": {
        "gpt3516k": "GPT-3.5 16K",
        "gpt-4.1": "GPT-4.1",
        "gpt-4.1-mini": "GPT-4.1 Mini",
        "gpt-4o": "GPT-4 Omni",
        "gpt-4o-mini": "GPT-4 Omni Mini",
        "gpt-4.1-nano": "GPT-4.1 Nano"
    },
    "gemini": {
        "gemini-1.5-flash": "Gemini 1.5 Flash",
        "gemini-1.5-pro": "Gemini 1.5 Pro",
        "gemini-2.0-flash-001": "Gemini 2.0 Flash",
        "gemini-2.5-pro": "Gemini 2.5 Pro",
        "gemini-2.5-flash": "Gemini 2.5 Flash"
    },
    "bedrock": {
        "ai21.jamba-1-5-large-v1:0": "AI21 Jamba 1.5 Large", 
        "amazon.nova-canvas-v1:0": "Amazon Nova Canvas",
        "amazon.nova-micro-v1:0": "Amazon Nova Micro",
        "amazon.nova-lite-v1:0": "Amazon Nova Lite",
        "amazon.nova-pro-v1:0": "Amazon Nova Pro",
        "anthropic.claude-3-haiku-20240307-v1:0": "Claude 3 Haiku",
        "anthropic.claude-3-sonnet-20240229-v1:0": "Claude 3 Sonnet",
        "us.meta.llama3-2-11b-instruct-v1:0": "Meta Llama 3.2 11B"
    },
    "anthropic": {
        "claude-opus-4-20250514": "Claude Opus 4",
        "claude-sonnet-4-20250514": "Claude Sonnet 4"
    },
    "other": {
        "source_model": "Source Model"
    }
}

# File Processing for Test Data
class TestDataProcessor:
    """Process CSV/Excel files containing prompt-ground truth pairs"""
    
    def __init__(self):
        self.supported_extensions = ['.csv', '.xlsx', '.xls']
    
    async def process_test_file(self, file_path: str, filename: str) -> List[TestCase]:
        """Process uploaded test file and extract test cases"""
        try:
            file_ext = Path(filename).suffix.lower()
            
            if file_ext not in self.supported_extensions:
                raise ValueError(f"Unsupported file type: {file_ext}")
            
            test_cases = []
            
            if file_ext == '.csv':
                test_cases = await self._process_csv(file_path)
            elif file_ext in ['.xlsx', '.xls']:
                test_cases = await self._process_excel(file_path)
            
            return test_cases
            
        except Exception as e:
            raise ValueError(f"Error processing test file: {str(e)}")
    
    async def _process_csv(self, file_path: str) -> List[TestCase]:
        """Process CSV file"""
        test_cases = []
        
        try:
            df = pd.read_csv(file_path)
            
            # Normalize column names (case-insensitive)
            df.columns = df.columns.str.strip().str.lower()
            
            # Look for prompt and ground_truth columns
            prompt_col = None
            ground_truth_col = None
            
            for col in df.columns:
                if 'prompt' in col:
                    prompt_col = col
                elif 'ground' in col and 'truth' in col:
                    ground_truth_col = col
                elif col in ['truth', 'answer', 'expected', 'target']:
                    ground_truth_col = col
            
            if not prompt_col or not ground_truth_col:
                raise ValueError("Required columns 'prompt' and 'ground_truth' not found")
            
            # Extract test cases
            for _, row in df.iterrows():
                prompt = str(row[prompt_col]).strip()
                ground_truth = str(row[ground_truth_col]).strip()
                
                if prompt and ground_truth and prompt != 'nan' and ground_truth != 'nan':
                    test_cases.append(TestCase(
                        prompt=prompt,
                        ground_truth=ground_truth
                    ))
            
        except Exception as e:
            raise ValueError(f"Error processing CSV: {str(e)}")
        
        return test_cases
    
    async def _process_excel(self, file_path: str) -> List[TestCase]:
        """Process Excel file"""
        test_cases = []
        
        try:
            df = pd.read_excel(file_path)
            
            # Normalize column names (case-insensitive)
            df.columns = df.columns.str.strip().str.lower()
            
            # Look for prompt and ground_truth columns
            prompt_col = None
            ground_truth_col = None
            
            for col in df.columns:
                if 'prompt' in col:
                    prompt_col = col
                elif 'ground' in col and 'truth' in col:
                    ground_truth_col = col
                elif col in ['truth', 'answer', 'expected', 'target']:
                    ground_truth_col = col
            
            if not prompt_col or not ground_truth_col:
                raise ValueError("Required columns 'prompt' and 'ground_truth' not found")
            
            # Extract test cases
            for _, row in df.iterrows():
                prompt = str(row[prompt_col]).strip()
                ground_truth = str(row[ground_truth_col]).strip()
                
                if prompt and ground_truth and prompt != 'nan' and ground_truth != 'nan':
                    test_cases.append(TestCase(
                        prompt=prompt,
                        ground_truth=ground_truth
                    ))
            
        except Exception as e:
            raise ValueError(f"Error processing Excel: {str(e)}")
        
        return test_cases

# Model Clients
class BaseModelClient:
    """Abstract base class for all model clients"""
    
    def __init__(self, api_key: str, model_name: str):
        self.api_key = api_key
        self.model_name = model_name
    
    async def generate_response(self, prompt: str, **kwargs) -> str:
        """Generate response from the model"""
        raise NotImplementedError

class GroqClient(BaseModelClient):
    """Groq API client"""
    
    def __init__(self, api_key: str, model_name: str):
        super().__init__(api_key, model_name)
        self.client = Groq(api_key=api_key)
    
    async def generate_response(self, prompt: str, **kwargs) -> str:
        try:
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.client.chat.completions.create(
                    model=self.model_name,
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=kwargs.get('max_tokens', 1000),
                    temperature=kwargs.get('temperature', 0.7)
                )
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            raise Exception(f"Groq API error: {str(e)}")

class OpenAIClient(BaseModelClient):
    """Azure OpenAI API client"""

    def __init__(self, api_key: str, model_name: str):
        super().__init__(api_key, model_name)
        self.client = AzureOpenAI(
        api_key = os.getenv("AZURE_OPENAI_API_KEY"),  
        api_version = "2023-07-01-preview",
        azure_endpoint = os.getenv("API_URL")
        )

    async def generate_response(self, prompt: str, **kwargs) -> str:
        try:
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.client.chat.completions.create(
                    model=self.model_name,
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=kwargs.get('max_tokens', 1000),
                    temperature=kwargs.get('temperature', 0.7)
                )
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            raise Exception(f"OpenAI API error: {str(e)}")

class BedrockClient(BaseModelClient):
    """Amazon Bedrock API client"""

    def __init__(self, api_key: str, model_name: str):
        super().__init__(api_key, model_name)
        # For Bedrock, we typically use AWS credentials instead of an API key
        # You can configure AWS credentials via environment variables, AWS credentials file, or IAM roles
        self.client = boto3.client(
            'bedrock-runtime',
            region_name=os.getenv('AWS_REGION', 'us-east-1'),
            aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY')
        )

    async def generate_response(self, prompt: str, **kwargs) -> str:
        try:
            # Different models have different request formats
            # This example uses Claude on Bedrock format
            request_body = self._build_request_body(prompt, **kwargs)
            
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.client.invoke_model(
                    modelId=self.model_name,
                    body=json.dumps(request_body),
                    contentType='application/json'
                )
            )
            
            # Parse the response
            response_body = json.loads(response['body'].read())
            # return self._extract_content(response_body)
            return "Bedrock response not implemented yet"  # Placeholder for actual implementation
            
        except Exception as e:
            raise Exception(f"Bedrock API error: {str(e)}")

    def _build_request_body(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Build request body based on model type"""
        
        # For Claude models (anthropic.claude-v2, anthropic.claude-instant-v1, etc.)
        if 'claude' in self.model_name.lower():
            return {
                "prompt": f"\n\nHuman: {prompt}\n\nAssistant:",
                "max_tokens_to_sample": kwargs.get('max_tokens', 1000),
                "temperature": kwargs.get('temperature', 0.7),
                "top_p": kwargs.get('top_p', 0.9),
                "stop_sequences": kwargs.get('stop_sequences', ["\n\nHuman:"])
            }
        
        # For Amazon Titan models
        elif 'titan' in self.model_name.lower():
            return {
                "inputText": prompt,
                "textGenerationConfig": {
                    "maxTokenCount": kwargs.get('max_tokens', 1000),
                    "temperature": kwargs.get('temperature', 0.7),
                    "topP": kwargs.get('top_p', 0.9),
                    "stopSequences": kwargs.get('stop_sequences', [])
                }
            }
        
        # For AI21 Jurassic models
        elif 'j2' in self.model_name.lower():
            return {
                "prompt": prompt,
                "maxTokens": kwargs.get('max_tokens', 1000),
                "temperature": kwargs.get('temperature', 0.7),
                "topP": kwargs.get('top_p', 0.9),
                "stopSequences": kwargs.get('stop_sequences', [])
            }
        
        # Default format (adjust based on your specific model)
        else:
            return {
                "prompt": prompt,
                "max_tokens": kwargs.get('max_tokens', 1000),
                "temperature": kwargs.get('temperature', 0.7)
            }

    def _extract_content(self, response_body: Dict[str, Any]) -> str:
        """Extract content from response based on model type"""
        
        # For Claude models
        if 'claude' in self.model_name.lower():
            return response_body.get('completion', '').strip()
        
        # For Amazon Titan models
        elif 'titan' in self.model_name.lower():
            results = response_body.get('results', [])
            if results:
                return results[0].get('outputText', '').strip()
        
        # For AI21 Jurassic models
        elif 'j2' in self.model_name.lower():
            completions = response_body.get('completions', [])
            if completions:
                return completions[0].get('data', {}).get('text', '').strip()
        
        # Default extraction
        return response_body.get('generated_text', '').strip()
    

class GeminiClient(BaseModelClient):
    """Google Gemini API client"""

    def __init__(self, api_key: str, model_name: str = "gemini-1.5-pro"):
        super().__init__(api_key, model_name)
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel(model_name)

    async def generate_response(self, prompt: str, **kwargs) -> str:
        try:
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.model.generate_content(
                    prompt,
                    generation_config={
                        "temperature": kwargs.get("temperature", 0.7),
                        "max_output_tokens": kwargs.get("max_tokens", 1000),
                    }
                )
            )
            return response.text.strip()
        except Exception as e:
            raise Exception(f"Gemini API error: {str(e)}")
        
# LLM Judge for Evaluation
class LLMJudge:
    """LLM-as-a-judge for evaluating response quality"""
    
    def __init__(self, judge_client: BaseModelClient):
        self.judge_client = judge_client
    
    async def evaluate_response(self, prompt: str, model_response: str, ground_truth: str) -> tuple[float, str]:
        """Evaluate a model response against ground truth using LLM as judge"""
        
        judge_prompt = f"""
You are an expert evaluator tasked with scoring the quality and correctness of AI model responses.

Original Question/Prompt: {prompt}

Ground Truth/Expected Answer: {ground_truth}

Model Response to Evaluate: {model_response}

Please evaluate the model response based on the following criteria:
1. Factual accuracy compared to the ground truth
2. Completeness of the answer
3. Relevance to the original question
4. Clarity and coherence

Provide your evaluation in the following format:
SCORE: [A number between 0-100, where 0 is completely wrong and 100 is perfect]
EXPLANATION: [Brief explanation of your scoring rationale]

Consider partial credit for responses that are partially correct or contain some relevant information.
If the model response contains the correct answer but has additional context, give it high marks (90-100).
If the model response is factually correct but verbose, still give it high marks (85-95).
"""
        
        try:
            judge_response = await self.judge_client.generate_response(judge_prompt)
            
            # Parse the judge response
            score, explanation = self._parse_judge_response(judge_response)
            return score, explanation
            
        except Exception as e:
            logger.error(f"Error in LLM judge evaluation: {str(e)}")
            # Fallback to smart fuzzy matching
            fallback_score = self._smart_fuzzy_match(model_response, ground_truth)
            return fallback_score, f"Judge evaluation failed, used fuzzy matching: {str(e)}"
    
    def _parse_judge_response(self, judge_response: str) -> tuple[float, str]:
        """Parse the judge response to extract score and explanation"""
        try:
            lines = judge_response.strip().split('\n')
            score = 0.0
            explanation = "No explanation provided"
            
            for line in lines:
                line = line.strip()
                if line.upper().startswith('SCORE:'):
                    score_text = line.replace('SCORE:', '').replace('score:', '').strip()
                    # Extract numeric value
                    score_match = re.search(r'(\d+(?:\.\d+)?)', score_text)
                    if score_match:
                        score = float(score_match.group(1))
                        score = max(0.0, min(100.0, score))  # Clamp between 0-100
                elif line.upper().startswith('EXPLANATION:'):
                    explanation = line.replace('EXPLANATION:', '').replace('explanation:', '').strip()
            
            return score, explanation
            
        except Exception as e:
            logger.error(f"Error parsing judge response: {str(e)}")
            return 0.0, f"Failed to parse judge response: {str(e)}"
    
    def _smart_fuzzy_match(self, model_response: str, ground_truth: str) -> float:
        """Enhanced fuzzy matching with better logic"""
        model_clean = model_response.lower().strip()
        truth_clean = ground_truth.lower().strip()
        
        # Check if ground truth is contained in model response
        if truth_clean in model_clean:
            return 95.0
        
        # Check if model response is contained in ground truth  
        if model_clean in truth_clean:
            return 90.0
        
        # Use sequence matching for similarity
        similarity = SequenceMatcher(None, model_clean, truth_clean).ratio()
        
        if similarity >= 0.9:
            return 85.0
        elif similarity >= 0.8:
            return 70.0
        elif similarity >= 0.6:
            return 50.0
        else:
            return 0.0

# Model Evaluator
class ModelEvaluator:
    """Main class for evaluating multiple models"""
    
    def __init__(self,api_keys: Dict[str, str] = None):
        self.groq_api_key = api_keys.get("groq") if api_keys else os.getenv("GROQ_API_KEY")
        self.openai_api_key = api_keys.get("openai") if api_keys else os.getenv("AZURE_OPENAI_API_KEY")
        self.gemini_api_key = api_keys.get("gemini") if api_keys else os.getenv("GEMINI_API_KEY")
        self.anthropic_api_key = api_keys.get("Anthropic_API_KEY") if api_keys else os.getenv("ANTHROPIC_API_KEY")
        self.model_clients = {}
        self.judge = None
        
        # Setup judge if Groq is available
        if self.groq_api_key:
            judge_client = GroqClient(self.groq_api_key, "llama-3.3-70b-versatile")
            self.judge = LLMJudge(judge_client)
    
    def setup_model_clients(self, models: List[str]):
        """Setup model clients for evaluation"""
        self.model_clients = {}
        
        for model_name in models:
            # Determine provider and setup client
            if model_name in SUPPORTED_MODELS["groq"] and self.groq_api_key:
                self.model_clients[model_name] = GroqClient(self.groq_api_key, model_name)

            elif model_name in SUPPORTED_MODELS["openai"] and self.openai_api_key:
                self.model_clients[model_name] = OpenAIClient(self.openai_api_key, model_name)

            elif model_name in SUPPORTED_MODELS["gemini"] and self.gemini_api_key:
                self.model_clients[model_name] = GeminiClient(self.gemini_api_key, model_name)
            
            elif model_name in SUPPORTED_MODELS["bedrock"] and os.getenv("AWS_ACCESS_KEY_ID") and os.getenv("AWS_SECRET_ACCESS_KEY"):
                self.model_clients[model_name] = BedrockClient(
                    os.getenv("AWS_ACCESS_KEY_ID"), 
                    model_name
                )
            else:   
                logger.warning(f"Model {model_name} not supported or API key missing")
    
    async def evaluate_models(self, test_cases: List[TestCase], models: List[str], 
                            use_llm_judge: bool = True, **kwargs) -> Dict[str, Any]:
        """Evaluate multiple models against test cases"""
        
        self.setup_model_clients(models)
        
        if not self.model_clients:
            raise ValueError("No valid model clients configured")
        
        all_results = []
        model_summaries = {}
        
        for model_name, client in self.model_clients.items():
            logger.info(f"Evaluating model: {model_name}")
            
            model_results = []
            total_score = 0.0
            correct_count = 0
            total_time = 0.0
            
            for i, test_case in enumerate(test_cases):
                try:
                    start_time = time.time()
                    response = await client.generate_response(test_case.prompt, **kwargs)
                    response_time = time.time() - start_time
                    
                    # Evaluate response
                    if use_llm_judge and self.judge:
                        accuracy_score, judge_explanation = await self.judge.evaluate_response(
                            test_case.prompt, response, test_case.ground_truth
                        )
                        is_correct = accuracy_score >= 70.0
                    else:
                        is_correct = self._simple_match(response, test_case.ground_truth)
                        accuracy_score = 100.0 if is_correct else 0.0
                        judge_explanation = "Simple string matching used"
                    
                    result = ModelResult(
                        model_name=model_name,
                        prompt=test_case.prompt,
                        response=response,
                        ground_truth=test_case.ground_truth,
                        is_correct=is_correct,
                        accuracy_score=accuracy_score,
                        response_time=response_time,
                        judge_explanation=judge_explanation
                    )
                    
                    model_results.append(result.dict())
                    total_score += accuracy_score
                    if is_correct:
                        correct_count += 1
                    total_time += response_time
                    
                    logger.info(f"  Test {i+1}/{len(test_cases)}: Score {accuracy_score:.1f}%")
                    
                except Exception as e:
                    logger.error(f"Error evaluating {model_name} on test {i+1}: {str(e)}")
                    error_result = ModelResult(
                        model_name=model_name,
                        prompt=test_case.prompt,
                        response=f"ERROR: {str(e)}",
                        ground_truth=test_case.ground_truth,
                        is_correct=False,
                        accuracy_score=0.0,
                        response_time=0.0,
                        judge_explanation=f"Evaluation failed: {str(e)}"
                    )
                    model_results.append(error_result.dict())
            
            # Calculate model summary
            avg_score = total_score / len(test_cases) if test_cases else 0
            accuracy_percentage = (correct_count / len(test_cases) * 100) if test_cases else 0
            avg_response_time = total_time / len(test_cases) if test_cases else 0
            
            model_summaries[model_name] = {
                "model_name": model_name,
                "total_test_cases": len(test_cases),
                "correct_responses": correct_count,
                "accuracy_percentage": accuracy_percentage,
                "average_score": avg_score,
                "average_response_time": avg_response_time,
                "detailed_results": model_results
            }
            
            all_results.extend(model_results)
        
        # Calculate overall results
        overall_results = self._calculate_overall_results(model_summaries)
        
        return {
            "model_summaries": model_summaries,
            "overall_results": overall_results,
            "all_results": all_results
        }
    
    def _simple_match(self, response: str, ground_truth: str) -> bool:
        """Simple string matching for binary accuracy"""
        response_clean = response.lower().strip()
        truth_clean = ground_truth.lower().strip()
        
        if response_clean == truth_clean:
            return True
        
        if truth_clean in response_clean:
            return True
        
        similarity = SequenceMatcher(None, response_clean, truth_clean).ratio()
        return similarity >= 0.8
    
    def _calculate_overall_results(self, model_summaries: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall evaluation results"""
        if not model_summaries:
            return {}
        
        # Sort models by average score
        sorted_models = sorted(
            model_summaries.items(),
            key=lambda x: x[1]["average_score"],
            reverse=True
        )
        
        best_model = sorted_models[0][0] if sorted_models else "None"
        worst_model = sorted_models[-1][0] if sorted_models else "None"
        
        # Calculate variance
        scores = [summary["average_score"] for summary in model_summaries.values()]
        avg_score = sum(scores) / len(scores)
        variance = sum((score - avg_score) ** 2 for score in scores) / len(scores)
        
        # FIXED: Add total_test_cases calculation
        total_test_cases = model_summaries[list(model_summaries.keys())[0]]["total_test_cases"] if model_summaries else 0
        
        return {
            "total_models": len(model_summaries),
            "total_test_cases": total_test_cases,  # ADDED: This was missing
            "best_performing_model": best_model,
            "worst_performing_model": worst_model,
            "overall_average_score": avg_score,
            "overall_average_accuracy": avg_score,  # ADDED: Frontend expects this field
            "performance_variance": variance,
            "model_rankings": [
                {
                    "model_name": model_name,
                    "rank": i + 1,
                    "average_score": summary["average_score"],
                    "average_accuracy_score": summary["average_score"],  # ADDED: Frontend expects this field
                    "accuracy_percentage": summary["accuracy_percentage"],
                    "average_response_time": summary["average_response_time"]  # ADDED: Frontend expects this field
                }
                for i, (model_name, summary) in enumerate(sorted_models)
            ]
        }

# PDF Report Generator
class ModelEvaluationPDFGenerator:
    """Generate PDF reports from model evaluation results"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        self.title_style = ParagraphStyle(
            'ModelEvalTitle',
            parent=self.styles['Title'],
            fontSize=24,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=colors.HexColor('#1a365d'),
            fontName='Helvetica-Bold'
        )
        
        self.heading_style = ParagraphStyle(
            'ModelEvalHeading',
            parent=self.styles['Heading1'],
            fontSize=16,
            spaceAfter=15,
            spaceBefore=20,
            textColor=colors.HexColor('#2b6cb0'),
            fontName='Helvetica-Bold'
        )
        
        self.subheading_style = ParagraphStyle(
            'ModelEvalSubHeading',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=10,
            spaceBefore=15,
            textColor=colors.HexColor('#4a5568'),
            fontName='Helvetica-Bold'
        )
        
        self.body_style = ParagraphStyle(
            'ModelEvalBody',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=8,
            textColor=colors.HexColor('#2d3748'),
            alignment=TA_JUSTIFY
        )
        
        self.code_style = ParagraphStyle(
            'ModelEvalCode',
            parent=self.styles['Normal'],
            fontSize=9,
            spaceAfter=5,
            textColor=colors.HexColor('#2d3748'),
            fontName='Courier',
            backColor=colors.HexColor('#f7fafc'),
            borderColor=colors.HexColor('#e2e8f0'),
            borderWidth=1,
            borderPadding=5
        )
    
    def _create_model_summaries(self, detailed_results: List[Dict]) -> Dict[str, Dict]:
        """Create model summaries from detailed results"""
        model_summaries = {}
        
        for result in detailed_results:
            model_name = result['model_name']
            if model_name not in model_summaries:
                model_summaries[model_name] = {
                    'total_test_cases': 0,
                    'correct_responses': 0,
                    'total_score': 0,
                    'total_response_time': 0,
                    'test_cases': []
                }
            
            summary = model_summaries[model_name]
            summary['total_test_cases'] += 1
            summary['correct_responses'] += 1 if result['is_correct'] else 0
            summary['total_score'] += result['accuracy_score']
            summary['total_response_time'] += result['response_time']
            summary['test_cases'].append(result)
        
        # Calculate averages
        for model_name, summary in model_summaries.items():
            summary['accuracy_percentage'] = (summary['correct_responses'] / summary['total_test_cases']) * 100
            summary['average_score'] = summary['total_score'] / summary['total_test_cases']
            summary['average_response_time'] = summary['total_response_time'] / summary['total_test_cases']
        
        return model_summaries
    
    def generate_pdf(self, results: Dict[str, Any], title: str = "Model Evaluation Report") -> bytes:
        """Generate PDF from evaluation results"""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=50,
            leftMargin=50,
            topMargin=60,
            bottomMargin=60
        )
        
        content = []
        
        # Title and metadata
        content.append(Paragraph(title, self.title_style))
        content.append(Spacer(1, 20))
        
        timestamp = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        content.append(Paragraph(f"Generated on {timestamp}", self.body_style))
        content.append(Paragraph(f"Evaluation ID: {results.get('evaluation_id', 'N/A')}", self.body_style))
        content.append(Spacer(1, 30))
        
        # Overall Results
        overall = results.get("overall_results", {})
        content.append(Paragraph("Executive Summary", self.heading_style))
        
        summary_data = [
            ["Metric", "Value"],
            ["Total Models Evaluated", str(overall.get("total_models", 0))],
            ["Total Test Cases", str(overall.get("total_test_cases", 0))],
            ["Best Performing Model", overall.get("best_performing_model", "N/A")],
            ["Worst Performing Model", overall.get("worst_performing_model", "N/A")],
            ["Overall Average Score", f"{overall.get('overall_average_score', 0):.2f}%"],
            ["Overall Average Accuracy", f"{overall.get('overall_average_accuracy', 0):.2f}%"],
            ["Performance Variance", f"{overall.get('performance_variance', 0):.2f}%"]
        ]
        
        summary_table = Table(summary_data, colWidths=[3*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3182ce')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f7fafc')),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')
        ]))
        
        content.append(summary_table)
        content.append(Spacer(1, 20))
        
        # Model Rankings
        content.append(Paragraph("Model Performance Rankings", self.heading_style))
        
        rankings = overall.get("model_rankings", [])
        if rankings:
            ranking_data = [["Rank", "Model", "Avg Score", "Accuracy %", "Avg Response Time (s)"]]
            for ranking in rankings:
                ranking_data.append([
                    str(ranking["rank"]),
                    ranking["model_name"],
                    f"{ranking['average_score']:.2f}%",
                    f"{ranking['accuracy_percentage']:.2f}%",
                    f"{ranking['average_response_time']:.3f}s"
                ])
            
            ranking_table = Table(ranking_data, colWidths=[0.8*inch, 2*inch, 1.2*inch, 1.2*inch, 1.3*inch])
            ranking_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#38a169')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f0fff4')),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')
            ]))
            
            content.append(ranking_table)
        
        content.append(Spacer(1, 20))
        
        # Create model summaries from detailed results
        detailed_results = results.get("detailed_results", [])
        model_summaries = self._create_model_summaries(detailed_results)
        
        # Individual Model Results
        content.append(Paragraph("Detailed Model Results", self.heading_style))
        
        for model_name, summary in model_summaries.items():
            # Model summary section
            model_content = []
            model_content.append(Paragraph(f"Model: {model_name}", self.subheading_style))
            
            model_data = [
                ["Metric", "Value"],
                ["Total Test Cases", str(summary["total_test_cases"])],
                ["Correct Responses", str(summary["correct_responses"])],
                ["Accuracy Percentage", f"{summary['accuracy_percentage']:.2f}%"],
                ["Average Score", f"{summary['average_score']:.2f}%"],
                ["Average Response Time", f"{summary['average_response_time']:.3f}s"]
            ]
            
            model_table = Table(model_data, colWidths=[2.5*inch, 2*inch])
            model_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e2e8f0')),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')
            ]))
            
            model_content.append(model_table)
            model_content.append(Spacer(1, 15))
            
            # Individual test case results
            model_content.append(Paragraph(f"Test Case Details for {model_name}", self.subheading_style))
            
            for i, test_case in enumerate(summary['test_cases'], 1):
                # Test case header
                status_color = colors.HexColor('#22c55e') if test_case['is_correct'] else colors.HexColor('#ef4444')
                status_text = "✓ CORRECT" if test_case['is_correct'] else "✗ INCORRECT"
                
                test_case_data = [
                    [f"Test Case {i}", f"{status_text}", f"Score: {test_case['accuracy_score']}%", f"Time: {test_case['response_time']:.3f}s"]
                ]
                
                test_case_table = Table(test_case_data, colWidths=[1.5*inch, 1.5*inch, 1.5*inch, 1.5*inch])
                test_case_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8fafc')),
                    ('TEXTCOLOR', (1, 0), (1, 0), status_color),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')
                ]))
                
                model_content.append(test_case_table)
                
                # Prompt and responses
                details_data = [
                    ["Prompt", test_case['prompt'][:200] + "..." if len(test_case['prompt']) > 200 else test_case['prompt']],
                    ["Expected", test_case['ground_truth'][:200] + "..." if len(test_case['ground_truth']) > 200 else test_case['ground_truth']],
                    ["Actual Response", test_case['response'][:300] + "..." if len(test_case['response']) > 300 else test_case['response']],
                    ["Judge Explanation", test_case['judge_explanation']]
                ]
                
                details_table = Table(details_data, colWidths=[1.5*inch, 4.5*inch])
                details_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#ffffff')),
                    ('ALIGN', (0, 0), (0, -1), 'LEFT'),
                    ('ALIGN', (1, 0), (1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 8),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                    ('LEFTPADDING', (0, 0), (-1, -1), 5),
                    ('RIGHTPADDING', (0, 0), (-1, -1), 5),
                    ('TOPPADDING', (0, 0), (-1, -1), 5),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 5)
                ]))
                
                model_content.append(details_table)
                model_content.append(Spacer(1, 10))
            
            # Keep model content together
            content.append(KeepTogether(model_content))
            content.append(PageBreak())
        
        # Evaluation Summary
        content.append(Paragraph("Evaluation Summary", self.heading_style))
        summary_text = results.get("evaluation_summary", "No summary available")
        content.append(Paragraph(summary_text, self.body_style))
        
        # Build PDF
        doc.build(content)
        buffer.seek(0)
        return buffer.read()

# Utility functions
async def save_uploaded_file(upload_file: UploadFile, temp_dir: str = None) -> str:
    """Save uploaded file to temporary location"""
    if temp_dir is None:
        temp_dir = tempfile.mkdtemp()
    
    file_path = os.path.join(temp_dir, upload_file.filename)
    
    try:
        content = await upload_file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        return file_path
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving file: {str(e)}"
        )

# Router
router = APIRouter(prefix="/model-evaluation", tags=["Model Evaluation"])

# Initialize processors
test_data_processor = TestDataProcessor()
pdf_generator = ModelEvaluationPDFGenerator()

@router.post("/analyze", response_model=ModelEvaluationResponse)
async def analyze_models(
    models: str = Form(..., description="Comma-separated list of models to evaluate"),
    api_keys: str = Form(..., description="""{"model":"gemini","api_key":"your_api_key"}"""),
    file: UploadFile = File(..., description="CSV/Excel file with prompt,ground_truth columns"),
    use_llm_judge: bool = Form(True, description="Use LLM as judge for scoring"),
    max_tokens: int = Form(1000, description="Maximum tokens for responses"),
    temperature: float = Form(0.7, description="Temperature for model responses"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Analyze multiple AI models against test cases from uploaded file
    
    This endpoint:
    1. Processes uploaded CSV/Excel file with prompt-ground_truth pairs
    2. Evaluates specified models against all test cases
    3. Generates comprehensive evaluation results
    4. Returns detailed analysis and rankings
    
    Parameters:
    - models: Comma-separated list of model names to evaluate
    - file: CSV/Excel file with 'prompt' and 'ground_truth' columns
    - use_llm_judge: Whether to use LLM as judge for scoring
    - max_tokens: Maximum tokens for model responses
    - temperature: Temperature parameter for model responses
    """
    
    # Parse models list
    model_list = [model.strip() for model in models.split(",") if model.strip()]
    print("Api_keys", api_keys)
    api_keys_dict = json.loads(api_keys)

    print(f"API Keys: {api_keys_dict}")
    if not model_list:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No models specified for evaluation"
        )
    
    # Validate file type
    if not file.filename.endswith(('.csv', '.xlsx', '.xls')):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid file type. Please upload CSV or Excel file (.csv, .xlsx, .xls)"
        )
    
    # Process uploaded file
    temp_dir = tempfile.mkdtemp()
    try:
        file_path = await save_uploaded_file(file, temp_dir)
        test_cases = await test_data_processor.process_test_file(file_path, file.filename)
        
        if not test_cases:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No valid test cases found in uploaded file"
            )
        
        logger.info(f"Loaded {len(test_cases)} test cases from {file.filename}")
        

        # Initialize evaluator and run evaluation
        evaluator = ModelEvaluator(api_keys=api_keys_dict)
        
        # Check if any requested models are supported
        supported_model_names = []
        for provider_models in SUPPORTED_MODELS.values():
            supported_model_names.extend(provider_models.keys())
        
        unsupported_models = [model for model in model_list if model not in supported_model_names]
        if unsupported_models:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unsupported models: {', '.join(unsupported_models)}. Supported models: {', '.join(supported_model_names)}"
            )
        
        # Run evaluation
        results = await evaluator.evaluate_models(
            test_cases=test_cases,
            models=model_list,
            use_llm_judge=use_llm_judge,
            max_tokens=max_tokens,
            temperature=temperature
        )
        
        # Generate evaluation summary
        evaluation_summary = await generate_evaluation_summary(results)

        print("Evaluation_summary", evaluation_summary)   
        # Create response
        evaluation_id = str(uuid.uuid4())
        
        return ModelEvaluationResponse(
            evaluation_id=evaluation_id,
            total_test_cases=len(test_cases),
            models_evaluated=model_list,
            overall_results=results["overall_results"],
            detailed_results=results["all_results"],
            best_performing_model=results["overall_results"].get("best_performing_model", "None"),
            worst_performing_model=results["overall_results"].get("worst_performing_model", "None"),
            evaluation_summary=str(evaluation_summary),
            generated_at=datetime.utcnow()
        )
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error during model evaluation: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error during model evaluation: {str(e)}"
        )
    
    finally:
        # Clean up temporary files
        import shutil
        shutil.rmtree(temp_dir, ignore_errors=True)

@router.post("/generate-pdf")
async def generate_evaluation_pdf(
    evaluation_results: str = Form(..., description="JSON string of evaluation results"),
    title: str = Form("Model Evaluation Report", description="Report title"),
    current_user: User = Depends(get_current_user)
):
    """
    Generate PDF report from model evaluation results
    
    This endpoint:
    1. Takes JSON-formatted evaluation results
    2. Generates a comprehensive PDF report
    3. Returns the PDF as downloadable file
    
    Parameters:
    - evaluation_results: JSON string containing evaluation results
    - title: Title for the PDF report
    """
    
    try:
        # Parse evaluation results
        results = json.loads(evaluation_results)
        
        # Generate PDF report
        pdf_content = pdf_generator.generate_pdf(results, title)
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"model_evaluation_report_{timestamp}.pdf"
        
        return Response(
            content=pdf_content,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename={filename}"
            }
        )
        
    except json.JSONDecodeError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid JSON format in evaluation results"
        )
    except Exception as e:
        logger.error(f"Error generating PDF: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generating PDF: {str(e)}"
        )

@router.get("/supported-models")
async def get_supported_models():
    """Get list of supported models for evaluation"""
    
    # Check which API keys are available
    available_providers = {}
    
    if os.getenv("GROQ_API_KEY"):
        available_providers["groq"] = {
            "name": "Groq",
            "models": SUPPORTED_MODELS["groq"]
        }
    
    if os.getenv("AZURE_OPENAI_API_KEY"):
        available_providers["openai"] = {
            "name": "OpenAI",
            "models": SUPPORTED_MODELS["openai"]
        }
    
    if os.getenv("ANTHROPIC_API_KEY"):
        available_providers["anthropic"] = {
            "name": "Anthropic",
            "models": SUPPORTED_MODELS["anthropic"]
        }
    
    if os.getenv("GEMINI_API_KEY"):
        available_providers["gemini"] = {
            "name": "Gemini",
            "models": SUPPORTED_MODELS["gemini"]
        }
    
    if os.getenv("AWS_ACCESS_KEY_ID") and os.getenv("AWS_SECRET_ACCESS_KEY"):
        available_providers["bedrock"] = {
            "name": "Bedrock",
            "models": SUPPORTED_MODELS["bedrock"]
        }

    # Flatten model list
    all_models = []
    for provider, info in available_providers.items():
        for model_id, model_name in info["models"].items():
            all_models.append({
                "id": model_id,
                "name": model_name,
                "provider": provider
            })
    
    return {
        "providers": available_providers,
        "all_models": all_models,
        "total_models": len(all_models),
        "file_format_requirements": {
            "supported_formats": [".csv", ".xlsx", ".xls"],
            "required_columns": ["prompt", "ground_truth"],
            "example_structure": {
                "prompt": "What is the capital of France?",
                "ground_truth": "Paris"
            }
        }
    }

@router.get("/sample-template")
async def download_sample_template():
    """Download a sample CSV template for model evaluation"""
    
    # Create sample data
    sample_data = [
        {
            "prompt": "What is the capital of France?",
            "ground_truth": "Paris"
        },
        {
            "prompt": "Explain the concept of machine learning in simple terms.",
            "ground_truth": "Machine learning is a subset of artificial intelligence that enables computers to learn and make decisions from data without being explicitly programmed for every task."
        },
        {
            "prompt": "What is 2 + 2?",
            "ground_truth": "4"
        },
        {
            "prompt": "Name three benefits of renewable energy.",
            "ground_truth": "1. Environmentally friendly with reduced greenhouse gas emissions, 2. Sustainable and inexhaustible energy source, 3. Long-term cost savings and energy independence"
        },
        {
            "prompt": "What programming language is known for data science?",
            "ground_truth": "Python"
        }
    ]
    
    # Create CSV content
    df = pd.DataFrame(sample_data)
    csv_buffer = io.StringIO()
    df.to_csv(csv_buffer, index=False)
    csv_content = csv_buffer.getvalue()
    
    return Response(
        content=csv_content,
        media_type="text/csv",
        headers={
            "Content-Disposition": "attachment; filename=model_evaluation_template.csv"
        }
    )

price_calculator = PriceCalculator()

@router.post("/pricing", response_model=PricingResponse)
async def calculate_model_pricing(
    request: PricingRequest,
    current_user: User = Depends(get_current_user)
):
    """
    Calculate pricing for AI model inference based on token usage
    
    This endpoint:
    1. Calculates input token costs
    2. Calculates output token costs
    3. Provides total cost per invocation
    4. Calculates total cost for multiple invocations
    5. Returns detailed cost breakdown
    
    Parameters:
    - model_id: Identifier of the model for pricing
    - input_tokens: Number of input tokens
    - output_tokens: Number of output tokens
    - invocations: Number of model invocations (default: 1)
    """
    
    try:
        # Check if model is supported
        supported_models = price_calculator.get_supported_models()
        if request.model_id not in supported_models:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Model '{request.model_id}' not supported. Supported models: {', '.join(supported_models)}"
            )
        
        # Calculate costs
        input_cost = price_calculator.calculate_input_price(request.input_tokens, request.model_id)
        output_cost = price_calculator.calculate_output_price(request.output_tokens, request.model_id)
        total_cost_per_invocation = price_calculator.calculate_total_price(
            request.input_tokens, 
            request.output_tokens, 
            request.model_id
        )       
        
        # Calculate total cost for all invocations
        total_cost_all_invocations = total_cost_per_invocation * request.invocations
        
        # Determine model provider
        model_provider = "unknown"
        for provider, models in SUPPORTED_MODELS.items():
            if request.model_id in models:
                model_provider = provider
                break
        
        # Create detailed cost breakdown
        cost_breakdown = {
            "input_cost_per_1k_tokens": price_calculator.model_input_token_prices.get(request.model_id, 0),
            "output_cost_per_1k_tokens": price_calculator.model_output_token_prices.get(request.model_id, 0),
            "input_cost_calculation": f"({request.input_tokens} tokens / 1000) × ${price_calculator.model_input_token_prices.get(request.model_id, 0)}",
            "output_cost_calculation": f"({request.output_tokens} tokens / 1000) × ${price_calculator.model_output_token_prices.get(request.model_id, 0)}",
            "cost_per_invocation": {
                "input": input_cost,
                "output": output_cost,
                "total": total_cost_per_invocation
            },
            "cost_scaling": {
                "100_invocations": total_cost_per_invocation * 100,
                "1000_invocations": total_cost_per_invocation * 1000,
                "10000_invocations": total_cost_per_invocation * 10000
            }
        }
        
        return PricingResponse(
            model_id=request.model_id,
            input_tokens=request.input_tokens,
            output_tokens=request.output_tokens,
            invocations=request.invocations,
            input_cost=input_cost,
            output_cost=output_cost,
            total_cost_per_invocation=total_cost_per_invocation,
            total_cost_all_invocations=total_cost_all_invocations,
            cost_breakdown=cost_breakdown,
            model_provider=model_provider,
            timestamp=datetime.utcnow()
        )
        
    except Exception as e:
        logger.error(f"Error calculating pricing: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error calculating pricing: {str(e)}"
        )

@router.get("/pricing/models")
async def get_pricing_models():
    """Get all models available for pricing calculation with their rates"""
    
    try:
        supported_models = price_calculator.get_supported_models()
        
        models_with_pricing = []
        for model_id in supported_models:
            input_price = price_calculator.model_input_token_prices.get(model_id, 0)
            output_price = price_calculator.model_output_token_prices.get(model_id, 0)
            
            # Determine provider
            provider = "unknown"
            model_name = model_id
            for prov, models in SUPPORTED_MODELS.items():
                if model_id in models:
                    provider = prov
                    model_name = models[model_id]
                    break
            
            models_with_pricing.append({
                "model_id": model_id,
                "model_name": model_name,
                "provider": provider,
                "input_price_per_1k_tokens": input_price,
                "output_price_per_1k_tokens": output_price,
                "currency": "USD"
            })
        
        # Sort by provider and then by price
        models_with_pricing.sort(key=lambda x: (x["provider"], x["input_price_per_1k_tokens"]))
        
        return {
            "models": models_with_pricing,
            "total_models": len(models_with_pricing),
            "providers": list(set(model["provider"] for model in models_with_pricing)),
            "pricing_notes": {
                "currency": "USD",
                "unit": "per 1000 tokens",
                "calculation": "Actual cost = (tokens / 1000) × price_per_1k_tokens"
            }
        }
        
    except Exception as e:
        logger.error(f"Error getting pricing models: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error getting pricing models: {str(e)}"
        )

@router.post("/pricing/compare")
async def compare_model_pricing(
    input_tokens: int = Form(..., description="Number of input tokens"),
    output_tokens: int = Form(..., description="Number of output tokens"),
    models: str = Form(..., description="Comma-separated list of models to compare"),
    invocations: int = Form(1, description="Number of invocations"),
    current_user: User = Depends(get_current_user)
):
    """
    Compare pricing across multiple models for the same token usage
    
    This endpoint:
    1. Calculates costs for multiple models
    2. Provides cost comparison and rankings
    3. Shows potential savings between models
    4. Returns recommendations based on cost-effectiveness
    """
    
    try:
        # Parse models list
        model_list = [model.strip() for model in models.split(",") if model.strip()]
        
        if not model_list:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No models specified for comparison"
            )
        
        # Calculate pricing for each model
        pricing_results = []
        supported_models = price_calculator.get_supported_models()
        
        for model_id in model_list:
            if model_id not in supported_models:
                continue
                
            input_cost = price_calculator.calculate_input_price(input_tokens, model_id)
            output_cost = price_calculator.calculate_output_price(output_tokens, model_id)
            total_cost = price_calculator.calculate_total_price(input_tokens, output_tokens, model_id)
            total_cost_all = total_cost * invocations
            
            # Get provider and model name
            provider = "unknown"
            model_name = model_id
            for prov, models_dict in SUPPORTED_MODELS.items():
                if model_id in models_dict:
                    provider = prov
                    model_name = models_dict[model_id]
                    break
            
            pricing_results.append({
                "model_id": model_id,
                "model_name": model_name,
                "provider": provider,
                "input_cost": input_cost,
                "output_cost": output_cost,
                "total_cost_per_invocation": total_cost,
                "total_cost_all_invocations": total_cost_all,
                "input_price_per_1k": price_calculator.model_input_token_prices.get(model_id, 0),
                "output_price_per_1k": price_calculator.model_output_token_prices.get(model_id, 0)
            })
        
        if not pricing_results:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No valid models found for comparison"
            )
        
        # Sort by total cost (ascending)
        pricing_results.sort(key=lambda x: x["total_cost_all_invocations"])
        
        # Calculate savings and recommendations
        cheapest = pricing_results[0]
        most_expensive = pricing_results[-1]
        
        cost_savings = {
            "cheapest_model": cheapest["model_id"],
            "most_expensive_model": most_expensive["model_id"],
            "cost_difference": most_expensive["total_cost_all_invocations"] - cheapest["total_cost_all_invocations"],
            "savings_percentage": ((most_expensive["total_cost_all_invocations"] - cheapest["total_cost_all_invocations"]) / most_expensive["total_cost_all_invocations"] * 100) if most_expensive["total_cost_all_invocations"] > 0 else 0
        }
        
        return {
            "comparison_results": pricing_results,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "invocations": invocations,
            "cost_savings": cost_savings,
            "recommendations": {
                "most_cost_effective": cheapest["model_id"],
                "provider_breakdown": {
                    provider: [r for r in pricing_results if r["provider"] == provider]
                    for provider in set(r["provider"] for r in pricing_results)
                }
            },
            "timestamp": datetime.utcnow()
        }
        
    except Exception as e:
        logger.error(f"Error comparing model pricing: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error comparing model pricing: {str(e)}"
        )

@router.get("/health")
async def health_check():
    """Health check endpoint for model evaluation service"""
    
    # Check available API keys
    api_status = {
        "groq": "available" if os.getenv("GROQ_API_KEY") else "not_configured",
        "openai": "available" if os.getenv("OPENAI_API_KEY") else "not_configured",
    }
    
    total_available_models = 0
    for provider in SUPPORTED_MODELS:
        if api_status.get(provider) == "available":
            total_available_models += len(SUPPORTED_MODELS[provider])
    
    return {
        "status": "healthy",
        "api_services": api_status,
        "total_available_models": total_available_models,
        "supported_file_formats": test_data_processor.supported_extensions,
        "timestamp": datetime.utcnow().isoformat()
    }

# Utility function for generating evaluation summary
async def generate_evaluation_summary(results: Dict[str, Any]) -> str:
    """Generate a human-readable evaluation summary"""
    
    overall = results.get("overall_results", {})
    model_summaries = results.get("model_summaries", {})
    
    if not overall or not model_summaries:
        return "No evaluation results available."
    
    summary_parts = []
    
    # Overall statistics
    total_models = overall.get("total_models", 0)
    best_model = overall.get("best_performing_model", "Unknown")
    avg_score = overall.get("overall_average_score", 0)
    
    summary_parts.append(f"Evaluated {total_models} models with an overall average score of {avg_score:.2f}%.")
    summary_parts.append(f"Best performing model: {best_model}")
    
    # Model performance breakdown
    rankings = overall.get("model_rankings", [])
    if rankings:
        summary_parts.append("\nModel Performance Rankings:")
        for i, ranking in enumerate(rankings[:3]):  # Top 3
            model_name = ranking["model_name"]
            score = ranking["average_score"]
            accuracy = ranking["accuracy_percentage"]
            summary_parts.append(f"{i+1}. {model_name}: {score:.2f}% avg score, {accuracy:.2f}% accuracy")
    
    # Performance analysis
    if len(rankings) > 1:
        best_score = rankings[0]["average_score"]
        worst_score = rankings[-1]["average_score"]
        score_gap = best_score - worst_score
        
        if score_gap > 20:
            summary_parts.append(f"\nSignificant performance variation detected ({score_gap:.1f}% gap between best and worst models).")
        elif score_gap > 10:
            summary_parts.append(f"\nModerate performance variation ({score_gap:.1f}% gap between best and worst models).")
        else:
            summary_parts.append(f"\nConsistent performance across models ({score_gap:.1f}% gap).")
    
    client=GroqClient(api_key=os.getenv("GROQ_API_KEY"),model_name="llama3-70b-8192")
    response=await client.generate_response(
        prompt=f"""Summarize the model evaluation results in a concise manner from this data {summary_parts} and 
         provide me the detail model evaluation summary in md format.
         Do not generate the any table or any other format just generate the summary in md format.
         Try to provide me the your analysis based on the model performance and also provide me the
         performance of the models based on the overall performance and also provide me the best performing model and
         worst performing model and also provide me the overall average score of the models.
         generate the detailed summary of the model evaluation results.
         """,
    )

    # return " ".join(summary_parts)
    print("Generated Summary:", response)
    return response

# Add SimpleDocDocument import fix
from reportlab.platypus import SimpleDocTemplate as SimpleDocDocument