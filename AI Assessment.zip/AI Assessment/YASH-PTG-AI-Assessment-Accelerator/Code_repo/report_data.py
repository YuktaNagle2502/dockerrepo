# universal_reports.py
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Text, LargeBinary
from sqlalchemy.orm import relationship, Session
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from database import Base
import uuid
import io
import mimetypes
from login_project import get_current_user, User, Project

# Database Model
class Report(Base):
    """Universal report table for storing reports from all modules"""
    __tablename__ = "reports"
    
    id = Column(Integer, primary_key=True, index=True)
    report_uuid = Column(String, unique=True, index=True, nullable=False)  # Unique identifier for public access
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    
    # Module and context information
    module_name = Column(String, nullable=False)  # e.g., "pre_workshop", "data_compliance", "ai_profiling"
    module_entity_id = Column(Integer, nullable=False)  # ID of the entity within the module (session_id, use_case_id, etc.)
    
    # Report metadata
    report_name = Column(String, nullable=False)  # Human readable name
    report_type = Column(String, nullable=False)  # "pdf", "json", "xlsx", "html"
    file_content = Column(LargeBinary, nullable=False)  # File content as binary
    file_size = Column(Integer, nullable=False)  # File size in bytes
    mime_type = Column(String, nullable=False)  # MIME type for proper download
    
    # Status and metadata
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = relationship("User")
    project = relationship("Project")

# Pydantic Models
class ReportCreate(BaseModel):
    """Model for creating a new report"""
    user_id: int
    project_id: int
    module_name: str
    module_entity_id: int
    report_name: str
    report_type: str
    file_content: bytes
    mime_type: Optional[str] = None

class ReportResponse(BaseModel):
    """Model for report response"""
    id: int
    report_uuid: str
    user_id: int
    project_id: int
    module_name: str
    module_entity_id: int
    report_name: str
    report_type: str
    file_size: int
    mime_type: str
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class ReportListItem(BaseModel):
    """Simplified model for report listing"""
    id: int
    report_uuid: str
    module_name: str
    module_entity_id: int
    report_name: str
    report_type: str
    file_size: int
    created_at: datetime

# Universal Report Manager Class
class UniversalReportManager:
    """Universal report storage and retrieval manager"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def save_report(
        self, 
        user_id: int,
        project_id: int,
        module_name: str,
        module_entity_id: int,
        report_name: str,
        file_content: Union[bytes, io.BytesIO],
        report_type: str = "pdf",
        mime_type: Optional[str] = None
    ) -> Report:
        """
        Save a report to the database
        
        Args:
            user_id: ID of the user creating the report
            project_id: ID of the associated project
            module_name: Name of the module (e.g., "pre_workshop", "data_compliance")
            module_entity_id: ID of the entity within the module
            report_name: Human readable name for the report
            file_content: Report content as bytes or BytesIO
            report_type: Type of report (pdf, json, xlsx, html)
            mime_type: MIME type (auto-detected if not provided)
        
        Returns:
            Created Report object
        """
        
        # Handle BytesIO objects
        if isinstance(file_content, io.BytesIO):
            file_content.seek(0)
            content_bytes = file_content.read()
        else:
            content_bytes = file_content
        
        # Auto-detect MIME type if not provided
        if not mime_type:
            mime_type = self._get_mime_type(report_type)
        
        # Generate unique UUID for the report
        report_uuid = str(uuid.uuid4())
        
        # Check if report already exists for this module entity
        existing_report = self.db.query(Report).filter(
            Report.user_id == user_id,
            Report.project_id == project_id,
            Report.module_name == module_name,
            Report.module_entity_id == module_entity_id,
            Report.report_type == report_type,
            Report.is_active == True
        ).first()
        
        if existing_report:
            # Update existing report
            existing_report.file_content = content_bytes
            existing_report.file_size = len(content_bytes)
            existing_report.report_name = report_name
            existing_report.mime_type = mime_type
            existing_report.updated_at = datetime.utcnow()
            self.db.commit()
            self.db.refresh(existing_report)
            return existing_report
        else:
            # Create new report
            new_report = Report(
                report_uuid=report_uuid,
                user_id=user_id,
                project_id=project_id,
                module_name=module_name,
                module_entity_id=module_entity_id,
                report_name=report_name,
                report_type=report_type,
                file_content=content_bytes,
                file_size=len(content_bytes),
                mime_type=mime_type
            )
            
            self.db.add(new_report)
            self.db.commit()
            self.db.refresh(new_report)
            return new_report
    
    def get_report_by_uuid(self, report_uuid: str, user_id: int) -> Optional[Report]:
        """Get a report by its UUID (with user access check)"""
        return self.db.query(Report).filter(
            Report.report_uuid == report_uuid,
            Report.user_id == user_id,
            Report.is_active == True
        ).first()
    
    def get_reports_by_module(
        self, 
        user_id: int, 
        module_name: str, 
        module_entity_id: Optional[int] = None,
        project_id: Optional[int] = None
    ) -> List[Report]:
        """Get all reports for a specific module"""
        query = self.db.query(Report).filter(
            Report.user_id == user_id,
            Report.module_name == module_name,
            Report.is_active == True
        )
        
        if module_entity_id is not None:
            query = query.filter(Report.module_entity_id == module_entity_id)
        
        if project_id is not None:
            query = query.filter(Report.project_id == project_id)
        
        return query.order_by(Report.created_at.desc()).all()
    
    def get_reports_by_project(self, user_id: int, project_id: int) -> List[Report]:
        """Get all reports for a specific project"""
        return self.db.query(Report).filter(
            Report.user_id == user_id,
            Report.project_id == project_id,
            Report.is_active == True
        ).order_by(Report.created_at.desc()).all()
    
    def get_user_reports(self, user_id: int, limit: int = 50) -> List[Report]:
        """Get all reports for a user"""
        return self.db.query(Report).filter(
            Report.user_id == user_id,
            Report.is_active == True
        ).order_by(Report.created_at.desc()).limit(limit).all()
    
    def delete_report(self, report_uuid: str, user_id: int) -> bool:
        """Soft delete a report"""
        report = self.get_report_by_uuid(report_uuid, user_id)
        if report:
            report.is_active = False
            report.updated_at = datetime.utcnow()
            self.db.commit()
            return True
        return False
    
    def get_report_content(self, report_uuid: str, user_id: int) -> Optional[bytes]:
        """Get the binary content of a report"""
        report = self.get_report_by_uuid(report_uuid, user_id)
        if report:
            return report.file_content
        return None
    
    def _get_mime_type(self, report_type: str) -> str:
        """Get MIME type based on report type"""
        mime_map = {
            "pdf": "application/pdf",
            "json": "application/json",
            "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "xls": "application/vnd.ms-excel",
            "html": "text/html",
            "txt": "text/plain",
            "csv": "text/csv",
            "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        }
        return mime_map.get(report_type.lower(), "application/octet-stream")

# Helper Functions for Integration
def save_module_report(
    db: Session,
    user_id: int,
    project_id: int,
    module_name: str,
    module_entity_id: int,
    report_name: str,
    file_content: Union[bytes, io.BytesIO],
    report_type: str = "pdf"
) -> Report:
    """
    Convenience function to save a report from any module
    
    Usage in modules:
    from universal_reports import save_module_report
    
    # In your endpoint:
    report = save_module_report(
        db=db,
        user_id=current_user.id,
        project_id=session.project_id,
        module_name="pre_workshop",
        module_entity_id=session_id,
        report_name=f"Pre-Workshop Report - {session.session_name}",
        file_content=pdf_content,
        report_type="pdf"
    )
    """
    manager = UniversalReportManager(db)
    return manager.save_report(
        user_id=user_id,
        project_id=project_id,
        module_name=module_name,
        module_entity_id=module_entity_id,
        report_name=report_name,
        file_content=file_content,
        report_type=report_type
    )

def get_module_reports(
    db: Session,
    user_id: int,
    module_name: str,
    module_entity_id: Optional[int] = None,
    project_id: Optional[int] = None
) -> List[ReportListItem]:
    """
    Convenience function to get reports for a module
    
    Usage:
    reports = get_module_reports(
        db=db,
        user_id=current_user.id,
        module_name="pre_workshop",
        module_entity_id=session_id
    )
    """
    manager = UniversalReportManager(db)
    reports = manager.get_reports_by_module(
        user_id=user_id,
        module_name=module_name,
        module_entity_id=module_entity_id,
        project_id=project_id
    )
    
    return [
        ReportListItem(
            id=report.id,
            report_uuid=report.report_uuid,
            module_name=report.module_name,
            module_entity_id=report.module_entity_id,
            report_name=report.report_name,
            report_type=report.report_type,
            file_size=report.file_size,
            created_at=report.created_at
        )
        for report in reports
    ]

# FastAPI Router for Report Management
from fastapi import APIRouter, Depends, HTTPException, status, Response, UploadFile, File, Form
from fastapi.responses import StreamingResponse
from database import get_db

reports_router = APIRouter(prefix="/reports", tags=["Reports"])

@reports_router.get("/user", response_model=List[ReportListItem])
def get_user_all_reports(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all reports for the current user"""
    manager = UniversalReportManager(db)
    reports = manager.get_user_reports(current_user.id)
    
    return [
        ReportListItem(
            id=report.id,
            report_uuid=report.report_uuid,
            module_name=report.module_name,
            module_entity_id=report.module_entity_id,
            report_name=report.report_name,
            report_type=report.report_type,
            file_size=report.file_size,
            created_at=report.created_at
        )
        for report in reports
    ]

@reports_router.get("/project/{project_id}", response_model=List[ReportListItem])
def get_project_reports(
    project_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all reports for a specific project"""
    manager = UniversalReportManager(db)
    reports = manager.get_reports_by_project(current_user.id, project_id)
    
    return [
        ReportListItem(
            id=report.id,
            report_uuid=report.report_uuid,
            module_name=report.module_name,
            module_entity_id=report.module_entity_id,
            report_name=report.report_name,
            report_type=report.report_type,
            file_size=report.file_size,
            created_at=report.created_at
        )
        for report in reports
    ]

@reports_router.get("/module/{module_name}")
def get_module_all_reports(
    module_name: str,
    module_entity_id: Optional[int] = None,
    project_id: Optional[int] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get reports for a specific module"""
    return get_module_reports(
        db=db,
        user_id=current_user.id,
        module_name=module_name,
        module_entity_id=module_entity_id,
        project_id=project_id
    )

@reports_router.get("/download/{report_uuid}")
def download_report(
    report_uuid: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Download a report by its UUID"""
    manager = UniversalReportManager(db)
    report = manager.get_report_by_uuid(report_uuid, current_user.id)
    
    if not report:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Report not found"
        )
    
    # Create filename
    extension = report.report_type
    filename = f"{report.report_name.replace(' ', '_')}.{extension}"
    
    # Return file as streaming response
    def iterfile():
        yield report.file_content
    
    return StreamingResponse(
        iterfile(),
        media_type=report.mime_type,
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

@reports_router.delete("/{report_uuid}")
def delete_report(
    report_uuid: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a report"""
    manager = UniversalReportManager(db)
    success = manager.delete_report(report_uuid, current_user.id)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Report not found"
        )
    
    return {"message": "Report deleted successfully"}

@reports_router.post("/save", response_model=ReportResponse)
async def save_report_to_database(
    file: UploadFile = File(...),
    user_id: int = Form(...),
    project_id: int = Form(...),
    module_name: str = Form(...),
    module_entity_id: int = Form(...),
    report_name: str = Form(...),
    report_type: str = Form(default="pdf"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Save a report file to the database
    
    Frontend usage:
    const formData = new FormData();
    formData.append('file', fileObject);
    formData.append('user_id', userId);
    formData.append('project_id', projectId);
    formData.append('module_name', 'pre_workshop');
    formData.append('module_entity_id', sessionId);
    formData.append('report_name', 'My Report');
    formData.append('report_type', 'pdf');
    
    fetch('/reports/save', {
        method: 'POST',
        body: formData
    })
    """
    
    # Verify user owns the project
    project = db.query(Project).filter(
        Project.id == project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project not found or access denied"
        )
    
    # Read file content
    file_content = await file.read()
    
    # Auto-detect report type from filename if not provided
    if report_type == "pdf" and file.filename:
        file_extension = file.filename.split('.')[-1].lower()
        if file_extension in ['json', 'xlsx', 'html', 'txt', 'csv', 'docx']:
            report_type = file_extension
    
    # Save report using the helper function
    try:
        report = save_module_report(
            db=db,
            user_id=user_id,
            project_id=project_id,
            module_name=module_name,
            module_entity_id=module_entity_id,
            report_name=report_name,
            file_content=file_content,
            report_type=report_type
        )
        
        return ReportResponse.model_validate(report)
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving report: {str(e)}"
        )