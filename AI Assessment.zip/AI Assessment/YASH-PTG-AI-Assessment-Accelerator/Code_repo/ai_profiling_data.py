from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Response
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List, Dict, Any
import json
import os
import tempfile
import shutil
from pathlib import Path
import pandas as pd
import numpy as np
import logging
from groq import Groq
import re
import io
import warnings

# ReportLab imports for PDF generation
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.colors import HexColor, black, white, red, green, orange
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from reportlab.lib import colors

# Import auth dependencies
from login_project import get_current_user, User

# Suppress warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Pydantic Models for API
class DataProfilingAnalysisResponse(BaseModel):
    analysis_type: str
    generated_content: str
    file_analyzed: str
    data_quality_score: float
    generated_at: datetime

class DataFileStats(BaseModel):
    filename: str
    file_type: str
    size_mb: float
    num_rows: int
    num_columns: int
    data_quality_score: float
    completeness_percentage: float

# Data Profiling Engine
class DataProfilerAPI:
    """
    API-based data profiling system using Groq API
    Supports CSV, TXT, Excel, JSON, and Parquet files
    """
    
    def __init__(self, groq_api_key: str):
        """Initialize the data profiler with Groq API key"""
        self.groq_client = Groq(api_key=groq_api_key)
        self.supported_formats = ['.csv', '.txt', '.parquet', '.xlsx', '.xls', '.json']
        self.logger = logger
        
    async def load_data(self, file_path: str) -> pd.DataFrame:
        """Load data from various file formats"""
        file_ext = os.path.splitext(file_path)[1].lower()
        
        if file_ext not in self.supported_formats:
            raise ValueError(f"Unsupported file format: {file_ext}. Supported formats: {self.supported_formats}")
        
        try:
            if file_ext == '.csv':
                # Try different encodings and separators
                encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
                separators = [',', ';', '\t', '|']
                
                for encoding in encodings:
                    for sep in separators:
                        try:
                            df = pd.read_csv(file_path, encoding=encoding, sep=sep)
                            if len(df.columns) > 1:  # Valid CSV should have multiple columns
                                self.logger.info(f"Successfully loaded CSV with encoding: {encoding}, separator: {sep}")
                                return df
                        except:
                            continue
                
                # Fallback to basic CSV loading
                df = pd.read_csv(file_path)
                
            elif file_ext == '.txt':
                # Try to detect if it's a delimited file
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        first_line = f.readline()
                        if '\t' in first_line:
                            df = pd.read_csv(file_path, sep='\t')
                        elif ',' in first_line:
                            df = pd.read_csv(file_path, sep=',')
                        elif ';' in first_line:
                            df = pd.read_csv(file_path, sep=';')
                        elif '|' in first_line:
                            df = pd.read_csv(file_path, sep='|')
                        else:
                            # Plain text file - create single column DataFrame
                            with open(file_path, 'r', encoding='utf-8') as f:
                                content = f.read()
                            lines = content.split('\n')
                            df = pd.DataFrame({'text_content': lines})
                except Exception as e:
                    # Try with different encoding
                    try:
                        with open(file_path, 'r', encoding='latin-1') as f:
                            content = f.read()
                        lines = content.split('\n')
                        df = pd.DataFrame({'text_content': lines})
                    except:
                        raise ValueError(f"Could not read text file: {str(e)}")
                        
            elif file_ext in ['.xlsx', '.xls']:
                df = pd.read_excel(file_path)
                
            elif file_ext == '.json':
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                if isinstance(data, list):
                    df = pd.DataFrame(data)
                else:
                    df = pd.DataFrame([data])
                        
            elif file_ext == '.parquet':
                try:
                    df = pd.read_parquet(file_path)
                except ImportError:
                    raise ValueError("pyarrow library not installed. Install with: pip install pyarrow")
                
            else:
                raise ValueError(f"Unsupported file format: {file_ext}")
                
            self.logger.info(f"Successfully loaded {file_ext} file with shape: {df.shape}")
            return df
            
        except Exception as e:
            self.logger.error(f"Error loading file: {str(e)}")
            raise
    
    def basic_profiling(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Perform basic statistical profiling of the dataset"""
        profile = {
            'basic_info': {
                'num_rows': len(df),
                'num_columns': len(df.columns),
                'memory_usage': df.memory_usage(deep=True).sum(),
                'file_size_mb': df.memory_usage(deep=True).sum() / (1024 * 1024)
            },
            'column_info': {},
            'data_types': {str(col): str(dtype) for col, dtype in df.dtypes.items()},
            'missing_values': {str(col): int(count) for col, count in df.isnull().sum().items()},
            'missing_percentage': {str(col): float(pct) for col, pct in (df.isnull().sum() / len(df) * 100).items()}
        }
        
        # Detailed column analysis
        for col in df.columns:
            col_str = str(col)
            col_profile = {
                'dtype': str(df[col].dtype),
                'non_null_count': int(df[col].count()),
                'null_count': int(df[col].isnull().sum()),
                'unique_count': int(df[col].nunique()),
                'unique_percentage': float((df[col].nunique() / len(df) * 100)) if len(df) > 0 else 0
            }
            
            # Numeric columns
            if pd.api.types.is_numeric_dtype(df[col]):
                try:
                    col_profile.update({
                        'min': float(df[col].min()) if pd.notna(df[col].min()) else None,
                        'max': float(df[col].max()) if pd.notna(df[col].max()) else None,
                        'mean': float(df[col].mean()) if pd.notna(df[col].mean()) else None,
                        'median': float(df[col].median()) if pd.notna(df[col].median()) else None,
                        'std': float(df[col].std()) if pd.notna(df[col].std()) else None,
                        'skewness': float(df[col].skew()) if pd.notna(df[col].skew()) else None,
                        'kurtosis': float(df[col].kurtosis()) if pd.notna(df[col].kurtosis()) else None
                    })
                except:
                    col_profile.update({
                        'min': None, 'max': None, 'mean': None, 'median': None, 
                        'std': None, 'skewness': None, 'kurtosis': None
                    })
                    
            # String columns
            elif pd.api.types.is_string_dtype(df[col]) or pd.api.types.is_object_dtype(df[col]):
                try:
                    str_series = df[col].astype(str)
                    col_profile.update({
                        'avg_length': float(str_series.str.len().mean()),
                        'min_length': int(str_series.str.len().min()),
                        'max_length': int(str_series.str.len().max()),
                        'most_common': {str(k): int(v) for k, v in df[col].value_counts().head(5).items()}
                    })
                except:
                    col_profile.update({
                        'avg_length': None, 'min_length': None, 'max_length': None,
                        'most_common': {}
                    })
                    
            # DateTime columns
            elif pd.api.types.is_datetime64_any_dtype(df[col]):
                try:
                    col_profile.update({
                        'min_date': str(df[col].min()),
                        'max_date': str(df[col].max()),
                        'date_range_days': int((df[col].max() - df[col].min()).days) if df[col].notna().any() else 0
                    })
                except:
                    col_profile.update({
                        'min_date': None, 'max_date': None, 'date_range_days': None
                    })
                    
            profile['column_info'][col_str] = col_profile
            
        return profile
    
    def calculate_data_quality_score(self, df: pd.DataFrame, basic_profile: Dict[str, Any]) -> float:
        """Calculate overall data quality score"""
        try:
            # Completeness score (percentage of non-null values)
            total_cells = basic_profile['basic_info']['num_rows'] * basic_profile['basic_info']['num_columns']
            total_missing = sum(basic_profile['missing_values'].values())
            completeness = ((total_cells - total_missing) / total_cells * 100) if total_cells > 0 else 0
            
            # Consistency score (check for obvious data issues)
            consistency = 100.0
            for col in df.columns:
                if df[col].dtype == 'object':
                    # Check for mixed data types in text columns
                    unique_vals = df[col].dropna().unique()
                    if len(unique_vals) > 0:
                        text_ratio = sum(1 for val in unique_vals if isinstance(val, str)) / len(unique_vals)
                        consistency *= text_ratio
            
            # Volume score (penalize very small datasets)
            volume_score = min(100.0, df.shape[0] / 100 * 100)  # Assume 100 rows is minimum good volume
            
            # Overall quality score
            quality_score = (completeness * 0.5 + consistency * 0.3 + volume_score * 0.2)
            return round(quality_score, 2)
        except:
            return 50.0  # Default score if calculation fails
    
    async def llm_analysis(self, df: pd.DataFrame, basic_profile: Dict[str, Any], filename: str) -> str:
        """Use Groq LLM to perform advanced analysis and generate markdown report"""
        
        # Prepare data summary for LLM
        sample_data = []
        try:
            if len(df) > 0:
                sample_data = df.head(100).to_dict('records')
                # Convert any non-serializable types to strings
                for record in sample_data:
                    for key, value in record.items():
                        if pd.isna(value) or value is None:
                            record[key] = "null"
                        elif not isinstance(value, (str, int, float, bool)):
                            record[key] = str(value)
        except Exception as e:
            self.logger.warning(f"Could not prepare sample data: {str(e)}")
        
        data_summary = {
            'shape': df.shape,
            'columns': [str(col) for col in df.columns],
            'dtypes': {str(col): str(dtype) for col, dtype in df.dtypes.items()},
            'sample_data': sample_data[:10] if sample_data else []  # Limit to 10 rows for prompt
        }
        
        # Calculate additional metrics
        total_cells = basic_profile['basic_info']['num_rows'] * basic_profile['basic_info']['num_columns']
        total_missing = sum(basic_profile['missing_values'].values())
        completeness_score = ((total_cells - total_missing) / total_cells * 100) if total_cells > 0 else 0
        
        # Create comprehensive prompt for LLM
        system_prompt = """
        You are a senior data analyst and data scientist with expertise in data profiling, quality assessment, and business intelligence.
        Your task is to analyze the provided dataset and generate a comprehensive data profiling report.
        
        Focus on the following areas:
        1. Executive Summary with key findings
        2. Data Quality Assessment and Scoring
        3. Column-by-Column Analysis
        4. Data Patterns and Insights Discovery
        5. Potential Data Issues and Anomalies
        6. Business Intelligence Opportunities
        7. Data Preprocessing Recommendations
        
        
        Generate a detailed report in markdown format with clear sections, tables where appropriate, and actionable insights.
        Use professional language and provide specific, data-driven observations.
        """
        
        user_request = f"""
        Please analyze the following dataset and generate a comprehensive data profiling report:
        
        **File Information:**
        - Filename: {filename}
        - Shape: {data_summary['shape']} (rows x columns)
        - Columns: {data_summary['columns']}
        - Data Types: {data_summary['dtypes']}
        - File Size: {basic_profile['basic_info']['file_size_mb']:.2f} MB
        - Data Completeness: {completeness_score:.2f}%
        
        **Missing Values Analysis:**
        {json.dumps(basic_profile['missing_values'], indent=2)}
        
        **Sample Data (first 10 rows):**
        {json.dumps(data_summary['sample_data'], indent=2)}
        
        **Column Statistics Summary:**
        {json.dumps({col: info for col, info in list(basic_profile['column_info'].items())[:5]}, indent=2)}
        
        Generate a comprehensive data profiling report in markdown format.
        Provide specific insights about data quality, patterns, and business value.
        Include actionable recommendations for data improvement and usage.
        """
        
        try:
            response = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_request}
                ],
                temperature=0.2,
                max_tokens=4000
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            self.logger.error(f"Error in LLM analysis: {str(e)}")
            return self._generate_fallback_report(df, basic_profile, filename, completeness_score)
    
    def _generate_fallback_report(self, df: pd.DataFrame, basic_profile: Dict[str, Any], filename: str, completeness_score: float) -> str:
        """Generate a fallback report if LLM analysis fails"""
        
        report = f"""
# Data Profiling Report

## Executive Summary

**File**: {filename}  
**Dataset Shape**: {df.shape[0]:,} rows × {df.shape[1]} columns  
**Data Completeness**: {completeness_score:.2f}%  
**File Size**: {basic_profile['basic_info']['file_size_mb']:.2f} MB

## Data Quality Assessment

### Overall Metrics
- **Total Data Points**: {basic_profile['basic_info']['num_rows'] * basic_profile['basic_info']['num_columns']:,}
- **Missing Values**: {sum(basic_profile['missing_values'].values()):,}
- **Data Types**: {len(set(basic_profile['data_types'].values()))} unique types

### Column Analysis

| Column | Data Type | Non-Null Count | Unique Values | Missing % |
|--------|-----------|----------------|---------------|-----------|
"""
        
        for col, info in basic_profile['column_info'].items():
            missing_pct = basic_profile['missing_percentage'].get(col, 0)
            report += f"| {col[:20]}{'...' if len(col) > 20 else ''} | {info['dtype']} | {info['non_null_count']:,} | {info['unique_count']:,} | {missing_pct:.1f}% |\n"
        
        report += """

## Data Quality Issues

"""
        
        # Identify issues
        issues = []
        for col, missing_pct in basic_profile['missing_percentage'].items():
            if missing_pct > 50:
                issues.append(f"- **{col}**: High missing data ({missing_pct:.1f}%)")
            elif missing_pct > 20:
                issues.append(f"- **{col}**: Moderate missing data ({missing_pct:.1f}%)")
        
        if issues:
            report += "\n".join(issues)
        else:
            report += "- No significant data quality issues detected"
        
        report += """

## Recommendations

1. **Data Cleaning**: Address missing values in high-missing columns
2. **Data Validation**: Verify data types and formats
3. **Quality Monitoring**: Implement ongoing data quality checks
4. **Documentation**: Create data dictionary and metadata

## Analysis Limitations

This report was generated using basic profiling due to AI analysis unavailability.
For more detailed insights, please ensure AI service connectivity.
"""
        
        return report
    
    async def analyze_file(self, file_path: str, filename: str) -> Dict[str, Any]:
        """Main method to analyze a file and generate comprehensive report"""
        try:
            self.logger.info(f"Starting analysis for file: {filename}")
            
            # Load data
            df = await self.load_data(file_path)
            self.logger.info(f"Loaded data with shape: {df.shape}")
            
            # Basic profiling
            self.logger.info("Performing basic profiling...")
            basic_profile = self.basic_profiling(df)
            
            # Calculate quality score
            quality_score = self.calculate_data_quality_score(df, basic_profile)
            
            # LLM analysis to generate markdown report
            self.logger.info("Performing AI-powered analysis...")
            markdown_content = await self.llm_analysis(df, basic_profile, filename)
            
            self.logger.info("Analysis completed successfully!")
            
            return {
                'analysis_type': 'comprehensive',
                'generated_content': markdown_content,
                'file_analyzed': filename,
                'data_quality_score': quality_score,
                'generated_at': datetime.utcnow()
            }
            
        except Exception as e:
            self.logger.error(f"Analysis failed: {str(e)}")
            raise

# PDF Report Generator
class DataProfilingPDFGenerator:
    """Generate PDF reports for data profiling analysis from markdown content"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        # Title style
        self.title_style = ParagraphStyle(
            'DataProfilingTitle',
            parent=self.styles['Title'],
            fontSize=24,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=HexColor('#1a365d'),
            fontName='Helvetica-Bold'
        )
        
        # Subtitle style
        self.subtitle_style = ParagraphStyle(
            'DataProfilingSubtitle',
            parent=self.styles['Normal'],
            fontSize=16,
            spaceAfter=20,
            alignment=TA_CENTER,
            textColor=HexColor('#2d3748'),
            fontName='Helvetica-Oblique'
        )
        
        # Heading styles
        self.h1_style = ParagraphStyle(
            'DataProfilingH1',
            parent=self.styles['Heading1'],
            fontSize=18,
            spaceAfter=15,
            spaceBefore=25,
            textColor=HexColor('#2b6cb0'),
            fontName='Helvetica-Bold',
            backColor=HexColor('#ebf8ff'),
            borderWidth=1,
            borderColor=HexColor('#3182ce'),
            borderPadding=8,
            leftIndent=10
        )
        
        self.h2_style = ParagraphStyle(
            'DataProfilingH2',
            parent=self.styles['Heading2'],
            fontSize=16,
            spaceAfter=12,
            spaceBefore=18,
            textColor=HexColor('#2c5282'),
            fontName='Helvetica-Bold',
            leftIndent=5
        )
        
        self.h3_style = ParagraphStyle(
            'DataProfilingH3',
            parent=self.styles['Heading3'],
            fontSize=14,
            spaceAfter=10,
            spaceBefore=15,
            textColor=HexColor('#3182ce'),
            fontName='Helvetica-Bold',
            leftIndent=10
        )
        
        # Body styles
        self.body_style = ParagraphStyle(
            'DataProfilingBody',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=8,
            textColor=HexColor('#2d3748'),
            alignment=TA_JUSTIFY,
            leftIndent=20,
            rightIndent=20
        )
        
        # List styles
        self.bullet_style = ParagraphStyle(
            'DataProfilingBullet',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=6,
            textColor=HexColor('#4a5568'),
            leftIndent=30,
            bulletIndent=20
        )
    
    def generate_pdf(self, markdown_content: str, title: str = "Data Profiling Report") -> bytes:
        """Generate PDF from markdown content"""
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=50,
            leftMargin=50,
            topMargin=60,
            bottomMargin=60
        )
        
        # Parse markdown and build content
        content = self._parse_markdown_to_reportlab(markdown_content, title)
        
        # Build PDF
        doc.build(content)
        buffer.seek(0)
        return buffer.read()
    
    def _clean_text(self, text: str) -> str:
        """Clean and escape text for ReportLab"""
        # Remove problematic characters and fix common issues
        text = text.replace('\\n', '\n')
        text = text.replace('\\\\', '\\')
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        
        # Fix common markdown to HTML issues
        text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
        text = re.sub(r'\*(.*?)\*', r'<i>\1</i>', text)
        text = re.sub(r'`(.*?)`', r'<font name="Courier">\1</font>', text)
        
        return text
    
    def _parse_markdown_to_reportlab(self, markdown_content: str, title: str) -> List:
        """Parse markdown content to ReportLab elements"""
        content = []
        
        # Add cover page
        content.append(Paragraph(title, self.title_style))
        content.append(Spacer(1, 20))
        
        # Add generation info
        timestamp = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        content.append(Paragraph(f"Generated on {timestamp}", self.subtitle_style))
        content.append(Spacer(1, 30))
        
        # Clean the markdown content
        cleaned_content = self._clean_text(markdown_content)
        
        # Split content into lines
        lines = cleaned_content.split('\n')
        
        in_table = False
        table_rows = []
        
        for line in lines:
            original_line = line
            line = line.strip()
            
            if not line:
                if in_table:
                    # End table
                    if len(table_rows) > 1:  # Header + at least one row
                        content.append(self._create_table(table_rows))
                    table_rows = []
                    in_table = False
                content.append(Spacer(1, 8))
                continue
            
            # Handle tables
            if '|' in line and line.count('|') >= 2:
                if not in_table:
                    in_table = True
                    table_rows = []
                
                # Clean table row
                cells = [cell.strip() for cell in line.split('|')[1:-1]]  # Remove empty first/last
                if cells and not all(cell in ['-', '--', '---', '----'] or cell.startswith('-') for cell in cells):
                    table_rows.append(cells)
                continue
            else:
                if in_table:
                    # End table
                    if len(table_rows) > 1:
                        content.append(self._create_table(table_rows))
                    table_rows = []
                    in_table = False
            
            # Handle headings
            if line.startswith('# '):
                text = line[2:].strip()
                content.append(Paragraph(text, self.h1_style))
                
            elif line.startswith('## '):
                text = line[3:].strip()
                content.append(Paragraph(text, self.h2_style))
                
            elif line.startswith('### '):
                text = line[4:].strip()
                content.append(Paragraph(text, self.h3_style))
            
            # Handle lists
            elif line.startswith('- ') or line.startswith('* '):
                text = line[2:].strip()
                content.append(Paragraph(f"• {text}", self.bullet_style))
                
            elif re.match(r'^\d+\.', line):
                text = re.sub(r'^\d+\.\s*', '', line)
                content.append(Paragraph(f"• {text}", self.bullet_style))
            
            # Handle regular paragraphs
            else:
                if line.strip():
                    content.append(Paragraph(line, self.body_style))
        
        # Handle any remaining table
        if in_table and len(table_rows) > 1:
            content.append(self._create_table(table_rows))
        
        return content
    
    def _create_table(self, rows: List[List[str]]) -> Table:
        """Create a ReportLab table from markdown table rows"""
        if not rows:
            return Spacer(1, 0)
        
        # Calculate column widths based on content
        max_cols = max(len(row) for row in rows)
        col_width = 6.5 * inch / max_cols if max_cols > 0 else 1 * inch
        col_widths = [col_width] * max_cols
        
        # Create table data with proper cell formatting
        table_data = []
        for i, row in enumerate(rows):
            # Pad row to max columns
            while len(row) < max_cols:
                row.append('')
            
            # Create paragraphs for each cell
            cell_paragraphs = []
            for cell in row:
                if i == 0:  # Header row
                    p = Paragraph(f"<b>{cell}</b>", self.styles['Normal'])
                else:
                    p = Paragraph(cell, self.styles['Normal'])
                cell_paragraphs.append(p)
            table_data.append(cell_paragraphs)
        
        table = Table(table_data, colWidths=col_widths)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), HexColor('#3182ce')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BACKGROUND', (0, 1), (-1, -1), HexColor('#f7fafc')),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#f7fafc'), colors.white])
        ]))
        
        return table

# Utility functions
async def save_uploaded_file(upload_file: UploadFile, temp_dir: str = None) -> str:
    """Save uploaded file to temporary location"""
    if temp_dir is None:
        temp_dir = tempfile.mkdtemp()
    
    file_path = os.path.join(temp_dir, upload_file.filename)
    
    try:
        content = await upload_file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        return file_path
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving file: {str(e)}"
        )

# Router
router = APIRouter(prefix="/data-profiling", tags=["Data Profiling"])

# Get API key from environment
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    print("Warning: GROQ_API_KEY not found in environment variables")

# Initialize processors
pdf_generator = DataProfilingPDFGenerator()

@router.post("/analyze", response_model=DataProfilingAnalysisResponse)
async def analyze_data_file(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    Analyze uploaded data file and generate comprehensive profiling report
    
    This endpoint:
    1. Processes the uploaded data file (CSV, Excel, JSON, TXT, Parquet)
    2. Performs comprehensive data profiling analysis
    3. Generates AI-powered insights and recommendations
    4. Returns markdown-formatted report content
    
    Parameters:
    - file: Upload file (any supported format)
    """
    
    if not GROQ_API_KEY:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="AI service not configured"
        )
    
    # Validate file type
    file_ext = Path(file.filename).suffix.lower()
    supported_formats = ['.csv', '.txt', '.parquet', '.xlsx', '.xls', '.json']
    
    if file_ext not in supported_formats:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file type: {file_ext}. Supported formats: {', '.join(supported_formats)}"
        )
    
    # Process uploaded file
    temp_dir = tempfile.mkdtemp()
    try:
        file_path = await save_uploaded_file(file, temp_dir)
        
        # Initialize profiler and analyze
        profiler = DataProfilerAPI(GROQ_API_KEY)
        analysis_result = await profiler.analyze_file(file_path, file.filename)
        
        return DataProfilingAnalysisResponse(**analysis_result)
        
    except Exception as e:
        logger.error(f"Error analyzing file: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error analyzing file: {str(e)}"
        )
    
    finally:
        # Clean up temporary files
        shutil.rmtree(temp_dir, ignore_errors=True)

@router.post("/generate-pdf")
async def generate_data_profiling_pdf(
    content: str,
    current_user: User = Depends(get_current_user)
):
    """
    Generate PDF report from data profiling analysis markdown content
    
    This endpoint:
    1. Takes markdown-formatted data profiling content
    2. Generates a beautifully formatted PDF report
    3. Returns the PDF as downloadable file
    
    Parameters:
    - content: The markdown content to convert to PDF
    """
    
    try:
        # Generate PDF from markdown content
        pdf_content = pdf_generator.generate_pdf(
            content, 
            "Data Profiling Report"
        )
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"data_profiling_report_{timestamp}.pdf"
        
        return Response(
            content=pdf_content,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename={filename}"
            }
        )
        
    except Exception as e:
        logger.error(f"Error generating PDF: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generating PDF: {str(e)}"
        )