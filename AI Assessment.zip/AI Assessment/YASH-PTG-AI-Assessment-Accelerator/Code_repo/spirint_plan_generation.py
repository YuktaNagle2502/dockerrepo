from fastapi import APIRouter, Depends, HTTPException, status, Response, Form
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
import json
import os
import uuid
from pathlib import Path
import asyncio
from groq import Groq
import time
import tempfile
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.lib.colors import HexColor, black, white, blue, red, green
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.charts.legends import Legend
from reportlab.graphics.charts.barcharts import VerticalBarChart
import io
import logging

# Import database configuration and auth dependencies
from database import get_db
from login_project import get_current_user, User, Project
from pre_workshop import GeneratedUseCase, PreWorkshopSession

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Pydantic Models
class SprintPlanningRequest(BaseModel):
    use_case_id: int
    project_type: str = Field(default="web application", description="Type of project: web application, mobile app, data platform, etc.")
    sprint_duration: str = Field(default="2 weeks", description="Duration of each sprint")
    total_sprints: int = Field(default=4, description="Total number of sprints")
    team_size: int = Field(default=4, description="Total team members")
    
class SprintPlanningResponse(BaseModel):
    use_case_id: int
    project_type: str
    generated_content: Dict[str, Any]
    total_sprints: int
    estimated_duration: str
    estimated_cost: str
    generated_at: datetime

class PDFGenerationRequest(BaseModel):
    content: Dict[str, Any]
    title: str = Field(default="Sprint Planning Document")
    include_charts: bool = Field(default=True, description="Include charts and visualizations")

# Sprint Planning Content Generator
class SprintPlanningGenerator:
    def __init__(self, groq_api_key: str):
        """Initialize the sprint planning generator with Groq API key."""
        self.groq_client = Groq(api_key=groq_api_key)
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom styles for the PDF document."""
        # Title style
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Title'],
            fontSize=24,
            spaceAfter=30,
            alignment=TA_CENTER,
            textColor=HexColor('#1f4e79')
        )
        
        # Section header style
        self.section_style = ParagraphStyle(
            'SectionHeader',
            parent=self.styles['Heading1'],
            fontSize=16,
            spaceAfter=12,
            spaceBefore=20,
            textColor=HexColor('#2c5282'),
            borderWidth=1,
            borderColor=HexColor('#2c5282'),
            borderPadding=5
        )
        
        # Subsection style
        self.subsection_style = ParagraphStyle(
            'SubsectionHeader',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=10,
            spaceBefore=15,
            textColor=HexColor('#4a5568')
        )
        
        # Body text style
        self.body_style = ParagraphStyle(
            'CustomBody',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=6,
            alignment=TA_JUSTIFY,
            leftIndent=0,
            rightIndent=0
        )
        
        # Bullet point style
        self.bullet_style = ParagraphStyle(
            'BulletPoint',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=4,
            leftIndent=20,
            bulletIndent=10
        )
        
        # Table cell style
        self.table_cell_style = ParagraphStyle(
            'TableCell',
            parent=self.styles['Normal'],
            fontSize=9,
            spaceAfter=2,
            alignment=TA_LEFT,
            leftIndent=2,
            rightIndent=2
        )
        
        # Table header style
        self.table_header_style = ParagraphStyle(
            'TableHeader',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceAfter=2,
            alignment=TA_LEFT,
            leftIndent=2,
            rightIndent=2,
            textColor=white
        )

    def _create_table_cell(self, text: str, is_header: bool = False) -> Paragraph:
        """Create a properly formatted table cell with text wrapping."""
        if is_header:
            return Paragraph(str(text), self.table_header_style)
        else:
            return Paragraph(str(text), self.table_cell_style)

    async def generate_sprint_content(self, use_case_data: Dict[str, Any], project_type: str = "web application") -> Dict[str, Any]:
        """Generate comprehensive sprint planning content using Groq LLM."""
        
        # Format use case data for the prompt
        use_case_description = json.dumps(use_case_data, indent=2)
        
        prompt = f"""
        You are a senior project manager and technical architect. Generate a comprehensive sprint planning document for the following project:

        Project Description: {use_case_description}
        Project Type: {project_type}

        Please provide a detailed response in the following JSON format:

        {{
            "project_overview": {{
                "title": "Project Title",
                "description": "Detailed project description",
                "objectives": ["objective1", "objective2", "objective3"],
                "scope": "Project scope description",
                "success_criteria": ["criteria1", "criteria2", "criteria3"]
            }},
            "technical_requirements": {{
                "technology_stack": ["tech1", "tech2", "tech3"],
                "architecture_pattern": "Architecture pattern description",
                "database_requirements": "Database requirements",
                "security_requirements": ["security1", "security2", "security3"]
            }},
            "aws_services": {{
                "compute": ["EC2", "Lambda", "ECS"],
                "storage": ["S3", "RDS", "DynamoDB"],
                "networking": ["VPC", "CloudFront", "API Gateway"],
                "security": ["IAM", "Cognito", "WAF"],
                "monitoring": ["CloudWatch", "X-Ray", "CloudTrail"],
                "estimated_monthly_cost": "$500-800"
            }},
            "team_structure": {{
                "total_developers": 4,
                "roles": [
                    {{"role": "Full-Stack Developer", "count": 2, "responsibilities": ["Frontend", "Backend", "API Development"]}},
                    {{"role": "DevOps Engineer", "count": 1, "responsibilities": ["Infrastructure", "CI/CD", "Monitoring"]}},
                    {{"role": "QA Engineer", "count": 1, "responsibilities": ["Testing", "Quality Assurance", "Bug Reporting"]}}
                ]
            }},
            "sprint_plan": {{
                "duration": "8 weeks",
                "total_sprints": 4,
                "sprints": [
                    {{
                        "sprint_number": 1,
                        "duration": "2 weeks",
                        "goals": ["Setup environment", "Basic authentication", "Database schema"],
                        "tasks": [
                            {{"task": "Project setup and repository creation", "effort": "8 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "AWS infrastructure setup", "effort": "16 hours", "assignee": "DevOps Engineer"}},
                            {{"task": "Database design and setup", "effort": "12 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "Basic authentication implementation", "effort": "20 hours", "assignee": "Full-Stack Developer"}}
                        ],
                        "deliverables": ["Environment setup", "Authentication system", "Database schema"]
                    }},
                    {{
                        "sprint_number": 2,
                        "duration": "2 weeks",
                        "goals": ["Core functionality", "API development", "Frontend foundation"],
                        "tasks": [
                            {{"task": "Core API development", "effort": "24 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "Frontend framework setup", "effort": "12 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "User interface design", "effort": "16 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "Testing framework setup", "effort": "8 hours", "assignee": "QA Engineer"}}
                        ],
                        "deliverables": ["Core APIs", "Frontend foundation", "Testing framework"]
                    }},
                    {{
                        "sprint_number": 3,
                        "duration": "2 weeks",
                        "goals": ["Feature completion", "Integration testing", "Performance optimization"],
                        "tasks": [
                            {{"task": "Feature implementation", "effort": "28 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "Integration testing", "effort": "16 hours", "assignee": "QA Engineer"}},
                            {{"task": "Performance optimization", "effort": "12 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "Security implementation", "effort": "16 hours", "assignee": "DevOps Engineer"}}
                        ],
                        "deliverables": ["Complete features", "Integration tests", "Performance optimization"]
                    }},
                    {{
                        "sprint_number": 4,
                        "duration": "2 weeks",
                        "goals": ["Final testing", "Deployment", "Documentation"],
                        "tasks": [
                            {{"task": "End-to-end testing", "effort": "20 hours", "assignee": "QA Engineer"}},
                            {{"task": "Production deployment", "effort": "16 hours", "assignee": "DevOps Engineer"}},
                            {{"task": "Documentation completion", "effort": "12 hours", "assignee": "Full-Stack Developer"}},
                            {{"task": "User training materials", "effort": "8 hours", "assignee": "Full-Stack Developer"}}
                        ],
                        "deliverables": ["Production deployment", "Complete documentation", "Training materials"]
                    }}
                ]
            }},
            "risks_and_mitigation": [
                {{"risk": "Technical complexity", "impact": "High", "mitigation": "Regular code reviews and technical spikes"}},
                {{"risk": "Resource availability", "impact": "Medium", "mitigation": "Cross-training and knowledge sharing"}},
                {{"risk": "Integration challenges", "impact": "Medium", "mitigation": "Early integration testing and API contracts"}}
            ],
            "budget_estimation": {{
                "development_cost": "$32,000-40,000",
                "aws_infrastructure": "$500-800/month",
                "third_party_services": "$200-400/month",
                "total_poc_cost": "$35,000-45,000"
            }}
        }}

        Generate realistic and detailed content for each section based on the project description provided.
        """
        
        try:
            response = self.groq_client.chat.completions.create(
                model="llama3-70b-8192",
                messages=[
                    {"role": "system", "content": "You are a senior project manager and technical architect with extensive experience in software development and AWS cloud infrastructure."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=4000
            )
            
            content = response.choices[0].message.content
            
            # Clean up the response to extract JSON
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0].strip()
            elif "```" in content:
                content = content.split("```")[1].split("```")[0].strip()
            
            return json.loads(content)
            
        except Exception as e:
            logger.error(f"Error generating content with Groq: {e}")
            return self._get_fallback_content()

    def _get_fallback_content(self) -> Dict[str, Any]:
        """Provide fallback content in case of API failure."""
        return {
            "project_overview": {
                "title": "Sample Project",
                "description": "This is a sample project generated as fallback content.",
                "objectives": ["Implement core functionality", "Ensure scalability", "Maintain security"],
                "scope": "Development of a full-stack web application with cloud deployment",
                "success_criteria": ["Successful deployment", "Performance benchmarks met", "Security compliance achieved"]
            },
            "technical_requirements": {
                "technology_stack": ["React.js", "Node.js", "Python", "PostgreSQL"],
                "architecture_pattern": "Microservices architecture with API Gateway",
                "database_requirements": "PostgreSQL for relational data, Redis for caching",
                "security_requirements": ["JWT authentication", "HTTPS encryption", "Input validation"]
            },
            "aws_services": {
                "compute": ["EC2", "Lambda", "ECS"],
                "storage": ["S3", "RDS", "DynamoDB"],
                "networking": ["VPC", "CloudFront", "API Gateway"],
                "security": ["IAM", "Cognito", "WAF"],
                "monitoring": ["CloudWatch", "X-Ray", "CloudTrail"],
                "estimated_monthly_cost": "$500-800"
            },
            "team_structure": {
                "total_developers": 4,
                "roles": [
                    {"role": "Full-Stack Developer", "count": 2, "responsibilities": ["Frontend", "Backend", "API Development"]},
                    {"role": "DevOps Engineer", "count": 1, "responsibilities": ["Infrastructure", "CI/CD", "Monitoring"]},
                    {"role": "QA Engineer", "count": 1, "responsibilities": ["Testing", "Quality Assurance", "Bug Reporting"]}
                ]
            },
            "sprint_plan": {
                "duration": "8 weeks",
                "total_sprints": 4,
                "sprints": [
                    {
                        "sprint_number": 1,
                        "duration": "2 weeks",
                        "goals": ["Setup environment", "Basic authentication", "Database schema"],
                        "tasks": [
                            {"task": "Project setup and repository creation", "effort": "8 hours", "assignee": "Full-Stack Developer"},
                            {"task": "AWS infrastructure setup", "effort": "16 hours", "assignee": "DevOps Engineer"}
                        ],
                        "deliverables": ["Environment setup", "Authentication system"]
                    }
                ]
            },
            "risks_and_mitigation": [
                {"risk": "Technical complexity", "impact": "High", "mitigation": "Regular code reviews and technical spikes"}
            ],
            "budget_estimation": {
                "development_cost": "$32,000-40,000",
                "aws_infrastructure": "$500-800/month",
                "third_party_services": "$200-400/month",
                "total_poc_cost": "$35,000-45,000"
            }
        }

    def create_team_pie_chart(self, team_data: Dict[str, Any]) -> Drawing:
        """Create a pie chart showing team composition."""
        drawing = Drawing(200, 200)
        
        pie = Pie()
        pie.x = 50
        pie.y = 50
        pie.width = 100
        pie.height = 100
        
        # Extract team composition data
        roles = team_data.get('roles', [])
        pie.data = [role.get('count', 1) for role in roles]
        pie.labels = [role.get('role', 'Unknown') for role in roles]
        
        # Set colors
        colors_list = [HexColor('#3182ce'), HexColor('#38a169'), HexColor('#d69e2e'), HexColor('#e53e3e')]
        for i, color in enumerate(colors_list[:len(pie.data)]):
            pie.slices[i].fillColor = color
        
        drawing.add(pie)
        return drawing

    def create_sprint_timeline_chart(self, sprint_data: Dict[str, Any]) -> Drawing:
        """Create a timeline chart showing sprint progression."""
        drawing = Drawing(400, 200)
        
        # Create a simple bar chart showing sprint timeline
        chart = VerticalBarChart()
        chart.x = 50
        chart.y = 50
        chart.height = 100
        chart.width = 300
        
        # Sample data for sprints
        sprints = sprint_data.get('sprints', [])
        chart.data = [[len(sprint.get('tasks', [])) for sprint in sprints]]
        chart.categoryAxis.categoryNames = [f"Sprint {sprint.get('sprint_number', i+1)}" for i, sprint in enumerate(sprints)]
        chart.valueAxis.valueMin = 0
        chart.valueAxis.valueMax = max([len(sprint.get('tasks', [])) for sprint in sprints]) + 2 if sprints else 10
        
        chart.bars[0].fillColor = HexColor('#3182ce')
        
        drawing.add(chart)
        return drawing

    def generate_pdf_report(self, content: Dict[str, Any], filename: str = None) -> bytes:
        """Generate a comprehensive PDF report using ReportLab."""
        
        # Create PDF in memory
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
        story = []
        
        # Title
        title = content.get('project_overview', {}).get('title', 'Sprint Planning Document')
        story.append(Paragraph(title, self.title_style))
        story.append(Spacer(1, 12))
        
        # Document info
        story.append(Paragraph(f"Generated on: {datetime.now().strftime('%B %d, %Y')}", self.body_style))
        story.append(Spacer(1, 20))
        
        # Executive Summary
        story.append(Paragraph("Executive Summary", self.section_style))
        story.append(Paragraph(content.get('project_overview', {}).get('description', ''), self.body_style))
        story.append(Spacer(1, 12))
        
        # Project Overview
        story.append(Paragraph("Project Overview", self.section_style))
        
        overview = content.get('project_overview', {})
        story.append(Paragraph("Project Objectives:", self.subsection_style))
        for objective in overview.get('objectives', []):
            story.append(Paragraph(f"• {objective}", self.bullet_style))
        story.append(Spacer(1, 8))
        
        story.append(Paragraph("Success Criteria:", self.subsection_style))
        for criteria in overview.get('success_criteria', []):
            story.append(Paragraph(f"• {criteria}", self.bullet_style))
        story.append(Spacer(1, 12))
        
        # Technical Requirements
        story.append(Paragraph("Technical Requirements", self.section_style))
        
        tech_req = content.get('technical_requirements', {})
        story.append(Paragraph("Technology Stack:", self.subsection_style))
        for tech in tech_req.get('technology_stack', []):
            story.append(Paragraph(f"• {tech}", self.bullet_style))
        story.append(Spacer(1, 8))
        
        story.append(Paragraph("Architecture Pattern:", self.subsection_style))
        story.append(Paragraph(tech_req.get('architecture_pattern', ''), self.body_style))
        story.append(Spacer(1, 12))
        
        # AWS Services
        story.append(Paragraph("AWS Services Required", self.section_style))
        
        aws_services = content.get('aws_services', {})
        
        # Create AWS services table
        aws_data = [[
            self._create_table_cell('Service Category', True),
            self._create_table_cell('Services', True)
        ]]
        
        for category, services in aws_services.items():
            if isinstance(services, list):
                services_text = ', '.join(services)
                aws_data.append([
                    self._create_table_cell(category.replace('_', ' ').title()),
                    self._create_table_cell(services_text)
                ])
            elif category == 'estimated_monthly_cost':
                aws_data.append([
                    self._create_table_cell('Monthly Cost'),
                    self._create_table_cell(services)
                ])
        
        aws_table = Table(aws_data, colWidths=[2.5*inch, 3.5*inch])
        aws_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), HexColor('#3182ce')),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
            ('TOPPADDING', (0, 0), (-1, 0), 8),
            ('BACKGROUND', (0, 1), (-1, -1), HexColor('#f7fafc')),
            ('GRID', (0, 0), (-1, -1), 1, black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#f7fafc'), white])
        ]))
        
        story.append(aws_table)
        story.append(Spacer(1, 12))
        
        # Team Structure
        story.append(Paragraph("Team Structure", self.section_style))
        
        team_structure = content.get('team_structure', {})
        story.append(Paragraph(f"Total Developers Required: {team_structure.get('total_developers', 'TBD')}", self.body_style))
        story.append(Spacer(1, 8))
        
        # Team roles table
        team_data = [[
            self._create_table_cell('Role', True),
            self._create_table_cell('Count', True),
            self._create_table_cell('Key Responsibilities', True)
        ]]
        
        for role in team_structure.get('roles', []):
            responsibilities = ', '.join(role.get('responsibilities', []))
            team_data.append([
                self._create_table_cell(role.get('role', '')),
                self._create_table_cell(str(role.get('count', ''))),
                self._create_table_cell(responsibilities)
            ])
        
        team_table = Table(team_data, colWidths=[2*inch, 0.8*inch, 3.2*inch])
        team_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), HexColor('#38a169')),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BACKGROUND', (0, 1), (-1, -1), HexColor('#f0fff4')),
            ('GRID', (0, 0), (-1, -1), 1, black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#f0fff4'), white])
        ]))
        
        story.append(team_table)
        story.append(Spacer(1, 20))
        
        # Sprint Plan
        story.append(Paragraph("Sprint Plan", self.section_style))
        
        sprint_plan = content.get('sprint_plan', {})
        story.append(Paragraph(f"Total Duration: {sprint_plan.get('duration', 'TBD')}", self.body_style))
        story.append(Paragraph(f"Number of Sprints: {sprint_plan.get('total_sprints', 'TBD')}", self.body_style))
        story.append(Spacer(1, 12))
        
        # Individual sprint details
        for sprint in sprint_plan.get('sprints', []):
            story.append(Paragraph(f"Sprint {sprint.get('sprint_number', 'X')} - {sprint.get('duration', 'TBD')}", self.subsection_style))
            
            story.append(Paragraph("Goals:", self.body_style))
            for goal in sprint.get('goals', []):
                story.append(Paragraph(f"• {goal}", self.bullet_style))
            
            story.append(Paragraph("Key Tasks:", self.body_style))
            
            # Tasks table
            task_data = [[
                self._create_table_cell('Task', True),
                self._create_table_cell('Effort', True),
                self._create_table_cell('Assignee', True)
            ]]
            
            for task in sprint.get('tasks', []):
                task_data.append([
                    self._create_table_cell(task.get('task', '')),
                    self._create_table_cell(task.get('effort', '')),
                    self._create_table_cell(task.get('assignee', ''))
                ])
            
            task_table = Table(task_data, colWidths=[3.2*inch, 0.8*inch, 2*inch])
            task_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), HexColor('#d69e2e')),
                ('TEXTCOLOR', (0, 0), (-1, 0), white),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('BACKGROUND', (0, 1), (-1, -1), HexColor('#fffbf0')),
                ('GRID', (0, 0), (-1, -1), 1, black),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#fffbf0'), white])
            ]))
            
            story.append(task_table)
            story.append(Spacer(1, 8))
            
            story.append(Paragraph("Deliverables:", self.body_style))
            for deliverable in sprint.get('deliverables', []):
                story.append(Paragraph(f"• {deliverable}", self.bullet_style))
            
            story.append(Spacer(1, 12))
        
        # Risks and Mitigation
        story.append(Paragraph("Risks and Mitigation", self.section_style))
        
        risk_data = [[
            self._create_table_cell('Risk', True),
            self._create_table_cell('Impact', True),
            self._create_table_cell('Mitigation Strategy', True)
        ]]
        
        for risk in content.get('risks_and_mitigation', []):
            risk_data.append([
                self._create_table_cell(risk.get('risk', '')),
                self._create_table_cell(risk.get('impact', '')),
                self._create_table_cell(risk.get('mitigation', ''))
            ])
        
        risk_table = Table(risk_data, colWidths=[2*inch, 1*inch, 3*inch])
        risk_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), HexColor('#e53e3e')),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BACKGROUND', (0, 1), (-1, -1), HexColor('#fed7d7')),
            ('GRID', (0, 0), (-1, -1), 1, black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#fed7d7'), white])
        ]))
        
        story.append(risk_table)
        story.append(Spacer(1, 20))
        
        # Budget Estimation
        story.append(Paragraph("Budget Estimation", self.section_style))
        
        budget = content.get('budget_estimation', {})
        budget_data = [[
            self._create_table_cell('Cost Component', True),
            self._create_table_cell('Estimated Cost', True)
        ]]
        
        for component, cost in budget.items():
            budget_data.append([
                self._create_table_cell(component.replace('_', ' ').title()),
                self._create_table_cell(cost)
            ])
        
        budget_table = Table(budget_data, colWidths=[3*inch, 2*inch])
        budget_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), HexColor('#38a169')),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BACKGROUND', (0, 1), (-1, -1), HexColor('#f0fff4')),
            ('GRID', (0, 0), (-1, -1), 1, black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#f0fff4'), white])
        ]))
        
        story.append(budget_table)
        story.append(Spacer(1, 12))
        
        # Build PDF
        doc.build(story)
        
        # Get PDF data
        buffer.seek(0)
        pdf_data = buffer.getvalue()
        buffer.close()
        
        return pdf_data

# Router
router = APIRouter(prefix="/sprint-planning", tags=["Sprint Planning"])

# Get API key from environment
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    print("Warning: GROQ_API_KEY not found in environment variables")

@router.post("/generate", response_model=SprintPlanningResponse)
async def generate_sprint_plan(
    use_case_id: int = Form(...),
    project_type: str = Form(default="web application"),
    sprint_duration: str = Form(default="2 weeks"),
    total_sprints: int = Form(default=4),
    team_size: int = Form(default=4),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Generate sprint planning document from use case
    
    This endpoint:
    1. Retrieves use case information from the database
    2. Generates comprehensive sprint planning using AI
    3. Returns structured sprint planning data
    """
    
    try:
        # Verify user has access to the use case
        use_case = db.query(GeneratedUseCase).filter(
            GeneratedUseCase.id == use_case_id
        ).first()
        
        if not use_case:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Use case not found"
            )
        
        # Get the pre-workshop session to verify user access
        session = db.query(PreWorkshopSession).filter(
            PreWorkshopSession.id == use_case.session_id
        ).first()
        
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Session not found"
            )

        # Verify project ownership through the project relationship
        project = db.query(Project).filter(
            Project.id == session.project_id,
            Project.owner_id == current_user.id,
            Project.is_active == True
        ).first()

        if not project:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this use case"
            )
        
        # Prepare use case data for sprint planning
        use_case_data = {
            'title': use_case.title,
            'description': use_case.description,
            'business_category': use_case.business_category,
            'primary_genai_capability': use_case.primary_genai_capability,
            'aws_services': use_case.aws_services,
            'complexity': use_case.complexity,
            'estimated_effort': use_case.estimated_effort,
            'success_metrics': use_case.success_metrics,
            'dependencies': use_case.dependencies,
            'risks': use_case.risks,
            'cost_estimate': use_case.cost_estimate,
            'roi_potential': use_case.roi_potential
        }
        
        # Generate sprint planning content
        generator = SprintPlanningGenerator(GROQ_API_KEY)
        sprint_content = await generator.generate_sprint_content(use_case_data, project_type)
        
        # Extract key information for response
        sprint_plan = sprint_content.get('sprint_plan', {})
        budget = sprint_content.get('budget_estimation', {})
        
        return SprintPlanningResponse(
            use_case_id=use_case_id,
            project_type=project_type,
            generated_content=sprint_content,
            total_sprints=sprint_plan.get('total_sprints', total_sprints),
            estimated_duration=sprint_plan.get('duration', f"{total_sprints * 2} weeks"),
            estimated_cost=budget.get('total_poc_cost', 'TBD'),
            generated_at=datetime.now()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating sprint plan: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generating sprint plan: {str(e)}"
        )

@router.post("/generate-pdf")
async def generate_sprint_pdf(
    content: str = Form(...),
    title: str = Form(default="Sprint Planning Document"),
    include_charts: bool = Form(default=True),
    current_user: User = Depends(get_current_user)
):
    """
    Generate PDF report from sprint planning content
    
    This endpoint:
    1. Takes JSON-formatted sprint planning content
    2. Generates a beautifully formatted PDF report
    3. Returns the PDF as a downloadable file
    """
    
    try:
        # Parse the content JSON
        try:
            sprint_content = json.loads(content)
        except json.JSONDecodeError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid JSON content provided"
            )
        
        # Generate PDF
        generator = SprintPlanningGenerator(GROQ_API_KEY)
        pdf_data = generator.generate_pdf_report(sprint_content)
        
        # Generate filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"sprint_planning_{timestamp}.pdf"
        
        # Return PDF as response
        return Response(
            content=pdf_data,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "Content-Length": str(len(pdf_data))
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating PDF: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generating PDF: {str(e)}"
        )

@router.get("/templates")
async def get_sprint_templates(
    current_user: User = Depends(get_current_user)
):
    """
    Get available sprint planning templates
    
    This endpoint returns predefined templates for different project types.
    """
    
    templates = {
        "web_application": {
            "name": "Web Application",
            "description": "Full-stack web application development",
            "default_sprints": 4,
            "default_duration": "2 weeks",
            "typical_team_size": 4,
            "key_technologies": ["React", "Node.js", "AWS", "Database"]
        },
        "mobile_app": {
            "name": "Mobile Application",
            "description": "Native or cross-platform mobile app development",
            "default_sprints": 6,
            "default_duration": "2 weeks",
            "typical_team_size": 5,
            "key_technologies": ["React Native", "Flutter", "iOS", "Android"]
        },
        "data_platform": {
            "name": "Data Platform",
            "description": "Big data processing and analytics platform",
            "default_sprints": 8,
            "default_duration": "2 weeks",
            "typical_team_size": 6,
            "key_technologies": ["AWS EMR", "Spark", "Kafka", "ML Services"]
        },
        "ai_ml_solution": {
            "name": "AI/ML Solution",
            "description": "Machine learning and AI-powered application",
            "default_sprints": 6,
            "default_duration": "2 weeks",
            "typical_team_size": 4,
            "key_technologies": ["SageMaker", "Lambda", "API Gateway", "S3"]
        },
        "microservices": {
            "name": "Microservices Architecture",
            "description": "Microservices-based distributed system",
            "default_sprints": 10,
            "default_duration": "2 weeks",
            "typical_team_size": 8,
            "key_technologies": ["Docker", "Kubernetes", "API Gateway", "Service Mesh"]
        }
    }
    
    return {
        "templates": templates,
        "total_templates": len(templates)
    }