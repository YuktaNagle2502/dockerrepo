from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Response
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List, Dict, Any
import json
import os
import uuid
from pathlib import Path
import pandas as pd
import asyncio
from groq import Groq
import time
import tempfile
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
import io
import openpyxl
from openpyxl import load_workbook

# Import database configuration and auth dependencies
from database import Base, get_db
from login_project import get_current_user, User, Project

# Database Models
class PreWorkshopSession(Base):
    __tablename__ = "pre_workshop_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    session_name = Column(String, nullable=False)
    description = Column(Text)
    status = Column(String, default="draft")  # draft, questionnaire_uploaded, use_cases_generated, completed
    excel_file_path = Column(String)  # Path to uploaded Excel file
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    project = relationship("Project")
    questionnaire_responses = relationship("QuestionnaireResponse", back_populates="session")
    generated_use_cases = relationship("GeneratedUseCase", back_populates="session")

class QuestionnaireResponse(Base):
    __tablename__ = "questionnaire_responses"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("pre_workshop_sessions.id"), nullable=False)
    category = Column(String)  # e.g., "Business Context and Use Case Definition"
    question = Column(Text, nullable=False)
    description = Column(Text)  # Question description
    response = Column(Text, nullable=False)
    additional_notes = Column(Text)  # Additional notes from Excel
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    session = relationship("PreWorkshopSession", back_populates="questionnaire_responses")

class GeneratedUseCase(Base):
    __tablename__ = "generated_use_cases"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("pre_workshop_sessions.id"), nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    aws_services = Column(JSON)  # List of AWS services
    primary_genai_capability = Column(String)
    business_category = Column(String)
    customer_pain_points = Column(JSON)  # List of pain points
    priority = Column(String)  # High/Medium/Low
    complexity = Column(String)  # High/Medium/Low
    estimated_effort = Column(String)
    success_metrics = Column(JSON)  # List of metrics
    aws_architecture = Column(Text)
    cost_estimate = Column(String)
    dependencies = Column(JSON)  # List of dependencies
    risks = Column(JSON)  # List of risks
    roi_potential = Column(String)  # High/Medium/Low
    implementation_phases = Column(JSON)  # List of phases
    is_selected = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    justification = Column(Text, nullable=True)  # Justification for use case selection
    
    # Relationships
    session = relationship("PreWorkshopSession", back_populates="generated_use_cases")

# Pydantic Models
class PreWorkshopSessionCreate(BaseModel):
    project_id: int
    session_name: str
    description: Optional[str] = None

class PreWorkshopSessionResponse(BaseModel):
    id: int
    project_id: int
    session_name: str
    description: Optional[str]
    status: str
    excel_file_path: Optional[str]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class QuestionnaireResponseResponse(BaseModel):
    id: int
    session_id: int
    category: Optional[str]
    question: str
    description: Optional[str]
    response: str
    additional_notes: Optional[str]
    created_at: datetime
    
    class Config:
        from_attributes = True

class GeneratedUseCaseResponse(BaseModel):
    id: int
    session_id: int
    title: str
    description: str
    aws_services: List[str]
    primary_genai_capability: str
    business_category: str
    customer_pain_points: List[str]
    priority: str
    complexity: str
    estimated_effort: str
    success_metrics: List[str]
    aws_architecture: str
    cost_estimate: str
    dependencies: List[str]
    risks: List[str]
    roi_potential: str
    implementation_phases: List[str]
    is_selected: bool
    created_at: datetime
    justification:str
    
    class Config:
        from_attributes = True

class PreWorkshopSessionDetail(PreWorkshopSessionResponse):
    questionnaire_responses: List[QuestionnaireResponseResponse]
    generated_use_cases: List[GeneratedUseCaseResponse]

class ReportRequest(BaseModel):
    session_id: int
    report_type: str = "pdf"  # pdf, json
    include_sections: List[str] = ["questionnaire", "use_cases", "recommendations"]

class ExcelUploadResponse(BaseModel):
    message: str
    total_responses: int
    session_status: str
    responses_preview: List[Dict[str, Any]]

# Excel Processing Functions
def process_excel_questionnaire(file_path: str) -> List[Dict[str, Any]]:
    """
    Process Excel file and extract questionnaire responses from Sheet1
    Expected format:
    Column A: Category
    Column B: Question
    Column C: Description
    Column D: Customer_responses
    Column E: Additional Notes / Links
    """
    try:
        # Load workbook
        workbook = load_workbook(file_path, read_only=True)
        
        # Check if Sheet1 exists
        if "1.  Use Case Discovery" not in workbook.sheetnames:
            raise ValueError("Sheet1 not found in Excel file")
        
        sheet = workbook["1.  Use Case Discovery"]
        responses = []
        
        # Skip header row, start from row 2
        for row in sheet.iter_rows(min_row=2, values_only=True):
            if not row or all(cell is None for cell in row):
                continue
                
            category = row[0] if len(row) > 0 else None
            question = row[1] if len(row) > 1 else None
            description = row[2] if len(row) > 2 else None
            customer_response = row[3] if len(row) > 3 else None
            additional_notes = row[4] if len(row) > 4 else None
            
            # Skip rows without question or response
            if not question or not customer_response:
                continue
                
            # Clean up text data
            question = str(question).strip() if question else ""
            customer_response = str(customer_response).strip() if customer_response else ""
            
            # Skip empty responses
            if not customer_response or customer_response.lower() in ['', 'null', 'none']:
                continue
            
            responses.append({
                "category": str(category).strip() if category else None,
                "question": question,
                "description": str(description).strip() if description else None,
                "response": customer_response,
                "additional_notes": str(additional_notes).strip() if additional_notes else None
            })
        
        workbook.close()
        return responses
        
    except Exception as e:
        raise ValueError(f"Error processing Excel file: {str(e)}")

async def save_uploaded_file(upload_file: UploadFile, session_id: int) -> str:
    """Save uploaded file to disk and return file path"""
    
    # Create uploads directory if it doesn't exist
    uploads_dir = Path("uploads/pre_workshop")
    uploads_dir.mkdir(parents=True, exist_ok=True)
    
    # Generate unique filename
    file_extension = Path(upload_file.filename).suffix
    unique_filename = f"session_{session_id}_{uuid.uuid4()}{file_extension}"
    file_path = uploads_dir / unique_filename
    
    try:
        # Save file
        content = await upload_file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        # print("Uploaded content for questionainer :",content)
        return str(file_path)
    
    except Exception as e:
        # Clean up if there was an error
        if file_path.exists():
            file_path.unlink()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving file: {str(e)}"
        )

# GenAI Use Cases Generator (from existing code)
class GenAIUseCasesGenerator:
    """Generate GenAI use cases from customer responses"""
    
    def __init__(self, api_key: str, model: str = "llama-3.3-70b-versatile"):
        self.client = Groq(api_key=api_key)
        self.model = model
    
    async def generate_aws_genai_use_cases(self, customer_responses: List[str]) -> List[Dict]:
        """Generate AWS-based GenAI use cases from customer responses"""
        
        # Combine all customer responses
        combined_responses = "\n".join([f"- {response}" for response in customer_responses])
        
        system_prompt = """
        You are an expert AWS GenAI solutions architect specialized in identifying practical GenAI use cases for business problems.
        Your task is to analyze customer responses and generate specific, actionable AWS GenAI use cases that can be proposed to clients.
        
        Focus on AWS GenAI services like:
        - Amazon Bedrock (Claude, Titan, Jurassic models)
        - Amazon SageMaker (Custom ML models)
        - Amazon Comprehend (NLP)
        - Amazon Textract (Document analysis)
        - Amazon Transcribe (Speech-to-text)
        - Amazon Polly (Text-to-speech)
        - Amazon Rekognition (Image/Video analysis)
        - Amazon Lex (Conversational AI)
        - Amazon Kendra (Intelligent search)
        - Amazon CodeWhisperer (Code generation)
        - Amazon Personalize (Recommendations)
        
        IMPORTANT: Always respond with ONLY valid JSON format containing an array of use cases.
        Do not include any explanatory text, just the JSON array.
        """
        
        user_request = f"""
        Customer Responses Analysis:
        {combined_responses}
        
        Based on these customer responses, generate 10-15 specific AWS GenAI use cases that could address their requirements. For each use case, provide:
        
        Return ONLY this JSON structure with NO additional text:
        [
          {{
            "title": "Specific AWS GenAI Use Case Title",
            "description": "Detailed description of how AWS GenAI solves the customer problem",
            "aws_services": ["Amazon Bedrock", "Amazon SageMaker", "etc"],
            "primary_genai_capability": "Primary GenAI technology (e.g., LLM, NLP, Computer Vision)",
            "business_category": "Business category (e.g., Customer Service, Operations, Analytics)",
            "customer_pain_points": ["pain point 1", "pain point 2"],
            "priority": "High/Medium/Low",
            "complexity": "High/Medium/Low",
            "estimated_effort": "X weeks/months",
            "success_metrics": ["metric1", "metric2", "metric3"],
            "aws_architecture": "High-level AWS architecture description",
            "cost_estimate": "Estimated monthly AWS cost range",
            "dependencies": ["dependency1", "dependency2"],
            "risks": ["risk1", "risk2"],
            "roi_potential": "High/Medium/Low",
            "implementation_phases": ["phase1", "phase2", "phase3"]
            "Justification":"Justification how this usecase will solve the customer problem, How the ROI is calculated and what is the impact of
            this usecase for the particular customer needs",
          }}
        ]
        """
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_request}
                ],
                temperature=0.7,
                max_tokens=4000
            )
            
            ai_response = response.choices[0].message.content.strip()
            
            # Try to parse as JSON to validate
            try:
                parsed_json = json.loads(ai_response)
                return parsed_json
            
            except json.JSONDecodeError:
                # Try to extract JSON from response if wrapped in text
                import re
                json_match = re.search(r'\[.*\]', ai_response, re.DOTALL)
                if json_match:
                    try:
                        parsed_json = json.loads(json_match.group())
                        return parsed_json
                        return parsed_json
                    except:
                        pass
                
                # Fallback: return error message
                return [{
                    "title": "Error in AI Response",
                    "description": "Could not parse AI response into valid JSON",
                    "aws_services": ["N/A"],
                    "primary_genai_capability": "N/A",
                    "business_category": "Error",
                    "customer_pain_points": ["Invalid AI response"],
                    "priority": "High",
                    "complexity": "High",
                    "estimated_effort": "N/A",
                    "success_metrics": ["Fix AI response parsing"],
                    "aws_architecture": "N/A",
                    "cost_estimate": "N/A",
                    "dependencies": ["Valid AI response"],
                    "risks": ["Invalid JSON format"],
                    "roi_potential": "Low",
                    "implementation_phases": ["Debug response format"]
                }]
                
        except Exception as e:
            return [{
                "title": "API Error",
                "description": f"Error calling Groq API: {str(e)}",
                "aws_services": ["N/A"],
                "primary_genai_capability": "N/A",
                "business_category": "Error",
                "customer_pain_points": ["API connection failed"],
                "priority": "High",
                "complexity": "High",
                "estimated_effort": "N/A",
                "success_metrics": ["Fix API connection"],
                "aws_architecture": "N/A",
                "cost_estimate": "N/A",
                "dependencies": ["Valid API key"],
                "risks": ["API unavailable"],
                "roi_potential": "Low",
                "implementation_phases": ["Establish API connection"]
            }]

# Report Generation Functions
def generate_pdf_report(session_data: Dict, questionnaire_responses: List[Dict], use_cases: List[Dict]) -> bytes:
    """Generate PDF report for pre-workshop session"""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
    
    # Get styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=20,
        spaceAfter=30,
        alignment=TA_CENTER
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        spaceAfter=12,
        spaceBefore=20
    )
    
    # Build content
    content = []
    
    # Title
    content.append(Paragraph("Pre-Workshop Assessment Report", title_style))
    content.append(Spacer(1, 20))
    
    # Session Information
    content.append(Paragraph("Session Information", heading_style))
    session_info = [
        ["Session Name:", session_data['session_name']],
        ["Description:", session_data.get('description', 'N/A')],
        ["Status:", session_data['status']],
        ["Created:", session_data['created_at']],
        ["Updated:", session_data['updated_at']]
    ]
    
    session_table = Table(session_info, colWidths=[2*inch, 4*inch])
    session_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.grey),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('BACKGROUND', (1, 0), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    content.append(session_table)
    content.append(Spacer(1, 20))
    
    # Questionnaire Responses
    content.append(Paragraph("Questionnaire Responses", heading_style))
    
    # Group responses by category
    categories = {}
    for response in questionnaire_responses:
        category = response.get('category', 'General')
        if category not in categories:
            categories[category] = []
        categories[category].append(response)
    
    for category, responses in categories.items():
        if category and category != 'None':
            content.append(Paragraph(f"<b>{category}</b>", heading_style))
        
        for i, response in enumerate(responses, 1):
            content.append(Paragraph(f"<b>Q{i}: {response['question']}</b>", styles['Normal']))
            if response.get('description'):
                content.append(Paragraph(f"<i>{response['description']}</i>", styles['Normal']))
            content.append(Paragraph(f"<b>Answer:</b> {response['response']}", styles['Normal']))
            if response.get('additional_notes'):
                content.append(Paragraph(f"<i>Notes: {response['additional_notes']}</i>", styles['Normal']))
            content.append(Spacer(1, 10))
    
    content.append(PageBreak())
    
    # Generated Use Cases
    content.append(Paragraph("Generated AWS GenAI Use Cases", heading_style))
    
    for i, use_case in enumerate(use_cases, 1):
        content.append(Paragraph(f"<b>Use Case {i}: {use_case['title']}</b>", heading_style))
        content.append(Paragraph(f"<b>Description:</b> {use_case['description']}", styles['Normal']))
        content.append(Spacer(1, 8))
        
        # Use case details table
        use_case_details = [
            ["AWS Services:", ", ".join(use_case.get('aws_services', []))],
            ["Primary GenAI Capability:", use_case.get('primary_genai_capability', 'N/A')],
            ["Business Category:", use_case.get('business_category', 'N/A')],
            ["Priority:", use_case.get('priority', 'N/A')],
            ["Complexity:", use_case.get('complexity', 'N/A')],
            ["Estimated Effort:", use_case.get('estimated_effort', 'N/A')],
            ["Cost Estimate:", use_case.get('cost_estimate', 'N/A')],
            ["ROI Potential:", use_case.get('roi_potential', 'N/A')]
        ]
        
        details_table = Table(use_case_details, colWidths=[2*inch, 4*inch])
        details_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        content.append(details_table)
        content.append(Spacer(1, 15))
    
    # Build PDF
    doc.build(content)
    buffer.seek(0)
    return buffer.read()

# Router
router = APIRouter(prefix="/pre-workshop", tags=["Pre-Workshop"])

# Get AI API key from environment
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
if not GROQ_API_KEY:
    print("Warning: GROQ_API_KEY not found in environment variables")

# API Endpoints

@router.post("/sessions", response_model=PreWorkshopSessionResponse)
def create_pre_workshop_session(
    session_data: PreWorkshopSessionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new pre-workshop session"""
    
    # Verify project ownership
    project = db.query(Project).filter(
        Project.id == session_data.project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project not found or access denied"
        )
    
    # Create session
    db_session = PreWorkshopSession(
        project_id=session_data.project_id,
        session_name=session_data.session_name,
        description=session_data.description
    )
    db.add(db_session)
    db.commit()
    db.refresh(db_session)
    
    return db_session

@router.get("/sessions", response_model=List[PreWorkshopSessionResponse])
def get_pre_workshop_sessions(
    project_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all pre-workshop sessions for a project"""
    
    # Verify project ownership
    project = db.query(Project).filter(
        Project.id == project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Project not found or access denied"
        )
    
    sessions = db.query(PreWorkshopSession).filter(
        PreWorkshopSession.project_id == project_id
    ).all()
    
    return sessions

@router.get("/sessions/{session_id}", response_model=PreWorkshopSessionDetail)
def get_pre_workshop_session(
    session_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get detailed pre-workshop session with responses and use cases"""
    
    session = db.query(PreWorkshopSession).filter(
        PreWorkshopSession.id == session_id
    ).first()
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    # Verify project ownership
    project = db.query(Project).filter(
        Project.id == session.project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Access denied"
        )
    
    return session

@router.post("/sessions/{session_id}/upload-questionnaire", response_model=ExcelUploadResponse)
async def upload_questionnaire_excel(
    session_id: int,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Upload Excel file with questionnaire responses (Sheet1)"""
    
    # Verify session access
    session = db.query(PreWorkshopSession).filter(
        PreWorkshopSession.id == session_id
    ).first()
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    # Verify project ownership
    project = db.query(Project).filter(
        Project.id == session.project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Access denied"
        )
    
    # Validate file type
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid file type. Please upload an Excel file (.xlsx or .xls)"
        )
    
    # Save uploaded file
    try:
        file_path = await save_uploaded_file(file, session_id)
        
        # Process Excel file
        questionnaire_responses = process_excel_questionnaire(file_path)
        
        if not questionnaire_responses:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No valid questionnaire responses found in Sheet1"
            )
        
        # Clear existing responses for this session
        db.query(QuestionnaireResponse).filter(
            QuestionnaireResponse.session_id == session_id
        ).delete()
        
        # Save questionnaire responses to database
        saved_responses = []
        for response_data in questionnaire_responses:
            db_response = QuestionnaireResponse(
                session_id=session_id,
                category=response_data['category'],
                question=response_data['question'],
                description=response_data['description'],
                response=response_data['response'],
                additional_notes=response_data['additional_notes']
            )
            db.add(db_response)
            saved_responses.append(db_response)
        
        # Update session with file path and status
        session.excel_file_path = file_path
        session.status = "questionnaire_uploaded"
        session.updated_at = datetime.utcnow()
        
        db.commit()
        
        # Create response preview
        responses_preview = [
            {
                "category": resp['category'],
                "question": resp['question'][:100] + "..." if len(resp['question']) > 100 else resp['question'],
                "response": resp['response'][:200] + "..." if len(resp['response']) > 200 else resp['response']
            }
            for resp in questionnaire_responses[:5]  # Show first 5 responses
        ]
        
        return ExcelUploadResponse(
            message="Questionnaire responses uploaded successfully",
            total_responses=len(questionnaire_responses),
            session_status="questionnaire_uploaded",
            responses_preview=responses_preview
        )
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing Excel file: {str(e)}"
        )

@router.post("/sessions/{session_id}/generate-use-cases")
async def generate_use_cases(
    session_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Generate AWS GenAI use cases from uploaded questionnaire responses"""
    
    if not GROQ_API_KEY:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="AI service not configured"
        )
    
    # Verify session access
    session = db.query(PreWorkshopSession).filter(
        PreWorkshopSession.id == session_id
    ).first()
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    # Verify project ownership
    project = db.query(Project).filter(
        Project.id == session.project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Access denied"
        )
    
    # Get questionnaire responses
    responses = db.query(QuestionnaireResponse).filter(
        QuestionnaireResponse.session_id == session_id
    ).all()
    
    if not responses:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No questionnaire responses found. Please upload Excel file first."
        )
    
    # Extract response texts
    response_texts = [resp.response for resp in responses]
    
    # Generate use cases using AI
    try:
        generator = GenAIUseCasesGenerator(GROQ_API_KEY)
        use_cases_data = await generator.generate_aws_genai_use_cases(response_texts)
        
        # Clear existing use cases for this session
        db.query(GeneratedUseCase).filter(
            GeneratedUseCase.session_id == session_id
        ).delete()
        
        for use_case in use_cases_data:
            db_use_case = GeneratedUseCase(
                session_id=session_id,
                title=use_case.get('title', 'Unknown'),
                description=use_case.get('description', ''),
                aws_services=use_case.get('aws_services', []),
                primary_genai_capability=use_case.get('primary_genai_capability', ''),
                business_category=use_case.get('business_category', ''),
                customer_pain_points=use_case.get('customer_pain_points', []),
                priority=use_case.get('priority', 'Medium'),
                complexity=use_case.get('complexity', 'Medium'),
                estimated_effort=use_case.get('estimated_effort', ''),
                success_metrics=use_case.get('success_metrics', []),
                aws_architecture=use_case.get('aws_architecture', ''),
                cost_estimate=use_case.get('cost_estimate', ''),
                dependencies=use_case.get('dependencies', []),
                risks=use_case.get('risks', []),
                roi_potential=use_case.get('roi_potential', 'Medium'),
                implementation_phases=use_case.get('implementation_phases', []),
                justification=use_case.get('Justification', 'No justification provided')
            )
            db.add(db_use_case)
            print(f"Generated Use Case: {db_use_case.title} - {db_use_case.description[:50]}...") 
        
        # Update session status
        session.status = "use_cases_generated"
        session.updated_at = datetime.utcnow()
        
        db.commit()
        
        return {
            "message": "Use cases generated successfully",
            "total_use_cases": len(use_cases_data),
            "session_status": "use_cases_generated",
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generating use cases: {str(e)}"
        )

@router.post("/sessions/{session_id}/generate-report")
async def generate_report(
    session_id: int,
    report_request: ReportRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Generate and download pre-workshop report"""
    
    # Verify session access
    session = db.query(PreWorkshopSession).filter(
        PreWorkshopSession.id == session_id
    ).first()
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    # Verify project ownership
    project = db.query(Project).filter(
        Project.id == session.project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Access denied"
        )
    
    # Get session data
    questionnaire_responses = db.query(QuestionnaireResponse).filter(
        QuestionnaireResponse.session_id == session_id
    ).all()
    
    use_cases = db.query(GeneratedUseCase).filter(
        GeneratedUseCase.session_id == session_id
    ).all()
    
    if report_request.report_type == "pdf":
        # Generate PDF report
        session_data = {
            "session_name": session.session_name,
            "description": session.description,
            "status": session.status,
            "created_at": session.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            "updated_at": session.updated_at.strftime("%Y-%m-%d %H:%M:%S")
        }
        
        questionnaire_data = [
            {
                "category": resp.category,
                "question": resp.question,
                "description": resp.description,
                "response": resp.response,
                "additional_notes": resp.additional_notes
            }
            for resp in questionnaire_responses
        ]
        
        use_cases_data = [
            {
                "title": uc.title,
                "description": uc.description,
                "aws_services": uc.aws_services,
                "primary_genai_capability": uc.primary_genai_capability,
                "business_category": uc.business_category,
                "priority": uc.priority,
                "complexity": uc.complexity,
                "estimated_effort": uc.estimated_effort,
                "cost_estimate": uc.cost_estimate,
                "roi_potential": uc.roi_potential
            }
            for uc in use_cases
        ]
        
        try:
            pdf_content = generate_pdf_report(session_data, questionnaire_data, use_cases_data)
            
            # Update session status
            session.status = "completed"
            session.updated_at = datetime.utcnow()
            db.commit()
            
            # Return PDF as response
            return Response(
                content=pdf_content,
                media_type="application/pdf",
                headers={
                    "Content-Disposition": f"attachment; filename=pre_workshop_report_{session_id}.pdf"
                }
            )
            
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error generating PDF report: {str(e)}"
            )
    
    elif report_request.report_type == "json":
        # Return JSON report
        report_data = {
            "session_info": {
                "id": session.id,
                "session_name": session.session_name,
                "description": session.description,
                "status": session.status,
                "created_at": session.created_at.isoformat(),
                "updated_at": session.updated_at.isoformat()
            },
            "questionnaire_responses": [
                {
                    "id": resp.id,
                    "category": resp.category,
                    "question": resp.question,
                    "description": resp.description,
                    "response": resp.response,
                    "additional_notes": resp.additional_notes,
                    "created_at": resp.created_at.isoformat()
                }
                for resp in questionnaire_responses
            ],
            "generated_use_cases": [
                {
                    "id": uc.id,
                    "title": uc.title,
                    "description": uc.description,
                    "aws_services": uc.aws_services,
                    "primary_genai_capability": uc.primary_genai_capability,
                    "business_category": uc.business_category,
                    "customer_pain_points": uc.customer_pain_points,
                    "priority": uc.priority,
                    "complexity": uc.complexity,
                    "estimated_effort": uc.estimated_effort,
                    "success_metrics": uc.success_metrics,
                    "aws_architecture": uc.aws_architecture,
                    "cost_estimate": uc.cost_estimate,
                    "dependencies": uc.dependencies,
                    "risks": uc.risks,
                    "roi_potential": uc.roi_potential,
                    "implementation_phases": uc.implementation_phases,
                    "is_selected": uc.is_selected
                }
                for uc in use_cases
            ]
        }
        
        # Update session status
        session.status = "completed"
        session.updated_at = datetime.utcnow()
        db.commit()
        
        return Response(
            content=json.dumps(report_data, indent=2),
            media_type="application/json",
            headers={
                "Content-Disposition": f"attachment; filename=pre_workshop_report_{session_id}.json"
            }
        )
    
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid report type. Supported types: pdf, json"
        )
    
class BulkUseCaseSelection(BaseModel):
    use_case_ids: List[int]
    is_selected: bool = True

@router.put("/sessions/{session_id}/use-cases/select")
def select_use_cases(
    session_id: int,
    selection_data: BulkUseCaseSelection,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Select or deselect multiple use cases at once"""
    
    # Verify session access
    session = db.query(PreWorkshopSession).filter(
        PreWorkshopSession.id == session_id
    ).first()
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    # Verify project ownership
    project = db.query(Project).filter(
        Project.id == session.project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Access denied"
        )
    
    # Validate that all use case IDs belong to this session
    use_cases = db.query(GeneratedUseCase).filter(
        GeneratedUseCase.session_id == session_id,
        GeneratedUseCase.id.in_(selection_data.use_case_ids)
    ).all()
    
    if len(use_cases) != len(selection_data.use_case_ids):
        found_ids = [uc.id for uc in use_cases]
        missing_ids = [uc_id for uc_id in selection_data.use_case_ids if uc_id not in found_ids]
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Use cases not found: {missing_ids}"
        )
    
    # Update selection status for all use cases
    updated_count = 0
    for use_case in use_cases:
        use_case.is_selected = selection_data.is_selected
        updated_count += 1
    
    db.commit()
    
    action = "selected" if selection_data.is_selected else "deselected"
    return {
        "message": f"Successfully {action} {updated_count} use cases",
        "updated_use_cases": updated_count,
        "use_case_ids": selection_data.use_case_ids,
        "is_selected": selection_data.is_selected
    }

@router.get("/sessions/{session_id}/use-cases/selected")
def get_selected_use_cases(
    session_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all selected use cases for a session"""
    
    # Verify session access
    session = db.query(PreWorkshopSession).filter(
        PreWorkshopSession.id == session_id
    ).first()
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    # Verify project ownership
    project = db.query(Project).filter(
        Project.id == session.project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Access denied"
        )
    
    # Get selected use cases
    selected_use_cases = db.query(GeneratedUseCase).filter(
        GeneratedUseCase.session_id == session_id,
        GeneratedUseCase.is_selected == True
    ).all()
    
    return {
        "session_id": session_id,
        "total_selected": len(selected_use_cases),
        "selected_use_cases": [
            {
                "id": uc.id,
                "title": uc.title,
                "description": uc.description,
                "priority": uc.priority,
                "complexity": uc.complexity,
                "roi_potential": uc.roi_potential,
                "aws_services": uc.aws_services
            }
            for uc in selected_use_cases
        ]
    }

@router.delete("/sessions/{session_id}")
def delete_pre_workshop_session(
    session_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a pre-workshop session"""
    
    # Verify session access
    session = db.query(PreWorkshopSession).filter(
        PreWorkshopSession.id == session_id
    ).first()
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    # Verify project ownership
    project = db.query(Project).filter(
        Project.id == session.project_id,
        Project.owner_id == current_user.id,
        Project.is_active == True
    ).first()
    
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Access denied"
        )
    
    # Delete uploaded file if exists
    if session.excel_file_path and os.path.exists(session.excel_file_path):
        try:
            os.remove(session.excel_file_path)
        except:
            pass  # Ignore file deletion errors
    
    # Delete associated data
    db.query(QuestionnaireResponse).filter(
        QuestionnaireResponse.session_id == session_id
    ).delete()
    
    db.query(GeneratedUseCase).filter(
        GeneratedUseCase.session_id == session_id
    ).delete()
    
    db.delete(session)
    db.commit()
    
    return {"message": "Pre-workshop session deleted successfully"}